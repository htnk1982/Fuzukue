/* 文机 アプリ：画面・入力・モード・ファイル・印刷
 * 方針：1画面。ポップアップ／ダイアログは使わない（選択肢だけはプルダウン）。
 *   上部ドック = Fキー行 ＋ 子メニュー行（開いた F グループの項目、またはインライン・フォーム）。下部 = 状態行
 *   右パネル  = 使い方／コマンド一覧（同じ画面内でトグル）。ツリーは紙面に替わる見え方
 *   表示は常に白黒＋網点（印刷イメージ）
 *   フォームの選択肢はプルダウン（select）。押すたびに値が巡るボタンは使わない（今の値と選べる値が一目で分かるように） */
(function (FZ) {
'use strict';
const $ = id => document.getElementById(id);
const M = FZ.M, G = FZ.graphemes;
const PX = 96 / 72;
const ed = new FZ.Editor();
const st = { mode: 'text', sub: null, ruleKind: 'thin', shade: 'gray', rc: { page: 0, y: 0, col: 0 }, ranchor: null, preview: null, zoom: 'width', grid: true, mono: true,
  file: null, composing: false, compStart: 0, lastPasteShift: false, lastPaste: null, jaLift: false, /* 和文の番号・記号を起こす（C-3、任意。貼付と .md/.txt の読み込みに効く） */ msg: '', msgAlert: false, msgTimer: 0,
  group: 'struct', armed: false, form: null, side: null, formFocus: false, fig: null }; // group：子メニュー行に出しているグループ（常に何か出ている）。armed：F キーを押した直後で、1 文字キーが項目の実行に使われる状態
const main = $('main'), pagesEl = $('pages'), ta = $('ta'), sub = $('sub'), sideEl = $('side');
let pageCache = [], wraps = [];
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const half = v => Math.round(v * 2) / 2;
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ================= 描画（フレーム合流・幾何キャッシュ） ================= */
let renderQueued = false, overlayQueued = false, geomDirty = true, pageGeom = [], mainW = 0, mainH = 0;
function mainSize() { if (!mainW) { mainW = main.clientWidth; mainH = main.clientHeight; } return [mainW, mainH]; }
function requestRender() { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); }
function requestOverlay() { if (overlayQueued || renderQueued) return; overlayQueued = true; requestAnimationFrame(() => { overlayQueued = false; renderOverlay(); status(); }); }
function flush() { if (renderQueued) { renderQueued = false; render(); } if (overlayQueued) { overlayQueued = false; renderOverlay(); status(); } }
function targetWidthPx() {
  const [mw, mh] = mainSize(); const avail = mw - 28; const W = ed.lay.geo.W, H = ed.lay.geo.H;
  if (st.zoom === 'width') return Math.min(avail, W * PX * 2.4);
  if (st.zoom === 'page') return Math.min(avail, (mh - 30) * W / H); // 高さを画面に合わせる
  return W * PX * Number(st.zoom); // 倍率（1 = 100%）
}
let lastWpx = 0, lastN = 0;
let skipTree = false; // 紙面のスクロールだけのときはツリーを描き直さない
function render() {
  const vw = st.view || 'paper'; document.body.classList.toggle('vtree', vw === 'tree'); document.body.classList.toggle('vsplit', vw === 'split'); document.body.classList.toggle('tfocus', st.mode === 'tree');
  if (vw !== 'paper') { if (!skipTree) renderTree(); } else if (treeEl.style.display !== 'none') { treeEl.style.display = 'none'; treeEl.innerHTML = ''; }
  if (vw === 'tree') { if (pagesEl.style.display !== 'none') pagesEl.style.display = 'none'; status(); syncView(); return; }
  if (pagesEl.style.display === 'none') { pagesEl.style.display = ''; geomDirty = true; }
  const lay = ed.lay, n = lay.pages.length;
  const wpx = Math.max(120, targetWidthPx());
  if (wpx !== lastWpx || n !== lastN) { geomDirty = true; lastWpx = wpx; lastN = n; }
  pagesEl.style.width = wpx + 'px';
  pagesEl.style.setProperty('--pw', lay.geo.W + 'pt'); pagesEl.style.setProperty('--ph', lay.geo.H + 'pt');
  while (wraps.length > n) { wraps.pop().remove(); pageCache.pop(); }
  while (wraps.length < n) { const d = document.createElement('div'); d.className = 'pgwrap'; d.dataset.page = wraps.length; pagesEl.append(d); wraps.push(d); pageCache.push(''); }
  const ph = wpx * lay.geo.H / lay.geo.W;
  const top = main.scrollTop, bottom = top + mainSize()[1]; let firstVis = 0, lastVis = n - 1;
  if (ph && n > 3) { const gap = 12; firstVis = clamp(Math.floor((top - 12) / (ph + gap)) - 1, 0, n - 1); lastVis = clamp(Math.ceil(bottom / (ph + gap)) + 1, 0, n - 1); }
  for (let p = 0; p < n; p++) {
    const w = wraps[p];
    if (p < firstVis || p > lastVis) { if (pageCache[p] !== '') { w.innerHTML = ''; pageCache[p] = ''; } w.style.height = ph + 'px'; continue; }
    w.style.height = '';
    const svg = FZ.renderPage(lay, p, { grid: st.grid, font: ed.doc.format.font, mono: true, imageHref }); if (pageCache[p] !== svg) { w.innerHTML = svg; pageCache[p] = svg; }
  }
  applyFonts();
  renderOverlay(); status();
}
function measurePages() { // 1回だけ強制レイアウト。以後はキャッシュ
  const rm = main.getBoundingClientRect(); pageGeom = wraps.map(w => { const r = w.getBoundingClientRect(); return { left: r.left - rm.left + main.scrollLeft, top: r.top - rm.top + main.scrollTop, width: r.width, height: r.height }; }); geomDirty = false;
}
function pagePt(p) { if (geomDirty || !pageGeom[p]) measurePages(); const g = pageGeom[p]; if (!g) return null; return { left: g.left, top: g.top, scale: g.width / ed.lay.geo.W }; }
function selectionRects() {
  const s = ed.sel(); if (!s) return []; const out = [];
  const before = (l, g, l2, g2) => l < l2 || (l === l2 && g < g2);
  ed.lay.pages.forEach((pg, p) => { for (const es of pg.rowmap.values()) for (const e of es) {
    if (before(e.line, e.seg, s.a.line, s.a.seg) || before(s.b.line, s.b.seg, e.line, e.seg)) continue;
    let from = e.startOff, to = e.endOff;
    if (e.line === s.a.line && e.seg === s.a.seg) from = Math.max(from, s.a.off); if (e.line === s.b.line && e.seg === s.b.seg) to = Math.min(to, s.b.off);
    if (to < from) continue; if (to === from && !(e.startOff === e.endOff)) continue;
    const colOf = off => { let best = e.carets[0]; for (const c of e.carets) if (Math.abs(c.off - off) < Math.abs(best.off - off)) best = c; return best.col; };
    const c1 = colOf(from), c2 = colOf(to); out.push({ page: p, y: e.y, h: e.h, col: c1, w: Math.max(0.3, c2 - c1) });
  } });
  return out;
}
function renderOverlay() {
  if (st.mode === 'tree') { renderTreeOverlay(); if (st.view !== 'split') return; }
  const lay = ed.lay; const pp0 = pagePt(0); const ov = { selRects: [], rects: [], lines: [], hits: [], caret: null, composing: st.composing, mono: true, scale: pp0 ? pp0.scale : 1 };
  if (st.mode === 'text') {
    ov.selRects = st.cells ? cellRects() : selectionRects();
    if (drag && drag.kind === 'tcol' && drag.rows) ov.lines.push({ page: drag.page, c1: drag.x, r1: drag.rows.y1, c2: drag.x, r2: drag.rows.y2, w: 2.2 });
    const xy = ed.xy(); if (xy) { let w = 1; const seg = ed.seg(); if (ed.caret.vcol == null && ed.caret.off < seg.text.length) { const g = G(seg.text).find(g => g.start === ed.caret.off); if (g) w = FZ.gWidth(g, seg.marks[g.start] | 0); } ov.caret = { page: xy.page, y: xy.y, h: xy.h, col: xy.col, w }; ov.caretColor = inDarkFill(xy) ? '#fff' : '#111'; }
  } else if (st.mode === 'fig') {
    const fi = figInfo(); if (fi) { const F = fi.F, X = x => fi.left + x, P = fi.page, Y = y => fi.Y0 + y; ov.handles = []; ov.ports = [];
      if (st.fig.connecting) ov.labels = F.boxes.map(b => ({ page: P, col: X(b.x), y: Y(b.y), text: String(b.id) }));
      const ids = figIds(); for (const id of ids) { const b = FZ.figureBox(F, id); if (b) ov.rects.push({ page: P, col: X(b.x) - 0.18, y: Y(b.y) - 0.12, w: b.w + 0.36, h: b.h + 0.24, fill: '#1a56c4', opacity: st.fig.connecting === id ? 0.2 : 0.07, stroke: '#1a56c4', sw: 1.1 }); } // 選択は箱の少し外に破線（箱の線の太さと紛れないように）
      const one = figSel(); if (one && !st.fig.connecting) for (const h of FZ.figureHandles(one)) ov.handles.push({ page: P, col: X(h.x), y: Y(h.y) });
      for (const id of new Set([st.fig.hover, one && one.id].filter(x => x != null))) { const b = FZ.figureBox(F, id); if (b && !drag) for (const q of FZ.figurePorts(b)) ov.ports.push({ page: P, col: X(q.x), y: Y(q.y) }); }
      if (st.fig.selArrow != null && F.arrows[st.fig.selArrow]) { const a = F.arrows[st.fig.selArrow]; const A = FZ.figureBox(F, a.from), B = FZ.figureBox(F, a.to); if (A && B) for (const sg of FZ.figureRoute(A, B)) ov.lines.push(sg.k === 'h' ? { page: P, c1: X(sg.from), r1: Y(sg.y), c2: X(sg.to), r2: Y(sg.y), w: 3 } : { page: P, c1: X(sg.col), r1: Y(sg.y1), c2: X(sg.col), r2: Y(sg.y2), w: 3 }); }
      if (st.fig.link) { const L = st.fig.link; const A = FZ.figureBox(F, L.from); if (A) { const q = FZ.figurePorts(A).find(p => p.id === L.port) || { x: A.x + A.w / 2, y: A.y + A.h / 2 }; ov.lines.push({ page: P, c1: X(q.x), r1: Y(q.y), c2: X(L.x), r2: Y(L.y), w: 1.6 }); } if (L.to != null) { const T = FZ.figureBox(F, L.to); if (T) ov.rects.push({ page: P, col: X(T.x), y: Y(T.y), w: T.w, h: T.h, fill: '#c81e1e', opacity: 0.15, stroke: '#c81e1e', solid: true, sw: 2 }); } }
      if (st.fig.band) { const bd = st.fig.band; ov.rects.push({ page: P, col: X(Math.min(bd.x1, bd.x2)), y: Y(Math.min(bd.y1, bd.y2)), w: Math.abs(bd.x2 - bd.x1), h: Math.abs(bd.y2 - bd.y1), fill: 'none', opacity: 0, stroke: '#1a56c4' }); }
      ov.rects.push({ page: P, col: fi.left, y: fi.Y0, w: fi.right - fi.left, h: F.h, fill: 'none', opacity: 0, stroke: '#9ab' });
      ov.handles.push({ page: P, col: fi.left + (fi.right - fi.left) / 2, y: Y(F.h), bar: true }); }
  } else if (st.mode === 'tree') { /* 並べる：ツリーで選んだ節の範囲を紙面に薄く示す */
    const n0 = treeNodeSel(); const list = treeSelected(); for (const n of (list.length ? list : [n0])) { const i = n && n.obj ? ed.doc.lines.indexOf(n.obj) : -1; if (i < 0) continue; const e2 = n.kind === 'sent' || n.kind === 'fig' ? i : Math.max(i, Math.min(n.end, i + 400)); const cols = lay.geo.cols; /* G2：複数選んだ節もすべて */
      for (let k = i; k <= e2; k++) { const lm = lay.lineMap[k]; if (!lm) continue; for (const r of lm.rows) ov.rects.push({ page: r.page, col: -0.4, y: r.y, w: cols + 0.8, h: r.h, fill: '#000', opacity: k === i ? 0.10 : 0.05, stroke: 'none', sw: 0 }); } }
  } else {
    const rc = st.rc; ov.lines.push({ page: rc.page, c1: rc.col - .45, r1: rc.y, c2: rc.col + .45, r2: rc.y }, { page: rc.page, c1: rc.col, r1: rc.y - .45, c2: rc.col, r2: rc.y + .45 });
    if (st.ranchor && (st.sub === 'rect' || st.mode === 'fill')) { const a = st.ranchor; ov.rects.push({ page: rc.page, col: Math.min(a.col, rc.col), y: Math.min(a.y, rc.y), w: Math.abs(a.col - rc.col), h: Math.abs(a.y - rc.y), fill: st.mode === 'fill' ? '#555' : 'none', opacity: .25, stroke: '#c81e1e' }); }
    if (st.preview) ov.lines.push(st.preview);
  }
  if (st.form === 'aiback' && st.aiBack && st.aiBack.hunks.length) { const S = st.aiBack, cols = lay.geo.cols; /* AI からの戻し：違う所（今の塊は濃く、足す所は線） */
    S.hunks.forEach((h, k) => { const cur = k === S.i;
      if (h.rem.length) for (const i of h.rem) { const lm = lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) ov.rects.push({ page: r.page, col: -0.6, y: r.y, w: cols + 1.2, h: r.h, fill: '#000', opacity: cur ? 0.13 : 0.05, stroke: cur ? '#000' : 'none', sw: cur ? 0.8 : 0 }); }
      if (h.kind === 'add' || h.kind === 'chg') { const at = h.rem.length ? h.rem[h.rem.length - 1] + 1 : h.at; const lm = lay.lineMap[Math.min(at, ed.doc.lines.length - 1)]; const r = lm && lm.rows[0]; const lmP = at > 0 ? lay.lineMap[at - 1] : null; const rp = lmP && lmP.rows[lmP.rows.length - 1];
        if (h.kind === 'add' && (r || rp)) { const y = r && at < ed.doc.lines.length ? r.y : rp.y + rp.h, pg = r && at < ed.doc.lines.length ? r.page : rp.page; ov.lines.push({ page: pg, c1: -0.6, r1: y, c2: cols + 0.6, r2: y, w: cur ? 3 : 1.5 }); } } }); }
  wraps.forEach((w, p) => { const g = w.querySelector('.ov'); if (g) g.innerHTML = FZ.renderOverlay(lay, p, ov); });
  if (ov.caret) positionTA(ov.caret);
}
function inDarkFill(xy) { const pg = ed.lay.pages[xy.page]; return pg && pg.fills.some(f => f.shade === 'dark' && xy.col >= f.col && xy.col < f.col + f.cols && xy.y >= f.y1 && xy.y < f.y2); }
function positionTA(c) {
  const pp = pagePt(c.page); if (!pp) return; const geo = ed.lay.geo; const x = geo.left + c.col * geo.cw, y = geo.top + (geo.bodyTop + c.y) * geo.ch;
  const hpx = Math.max(10, c.h * geo.ch * pp.scale), fontPx = Math.max(8, geo.cw * pp.scale);
  let cellsBefore = 0; const seg = ed.seg(); const off = ed.caret.off; for (const g of G(seg.text)) { if (g.start >= off) break; cellsBefore += FZ.isHalf(g.text.codePointAt(0)) ? 0.5 : 1; }
  const before = cellsBefore * fontPx;
  Object.assign(ta.style, { left: (pp.left + x * pp.scale - before) + 'px', top: (pp.top + y * pp.scale) + 'px', width: (before + 6) + 'px', height: hpx + 'px', fontSize: fontPx + 'px', lineHeight: hpx + 'px' });
}
function scrollToCaret(force) {
  if (st.mode === 'tree' && !force) return;
  const xy = st.mode === 'text' || force ? ed.xy() : st.mode === 'fig' ? (() => { const fi = figInfo(); if (!fi) return null; const b = st.fig.sel != null ? FZ.figureBox(fi.F, st.fig.sel) : null; return b ? { page: fi.page, y: fi.Y0 + b.y, h: b.h } : { page: fi.page, y: fi.Y0, h: fi.F.h }; })() : { page: st.rc.page, y: st.rc.y, h: 1 }; if (!xy) return; const pp = pagePt(xy.page); if (!pp) return; const geo = ed.lay.geo;
  const top = pp.top + (geo.top + (geo.bodyTop + xy.y) * geo.ch) * pp.scale, bottom = top + xy.h * geo.ch * pp.scale;
  const mh = mainSize()[1]; if (top < main.scrollTop + 24) main.scrollTop = top - 60; else if (bottom > main.scrollTop + mh - 24) main.scrollTop = bottom - mh + 60;
}
/* ================= 本文入力（隠し textarea） ================= */
function syncTA() {
  if (st.composing || st.mode !== 'text') return; const seg = ed.seg();
  if (ta.value !== seg.text) ta.value = seg.text;
  const s = ed.selInSeg(); const a = s ? s.a.off : ed.caret.off, b = s ? s.b.off : ed.caret.off;
  if (ta.selectionStart !== a || ta.selectionEnd !== b) try { ta.setSelectionRange(a, b, 'forward'); } catch { }
}
function focusTA() { if (st.formFocus) return; if (document.activeElement !== ta) ta.focus({ preventScroll: true }); }
ta.addEventListener('input', e => {
  if (st.mode !== 'text') { syncTA(); return; }
  if (ed.line().attrs.figure) { ta.value = ''; msg('図の中は Enter で編集（箱の文字は箱を選んで Enter）', true); return; }
  if (ed.line().attrs.toc) { ta.value = ''; msg('目次の行には文字を入れられません（Enter で範囲の設定、Backspace で目次を消す）', true); return; }
  if (ed.line().attrs.hr) { ta.value = ''; msg('区切り線の行には文字を入れられません（Enter で下に行を足す、Backspace で区切り線を消す）', true); return; }
  if (!st.composing && !e.isComposing) { const v = ta.value, se = ta.selectionEnd; if (autoCellify()) { ta.value = v; try { ta.setSelectionRange(se, se); } catch { } } } // keydown を経ない入力でも箱の中のセル化を適用
  ed.applyDiff(ta.value, ta.selectionEnd, { composing: st.composing || e.isComposing });
});
ta.addEventListener('compositionstart', () => { st.composing = true; st.compStart = ed.caret.off; ed.breakUndo(); requestOverlay(); });
ta.addEventListener('compositionend', () => {
  st.composing = false; if (st.mode !== 'text') { syncTA(); return; } ed.applyDiff(ta.value, ta.selectionEnd, { composing: false });
  ed.breakUndo(); syncTA(); requestOverlay();
});
ta.addEventListener('drop', e => e.preventDefault());
/* ---------- ファイルのドラッグ＆ドロップ ----------
 * 原本（.fzk／.md／.txt）は開く（今の文書が未保存なら確かめる）。画像は放した位置の行に図表として付ける（資料書式は図表欄）。
 * 窓のどこに落としても、ブラウザがファイルへ移動して文書を失わないように既定の動作を止める。
 * 上書き保存：放した項目からファイルの参照（File System Access）を取れれば同じファイルに保存、取れなければ Ctrl+S で保存先を聞く */
const DROP_DOC = /\.(fzk|md|markdown|txt|json)$/i, DROP_IMG = /\.(png|jpe?g|gif|svg|webp)$/i;
const isFileDrag = dt => !!dt && [...(dt.types || [])].includes('Files');
let dropEl = null, dropTimer = 0;
function dropHint(on, text) { if (!dropEl) { dropEl = document.createElement('div'); dropEl.id = 'dropHint'; document.body.append(dropEl); } if (on) dropEl.innerHTML = `<span>${esc(text)}</span>`; dropEl.classList.toggle('on', !!on); }
window.addEventListener('dragover', e => { if (!isFileDrag(e.dataTransfer)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; clearTimeout(dropTimer); dropTimer = setTimeout(() => dropHint(false), 250);
  if (!dropEl || !dropEl.classList.contains('on')) dropHint(true, '放すと開きます（.fzk／.md／.txt）　画像は放した行に図表として入ります'); });
window.addEventListener('dragleave', e => { if (!e.relatedTarget) dropHint(false); });
window.addEventListener('drop', e => {
  if (!isFileDrag(e.dataTransfer)) return; e.preventDefault(); e.stopPropagation(); clearTimeout(dropTimer); dropHint(false);
  const ents = [...e.dataTransfer.items].filter(it => it.kind === 'file').map(it => ({ file: it.getAsFile(), handle: fsHandle(it) })).filter(x => x.file); // 参照はイベントの中で取る
  dropFiles(ents, e).catch(er => msg('開けませんでした：' + er.message, true));
}, true);
function fsHandle(it) { try { return typeof it.getAsFileSystemHandle === 'function' ? Promise.resolve(it.getAsFileSystemHandle()).catch(() => null) : null; } catch { return null; } }
async function dropFiles(ents, e) {
  const docs = ents.filter(x => DROP_DOC.test(x.file.name)), imgs = ents.filter(x => /^image\//.test(x.file.type) || DROP_IMG.test(x.file.name));
  if (docs.length) { const d = docs[0]; const text = await d.file.text(); const h = d.handle ? await d.handle : null;
    withDiscard(() => { loadText(text, d.file.name, h && h.kind === 'file' ? { handle: h, name: d.file.name } : null); if (docs.length > 1) msg(`${docs.length} 個のうち「${d.file.name}」を開きました（原本は 1 つずつ開きます）`); }); return; }
  if (imgs.length) {
    if (st.form) closeForm(); if (st.mode !== 'text') exitMode();
    const g = e && eventToGrid(e); if (g && g.row >= 0 && g.row < ed.lay.geo.rows) { const pos = FZ.xyToPos(ed.lay, g.page, Math.floor(g.row), half(clamp(g.col, 0, ed.lay.geo.cols))); if (pos) ed.setCaret(pos); } // 放した行に付ける
    if (ed.line().attrs.figure) { msg('流れ図の行には画像を付けられません。別の行に放してください', true); return; }
    let last = null; for (const x of imgs) { try { const r = await readImageBlob(x.file, x.file.name); if (last) { const nm = ed.addImage(last.mime, last.data, last.name); ed.addFigure({ file: nm, kind: '図', title: '' }); } last = r; } catch (er) { msg('画像を読めませんでした：' + x.file.name, true); } }
    if (last) addImageFigure(last); render(); return; }
  { const dx = ents.find(x => /\.docx$/i.test(x.file.name)); if (dx) { importDocxFile(dx.file); return; } } // Word：構造を起こして取り込む（X5）
  const n = ents[0] ? ents[0].file.name : ''; msg(/\.(doc|pptx?|xlsx?|pdf)$/i.test(n) ? `「${n}」は開けません（Word は .docx なら取り込めます。PowerPoint などは、生成 AI や Office で Markdown にしてから開いてください）` : `「${n}」は開けない種類のファイルです（.fzk／.md／.txt と画像）`, true);
}
function clipText(raw) { const plain = FZ.expandRefsText(ed.doc, raw); st.clip = plain !== raw ? { plain, raw } : null; return plain; } // 外へは図番を「図 1」の文字に開いて渡す
ta.addEventListener('copy', e => { if (st.mode === 'tree') { e.clipboardData.setData('text/plain', treeCopyText()); e.preventDefault(); msg('選んだ節を子ごと Markdown で写しました'); return; } if (st.cells) { const R = cellRect(); if (R) { e.clipboardData.setData('text/plain', FZ.tbl.cellsText(ed, R)); e.preventDefault(); msg('セルを写しました（タブ区切り）'); return; } } const s = ed.sel(); const t = s ? ed.textOf(s) : ed.line().segs.map(x => x.text).join('\t') + '\n'; e.clipboardData.setData('text/plain', clipText(t)); e.preventDefault(); });
ta.addEventListener('cut', e => { if (st.mode === 'tree') { e.preventDefault(); return; } const s = ed.sel(); if (!s) { e.preventDefault(); return; } e.clipboardData.setData('text/plain', clipText(ed.textOf(s))); e.preventDefault(); ed.mutate('', () => ed.deleteSelection()); });
/* 貼り付けの出どころ（Office は HTML の Generator、スプレッドシートは印）：'excel'｜'sheets'｜'powerpoint'｜'word'｜'' */
function clipSource(html) {
  if (!html) return ''; const g = (html.match(/<meta[^>]*name=["']?Generator["']?[^>]*content=["']?([^"'>]*)/i) || html.match(/<meta[^>]*content=["']?([^"'>]*)["']?[^>]*name=["']?Generator/i) || [])[1] || '';
  if (/Excel/i.test(g) || /urn:schemas-microsoft-com:office:excel/i.test(html)) return 'excel'; if (/google-sheets-html-origin/i.test(html)) return 'sheets';
  if (/PowerPoint/i.test(g) || /urn:schemas-microsoft-com:office:powerpoint/i.test(html)) return 'powerpoint'; if (/Word/i.test(g) || /urn:schemas-microsoft-com:office:word/i.test(html)) return 'word'; return '';
}
/* Excel・スプレッドシートの HTML からセルの書式を読む（完全互換ではなく、文机の白黒の世界に写せるものだけ）：
 * 太字・下線・取消線・揃え（右・中央）・背景色（明るさで 淡／薄網／濃網 の 3 段に。濃網は白抜き）。結合セルは空のセルで埋める。読めなければ null */
function shadeOf(c) {
  c = String(c || '').trim().toLowerCase(); if (!c || /^(none|transparent|auto|inherit|initial|windowtext|window|white)$/.test(c)) return null;
  const NAMED = { black: '000000', gray: '808080', grey: '808080', silver: 'c0c0c0', yellow: 'ffff00', red: 'ff0000', blue: '0000ff', green: '008000', lime: '00ff00', aqua: '00ffff', cyan: '00ffff', navy: '000080', teal: '008080', maroon: '800000', purple: '800080', olive: '808000', fuchsia: 'ff00ff', orange: 'ffa500' };
  let r, g, b, m; c = c.replace(/\s*!important$/, '').split(/\s+/)[0];
  if ((m = c.match(/^#?([0-9a-f]{6})$/))) { r = parseInt(m[1].slice(0, 2), 16); g = parseInt(m[1].slice(2, 4), 16); b = parseInt(m[1].slice(4, 6), 16); }
  else if ((m = c.match(/^#?([0-9a-f]{3})$/))) { r = parseInt(m[1][0] + m[1][0], 16); g = parseInt(m[1][1] + m[1][1], 16); b = parseInt(m[1][2] + m[1][2], 16); }
  else if ((m = c.match(/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/))) { r = +m[1]; g = +m[2]; b = +m[3]; }
  else if (NAMED[c]) return shadeOf('#' + NAMED[c]); else return null;
  const L = (0.299 * r + 0.587 * g + 0.114 * b) / 255; return L >= 0.96 ? null : L >= 0.84 ? 'light' : L >= 0.55 ? 'gray' : 'dark';
}
function sheetGrid(html) {
  let dd; try { dd = new DOMParser().parseFromString(html, 'text/html'); } catch { return null; } const table = dd.querySelector('table'); if (!table) return null;
  const css = {}; for (const st of dd.querySelectorAll('style')) for (const m of st.textContent.matchAll(/\.([\w-]+)\s*\{([^}]*)\}/g)) css[m[1]] = (css[m[1]] || '') + ';' + m[2];
  const decl = t => { const o = {}; for (const part of String(t).split(';')) { const k = part.indexOf(':'); if (k > 0) o[part.slice(0, k).trim().toLowerCase()] = part.slice(k + 1).trim().replace(/^['"]|['"]$/g, ''); } return o; };
  const textOf = td => { const c = td.cloneNode(true); c.querySelectorAll('br').forEach(b => b.replaceWith('\u2028')); return c.textContent.replace(/\u00a0/g, ' ').replace(/[ \t\r\n]+/g, ' ').replace(/\s*\u2028\s*/g, ' ').trim(); };
  const rows = []; let any = false;
  table.querySelectorAll('tr').forEach((tr, r) => { const row = rows[r] = rows[r] || []; let c = 0;
    for (const td of tr.children) { if (!/^(TD|TH)$/.test(td.tagName)) continue; while (row[c]) c++;
      const stl = decl((td.className ? String(td.className).split(/\s+/).map(k => css[k] || '').join(';') : '') + ';' + (td.getAttribute('style') || ''));
      const text = textOf(td); const inner = (sel) => { const e = td.querySelector(sel); return !!e && textOf(e) === text && text !== ''; };
      const fw = stl['font-weight'] || ''; const deco = (stl['text-decoration'] || '') + ' ' + (stl['text-line-through'] || '');
      const cell = { text, bold: /^(bold|bolder|[6-9]00)$/.test(fw) || inner('b,strong'), under: /underline/.test(deco) || (!!stl['text-underline-style'] && stl['text-underline-style'] !== 'none') || inner('u'), strike: /line-through|single/.test(deco) || inner('s,strike,del'),
        align: ({ right: 'right', center: 'center', centre: 'center', justify: 'justify' })[(stl['text-align'] || td.getAttribute('align') || '').toLowerCase()] || null, shade: shadeOf(stl['background'] || stl['background-color'] || td.getAttribute('bgcolor')) };
      if (cell.bold || cell.under || cell.strike || cell.align || cell.shade) any = true;
      const cs = Math.max(1, Math.min(50, +td.getAttribute('colspan') || 1)), rs = Math.max(1, Math.min(500, +td.getAttribute('rowspan') || 1));
      for (let dr = 0; dr < rs; dr++) for (let dc = 0; dc < cs; dc++) { const rr = rows[r + dr] = rows[r + dr] || []; rr[c + dc] = dr || dc ? { text: '', shade: cell.shade, cont: true } : cell; }
      c += cs; } });
  const n = Math.max(0, ...rows.map(r => r.length)); if (!rows.length || !n) return null;
  for (const r of rows) for (let k = 0; k < n; k++) if (!r[k]) r[k] = { text: '' };
  while (rows.length && rows[rows.length - 1].every(x => !x.text)) rows.pop(); return rows.length ? { rows, styled: any } : null;
}
/* 書式付きの表を差し込む：Markdown の表で組んでから、セルの太字・下線・取消線・揃え・網を当てる */
function insertSheet(grid) {
  const esc2 = t => t.replace(/\|/g, '｜').replace(/([\\`*_\[\]<>~])/g, '\\$1'); const n = grid.rows[0].length;
  const md = grid.rows.map((r, i) => '| ' + r.map(c => esc2(c.text)).join(' | ') + ' |' + (i === 0 ? '\n|' + Array.from({ length: n }, () => ' --- ').join('|') + '|' : '')).join('\n') + '\n';
  const d = FZ.fromMarkdown(md, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true });
  const tl = []; d.lines.forEach((l, i) => { if (l.attrs.cells) tl.push(i); }); if (tl.length !== grid.rows.length) { insertDoc(d); return; }
  const shaded = grid.rows.some(r => r.some(c => c.shade)); if (shaded) d.fills = d.fills.filter(x => x.from > tl[tl.length - 1] || x.to < tl[0]); // Excel に網があれば、文机の既定の見出しの網の代わりに Excel の網
  tl.forEach((li, r) => { const ln = d.lines[li]; const cells = grid.rows[r]; const segs = ln.segs.slice().sort((a, b) => a.col - b.col); const bounds = FZ.cellsAt(d, li, d.format.cols);
    const al = cells.map(c => c.align || null); if (al.some(Boolean)) ln.attrs.cellAlign = al.map(x => x || 'left');
    segs.forEach((sg, k) => { const c = cells[k]; if (!c) return; const add = (c.bold ? M.BOLD : 0) | (c.under ? M.UNDER : 0) | (c.strike ? M.STRIKE : 0); if (add) sg.marks = sg.marks.map(m => m | add); });
    let k = 0; while (k < cells.length) { const sh = cells[k].shade; if (!sh || !bounds[k]) { k++; continue; } let e = k; while (e + 1 < cells.length && cells[e + 1].shade === sh && bounds[e + 1]) e++; d.fills.push({ id: FZ.uid(), col: bounds[k].left, cols: bounds[e].right - bounds[k].left, from: li, to: li, shade: sh }); k = e + 1; } });
  insertDoc(d);
}
ta.addEventListener('paste', e => {
  if (st.mode === 'tree') { e.preventDefault(); treePaste(e.clipboardData.getData('text/plain') || ''); return; }
  e.preventDefault(); const dt = e.clipboardData; const text = dt.getData('text/plain'); const html = dt.getData('text/html') || ''; const src = clipSource(html);
  const imgItem = [...(dt.items || [])].find(x => x.kind === 'file' && /^image\//.test(x.type)); const shift = st.lastPasteShift;
  if (st.mode !== 'text' || ed.line().attrs.figure || ed.line().attrs.toc || ed.line().attrs.hr) return;
  /* 貼り付けの振り分け：Excel・スプレッドシートのセル（2 つ以上）→ 表。図・画像（Excel のグラフ、PowerPoint の図形・画像、画面の切り取り、ブラウザの画像）→ 図表（挿入の「画像」と同じ）。
     それ以外の文字（Word・ブラウザの文章）は従来どおり。Word の文章には画面の絵も付いてくるが、文字を優先する。Ctrl+Shift+V は文字のまま */
  const sheet = (src === 'excel' || src === 'sheets') && /<table/i.test(html) && text;
  if (sheet && !shift) { const rows = FZ.parseTSV(text); const n = rows.reduce((t, r) => t + r.length, 0);
    if (n >= 2) { const grid = sheetGrid(html); const tsvRows = rows.length; const imgP = imgItem && imgItem.getAsFile() ? readImageBlob(imgItem.getAsFile(), '') : null; if (imgP) imgP.catch(() => { });
      if (grid && grid.rows.length === tsvRows) insertSheet(grid); else insertMarkdown(FZ.tsvToMarkdown(text));
      st.lastPaste = { kind: 'sheet', snap: ed.undoStack[ed.undoStack.length - 1], img: imgP }; st.lastPasteShift = false; ed.breakUndo();
      msg((src === 'excel' ? 'Excel' : 'スプレッドシート') + ' のセルを表として貼り付け' + (grid && grid.styled ? '（太字・揃え・網を写す）' : '') + '：' + (FZ.chartable && FZ.chartable(rows) ? 'Ctrl+G でグラフに／' : '') + (imgP ? 'Ctrl+Alt+V で見た目のまま図に／' : '') + 'Ctrl+Z で取消／Ctrl+Shift+V で文字のまま', false, 8000); return; }
    ed.insertText(text.replace(/\r?\n$/, ''), { key: '' }); st.lastPasteShift = false; ed.breakUndo(); return; } // セル 1 つは文字（末尾の改行は付けない）
  if (imgItem && (!text.trim() || src === 'powerpoint' || ((src === 'excel' || src === 'sheets') && !/<table/i.test(html)))) { const fl = imgItem.getAsFile(); st.lastPasteShift = false;
    if (fl) readImageBlob(fl, '').then(r => { addImageFigure(r); if (src === 'powerpoint' || src === 'excel') msg((src === 'excel' ? 'Excel のグラフ・図' : 'PowerPoint の図形・画像') + 'を図として貼り付け：題を入れて Enter'); }, er => msg('画像を貼り付けられませんでした：' + er.message, true)); return; } // 図・画像 → 図表
  if (!text) return;
  if (st.clip && st.clip.plain === text) { ed.insertText(st.clip.raw, { key: '' }); ed.breakUndo(); return; } // 文机の中でのコピー：図番の字を保ったまま
  if (!st.lastPasteShift && !/\n./.test(text.replace(/\r/g, '').replace(/\n+$/, '')) && /\*\*[^*\n]+\*\*|~~[^~\n]+~~/.test(text) && insertInlineMarkdown(text)) { st.lastPasteShift = false; ed.breakUndo(); msg('太字・取消線を整えて貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); return; } // 1 行の **太字**
  const multi = text.replace(/\r/g, '').split('\n').length >= 2;
  if (!st.lastPasteShift && FZ.looksLikeTSV(text)) { insertMarkdown(FZ.tsvToMarkdown(text)); msg('表として貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else if (!st.lastPasteShift && multi && FZ.looksLikeMarkdown(text)) { insertMarkdown(text); msg('Markdown として整形（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else if (!st.lastPasteShift && multi && st.jaLift && FZ.jaMarkerCount(text) >= 2) { insertMarkdown(text); msg('和文の番号・記号を見出し・箇条書きに起こして貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else { ed.insertText(text, { key: '' }); st.lastPaste = { text, snap: ed.undoStack[ed.undoStack.length - 1] }; if (multi && FZ.markdownSignals(text).inline + FZ.markdownSignals(text).list) msg('そのまま貼り付け（Markdown として整形：Ctrl+Alt+V）'); }
  st.lastPasteShift = false; ed.breakUndo();
});
/* 1 行の Markdown（**太字** ~~取消~~ リンク）を、今の位置に文字として差し込む（行は分けない）。段落 1 つにならなければ false */
function insertInlineMarkdown(text) {
  let d; try { d = FZ.fromMarkdown(text.replace(/\r?\n+$/, ''), { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true }); } catch { return false; }
  const ls = d.lines.filter(l => l.segs.some(s => s.text)); if (ls.length !== 1 || ls[0].segs.length !== 1 || ls[0].attrs.style || ls[0].attrs.list || ls[0].attrs.cells) return false; const sg = ls[0].segs[0];
  ed.mutate('', () => { ed.deleteSelection(); ed.materialize(); const seg = ed.seg(), at = ed.caret.off; ed.spliceSeg(seg, at, at, sg.text, sg.marks.map(m => (m & ~M.LINK) | (ed.typing & ~M.LINK))); if (sg.links) { seg.links = (seg.links || []).concat(sg.links.map(l => ({ ...l, start: l.start + at, end: l.end + at }))); FZ.syncLinks(seg); } ed.caret.off = at + sg.text.length; ed.caret.vcol = null; ed.anchor = null; });
  return true;
}
/* 直前にそのまま貼った文字列を Markdown として整形し直す（取り消してから変換。クリップボードは読まない） */
function pasteAsMarkdown() {
  const lp = st.lastPaste;
  if (lp && lp.kind === 'sheet') { // Excel のセルを表で貼った直後：見た目のまま図に貼り直す（表を取り消してから図）
    if (!lp.snap || ed.undoStack[ed.undoStack.length - 1] !== lp.snap) { msg('直前の貼り付けがありません（表を貼った直後に Ctrl+Alt+V）', true); return; }
    if (!lp.img) { msg('コピー元が図を渡していないので、図にできません', true); return; }
    lp.img.then(r => { if (ed.undoStack[ed.undoStack.length - 1] !== lp.snap) return; ed.mutate('', () => ed.restore(lp.snap)); st.lastPaste = null; addImageFigure(r); msg('Excel のセルを図に貼り直しました（題を入れて Enter／Ctrl+Z で表に戻る）'); }, er => msg('図を読めませんでした：' + er.message, true)); return; } if (!lp || !lp.snap || ed.undoStack[ed.undoStack.length - 1] !== lp.snap) { msg('直前の貼り付けがありません（貼り付けた直後に Ctrl+Alt+V）', true); return; }
  insertMarkdown(lp.text, lp.snap); st.lastPaste = null; ed.breakUndo(); msg('Markdown として整形（Ctrl+Z でそのままの貼付に戻る）');
}
/* Markdown を今の文書に差し込む。貼付なので「# が 1 つなら表題」にはせず、改行は行として保つ（ワープロの作法） */
function insertMarkdown(text, before) { // before：この状態に戻してから差し込む（そのまま貼った直後の整形し直し）
  if (text.length > BIG_TEXT && getWorker()) { parseText(text, 'md', { fragment: true, hardBreaks: true }, JSON.parse(JSON.stringify(ed.doc.format))).then(d => insertDoc(d, before)).catch(e => msg('整形できませんでした：' + e.message, true)); return; }
  insertDoc(FZ.fromMarkdown(text, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true }), before);
}
function insertDoc(d, before) {
  if (st.jaLift) FZ.liftJaMarkers(d);
  ed.mutate('', () => {
    if (before) ed.restore(before);
    ed.deleteSelection(); ed.materialize(); const c = ed.caret; let at = c.line; const cur = ed.line();
    const replace = cur.segs.length === 1 && cur.segs[0].text === '' && !FZ.inTable(ed.doc, at);
    if (!replace) at = c.line + 1;
    d.lines.forEach((ln, k) => ed.insertLine(at + k, ln));
    for (const r of d.rules) { if (r.axis === 'h') r.line += at; else { r.from += at; r.to += at; } ed.doc.rules.push(r); }
    for (const f of d.fills) { f.from += at; f.to += at; ed.doc.fills.push(f); }
    if (replace) ed.removeLine(at + d.lines.length);
    ed.dedupeRules(); ed.normalizeSegs();
    const last = at + d.lines.length - 1; const ll = ed.doc.lines[last]; ed.caret = { line: last, seg: ll.segs.length - 1, off: ll.segs[ll.segs.length - 1].text.length, vcol: null, vrow: 0 }; ed.anchor = null;
  });
}
/* ---------- 文書の挿入・分割（専用機の「他文書の結合」「文書分割」） ---------- */
/* 挿入する文書の画像・図表・図番を、今の文書と重ならないように付け替える（同じ名前で中身が違う画像は名前を変える。図表の ID が重なれば変える。図番の字は今の文書の表で振り直す） */
function mergeAssets(d) {
  const imgMap = new Map(); ed.doc.images = ed.doc.images || {};
  for (const [nm, img] of Object.entries(d.images || {})) { const cur = ed.doc.images[nm]; if (!cur) { ed.doc.images[nm] = img; continue; } if (cur.data === img.data) continue; let k = 2, nn; const m = nm.match(/^(.*?)(\.[^.]*)?$/); do { nn = m[1] + '_' + k++ + (m[2] || ''); } while (ed.doc.images[nn]); ed.doc.images[nn] = img; imgMap.set(nm, nn); }
  const ids = new Set(); for (const ln of ed.doc.lines) for (const fg of ln.attrs.figs || []) ids.add(fg.id); const idMap = new Map();
  for (const ln of d.lines) { for (const fg of ln.attrs.figs || []) { if (imgMap.has(fg.file)) fg.file = imgMap.get(fg.file); if (ids.has(fg.id)) { let k = 2; while (ids.has(fg.id + '_' + k)) k++; idMap.set(fg.id, fg.id + '_' + k); fg.id = fg.id + '_' + k; } ids.add(fg.id); }
    for (const sg of ln.segs) { if (sg.links) for (const l of sg.links) if (l.image && imgMap.has(l.url)) l.url = imgMap.get(l.url);
      if (FZ.hasRefs(sg.text)) { let t = ''; for (const ch of sg.text) { const id = FZ.refId(d, ch); t += id != null ? FZ.refChar(ed.doc, idMap.get(id) || id) : ch; } sg.text = t; } } }
}
async function insertFileHere() {
  let r; try { r = await FZ.files.open(); } catch (e) { msg('開けませんでした：' + e.message, true); return; } if (!r) return;
  const isMd = /\.(md|markdown)$/i.test(r.name || ''); let d;
  try { d = /^\uFEFF?#fzk\b/.test(r.text) ? FZ.parse(r.text) : isMd ? FZ.fromMarkdown(r.text, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true }) : FZ.parse(r.text); } catch (e) { msg('読めませんでした：' + e.message, true); return; }
  mergeAssets(d); insertDoc(d); render(); msg(`「${r.name}」を挿入しました（${d.lines.length} 行。${K('undo')} で取り消し）`);
}
/* カーソルの行から文末までを別の文書として保存し、保存できたらこの文書から除く（取り消しで戻せる） */
async function splitHere() {
  if (st.mode !== 'text') exitMode(); const L = ed.caret.line, N = ed.doc.lines.length; if (L === 0) { msg('文書の先頭では分けられません（分けたい行にカーソルを置く）', true); return; }
  const e2 = new FZ.Editor(); e2.onChange = () => { }; e2.onCaret = () => { }; e2.setDoc(FZ.parse(FZ.serialize(ed.doc))); for (let k = 0; k < L; k++) e2.removeLine(0);
  const tail = FZ.serialize(e2.doc); const base = baseTitle();
  let r; try { r = await FZ.files.saveAs(tail, base + '_後半.fzk'); } catch (e) { msg('保存できませんでした：' + e.message, true); return; } if (!r) return;
  ed.mutate('split', () => { for (let k = N - 1; k >= L; k--) ed.removeLine(k); if (!ed.doc.lines.length) ed.insertLine(0, FZ.newLine()); const last = ed.doc.lines.length - 1; ed.caret = { line: last, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; });
  render(); msg(`${L + 1} 行目から先を「${r.name}」に保存し、この文書から除きました（この文書は未保存。${K('undo')} で戻せる）`, false, 10000);
}
/* ローマ字をかなに（Rupo の「シフトミス訂正」）：選んだ範囲、無ければカーソルの直前の英字の続き */
function romajiHere() {
  if (st.mode !== 'text') return; let s = ed.selInSeg();
  if (!s) { if (ed.sel()) { msg('1 つのセルか段落の中を選んでください', true); return; } const c = ed.caret, t = ed.seg().text; let a = c.off; while (a > 0 && /[A-Za-z'\-]/.test(t[a - 1])) a--; if (a === c.off) { msg('カーソルの前に英字がありません（範囲を選んでも可）', true); return; } ed.setCaret({ line: c.line, seg: c.seg, off: a }); ed.setCaret({ line: c.line, seg: c.seg, off: c.off }, true); s = ed.selInSeg(); }
  const src = ed.textOf(s); const kana = FZ.romajiToKana(src); if (kana === src) { msg('かなに直せる英字がありません', true); return; }
  ed.insertText(kana, { key: 'romaji' }); flush(); msg(`「${src.slice(0, 20)}」をかなにしました。漢字にするには IME の再変換（変換キー）`);
}
/* 字数（専用機の文書情報表示）：全体と選択範囲。原稿用紙は 400 字詰め（20 字×20 行、段落ごとに行を改め、行頭 1 字下げ）で換算 */
function countInfo() {
  const isSp = ch => /[\s\u3000]/.test(ch); let all = 0, noSp = 0, paras = 0, rows = 0;
  for (const ln of ed.doc.lines) { const t = ln.segs.map(sg => sg.text).join(''); const n = [...t].length; all += n; let k = 0; for (const ch of t) if (!isSp(ch)) k++; noSp += k; if (k) paras++; rows += k ? Math.ceil((n + 1) / 20) : 1; }
  const s = ed.sel(); let sel = null; if (s) { const t = ed.textOf(s); const n = [...t.replace(/\n/g, '')].length; let k = 0; for (const ch of t) if (!isSp(ch)) k++; sel = { n, k }; }
  return { all, noSp, paras, rows, sheets: Math.ceil(rows / 20), pages: ed.lay.pages.length, sel };
}
FZ.countInfo = countInfo;
function prepareTyping() {
  if (st.cells) { st.cells = null; requestOverlay(); }
  autoCellify();
  const s = ed.sel(); const needDel = s && !ed.selInSeg();
  if (needDel || ed.caret.vcol != null || ed.caret.vrow > 0) { ed.pushUndo('type'); if (needDel) ed.deleteSelection(); ed.materialize(); ed.relayout(); ed.onChange('edit'); flush(); syncTA(); }
}
/* 空行に囲み（内側の縦罫線）があるとき、その中で打ち始めたら自動でセルにする（箱の中の文字） */
function autoCellify() {
  const c = ed.caret; const i = c.line; const ln = ed.line(); if (ln.attrs.cells || c.vrow > 0) return false;
  const vr = FZ.vRulesAt(ed.doc, i).filter(r => r.col > 0 && r.col < ed.lay.geo.cols); if (!vr.length) return false;
  if (!ln.segs.every(sg => !sg.text.trim())) return false;
  const xy = ed.xy(); const col = c.vcol != null ? c.vcol : (xy ? xy.col : 0);
  ed.mutate('', () => { ed.cellify(i); const cells = FZ.cellsAt(ed.doc, i); const k = Math.max(0, cells.findIndex(x => col >= x.left && col < x.right)); const l2 = ed.line(); let sidx = l2.segs.findIndex(sg => sg.col === cells[k].left); if (sidx < 0) { l2.segs.push(FZ.newSeg(cells[k].left, '')); l2.segs.sort((a, b) => a.col - b.col); sidx = l2.segs.findIndex(sg => sg.col === cells[k].left); } c.seg = sidx; c.off = 0; c.vcol = null; });
  flush(); syncTA(); return true;
}
/* ================= キー操作 ================= */
ta.addEventListener('keydown', onKey);
function onKey(e) {
  if (st.mode !== 'text') { modeKey(e); return; }
  if (!st.composing && !e.isComposing && e.keyCode !== 229 && ta.value !== ed.seg().text) syncTA();
  if (e.isComposing || e.keyCode === 229 || e.key === 'Process') { prepareTyping(); return; }
  const k = e.key, ctrl = e.ctrlKey || e.metaKey, shift = e.shiftKey, alt = e.altKey;
  // 開いている子メニュー：1キーで実行して閉じる。合わないキーは閉じて通常処理
  if (st.armed && !ctrl && !alt && k.length === 1) { const it = GROUPS[st.group].items.find(it => it.key && it.key.toLowerCase() === k.toLowerCase()); if (it) { e.preventDefault(); const g0 = st.group; disarm(); runItem(it); if (st.group === g0) afterGroupItem(); if (it.msel) drawSub(); return; } disarm(); }
  if (/^F\d+$/.test(k) && !ctrl && !alt) { if (fkey(k)) e.preventDefault(); return; }
  if (st.cells && !['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(k)) { // セルの範囲を選んでいる：Delete で中身を消す、Esc でやめる、Ctrl+C で写す。ほかのキーは範囲を解いて通常どおり
    if ((k === 'Delete' || k === 'Backspace') && !ctrl) { e.preventDefault(); const R = cellRect(); st.cells = null; if (R) FZ.tbl.clearCells(ed, R); return; }
    if (k === 'Escape') { e.preventDefault(); st.cells = null; requestOverlay(); drawSub(); return; }
    if (ctrl && (k.toLowerCase() === 'c')) return;
    st.cells = null; requestOverlay(); }
  if (k === 'Escape') { e.preventDefault(); escape(); return; }
  if (ctrl && !alt) {
    const lk = k.toLowerCase(); let done = true;
    switch (lk) {
      case 's': run(shift ? 'saveAs' : 'save'); break; case 'o': run(shift ? 'outlinePanel' : 'open'); break; case 'z': shift ? run('redo') : run('undo'); break; case 'y': run('redo'); break;
      case 'f': run('find'); break; case 'h': run('replace'); break; case 'p': run('print'); break; case 'k': run('palette'); break; case 'a': ed.selectAll(); break;
      case 'b': run('bold'); break; case 'u': run('under'); break; case 'e': run('alignC'); break; case 'r': run('alignR'); break; case 'j': run('alignJ'); break;
      case 'l': if (shift) run('link'); else run('alignL'); break; case 'g': run(shift ? 'grid' : 'chart'); break;
      case 'home': ed.docStart(shift); break; case 'end': ed.docEnd(shift); break;
      case '=': case '+': case ';': run('zoomIn'); break; case '-': run('zoomOut'); break; case '0': run(shift ? 'zoomPage' : 'zoomFit'); break;
      case 'v': st.lastPasteShift = shift; done = false; break; case 'c': case 'x': done = false; break;
      case 'enter': run('pageBreak'); break; case 'n': run('new'); break; case 'm': run(shift ? 'posLeft' : 'moveTo'); break; // Ctrl+M：送り先を選んで移す（S3）。位置は F6→J／H、Ctrl+Shift+M は左へ
      case 'arrowup': run('outlineUp'); break; case 'arrowdown': run('outlineDown'); break;
      case 'arrowleft': ed.moveH(-1, shift); break; case 'arrowright': ed.moveH(1, shift); break;
      default: done = false;
    }
    if (done) e.preventDefault(); return;
  }
  if (ctrl && alt && k.toLowerCase() === 'v') { e.preventDefault(); run('pasteMd'); return; }
  if (alt) { const m2 = { ArrowUp: 'sx:up', ArrowDown: 'sx:down', ArrowLeft: 'sx:out', ArrowRight: 'sx:in' }[k]; if (m2) { run(m2); e.preventDefault(); } return; } // 構造の近道：紙面でもツリーと同じ意味（梯子・並べ替え）
  if (ed.line().attrs.hr && !ctrl) { // 区切り線の行：Enter で下に本文の行、Backspace/Delete で区切り線を消して空行に
    if (k === 'Enter') { e.preventDefault(); const at = ed.caret.line; ed.mutate('', () => { ed.insertLine(at + 1, FZ.newLine()); ed.caret = { line: at + 1, seg: 0, off: 0, vcol: null, vrow: 0 }; }); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); ed.setAttrs({ hr: null }); msg('区切り線を消しました'); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('区切り線の行には文字を入れられません', true); return; }
  }
  if (ed.line().attrs.toc && !ctrl) { // 目次の行：Enter で範囲の設定、Backspace/Delete で目次を消して空行に
    if (k === 'Enter') { e.preventDefault(); openForm('toc'); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); ed.removeToc(ed.caret.line); msg('目次を消しました'); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('目次の行には文字を入れられません（Enter で範囲の設定）', true); return; }
  }
  if (ed.line().attrs.figure && !ctrl) { // 図の行：Enter で図の編集へ。箱が無ければ Backspace/Delete で本文の空行に戻す
    if (k === 'Enter') { e.preventDefault(); enterFigMode(ed.caret.line); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); if (!ed.line().attrs.figure.boxes.length) ed.removeFigure(ed.caret.line); else msg('図を消すには、箱をすべて消してから Backspace', true); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('図の中は Enter で編集', true); return; }
  }
  let handled = true;
  switch (k) {
    case 'Enter': if (shift) ed.softBreak(); else ed.enter(); break; case 'Tab': ed.tab(shift); break; /* Shift+Enter：段落・項目の中の改行 */ case 'Backspace': ed.backspace(); break; case 'Delete': ed.del(); break;
    case 'ArrowLeft': ed.moveH(-1, shift); break; case 'ArrowRight': ed.moveH(1, shift); break; case 'ArrowUp': ed.moveV(-1, shift); break; case 'ArrowDown': ed.moveV(1, shift); break;
    case 'Home': ed.home(shift); break; case 'End': ed.end(shift); break;
    case 'PageUp': for (let i = 0; i < Math.max(4, ed.lay.geo.rows - 4); i++) ed.moveV(-1, shift); break; case 'PageDown': for (let i = 0; i < Math.max(4, ed.lay.geo.rows - 4); i++) ed.moveV(1, shift); break;
    default: handled = false;
  }
  if (handled) { e.preventDefault(); return; }
  if (k.length === 1) prepareTyping();
}
function escape() { if (st.form) { closeForm(); return; } if (GROUPS[st.group] && GROUPS[st.group].parent) { showGroup(GROUPS[st.group].parent); return; } if (st.armed) { disarm(); return; } if (st.side) { closeSide(); return; } if (ed.sel()) { ed.anchor = null; ed.onCaret(); } }
function fkey(k) {
  const map = FK[st.mode === 'fill' ? 'fill' : st.mode === 'rule' ? 'rule' : st.mode === 'fig' ? 'fig' : 'text']; const item = map.find(x => x[0] === k); /* ツリーも紙面と同じ F キー */ if (!item || !item[2]) { if (FK_HIDDEN[k]) { run(FK_HIDDEN[k]); return true; } return false; } run(item[2]); return true;
}
/* ---------- 罫線・網掛けモードのキー ---------- */
function modeKey(e) {
  if (st.mode === 'tree') { treeKeyDown(e); return; }
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey;
  if (e.isComposing || e.keyCode === 229) { e.preventDefault(); return; }
  if (st.mode === 'fig') { figKey(e); return; }
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  e.preventDefault();
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.ranchor) { st.ranchor = null; requestOverlay(); return; } exitMode(); return; }
  if (ctrl && k.toLowerCase() === 'z') { shift ? ed.redo() : ed.undo(); return; } if (ctrl && k.toLowerCase() === 'y') { ed.redo(); return; }
  if (ctrl && k.toLowerCase() === 's') { run('save'); return; } if (ctrl && k.toLowerCase() === 'k') { run('palette'); return; }
  const dir = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[k];
  if (dir) { if (st.mode === 'fill' || st.sub === 'rect') { if (!st.ranchor) st.ranchor = { ...st.rc }; ruleMove(dir); } else ruleStep(dir, !shift); return; }
  if (st.mode === 'fill' && !ctrl && k.length === 1) { const id = Object.keys(SWATCH_KEY).find(x => SWATCH_KEY[x] === k.toUpperCase()); if (id) { run('s:' + id); return; } } // 見本の 1 文字で文様を選ぶ
  if (k === 'Enter') { if (st.mode === 'fill') applyFill(); else if (st.sub === 'rect') applyRect(); else { st.ranchor = { ...st.rc }; st.sub = 'rect'; drawSub(); drawFkeys(); status(); } return; }
  if (k === 'Home') { st.rc.col = 0; requestOverlay(); return; } if (k === 'End') { st.rc.col = ed.lay.geo.cols; requestOverlay(); return; }
  if (k === 'PageDown') { if (st.rc.page < ed.lay.pages.length - 1) { st.rc.page++; st.rc.y = 0; st.ranchor = null; requestOverlay(); scrollToCaret(); } return; }
  if (k === 'PageUp') { if (st.rc.page > 0) { st.rc.page--; st.rc.y = 0; st.ranchor = null; requestOverlay(); scrollToCaret(); } return; }
  if (k === 'Backspace' || k === 'Delete') { st.sub = st.sub === 'erase' ? null : 'erase'; drawSub(); drawFkeys(); status(); return; }
}
/* ================= 罫線モード ================= */
function enterRuleMode() { if (st.composing || st.mode === 'rule') return; if (st.mode === 'tree') exitTree(); if (st.mode === 'fig') st.fig = null; const xy = ed.xy(); st.mode = 'rule'; st.sub = null; st.ranchor = null; st.preview = null; st.rc = xy ? { page: xy.page, y: Math.max(0, xy.y), col: Math.max(0, Math.floor(xy.col)) } : { page: 0, y: 0, col: 0 }; ed.anchor = null; st.group = null; st.form = null; render(); drawFkeys(); drawSub(); focusTA(); }
function enterFillMode() { if (st.mode === 'tree') exitTree(); if (st.mode === 'fig') { st.fig = null; st.mode = 'text'; } if (st.mode === 'text') { const xy = ed.xy(); st.rc = xy ? { page: xy.page, y: Math.max(0, xy.y), col: Math.max(0, Math.floor(xy.col)) } : { page: 0, y: 0, col: 0 }; } st.mode = 'fill'; st.sub = null; st.ranchor = null; st.preview = null; ed.anchor = null; st.group = null; st.form = null; render(); drawFkeys(); drawSub(); focusTA(); }
function exitMode() { if (st.mode === 'tree') { if (st.treeCmd) return; /* コマンドの中から呼ばれたとき（st.treeCmd）はツリーのまま */ exitTree(); return; } if (st.mode === 'fig') { exitFigMode(); return; } st.mode = 'text'; st.sub = null; st.ranchor = null; st.preview = null; const rc = st.rc; const pos = FZ.xyToPos(ed.lay, rc.page, Math.min(rc.y, Math.max(0, ed.lay.geo.rows - 1)), rc.col); if (pos) ed.setCaret(pos); render(); drawFkeys(); drawSub(); syncTA(); focusTA(); }
function ruleMove(dir) { const rc = st.rc, geo = ed.lay.geo; const maxY = geo.rows; if (dir === 'left') rc.col = Math.max(0, rc.col - 1); if (dir === 'right') rc.col = Math.min(geo.cols, rc.col + 1); if (dir === 'up') rc.y = Math.max(0, rc.y - 1); if (dir === 'down') rc.y = Math.min(maxY, rc.y + 1); requestOverlay(); scrollToCaret(); }
function ensureRows(page, y) { const e = ed.lay.endPos; if (page !== e.page || y < e.y) return; const need = y - e.y + 1; for (let k = 0; k < need; k++) ed.insertLine(ed.doc.lines.length, FZ.newLine()); ed.relayout(); }
function hSeg(page, y, from, to, erase, dir) { ed.mutate('rule', () => { let line = ed.hAnchorAt(page, y); if (line == null) { ensureRows(page, y - 1); line = ed.hAnchorAt(page, y); } if (line == null) { msg('折返し行の途中には横線を引けません', true); return; } if (erase) ed.eraseH(line, from, to); else { const id = ed.addHRule(line, from, to, st.ruleKind, dir); } }); }
function vSeg(page, y, col, erase, dir) { ed.mutate('rule', () => { let line = ed.vAnchorAt(page, y); if (line == null) { ensureRows(page, y); line = ed.vAnchorAt(page, y); } if (line == null) return; if (erase) ed.eraseV(line, line, col); else { const id = ed.addVRule(line, line, col, st.ruleKind, dir); } }); }
function ruleStep(dir, draw) {
  const rc = st.rc, geo = ed.lay.geo, erase = st.sub === 'erase'; const maxY = geo.rows;
  if (dir === 'right') { if (rc.col >= geo.cols) return; if (draw) hSeg(rc.page, rc.y, rc.col, rc.col + 1, erase, 'r'); rc.col++; }
  if (dir === 'left') { if (rc.col <= 0) return; if (draw) hSeg(rc.page, rc.y, rc.col - 1, rc.col, erase, 'l'); rc.col--; }
  if (dir === 'down') { if (rc.y >= maxY) return; if (draw) vSeg(rc.page, rc.y, rc.col, erase, 'd'); rc.y++; }
  if (dir === 'up') { if (rc.y <= 0) return; if (draw) vSeg(rc.page, rc.y - 1, rc.col, erase, 'u'); rc.y--; }
  requestOverlay(); scrollToCaret();
}
function rectCoords() { const a = st.ranchor || st.rc, b = st.rc; return { page: b.page, y1: Math.min(a.y, b.y), y2: Math.max(a.y, b.y), c1: Math.min(a.col, b.col), c2: Math.max(a.col, b.col) }; }
function applyRect() {
  const r = rectCoords(); if (r.y2 <= r.y1 || r.c2 <= r.c1) { st.ranchor = null; requestOverlay(); return; }
  ed.mutate('', () => { ensureRows(r.page, r.y2 - 1); const la = ed.hAnchorAt(r.page, r.y1), lb = ed.hAnchorAt(r.page, r.y2); const vf = ed.vAnchorAt(r.page, r.y1), vt = ed.vAnchorAt(r.page, r.y2 - 1);
    if (la == null || lb == null || vf == null || vt == null) { msg('この範囲には囲みを引けません（折返し行の途中）', true); return; }
    if (st.sub === 'erase') { ed.eraseH(la, r.c1, r.c2); ed.eraseH(lb, r.c1, r.c2); ed.eraseV(vf, vt, r.c1); ed.eraseV(vf, vt, r.c2); } else { ed.addHRule(la, r.c1, r.c2, st.ruleKind); ed.addHRule(lb, r.c1, r.c2, st.ruleKind); ed.addVRule(vf, vt, r.c1, st.ruleKind); ed.addVRule(vf, vt, r.c2, st.ruleKind); } });
  st.ranchor = null; st.sub = null; drawSub(); drawFkeys();
}
function applyFill() {
  const r = rectCoords(); if (r.y2 <= r.y1 || r.c2 <= r.c1) { st.ranchor = null; requestOverlay(); return; }
  ed.mutate('', () => { ensureRows(r.page, r.y2 - 1); const vf = ed.vAnchorAt(r.page, r.y1), vt = ed.vAnchorAt(r.page, r.y2 - 1); if (vf == null || vt == null) return; ed.addFill(vf, vt, r.c1, r.c2 - r.c1, st.shade); });
  st.ranchor = null; drawSub();
}
/* ================= 図モード（フローチャート） =================
 * 紙面の上で直接いじる：クリックで選ぶ（Shift で足す）、ドラッグで動かす、四隅・辺のつまみで大きさ、箱の辺の点から別の箱へドラッグで矢印、
 * 空いた所をダブルクリックで箱を足す、箱・矢印をダブルクリックでその場で文字、空いた所をドラッグで囲んで選ぶ、図の下端のつまみで高さ。
 * キー（Tab・矢印・N・C・Delete…）とコマンドも残す */
function figInfo(line = st.fig ? st.fig.line : ed.caret.line) {
  const ln = ed.doc.lines[line]; if (!ln || !ln.attrs.figure) return null; const lm = ed.lay.lineMap[line]; if (!lm || !lm.rows[0]) return null;
  const r = lm.rows[0], row = lm.segs[0].rows[0]; return { line, F: ln.attrs.figure, page: r.page, Y0: r.y, left: row.left, right: row.right };
}
function figRowAt(g) { const p = ed.lay.pages[g.page]; if (!p) return null; const es = p.rowmap.get(Math.floor(g.row)); const e = es && es.find(x => x.fig); return e ? e.line : null; }
function enterFigMode(line, sel) {
  const ln = ed.doc.lines[line]; if (!ln || !ln.attrs.figure) return; if (st.form) closeForm(); if (st.armed) disarm(); st.cells = null;
  ed.anchor = null; ed.setCaret({ line, seg: 0, off: 0 }); st.mode = 'fig'; st.sub = null; st.ranchor = null; st.preview = null;
  const F = ln.attrs.figure; st.fig = { line, sel: sel !== undefined ? sel : (F.boxes[0] ? F.boxes[0].id : null), multi: new Set(), selArrow: null, connecting: false, hover: null, band: null, link: null };
  render(); drawFkeys(); drawSub(); focusTA();
}
function exitFigMode() { closeInline(true); st.mode = 'text'; const line = st.fig ? st.fig.line : ed.caret.line; st.fig = null; st.sub = null; pagesEl.style.cursor = ''; if (ed.doc.lines[line]) ed.setCaret({ line, seg: 0, off: 0 }); render(); drawFkeys(); drawSub(); syncTA(); focusTA(); }
/* 選択：1 つなら sel、2 つ以上なら multi（sel はその最後＝つまみを出す箱ではない） */
function figIds() { if (!st.fig) return []; if (st.fig.multi && st.fig.multi.size) return [...st.fig.multi]; return st.fig.sel != null ? [st.fig.sel] : []; }
function figSetSel(ids) { const arr = [...new Set(ids)]; st.fig.selArrow = null; st.fig.multi = new Set(arr.length >= 2 ? arr : []); st.fig.sel = arr.length ? arr[arr.length - 1] : null; }
function figSelect(id, add) { const cur = new Set(figIds()); if (add) { if (cur.has(id)) cur.delete(id); else cur.add(id); } else { cur.clear(); if (id != null) cur.add(id); } figSetSel([...cur]); }
function figSel() { const fi = figInfo(); const ids = figIds(); if (!fi || ids.length !== 1) return null; return FZ.figureBox(fi.F, ids[0]) || null; }
function figPrim() { const fi = figInfo(); const ids = figIds(); return fi && ids.length ? FZ.figureBox(fi.F, ids[ids.length - 1]) || null : null; }
function figRefresh() { requestOverlay(); drawSub(); status(); }
function figCycle(dir) { // Tab：箱 → 矢印 の順に選択を巡る
  const fi = figInfo(); if (!fi) return; const F = fi.F; const items = [...F.boxes.map(b => ({ box: b.id })), ...F.arrows.map((a, k) => ({ arrow: k }))]; if (!items.length) return;
  let k = items.findIndex(it => (st.fig.sel != null && it.box === st.fig.sel) || (st.fig.selArrow != null && it.arrow === st.fig.selArrow)); k = (k + dir + items.length) % items.length; if (k < 0) k = 0;
  const it = items[k]; figSetSel(it.box != null ? [it.box] : []); st.fig.selArrow = it.arrow ?? null; figRefresh(); scrollToCaret();
}
function figMove(dx, dy, resize) {
  const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) { if (fi && fi.F.boxes.length) { figSetSel([fi.F.boxes[0].id]); figRefresh(); } return; }
  const W = fi.right - fi.left;
  ed.figOp(fi.line, F => { const bs = ids.map(id => FZ.figureBox(F, id)).filter(Boolean);
    if (resize) { const bb = bs[bs.length - 1]; bb.w = clamp(bb.w + dx, 2, W - bb.x); bb.h = clamp(bb.h + dy, 1, F.h - bb.y); return; }
    const ddx = clamp(dx, -Math.min(...bs.map(b => b.x)), W - Math.max(...bs.map(b => b.x + b.w))), ddy = clamp(dy, -Math.min(...bs.map(b => b.y)), F.h - Math.max(...bs.map(b => b.y + b.h)));
    for (const b of bs) { b.x += ddx; b.y += ddy; } }, resize ? 'figsize' : 'figmove');
  figRefresh();
}
/* 箱を足す：at（図の座標）があればそこを中心に、無ければ選んだ箱の隣。足したらその場で文字を打てる */
function figAddBox(at) {
  const fi = figInfo(); if (!fi) return; const W = fi.right - fi.left; const sel = figSel(); let newId = 0;
  ed.figOp(fi.line, F => { newId = F.boxes.reduce((m, b) => Math.max(m, b.id), 0) + 1; let spot; if (at) { spot = { x: clamp(half(at.x - 4), 0, Math.max(0, W - 8)), y: Math.max(0, Math.round(at.y - 1.5)) }; } else spot = FZ.figureFreeSpot(F, W, sel, 8, 3);
    const b = { id: newId, x: spot.x, y: spot.y, w: 8, h: 3, text: '', kind: 'thin', shade: null, bold: false }; if (spot.y + 3 > F.h) F.h = spot.y + 3; F.boxes.push(b); });
  figSetSel([newId]); figRefresh(); flush(); openInline('box', newId);
}
function figDelete() {
  const fi = figInfo(); if (!fi) return;
  if (st.fig.selArrow != null) { const k = st.fig.selArrow; ed.figOp(fi.line, F => { F.arrows.splice(k, 1); }); st.fig.selArrow = null; figRefresh(); return; }
  const ids = figIds(); if (!ids.length) return; const order = fi.F.boxes.map(x => x.id); const k = order.indexOf(ids[0]);
  ed.figOp(fi.line, F => { F.boxes = F.boxes.filter(x => !ids.includes(x.id)); F.arrows = F.arrows.filter(a => !ids.includes(a.from) && !ids.includes(a.to)); });
  const left = fi.F.boxes; figSetSel(left.length ? [left[clamp(k, 0, left.length - 1)].id] : []); figRefresh();
  if (!left.length) msg('箱がありません。Esc で本文へ戻り Backspace で図を消せます');
}
function figConnectStart() { const b = figPrim(); if (!b) { msg('まず箱を選んでください（箱の辺の点から別の箱へドラッグしてもつなげます）', true); return; } st.fig.connecting = b.id; st.fig.selArrow = null; figRefresh(); }
function figConnect(from, to) {
  const fi = figInfo(); if (!fi || from == null || to == null || to === from) { figRefresh(); return; }
  let idx = -1; ed.figOp(fi.line, F => { const k = F.arrows.findIndex(a => a.from === from && a.to === to); if (k >= 0) { idx = k; return; } F.arrows.push({ from, to, label: '', kind: 'thin' }); idx = F.arrows.length - 1; });
  figSetSel([]); st.fig.selArrow = idx; figRefresh(); msg('矢印でつなぎました（ダブルクリックでラベル、Delete で消す）');
}
function figConnectTo(targetId) { const from = st.fig.connecting; st.fig.connecting = false; figConnect(from, targetId); }
function figCycleProp(prop, vals) { const fi = figInfo(); const p = figPrim(); if (!fi || !p) return; const k = vals.indexOf(p[prop]); figSetProp(prop, vals[(k + 1) % vals.length]); }
function figSetProp(prop, val) { const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) { msg('箱を選んでください', true); return; } ed.figOp(fi.line, F => { for (const id of ids) { const b = FZ.figureBox(F, id); if (b) b[prop] = val; } }); figRefresh(); }
function figHeight(d) { const fi = figInfo(); if (!fi) return; ed.figOp(fi.line, F => { const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); F.h = clamp(F.h + d, minH, 200); }); figRefresh(); }
function figAlign(mode) { const fi = figInfo(); const ids = figIds(); if (!fi || ids.length < (mode[0] === 'd' ? 3 : 2)) { msg(mode[0] === 'd' ? '等間隔には箱を 3 つ以上選んでください（Shift+クリックか囲むドラッグ）' : '揃えるには箱を 2 つ以上選んでください（Shift+クリックか囲むドラッグ）', true); return; } ed.figOp(fi.line, F => FZ.figureAlign(F, ids, mode)); figRefresh(); }
function figDuplicate() { const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) return; let out = []; ed.figOp(fi.line, F => { out = FZ.figureDuplicate(F, ids, fi.right - fi.left); }); figSetSel(out); figRefresh(); }
function figKey(e) {
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey;
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  if (ctrl && k.toLowerCase() === 'z') { e.preventDefault(); shift ? ed.redo() : ed.undo(); figRefresh(); return; } if (ctrl && k.toLowerCase() === 'y') { e.preventDefault(); ed.redo(); figRefresh(); return; }
  if (ctrl && k.toLowerCase() === 's') { e.preventDefault(); run('save'); return; } if (ctrl && k.toLowerCase() === 'k') { e.preventDefault(); run('palette'); return; }
  if (ctrl && k.toLowerCase() === 'a') { e.preventDefault(); const fi = figInfo(); if (fi) { figSetSel(fi.F.boxes.map(b => b.id)); figRefresh(); } return; }
  if (ctrl && k.toLowerCase() === 'd') { e.preventDefault(); figDuplicate(); return; }
  if (ctrl) return;
  e.preventDefault();
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.fig.connecting) { st.fig.connecting = false; figRefresh(); return; } exitFigMode(); return; }
  if (k === 'Tab') { figCycle(shift ? -1 : 1); return; }
  const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
  if (d) { if (st.fig.connecting) { figCycle(d[0] + d[1] < 0 ? -1 : 1); return; } figMove(d[0], d[1], shift); return; }
  if (k === 'Enter') { if (st.fig.connecting) { figConnectTo(st.fig.sel); return; } if (st.fig.selArrow != null) { openInline('arrow', st.fig.selArrow); return; } const b = figPrim(); if (b) openInline('box', b.id); else figAddBox(); return; }
  if (k === 'Delete' || k === 'Backspace') { figDelete(); return; }
  const lk = k.toLowerCase();
  if (lk === 'n') figAddBox(); else if (lk === 'c') figConnectStart(); else if (lk === 't') { const b = figPrim(); if (b) openInline('box', b.id); } else if (lk === 'p') { if (figSel()) openForm('box'); } else if (lk === 'd') figDuplicate();
  else if (lk === 'k') figCycleProp('kind', ['thin', 'thick', 'double', 'dotted']); else if (lk === 's') figCycleProp('shade', [null, 'gray', 'deep', 'dark', 'hatch', 'dots']); else if (lk === 'b') figCycleProp('bold', [false, true]); else if (lk === 'l') openForm('lanes'); else if (k === '+' || k === ';' || k === '=') figHeight(1); else if (k === '-') figHeight(-1);
  else if (/^[1-9]$/.test(k)) { const fi = figInfo(); const b = fi && fi.F.boxes.find(x => x.id === +k); if (b) { if (st.fig.connecting) figConnectTo(b.id); else { figSetSel([b.id]); figRefresh(); } } }
}
/* ---------- その場の文字入力（箱の文字・矢印のラベル） ---------- */
let inl = null; // { el, kind: 'box'|'arrow', id, line }
function openInline(kind, id) {
  closeInline(true); const fi = figInfo(); if (!fi) return; const F = fi.F; const geo = ed.lay.geo; const pp = pagePt(fi.page); if (!pp) return;
  let x1, y1, w, h, text;
  if (kind === 'box') { const b = FZ.figureBox(F, id); if (!b) return; x1 = fi.left + b.x; y1 = fi.Y0 + b.y; w = b.w; h = b.h; text = b.text; }
  else { const a = F.arrows[id]; const m = FZ.figureArrowMid(F, id); if (!a || !m) return; w = Math.max(8, FZ.textWidth(a.label) + 2); h = 1; x1 = fi.left + (m.horiz ? m.x - w / 2 : m.x + 0.5); y1 = fi.Y0 + (m.horiz ? Math.max(0, Math.floor(m.y) - 1) : Math.floor(m.y)); text = a.label; }
  const s = pp.scale, el = document.createElement('textarea'); el.className = 'inl' + (kind === 'arrow' ? ' one' : ''); el.value = text; el.spellcheck = false; el.setAttribute('aria-label', kind === 'box' ? '箱の文字' : '矢印のラベル');
  const lines = Math.max(1, String(text).split('\n').length), padTop = kind === 'box' ? Math.max(2, Math.floor(Math.max(0, h - lines) / 2) * geo.ch * s) : 2; // 箱の文字は上下の中ほどから
  Object.assign(el.style, { left: (pp.left + (geo.left + x1 * geo.cw) * s) + 'px', top: (pp.top + (geo.top + (geo.bodyTop + y1) * geo.ch) * s) + 'px', width: Math.max(48, w * geo.cw * s) + 'px', height: Math.max(20, h * geo.ch * s) + 'px', fontSize: Math.max(11, geo.fs * s * 0.9) + 'px', lineHeight: Math.max(13, geo.ch * s) + 'px', paddingTop: padTop + 'px' });
  main.append(el); st.formFocus = true; inl = { el, kind, id, line: fi.line };
  el.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.isComposing || ev.keyCode === 229) return; if (ev.key === 'Escape') { ev.preventDefault(); closeInline(false); } else if ((ev.key === 'Enter' && !ev.shiftKey && !ev.altKey) || ev.key === 'Tab') { ev.preventDefault(); closeInline(true); } });
  el.addEventListener('blur', () => { if (inl && inl.el === el) closeInline(true); });
  el.focus(); el.select(); msg(kind === 'box' ? '箱の文字：Enter で決定、Shift+Enter で改行、Esc で取消' : '矢印のラベル：Enter で決定、Esc で取消', false, 0);
}
function closeInline(commit) {
  if (!inl) return; const { el, kind, id, line } = inl; inl = null; st.formFocus = false; const v = el.value; el.remove(); msg('');
  const ln = ed.doc.lines[line]; const cur = ln && ln.attrs.figure; const old = cur ? (kind === 'box' ? (FZ.figureBox(cur, id) || {}).text : (cur.arrows[id] || {}).label) : null;
  if (commit && cur && old != null && v !== old) ed.figOp(line, F => { if (kind === 'box') { const b = FZ.figureBox(F, id); if (!b) return; b.text = v; const iw = Math.max(0.5, b.w - 2 * (b.w >= 4 ? 1 : 0.5)); const need = v.split('\n').reduce((t, s) => t + Math.max(1, Math.ceil(FZ.textWidth(s) / iw - 1e-6)), 0); if (need > b.h) { b.h = need; if (b.y + b.h > F.h) F.h = b.y + b.h; } } else { const a = F.arrows[id]; if (a) a.label = v.replace(/\n/g, ' '); } });
  if (st.mode === 'fig') figRefresh(); focusTA();
}
/* ---------- マウス（図） ---------- */
function figLocal(g) { const fi = figInfo(); if (!fi) return null; return { fi, x: g.col - fi.left, y: g.row - fi.Y0 }; }
const HANDLE_CURSOR = { nw: 'nwse-resize', se: 'nwse-resize', ne: 'nesw-resize', sw: 'nesw-resize', n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize' };
/* 図の座標 loc で何をつかむか：{ t: 'handle'|'port'|'height'|'box'|'arrow'|'empty', … } */
function figWhat(fi, loc) {
  const F = fi.F, W = fi.right - fi.left; const one = figSel();
  if (one && !st.fig.connecting) { const h = FZ.figureHandles(one).find(h => Math.abs(h.x - loc.x) <= 0.5 && Math.abs(h.y - loc.y) <= 0.36); if (h) return { t: 'handle', box: one, hid: h.id }; }
  for (const id of new Set([st.fig.hover, one && one.id].filter(x => x != null))) { const b = FZ.figureBox(F, id); if (!b) continue; const p = FZ.figurePorts(b).find(p => Math.abs(p.x - loc.x) <= 0.6 && Math.abs(p.y - loc.y) <= 0.42); if (p) return { t: 'port', box: b, port: p.id }; }
  const hit = FZ.figureHit(F, loc.x, loc.y); if (hit) return { t: 'box', box: hit };
  if (Math.abs(loc.y - F.h) <= 0.4 && Math.abs(loc.x - W / 2) <= 1.6) return { t: 'height' }; // 図の下端の真ん中のつまみ
  const ak = FZ.figureArrowHit(F, loc.x, loc.y); if (ak >= 0) return { t: 'arrow', k: ak };
  return { t: 'empty' };
}
function figHoverBox(F, loc) { for (let k = F.boxes.length - 1; k >= 0; k--) { const b = F.boxes[k]; if (loc.x >= b.x - 1 && loc.x <= b.x + b.w + 1 && loc.y >= b.y - 0.7 && loc.y <= b.y + b.h + 0.7) return b.id; } return null; }
function figPointerDown(e, g, clicks = 1) {
  const loc = figLocal(g); if (!loc) return; const { fi } = loc; const F = fi.F; const cap = () => pagesEl.setPointerCapture(e.pointerId);
  const w = figWhat(fi, loc);
  if (st.fig.connecting) { const hit = FZ.figureHit(F, loc.x, loc.y); if (hit) figConnectTo(hit.id); else { st.fig.connecting = false; figRefresh(); } focusTA(); return; }
  if (w.t === 'handle') { ed.pushUndo(''); drag = { kind: 'figsize', id: e.pointerId, box: w.box.id, hid: w.hid, sx: loc.x, sy: loc.y, o: { ...w.box }, moved: false }; cap(); return; }
  if (w.t === 'port') { st.fig.link = { from: w.box.id, port: w.port, x: loc.x, y: loc.y, to: null }; drag = { kind: 'figlink', id: e.pointerId }; cap(); figRefresh(); return; }
  if (w.t === 'height') { ed.pushUndo(''); drag = { kind: 'figh', id: e.pointerId, sy: loc.y, oh: F.h, moved: false }; cap(); return; }
  if (w.t === 'box') { const hit = w.box;
    if (e.shiftKey) { figSelect(hit.id, true); figRefresh(); focusTA(); return; }
    if (!figIds().includes(hit.id)) figSelect(hit.id, false); figRefresh();
    if (clicks >= 2) { openInline('box', hit.id); return; }
    ed.pushUndo(''); const ids = figIds(); drag = { kind: 'figmove', id: e.pointerId, clicked: hit.id, orig: ids.map(i => { const b = FZ.figureBox(F, i); return { id: i, x: b.x, y: b.y, w: b.w, h: b.h }; }), sx: loc.x, sy: loc.y, moved: false }; cap(); focusTA(); return; }
  if (w.t === 'arrow') { figSetSel([]); st.fig.selArrow = w.k; figRefresh(); if (clicks >= 2) { openInline('arrow', w.k); return; } focusTA(); return; }
  if (clicks >= 2) { figAddBox({ x: loc.x, y: loc.y }); return; }
  if (!e.shiftKey) figSetSel([]);
  st.fig.band = { x1: loc.x, y1: loc.y, x2: loc.x, y2: loc.y, base: figIds() }; drag = { kind: 'figband', id: e.pointerId }; cap(); figRefresh(); focusTA();
}
function figDragMove(g) {
  const loc = figLocal(g); if (!loc || !drag) return; const { fi } = loc; const F = fi.F; const W = fi.right - fi.left;
  if (drag.kind === 'figmove') { const o = drag.orig; let dx = half(loc.x - drag.sx), dy = Math.round(loc.y - drag.sy);
    dx = clamp(dx, -Math.min(...o.map(b => b.x)), W - Math.max(...o.map(b => b.x + b.w))); dy = clamp(dy, -Math.min(...o.map(b => b.y)), F.h - Math.max(...o.map(b => b.y + b.h)));
    let ch = false; for (const ob of o) { const b = FZ.figureBox(F, ob.id); if (!b) continue; if (b.x !== ob.x + dx || b.y !== ob.y + dy) { b.x = ob.x + dx; b.y = ob.y + dy; ch = true; } }
    if (ch) { drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figsize') { const b = FZ.figureBox(F, drag.box); if (!b) return; const r = FZ.figureResize(drag.o, drag.hid, loc.x - drag.sx, loc.y - drag.sy, W, F.h); if (r.x !== b.x || r.y !== b.y || r.w !== b.w || r.h !== b.h) { Object.assign(b, r); drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figh') { const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); const h = clamp(Math.round(drag.oh + loc.y - drag.sy), minH, 200); if (h !== F.h) { F.h = h; drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figlink') { const L = st.fig.link; L.x = loc.x; L.y = loc.y; const hit = FZ.figureHit(F, loc.x, loc.y); L.to = hit && hit.id !== L.from ? hit.id : null; requestOverlay(); return; }
  if (drag.kind === 'figband') { const bd = st.fig.band; bd.x2 = loc.x; bd.y2 = loc.y; const x1 = Math.min(bd.x1, bd.x2), x2 = Math.max(bd.x1, bd.x2), y1 = Math.min(bd.y1, bd.y2), y2 = Math.max(bd.y1, bd.y2);
    const inside = F.boxes.filter(b => b.x < x2 && b.x + b.w > x1 && b.y < y2 && b.y + b.h > y1).map(b => b.id); figSetSel([...bd.base, ...inside]); figRefresh(); }
}
function figDragEnd(d) {
  if (d.kind === 'figmove' || d.kind === 'figsize' || d.kind === 'figh') { if (d.moved) ed.onChange('edit'); else { ed.undoStack.pop(); if (d.kind === 'figmove' && d.orig.length > 1) figSetSel([d.clicked]); } } // 選んだ中の箱を動かさずにクリック：その箱だけを選ぶ
  else if (d.kind === 'figlink') { const L = st.fig.link; st.fig.link = null; if (L && L.to != null) figConnect(L.from, L.to); }
  else if (d.kind === 'figband') st.fig.band = null;
  figRefresh(); if (!inl) focusTA();
}
function figHover(g) {
  const loc = figLocal(g); if (!loc) return ''; const { fi } = loc; const F = fi.F; const hv = figHoverBox(F, loc); if (hv !== st.fig.hover) { st.fig.hover = hv; requestOverlay(); }
  if (Math.floor(g.row) !== fi.Y0 + Math.floor(loc.y) || loc.y < -0.5 || loc.y > F.h + 0.5) return '';
  const w = figWhat(fi, loc); return w.t === 'handle' ? HANDLE_CURSOR[w.hid] : w.t === 'port' ? 'crosshair' : w.t === 'box' ? 'move' : w.t === 'height' ? 'ns-resize' : w.t === 'arrow' ? 'pointer' : 'default';
}
/* ================= ツリー（構造を直接いじる見え方） =================
 * 本文の領域を切り替えて、文書の構造を左から右（または上から下）に広がる節として描く。データは文書そのもので、操作はすべて文書の編集（取り消しも共通）。
 * キー：矢印で移動、Enter 弟・Shift+Enter 兄・Tab 子、Alt+矢印で動かす・浅く深く、F2 文字、Delete 消す、Space 畳む、1〜9 深さ・0 本文まで、Esc 紙面へ。
 * マウス：クリックで選ぶ（Shift で足す）、ダブルクリックで文字、ドラッグで動かす（節の上・下・右に落とす）、空いた所を囲んで選ぶ、寄せると出る ＋ で足す */
const treeEl = $('tree'), tpane = $('treePane');
st.view = 'paper'; // 見え方：paper（紙面）・tree（ツリー）・split（並べる）。st.mode が 'tree' なら、操作の先はツリー
st.tree = { show: new Set(), scale: (() => { try { const v = +localStorage.getItem('fz.treeScale'); return v >= 0.5 && v <= 3 ? v : 1; } catch (e) { return 1; } })(), sel: null, multi: new Set(), depth: 9, dir: 'i', folds: new WeakSet(), hover: null, drop: null, band: null, view: null, edit: null };
const TREE_FS = 13, TREE_LH = 18, TREE_PX = 8, TREE_IND = 30;
function treeBuild(forceBody) { const title = ed.doc.title || (st.file && st.file.name ? st.file.name.replace(/\.[^.]+$/, '') : '') || '文書'; const nums = ed.lay.figNums; const tr = FZ.tree.build(ed.doc, { body: forceBody || st.tree.depth <= 0, sentences: st.tree.depth === -1, figs: true, title, figLabel: fg => { const nn = nums && nums.get(fg.id); return (nn ? nn.label : fg.kind) + (fg.title ? '　' + fg.title : '') + (fg.chart ? '' : fg.file ? '' : '（画像なし）'); } }); const r = tr.root; tr.top = (r.children.length === 1 && r.children[0].kind === 'title') ? r.children[0] : r; if (!forceBody && st.tree.depth > 0 && !tr.nodes.some(n => n.kind !== 'body' && n.kind !== 'block' && n !== tr.top)) { const t2 = treeBuild(true); t2.flat = true; return t2; } return tr; } /* 見出しも箇条書きも無い平文：段落を平らに並べて見せる（構造はここから作る） */
const treeKey = n => n.key || n.fig || n.obj || 'root';
/* 図表の節（図版・表・流れ図）：名前だけを出し、「表示」で中身を紙面と同じ描画で見せる（窓の幅と紙面での大きさの小さい方） */
const treeShowable = n => n && (n.kind === 'fig' || (n.kind === 'block' && (n.block === 'table' || n.block === 'figure')));
const treeShowKey = n => n.kind === 'fig' ? 'f:' + n.fig.id : 'b:' + n.line;
/* 紙面の上の範囲（pt）：{ page, x, y, w, h } */
function treeFigRect(n) { const L = ed.lay, geo = L.geo, cw = geo.cw, ch = geo.ch; const X = c => geo.left + c * cw, Y = r => geo.top + (geo.bodyTop + r) * ch;
  if (n.kind === 'fig') { for (let p = 0; p < L.pages.length; p++) { const pg = L.pages[p]; for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) if (im.id === n.fig.id) return { page: p, x: X(im.col) - 2, y: Y(im.y) - 2, w: im.w * cw + 4, h: im.h * ch + 4 }; } return null; }
  const lm = L.lineMap[n.line]; if (!lm || !lm.rows[0]) return null; const p = lm.rows[0].page; let y1 = Infinity, y2 = -Infinity; for (let i = n.line; i <= n.end; i++) { const m = L.lineMap[i]; if (!m) continue; for (const r of m.rows) if (r.page === p) { y1 = Math.min(y1, r.y); y2 = Math.max(y2, r.y + r.h); } } if (!(y2 > y1)) return null;
  let l, r; if (n.block === 'table') { const I = FZ.tbl.info(ed, n.line); if (!I) return null; l = I.L; r = I.R; } else { const row = lm.segs[0] && lm.segs[0].rows[0]; if (!row) return null; l = row.left; r = row.right; }
  return { page: p, x: X(l) - 2, y: Y(y1) - 2, w: (r - l) * cw + 4, h: (y2 - y1) * ch + 4 }; }
/* 紙面のページの描画をそのまま切り抜いて埋める（文様の id は付け替え：隠れた紙面の定義を指さない） */
function treeFigSvg(rc, x, y, w, h, k, cache) { let svg = cache.get(rc.page); if (svg == null) { svg = FZ.renderPage(ed.lay, rc.page, { grid: false, font: ed.doc.format.font, mono: true, imageHref }); cache.set(rc.page, svg); }
  const fsz = (svg.match(/font-size="([\d.]+)"/) || [])[1] || '10'; const body = svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '').replace(new RegExp('(s_[a-z0-9]+_|gdot)' + rc.page + '(?=["\\)])', 'g'), '$1t' + k);
  return `<svg class="pg tfig" x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${rc.x} ${rc.y} ${rc.w} ${rc.h}" preserveAspectRatio="xMinYMin meet" font-size="${fsz}">${body}</svg>`; }
function treeMarker(n) { if (n.root || n.kind === 'title' || n.kind === 'body' || n.kind === 'block') return ''; const lm = ed.lay.lineMap[n.line]; const row = lm && lm.segs[0] && lm.segs[0].rows[0]; if (!row) return ''; return row.glyphs.filter(g => g.marker).map(g => g.text).join('').trim(); }
function treeWrap(text, cols, maxLines) { const out = []; let cur = '', w = 0; for (const g of FZ.graphemes(text)) { const gw = FZ.textWidth(g.text); if (w + gw > cols + 1e-6) { out.push(cur); cur = ''; w = 0; if (out.length >= maxLines) break; } cur += g.text; w += gw; } if (out.length < maxLines) out.push(cur); else if (out.join('').length + cur.length < text.length || cur) { const last = out[maxLines - 1]; out[maxLines - 1] = last.slice(0, Math.max(0, last.length - 1)) + '…'; } return out.slice(0, maxLines).map(s => s || ''); }
function treeCount(n) { let c = 0; for (const k of n.children) c += 1 + treeCount(k); return c; }
/* 描く子：畳んだ節は描かない。深さ d（1〜9）より深い節は描かない（0＝本文まで全部） */
function treeVisKids(n, top) { if (st.tree.folds.has(treeKey(n))) return []; const d = st.tree.depth; return n.children.filter(c => d <= 0 || c.depth - top.depth <= d); } // 0＝本文まで、−1＝文まで（どちらも全部）
function renderTree() {
  treeEl.style.display = 'block';
  const tr = treeBuild(); const top = tr.top; const vis = n => treeVisKids(n, top); const isBox = n => !!n.para && vis(n).some(c => c.kind === 'sent'); const layVis = n => isBox(n) ? vis(n).filter(c => c.kind !== 'sent') : vis(n); /* 段落は文を収める枠：文は枠の中に縦に積む（木の行にしない） */
  const info = new Map(); // 節 → { lines, w, h, mk }
  const M = 20, IND = TREE_IND, dirI = st.tree.dir === 'i'; const PY = st.tree.exportW ? 5 : 3; // 箱の上下の余白：画面は詰めて行を多く見せる（書き出しは従来の 5）
  const shown = []; const walk = n => { shown.push(n); for (const c of vis(n)) walk(c); }; walk(top);
  const textOf = n => { const mk = treeMarker(n); return { mk, text: (mk ? mk + ' ' : '') + (n.text || (n.root ? '' : '（空）')) }; };
  /* 字下げ：箱は画面の右端まで伸ばす（右の余白は子を足す ＋ の分だけ）。収まらない文は箱の中で折り返す */
  const layK = targetWidthPx() / ed.lay.geo.W; const figCache = new Map(); let figK = 0; // 紙面での 1pt の画素
  const SC = st.tree.scale; const availW = st.tree.exportW ? st.tree.exportW : Math.max(240, (tpane.clientWidth - 16 - (tpane.scrollHeight > tpane.clientHeight ? 0 : 17)) / SC - M - 30); // 縦のスクロールバーが後から出ても横にはみ出さない。倍率の分だけ狭く組んで拡大する
  const sizeOf = (n, d) => { let x = info.get(n); if (x) return x; const body = n.kind === 'body' || n.kind === 'block'; const { mk, text } = textOf(n);
    if (isBox(n)) { const PB = PY + 1; const w = dirI ? Math.max(8 * TREE_FS + TREE_PX * 2, availW - (d | 0) * IND) : 22 * TREE_FS + TREE_PX * 2 + PB * 2; const iw = w - PB * 2; const cols = Math.max(4, Math.floor((iw - TREE_PX * 2) / TREE_FS)); let y = PB; const inner = [];
      for (const c of vis(n).filter(c2 => c2.kind === 'sent')) { const lines = treeWrap(c.text || '（空）', cols, 4); const h = lines.length * TREE_LH + PY * 2; inner.push({ c, rx: PB, ry: y, w: iw, h, lines }); y += h + 2; }
      x = { lines: [], mk: '', w, h: y - 2 + PB, inner, box: true }; info.set(n, x); return x; }
    const showable = treeShowable(n), open = showable && st.tree.show.has(treeShowKey(n)); const rc = open ? treeFigRect(n) : null;
    if (dirI) { const w = Math.max(6 * TREE_FS + TREE_PX * 2, availW - (d | 0) * IND); const fold = n.children.length && !vis(n).length; const cols = Math.max(4, Math.floor((w - TREE_PX * 2) / TREE_FS) - (fold ? 3 : 0) - (showable ? 4 : 0)); // 畳んだ数（＋n）・「表示」は箱の右端の中に。種類は箱に書かない（考える邪魔。帯の「種類」で見る・変える）
      const lines = treeWrap(text, cols, body ? 2 : 3); const fig = rc ? (() => { const fw = Math.max(40, Math.min(w - TREE_PX * 2, rc.w * layK)); return { rc, w: fw, h: rc.h * fw / rc.w }; })() : null;
      x = { lines, mk, w, h: lines.length * TREE_LH + PY * 2 + (fig ? fig.h + PY + 3 : 0), fig, showable, open }; info.set(n, x); return x; }
    const cols = body ? 20 : showable ? 16 : 13; const lines = treeWrap(text, cols, 2); let w0 = cols * TREE_FS + TREE_PX * 2; const fig = rc ? (() => { const fw = Math.max(40, Math.min(480, rc.w * layK)); return { rc, w: fw, h: rc.h * fw / rc.w }; })() : null; if (fig) w0 = Math.max(w0, fig.w + TREE_PX * 2);
    x = { lines, mk, w: w0, h: lines.length * TREE_LH + PY * 2 + (fig ? fig.h + PY + 3 : 0), fig, showable, open }; info.set(n, x); return x; };
  const L = FZ.tree.layout(top, { dir: st.tree.dir, visible: layVis, size: sizeOf, gapDepth: 40, gapSib: dirI ? (st.tree.exportW ? 6 : 4) : 8, indent: IND });
  for (const n of shown) { const s0 = info.get(n); if (!s0 || !s0.box) continue; const p = L.pos.get(n); for (const it of s0.inner) { L.pos.set(it.c, { x: p.x + it.rx, y: p.y + it.ry, w: it.w, h: it.h, depth: p.depth + 1 }); info.set(it.c, { lines: it.lines, mk: '', w: it.w, h: it.h, inBox: true }); } } /* 枠の中の文の位置 */
  // 選択を今の木に合わせる（消えた節なら親へ）
  const byKey = new Map(shown.map(n => [treeKey(n), n])); if (!st.tree.sel || !byKey.has(st.tree.sel)) { let p = st.tree.sel && tr.byObj.get(st.tree.sel); if (!p && st.tree.selLine != null) { const same = tr.nodes.filter(n => n.text === st.tree.selText).sort((a, b) => Math.abs(a.line - st.tree.selLine) - Math.abs(b.line - st.tree.selLine)); p = same[0] || FZ.tree.nodeAt(tr, Math.min(st.tree.selLine, ed.doc.lines.length - 1)); } while (p && !byKey.has(treeKey(p))) p = p.parent; st.tree.sel = treeKey(p || top); } // 取り消しで行が作り直されても、同じ行の節を選んだまま
  { const n = byKey.get(st.tree.sel); st.tree.selLine = n.line; st.tree.selText = n.text; }
  if (st.tree.pendSel) { const [a0, b0] = st.tree.pendSel; st.tree.pendSel = null; const ns = shown.filter(n => !n.root && n !== top && n.line != null && n.line >= a0 && n.line <= b0 && !(n.parent && n.parent.line != null && n.parent.line >= a0 && n.parent !== top && !n.parent.root)); if (ns.length > 1) { st.tree.multi = new Set(ns.map(treeKey)); st.tree.sel = treeKey(ns[0]); } }
  for (const k of [...st.tree.multi]) if (!byKey.has(k)) st.tree.multi.delete(k);
  const P = n => L.pos.get(n); const o = []; const edges = []; /* 線の点（書き出し用。画面の座標から余白 M を引いたもの） */
  for (const n of shown) { const kids = layVis(n); if (!kids.length) continue; const p = P(n);
    if (dirI) { const lx = M + p.x + 14; let d = '', last = 0; for (const c of kids) { const q = P(c); last = M + q.y + q.h / 2; d += `M${lx} ${last}H${M + q.x}`; edges.push({ pts: [[lx - M, last - M], [q.x, last - M]] }); } o.push(`<path d="M${lx} ${M + p.y + p.h}V${last}${d}"/>`); edges.push({ pts: [[lx - M, p.y + p.h], [lx - M, last - M]] }); continue; } // 親の下から縦の線、子へ横の枝
    for (const c of kids) { const q = P(c); if (st.tree.dir === 'h') { const x1 = M + p.x + p.w, y1 = M + p.y + p.h / 2, x2 = M + q.x, y2 = M + q.y + q.h / 2, mx = x1 + 18; o.push(`<path d="M${x1} ${y1}H${mx}V${y2}H${x2}"/>`); edges.push({ pts: [[x1 - M, y1 - M], [mx - M, y1 - M], [mx - M, y2 - M], [x2 - M, y2 - M]] }); } else { const x1 = M + p.x + p.w / 2, y1 = M + p.y + p.h, x2 = M + q.x + q.w / 2, y2 = M + q.y, my = y1 + 18; o.push(`<path d="M${x1} ${y1}V${my}H${x2}V${y2}"/>`); edges.push({ pts: [[x1 - M, y1 - M], [x1 - M, my - M], [x2 - M, my - M], [x2 - M, y2 - M]] }); } } }
  /* 頁の境目（字下げ）：その節から新しい頁になる所に線と頁番号。改頁を決めた所は実線と「改頁」 */
  let lastPg = null; const pageOfN = n => { if (!n.obj || n.root) return null; const lm = ed.lay.lineMap[n.line]; return lm && lm.rows[0] ? lm.rows[0].page : null; };
  const WW = dirI ? M + L.W + 28 : 0; const pageMark = (n, x, y) => { if (!dirI || n.kind === 'sent' || n.root) return ''; const pg = pageOfN(n); if (pg == null) return ''; const prev = lastPg; lastPg = pg; if (prev != null && pg <= prev) return ''; const forced = !!(n.obj && n.obj.attrs.breakBefore);
    /* 頁の境目：細い破線と、左端に四角で囲んだ P1・P2…（最初の頁から） */ const yy = y - 3.5; const lab = 'P' + (pg + 1); const bw = lab.length * 5.6 + 4; return `<g class="tpg${forced ? ' forced' : ''}"><path d="M${bw + 3} ${yy}H${WW - 8}"/><rect x="1.5" y="${yy - 5.5}" width="${bw}" height="11" rx="1"/><text x="${1.5 + bw / 2}" y="${yy + 3.3}" text-anchor="middle">${lab}</text><title>${pg + 1} 頁${forced ? '（ここから改頁）' : ''}</title></g>`; };
  const hitKeys = st.tree.find && st.tree.find.trim() ? new Set(treeFindHits().map(treeKey)) : null; /* ツリーで探す：当たった節 */
  const warns = st.form === 'scheck' ? (() => { const m = new Map(); for (const it of structIssues()) { const a = m.get(it.obj) || []; a.push(CHECK_NAMES[it.kind] + '：' + it.msg); m.set(it.obj, a); } return m; })() : null; /* 構造の点検：印を付ける節 */
  const aiMarks = st.form === 'aiback' && st.aiBack && st.aiBack.hunks.length ? (() => { const m = new Map(), S = st.aiBack, vis2 = new Set(shown); /* AI からの戻し：違う所の節に印（畳んだ・深さで隠れた行は見えている親に） */
    const nodeAt = i => { for (let k = i; k >= 0; k--) { let n = tr.byObj.get(ed.doc.lines[k]); if (!n) continue; while (n && !vis2.has(n)) n = n.parent; return n && n.obj ? n.obj : null; } return null; };
    S.hunks.forEach((h, k) => { const put = (o2, kind) => { if (!o2) return; const e = m.get(o2); if (!e) m.set(o2, { kind, cur: k === S.i }); else { if (e.kind !== kind) e.kind = 'chg'; if (k === S.i) e.cur = true; } }; if (h.rem.length) new Set(h.rem.map(nodeAt)).forEach(o2 => put(o2, h.kind)); else put(nodeAt(Math.max(0, h.at - 1)), 'add'); }); return m; })() : null;
  const nodesSvg = shown.map((n, i) => { const p = P(n), s = info.get(n); const key = treeKey(n); const on = key === st.tree.sel || st.tree.multi.has(key); const body = n.kind === 'body' || n.kind === 'block' || n.kind === 'sent'; const head = n.root || n.kind === 'title';
    const x = M + p.x, y = M + p.y; const hidden = n.children.length && !vis(n).length ? treeCount(n) : 0;
    const t = s.lines.map((ln, k) => `<text x="${x + TREE_PX}" y="${y + PY + TREE_LH * k + 13}"${head ? ' font-weight="700"' : ''}>${esc(ln)}</text>`).join('')
      + (s.showable ? `<g class="tshow" data-show="${i}"><rect x="${x + p.w - 44 - (hidden && dirI ? 30 : 0)}" y="${y + 4}" width="38" height="18" rx="2"/><text x="${x + p.w - 25 - (hidden && dirI ? 30 : 0)}" y="${y + 17}" text-anchor="middle">${s.open ? '閉じる' : '表示'}</text></g>` : '')
      + (s.fig ? `<rect class="tfigbg" x="${x + TREE_PX}" y="${y + s.lines.length * TREE_LH + PY + 3}" width="${s.fig.w}" height="${s.fig.h}"/>` + treeFigSvg(s.fig.rc, x + TREE_PX, y + s.lines.length * TREE_LH + PY + 3, s.fig.w, s.fig.h, figK++, figCache) : '')
      + (s.open && !s.fig ? `<text class="tk" x="${x + TREE_PX}" y="${y + s.lines.length * TREE_LH + PY + 9}">（紙面にまだ組まれていません）</text>` : '');
    const badge = hidden ? (dirI ? `<text class="fold" data-fold="${i}" x="${x + p.w - 6}" y="${y + p.h / 2 + 4}" text-anchor="end">＋${hidden}</text>` : st.tree.dir !== 'v' ? `<text class="fold" data-fold="${i}" x="${x + p.w + 5}" y="${y + p.h / 2 + 4}">＋${hidden}</text>` : `<text class="fold" data-fold="${i}" x="${x + p.w / 2}" y="${y + p.h + 14}" text-anchor="middle">＋${hidden}</text>`) : '';
    const wn = warns && n.kind !== 'sent' && n.obj ? warns.get(n.obj) : null; let warnB = wn ? `<g class="twarn"><title>${esc(wn.join('\n'))}</title><circle cx="${x + p.w - 9}" cy="${y + 9}" r="7"/><text x="${x + p.w - 9}" y="${y + 13}" text-anchor="middle">!</text></g>` : '';
    const am = aiMarks && n.kind !== 'sent' && n.obj ? aiMarks.get(n.obj) : null; if (am) warnB += `<g class="tdiff${am.cur ? ' cur' : ''}"><title>AI からの戻し：${AI_KIND[am.kind]}${am.kind === 'add' ? '（この後ろに）' : ''}</title><rect x="${x + p.w - 17}" y="${y + 2}" width="15" height="14" rx="2"/><text x="${x + p.w - 9.5}" y="${y + 13}" text-anchor="middle">${am.kind === 'add' ? '＋' : am.kind === 'del' ? '－' : '直'}</text></g>`;
    return `${pageMark(n, x, y)}<g class="tn${on ? ' on' : ''}${wn ? ' warn' : ''}${am ? ' diff' : ''}${hitKeys && hitKeys.has(key) ? ' hit' : ''}${body ? ' body' : ''}${head ? ' head' : ''}${n.kind === 'fig' ? ' figN' : ''}${s.box ? ' para' : ''}${n.kind === 'sent' ? ' sent' : ''}" data-i="${i}"><rect x="${x}" y="${y}" width="${p.w}" height="${p.h}" rx="3"/>${t}</g>${badge}${warnB}`; }).join('');
  const W = dirI ? M + L.W + 28 : L.W + M * 2 + 60, H = L.H + M * 2 + 40; // 字下げは窓の幅ちょうど（右端に子を足す ＋ の分）
  treeEl.innerHTML = `<svg width="${Math.ceil(W * SC)}" height="${Math.ceil(H * SC)}" viewBox="0 0 ${W} ${H}"><g class="tl">${o.join('')}</g>${nodesSvg}<g class="tov"></g></svg>`;
  st.tree.view = { tr, top, shown, pos: L.pos, M, info, edges, LW: L.W, LH: L.H };
  renderTreeOverlay(); if (st.view === 'split' && st.mode === 'tree') treeFollowPaper();
}
/* 並べるとき：ツリーで選んだ節 → 紙面のカーソルとその場所（紙面だけ動かす） */
let followLine = -1, followTimer = 0;
function treeFollowPaper(force) { if (st.view !== 'split') return; const n = treeNodeSel(); if (!n || !n.obj) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0 || (i === followLine && !force)) return; followLine = i;
  ed.caret = { line: i, seg: 0, off: n.kind === 'sent' ? n.sStart : 0, vcol: null, vrow: 0 }; ed.anchor = null; scrollToCaret(true); requestOverlay(); }
/* 並べるとき：紙面のカーソル → ツリーの節（ツリーだけ動かす） */
function treeFollowCaret(now) { if (st.view !== 'split' || st.mode === 'tree') return; if (followTimer) cancelAnimationFrame(followTimer); const go = () => { followTimer = 0; const v = st.tree.view; if (!v) return; let n = FZ.tree.nodeAt(v.tr, ed.caret.line); const shown = new Set(v.shown); while (n && !shown.has(n)) n = n.parent; if (!n) n = v.top; const k = treeKey(n); followLine = ed.caret.line; if (k === st.tree.sel) { renderTreeOverlay(); return; } st.tree.sel = k; renderTree(); treeScrollToSel(); }; if (now) go(); else followTimer = requestAnimationFrame(go); }
function treeNodeSel() { const v = st.tree.view; if (!v) return null; return v.shown.find(n => treeKey(n) === st.tree.sel) || v.top; }
function treeSelected() { const v = st.tree.view; if (!v) return []; const keys = new Set([...st.tree.multi, st.tree.sel]); return v.shown.filter(n => keys.has(treeKey(n))); }
function renderTreeOverlay() {
  const g = treeEl.querySelector('.tov'); const v = st.tree.view; if (!g || !v) return; const M = v.M; const o = [];
  const hv = st.tree.hover != null ? v.shown[st.tree.hover] : null;
  if (hv && !st.tree.drop && !st.tree.band && !st.tree.edit) { const p = v.pos.get(hv); const x = M + p.x, y = M + p.y; const btn = (cx, cy, act, tip) => `<g class="tadd" data-add="${act}"><title>${tip}</title><circle cx="${cx}" cy="${cy}" r="8"/><path d="M${cx - 4} ${cy}h8M${cx} ${cy - 4}v8"/></g>`;
    if (hv.kind !== 'body' && hv.kind !== 'block' && FZ.tree.childType(hv)) o.push(st.tree.dir !== 'v' ? btn(x + p.w + 12, y + p.h / 2, 'child', '子を足す（Tab）') : btn(x + p.w / 2, y + p.h + 12, 'child', '子を足す（Tab）'));
    if (!hv.root && hv !== v.top) o.push(st.tree.dir !== 'v' ? btn(x + p.w / 2, y + p.h + (st.tree.dir === 'i' ? 3 : 10), 'after', '弟を足す（Enter）') : btn(x + p.w + 10, y + p.h / 2, 'after', '弟を足す（Enter）')); }
  const d = st.tree.drop; if (d) { const p = v.pos.get(d.node); const x = M + p.x, y = M + p.y; if (d.rel === 'child') o.push(`<rect class="tdrop" x="${x - 3}" y="${y - 3}" width="${p.w + 6}" height="${p.h + 6}" rx="4"/>`); else if (st.tree.dir !== 'v') { const g2 = st.tree.dir === 'i' ? 2 : 5; const yy = d.rel === 'before' ? y - g2 : y + p.h + g2; o.push(`<path class="tdropl" d="M${x - 6} ${yy}H${x + p.w + 6}"/>`); } else { const xx = d.rel === 'before' ? x - 5 : x + p.w + 5; o.push(`<path class="tdropl" d="M${xx} ${y - 6}V${y + p.h + 6}"/>`); } }
  if (st.view === 'split' && st.mode !== 'tree') { const sl = ed.sel(); if (sl && sl.a.line !== sl.b.line) for (const n of v.shown) { if (n.root || n === v.top || n.line == null || n.line < sl.a.line || n.line > sl.b.line) continue; const p = v.pos.get(n); if (p) o.push(`<rect class="tpsel" x="${M + p.x - 2}" y="${M + p.y - 2}" width="${p.w + 4}" height="${p.h + 4}" rx="4"/>`); } } /* 並べる（G2）：紙面で選んだ範囲の節に印 */
  const b = st.tree.band; if (b) o.push(`<rect class="tband" x="${Math.min(b.x1, b.x2)}" y="${Math.min(b.y1, b.y2)}" width="${Math.abs(b.x2 - b.x1)}" height="${Math.abs(b.y2 - b.y1)}"/>`);
  g.innerHTML = o.join('');
}
function treeScrollToSel() { const v = st.tree.view; const n = treeNodeSel(); if (!v || !n) return; const p = v.pos.get(n); const svg = treeEl.querySelector('svg'); if (!p || !svg) return; const mr = tpane.getBoundingClientRect(), sr = svg.getBoundingClientRect(); const SC = st.tree.scale; const x = sr.left - mr.left + tpane.scrollLeft + (v.M + p.x) * SC, y = sr.top - mr.top + tpane.scrollTop + (v.M + p.y) * SC, pw = p.w * SC, ph = p.h * SC; const [mw, mh] = [tpane.clientWidth, tpane.clientHeight];
  if (y < tpane.scrollTop + 10) tpane.scrollTop = y - 40; else if (y + ph > tpane.scrollTop + mh - 10) tpane.scrollTop = y + ph - mh + 40; if (x < tpane.scrollLeft + 10) tpane.scrollLeft = x - 40; else if (x + pw > tpane.scrollLeft + mw - 10) tpane.scrollLeft = x + Math.min(pw, mw - 80) - mw + 40; }
function enterTree() {
  if (st.mode === 'tree') return; if (st.mode !== 'text') exitMode(); if (st.form) closeForm(); if (st.armed) disarm(); st.cells = null; const fromPaper = !st.view || st.view === 'paper'; if (fromPaper) st.view = 'tree';
  const psel = ed.sel(); st.tree.pendSel = psel && psel.a.line !== psel.b.line ? [psel.a.line, psel.b.line] : null; /* G2：紙面で範囲を選んでいたら、その節をツリーで選ぶ */
  st.mode = 'tree'; st.group = null; st.armed = false; st.tree.multi.clear(); st.tree.hover = null; st.tree.drop = null; st.tree.band = null;
  const tr = treeBuild(); let n = FZ.tree.nodeAt(tr, ed.caret.line); const top = tr.top; while (n && n !== top && st.tree.depth > 0 && n.depth - top.depth > st.tree.depth) n = n.parent; st.tree.sel = treeKey(n || top);
  const bk = st.tree.back; st.tree.back = null; if (bk) { const hit = bk.fig ? tr.figs.find(f => f.fig.id === bk.fig) : tr.byObj.get(bk.obj); if (hit) st.tree.sel = treeKey(hit); } // 行って帰る：図表の節に戻る
  if (fromPaper) { tpane.scrollTop = 0; tpane.scrollLeft = 0; } render(); drawFkeys(); drawSub(); treeScrollToSel(); focusTA();
}
function exitTree(toNode = true) {
  if (st.mode !== 'tree') return; closeTreeEdit(true); const n = treeNodeSel(); st.mode = 'text'; st.group = null; st.armed = false; if (st.view === 'tree') { st.view = 'paper'; treeEl.style.display = 'none'; treeEl.innerHTML = ''; } pagesEl.style.display = ''; geomDirty = true; pagesEl.style.cursor = ''; // 並べるときはツリーを残して紙面に移るだけ
  if (toNode && n && !n.root && n.obj) { const i = ed.doc.lines.indexOf(n.obj); if (i >= 0) ed.setCaret({ line: i, seg: 0, off: 0 }); }
  render(); drawFkeys(); drawSub(); scrollToCaret(); syncTA(); focusTA();
}
/* 行って帰る：図表の中身を紙面のその場で直す（Ctrl+Shift+O で同じ節に戻る） */
function treeOpenObject(n) { st.tree.back = n.kind === 'fig' ? { fig: n.fig.id } : { obj: n.obj }; exitTree(false);
  if (n.kind === 'fig') { const x = ed.figById(n.fig.id); if (x) ed.setCaret({ line: x.line, seg: 0, off: 0 }); st.figSel = n.fig.id; openForm(n.fig.chart ? 'chart' : 'fig'); msg('図表の設定（Ctrl+Shift+O でツリーに戻る）', false, 5000); return; }
  const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return;
  if (n.block === 'figure') { enterFigMode(i); msg('図を直しています（Esc で本文、Ctrl+Shift+O でツリーに戻る）', false, 5000); return; }
  ed.setCaret({ line: i, seg: 0, off: 0 }); scrollToCaret(); msg('表を直しています（Ctrl+Shift+O でツリーに戻る）', false, 5000); }
function toggleTree() { if (st.mode === 'tree') exitTree(); else enterTree(); } // 並べるときは、ツリーと紙面の間で移る
/* 見え方：紙面・ツリー・並べる（左にツリー、右に紙面） */
function setView(v) { if (v === st.view) return; if (v === 'paper') { if (st.mode === 'tree') exitTree(); st.view = 'paper'; render(); } else if (v === 'tree') { if (st.mode === 'tree') { st.view = 'tree'; render(); } else { st.view = 'paper'; enterTree(); } } else { const wasTree = st.mode === 'tree'; st.view = 'split'; if (!wasTree) { render(); treeFollowCaret(true); } else { render(); treeFollowPaper(true); } } geomDirty = true; syncView(); drawSub(); drawFkeys(); focusTA(); }
function treeRefresh() { if (st.structProxy) return; render(); drawSub(); status(); treeScrollToSel(); } // 紙面から構造の操作を使っている間（withCaretNode）は描き直しを後へ
/* ツリーの操作 → 文書の編集。終わったら選び直す */
function treeDo(fn, selectObj) { let r; ed.mutate('', () => { r = fn(); }); if (r && r.obj !== undefined) st.tree.sel = r.obj; else if (selectObj) st.tree.sel = selectObj; treeRefresh(); return r; }
/* 文の後ろ（前）に文を足す：仮の文を入れてその場で打つ（空のまま Esc で消える） */
function sentEnd(t) { return /[。．！？!?][」』）)】〉》”’]*$/.test(t) ? t : t + '。'; }
function treeAddSent(n, rel) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (!x) return; const at = rel === 'before' ? x.start : x.end; const ph = '新しい文。'; const prev = { key: treeKey(n), line: n.line, text: n.text };
  ed.mutate('', () => ed.spliceSeg(seg, at, at, ph, FZ.marksFor(ph, (seg.marks[x.start] | 0) & ~FZ.M.LINK))); st.tree.sel = FZ.tree.sentKey(n.obj, rel === 'before' ? n.si : n.si + 1); st.tree.multi.clear(); treeRefresh(); openTreeEdit(true); if (st.tree.edit) st.tree.edit.prev = prev; }
/* 文を動かす：段落の中で前・後ろの文と入れ替える */
function treeMoveSent(n, dir) { const seg = n.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); const j = n.si + dir; if (j < 0 || j >= ss.length) { msg('段落の端です（別の段落へはドラッグで）', true); return; } if (seg.links && seg.links.length) { msg('リンクを含む段落の文は並べ替えられません', true); return; }
  const A = ss[Math.min(n.si, j)], B = ss[Math.max(n.si, j)]; const piece = (x, last) => { let t = seg.text.slice(x.start, x.end), m = seg.marks.slice(x.start, x.end); if (!last) { const core = t.replace(/[ 　]+$/, ''); if (!/[。．！？!?][」』）)】〉》”’]*$/.test(core)) { t = core + '。'; m = m.slice(0, core.length).concat([m[core.length - 1] | 0]); } } return { t, m }; };
  const b = piece(B, false), a = piece(A, B.end >= seg.text.length); ed.mutate('', () => ed.spliceSeg(seg, A.start, B.end, b.t + a.t, b.m.concat(a.m))); st.tree.sel = FZ.tree.sentKey(n.obj, j); treeRefresh(); }
/* 文を別の段落の文の前・後ろへ（または段落の末尾へ） */
function treeDropSent(n, drop) { const sSeg = n.obj.segs[0]; const x = FZ.tree.sentences(sSeg.text)[n.si]; if (!x) return false; const t = drop.node; if (sSeg.links && sSeg.links.length) { msg('リンクを含む段落の文は動かせません', true); return false; }
  let piece = null, tObj = t.obj, tSi = t.kind === 'sent' ? t.si : null; const sameLine = tObj === n.obj;
  ed.mutate('', () => { const core = sSeg.text.slice(x.start, x.end); const tt = sentEnd(core.replace(/[ 　]+$/, '')); piece = { t: tt, m: FZ.marksFor(tt, (sSeg.marks[x.start] | 0) & ~FZ.M.LINK) }; for (let q = 0; q < Math.min(tt.length, core.length); q++) piece.m[q] = sSeg.marks[x.start + q] | 0;
    ed.spliceSeg(sSeg, x.start, x.end, '', []); const seg = tObj.segs[0]; let at;
    if (tSi == null) at = seg.text.length; else { let k = tSi; if (sameLine && tSi > n.si) k--; const ss = FZ.tree.sentences(seg.text); const y = ss[k]; at = !y ? seg.text.length : drop.rel === 'before' ? y.start : y.end; }
    if (at === seg.text.length && seg.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(seg.text)) { ed.spliceSeg(seg, at, at, '。', [seg.marks[at - 1] | 0]); at++; }
    ed.spliceSeg(seg, at, at, piece.t, piece.m);
    if (!sSeg.text.trim() && n.obj !== tObj) { const i = ed.doc.lines.indexOf(n.obj); if (i >= 0) FZ.tree.removeRange(ed, i, i); } });
  const ss2 = FZ.tree.sentences(tObj.segs[0].text); const k2 = ss2.findIndex(y => y.text.startsWith(piece.t.slice(0, Math.min(8, piece.t.length)))); st.tree.sel = FZ.tree.sentKey(tObj, Math.max(0, k2)); treeRefresh(); return true; }
/* 文を独立した段落に（浅く）：段落の後ろに新しい段落として */
function treeSplitSent(n) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (!x) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; let nl = null;
  ed.mutate('', () => { const t = seg.text.slice(x.start, x.end).replace(/[ 　]+$/, ''), m = seg.marks.slice(x.start, x.start + t.length); ed.spliceSeg(seg, x.start, x.end, '', []); nl = FZ.newLine(''); nl.attrs = { ...n.obj.attrs }; delete nl.attrs.figs; nl.segs[0].text = t; nl.segs[0].marks = m; FZ.tree.insertAt(ed, i + 1, nl); if (!seg.text.trim()) FZ.tree.removeRange(ed, i, i); });
  st.tree.sel = nl; treeRefresh(); msg('文を独立した段落にしました（Ctrl+Z で戻す）'); }
/* 文を種類（段落・見出し・箇条書き）の行に取り出す：段落をその文の前後で割る（前と後ろは段落のまま） */
function treeSentToKind(n, kind0) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; const i = ed.doc.lines.indexOf(n.obj); if (!x || i < 0) return; if (seg.links && seg.links.length) { msg('リンクを含む段落は割れません', true); return; }
  const sec = n.parent && n.parent.parent; const kind = kind0 === 'nlist' ? 'list' : kind0; const lvl = kind === 'num' ? (sec && sec.kind === 'num' ? Math.min(7, sec.level + 1) : 0) : kind === 'sym' ? (sec && sec.kind === 'sym' ? Math.min(7, sec.level + 1) : 0) : kind === 'list' ? (sec && sec.kind === 'list' ? Math.min(7, sec.level + 1) : 0) : 0;
  const attrsK = kind === 'title' ? { style: 'title' } : kind === 'num' || kind === 'sym' ? { style: kind, level: lvl } : kind === 'list' ? { list: kind0 === 'nlist' ? { level: lvl, kind: 'num' } : { level: lvl } } : {};
  let mid = null; ed.mutate('', () => { const end = x.start + x.text.length; const piece = (a, b) => ({ t: seg.text.slice(a, b).replace(/^[ 　]+|[ 　]+$/g, ''), m: seg.marks.slice(a, b) }); const B = piece(0, x.start), C = piece(x.start, end), A = piece(x.end, seg.text.length);
    const base = { ...n.obj.attrs }; const figs = base.figs; delete base.figs; const mk = (pc, at) => { const ln = FZ.newLine(''); ln.attrs = at; ln.segs[0].text = pc.t; ln.segs[0].marks = pc.m.slice(0, pc.t.length); while (ln.segs[0].marks.length < pc.t.length) ln.segs[0].marks.push(0); return ln; };
    const out = []; if (B.t) out.push(mk(B, { ...base })); mid = mk(C, kind === 'body' ? { ...base } : attrsK); out.push(mid); if (A.t) out.push(mk(A, { ...base })); if (figs) out[out.length - 1].attrs.figs = figs;
    const L0 = ed.doc.lines[i]; L0.segs = out[0].segs; L0.attrs = out[0].attrs; if (out[0] === mid) mid = L0; for (let k = 1; k < out.length; k++) FZ.tree.insertAt(ed, i + k, out[k]); });
  st.tree.sel = mid; treeRefresh(); msg('文を取り出しました（Ctrl+Z で戻す）'); }
/* 段落 → 見出し（いる節の子の段）。段落 → 前の段落の文 */
function treeParaUp(n) { const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; const t = FZ.tree.childType(n.parent) || { kind: 'list', level: 0 }; ed.mutate('', () => FZ.tree.retype(ed, i, i, t)); st.tree.sel = n.obj; treeRefresh(); msg('段落を' + ({ num: '番号見出し', sym: '記号見出し', list: '箇条書き', title: '表題' }[t.kind] || '見出し') + 'にしました（後ろの本文はその子に。Ctrl+Z で戻す）'); }
function treeParaDown(n) { const sib = n.parent.children.filter(c => c.kind !== 'fig'); const k = sib.indexOf(n); const pv = sib[k - 1]; if (!pv || pv.kind !== 'body' || !pv.obj || pv.obj.segs.length !== 1) { msg('前が段落でないので文にできません', true); return; }
  const i = ed.doc.lines.indexOf(n.obj); const ps = pv.obj.segs[0], s0 = n.obj.segs[0]; if ((ps.links && ps.links.length) || (s0.links && s0.links.length)) { msg('リンクを含む段落はつなげません', true); return; }
  ed.mutate('', () => { if (ps.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(ps.text)) ed.spliceSeg(ps, ps.text.length, ps.text.length, '。', [ps.marks[ps.text.length - 1] | 0]); ed.spliceSeg(ps, ps.text.length, ps.text.length, s0.text, s0.marks.slice()); if (n.obj.attrs.figs) pv.obj.attrs.figs = (pv.obj.attrs.figs || []).concat(n.obj.attrs.figs); FZ.tree.removeRange(ed, i, i); });
  st.tree.sel = pv.obj; treeRefresh(); msg('前の段落の文にしました（Ctrl+Z で戻す）'); }
/* ばらす（段落 → 文ごとの段落／箇条書き／親子）・まとめる（続く段落・箇条書き、または節と子 → 1 つの段落） */
function treeRegroup(how) { const n0 = treeNodeSel(); if (!n0) return;
  if (how === 'merge') { let list = treeSelected().filter(n => (n.kind === 'body' || n.kind === 'list' || n.kind === 'num' || n.kind === 'sym') && n.obj && n.obj.segs.length === 1).sort((p, q) => p.line - q.line); let range = null;
    if (list.length === 1) { const n = list[0]; if (n.end > n.line) range = [n.line, n.end]; else { msg('まとめる節を Shift+クリックで 2 つ以上選ぶか、子のある節を選んでください', true); return; } }
    if (!list.length) return; const objs = range ? ed.doc.lines.slice(range[0], range[1] + 1).filter(l => l.segs.length === 1 && !l.attrs.figure && !l.attrs.toc && !l.attrs.hr && !FZ.inTable(ed.doc, ed.doc.lines.indexOf(l))) : list.map(n => n.obj);
    if (objs.length < 2) { msg('まとめるものがありません', true); return; } const first = objs[0];
    ed.mutate('', () => { const seg = first.segs[0]; for (const o of objs.slice(1)) { const s1 = o.segs[0]; if (!s1.text.trim()) continue; if (seg.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(seg.text)) ed.spliceSeg(seg, seg.text.length, seg.text.length, '。', [seg.marks[seg.text.length - 1] | 0]); ed.spliceSeg(seg, seg.text.length, seg.text.length, s1.text, s1.marks.slice()); if (o.attrs.figs) first.attrs.figs = (first.attrs.figs || []).concat(o.attrs.figs); }
      for (const o of objs.slice(1).reverse()) { const i = ed.doc.lines.indexOf(o); if (i >= 0) FZ.tree.removeRange(ed, i, i); } const keep = first.attrs.figs; first.attrs = keep ? { figs: keep } : {}; });
    st.tree.multi.clear(); st.tree.sel = first; treeRefresh(); msg(objs.length + ' 個を 1 つの段落にまとめました（Ctrl+Z で戻す）'); return; }
  const node = n0.kind === 'sent' ? n0.parent : n0; if (node.kind !== 'body' || !node.obj || node.obj.segs.length !== 1) { msg('段落（本文）を選んでください', true); return; }
  const seg = node.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); if (ss.length < 2) { msg('文が 1 つの段落はばらせません', true); return; } if (seg.links && seg.links.length) { msg('リンクを含む段落はばらせません', true); return; }
  const i = ed.doc.lines.indexOf(node.obj); const sec = node.parent; const lv0 = sec && sec.kind === 'list' ? Math.min(7, sec.level + 1) : 0;
  ed.mutate('', () => { const base = { ...node.obj.attrs }; const figs = base.figs; delete base.figs; const lines = ss.map((x, k) => { const t = x.text.replace(/^[ 　]+/, ''); const a = x.start + (x.text.length - t.length); const ln = FZ.newLine(''); ln.segs[0].text = t; ln.segs[0].marks = seg.marks.slice(a, a + t.length);
      ln.attrs = how === 'para' ? { ...base } : how === 'list' ? { list: { level: lv0 } } : { list: { level: k === 0 ? lv0 : Math.min(7, lv0 + 1) } }; return ln; });
    if (figs) lines[lines.length - 1].attrs.figs = figs; const L0 = ed.doc.lines[i]; L0.segs = lines[0].segs; L0.attrs = lines[0].attrs; for (let k = 1; k < lines.length; k++) FZ.tree.insertAt(ed, i + k, lines[k]); });
  st.tree.sel = node.obj; treeRefresh(); msg({ para: '文ごとの段落に', list: '箇条書きに', tree: '親子（最初の文が親）に' }[how] + 'ばらしました（Ctrl+Z で戻す）'); }
function treeToggleBreak() { const n = treeNodeSel(); if (!n || !n.obj || n.root) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; ed.mutate('', () => { const a = ed.doc.lines[i].attrs; if (a.breakBefore) delete a.breakBefore; else a.breakBefore = true; }); treeRefresh(); msg(n.obj.attrs.breakBefore ? 'この節から新しい頁にします（ツリーに「改頁」の線）' : '改頁を外しました'); }
function treeAdd(rel, at) {
  const n = at || treeNodeSel(); if (!n) return; if (n.kind === 'sent') { if (rel === 'child') { msg('文には子を足せません', true); return; } treeAddSent(n, rel); return; } if (rel !== 'child' && (n.root || n === st.tree.view.top)) rel = 'child';
  if (rel === 'child' && (n.kind === 'body' || n.kind === 'block' || !FZ.tree.childType(n))) { msg('この節には子を足せません（本文・表・図）', true); return; }
  let ln = null; ed.mutate('', () => { ln = FZ.tree.add(ed, n, rel); }); if (!ln) return; if (rel === 'child') st.tree.folds.delete(treeKey(n));
  const prev = { key: treeKey(n), line: n.line, text: n.text }; st.tree.sel = ln; st.tree.multi.clear(); treeRefresh(); openTreeEdit(true); if (st.tree.edit) st.tree.edit.prev = prev;
}
function treeDelete() { const v0 = st.tree.view; const list = treeSelected().filter(n => !n.root && n !== (v0 && v0.top)); if (!list.length && treeNodeSel() === (v0 && v0.top)) { msg('いちばん上の節（表題）は消せません。紙面で直します', true); return; } if (!list.length) return; const v = st.tree.view; const first = list[0]; const sib = first.parent ? first.parent.children : []; const k = sib.indexOf(first); const next = sib[k + 1] || sib[k - 1] || first.parent; const figs = list.filter(n => n.kind === 'fig'), sents = list.filter(n => n.kind === 'sent' && !list.includes(n.parent)), rest = list.filter(n => n.kind !== 'fig' && n.kind !== 'sent');
  ed.mutate('', () => { for (const n of sents.slice().sort((p, q) => p.line - q.line || q.si - p.si)) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (x) ed.spliceSeg(seg, x.start, x.end, '', []); } /* 文は段落の中から消す */ for (const n of figs) { const x = ed.figById(n.fig.id); if (!x) continue; const at = ed.doc.lines[x.line].attrs; at.figs.splice(x.k, 1); if (!at.figs.length) delete at.figs; } FZ.tree.remove(ed, rest); }); /* 図表は図版だけを消す（付いている行は残す） */ st.tree.multi.clear(); st.tree.sel = next ? treeKey(next) : null; treeRefresh(); msg(`${list.length} 個の節を消しました（子と本文ごと。Ctrl+Z で戻る）`); }
function treeMoveSel(fn) { const v0 = st.tree.view; const all = treeSelected().filter(n => !n.root && n !== (v0 && v0.top)); const list = all.filter(n => n.kind !== 'fig'); if (!list.length) { if (all.length) msg('図表は付いている行と一緒に動きます（その行の節を動かす。並べ替えは F7→G 図表の設定）', true); return; } const n = treeNodeSel(); const key = treeKey(n); let ok = false; ed.mutate('', () => { ok = fn(list, n); }); if (!ok) { ed.undoStack.pop(); msg('そちらへは動かせません', true); } st.tree.sel = key; treeRefresh(); }
function treeNav(dirKey) {
  const v = st.tree.view; const n = treeNodeSel(); if (!v || !n) return; const h = st.tree.dir === 'h'; const along = st.tree.dir === 'i' ? { up: 'row-', down: 'row+', left: 'parent', right: 'child' } : h ? { up: 'prev', down: 'next', left: 'parent', right: 'child' } : { left: 'prev', right: 'next', up: 'parent', down: 'child' }; const a = along[dirKey];
  let t = null; const vis = c => treeVisKids(c, v.top);
  if (a === 'row-' || a === 'row+') { const k = v.shown.indexOf(n); t = v.shown[k + (a === 'row+' ? 1 : -1)] || null; } // 字下げ：上下は見えている次・前の行
  else if (a === 'parent') t = n === v.top ? null : n.parent; else if (a === 'child') { if (st.tree.folds.has(treeKey(n))) { st.tree.folds.delete(treeKey(n)); render(); } t = vis(n)[0] || null; }
  else { const p = v.pos.get(n); const same = v.shown.filter(c => c !== n && v.pos.get(c).depth === p.depth); const key = c => h ? v.pos.get(c).y : v.pos.get(c).x; const k0 = key(n); const cand = same.filter(c => a === 'next' ? key(c) > k0 : key(c) < k0).sort((x, y) => a === 'next' ? key(x) - key(y) : key(y) - key(x)); t = cand[0] || null; }
  if (t) { st.tree.sel = treeKey(t); st.tree.multi.clear(); renderTreeOverlay(); render(); drawSub(); status(); treeScrollToSel(); }
}
function treeKeyDown(e) {
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey, alt = e.altKey;
  if (e.isComposing || e.keyCode === 229) { e.preventDefault(); return; }
  if (st.armed && !ctrl && !alt && k.length === 1) { const it = (GROUPS[st.group] || { items: [] }).items.find(it => it.key && it.key.toLowerCase() === k.toLowerCase()); if (it) { e.preventDefault(); const g0 = st.group; disarm(); runItem(it); if (st.mode === 'tree' && st.group === g0) afterGroupItem(); if (it.msel) drawSub(); return; } disarm(); } // F キーで開いたグループ：1 文字で実行（紙面と同じ）
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  if (ctrl && !alt) { const lk = k.toLowerCase();
    if (lk === 'enter') { e.preventDefault(); openTreeEdit(false); return; }
    const TXT = { b: 'bold', u: 'under', e: 'alignC', r: 'alignR', j: 'alignJ', l: shift ? 'link' : 'alignL', f: 'find', h: 'replace', p: 'print', n: 'new', m: 'moveTo', g: 'chart' }; if (TXT[lk]) { e.preventDefault(); run(TXT[lk]); return; } // 紙面と同じ近道：選んだ節に効く
    if (lk === 'z') { e.preventDefault(); shift ? ed.redo() : ed.undo(); treeRefresh(); return; } if (lk === 'y') { e.preventDefault(); ed.redo(); treeRefresh(); return; }
    if (lk === 's') { e.preventDefault(); run(shift ? 'saveAs' : 'save'); return; } if (lk === 'k') { e.preventDefault(); run('palette'); return; } if (lk === 'o' && shift) { e.preventDefault(); exitTree(); return; }
    if (lk === 'c' || lk === 'x' || lk === 'v') return; // 写す・貼るは copy／paste の出来事で
    const mv = { arrowup: 'up', arrowdown: 'down', arrowleft: 'out', arrowright: 'in' }[lk]; if (mv) { e.preventDefault(); run('tv:' + mv); return; }
    if (lk === '=' || lk === '+' || lk === ';') { e.preventDefault(); treeZoom(1); return; } if (lk === '-') { e.preventDefault(); treeZoom(-1); return; } if (lk === '0') { e.preventDefault(); treeZoom(0); return; }
    return; }
  e.preventDefault();
  if (alt) { const mv = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'out', ArrowRight: 'in' }[k]; if (mv) run('tv:' + mv); return; }
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.group) { treeCloseGroup(); return; } if (st.tree.multi.size) { st.tree.multi.clear(); render(); return; } exitTree(); return; }
  const nav = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' }[k]; if (nav) { treeNav(nav); return; }
  if (k === 'Enter') { treeAdd(shift ? 'before' : 'after'); return; }
  if (k === 'Tab') { if (shift) run('tv:out'); else treeAdd('child'); return; }
  if (k === 'Delete' || k === 'Backspace') { treeDelete(); return; }
  if (k === ' ') { run('tv:fold'); return; }
  if (k === 'Home') { st.tree.sel = treeKey(st.tree.view.top); render(); treeScrollToSel(); return; }
  if (k === '+' || k === ';' || k === '=') { treeZoom(1); return; } if (k === '-') { treeZoom(-1); return; }
  if (/^[0-9]$/.test(k)) { treeSetDepth(+k); return; }
}
function treeSetDepth(d) { const n = treeNodeSel(); st.tree.depth = d; st.tree.folds = new WeakSet(); if (n) st.tree.sel = treeKey(n); render(); drawSub(); status(); treeScrollToSel(); }
/* その場で文字を直す（新しく足した節は、空のまま決めるか Esc で取り消すと消える） */
function openTreeEdit(isNew) {
  closeTreeEdit(true); const v = st.tree.view; const n = treeNodeSel(); if (!v || !n || n.root) { if (n && n.root) msg('根（文書の名前）は直せません。表題の行を足すと根になります', true); return; }
  if (n.kind !== 'fig' && (!n.obj || n.obj.segs.length !== 1 || n.kind === 'block')) { msg('表・図・囲みの中身は紙面で直します（Esc で紙面へ）', true); return; }
  const p = v.pos.get(n); const svg = treeEl.querySelector('svg'); const mr = tpane.getBoundingClientRect(), sr = svg.getBoundingClientRect(); const mk = (v.info.get(n) || {}).mk || '';
  const el = document.createElement('textarea'); el.className = 'inl tinl'; const rawT = n.kind === 'fig' ? n.fig.title : n.kind === 'sent' ? n.raw : n.obj.segs[0].text; const refs = [...rawT].filter(ch => FZ.isRefChar(ch)); el.value = rawT.replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕'); // 図番の字は〔図〕で見せ、決めるときに戻す el.spellcheck = false; el.setAttribute('aria-label', '節の文字');
  const body = n.kind === 'body'; const SC = st.tree.scale; Object.assign(el.style, { left: (sr.left - mr.left + tpane.scrollLeft + (v.M + p.x) * SC) + 'px', top: (sr.top - mr.top + tpane.scrollTop + (v.M + p.y) * SC) + 'px', width: (body ? Math.max(p.w, 420) : Math.max(p.w, 260)) * SC + 'px', height: (body ? 96 : Math.max(p.h, 30)) * SC + 'px', fontSize: TREE_FS * SC + 'px', lineHeight: TREE_LH * SC + 'px', textAlign: 'left', paddingTop: 4 * SC + 'px' });
  tpane.append(el); st.formFocus = true; st.tree.edit = { el, obj: n.obj, isNew, mk, fig: n.kind === 'fig' ? n.fig : null, sent: n.kind === 'sent' ? n.si : null, refs }; renderTreeOverlay();
  el.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.isComposing || ev.keyCode === 229) return; if (ev.key === 'Escape') { ev.preventDefault(); closeTreeEdit(false); } else if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); closeTreeEdit(true); } else if (ev.key === 'Tab') { ev.preventDefault(); closeTreeEdit(true); treeAdd(ev.shiftKey ? 'before' : 'child'); } });
  el.addEventListener('blur', () => { if (st.tree.edit && st.tree.edit.el === el) closeTreeEdit(true); });
  el.focus(); if (isNew) el.select(); else el.setSelectionRange(el.value.length, el.value.length);
  msg((mk ? mk + ' ' : '') + '文字を打って Enter（Tab で決めて子を足す、Esc で取消）', false, 0);
}
function closeTreeEdit(commit) {
  const E = st.tree.edit; if (!E) return; st.tree.edit = null; st.formFocus = false; let rk = 0; const v = E.el.value.replace(/\n/g, '').replace(/〔図〕/g, m => (E.refs && rk < E.refs.length) ? E.refs[rk++] : m); E.el.remove(); msg('');
  if (E.fig) { if (commit && v !== E.fig.title) ed.setFig(E.fig.id, { title: v }); if (st.mode === 'tree') { render(); drawSub(); status(); } focusTA(); return; } // 図表の題
  const i = ed.doc.lines.indexOf(E.obj); if (i < 0) { focusTA(); return; }
  if (E.isNew && (!commit || !v.trim())) { ed.undo(); if (E.prev) { st.tree.sel = E.prev.key; st.tree.selLine = E.prev.line; st.tree.selText = E.prev.text; } render(); drawSub(); status(); focusTA(); return; } // 足したばかりの節を取り消す（選びは元の節へ）
  if (E.sent != null) { const seg = E.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[E.sent]; if (commit && x && v.trim() && v !== x.text) { const t = sentEnd(v.trim()); const m0 = seg.marks[x.start] | 0; ed.mutate(E.isNew ? 'tnew' : '', () => ed.spliceSeg(seg, x.start, x.start + x.text.length, t, FZ.marksFor(t, m0 & ~FZ.M.LINK))); } }
  else if (commit && v !== E.obj.segs[0].text) { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(E.obj); if (n) { ed.mutate(E.isNew ? 'tnew' : '', () => FZ.tree.setText(ed, n, v)); } }
  if (st.mode === 'tree') { render(); drawSub(); status(); } focusTA();
}
/* 写す：選んだ節を子ごと Markdown に（AI へそのまま渡せる）。貼る：Markdown の箇条書き・見出しを選んだ節の子として */
/* ================= 構造・ツリーで書き出す（X1・X4） ================= */
/* ツリーの見た目の型：今のツリー（深さ・畳み・形）の箱と線。ツリーを出していなければ、その場で組む */
function treeModel() { const visible = st.view === 'tree' || st.view === 'split'; const sel = st.tree.sel; st.tree.exportW = 720; let v; try { renderTree(); v = st.tree.view; } finally { st.tree.exportW = 0; } /* 書き出しは決まった幅で組む（画面の幅に左右されない） */
  if (visible) { st.tree.sel = sel; renderTree(); } else { treeEl.style.display = 'none'; treeEl.innerHTML = ''; st.tree.view = null; }
  if (!v || !v.edges) return null; const cache = new Map(); let fk = 0;
  const nodes = v.shown.map(n => { const p = v.pos.get(n), s = v.info.get(n) || { lines: [] }; if (!p) return null; const o = { x: p.x, y: p.y, w: p.w, h: p.h, lines: s.lines || [], head: !!(n.root || n.kind === 'title'), body: n.kind === 'body' || n.kind === 'block', sent: n.kind === 'sent', para: !!s.box, inBox: !!s.inBox };
    if (s.fig) o.fig = treeFigModel(n, s, cache, fk++); return o; }).filter(Boolean); /* 中身を見せている図表・表・流れ図も書き出す（以前は名前の箱だけで、中身が抜けていた） */
  const W = Math.max(...nodes.map(n => n.x + n.w)) + 4, H = Math.max(...nodes.map(n => n.y + n.h)) + 4; return { nodes, edges: v.edges, W, H }; }
/* 書き出し用の図表の中身：箱の中の位置（書き出しの余白は 5）、紙面と同じ描画の SVG、表ならセルの箱、画像なら元の画像 */
function treeFigModel(n, s, cache, k) { const rc = s.fig.rc, w = s.fig.w, h = s.fig.h; const f = { x: TREE_PX, y: (s.lines || []).length * TREE_LH + 8, w, h, svg: treeFigSvg(rc, 0, 0, w, h, 900 + k, cache) };
  if (n.kind === 'block' && n.block === 'table') f.cells = treeTableCells(n, rc, w / rc.w);
  else if (n.kind === 'fig' && n.fig && n.fig.file && !n.fig.chart) { const img = ed.doc.images && ed.doc.images[n.fig.file]; if (img && /^image\/(png|jpeg|gif)$/.test(img.mime)) f.image = { mime: img.mime, data: img.data }; }
  return f; }
/* 表のセル：紙面の組版の位置を、ツリーの箱の中の位置に縮めて（Word・PowerPoint では字を直せる箱にする） */
function treeTableCells(n, rc, sc) { const L = ed.lay, geo = L.geo, cw = geo.cw, ch = geo.ch; const X = c => geo.left + c * cw, Y = r => geo.top + (geo.bodyTop + r) * ch; const I = FZ.tbl.info(ed, n.line); if (!I) return null; const out = [];
  for (let i = n.line; i <= n.end; i++) { const m = L.lineMap[i], ln = ed.doc.lines[i]; if (!m || !ln || !ln.attrs.cells) continue; const rows = m.rows.filter(r => r.page === rc.page); if (!rows.length) continue; const y1 = Math.min(...rows.map(r => r.y)), y2 = Math.max(...rows.map(r => r.y + r.h));
    for (const c of FZ.cellsAt(ed.doc, i, ed.doc.format.cols)) { if (c.left < I.L - 1e-6 || c.right > I.R + 1e-6) continue; const text = ln.segs.filter(g => g.col >= c.left - 1e-6 && g.col < c.right - 1e-6).map(g => g.text).join('').trim();
      out.push({ x: (X(c.left) - rc.x) * sc, y: (Y(y1) - rc.y) * sc, w: (c.right - c.left) * cw * sc, h: (y2 - y1) * ch * sc, text, head: i === n.line }); } }
  return out.length ? { list: out, fs: cw * sc * 0.82 } : null; }
/* 図表の中身の SVG を PNG に（PowerPoint・Word の絵に。字の書体は紙面の CSS を写して入れる） */
async function treeFigPng(f) { const rs = getComputedStyle(document.documentElement); const vars = { '--mincho': rs.getPropertyValue('--mincho'), '--gothic': rs.getPropertyValue('--gothic') }; let css = '';
  for (const sh of document.styleSheets) { let rules; try { rules = sh.cssRules; } catch { continue; } for (const r of rules) if (r.selectorText && /svg\.pg/.test(r.selectorText)) css += r.cssText.replace(/var\((--[a-z]+)\)/g, (m0, v) => vars[v] || 'serif') + '\n'; }
  const S = 3, W = Math.max(1, Math.round(f.w * S)), H = Math.max(1, Math.round(f.h * S)); const src = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${f.w} ${f.h}"><style>${css}</style><rect width="100%" height="100%" fill="#fff"/>${f.svg}</svg>`;
  const url = URL.createObjectURL(new Blob([src], { type: 'image/svg+xml' })); try { const img = new Image(); await new Promise((ok, ng) => { img.onload = ok; img.onerror = () => ng(new Error('図表の絵を作れませんでした')); img.src = url; }); const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(img, 0, 0, W, H); return c.toDataURL('image/png').split(',')[1]; } finally { URL.revokeObjectURL(url); } }
const TREE_FAMILY = () => { const o = FZ.officeFont(ed.doc.format.fontGothic || 'BIZ UDGothic'); return `'${o.ea}','BIZ UDGothic','Yu Gothic','Meiryo',sans-serif`; };
async function exportTree(kind) { const m = treeModel(); if (!m || !m.nodes.length) { msg('ツリーが空です', true); return; } const name = baseTitle() + '（ツリー）';
  try { await busy('ツリーを書き出し中…');
    if (kind !== 'pdf') for (const n of m.nodes) { const f = n.fig; if (!f || f.cells) continue; if (f.image) f.pic = { mime: f.image.mime, data: f.image.data }; else { try { f.pic = { mime: 'image/png', data: await treeFigPng(f) }; } catch (e) { f.pic = null; } } } /* 表はセルの箱、画像は元の画像、グラフ・流れ図は紙面と同じ描画の絵 */
    if (kind === 'pptx') { FZ.files.download(await FZ.zipAsync(FZ.treeToPptx(m, { files: true, font: ed.doc.format.fontGothic, title: name })), name + '.pptx'); msg('ツリーの見た目で PowerPoint に書き出しました（箱と線は図形。節の途中で頁を切らない）'); return; }
    const pw = 595.3, ph = 841.9; const svgs = FZ.treePageSvgs(m, pw, ph, { family: TREE_FAMILY() });
    if (kind === 'pdf') { printTreePages(svgs); return; }
    if (kind === 'docx') { /* Word：頁ごとに箱と線の図形のまとまり（Word で動かせる・字を直せる。画像にしない） */ const d = FZ.newDoc(); d.format = { ...d.format, ...JSON.parse(JSON.stringify(ed.doc.format)), kind: 'doc', paper: 'A4', widthMm: 210, heightMm: 297, landscape: false, margins: { top: 15, right: 15, bottom: 15, left: 15 }, headerRows: 0, footerRows: 0, header: '', footer: '' }; d.images = {};
      m.nodes.forEach((n, i) => { if (n.fig && n.fig.pic) { n.fig.picKey = 'tree-fig-' + i; d.images[n.fig.picKey] = n.fig.pic; } }); const Ds = FZ.treeDrawings(m, (210 - 30) * 72 / 25.4, (297 - 30) * 72 / 25.4 - 4); d.lines = Ds.map(D => ({ segs: [FZ.newSeg(0, '')], attrs: { drawing: D } }));
      FZ.files.download(await FZ.zipAsync(FZ.toDocx(d, { files: true })), name + '.docx'); msg(`ツリーの見た目で Word に書き出しました（${Ds.length} 頁。箱と線は Word の図形で、字も直せる）`); } } catch (e) { msg('ツリーの書き出しに失敗：' + e.message, true); } }
function printTreePages(svgs) { let box = $('treePrint'); if (box) box.remove(); box = document.createElement('div'); box.id = 'treePrint'; box.innerHTML = svgs.join(''); document.body.append(box); document.body.classList.add('ptree');
  let s = $('treePrintStyle'); if (!s) { s = document.createElement('style'); s.id = 'treePrintStyle'; document.head.append(s); } s.textContent = '@page { size: A4 portrait; margin: 0 } #treePrint { display: none } @media print { body.ptree > *:not(#treePrint) { display: none !important } body.ptree #treePrint { display: block } #treePrint svg { display: block; width: 210mm; height: 297mm; page-break-after: always; break-after: page } }';
  const done = () => { document.body.classList.remove('ptree'); box.remove(); window.removeEventListener('afterprint', done); }; window.addEventListener('afterprint', done); msg('ツリーを印刷します（PDF にするなら印刷先で「PDF に保存」）', false, 6000); setTimeout(() => { try { window.print(); } catch (e) { done(); } }, 50); }
/* Word の取り込み（X5） */
function pickDocx() { const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document'; inp.onchange = () => { const f = inp.files[0]; if (f) importDocxFile(f); }; inp.click(); }
async function importDocxFile(file) { try { await busy('Word を取り込み中…'); const buf = await file.arrayBuffer(); const r = await FZ.fromDocx(buf, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(defaultFormat())) }); if (!r.doc.title) r.doc.title = file.name.replace(/\.docx$/i, '');
    withDiscard(() => { st.file = null; st.savedAt = 0; ed.setDoc(r.doc); setFileName(file.name.replace(/\.docx$/i, '.fzk')); ed.dirty = true; clearRecovery(); st.mode = 'text'; drawFkeys(); drawSub(); render(); main.scrollTop = 0; focusTA();
      const t = FZ.tree.build(ed.doc, {}); const nh = t.nodes.filter(n => n.kind === 'num' || n.kind === 'sym').length; msg(`Word を取り込みました：見出し ${nh}${r.headings ? '' : r.lifted ? `（平文の番号から ${r.lifted} 行起こした）` : '（見出しが見つかりませんでした）'}・画像 ${r.images}。.fzk として保存してください`, false, 9000); }, '取り込む'); }
  catch (e) { msg('Word を取り込めませんでした：' + e.message, true); } }
/* ================= 構造の操作を紙面でも（G1・G4） =================
 * 紙面のカーソルの所（文を選んでいればその文、行を範囲で選んでいればその行の節）をツリーの節と見なし、ツリーと同じ操作を当てる。
 * 文書・選択・メニューは 1 つ：ツリーの操作の関数をそのまま使い、終わったらカーソルを結果の節（文なら文を選び直す）へ */
function sentSelOk() { const q = st.sentSel; const s = ed.sel(); if (!q || !s) return false; const ln = ed.doc.lines[s.a.line]; if (ln !== q.obj || s.a.line !== s.b.line || ln.segs.length !== 1) return false; return s.a.off === q.a && s.b.off === q.b; }
function selectSentence(pos) { if (st.mode === 'tree') { msg('ツリーでは文の深さ（F10 → Y）で文を選べます'); return false; } if (st.mode !== 'text') exitMode(); if (pos) ed.setCaret(pos);
  const L = ed.caret.line, ln = ed.doc.lines[L]; if (!ln || ln.segs.length !== 1 || !ln.segs[0].text.trim() || ln.attrs.cells || ln.attrs.figure || ln.attrs.toc) { msg('文を選べるのは本文・見出し・箇条書きの行です', true); return false; }
  const ss = FZ.tree.sentences(ln.segs[0].text); if (!ss.length) return false; const off = ed.caret.off; let k = ss.findIndex(x => off >= x.start && off < x.end); if (k < 0) k = off >= ss[ss.length - 1].start ? ss.length - 1 : 0;
  const x = ss[k]; const b = x.start + x.text.length; ed.anchor = { line: L, seg: 0, off: x.start }; ed.caret = { line: L, seg: 0, off: b, vcol: null, vrow: 0 }; ed.onCaret(); st.sentSel = { obj: ln, si: k, a: x.start, b, n: ss.length };
  requestOverlay(); status(); msg(ss.length > 1 ? `${k + 1} 文目（${ss.length} 文の段落）を選びました：Alt+← 段落に・Alt+→ 箇条書きに・Alt+↑↓ 並べ替え・${K('structGroup')} の種類で取り出す` : '1 文だけの段落です（段落として上げ下げ・並べ替え）', false, 7000); return true; }
function withCaretNode(fn, opts = {}) {
  if (st.mode === 'fig' || st.mode === 'rule' || st.mode === 'fill') exitMode();
  const ss = !opts.noSent && sentSelOk() ? st.sentSel : null; const tr = FZ.tree.build(ed.doc, { body: true, sentences: true, figs: false, title: ed.doc.title || '文書' }); const r = tr.root; tr.top = (r.children.length === 1 && r.children[0].kind === 'title') ? r.children[0] : r;
  const line = ed.doc.lines[ed.caret.line]; let node = ss ? tr.sents.find(n => n.obj === line && n.si === ss.si) : null; if (!node) node = tr.byObj.get(line);
  if (!node) { msg('ここには構造の操作が効きません（表の中・空行・図など）', true); return false; }
  const multi = new Set(); const sel = ed.sel(); if (!ss && sel && sel.a.line !== sel.b.line) for (let k = sel.a.line; k <= sel.b.line; k++) { const n = tr.byObj.get(ed.doc.lines[k]); if (n) multi.add(treeKey(n)); }
  const save = { view: st.tree.view, multi: st.tree.multi }; const caret0 = { ...ed.caret }, obj0 = line, u0 = ed.undoStack.length;
  st.tree.view = { tr, shown: [r, ...tr.nodes, ...tr.sents], top: tr.top, proxy: true }; st.tree.sel = treeKey(node); st.tree.multi = multi; st.structProxy = true;
  try { fn(node); } finally { st.structProxy = false; }
  const key = st.tree.sel; st.tree.view = null; st.tree.multi = save.multi;
  if (ed.undoStack.length !== u0 || opts.always) { let done = false;
    if (key && typeof key === 'object' && key.sent !== undefined) { const t2 = FZ.tree.build(ed.doc, { body: true, sentences: true }); const n2 = t2.sents.find(n => n.key === key); /* 文の名札は { sent: k }（行と番号で決まる） */ if (n2) { const L = ed.doc.lines.indexOf(n2.obj); const b = n2.sStart + n2.raw.length; ed.anchor = { line: L, seg: 0, off: n2.sStart }; ed.caret = { line: L, seg: 0, off: b, vcol: null, vrow: 0 }; st.sentSel = { obj: n2.obj, si: n2.si, a: n2.sStart, b, n: n2.parent.children.length }; done = true; } }
    if (!done) { const obj = key && typeof key === 'object' && key.sent === undefined ? key : obj0; let L = ed.doc.lines.indexOf(obj); if (L < 0) L = Math.min(caret0.line, ed.doc.lines.length - 1); const ln = ed.doc.lines[L]; const same = obj === obj0; const sg = same ? Math.min(caret0.seg, ln.segs.length - 1) : 0; ed.anchor = null; ed.caret = { line: L, seg: sg, off: same ? Math.min(caret0.off, ln.segs[sg].text.length) : 0, vcol: null, vrow: 0 }; st.sentSel = null; }
    ed.onCaret(); }
  render(); drawSub(); status(); requestOverlay(); return true; }
/* 構造の操作（ツリーの選んだ節／紙面のカーソルの節に同じ意味で効く） */
function structOp(op, arg) {
  const T = () => { const n = treeNodeSel(); if (!n) return; const para = n.kind === 'body' && n.obj && n.obj.segs.length === 1;
    if (op === 'out') { if (n.kind === 'sent') return treeSentToKind(n, 'body'); if (para) return treeParaUp(n); return treeMoveSel((list, x) => FZ.tree.promote(ed, st.tree.view.tr, x)); }
    if (op === 'in') { if (n.kind === 'sent') return treeSentToKind(n, 'list'); if (para) return treeParaDown(n); return treeMoveSel((list, x) => FZ.tree.demote(ed, st.tree.view.tr, x)); }
    if (op === 'up' || op === 'down') { const d = op === 'up' ? -1 : 1; if (n.kind === 'sent') return treeMoveSent(n, d); return treeMoveSel((list, x) => FZ.tree.shift(ed, st.tree.view.tr, x, d)); }
    if (op === 're') return treeRegroup(arg); };
  if (st.mode === 'tree') { T(); return; }
  if (st.mode !== 'text') exitMode();
  if ((op === 'up' || op === 'down') && !sentSelOk()) { run(op === 'up' ? 'outlineUp' : 'outlineDown'); return; } // 行・節の並べ替えは紙面の節の移動（範囲の選択にも効く）
  withCaretNode(T, { noSent: op === 're' }); }
/* 種類のコマンド：ツリーでは選んだ節（子の段も揃える）、紙面で文を選んでいればその文を段落から取り出す。それ以外は紙面の行の種類（従来どおり） */
function kindGuard(k) { if (st.mode === 'tree') { treeSetKind(k); return true; } if (st.mode === 'text' && sentSelOk() && st.sentSel.n > 1) { withCaretNode(n => { if (n.kind === 'sent') treeSentToKind(n, k); }); return true; } return false; }
/* AI に渡す：Markdown をクリップボードへ（ファイルにしない） */
async function copyText(t) { try { await navigator.clipboard.writeText(t); return true; } catch { /* file:// などで使えない時は下の方法 */ }
  try { const x = document.createElement('textarea'); x.value = t; x.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0'; document.body.append(x); x.select(); const r = document.execCommand('copy'); x.remove(); focusTA(); return r; } catch { return false; } }
/* カーソルの行を含む節（箇条書きの中なら、それを含む見出しの節）：{ line, end, text } | null */
function sectionAt(L) { const tr = FZ.tree.build(ed.doc, {}); let best = null; for (const n of tr.nodes) if (n.line <= L && n.end >= L && (n.kind === 'num' || n.kind === 'sym' || n.kind === 'title' || n.kind === 'list') && (!best || n.depth > best.depth)) best = n;
  if (best && best.kind === 'list') { let p = best; while (p.parent && p.parent.kind === 'list') p = p.parent; best = p.parent && !p.parent.root ? p.parent : p; } return best; }
async function aiCopy(whole) { let md, what, idx = null;
  if (whole) { md = FZ.toGfm(ed.doc, { fz: true }); what = '文書全体'; }
  else if (st.mode === 'tree') { md = treeCopyText(); const n = treeNodeSel(); what = n && !n.root ? '「' + String(n.text).slice(0, 16) + '」の節' : '文書全体'; idx = treeCopyIdx(); }
  else { const s = ed.sel(); if (s && s.a.line !== s.b.line) { md = FZ.toGfm(sliceDoc(s.a.line, s.b.line), { fz: true }); what = '選んだ範囲'; idx = rangeIdx(s.a.line, s.b.line); }
    else { const best = sectionAt(ed.caret.line);
      md = best ? FZ.toGfm(sliceDoc(best.line, best.end), { fz: true }) : FZ.toGfm(ed.doc, { fz: true }); what = best ? '「' + String(best.text).slice(0, 16) + '」の節' : '文書全体（見出しがありません）'; if (best) idx = rangeIdx(best.line, best.end); } }
  rememberScope(idx, what.replace(/（.*$/, ''));
  const ok = await copyText(md); msg(ok ? `${what}を Markdown で写しました（${md.length.toLocaleString()} 字）：AI の入力欄に貼り付けてください` : `写せませんでした（${K('exportMd')} で Markdown ファイルに）`, !ok, 7000); return ok; }
function sliceDoc(a, b) { const d = ed.doc; const sub = { ...d, lines: d.lines.slice(a, b + 1).map(l => JSON.parse(JSON.stringify(l))), rules: [], fills: [], images: d.images, refs: d.refs, _nums: FZ.figureNumbers(d) };
  { const ordOf = lines => { const c = [], out = []; for (const ln of lines) { const at = ln.attrs; if (at.style === 'title') c.length = 0; if (at.style !== 'num') { out.push(0); continue; } const lv = Math.min(7, at.level | 0); if (at.restart) c[lv] = (typeof at.restart === 'number' ? at.restart : 1) - 1; c.length = lv + 1; c[lv] = (c[lv] || 0) + 1; out.push(c[lv]); } return out; };
    const full = ordOf(d.lines.slice(0, b + 1)), c = []; sub.lines.forEach((ln, k) => { const at = ln.attrs; if (at.style === 'title') c.length = 0; if (at.style !== 'num') return; const lv = Math.min(7, at.level | 0); if (at.restart) c[lv] = (typeof at.restart === 'number' ? at.restart : 1) - 1; c.length = lv + 1; let v = (c[lv] || 0) + 1; const want = full[a + k]; if (v !== want) { at.restart = want > 1 ? want : true; v = want; } c[lv] = v; }); } /* 節だけ写しても見出しの番号は文書のまま（2 番目の節は「2.」） */
  for (const r of d.rules) { if (r.axis === 'h' && r.line >= a && r.line <= b + 1) sub.rules.push({ ...r, line: r.line - a }); else if (r.axis === 'v' && r.from >= a && r.to <= b) sub.rules.push({ ...r, from: r.from - a, to: r.to - a }); }
  for (const f of d.fills) if (f.from >= a && f.to <= b) sub.fills.push({ ...f, from: f.from - a, to: f.to - a }); const r = FZ.normalize(sub); r._nums = sub._nums; return r; } /* 範囲の外の節・図への参照も文書全体の番号で */
function treeCopyNodes() { const sel = treeSelected(); const ns = (sel.length ? sel : [treeNodeSel()]).filter(Boolean).sort((p, q) => p.line - q.line); return ns.filter(n => !ns.some(m => m !== n && FZ.tree.isAncestor(m, n))); }
function treeCopyIdx() { const ns = treeCopyNodes(); if (!ns.length || ns.some(n => n.root)) return null; const set = new Set(); for (const n of ns) { const a = ed.doc.lines.indexOf(n.obj); if (a < 0) continue; const b = n.kind === 'sent' ? a : a + (n.end - n.line); for (let k = a; k <= b; k++) set.add(k); } return set.size ? [...set].sort((x, y) => x - y) : null; }
function treeCopyText() { const sel = treeSelected(); if (sel.length && sel.every(n => n.kind === 'sent')) return sel.map(n => n.text).join(''); const ns = (sel.length ? sel : [treeNodeSel()]).filter(Boolean).sort((p, q) => p.line - q.line); const parts = []; for (const n of ns) { if (ns.some(m => m !== n && FZ.tree.isAncestor(m, n))) continue; parts.push(n.root ? FZ.toGfm(ed.doc, { fz: true }) : FZ.toGfm(sliceDoc(n.line, n.end), { fz: true })); } return parts.join('\n'); }
function treePaste(text) {
  const n = treeNodeSel(); if (!n || !text.trim()) return; if (n.kind === 'body' || n.kind === 'block') { msg('本文・表・図の節には貼れません。見出しか項目を選んでください', true); return; }
  let sub; try { const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(ed.doc.format)); sub = FZ.fromGfm(text, base); } catch (e) { msg('貼れませんでした：' + e.message, true); return; }
  const lines = sub.lines.filter((l, k, arr) => !(k === arr.length - 1 && !l.segs.some(s => s.text))); if (!lines.length) return; let firstObj = null;
  ed.mutate('', () => { const at = n.root ? ed.doc.lines.length : n.end + 1; lines.forEach((l, k) => FZ.tree.insertAt(ed, at + k, l)); for (const r of sub.rules) { if (r.axis === 'h') ed.doc.rules.push({ ...r, id: FZ.uid(), line: r.line + at }); else ed.doc.rules.push({ ...r, id: FZ.uid(), from: r.from + at, to: r.to + at }); } for (const f of sub.fills) ed.doc.fills.push({ ...f, id: FZ.uid(), from: f.from + at, to: f.to + at });
    const lvs = lines.map(l => ed.outlineLevel(l.attrs)); const min = Math.min(...lvs.filter(x => x < 99)); firstObj = lines[0];
    const t = (min >= 17 && n.kind !== 'list') ? { kind: 'list', level: 0 } : (FZ.tree.childType(n) || { kind: 'list', level: 0 }); // 箇条書きは見出しの下でも箇条書きのまま
    if (min < 99) for (let k = 0; k < lines.length; k++) { if (lvs[k] !== min) continue; let e2 = k; while (e2 + 1 < lines.length && !(lvs[e2 + 1] <= min)) e2++; const a0 = ed.doc.lines.indexOf(lines[k]); FZ.tree.retype(ed, a0, a0 + (e2 - k), t); } });
  st.tree.folds.delete(treeKey(n)); st.tree.sel = firstObj; treeRefresh(); msg(`${lines.length} 行を「${(n.text || '').slice(0, 12)}」の子として貼りました（Ctrl+Z で戻す）`);
}
/* マウス */
function treePt(e) { const svg = treeEl.querySelector('svg'); if (!svg) return null; const r = svg.getBoundingClientRect(); const SC = st.tree.scale; return { x: (e.clientX - r.left) / SC, y: (e.clientY - r.top) / SC }; }
function treeHit(pt, pad = 0) { const v = st.tree.view; if (!v) return -1; for (let i = v.shown.length - 1; i >= 0; i--) { const p = v.pos.get(v.shown[i]); const x = v.M + p.x, y = v.M + p.y; if (pt.x >= x - pad && pt.x <= x + p.w + pad && pt.y >= y - pad && pt.y <= y + p.h + pad) return i; } return -1; }
function treeDropAt(pt, movers) {
  const v = st.tree.view; const h = st.tree.dir !== 'v'; const gap = st.tree.dir === 'i' ? 2 : 6; const i = treeHit(pt, gap); if (i < 0) return null; const t = v.shown[i]; if (movers.length && movers[0].kind === 'sent') { const m0 = movers[0]; if (t === m0) return null; if (t.kind === 'sent') { const p = v.pos.get(t); return { node: t, rel: (pt.y - (v.M + p.y)) / p.h < 0.5 ? 'before' : 'after' }; } if (t.kind === 'body' && t.obj && t.obj.segs.length === 1) return { node: t, rel: 'child' }; return null; } movers = movers.filter(m => m.kind !== 'fig'); if (!movers.length || t.kind === 'fig' || movers.some(m => m === t || FZ.tree.isAncestor(m, t))) return null;
  const p = v.pos.get(t); const x = v.M + p.x, y = v.M + p.y; const along = h ? (pt.y - y) / p.h : (pt.x - x) / p.w; const across = h ? (pt.x - x) / p.w : (pt.y - y) / p.h;
  const canChild = t.kind !== 'body' && t.kind !== 'block' && FZ.tree.childType(t); const isTop = t === v.top || t.root;
  let rel = across > 0.66 && canChild ? 'child' : along < 0.3 ? 'before' : along > 0.7 ? 'after' : (canChild ? 'child' : along < 0.5 ? 'before' : 'after'); if (isTop) rel = canChild ? 'child' : null; if (!rel) return null; return { node: t, rel };
}
let tdrag = null;
treeEl.addEventListener('pointerdown', e => {
  if (e.button !== 0) return; if (st.mode !== 'tree' && st.view === 'split') enterTree(); /* 並べる：ツリーを押すとツリーへ */ const pt = treePt(e); if (!pt) return; e.preventDefault(); if (st.tree.edit) closeTreeEdit(true); if (st.form) closeForm(); if (st.armed) disarm(); const clicks = clickCount(e); const v = st.tree.view;
  const shw = e.target.closest('[data-show]'); if (shw) { const n = v.shown[+shw.dataset.show]; if (n) { const k = treeShowKey(n); if (st.tree.show.has(k)) st.tree.show.delete(k); else st.tree.show.add(k); st.tree.showAll = false; st.tree.sel = treeKey(n); render(); drawSub(); status(); treeScrollToSel(); } focusTA(); return; } // 図表の中身を見せる・閉じる
  const add = e.target.closest('[data-add]'); if (add && st.tree.hover != null) { const n = v.shown[st.tree.hover]; st.tree.sel = treeKey(n); treeAdd(add.dataset.add, n); return; }
  const fold = e.target.closest('[data-fold]'); if (fold) { const n = v.shown[+fold.dataset.fold]; st.tree.folds.delete(treeKey(n)); if (st.tree.depth > 0 && n.depth - v.top.depth >= st.tree.depth) { st.tree.depth = Math.min(9, n.depth - v.top.depth + 1); } render(); drawSub(); focusTA(); return; }
  const i = treeHit(pt);
  if (i >= 0) { const n = v.shown[i]; const key = treeKey(n);
    if (e.shiftKey) { if (st.tree.multi.has(key)) st.tree.multi.delete(key); else { st.tree.multi.add(key); if (st.tree.sel) st.tree.multi.add(st.tree.sel); } st.tree.sel = key; render(); drawSub(); status(); focusTA(); return; }
    if (!st.tree.multi.has(key)) st.tree.multi.clear(); st.tree.sel = key; render(); drawSub(); status();
    if (clicks >= 2) { const p = v.pos.get(n), inf = v.info.get(n); const inBody = inf && inf.fig && pt.y > v.M + p.y + inf.lines.length * TREE_LH + 4; if (treeShowable(n) && (n.kind !== 'fig' || inBody)) { treeOpenObject(n); return; } openTreeEdit(false); return; } // 図表の中身・表・流れ図：紙面のその場で直す
    if (n.kind === 'fig') { focusTA(); return; } // 図表はドラッグで動かさない（付いている行と動く）
    tdrag = { id: e.pointerId, kind: 'node', sx: pt.x, sy: pt.y, moved: false }; treeEl.setPointerCapture(e.pointerId); focusTA(); return; }
  if (!e.shiftKey) st.tree.multi.clear(); st.tree.band = { x1: pt.x, y1: pt.y, x2: pt.x, y2: pt.y, base: new Set(st.tree.multi) }; tdrag = { id: e.pointerId, kind: 'band' }; treeEl.setPointerCapture(e.pointerId); render(); focusTA();
});
treeEl.addEventListener('pointermove', e => {
  const pt = treePt(e); if (!pt) return; const v = st.tree.view; if (!v) return;
  if (!tdrag || tdrag.id !== e.pointerId) { if (e.buttons) return;
    if (e.target.closest('[data-add]')) { treeEl.style.cursor = 'pointer'; return; } // ＋の上：寄せている節を替えない（下の＋は次の行に重なる）
    let i = null; if (st.tree.hover != null && v.shown[st.tree.hover]) { const p = v.pos.get(v.shown[st.tree.hover]); if (p && pt.x >= v.M + p.x - 4 && pt.x <= v.M + p.x + p.w + 24 && pt.y >= v.M + p.y - 4 && pt.y <= v.M + p.y + p.h + 13) i = st.tree.hover; } // 今の節と＋の届く所にいる間は今の節のまま
    if (i == null) { const h2 = treeHit(pt, 6); i = h2 >= 0 ? h2 : null; }
    if (i !== st.tree.hover) { st.tree.hover = i; renderTreeOverlay(); } treeEl.style.cursor = e.target.closest('[data-fold]') ? 'pointer' : treeHit(pt) >= 0 ? 'grab' : ''; return; }
  if (tdrag.kind === 'node') { if (!tdrag.moved && Math.hypot(pt.x - tdrag.sx, pt.y - tdrag.sy) < 6) return; tdrag.moved = true; treeEl.style.cursor = 'grabbing'; st.tree.drop = treeDropAt(pt, treeSelected()); renderTreeOverlay(); return; }
  if (tdrag.kind === 'band') { const b = st.tree.band; b.x2 = pt.x; b.y2 = pt.y; const x1 = Math.min(b.x1, b.x2), x2 = Math.max(b.x1, b.x2), y1 = Math.min(b.y1, b.y2), y2 = Math.max(b.y1, b.y2); const keys = new Set(b.base);
    for (const n of v.shown) { const p = v.pos.get(n); const nx = v.M + p.x, ny = v.M + p.y; if (nx < x2 && nx + p.w > x1 && ny < y2 && ny + p.h > y1) keys.add(treeKey(n)); } st.tree.multi = keys; if (keys.size) st.tree.sel = [...keys][keys.size - 1]; render(); }
});
treeEl.addEventListener('pointerup', e => {
  if (!tdrag || tdrag.id !== e.pointerId) return; const d = tdrag; tdrag = null; treeEl.style.cursor = '';
  if (d.kind === 'node' && d.moved) { const drop = st.tree.drop; st.tree.drop = null; if (drop) { const sel0 = treeNodeSel(); if (sel0 && sel0.kind === 'sent') { treeDropSent(sel0, drop); focusTA(); return; } const list = treeSelected().filter(n => !n.root && n.kind !== 'fig' && n.kind !== 'sent'); const key = st.tree.sel; let ok = false; ed.mutate('', () => { ok = FZ.tree.move(ed, st.tree.view.tr, list, drop.node, drop.rel); }); if (!ok) { ed.undoStack.pop(); msg('そこへは動かせません', true); } else { if (drop.rel === 'child') st.tree.folds.delete(treeKey(drop.node)); msg(`${list.length} 個の節を動かしました（Ctrl+Z で戻す）`); } st.tree.sel = key; treeRefresh(); } else renderTreeOverlay(); }
  if (d.kind === 'band') { st.tree.band = null; render(); drawSub(); status(); }
  focusTA();
});
treeEl.addEventListener('pointerleave', () => { if (!tdrag && st.tree.hover != null) { st.tree.hover = null; renderTreeOverlay(); } });
treeEl.addEventListener('contextmenu', e => { e.preventDefault(); const pt = treePt(e); const i = pt ? treeHit(pt) : -1; if (i >= 0) { const n = st.tree.view.shown[i]; if (!st.tree.multi.has(treeKey(n))) { st.tree.multi.clear(); st.tree.sel = treeKey(n); } render(); drawSub(); status(); } msg('上の帯で、選んだ節を足す・動かす・種類を変えられます'); focusTA(); });
/* ================= 表：列の境のドラッグ・セルの範囲 ================= */
/* 位置 g が表の列の境（縦罫）の近くなら { I, k, line } */
function tableEdgeAt(g) {
  const p = ed.lay.pages[g.page]; if (!p) return null; const es = p.rowmap.get(Math.floor(g.row)); const e = es && es.find(x => x.cell); if (!e) return null;
  const I = FZ.tbl.info(ed, e.line); if (!I) return null; let k = -1, bd = 0.32; I.B.forEach((c, q) => { const dd = Math.abs(g.col - c); if (dd < bd) { bd = dd; k = q; } }); return k < 0 ? null : { I, k, line: e.line };
}
/* 表の行の y の範囲（そのページ） */
function tableRowsOn(I, page) { let y1 = Infinity, y2 = -Infinity; for (let i = I.a; i <= I.b; i++) { const lm = ed.lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) if (r.page === page) { y1 = Math.min(y1, r.y); y2 = Math.max(y2, r.y + r.h); } } return y1 <= y2 ? { y1, y2 } : null; }
/* カーソル位置のセル { line, col }（表の外なら null） */
function cellOfPos(p) { if (!p || !FZ.inTable(ed.doc, p.line)) return null; const I = FZ.tbl.info(ed, p.line); if (!I) return null; const s = ed.doc.lines[p.line].segs[p.seg]; if (!s) return null; let j = I.B.findIndex(c => Math.abs(c - s.col) < 1e-6); if (j < 0) j = I.B.filter(c => c <= s.col).length - 1; return { line: p.line, col: clamp(j, 0, I.n - 1), a: I.a }; }
/* 表の操作の対象：選んだセルの範囲、無ければカーソルのセル */
function cellRect() { if (st.cells) { const R = FZ.tbl.rectOf(ed, st.cells.a, st.cells.b); if (R) return R; } const c = cellOfPos(ed.caret); return c ? FZ.tbl.rectOf(ed, c, c) : null; }
function cellRects() {
  const R = st.cells && FZ.tbl.rectOf(ed, st.cells.a, st.cells.b); if (!R) return []; const out = []; const B = R.I.B;
  for (let i = R.la; i <= R.lb; i++) { const lm = ed.lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) out.push({ page: r.page, y: r.y, h: r.h, col: B[R.ca], w: B[R.cb + 1] - B[R.ca] }); }
  return out;
}
/* ================= マウス ================= */
let drag = null;
function eventToGrid(e) { // ポインタキャプチャ中でも座標から対象ページを求める
  if (!wraps.length) return null; const rm = main.getBoundingClientRect(); const yAbs = e.clientY - rm.top + main.scrollTop, xAbs = e.clientX - rm.left + main.scrollLeft;
  if (geomDirty) measurePages(); let p = 0; for (let i = 0; i < pageGeom.length; i++) { const g = pageGeom[i]; if (yAbs >= g.top - 6) p = i; if (yAbs < g.top + g.height + 6) break; }
  const g = pageGeom[p]; if (!g) return null; const scale = g.width / ed.lay.geo.W; const geo = ed.lay.geo;
  const xpt = (xAbs - g.left) / scale, ypt = (yAbs - g.top) / scale; return { page: p, col: (xpt - geo.left) / geo.cw, row: (ypt - geo.top) / geo.ch - geo.bodyTop };
}
/* 本文のクリック位置 → 論理位置（柱・ページの外・文末より後ろも） */
function posFromGrid(g) {
  const geo = ed.lay.geo; const y = Math.floor(g.row); const col = half(clamp(g.col, 0, geo.cols)); const hy = ed.lay.headY;
  if (y < 0 && hy != null && g.row >= hy && g.row < hy + geo.headerRows && ed.lay.pages[g.page] && ed.lay.pages[g.page].rowmap.has(hy)) return FZ.xyToPos(ed.lay, g.page, hy, col); // 柱の表題
  if (y < 0) return { line: 0, seg: 0, off: 0 };
  if (y >= geo.rows) return 'end';
  const pos = FZ.xyToPos(ed.lay, g.page, y, col); if (pos) return pos;
  const end = ed.lay.endPos; if (g.page === end.page && y >= end.y) { const ll = ed.doc.lines.length - 1; const ln = ed.doc.lines[ll]; return { line: ll, seg: ln.segs.length - 1, off: ln.segs[ln.segs.length - 1].text.length, vrow: y - end.y + 1, vcol: col }; }
  const f = ed.findRow(g.page, y, -1) || ed.findRow(g.page, y, 1); return f ? FZ.xyToPos(ed.lay, f.page, f.y, col) : null;
}
function setCaretFromGrid(g, extend) { const pos = posFromGrid(g); if (pos === 'end') ed.docEnd(extend); else if (pos) ed.setCaret(pos, extend); }
/* 押した回数（ダブル・トリプルクリック）。pointerdown の detail は Chromium では 0 なので自分で数える */
let lastDown = { t: -1e9, x: 0, y: 0, n: 0 };
function clickCount(e) { const now = e.timeStamp || performance.now(); const near = Math.abs(e.clientX - lastDown.x) < 5 && Math.abs(e.clientY - lastDown.y) < 5; const n = now - lastDown.t < 450 && near ? lastDown.n + 1 : 1; lastDown = { t: now, x: e.clientX, y: e.clientY, n }; return n; }
pagesEl.addEventListener('pointerdown', e => {
  if (st.mode === 'tree' && st.view === 'split') exitTree(false); // 並べる：紙面を押すと紙面へ
  if (e.button !== 0) return; const g = eventToGrid(e); if (!g) return; e.preventDefault(); const clicks = clickCount(e);
  if (inl) closeInline(true);
  if (st.form) closeForm(); if (st.armed) disarm();
  const geo = ed.lay.geo;
  if (st.mode === 'fig') { // 図の外をクリック：本文に戻ってそこにカーソル（別の図ならその図へ）
    const fi = figInfo(); const inFig = fi && g.page === fi.page && g.col >= fi.left - 1.2 && g.col <= fi.right + 1.2 && ((g.row >= fi.Y0 - 0.6 && g.row < fi.Y0 + fi.F.h) || figWhat(fi, { x: g.col - fi.left, y: g.row - fi.Y0 }).t === 'height');
    if (inFig) { figPointerDown(e, g, clicks); return; } exitFigMode();
  }
  if (st.mode === 'text' && !st.composing && figRowAt(g) != null) { enterFigMode(figRowAt(g), null); figPointerDown(e, g, clicks); return; }
  if (st.mode === 'text') {
    if (st.composing) return;
    const te = !e.shiftKey && tableEdgeAt(g); if (te) { const rows = tableRowsOn(te.I, g.page); st.cells = null; drag = { kind: 'tcol', id: e.pointerId, I: te.I, k: te.k, x: te.I.B[te.k], page: g.page, rows }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); return; }
    const fh = !e.shiftKey && figHit(g); if (fh) { st.figSel = fh.id; openForm(fh.chart ? 'chart' : 'fig'); return; } // 図版をクリック：図表の設定
    const prevCell = e.shiftKey ? (st.cells ? st.cells.a : cellOfPos(ed.caret)) : null;
    st.cells = null; setCaretFromGrid(g, e.shiftKey);
    if (prevCell) { const c2 = cellOfPos(ed.caret); if (c2 && c2.a === prevCell.a && (c2.line !== prevCell.line || c2.col !== prevCell.col)) { st.cells = { a: prevCell, b: c2 }; ed.anchor = null; ed.onCaret(); } } // Shift+クリック：表の中ならセルの範囲
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey) { const lk = FZ.linkAt(ed.seg(), ed.caret.off) || FZ.linkAt(ed.seg(), ed.caret.off - 1); if (lk) { openUrl(lk.url); return; } if (selectSentence()) { focusTA(); return; } } // Ctrl+クリック：リンクは開く、それ以外は文を選ぶ
    drag = { kind: 'sel', id: e.pointerId, cell: st.cells ? st.cells.a : cellOfPos(ed.caret) }; pagesEl.setPointerCapture(e.pointerId); focusTA(); syncTA();
    if (clicks === 2) ed.selectWord(); if (clicks >= 3) ed.selectLine();
  } else {
    const rc = { page: g.page, y: clamp(Math.round(g.row), 0, geo.rows), col: clamp(Math.round(g.col), 0, geo.cols) }; st.rc = rc; st.ranchor = { ...rc }; drag = { kind: 'rule', id: e.pointerId }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); focusTA();
  }
});
pagesEl.addEventListener('pointermove', e => {
  if (!drag || drag.id !== e.pointerId) { if (e.buttons) return; const g = eventToGrid(e); if (!g) return; let cur = ''; if (st.mode === 'fig' && st.fig) cur = figHover(g); else if (st.mode === 'text' && !inl) cur = tableEdgeAt(g) ? 'col-resize' : ''; if (pagesEl.style.cursor !== cur) pagesEl.style.cursor = cur; return; }
  const g = eventToGrid(e); if (!g) return; const geo = ed.lay.geo;
  if (drag.kind.startsWith('fig')) { figDragMove(g); return; }
  if (drag.kind === 'tcol') { const [lo, hi] = FZ.tbl.boundaryRange(ed, drag.I, drag.k); const x = clamp(half(g.col), lo, hi); if (x !== drag.x) { drag.x = x; requestOverlay(); } return; }
  if (drag.kind === 'sel') { if (st.composing) return; const y = clamp(Math.floor(g.row), 0, geo.rows - 1); const col = half(clamp(g.col, 0, geo.cols)); const f = ed.findRow(g.page, y, -1) || ed.findRow(g.page, y, 1); if (!f) return; const pos = FZ.xyToPos(ed.lay, f.page, f.y, col); if (!pos) return;
    const c2 = drag.cell ? cellOfPos(pos) : null; // 表の中で別のセルへ：セルの範囲を選ぶ
    if (c2 && c2.a === drag.cell.a && (c2.line !== drag.cell.line || c2.col !== drag.cell.col)) { st.cells = { a: drag.cell, b: c2 }; ed.anchor = null; ed.setCaret({ ...pos, vcol: null }); return; }
    if (st.cells && c2 && c2.line === drag.cell.line && c2.col === drag.cell.col) { st.cells = null; requestOverlay(); }
    ed.setCaret({ ...pos, vcol: null }, true); }
  else { const rc = { page: st.ranchor.page, y: clamp(Math.round(g.row), 0, geo.rows), col: clamp(Math.round(g.col), 0, geo.cols) }; st.rc = rc; const a = st.ranchor; if (st.mode === 'rule' && st.sub !== 'rect') { const horiz = Math.abs(rc.col - a.col) >= Math.abs(rc.y - a.y); st.preview = horiz ? { page: rc.page, c1: Math.min(a.col, rc.col), r1: a.y, c2: Math.max(a.col, rc.col), r2: a.y } : { page: rc.page, c1: a.col, r1: Math.min(a.y, rc.y), c2: a.col, r2: Math.max(a.y, rc.y) }; } requestOverlay(); }
});
pagesEl.addEventListener('pointerup', e => {
  if (!drag || drag.id !== e.pointerId) return; const d = drag; drag = null;
  if (d.kind.startsWith('fig')) { figDragEnd(d); return; }
  if (d.kind === 'tcol') { if (d.x !== d.I.B[d.k]) { FZ.tbl.moveBoundary(ed, d.I, d.k, d.x); msg('列の幅を変えました（Ctrl+Z で戻す）'); } requestOverlay(); focusTA(); return; }
  if (d.kind === 'rule') { const a = st.ranchor, b = st.rc; st.preview = null;
    if (st.mode === 'fill') { if (a.y !== b.y || a.col !== b.col) applyFill(); else { st.ranchor = null; requestOverlay(); } return; }
    if (st.sub === 'rect') { if (a.y !== b.y || a.col !== b.col) applyRect(); else { st.ranchor = null; requestOverlay(); } return; }
    const horiz = Math.abs(b.col - a.col) >= Math.abs(b.y - a.y); const erase = st.sub === 'erase';
    if (horiz && b.col !== a.col) hSeg(a.page, a.y, Math.min(a.col, b.col), Math.max(a.col, b.col), erase, b.col > a.col ? 'r' : 'l');
    else if (!horiz && b.y !== a.y) { const y1 = Math.min(a.y, b.y), y2 = Math.max(a.y, b.y); ed.mutate('', () => { ensureRows(a.page, y2 - 1); const vf = ed.vAnchorAt(a.page, y1), vt = ed.vAnchorAt(a.page, y2 - 1); if (vf == null || vt == null) return; if (erase) ed.eraseV(vf, vt, a.col); else ed.addVRule(vf, vt, a.col, st.ruleKind, b.y > a.y ? 'd' : 'u'); }); }
    st.ranchor = null; requestRender(); }
  else { if (st.cells) { drawSub(); status(); } focusTA(); }
});
pagesEl.addEventListener('pointerleave', () => { if (!drag && st.fig && st.fig.hover != null) { st.fig.hover = null; requestOverlay(); } });
/* 右クリック：帯をその場の操作に切り替える（ポップアップは出さない）。表＝表の編集、選んだ字＝文字、図＝図の帯、ほか＝段落 */
pagesEl.addEventListener('contextmenu', e => {
  e.preventDefault(); const g = eventToGrid(e); if (!g) return; if (inl) closeInline(true); if (st.form) closeForm();
  const fl = figRowAt(g);
  if (st.mode === 'fig' || (st.mode === 'text' && fl != null)) {
    if (st.mode !== 'fig') { if (fl == null) return; enterFigMode(fl, null); } const loc = figLocal(g); if (!loc) return; const w = figWhat(loc.fi, loc);
    if (w.t === 'box' && !figIds().includes(w.box.id)) figSelect(w.box.id, false); else if (w.t === 'arrow') { figSetSel([]); st.fig.selArrow = w.k; }
    figRefresh(); msg('上の帯で、選んだ箱の線・網・揃えを変えられます'); return;
  }
  if (st.mode !== 'text' || st.composing) return;
  const inSel = ed.sel() && selectionRects().some(r => r.page === g.page && g.row >= r.y && g.row < r.y + r.h && g.col >= r.col - 0.3 && g.col <= r.col + r.w + 0.3);
  const inCells = st.cells && cellRects().some(r => r.page === g.page && g.row >= r.y && g.row < r.y + r.h && g.col >= r.col && g.col <= r.col + r.w);
  if (!inSel && !inCells) { st.cells = null; setCaretFromGrid(g, false); }
  const grp = FZ.inTable(ed.doc, ed.caret.line) ? 'tedit' : ed.sel() && !sentSelOk() ? 'marks' : 'struct'; /* 右クリック：表の中は表の編集、文字を選んでいれば文字、それ以外は構造 */
  st.group = grp; st.armed = true; drawSub(); drawFkeys(); requestOverlay(); focusTA();
});
main.addEventListener('pointerdown', e => { if (e.target === main || e.target === pagesEl) { if (st.form) closeForm(); if (st.armed) disarm(); focusTA(); } });
main.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); if (st.view === 'tree') treeZoom(e.deltaY < 0 ? 1 : -1); else pageZoomStep(e.deltaY < 0 ? 1 : -1); } }, { passive: false });
tpane.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); treeZoom(e.deltaY < 0 ? 1 : -1); } }, { passive: false });
/* ================= コマンド ================= */
const CMDS = [];
const cmd = (id, label, group, keys, fn, kw = '') => CMDS.push({ id, label, group, keys, fn, kw });
cmd('editGroup', '編集メニュー（元に戻す・検索置換・整える）', '編集', '', () => toggleGroup('edit'));
cmd('insertGroup', '挿入メニュー（画像・図表・図・表・区切り線・囲み記事・目次）', '挿入', '', () => toggleGroup('insert'));
cmd('tableMenu', '表のメニュー（作る・行と列・セルの網と揃え・様式）', '表', '', () => toggleGroup('tedit'));
cmd('fmtGroup', '書式メニュー（用紙・文字数・体系・資料の柱・書体）', '書式', '', () => toggleGroup('fmt'));
cmd('viewGroup', '表示メニュー（倍率・グリッド・ツリー・コマンド一覧）', '表示', '', () => toggleGroup('view'));
cmd('slideHead', '資料の柱と欄…（本文欄の幅・仕切り・柱の題・機密表示・作成日・作成者・頁番号・表紙・開始番号）', '書式', '', () => { if (ed.doc.format.kind !== 'slide') { msg('資料書式の文書で使えます（新しい資料は ' + K('new') + ' → S、今の文書を資料にするには ' + K('format') + ' の「書式の種類」）', true); return; } openForm('slide'); }, '資料 柱 ヘッダ 機密 作成者 頁番号');
cmd('help', '取説（やりたいこと別の操作とキーの一覧）', '取説', '', () => toggleSide('help'));
cmd('manual', '取扱説明書を文書で開く（取説と同じ中身＋機能の見本。別の窓）', '取説', '', () => openManual(), '説明書 マニュアル 見本');
cmd('history', '版の履歴…（開いたとき・保存のたびの原本。選ぶとその版に戻す）', 'ファイル', '', () => toggleSide('hist'), '復元 元に戻す 版 履歴 バックアップ');
cmd('insertFile', '文書を挿入…（.fzk・.md・.txt を今の行に）', '挿入', '', () => insertFileHere(), '結合 読み込み 差し込む');
cmd('splitDoc', 'ここから先を別の文書に…（カーソルの行から文末までを別名で保存し、この文書から除く）', 'ファイル', '', () => splitHere(), '分割 切り出す');
cmd('count', '字数を数える…（選択範囲・空白を除く・原稿用紙換算）', '編集', '', () => openForm('count'), '文字数 カウント 原稿用紙');
cmd('romaji', 'ローマ字をかなに（選んだ範囲か、カーソルの前の英字。漢字は IME の再変換で）', '編集', '', () => romajiHere(), 'シフトミス 打ち間違い 英字 かな');
cmd('fileGroup', 'ファイルメニュー（新規・開く・保存・印刷・書き出し）', 'ファイル', '', () => toggleGroup('file'));
cmd('new', '新しい文書', 'ファイル', 'Ctrl+N', newDoc);
cmd('newSlide', '新しい資料（プレゼン。A4 横・1 行目は柱の表題）', 'ファイル', '', () => withDiscard(() => slideDoc()), 'プレゼン スライド 資料');
cmd('kindDoc', 'この文書を「文書」にする（Word 型の紙面。上の「種類」でも）', '書式', '', () => setKind('doc'), '種類 文書 ワード');
cmd('kindSlide', 'この文書を「資料」にする（プレゼン型。A4 横・柱に表題。上の「種類」でも）', '書式', '', () => setKind('slide'), '種類 資料 プレゼン スライド');
/* 文書の種類（上の帯の左端のプルダウン）：文書 ⇄ 資料。中身はそのまま、用紙・字数・柱だけを替える（取り消しで戻る） */
function docFormatFrom(cur) { let base = defaultFormat(); if (base.kind === 'slide') base = FZ.newDoc().format; const f = JSON.parse(JSON.stringify(cur)); delete f.pageAlt; for (const k of ['paper', 'widthMm', 'heightMm', 'landscape', 'cols', 'rows', 'headerRows', 'footerRows', 'hfGap', 'margins', 'header', 'footer']) if (base[k] !== undefined) f[k] = JSON.parse(JSON.stringify(base[k])); f.kind = 'doc'; return f; }
const pickPage = f => { const o = {}; for (const k of FZ.PAGE_KEYS) if (f[k] !== undefined) o[k] = JSON.parse(JSON.stringify(f[k])); return o; };
function setKind(k) {
  const cur = ed.doc.format; const ck = cur.kind === 'slide' ? 'slide' : 'doc'; if (ck === k) { syncKind(); return; } if (st.mode !== 'text') exitMode(); if (st.form) closeForm();
  let restored = false; ed.mutate('', () => { const alt = { ...(cur.pageAlt || {}) }; alt[ck] = pickPage(cur); /* 今の種類の版面を控え、もう一方の控えがあれば戻す */
    const f = k === 'slide' ? slideFormat(cur) : docFormatFrom(cur); if (alt[k]) { Object.assign(f, JSON.parse(JSON.stringify(alt[k]))); restored = true; } f.pageAlt = alt; ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); });
  syncKind(); msg(k === 'slide' ? `資料にしました（${restored ? 'この文書の資料の版面' : '資料の既定の版面'}・1 行目の表題は柱へ。柱の中身は ${K('slideHead')}、戻すには Ctrl+Z か「種類」で文書）` : `文書にしました（${restored ? 'この文書の書類の版面' : '書類の既定の版面'}。戻すには Ctrl+Z）`);
}
/* 見え方（紙面／ツリー）：帯の左端の 2 段目のプルダウン */
function syncView() { const el = $('viewSel'); if (!el) return; const v = st.view || 'paper'; if (el.value !== v) el.value = v; }
$('viewSel').addEventListener('change', e => { setView(e.target.value); });
function syncKind() { const el = $('kindSel'); if (!el) return; const k = ed.doc.format.kind === 'slide' ? 'slide' : 'doc'; if (el.value !== k) el.value = k; }
$('kindSel').addEventListener('change', e => { setKind(e.target.value); focusTA(); });
$('kind').addEventListener('pointerdown', e => { if (st.armed) disarm(); if (st.form) closeForm(); });
cmd('open', 'ファイルを開く…', 'ファイル', 'Ctrl+O', openFile);
cmd('save', '保存', 'ファイル', 'Ctrl+S', () => saveFile(false));
cmd('saveAs', '名前を付けて保存…', 'ファイル', 'Ctrl+Shift+S', () => saveFile(true));
cmd('pasteMd', '直前の貼り付けを別の形に（文字 → Markdown として整形、Excel のセルの表 → 見た目のまま図）', '編集', 'Ctrl+Alt+V', pasteAsMarkdown, 'markdown 貼付 paste');
cmd('newWindow', '新しい窓を開く（最大 8 つ。別の文書を同時に開ける）', 'ファイル', '', newWindow, '窓 ウィンドウ 複数 同時');
cmd('jaLift', '貼付・.md/.txt の読み込みで、行頭の「１．」「（１）」「①」「■」「・」などを見出し・箇条書きに起こす（切替）', '編集', '', () => { st.jaLift = !st.jaLift; try { localStorage.setItem('fz.jaLift', st.jaLift ? '1' : '0'); } catch { } msg('和文の番号・記号を起こす：' + (st.jaLift ? '入（貼付と .md/.txt の読み込みに効く）' : '切')); drawSub(); }, '和文 番号 起こす 貼付 変換');
cmd('tplSave', 'テンプレートとして保存…', 'ファイル', '', () => openForm('tplname'), '雛形');
cmd('settingsOut', '設定を書き出す（既定の書式・体系・テンプレート）', 'ファイル', '', exportSettings);
cmd('settingsIn', '設定を読み込む…', 'ファイル', '', importSettings);
cmd('exportMd', 'Markdown で書き出す（文机 Markdown：節の名札・参照・図版・改頁を注記で持つ GFM。読み込むと戻る）', 'ファイル', '', () => FZ.files.download(FZ.toGfm(ed.doc, { fz: true }), baseTitle() + '.md'), 'md');
cmd('exportDocx', 'Word（.docx）で書き出す（見出しスタイル・自動番号・表・図形・画像）', 'ファイル', '', async () => { try { await busy('Word に書き出し中…'); const d = await officeDoc(ed.doc); FZ.files.download(await FZ.zipAsync(FZ.toDocx(d, { files: true })), baseTitle() + '.docx'); msg('Word 文書を書き出しました' + (d._converted ? `（SVG・WebP の画像 ${d._converted} 枚を PNG にして入れた）` : '')); } catch (e) { msg('Word 書き出しに失敗：' + e.message, true); } }, 'word docx ワード');
cmd('importDocx', 'Word を取り込む…（.docx。見出しスタイル→見出し、箇条書き・段落番号→箇条書き、表・太字・リンク・画像。見出しスタイルが無ければ平文の番号から節を起こす）', 'ファイル', '', () => pickDocx(), 'Word docx 取り込み インポート 変換 見出し');
cmd('exportTreePptx', 'ツリーの見た目で PowerPoint（箱と線を図形で。節の途中で頁を切らない）', 'ファイル', '', () => exportTree('pptx'), 'ツリー 図 PowerPoint');
cmd('exportTreePdf', 'ツリーの見た目で印刷・PDF（A4 縦。節の途中で頁を切らない）', 'ファイル', '', () => exportTree('pdf'), 'ツリー 図 PDF 印刷');
cmd('exportTreeDocx', 'ツリーの見た目で Word（頁ごとの図）', 'ファイル', '', () => exportTree('docx'), 'ツリー 図 Word');
cmd('exportPptx', 'PowerPoint（.pptx）で書き出す（1 ページ＝1 スライド、表・図形・画像）', 'ファイル', '', async () => { try { await busy('PowerPoint に書き出し中…'); const d = await officeDoc(ed.doc); FZ.files.download(await FZ.zipAsync(FZ.toPptx(d, { files: true })), baseTitle() + '.pptx'); msg('PowerPoint を書き出しました' + (d._converted ? `（SVG・WebP の画像 ${d._converted} 枚を PNG にして入れた）` : '')); } catch (e) { msg('PowerPoint 書き出しに失敗：' + e.message, true); } }, 'powerpoint pptx パワポ スライド');
/* Word・PowerPoint に渡す文書：Office がそのまま開けない画像（SVG・WebP など）を PNG にする（画面の側で描いて写す）。
 * SVG は線画なので長辺 2000px で描き直してにじませない。変換は覚えておき、同じ画像は描き直さない。描けなかった画像は元のまま（書き出し側の注記になる） */
const PNGC = new Map(); const OFFICE_MIME = /^image\/(png|jpeg|gif)$/;
function toPng(img) {
  const key = img.mime + ':' + img.data.length + ':' + img.data.slice(0, 64) + img.data.slice(-64); if (PNGC.has(key)) return PNGC.get(key);
  const p = (async () => { const url = URL.createObjectURL(b64ToBlob(img)); try { const im = new Image(); im.src = url; await im.decode(); const sz = FZ.imageSize(img);
      const vector = /svg/.test(img.mime); let w = im.naturalWidth || sz.w || 800, h = im.naturalHeight || sz.h || 600; if (vector) { const r = (sz.h || h) / (sz.w || w); w = 2000; h = Math.max(1, Math.round(2000 * r)); if (h > 2000) { w = Math.max(1, Math.round(w * 2000 / h)); h = 2000; } }
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').drawImage(im, 0, 0, w, h);
      const blob = await new Promise(res => cv.toBlob(res, 'image/png')); if (!blob) throw new Error('PNG にできません');
      const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).replace(/^data:[^,]*,/, '')); fr.onerror = () => rej(fr.error); fr.readAsDataURL(blob); });
      return { mime: 'image/png', data }; } finally { URL.revokeObjectURL(url); } })();
  PNGC.set(key, p); p.catch(() => PNGC.delete(key)); return p;
}
async function officeDoc(doc) {
  const imgs = doc.images || {}; const names = Object.keys(imgs).filter(n => imgs[n] && imgs[n].data && !OFFICE_MIME.test(imgs[n].mime)); if (!names.length) return doc;
  const images = { ...imgs }; let n = 0; await Promise.all(names.map(async nm => { try { images[nm] = await toPng(imgs[nm]); n++; } catch { } }));
  const out = { ...doc, images }; Object.defineProperty(out, 'fileName', { value: doc.fileName || '', enumerable: false }); Object.defineProperty(out, '_converted', { value: n, enumerable: false }); return out;
}
cmd('exportTxt', 'プレーンTXT で書き出す', 'ファイル', '', () => FZ.files.download(FZ.toPlain(ed.doc), baseTitle() + '.txt'));
cmd('print', '印刷／PDF', 'ファイル', 'Ctrl+P', doPrint, 'pdf');
cmd('format', '書式（用紙・文字数・行数・余白・書体・番号体系）', '書式', '', () => toggleForm('format'));
cmd('fillMode', '網掛け（範囲を選んで地に網）', '配置', '', enterFillMode);
cmd('table', '表を入れる…（列数・行数・列幅）／表の中なら様式を変える…', '挿入', '（罫線モード）F6', () => toggleForm('table'));
cmd('marks', '文字メニュー（太字・下線などの修飾、倍角、リンク）', '文字', '', () => toggleGroup('marks'));
cmd('structGroup', '構造メニュー（種類・段の上げ下げ・並べ替え・組替・文・改頁・番号の形。紙面でもツリーでも同じ）', '構造', '', () => toggleGroup('struct'));
for (const [k, l, key] of [['out', '上げる（梯子：文→段落→見出し。見出し・箇条書きは浅く）', 'Alt+←'], ['in', '下げる（梯子：段落→前の段落の文、文→箇条書き。見出し・箇条書きは深く）', 'Alt+→'], ['up', '上へ（兄弟の中で。子と本文ごと。文は段落の中で）', 'Alt+↑'], ['down', '下へ（兄弟の中で）', 'Alt+↓']]) cmd('sx:' + k, '構造：' + l, '構造', key, () => structOp(k), '梯子 レベル 上げ下げ 格上げ 格下げ 並べ替え');
for (const [k, l] of [['para', '段落を文ごとの段落にばらす'], ['list', '段落を箇条書きにばらす（1 文 1 項目）'], ['tree', '段落を親子にばらす（最初の文が親、残りが子の項目）'], ['merge', '選んだ行・節（または節と子）を 1 つの段落にまとめる']]) cmd('sx:re:' + k, '組替：' + l, '構造', '', () => structOp('re', k), 'ばらす まとめる 文 段落 箇条書き 親子 組替');
cmd('moveTo', '送り先を選んで移す…（見出しの一覧から移し先を選ぶ。子と本文ごと。長い文書でドラッグしない）', '構造', 'Ctrl+M', () => { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); openForm('moveTo'); }, '移動 移す 送る 見出し 節');
cmd('checkStruct', '構造の点検…（子が 1 つ・中身なし・長い文・文末の不統一・段の飛び を節に印で）', '構造', '', () => { toggleForm('scheck'); if (st.view === 'tree' || st.view === 'split') render(); }, '点検 チェック 校正 文末 長い文');
cmd('sentOpt', '文の分け方…（「．」も文末に、箇条書きの中の文も分ける）', '書式', '', () => openForm('sentopt'), '文 分け方 句点 ピリオド');
cmd('park', '保留へ送る（選んだ節・文・範囲を文書の外の「保留の島」へ。書き出しには出ない。いつでも戻せる）', '構造', '', () => parkSel(), '保留 退避 パーキング 島 一時 置き場');
cmd('parkList', '保留の島…（退避した節・文を見る・戻す・消す）', '構造', '', () => openForm('parked'), '保留 退避 島 戻す');
cmd('sx:mark', '番号・記号の形…（カーソル・選んだ節の段のものすべて。全体は体系…）', '構造', '', () => openForm('marker'), '番号 記号 形 体系');
cmd('selSent', '文を選ぶ（カーソルのある文。紙面では Ctrl+クリックでも。選んだ文に上げる・下げる・種類・上へ下へが効く）', '構造', '', () => selectSentence(), '文 選択 センテンス');
cmd('aiCopySec', 'この節を Markdown で写す（AI に貼り付ける用。紙面＝カーソルの節か選んだ範囲、ツリー＝選んだ節と子）', 'ファイル', '', () => aiCopy(false), 'AI Markdown コピー 写す ChatGPT Claude 貼り付け');
cmd('aiCopyDoc', '文書全体を Markdown で写す（AI に貼り付ける用）', 'ファイル', '', () => aiCopy(true), 'AI Markdown コピー 全体 写す');
cmd('panels', '区画…（見出しの子の節を横に並べた枠に。霞が関型の 1 枚もの）', '配置', '', () => openPanels(), '区画 霞が関 ポンチ絵 枠 横に並べる 列 パネル');
cmd('aiReturn', 'AI から戻す…（AI が直した Markdown を貼ると、違う所を 1 つずつ見て取り込む・捨てる。飾り・罫は今のまま）', 'ファイル', '', () => aiReturn(), 'AI 戻す 取り込む 差分 比べる 貼り付け Markdown ChatGPT Claude');
for (const [k, l] of [['i', '字下げ（上から下へ 1 節 1 行。狭い幅でも読める）'], ['h', '横に広げる（左から右へ）'], ['v', '縦に広げる（上から下へ）']]) cmd('tvs:' + k, 'ツリーの形：' + l, '表示', '', () => { st.tree.dir = k; if ((!st.view || st.view === 'paper') && st.mode !== 'tree') enterTree(); render(); drawSub(); treeScrollToSel(); }, 'ツリー 形 向き');
cmd('find', '検索・置換（ツリーでは節を探す：当たった節に印、Enter で次へ）', '編集', 'Ctrl+F', () => toggleForm(st.mode === 'tree' ? 'tfind' : 'replace'));
cmd('replace', '置換', '編集', 'Ctrl+H', () => toggleForm('replace'));
cmd('lineGroup', '配置メニュー（揃え・位置・改ページ）', '配置', '', () => toggleGroup('line'));
cmd('palette', 'コマンド一覧', '表示', 'Ctrl+K', () => toggleSide('palette'));
cmd('undo', '元に戻す', '編集', 'Ctrl+Z', () => { ed.undo(); });
cmd('redo', 'やり直す', '編集', 'Ctrl+Y', () => { ed.redo(); });
cmd('selectAll', 'すべて選択', '編集', 'Ctrl+A', () => ed.selectAll());
cmd('bold', 'ゴシック太字', '文字', 'Ctrl+B', () => ed.toggleMark(M.BOLD));
cmd('under', '下線', '文字', 'Ctrl+U', () => ed.toggleMark(M.UNDER));
cmd('dot', '傍点', '文字', '', () => ed.toggleMark(M.DOT));
cmd('shade', '網掛け文字', '文字', '', () => ed.toggleMark(M.SHADE));
cmd('codeSpan', '文中のコード（Markdown の ` と往復。淡い網・ゴシック）', '文字', '', () => ed.toggleMark(M.CODE), 'code コード 等幅');
cmd('outline', '白抜き', '文字', '', () => ed.toggleMark(M.OUTLINE));
cmd('strike', '取消線', '文字', '', () => ed.toggleMark(M.STRIKE));
cmd('under2', '二重下線', '文字', '', () => ed.toggleMark(M.UNDER2));
cmd('wave', '波線の下線', '文字', '', () => ed.toggleMark(M.WAVE));
cmd('strike2', '二重取消線', '文字', '', () => ed.toggleMark(M.STRIKE2));
cmd('shadeType', '網の文様…（字の網掛けを斜線・格子・濃さなどに）', '文字', '', () => openForm('shadeType'), '網掛け 文様 パターン 斜線 格子');
cmd('shadow', '影文字（白抜きと組むと新聞の影付き白抜き）', '文字', '', () => ed.toggleMark(M.SHADOW), '影 シャドウ 白抜き 見出し');
cmd('scale', 'm×n 倍角…（横・縦 1〜9 倍）', '文字', '', () => openForm('scale'), '倍角 拡大 大きい字 掲示');
cmd('wide', '横倍角', '文字', '', () => ed.toggleMark(M.WIDE));
cmd('tall', '縦倍角', '文字', '', () => ed.toggleMark(M.TALL));
cmd('quad', '四倍角', '文字', '', () => { const s = ed.sel(); if (s) { const all = ed.allMarked(s, M.WIDE) && ed.allMarked(s, M.TALL); ed.mutate('', () => ed.forEachMark(s, m => all ? (m & ~(M.WIDE | M.TALL)) : (m | M.WIDE | M.TALL))); ed.typing = all ? (ed.typing & ~(M.WIDE | M.TALL)) : (ed.typing | M.WIDE | M.TALL); } else { const on = (ed.typing & M.WIDE) && (ed.typing & M.TALL); ed.typing = on ? (ed.typing & ~(M.WIDE | M.TALL)) : (ed.typing | M.WIDE | M.TALL); ed.onCaret(); } });
cmd('clearMarks', '修飾をすべて解除', '文字', '', () => ed.setMarks(0));
cmd('alignL', '左揃え', '配置', 'Ctrl+L', () => ed.setAttrs({ align: null }));
cmd('alignC', '中央揃え', '配置', 'Ctrl+E', () => ed.toggleAttr('align', 'center'));
cmd('alignR', '右揃え', '配置', 'Ctrl+R', () => ed.toggleAttr('align', 'right'));
cmd('alignJ', '均等割付', '配置', 'Ctrl+J', () => ed.toggleAttr('align', 'justify'));
cmd('styleBody', '本文（見出し・箇条書き・発言録を外す。位置は保つ）', '構造', '', () => kindGuard('body') || ed.setAttrs({ style: null, level: null, list: null, speakerCols: null }));
cmd('styleTitle', '表題', '構造', '', () => kindGuard('title') || ed.setAttrs({ style: 'title' }));
cmd('styleNum', '数字見出し（レベル別の番号。Tab で深く）', '構造', '', () => kindGuard('num') || ed.setHeading('num'), '見出し 番号 章');
cmd('styleSym', '記号見出し（レベル別の記号。Tab で深く）', '構造', '', () => kindGuard('sym') || ed.setHeading('sym'), '見出し ■');
cmd('styleSpeech', '発言録（発言者：本文）', '配置', '', () => { const cur = ed.line().attrs; if (cur.style === 'speech') ed.setAttrs({ style: null, speakerCols: null }); else openForm('speech'); }, '台本 議事録');
cmd('item', '箇条書き（レベル別の記号。Tab で深く）切替', '構造', '', () => kindGuard('list') || ed.setList(), '項目 bullet');
cmd('scheme', '見出しと箇条書きの体系…（三体系：番号と記号、見出しの前後の空き、本文の位置）', '書式', '', () => toggleForm('scheme'), 'レベル 箇条書き 番号 記号');
cmd('arrow', '→ 結論・展開の行頭記号', '構造', '', () => ed.setList('arrow'));
cmd('numItem', '番号付き箇条書き（1） 2） 3）…。続く項目を自動で数える。Tab で深く（a） b）…）、Markdown の 1. 2. と往復）切替', '構造', '', () => kindGuard('nlist') || ed.setList('num'), '番号 番号付き リスト ordered 連番');
cmd('todo', '❏ 課題（アクション）の行頭記号 入切', '構造', '', () => ed.setList('todo'), 'todo task チェック 課題');
cmd('done', '☑ 完了 入切（❏ の行を完了に、☑ を ❏ に戻す）', '構造', '', () => ed.setList('done'), 'done 完了 チェック');
cmd('quote', '引用（左に線、2 マス字下げ）入切', '配置', '', () => ed.cycleQuote(), 'blockquote');
cmd('code', 'コード（淡い地。Markdown のコードブロック）切替', '配置', '', () => ed.toggleCode(), 'code pre');
cmd('link', 'リンク…（選択範囲に URL を付ける／外す）', '文字', 'Ctrl+Shift+L', () => openForm('link'), 'url ハイパーリンク');
cmd('childItem', '子項目を作る（1階層下）', '構造', '', () => ed.childItem());
for (const h of FZ.HEADINGS) cmd('hd:' + h.id, '見出し飾り：' + h.label + '（' + h.desc + '）', '見出し飾り', '', () => FZ.applyHeading(ed, h.id), '新聞 見出し');
for (const t of FZ.TABLES) cmd('tb:' + t.id, '表スタイル：' + t.label + '（' + t.desc + '）', '表の様式', '', () => { if (!FZ.applyTable(ed, t.id)) msg('表の中にカーソルを置いてください', true); }, '新聞 表組');
for (const o of FZ.TABLE_OPS) cmd('to:' + o.id, o.id === 'headFill' ? '表：見出し行の網…（薄網・濃網・墨・斜線・なしから選ぶ）' : '表：' + o.label + '（' + o.desc + '）', '表の様式', '', () => { if (o.id === 'headFill') { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return; } openForm('headFill'); return; } if (!FZ.applyTableOp(ed, o.id)) { msg('表の中にカーソルを置いてください', true); return; } if (o.id === 'repeat') { const rg = FZ.tableRange(ed); msg(rg && ed.doc.lines[rg[0]].attrs.noRepeat ? 'この表は見出し行を繰り返しません' : 'ページをまたぐと、次のページの頭に見出し行を繰り返します'); } }, o.id === 'repeat' ? '表組 見出し行 繰り返し タイトル行 ヘッダ行 ページ' : '表組');
cmd('headGroup', '見出し飾り…（新聞の見出し表現）', '配置', '', () => toggleGroup('head'));
cmd('hr', '区切り線を入れる（行の真ん中に線を引く行。Markdown の ---。手で引いた罫とは別）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); ed.insertHr(); }, '区切り線 水平線 hr ---');
cmd('toc', '目次を入れる／範囲を変える（見出しを抜き出して頁番号を自動で付ける）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); openForm('toc'); }, '目次 もくじ 見出し一覧 索引');
cmd('figOpen', '画像を入れる…（図表として今の行に付ける。資料書式では右の図表欄に積む。貼り付け・ドラッグ＆ドロップでも入る）', '挿入', 'Ctrl+V（画像）', () => { if (st.mode !== 'text') exitMode(); pickImage().then(r => { if (r) addImageFigure(r); }); }, '画像 図 写真 グラフ ピクチャ 挿入 png jpeg');
cmd('figEdit', '図表…（題・図／表・幅・順番・差し替え・削除）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); const L = ed.figList(); if (!L.length) { msg('図表がありません（' + K('figOpen') + ' で画像を入れる、または画像を貼り付け）', true); return; } const here = L.filter(x => x.line <= ed.caret.line); const fx = here.length ? here[here.length - 1] : L[0]; st.figSel = fx.fg.id; openForm(fx.fg.chart ? 'chart' : 'fig'); }, '図表 画像 図番号 題 キャプション');
cmd('chart', 'グラフ…（表の中なら表のデータで作る。Excel のセルを表として貼った後もここで。今の行にグラフがあれば直す）', '挿入', 'Ctrl+G', () => chartCmd(), 'グラフ 棒 横棒 折れ線 円 帯 積み上げ チャート 表から Excel');
cmd('figTree', '構成図を作る…（カーソル・選んだ節と子の見出し・箇条書きを、箱と矢印の図に自動で並べる）', '挿入', '', () => openForm('figtree'), '構成図 組織図 ツリー 図 自動 流れ図 マインドマップ');
cmd('secRef', '節の参照を入れる…（本文に「2. 構成」のような見出しの番号と題。並べ替えても番号が追う）', '挿入', '', () => { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); openForm('secref'); }, '参照 相互参照 節 見出し 章');
cmd('skeleton', '構成の型…（報告書・企画書・議事録・霞が関の説明資料・論点整理・事業概要・答申 の骨組みを流し込む）', '構造', '', () => { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); openForm('skeleton'); }, '型 テンプレート 骨組み 霞が関 報告書 企画書 議事録');
cmd('figRef', '図番を入れる（本文に「図 1」。図表の順番が変わっても番号が追従）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); if (!ed.figList().length) { msg('図表がありません', true); return; } openForm('figref'); }, '図番 参照 相互参照 図 表');
cmd('dateToday', '作成日を今日の日付にする（資料の柱。書式の「資料の柱…」で「自動」にすると毎日今日の日付になる）', '書式', '', () => { const f = ed.doc.format; const t = FZ.todayJa(); if (!f.dateAuto && f.date === t) { msg('作成日はすでに今日です（' + t + '）'); return; } ed.mutate('', () => { f.date = t; f.dateAuto = false; }); msg('作成日を今日にしました：' + t); }, '日付 今日 作成日 更新 本日');
cmd('mdStars', '文中に残った **…** を太字にする（生成 AI の Markdown を取り込んで ** が文字のまま残ったとき。選択範囲、無ければ文書全体。対にならない ** は消す）', '編集', '', () => { const n = ed.cleanMdStars(); msg(n ? `** を ${n} か所直しました（Ctrl+Z で戻す）` : '文中に ** はありません'); }, '** アスタリスク 太字 markdown 記号 整える');
cmd('newSlide', '新しい資料（A4 横、本文欄＋図表欄、柱に題・機密表示・日付・頁番号。新規 → S）', 'ファイル', '', () => withDiscard(slideDoc), '資料 プレゼン スライド パワポ 横');
cmd('figInsert', '図（フローチャート）を入れる／編集する', '挿入', '', () => { if (st.mode === 'fig') return; const ln = ed.line(); if (ln.attrs.figure) { enterFigMode(ed.caret.line); return; } if (st.mode !== 'text') exitMode(); const at = ed.insertFigure(10); enterFigMode(at); msg('図：N 箱を足す／C 矢印でつなぐ／Tab 選ぶ／矢印キーで動かす／L レーン／Esc で本文へ'); }, 'フローチャート 流れ図 箱 矢印 スイムレーン');
cmd('fg:add', '図：箱を足す（空いた所をダブルクリックでも）', '図', 'N', () => { if (st.mode === 'fig') figAddBox(); });
cmd('fg:text', '図：箱の文字をその場で打つ（箱をダブルクリックでも）', '図', 'Enter / T', () => { if (st.mode !== 'fig') return; if (st.fig.selArrow != null) { openInline('arrow', st.fig.selArrow); return; } const b = figPrim(); if (b) openInline('box', b.id); else msg('箱を選んでください', true); });
cmd('fg:props', '図：箱の設定…（文字・幅・高さ・線・網）', '図', 'P', () => { if (st.mode === 'fig' && figSel()) openForm('box'); });
cmd('fg:connect', '図：矢印でつなぐ（箱の辺の点から別の箱へドラッグでも）', '図', 'C', () => { if (st.mode === 'fig') figConnectStart(); });
cmd('fg:dup', '図：選んだ箱を複製', '図', 'D / Ctrl+D', () => { if (st.mode === 'fig') figDuplicate(); });
cmd('fg:all', '図：箱をすべて選ぶ', '図', 'Ctrl+A', () => { const fi = st.mode === 'fig' && figInfo(); if (fi) { figSetSel(fi.F.boxes.map(b => b.id)); figRefresh(); } });
cmd('fg:delete', '図：選んだ箱／矢印を消す', '図', 'Delete', () => { if (st.mode === 'fig') figDelete(); });
cmd('fg:kind', '図：箱の線種（細→太→二重→点線）', '図', 'K', () => { if (st.mode === 'fig') figCycleProp('kind', ['thin', 'thick', 'double', 'dotted']); });
cmd('fg:shade', '図：箱の網（なし→薄→濃網→墨→斜線→点）', '図', 'S', () => { if (st.mode === 'fig') figCycleProp('shade', [null, 'gray', 'deep', 'dark', 'hatch', 'dots']); });
for (const [k, l] of [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']]) cmd('fg:k:' + k, '図：箱の線を' + l + 'に', '図', '', () => { if (st.mode === 'fig') figSetProp('kind', k); });
for (const [id, l] of [['none', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['dots', '点']]) cmd('fg:s:' + id, '図：箱の網を' + l + 'に', '図', '', () => { if (st.mode === 'fig') figSetProp('shade', id === 'none' ? null : id); });
for (const [m, l] of [['left', '左を揃える'], ['center', '左右の中央を揃える'], ['right', '右を揃える'], ['top', '上を揃える'], ['middle', '上下の中央を揃える'], ['bottom', '下を揃える'], ['dh', '横に等間隔'], ['dv', '縦に等間隔']]) cmd('fg:al:' + m, '図：選んだ箱の' + l, '図', '', () => { if (st.mode === 'fig') figAlign(m); });
cmd('fg:bold', '図：箱の文字を太字', '図', 'B', () => { if (st.mode === 'fig') figCycleProp('bold', [false, true]); });
cmd('fg:lanes', '図：スイムレーン…（縦／横、名前）', '図', 'L', () => { if (st.mode === 'fig') openForm('lanes'); });
cmd('fg:taller', '図の高さ＋1（図の下端のつまみをドラッグでも）', '図', '+', () => { if (st.mode === 'fig') figHeight(1); });
cmd('fg:shorter', '図の高さ−1', '図', '-', () => { if (st.mode === 'fig') figHeight(-1); });
cmd('tableGroup', '表スタイル…（新聞・統計表の表組）', '表', '', () => toggleGroup('table'));
/* 表の編集（行・列・セル）。右クリックで帯に出る。セルの操作は選んだ範囲（ドラッグ・Shift+クリック）か、カーソルのセル */
function tblDo(fn) { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return false; } const r = fn(); if (r === 'narrow') msg('列が狭くて足せません（列の境の罫をドラッグして広げてから）', true); return r; }
function cellsDo(fn) { const R = cellRect(); if (!R) { msg('表の中にカーソルを置いてください', true); return; } fn(R); requestOverlay(); }
cmd('teditGroup', '表の編集…（行・列の挿入と削除、セルの網・揃え・消去。表の中で右クリックでも）', '表', '', () => { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return; } toggleGroup('tedit'); });
cmd('tr:above', '表：上に行を挿入', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertRow(ed, false); }));
cmd('tr:below', '表：下に行を挿入', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertRow(ed, true); }));
cmd('tr:del', '表：この行を削除', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteRow(ed); }));
cmd('tc:left', '表：左に列を挿入（今の列を半分に分ける）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertCol(ed, false); }));
cmd('tc:right', '表：右に列を挿入（今の列を半分に分ける）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertCol(ed, true); }));
cmd('tc:del', '表：この列を削除（幅は隣の列へ）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteCol(ed); }));
cmd('tdel', '表を削除', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteTable(ed); }));
for (const [id, l] of [['gray', '薄網'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['none', 'なし']]) cmd('tcs:' + id, '表：セルの網を' + l + 'に', '表', '', () => cellsDo(R => FZ.tbl.fillCells(ed, R, id)));
for (const [al, l] of [['left', '左'], ['center', '中央'], ['right', '右']]) cmd('tca:' + al, '表：セルを' + l + '揃えに', '表', '', () => cellsDo(R => FZ.tbl.alignCells(ed, R, al)));
cmd('tcb', '表：セルの字を太字（切替）', '表', '', () => cellsDo(R => FZ.tbl.boldCells(ed, R)));
cmd('tcx', '表：セルの中身を消す（範囲を選んで Delete でも）', '表', '', () => cellsDo(R => { st.cells = null; FZ.tbl.clearCells(ed, R); }));
cmd('indent', 'レベルを深く（見出し・箇条書き。位置は変えない）', '構造', 'Tab', () => { if (!ed.indent(1)) msg('本文の行にはレベルがありません。位置を動かすのは ' + K('posRight') + '（右へ）／' + K('posLeft') + '（左へ）', true); });
cmd('outdent', 'レベルを浅く（見出し・箇条書き。位置は変えない）', '構造', 'Shift+Tab', () => { if (!ed.indent(-1)) msg('本文の行にはレベルがありません。位置を動かすのは ' + K('posLeft') + '（左へ）／' + K('posRight') + '（右へ）、Ctrl+Shift+M', true); });
/* 位置（見た目）：行頭の桁をレベルと独立に動かす。見出し・箇条書きは位置が固定され、レベルを変えても動かない（K で自動に戻す） */
cmd('posRight', '位置を右へ 1 桁（レベルは変えない）', '配置', '', () => { if (!ed.posShift(1)) msg('この行は位置を動かせません（表・図・目次・中央／右揃えの行）', true); }, '字下げ インデント 位置');
cmd('posLeft', '位置を左へ 1 桁（レベルは変えない）', '配置', 'Ctrl+Shift+M', () => { if (!ed.posShift(-1)) msg('この行は位置を動かせません（表・図・目次・中央／右揃えの行）', true); }, '字下げ インデント 位置');
cmd('posAuto', '位置を自動に戻す（見出し・箇条書きはレベルから決まる桁、本文は左端）', '配置', '', () => { if (!ed.posReset()) msg('位置は自動のままです'); }, '字下げ解除 インデント 位置');
cmd('restart', '番号を 1 から数え直す', '構造', '', () => ed.toggleAttr('restart', true));
cmd('pageBreak', 'ここから改頁（この行・節から新しい頁。もう一度で外す）', '構造', 'Ctrl+Enter', () => ed.toggleAttr('breakBefore', true));
cmd('keepLine', '段落をページで分割しない（繰り越す）', '配置', '', () => ed.toggleAttr('keep', 'line'));
/* 次と同頁：点灯は実際に効いているか。題（表題・記号見出し・題のレベル）は既定で効いていて、押すと「送らない」になる（K-12） */
const keepNextOn = a => a.keep === 'next' || (a.keep !== 'free' && ed.isTitleLike(a));
cmd('keepNext', '次の段落と同じページに置く（題の行では「送らない」の切替）', '配置', '', () => { const a = ed.line().attrs; if (ed.isTitleLike(a)) ed.setAttrs({ keep: a.keep === 'free' ? null : 'free' }); else ed.toggleAttr('keep', 'next'); msg(keepNextOn(ed.line().attrs) ? '次と同頁：効いています' : '次と同頁：外しました'); });
cmd('outlineUp', '節を上へ移動', 'アウトライン', 'Alt+↑', () => ed.moveSection(ed.caret.line, -1));
cmd('outlineDown', '節を下へ移動', 'アウトライン', 'Alt+↓', () => ed.moveSection(ed.caret.line, 1));
cmd('outlinePanel', 'ツリー（文書の構造を左から右へ広げて見る・並べ替える）切替', '表示', 'Ctrl+Shift+O', () => toggleTree(), 'アウトライン マインドマップ 構成 ツリー');
const tvSel = () => (st.mode === 'tree' ? treeSelected().filter(n => !n.root) : []);
cmd('tv:after', 'ツリー：弟を足す（同じ種類・レベル）', 'ツリー', 'Enter', () => { if (st.mode === 'tree') treeAdd('after'); });
cmd('tv:before', 'ツリー：兄を足す', 'ツリー', 'Shift+Enter', () => { if (st.mode === 'tree') treeAdd('before'); });
cmd('tv:child', 'ツリー：子を足す（節に寄せると出る ＋ でも）', 'ツリー', 'Tab', () => { if (st.mode === 'tree') treeAdd('child'); });
cmd('tv:del', 'ツリー：選んだ節を消す（子と本文ごと）', 'ツリー', 'Delete', () => { if (st.mode === 'tree') treeDelete(); });
cmd('tv:up', 'ツリー：兄弟の中で上へ（子と本文ごと。文は段落の中で）', 'ツリー', 'Alt+↑ / Ctrl+↑', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeMoveSent(treeNodeSel(), -1); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.shift(ed, st.tree.view.tr, n, -1)); });
cmd('tv:down', 'ツリー：兄弟の中で下へ', 'ツリー', 'Alt+↓ / Ctrl+↓', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeMoveSent(treeNodeSel(), 1); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.shift(ed, st.tree.view.tr, n, 1)); });
cmd('tv:out', 'ツリー：浅く（親の弟に。文は独立した段落に）', 'ツリー', 'Alt+← / Shift+Tab', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeSentToKind(treeNodeSel(), 'body'); return; } if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'body' && treeNodeSel().obj && treeNodeSel().obj.segs.length === 1) { treeParaUp(treeNodeSel()); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.promote(ed, st.tree.view.tr, n)); });
cmd('tv:in', 'ツリー：深く（兄の末の子に）', 'ツリー', 'Alt+→ / Ctrl+→', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeSentToKind(treeNodeSel(), 'list'); return; } if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'body' && treeNodeSel().obj && treeNodeSel().obj.segs.length === 1) { treeParaDown(treeNodeSel()); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.demote(ed, st.tree.view.tr, n)); });
cmd('tv:edit', 'ツリー：節の文字・図表の題を直す（ダブルクリックでも）', 'ツリー', 'Ctrl+Enter', () => { if (st.mode === 'tree') openTreeEdit(false); });
cmd('tv:fold', 'ツリー：畳む・開く', 'ツリー', 'Space', () => { if (st.mode !== 'tree') return; const n = treeNodeSel(); if (!n || !n.children.length) return; const k = treeKey(n); if (st.tree.folds.has(k)) st.tree.folds.delete(k); else st.tree.folds.add(k); render(); drawSub(); });
cmd('tv:paper', 'ツリーから紙面へ（選んだ節の頭に）', 'ツリー', 'Esc', () => exitTree());
for (const [k, l] of [['para', '段落を文ごとの段落にばらす'], ['list', '段落を箇条書きにばらす（1 文 1 項目）'], ['tree', '段落を親子にばらす（最初の文が親、残りが子の項目）'], ['merge', '選んだ節（または節と子）を 1 つの段落にまとめる']]) cmd('tvr:' + k, 'ツリー：' + l, 'ツリー', '', () => { if (st.mode !== 'tree') return; treeRegroup(k); }, 'ばらす まとめる 文 段落 箇条書き 親子');
cmd('tv:break', 'ツリー：この節から改頁（もう一度で外す）', 'ツリー', '', () => { if (st.mode === 'tree') treeToggleBreak(); }, '改頁 改ページ 頁 境目');
cmd('tvf:open', 'ツリー：図表をすべて表示（中身を見せる）', 'ツリー', '', () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) enterTree(); const tr = treeBuild(); for (const n of tr.figs) st.tree.show.add(treeShowKey(n)); for (const n of tr.nodes) if (treeShowable(n)) st.tree.show.add(treeShowKey(n)); st.tree.showAll = true; render(); drawSub(); treeScrollToSel(); }, '図表 表示 開く 一括');
cmd('tvf:close', 'ツリー：図表をすべて閉じる（名前だけ）', 'ツリー', '', () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) return; st.tree.show.clear(); st.tree.showAll = false; render(); drawSub(); treeScrollToSel(); }, '図表 閉じる 一括');
for (const [d, l] of [[1, '1 段（いちばん上の見出し）まで'], [2, '2 段まで'], [3, '3 段まで'], [4, '4 段まで'], [9, 'すべての見出し・項目'], [0, '本文・表・囲みまで'], [-1, '文まで（段落を「。」ごとの文に分けて、並べ替え・直す）']]) cmd('tvd:' + d, 'ツリーの深さ：' + l + 'を一括で表示（畳みも解く）', 'ツリー', String(d), () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) enterTree(); treeSetDepth(d); }, 'ツリー 深さ レベル 階層 畳む 開く');
for (const [k, l] of [['num', '番号見出し'], ['sym', '記号見出し'], ['nlist', '番号箇条書き'], ['list', '記号箇条書き'], ['body', '本文'], ['title', '表題']]) cmd('tvk:' + k, 'ツリー：選んだ節を' + l + 'に', 'ツリー', '', () => treeSetKind(k));
/* 種類を変える：表題・番号見出し（num）・記号見出し（sym）・番号箇条書き（nlist）・記号箇条書き（list）・本文 */
function treeSetKind(kind0) { if (st.mode !== 'tree') return; const s0 = treeNodeSel(); if (s0 && s0.kind === 'sent') { treeSentToKind(s0, kind0); return; } /* 文の種類を変える：段落を割って取り出す */ const list = tvSel().filter(n => n.kind !== 'block' && n.kind !== 'fig'); if (!list.length) return; const key = st.tree.sel; const kind = kind0 === 'nlist' ? 'list' : kind0;
  ed.mutate('', () => { for (const n of list.sort((p, q) => q.line - p.line)) { const i = ed.doc.lines.indexOf(n.obj); if (i < 0) continue; const tr = FZ.tree.build(ed.doc, { body: true }); const nn = tr.byObj.get(n.obj); const lvl = kind === 'list' || kind === 'num' || kind === 'sym' ? (n.kind === kind ? n.level : nn && nn.parent && nn.parent.kind === kind ? Math.min(7, nn.parent.level + 1) : 0) : 0; FZ.tree.retype(ed, i, nn ? nn.end : i, { kind, level: lvl });
    const a = ed.doc.lines[i].attrs; if (kind === 'list' && a.list) { if (kind0 === 'nlist') a.list = { ...a.list, kind: 'num' }; else if (a.list.kind === 'num') { const l2 = { ...a.list }; delete l2.kind; a.list = l2; } } } });
  st.tree.sel = key; treeRefresh(); }
/* 節の種類の名前（箱の右端に出す）と、帯の「種類」の値 */
function treeKindOf(n) { if (!n || n.root) return ''; if (n.kind === 'list') return n.obj && n.obj.attrs.list && n.obj.attrs.list.kind === 'num' ? 'nlist' : 'list'; return n.kind; }
function treeKindLabel(n) { const k = treeKindOf(n); const lv = (n.level | 0) + 1; if (k === 'block') return /^［([^］]+)］/.test(n.text) ? n.text.match(/^［([^］]+)］/)[1] : '塊'; const lk = n.obj && n.obj.attrs.list && n.obj.attrs.list.kind;
  return { title: '表題', num: '番号見出し' + lv, sym: '記号見出し' + lv, nlist: '番号箇条書き' + lv, list: (lk === 'arrow' ? '矢印' : lk === 'todo' || lk === 'done' ? '課題' : '記号箇条書き') + lv, body: '本文' }[k] || ''; }
/* 番号・記号の形（体系）：選んだ節の種類とレベルの段。同じ種類・同じ段のものすべてに効く */
const TREE_SCH = { num: ['scheme', null, '番号見出し'], sym: ['symScheme', 'DEFAULT_SYM', '記号見出し'], nlist: ['listScheme', 'DEFAULT_LIST', '番号箇条書き'], list: ['bulletScheme', 'DEFAULT_BULLET', '記号箇条書き'] };
function treeMarkerChoices(k) { if (k === 'num' || k === 'nlist') return FZ.NUMBER_KEYS.slice(); const set = [...(k === 'list' ? FZ.DEFAULT_BULLET : FZ.DEFAULT_SYM), ...FZ.SYMBOL_PRESETS]; return [...new Set(set), FZ.NONE_TOKEN]; }
function treeMarkerNow(n) { const k = treeKindOf(n); const d = TREE_SCH[k]; if (!d) return null; const arr = FZ.normalizeScheme(ed.doc.format[d[0]], d[1] ? FZ[d[1]] : FZ.DEFAULT_SCHEME); return { k, lv: clamp(n.level | 0, 0, 7), tok: arr[clamp(n.level | 0, 0, 7)], arr, field: d[0], name: d[2] }; }
function treeSetMarker(tok) { const n = treeNodeSel(); const m = n && treeMarkerNow(n); if (!m || !tok || tok === m.tok) return; const key = st.tree.sel;
  ed.mutate('', () => { const arr = m.arr.slice(); arr[m.lv] = tok; ed.doc.format = { ...ed.doc.format, [m.field]: FZ.normalizeScheme(arr, m.field === 'scheme' ? FZ.DEFAULT_SCHEME : FZ[TREE_SCH[m.k][1]]) }; });
  st.tree.sel = key; treeRefresh(); msg(`${m.name}${m.lv + 1} の形を「${tok}」にしました（同じ段のものすべて。Ctrl+Z で戻す。全体は ${K('scheme')}）`); }
cmd('zoomIn', '拡大', '表示', 'Ctrl++', () => zoomStep(1));
cmd('zoomOut', '縮小', '表示', 'Ctrl+-', () => zoomStep(-1));
cmd('zoomFit', '幅に合わせる（ツリーでは等倍）', '表示', 'Ctrl+0', () => { if (st.mode === 'tree') { treeZoom(0); return; } st.zoom = 'width'; render(); });
cmd('zoomPage', '高さに合わせる（ページ全体）', '表示', 'Ctrl+Shift+0', () => { if (st.mode === 'tree') { treeZoom(0); return; } st.zoom = 'page'; render(); });
cmd('zoomPct', '表示倍率（％）…', '表示', '', () => openForm('zoom'), 'ズーム');
cmd('grid', '補助グリッド 表示切替', '表示', 'Ctrl+Shift+G', () => { st.grid = !st.grid; render(); });
cmd('landscape', '用紙の縦横を入れ替える', '書式', '', () => { ed.mutate('', () => { const f = ed.doc.format; [f.widthMm, f.heightMm] = [f.heightMm, f.widthMm]; f.landscape = f.widthMm > f.heightMm; }); });
cmd('fontMincho', '本文を明朝で組む', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'mincho'; }));
cmd('fontGothic', '本文をゴシックで組む', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'gothic'; }));
cmd('fontSystem', '本文書体：システム書体', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'system'; }));
cmd('exitMode', '本文へ戻る', '罫線', 'Esc', exitMode);
cmd('erase', '罫線を消す（矢印で消去）切替', '罫線', '（罫線モード）F5 / Backspace', () => { if (st.mode === 'text') enterRuleMode(); st.sub = st.sub === 'erase' ? null : 'erase'; drawSub(); drawFkeys(); status(); });
for (const [k, l] of [['thin', '細線'], ['thick', '太線'], ['double', '二重線'], ['dotted', '点線'], ['arrow', '矢印（引いた方向に矢じり。折れても最後だけ）']]) cmd('k:' + k, '線種：' + l, '罫線', '（罫線モード）F' + (['thin', 'thick', 'double', 'dotted'].indexOf(k) + 1 || ''), () => { st.ruleKind = k; if (st.mode === 'text') enterRuleMode(); drawFkeys(); drawSub(); status(); });
/* 網掛けモードの文様：F1〜F5 は従来の 5 つ、ほかは帯の見本の 1 文字（SWATCH_KEY） */
const SWATCH_KEY = { light: '1', gray: '2', mid: '3', deep: '4', dark: '5', hatch: '6', hatch2: '7', horz: '8', vert: '9', grid: '0', check: 'Q', dots: 'W', wide: 'E' };
const FILL_FK = { gray: 'F1', dark: 'F2', hatch: 'F3', dots: 'F4', none: 'F5' };
for (const sh of FZ.SHADES.filter(x => x.id !== 'text').concat([{ id: 'none', label: '網掛けを消す' }])) cmd('s:' + sh.id, '網掛け：' + sh.label, '罫線', '（網掛け）' + [FILL_FK[sh.id], SWATCH_KEY[sh.id]].filter(Boolean).join(' / '), () => { st.shade = sh.id; if (st.mode !== 'fill') enterFillMode(); drawFkeys(); drawSub(); status(); }, '文様 パターン');
/* 見本の小さな絵（帯・欄で文様を選ぶとき） */
function swatch(id, size = 14) { const sh = FZ.SHADE_BY[id]; if (!sh) return `<svg class="sw" width="${size}" height="${size}" viewBox="0 0 14 14"><rect x=".5" y=".5" width="13" height="13" fill="#fff" stroke="#000"/><path d="M3 3l8 8M11 3l-8 8" stroke="#000"/></svg>`;
  const pid = 'swp_' + id; return `<svg class="sw" width="${size}" height="${size}" viewBox="0 0 14 14"><defs>${FZ.patternDefFor(sh, pid)}</defs><rect x=".5" y=".5" width="13" height="13" fill="url(#${pid})" stroke="#000"/></svg>`; }
function run(id) { const c = CMDS.find(c => c.id === id); if (!c) return; if (st.mode !== 'tree') { c.fn(); return; } treeBeforeCmd(c); if (st.mode !== 'tree') { c.fn(); return; } st.treeCmd = true; try { c.fn(); } finally { st.treeCmd = false; } }
/* ツリーでコマンドを使う：対象は選んだ節の行（カーソルをその行に。文字のコマンドは行の文字全体を選ぶ）。紙面でしかできないものは、その節の所で紙面に移ってから */
const TREE_OWN = /^(tv|tvd|tvk|tvf|tvs|sx)[:]|^(moveTo|checkStruct|sentOpt|park|zoom|outlinePanel|viewGroup|fileGroup|editGroup|marks|structGroup|exportTree|selSent|aiCopy|aiReturn|panels|lineGroup|insertGroup|decorGroup|fmtGroup|help|palette|undo|redo|save|saveAs|open|new|kindDoc|kindSlide|grid)/;
const TREE_PAPER = new Set(['fillMode', 'tableMenu', 'figInsert', 'replace', 'findNext', 'findPrev', 'link', 'headGroup', 'tableGroup', 'teditGroup', 'print', 'speech']);
function treeBeforeCmd(c) {
  if (TREE_OWN.test(c.id)) return; const n = treeNodeSel(); const i = n && n.obj ? ed.doc.lines.indexOf(n.obj) : -1;
  if (i >= 0) { const ln = ed.doc.lines[i]; const ls = ln.segs.length - 1; ed.caret = { line: i, seg: ls, off: ln.segs[ls].text.length, vcol: null, vrow: 0 }; ed.anchor = c.group === '文字' && (ln.segs.length > 1 || ln.segs[0].text) ? { line: i, seg: 0, off: 0 } : null; }
  if (TREE_PAPER.has(c.id) || c.group === '罫線') { exitTree(); if (i >= 0) ed.setCaret({ line: i, seg: 0, off: 0 }); msg('紙面で続けます（Ctrl+Shift+O でツリーに戻る）', false, 5000); } }
function baseTitle() { return (ed.doc.title || (st.file && st.file.name.replace(/\.[^.]+$/, '')) || '文書').replace(/[\\/:*?"<>|]/g, '_'); }
/* ---------- メニュー：F キー（キートップ）と子メニュー（ピクトグラムのタイル） ----------
 * 分類の原則：文字（字の見た目）→ 段落（行の種類）→ 配置（行の置き場所）→ 挿入（ものを入れる）→ 罫線・飾り（線と飾り）→ 書式（文書全体の決まり）→ 表示（画面だけ）。
 * F キー 1 つ＝グループ 1 つ。押すとそのグループのタイルが右に並び「構え」になり、タイルの 1 文字で実行する。
 * 印刷・保存はファイルの中（Ctrl+P／Ctrl+S。旧来の F12 も保存として効く）。キーの一覧（使い方・コマンド一覧）はこの表から作る */
const FK = {
  text: [['F1', '取説', 'help'], ['F2', 'ﾌｧｲﾙ', 'fileGroup'], ['F3', '編集', 'editGroup'], ['F4', '構造', 'structGroup'], ['F5', '文字', 'marks'], ['F6', '配置', 'lineGroup'], ['F7', '挿入', 'insertGroup'], ['F8', '表', 'tableMenu'], ['F9', '書式', 'fmtGroup'], ['F10', '表示', 'viewGroup']],
  rule: [['F1', '細', 'k:thin'], ['F2', '太', 'k:thick'], ['F3', '二重', 'k:double'], ['F4', '点線', 'k:dotted'], ['F5', '消去', 'erase'], ['F6', '表…', 'table'], ['F7', '囲み', 'rect'], ['F8', '網掛け', 'fillMode'], ['F9', '', ''], ['F10', '一覧', 'palette'], ['Esc', '本文へ', 'exitMode']],
  fig: [['F1', '箱', 'fg:add'], ['F2', '文字', 'fg:text'], ['F3', '矢印', 'fg:connect'], ['F4', '削除', 'fg:delete'], ['F5', '複製', 'fg:dup'], ['F6', '箱の\n設定…', 'fg:props'], ['F7', 'レーン…', 'fg:lanes'], ['F8', '高さ＋', 'fg:taller'], ['F9', '高さ−', 'fg:shorter'], ['F10', '一覧', 'palette'], ['Esc', '本文へ', 'exitMode']],
  tree: [['F1', '取説', 'help'], ['F2', '文字', 'tv:edit'], ['F3', '弟', 'tv:after'], ['F4', '子', 'tv:child'], ['F5', '上へ', 'tv:up'], ['F6', '下へ', 'tv:down'], ['F7', '浅く', 'tv:out'], ['F8', '深く', 'tv:in'], ['F9', '畳む', 'tv:fold'], ['F10', '一覧', 'palette'], ['Esc', '紙面へ', 'tv:paper']],
  fill: [['F1', '薄', 's:gray'], ['F2', '濃', 's:dark'], ['F3', '斜線', 's:hatch'], ['F4', '点', 's:dots'], ['F5', '消す', 's:none'], ['F6', '', ''], ['F7', '', ''], ['F8', '', ''], ['F9', '', ''], ['F10', '一覧', 'palette'], ['Esc', '本文へ', 'exitMode']],
};
const FK_HIDDEN = { F12: 'save' }; // 表には出さない（保存の本線は Ctrl+S）
const GROUP_OF = { fileGroup: 'file', editGroup: 'edit', structGroup: 'struct', marks: 'marks', lineGroup: 'line', insertGroup: 'insert', tableMenu: 'tedit', fmtGroup: 'fmt', viewGroup: 'view' };
const SUBGROUP_OF = { headGroup: 'head', tableGroup: 'table', teditGroup: 'tedit' };
/* フォームを開いたら、そのフォームの属するグループを子メニューに出す（閉じた後に関連の項目が並ぶ） */
const FORM_GROUP = { headFill: 'table', shadeType: 'marks', scale: 'marks', count: 'edit', format: 'fmt', scheme: 'fmt', slide: 'fmt', find: 'edit', replace: 'edit', table: 'insert', toc: 'insert', fig: 'insert', chart: 'insert', figtree: 'insert', tfind: 'edit', moveTo: 'struct', scheck: 'edit', sentopt: 'fmt', secref: 'insert', skeleton: 'insert', parked: 'struct', figref: 'insert', link: 'marks', speech: 'line', marker: 'fmt', newdoc: 'file', tplname: 'file', aiback: 'file', panels: 'line', zoom: 'view' };
function drawFkeys() {
  const mode = st.mode === 'fill' ? 'fill' : st.mode === 'rule' ? 'rule' : st.mode === 'fig' ? 'fig' : 'text'; const map = FK[mode]; /* ツリーも紙面と同じ F キー */
  const onMap = { ['k:' + st.ruleKind]: st.mode === 'rule', ['s:' + st.shade]: st.mode === 'fill', erase: st.sub === 'erase', rect: st.sub === 'rect' && st.mode === 'rule', table: st.form === 'table' && mode === 'rule', help: st.side === 'help', palette: st.side === 'palette' && mode !== 'text' };
  if (mode === 'text') { const g = GROUPS[st.group]; const sg = g && g.parent ? g.parent : st.group; for (const [id, gn] of Object.entries(GROUP_OF)) if (gn === sg) onMap[id] = true; }
  $('fkeys').innerHTML = map.map(([k, l, id]) => { const on = !!onMap[id]; const armed = on && st.armed && !!GROUP_OF[id]; const c = cmdById(id);
    const pane = id === 'help' || id === 'palette'; // 右の欄の開閉は点灯（黒地）ではなく下の太線で示す。黒地は今のグループだけ
    return `<div class="fk${on ? (pane ? ' pon' : ' on') : ''}${armed ? ' armed' : ''}${!id ? ' dim' : ''}${k === 'Esc' ? ' esc' : ''}" data-cmd="${id}"${c ? ` title="${esc(c.label)}"` : ''}><span class="k">${k}</span><span class="l">${l ? esc(l).replace('\n', '<br>') : '&nbsp;'}</span></div>`; }).join('');
}
$('fkeys').addEventListener('pointerdown', e => { const d = e.target.closest('.fk'); if (!d || !d.dataset.cmd) return; e.preventDefault(); run(d.dataset.cmd); });
/* ---------- 子メニュー（グループ／フォーム／ヒント） ---------- */
const A = () => ed.line().attrs, L = () => ed.line().attrs.list;
function isOn(bit) { if (bit === M.BOLD && ed.isTitleLike(ed.line().attrs)) return !ed.line().attrs.thin; const s = ed.sel(); return s ? ed.allMarked(s, bit) : !!(ed.typing & bit); } // 題の行の太字は行の見た目（細字でなければ点灯）
/* 項目：{ cl: 塊の名前 } で塊を切る。key＝構えのときの 1 文字、short＝タイルの名前（無ければ label）、icon＝ピクトグラム（無ければ cmd の名前） */
/* 排他の選択はプルダウン：状態を選んで置いておくもの（倍率・ツリーの深さ・図表・形・書体・向き）。範囲にかける操作（揃え・種類・網）はボタンのまま。
   メニューの項目 { key, msel: 名前 }。構えのキーは次の値へ送る。cmds＝道筋（F キー → 1 文字）を載せるコマンド */
const pct = v => Math.round(v * 100) + '%';
const MSEL = {
  zoom: { label: '倍率', cmds: ['zoomFit', 'zoomPage', 'zoomPct'], tip: () => st.mode === 'tree' ? 'ツリーの倍率（Ctrl+ホイール・＋／−でも）' : '紙面の倍率（Ctrl+ホイール・Ctrl+＋／−でも）',
    opts: () => { if (st.mode === 'tree') return TREE_SCALES.map(v => [v, v === 1 ? '等倍' : pct(v)]); const o = [['width', '幅に合わせる'], ['page', 'ページ全体'], ...[0.5, 0.75, 1, 1.25, 1.5, 2].map(v => [v, pct(v)])]; if (typeof st.zoom === 'number' && !o.some(x => x[0] === st.zoom)) o.push([st.zoom, pct(st.zoom)]); o.push(['pct', '指定…', 1]); return o; },
    val: () => st.mode === 'tree' ? st.tree.scale : st.zoom,
    set: v => { if (st.mode === 'tree') { st.tree.scale = +v; try { localStorage.setItem('fz.treeScale', String(st.tree.scale)); } catch (e) { /* 覚えられなくても動く */ } render(); return; } if (v === 'pct') { run('zoomPct'); return; } st.zoom = v === 'width' || v === 'page' ? v : +v; render(); } },
  depth: { label: '深さ', cmds: Object.keys({ 'tvd:1': 1, 'tvd:2': 1, 'tvd:3': 1, 'tvd:9': 1, 'tvd:0': 1, 'tvd:-1': 1 }), tip: () => 'ツリーの深さ（文書全体を一度に開く・畳む）：1〜3 段・全段（すべての見出し・項目）・本文まで・文まで', bare: 1, opts: () => [[1, '1段'], [2, '2段'], [3, '3段'], [9, '全段'], [0, '本文'], [-1, '文']], val: () => st.tree.depth, set: v => run('tvd:' + v) },
  figs: { label: '図表', cmds: ['tvf:open', 'tvf:close'], bare: 1, tip: () => 'ツリーの図表：図題＝題だけ／図中身＝中身も見せる（1 つずつは図表の節の「表示」で）', opts: () => { const o = [['close', '図題'], ['open', '図中身']]; if (!st.tree.showAll && st.tree.show.size) o.unshift(['', '図一部', 1]); return o; }, val: () => st.tree.showAll ? 'open' : st.tree.show.size ? '' : 'close', set: v => { if (v) run('tvf:' + v); } },
  shape: { label: '形', cmds: ['tvs:i', 'tvs:h', 'tvs:v'], bare: 1, tip: () => 'ツリーの形：字下げ・横に広げる・縦に広げる', opts: () => [['i', '字下げ'], ['h', '横広げ'], ['v', '縦広げ']], val: () => st.tree.dir, set: v => run('tvs:' + v) },
  font: { label: '書体', cmds: ['fontMincho', 'fontGothic'], tip: () => '本文の書体（文書全体）', opts: () => [['mincho', '明朝'], ['gothic', 'ゴシック']], val: () => ed.doc.format.font === 'gothic' ? 'gothic' : 'mincho', set: v => run(v === 'gothic' ? 'fontGothic' : 'fontMincho') },
  orient: { label: '向き', cmds: ['landscape'], tip: () => '用紙の向き（縦長・横長）', opts: () => [['p', '縦長'], ['l', '横長']], val: () => ed.doc.format.landscape ? 'l' : 'p', set: v => { if ((v === 'l') !== !!ed.doc.format.landscape) run('landscape'); } } };
function mselHtml(it, noKey) { const M = MSEL[it.msel]; const o = M.opts(); const cur = String(M.val()); const kk = !noKey && it.key ? String(it.key) : '';
  const list = o.some(x => String(x[0]) === cur) ? o : [[cur, '—'], ...o];
  return `<label class="ms" title="${esc(M.tip() + (kk ? `　［${kk}］で次へ` : ''))}">${M.bare ? '' : `<span class="ml">${esc(M.label)}</span>`}<select id="ms_${it.msel}" data-msel="${it.msel}">${list.map(([v, l]) => `<option value="${esc(String(v))}"${String(v) === cur ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>${kk ? `<span class="k${[...kk].length > 1 ? ' w' : ''}"><b>${esc(kk)}</b></span>` : ''}</label>`; }
function clusterHtml(c, noKey) { const t = c.items.filter(i => !i.msel), m = c.items.filter(i => i.msel); const lab = c.label ? `<span class="cll" title="${esc(c.label)}">${vlabel(c.label)}</span>` : '';
  if (t.length && m.length && t.length % 2) return `<div class="cl">${lab}<div class="cg mix">${c.items.map(i => i.msel ? mselHtml(i, noKey) : tile(i)).join('')}</div></div>`; // タイルが奇数なら空いた段にプルダウンを詰める
  return `<div class="cl">${lab}${t.length ? `<div class="cg">${t.map(tile).join('')}</div>` : ''}${m.length ? `<div class="sg">${m.map(i => mselHtml(i, noKey)).join('')}</div>` : ''}</div>`; }
/* 構えのキー・クリックで項目を実行：プルダウンは次の値へ（「指定…」「一部だけ」は飛ばす） */
function runItem(it) { if (!it.msel) { run(it.cmd); return; } const M = MSEL[it.msel]; const o = M.opts().filter(x => !x[2]); const i = o.findIndex(x => String(x[0]) === String(M.val())); const nx = o[(i + 1) % o.length]; M.set(String(nx[0])); msg(M.label + '：' + nx[1]); }
const GROUPS = {
  file: { title: 'ファイル', items: [{ cl: '文書' }, { key: 'N', label: '新規…', short: '新規', cmd: 'new', icon: 'new' }, { key: 'D', label: '新しい資料', short: '資料', cmd: 'newSlide', icon: 'slideNew' }, { key: 'O', label: '開く…', short: '開く', cmd: 'open', icon: 'open' }, { key: 'S', label: '保存', cmd: 'save', icon: 'save' }, { key: 'A', label: '名前を付けて保存…', short: '別名保存', cmd: 'saveAs', icon: 'saveAs' }, { key: 'P', label: '印刷・PDF', short: '印刷', cmd: 'print', icon: 'print' },
    { cl: '人に渡す' }, { key: '1', label: 'Word', cmd: 'exportDocx', icon: 'word' }, { key: '2', label: 'PowerPoint', short: 'PPT', cmd: 'exportPptx', icon: 'pptx' }, { key: '4', label: 'テキスト', short: 'TXT', cmd: 'exportTxt', icon: 'txt' },
    { cl: 'ツリー図' }, { key: '5', label: 'ツリーの見た目で PowerPoint（箱と線の図形）', short: 'ﾂﾘｰPPT', cmd: 'exportTreePptx', icon: 'pptx' }, { key: '6', label: 'ツリーの見た目で印刷・PDF', short: 'ﾂﾘｰPDF', cmd: 'exportTreePdf', icon: 'print' }, { key: '7', label: 'ツリーの見た目で Word（頁ごとの図）', short: 'ﾂﾘｰWord', cmd: 'exportTreeDocx', icon: 'word' },
    { cl: 'AI' }, { key: 'C', label: 'この節を Markdown で写す（貼り付け用）', short: '節を写す', cmd: 'aiCopySec', icon: 'aiSec' }, { key: 'V', label: '文書全体を Markdown で写す（貼り付け用）', short: '全体写す', cmd: 'aiCopyDoc', icon: 'aiDoc' }, { key: 'R', label: 'AI から戻す…（直してもらった Markdown を貼って、違う所を 1 つずつ取り込む）', short: '差分取込', cmd: 'aiReturn', icon: 'aiBack', on: () => st.form === 'aiback' }, { key: '3', label: 'Markdown ファイルに書き出す', short: 'MD', cmd: 'exportMd', icon: 'md' },
    { cl: 'ほか' }, { key: 'G', label: 'Word を取り込む…（.docx の見出し・箇条書き・表から構造を起こす）', short: 'Word取込', cmd: 'importDocx', icon: 'word' }, { key: 'W', label: '新しい窓', short: '新窓', cmd: 'newWindow', icon: 'newWin' }, { key: 'H', label: '版の履歴…', short: '履歴', cmd: 'history', icon: 'history', on: () => st.side === 'hist' }, { key: 'B', label: 'ここから先を別の文書に…', short: '分割', cmd: 'splitDoc', icon: 'split' }, { key: 'T', label: 'テンプレート保存…', short: '雛形', cmd: 'tplSave', icon: 'tpl' } ] },
  edit: { title: '編集', items: [{ cl: '戻す' }, { key: 'Z', label: '元に戻す', short: '戻す', cmd: 'undo', icon: 'undo' }, { key: 'Y', label: 'やり直す', short: 'やり直し', cmd: 'redo', icon: 'redo' },
    { cl: '探す' }, { key: 'F', label: '検索・置換…', short: '検索', cmd: 'find', icon: 'find', on: () => st.form === 'find' || st.form === 'replace' }, { key: 'A', label: 'すべて選択', short: '全選択', cmd: 'selectAll', icon: 'selAll' }, { key: 'Q', label: '文を選ぶ（Ctrl+クリックでも）', short: '文選択', cmd: 'selSent', icon: 'sentSel' },
    { cl: '整える' }, { key: 'V', label: '貼り直し（MD 整形・Excel は図に）', short: '貼り直し', cmd: 'pasteMd', icon: 'pasteMd' }, { key: 'C', label: '字数を数える…', short: '字数', cmd: 'count', icon: 'count', on: () => st.form === 'count' }, { key: 'K', label: '構造の点検…（子が 1 つ・中身なし・長い文・文末の不統一・段の飛び）', short: '点検', cmd: 'checkStruct', icon: 'check', on: () => st.form === 'scheck' },
    { cl: '救済' }, { key: 'R', label: 'ローマ字をかなに', short: 'かな化', cmd: 'romaji', icon: 'romaji' }, { key: 'B', label: '** を太字に', short: '**太字', cmd: 'mdStars', icon: 'stars' }, { key: 'J', label: '和文の番号を起こす（「1.」「（1）」などを見出し・箇条書きに）', short: '番号化', cmd: 'jaLift', icon: 'jaLift', on: () => st.jaLift },
    { cl: '保留' }, { key: 'P', label: '保留へ送る（文書の外へ退避。書き出しに出ない）', short: '保留', cmd: 'park', icon: 'park' }, { key: 'O', label: '保留の島…（退避した節・文を戻す）', short: '保留島', cmd: 'parkList', icon: 'parkList', on: () => st.form === 'parked' }] },
  struct: { title: '構造', items: [{ cl: '種類' }, { key: '1', label: '本文', cmd: 'styleBody', icon: 'body', on: () => !A().style && !A().list }, { key: '2', label: '表題', cmd: 'styleTitle', icon: 'title', on: () => A().style === 'title' }, { key: '3', label: '番号見出し', short: '番号見出', cmd: 'styleNum', icon: 'numHead', on: () => A().style === 'num' }, { key: '4', label: '記号見出し', short: '記号見出', cmd: 'styleSym', icon: 'symHead', on: () => A().style === 'sym' }, { key: '5', label: '箇条書き', short: '箇条', cmd: 'item', icon: 'bullet', on: () => !!L() && !['num', 'arrow', 'todo', 'done'].includes(L().kind) }, { key: 'N', label: '番号付き箇条書き', short: '番号箇条', cmd: 'numItem', icon: 'numItem', on: () => L() && L().kind === 'num' }, { key: 'E', label: '結論', cmd: 'arrow', icon: 'arrow', on: () => L() && L().kind === 'arrow' }, { key: 'R', label: '課題', cmd: 'todo', icon: 'todo', on: () => L() && (L().kind === 'todo' || L().kind === 'done') }, { key: 'D', label: '完了', cmd: 'done', icon: 'done', on: () => L() && L().kind === 'done' }, { key: 'T', label: '子項目', short: '子項目', cmd: 'childItem', icon: 'child' },
    { cl: '段' }, { key: 'S', label: '上げる（Alt+←。文→段落→見出し、見出し・箇条書きは浅く）', short: '上げる', cmd: 'sx:out', icon: 'sxOut' }, { key: 'A', label: '下げる（Alt+→。段落→前の段落の文、文→箇条書き、見出し・箇条書きは深く）', short: '下げる', cmd: 'sx:in', icon: 'sxIn' }, { key: 'I', label: '上へ（Alt+↑。子と本文ごと。文は段落の中で）', short: '上へ', cmd: 'sx:up', icon: 'tUp' }, { key: 'K', label: '下へ（Alt+↓）', short: '下へ', cmd: 'sx:down', icon: 'tDown' }, { key: 'J', label: '番号再開', short: '再開', cmd: 'restart', icon: 'restart', on: () => !!A().restart }, { key: 'V', label: '送り先を選んで移す…（Ctrl+M）', short: '移す', cmd: 'moveTo', icon: 'moveTo', on: () => st.form === 'moveTo' },
    { cl: '組替' }, { key: 'G', label: '段落を文ごとの段落にばらす', short: '段落化', cmd: 'sx:re:para', icon: 'reSplit' }, { key: 'L', label: '段落を箇条書きにばらす（1 文 1 項目）', short: '箇条化', cmd: 'sx:re:list', icon: 'reList' }, { key: 'H', label: '段落を親子にばらす（最初の文が親）', short: '親子化', cmd: 'sx:re:tree', icon: 'reTree' }, { key: 'M', label: 'まとめる（選んだ行・節と子を 1 つの段落に）', short: 'まとめ', cmd: 'sx:re:merge', icon: 'reMerge' },
    { cl: 'ツリー' }, { key: 'W', label: 'ツリー（紙面と行き来。Ctrl+Shift+O）', short: 'ﾂﾘｰ', cmd: 'outlinePanel', icon: 'treeView', on: () => st.mode === 'tree' }, { key: 'F', msel: 'depth' }, { key: 'Z', msel: 'figs' }, { key: 'X', msel: 'shape' }] }, // 表示（F10）のツリーの項目もここに：構造を直しながら深さ・図表・形を切り替える
  marks: { title: '文字', items: [{ cl: '修飾' }, { key: '1', label: '太字', cmd: 'bold', on: () => isOn(M.BOLD) }, { key: '2', label: '下線', cmd: 'under', on: () => isOn(M.UNDER) }, { key: '3', label: '傍点', cmd: 'dot', on: () => isOn(M.DOT) }, { key: '4', label: '網掛け', short: '網掛', cmd: 'shade', on: () => isOn(M.SHADE) }, { key: '5', label: '白抜き', short: '白抜', cmd: 'outline', on: () => isOn(M.OUTLINE) }, { key: '6', label: '取消線', short: '取消', cmd: 'strike', on: () => isOn(M.STRIKE) },
    { cl: '倍角' }, { key: '7', label: '横倍角', short: '横倍', cmd: 'wide', on: () => isOn(M.WIDE) }, { key: '8', label: '縦倍角', short: '縦倍', cmd: 'tall', on: () => isOn(M.TALL) }, { key: '9', label: '四倍角', short: '四倍', cmd: 'quad', on: () => isOn(M.WIDE) && isOn(M.TALL) }, { key: 'K', label: 'm×n 倍角…', short: 'm×n', cmd: 'scale', on: () => st.form === 'scale' }, { key: 'H', label: '影文字', short: '影', cmd: 'shadow', on: () => isOn(M.SHADOW) },
    { cl: '線' }, { key: 'A', label: '二重下線', short: '二重下', cmd: 'under2', on: () => isOn(M.UNDER2) }, { key: 'S', label: '波線', cmd: 'wave', on: () => isOn(M.WAVE) }, { key: 'D', label: '二重取消線', short: '二重消', cmd: 'strike2', on: () => isOn(M.STRIKE2) }, { key: 'F', label: 'コード', short: 'ｺｰﾄﾞ', cmd: 'codeSpan', on: () => isOn(M.CODE) }, { key: 'G', label: '網の文様…', short: '文様', cmd: 'shadeType', on: () => st.form === 'shadeType' },
    { cl: 'ほか' }, { key: 'L', label: 'リンク…', short: 'ﾘﾝｸ', cmd: 'link', on: () => !!FZ.linkAt(ed.seg(), ed.caret.off) }, { key: 'N', label: '図番…', short: '図番', cmd: 'figRef' }, { key: '0', label: '解除', cmd: 'clearMarks' }] },
  line: { title: '配置', items: [{ cl: '揃え' }, { key: '7', label: '左揃え', short: '左', cmd: 'alignL', on: () => !A().align || A().align === 'left' }, { key: '8', label: '中央揃え', short: '中央', cmd: 'alignC', on: () => A().align === 'center' }, { key: '9', label: '右揃え', short: '右', cmd: 'alignR', on: () => A().align === 'right' }, { key: '0', label: '均等割付', short: '均等', cmd: 'alignJ', on: () => A().align === 'justify' },
    { cl: '位置' }, { key: 'H', label: '左へ', cmd: 'posLeft' }, { key: 'J', label: '右へ', cmd: 'posRight' }, { key: 'K', label: '自動', cmd: 'posAuto', on: () => A().indent != null && !!FZ.nodeKind(A()) },
    { cl: '形' }, { key: 'O', label: '引用', cmd: 'quote', icon: 'quote', on: () => !!A().quote }, { key: 'P', label: 'コード', short: 'ｺｰﾄﾞ', cmd: 'code', icon: 'codeBlock', on: () => !!A().code }, { key: '6', label: '発言録', short: '発言録', cmd: 'styleSpeech', icon: 'speech', on: () => A().style === 'speech' }, { key: 'C', label: '区画…（見出しの子の節を枠に入れて並べる：横・縦・縦横 m×n。霞が関型の 1 枚もの）', short: '区画', cmd: 'panels', icon: 'panels', on: () => st.form === 'panels' },
    { cl: '送り' }, { key: 'F', label: '分割禁止（この行を頁で割らない）', short: '分割禁止', cmd: 'keepLine', on: () => A().keep === 'line' }, { key: 'G', label: '次と同頁', short: '次と同頁', cmd: 'keepNext', on: () => keepNextOn(A()) }, { key: 'B', label: 'ここから改頁', short: '改頁', cmd: 'pageBreak', icon: 'pageBreak', on: () => !!A().breakBefore },
    { cl: '飾り' }, { key: 'Y', label: '見出し飾り…（新聞の見出し表現）', short: '見出飾り', cmd: 'headGroup', icon: 'headDeco', on: () => !!A().deco }, { key: 'M', label: '網掛け（範囲を選んで地に網）', short: '網掛', cmd: 'fillMode', icon: 'fill' }] },
  insert: { title: '挿入', items: [{ cl: '図表' }, { key: 'P', label: '画像…', short: '画像', cmd: 'figOpen', icon: 'image' }, { key: 'C', label: 'グラフ…', short: 'ｸﾞﾗﾌ', cmd: 'chart', icon: 'chart' }, { key: 'T', label: '表…', short: '表', cmd: 'table', icon: 'table', on: () => !!A().cells }, { key: 'I', label: '図（流れ図）', short: '流れ図', cmd: 'figInsert', icon: 'flow', on: () => !!A().figure }, { key: 'R', label: '構成図を作る…（節と子から）', short: '構成図', cmd: 'figTree', icon: 'tShapeH', on: () => st.form === 'figtree' }, { key: 'G', label: '図表の設定…', short: '図表設定', cmd: 'figEdit', icon: 'figEdit', on: () => !!A().figs },
    { cl: '参照' }, { key: 'N', label: '図番…', short: '図番', cmd: 'figRef', icon: 'figRef' }, { key: 'S', label: '節の参照…（見出しの番号と題。並べ替えても追う）', short: '節の参照', cmd: 'secRef', icon: 'secRef' }, { key: 'D', label: '文書を挿入…', short: '文書', cmd: 'insertFile', icon: 'insertFile' }, { key: 'U', label: '構成の型…（報告書・企画書・霞が関の資料などの骨組み）', short: '構成の型', cmd: 'skeleton', icon: 'skeleton' },
    { cl: '区切り' }, { key: 'L', label: '区切り線', short: '区切線', cmd: 'hr', icon: 'hr', on: () => !!A().hr }, { key: 'Y', label: '記事の区切り', short: '記事', cmd: 'hd:sep', icon: 'sepDia' }, { key: 'K', label: '囲み記事', short: '囲み', cmd: 'hd:article', icon: 'article' }, { key: 'J', label: '囲み（題なし）', short: '枠', cmd: 'hd:articleN', icon: 'articleN' }, { key: 'M', label: '目次…', short: '目次', cmd: 'toc', icon: 'toc', on: () => !!A().toc }] },
  fmt: { title: '書式', items: [{ cl: '用紙' }, { key: 'F', label: '用紙・文字数…', short: '用紙', cmd: 'format', icon: 'page', on: () => st.form === 'format' }, { key: 'M', msel: 'font' }, { key: 'R', msel: 'orient' },
    { cl: '体系' }, { key: 'W', label: '見出し・箇条の体系と空き…', short: '体系', cmd: 'scheme', icon: 'scheme', on: () => st.form === 'scheme' }, { key: 'S', label: '文の分け方…（「．」も文末に・箇条書きの中の文も）', short: '文分け', cmd: 'sentOpt', icon: 'sentSel', on: () => st.form === 'sentopt' }, { key: 'N', label: '番号・記号の形…（カーソルの段のものすべて）', short: '番号形', cmd: 'sx:mark', icon: 'scheme', on: () => st.form === 'marker' },
    { cl: '資料' }, { key: 'H', label: '資料の柱と表紙…', short: '柱・表紙', cmd: 'slideHead', icon: 'slideHead', on: () => st.form === 'slide' }, { key: 'D', label: '作成日を今日に', short: '作成日', cmd: 'dateToday', icon: 'date' }, { cl: '設定' }, { key: 'X', label: '設定を書き出す', short: '書出', cmd: 'settingsOut', icon: 'cfgOut' }, { key: 'I', label: '設定を読み込む…', short: '読込', cmd: 'settingsIn', icon: 'cfgIn' }] },
  view: { title: '表示', items: [{ cl: '倍率' }, { key: '1', msel: 'zoom' }, { key: '2', label: '拡大', cmd: 'zoomIn', icon: 'zoomIn' }, { key: '3', label: '縮小', cmd: 'zoomOut', icon: 'zoomOut' }, { key: 'G', label: 'グリッド', short: '方眼', cmd: 'grid', icon: 'grid', on: () => !!st.grid },
    { cl: '探す' }, { key: 'K', label: 'コマンド一覧', short: '一覧', cmd: 'palette', icon: 'palette', on: () => st.side === 'palette' }, { key: 'H', label: '取説', cmd: 'help', icon: 'help', on: () => st.side === 'help' }, { key: 'M', label: '取扱説明書', short: '説明書', cmd: 'manual', icon: 'manual' }] },
  head: { title: '見出し飾り', parent: 'line', items: [{ cl: '飾り' }, ...FZ.HEADINGS.map(h => ({ key: h.key, label: h.label, short: h.id === 'sep' ? '区切り' : h.short, cmd: 'hd:' + h.id }))] },
  table: { title: '表の様式', parent: 'tedit', items: [{ cl: '様式' }, ...FZ.TABLES.map(t => ({ key: t.key, label: t.label, short: t.short, cmd: 'tb:' + t.id })), { cl: '操作' }, ...FZ.TABLE_OPS.map(o => ({ key: o.key, label: o.label, short: o.short, cmd: 'to:' + o.id, on: o.id === 'repeat' ? () => { const rg = FZ.tableRange(ed); return !!rg && !ed.doc.lines[rg[0]].attrs.noRepeat; } : undefined }))] },
  tedit: { title: '表', items: [{ cl: '表' }, { key: 'N', label: '表を作る…（列数・行数・列幅）', short: '表作成', cmd: 'table', icon: 'table', on: () => st.form === 'table' }, { cl: '行' }, { key: 'R', label: '上に行を挿入', short: '上に行', cmd: 'tr:above', icon: 'rowAbove' }, { key: 'F', label: '下に行を挿入', short: '下に行', cmd: 'tr:below', icon: 'rowBelow' }, { key: 'V', label: '行を削除', short: '行削除', cmd: 'tr:del', icon: 'rowDel' },
    { cl: '列' }, { key: 'T', label: '左に列を挿入', short: '左に列', cmd: 'tc:left', icon: 'colLeft' }, { key: 'G', label: '右に列を挿入', short: '右に列', cmd: 'tc:right', icon: 'colRight' }, { key: 'B', label: '列を削除', short: '列削除', cmd: 'tc:del', icon: 'colDel' },
    { cl: 'セルの網' }, { key: '1', label: '薄網', cmd: 'tcs:gray', sw: 'gray' }, { key: '2', label: '濃網', cmd: 'tcs:deep', sw: 'deep' }, { key: '3', label: '墨（白抜き）', short: '墨', cmd: 'tcs:dark', sw: 'dark' }, { key: '4', label: '斜線', cmd: 'tcs:hatch', sw: 'hatch' }, { key: '0', label: '網を消す', short: 'なし', cmd: 'tcs:none', sw: 'none' },
    { cl: 'セル' }, { key: '7', label: '左揃え', short: '左', cmd: 'tca:left', icon: 'alignL' }, { key: '8', label: '中央揃え', short: '中央', cmd: 'tca:center', icon: 'alignC' }, { key: '9', label: '右揃え', short: '右', cmd: 'tca:right', icon: 'alignR' }, { key: 'K', label: '太字', cmd: 'tcb', icon: 'bold' }, { key: 'D', label: '中身を消す', short: '消去', cmd: 'tcx', icon: 'clearCell' },
    { cl: '表' }, { key: 'U', label: '表の様式…（格子・新聞・統計表）', short: '様式', cmd: 'tableGroup', icon: 'tableStyle' }, { key: 'X', label: '表を削除', short: '表削除', cmd: 'tdel', icon: 'tableDel' }] },
};
/* ツリーの帯（ツリーのときに出る。キーはツリーのキー） */
const TREE_BAND = { title: 'ツリー', items: [{ cl: '足す' }, { key: '⏎', label: '弟を足す（Enter）', short: '弟', cmd: 'tv:after', icon: 'tSib' }, { key: 'Tab', label: '子を足す（Tab）', short: '子', cmd: 'tv:child', icon: 'tChild' },
  { cl: '動かす' }, { label: '上へ（Alt+↑）', short: '上へ', cmd: 'tv:up', icon: 'tUp' }, { label: '下へ（Alt+↓）', short: '下へ', cmd: 'tv:down', icon: 'tDown' }, { label: '浅く（Alt+←）', short: '浅く', cmd: 'tv:out', icon: 'outdent' }, { label: '深く（Alt+→）', short: '深く', cmd: 'tv:in', icon: 'indent' },
  { cl: '節' }, { key: 'C+⏎', label: '文字を直す', short: '直す', cmd: 'tv:edit', icon: 'figText' }, { key: 'Del', label: '消す', cmd: 'tv:del', icon: 'figDel' }, { label: 'ここから改頁', short: '改頁', cmd: 'tv:break', icon: 'pageBreak', on: () => { const n = treeNodeSel(); return !!(n && n.obj && n.obj.attrs.breakBefore); } }, // 紙面へは Esc か「表示」のプルダウン
  { label: '畳む・開く（Space。選んだ節だけ）', short: '畳む', cmd: 'tv:fold', icon: 'tFold' }] }; // R6：帯は構造の操作だけ。深さ・図表の開閉・形・倍率は F10（表示） // 拡大・縮小は F10（表示）・Ctrl+ホイール・Ctrl+＋／−・＋／− // 文字（F2）・紙面へ（Esc）は F キーの行にある
/* 図の帯（図を編集しているときに出る。メニューのグループではない。キーは図のキー） */
const FIG_BAND = { title: '図', items: [{ cl: '足す' }, { key: 'N', label: '箱を足す', short: '箱', cmd: 'fg:add', icon: 'figAdd' }, { key: 'C', label: '矢印でつなぐ', short: 'つなぐ', cmd: 'fg:connect', icon: 'figConnect', on: () => !!(st.fig && st.fig.connecting) }, { key: 'D', label: '複製', cmd: 'fg:dup', icon: 'figDup' },
    { cl: '文字' }, { key: 'T', label: '文字を打つ', short: '文字', cmd: 'fg:text', icon: 'figText' }, { key: 'B', label: '太字', cmd: 'fg:bold', icon: 'bold', on: () => !!(figPrim() && figPrim().bold) },
    { cl: '線' }, ...[['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']].map(([k, l]) => ({ label: l, cmd: 'fg:k:' + k, icon: 'ln_' + k, on: () => !!(figPrim() && figPrim().kind === k) })),
    { cl: '網' }, ...[['none', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨'], ['hatch', '斜線'], ['dots', '点']].map(([id, l]) => ({ label: l, cmd: 'fg:s:' + id, sw: id, on: () => !!(figPrim() && (figPrim().shade || 'none') === id) })),
    { cl: '揃え' }, ...[['left', '左', '左'], ['center', '中央', '中'], ['right', '右', '右'], ['top', '上', '上'], ['middle', '中段', '中段'], ['bottom', '下', '下'], ['dh', '横等間隔', '横等'], ['dv', '縦等間隔', '縦等']].map(([m, l, sh]) => ({ label: l, short: sh, cmd: 'fg:al:' + m, icon: 'al_' + m }))] }; // 消す・レーン・図の高さ・本文へ は F キーの行にある
/* コマンドのキー：メニューの道筋（F キー → 1 文字）をこの表から引く。ほかの近道（Ctrl など）は cmd() の keys */
const CMDI = new Map(); function cmdById(id) { if (!id) return null; if (CMDI.size !== CMDS.length) { CMDI.clear(); for (const c of CMDS) CMDI.set(c.id, c); } return CMDI.get(id) || null; }
let PATHS = null;
function menuPaths() {
  if (PATHS) return PATHS; PATHS = new Map(); const add = (id, p) => { if (!PATHS.has(id)) PATHS.set(id, []); if (!PATHS.get(id).includes(p)) PATHS.get(id).push(p); };
  for (const [k, , id] of FK.text) { if (!id) continue; add(id, k); const gn = GROUP_OF[id]; if (!gn) continue;
    const walk = (g, pre, depth) => { for (const it of GROUPS[g].items) { if (it.msel) { for (const id of MSEL[it.msel].cmds) add(id, pre + '→' + it.key); continue; } if (!it.cmd) continue; const p = pre + '→' + it.key; add(it.cmd, p); const sg = SUBGROUP_OF[it.cmd]; if (sg && depth < 2 && sg !== g) walk(sg, p, depth + 1); } };
    walk(gn, k, 0); }
  for (const [k, id] of Object.entries(FK_HIDDEN)) add(id, k);
  return PATHS;
}
function keysOf(c) { return [...(menuPaths().get(c.id) || []), c.keys].filter(Boolean).join(' / '); }
function K(id) { const p = menuPaths().get(id); if (p && p.length) return p[0]; const c = cmdById(id); return c ? c.keys : ''; } // 案内の文に出すキー
/* F キー：そのグループを子メニューに出して「構え」（1 文字キーで項目を実行）。同じ F キーをもう一度で構えを解く。子メニューは閉じない */
function toggleGroup(name) { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); if (st.form) closeForm(); if (st.group === name) st.armed = !st.armed; else { st.group = name; st.armed = true; } drawSub(); drawFkeys(); focusTA(); }
function showGroup(name) { st.group = name; st.armed = false; drawSub(); drawFkeys(); }
function disarm() { if (!st.armed) return; st.armed = false; drawSub(); drawFkeys(); }
function afterGroupItem() { const g = GROUPS[st.group]; if (g && g.parent && (st.mode === 'text' || st.mode === 'tree') && !st.form) showGroup(g.parent); }
/* ツリー：開いたグループを閉じて、ツリーの帯（構造の操作）に戻る */
function treeCloseGroup() { st.group = null; st.armed = false; drawSub(); drawFkeys(); focusTA(); } // 見出し飾り・表の様式は罫線・飾りの下の階層なので、実行したら罫線・飾りに戻る
function closeGroup() { disarm(); }
function tile(it) { const on = !!(it.on && it.on()); const c = cmdById(it.cmd); const tip = (c ? c.label : it.label) + (it.key ? `　［${it.key}］` : '');
  const kk = it.key ? String(it.key) : ''; /* キーは半角幅の墨抜き（2 字以上は詰めて） */
  return `<span class="ch${on ? ' on' : ''}${it.sw ? ' sw' : ''}" data-cmd="${it.cmd}" title="${esc(tip)}">${it.sw ? swatch(it.sw) : FZ.icon(it.icon || it.cmd)}<span class="lb">${esc(it.short || it.label)}</span>${kk ? `<span class="k${[...kk].length > 1 ? ' w' : ''}"><b>${esc(kk)}</b></span>` : ''}</span>`; }
function clusters(items) { const out = []; let cur = null; for (const it of items) { if (it.cl !== undefined) { cur = { label: it.cl, items: [] }; out.push(cur); } else { if (!cur) { cur = { label: '', items: [] }; out.push(cur); } cur.items.push(it); } } return out; }
function drawSub() { drawSubBody(); updateGuide(); drawIsland(); }
function drawSubBody() {
  if (!st.armed || st.form || (st.mode !== 'text' && st.mode !== 'tree')) document.body.classList.remove('armed');
  if (st.form) { drawForm(); return; }
  sub.classList.remove('form', 'hint'); st.formFocus = false;
  if (st.mode === 'rule') { sub.classList.add('hint'); sub.innerHTML = `<span class="ttl">罫線</span><span class="hintl"><b>矢印キー</b> 線を引く　<b>Shift+矢印</b> 移動　<b>Enter</b> 囲みの始点／確定　<b>Backspace</b> 消去切替　<b>ドラッグ</b> でも引ける　<b>Esc</b> 本文へ</span>`; return; }
  if (st.mode === 'tree' && !st.group) { const n = treeNodeSel(); const m = treeSelected().length; const kindOpt = n && !n.root && n.kind !== 'block' ? treeKindOf(n) : ''; const mk = n && treeMarkerNow(n);
    const sel = (id, vals, cur, tip) => `<select id="${id}" class="cyc" title="${esc(tip)}">${vals.map(([v, l]) => `<option value="${v}"${String(v) === String(cur) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    const mkVals = mk ? (() => { const ch = treeMarkerChoices(mk.k); if (!ch.includes(mk.tok)) ch.unshift(mk.tok); return ch.map(t => [t, t === FZ.NONE_TOKEN ? 'なし（記号なし）' : t]); })() : [['', '—']];
    sub.innerHTML = `<div class="cl tsels"><label>種類 ${sel('tvKind', [['', '—'], ['title', '表題'], ['num', '番号見出し'], ['sym', '記号見出し'], ['nlist', '番号箇条書き'], ['list', '記号箇条書き'], ['body', '本文']], kindOpt, '選んだ節の種類（段は木の位置で決まる）。文を選んで変えると、段落を割って取り出す')}</label><label title="${mk ? esc(mk.name) + ' ' + (mk.lv + 1) + '（この段のものすべて）の番号・記号の形' : '番号見出し・記号見出し・箇条書きを選ぶと変えられる'}">番号 ${sel('tvMark', mkVals, mk ? mk.tok : '', mk ? `${mk.name}${mk.lv + 1}（この段のものすべて）の番号・記号の形。全体は ${K('scheme')}` : '')}</label></div><div class="cl tsels"><label>組替 ${sel('tvRe', [['', '—'], ['para', '文ごとの段落に'], ['list', '箇条書きに'], ['tree', '親子に'], ['merge', 'まとめる']], '', '段落をばらす（文ごとの段落／箇条書き／最初の文を親にした親子）、選んだ節（または節と子）を 1 つの段落にまとめる')}</label></div>` + clusterHtml({ label: '表示', items: [{ msel: 'depth' }, { msel: 'figs' }, { msel: 'shape' }] }, true) + clusters(TREE_BAND.items).map(c => clusterHtml(c)).join('') + `<span class="cl note">${m > 1 ? `${m} 個を<br>選択中` : ''}${(ed.doc.parked || []).length ? `<span class="ch pkn" data-cmd="parkList" title="保留の島を開く">保留 ${ed.doc.parked.length}</span>` : ''}</span>`;
    $('tvKind').onchange = ev => { if (ev.target.value) treeSetKind(ev.target.value); focusTA(); }; $('tvMark').disabled = !mk; $('tvMark').onchange = ev => { treeSetMarker(ev.target.value); focusTA(); }; $('tvRe').onchange = ev => { const v = ev.target.value; if (v) treeRegroup(v); focusTA(); }; fitClusterNames(); return; } /* ツリーの帯に表示（深さ・図表・形）も：編集しながら切り替える */
  if (st.mode === 'fig') { const n = figIds().length; sub.innerHTML = clusters(FIG_BAND.items).map(c => clusterHtml(c)).join('') + `<span class="cl note">${st.fig.connecting ? '<b class="alert">矢印の先の<br>箱をクリック</b>' : n > 1 ? `${n} 個を<br>選択中` : st.fig.selArrow != null ? '矢印を<br>選択中' : ''}</span>`; fitClusterNames(); return; }
  if (st.mode === 'fill') { sub.classList.add('hint'); sub.innerHTML = `<span class="ttl">網掛け</span><span class="hintl"><b>矢印</b> 範囲 <b>Enter</b> 掛ける <b>Esc</b> 本文へ</span><span class="sws">${FZ.SHADES.filter(x => x.id !== 'text').map(sh => `<span class="ch sw${st.shade === sh.id ? ' on' : ''}" data-cmd="s:${sh.id}" title="${esc(sh.label)}">${swatch(sh.id)}<span class="lb">${esc(sh.name)}</span><span class="k">${SWATCH_KEY[sh.id]}</span></span>`).join('')}<span class="ch sw${st.shade === 'none' ? ' on' : ''}" data-cmd="s:none" title="網掛けを消す">${swatch('none')}<span class="lb">消す</span><span class="k">F5</span></span></span>`; return; }
  const g = GROUPS[st.group] || GROUPS.struct; sub.classList.toggle('armed', st.armed);
  const back = g.parent ? `<span class="ch back" data-back="1" title="${esc(GROUPS[g.parent].title)}に戻る［Esc］">${FZ.icon('back')}<span class="lb">戻る</span><span class="k">Esc</span></span>` : '';
  const note = (st.group === 'table' || st.group === 'tedit') && !FZ.tableRange(ed) ? '<span class="cl note" title="表の中にカーソルを置いてから選ぶ"><b class="alert">表の<br>中で</b></span>' : '';
  document.body.classList.toggle('armed', !!st.armed); // 構え：帯の左端を太線に、項目のキーを黒地に、状態行の案内を反転に、カーソルを薄く（打った字が本文に入らない状態）
  sub.innerHTML = back + clusters(g.items).map(c => clusterHtml(c)).join('') + note;
  fitClusterNames();
}
/* 塊の名前の縦書き：伸ばし棒・ダッシュは縦の形に */
const VFORM = { 'ー': '｜', '－': '｜', '—': '｜', '〜': '≀', '…': '︙' }; const vlabel = t => [...t].map(ch => esc(VFORM[ch] || ch)).join('<br>');
/* 塊の名前（縦書き）は、帯が 1 段に収まる時だけ出す（収まらなければ隠してタイルを優先） */
function fitClusterNames() { sub.classList.remove('tight'); const cls = [...sub.querySelectorAll(':scope > .cl')]; if (cls.length < 2) return; const t0 = cls[0].getBoundingClientRect().top; if (cls.some(c => Math.abs(c.getBoundingClientRect().top - t0) > 4)) sub.classList.add('tight'); }
/* 子メニューの項目をクリック：実行して構えを解く（キーで押したときと同じ）。別のメニューやフォームを開く項目はそちらに移る */
sub.addEventListener('pointerdown', e => { if (e.target.closest('input,button,label,select')) return; e.preventDefault(); const c = e.target.closest('.ch'); if (!c) return; if (c.dataset.back) { const g = GROUPS[st.group]; if (g && g.parent) showGroup(g.parent); focusTA(); return; } const g = st.group; run(c.dataset.cmd); if ((st.mode === 'text' || (st.mode === 'tree' && g)) && !st.form) { if (st.group === g) { disarm(); afterGroupItem(); drawSub(); } else drawSub(); focusTA(); } });
$('status').addEventListener('pointerdown', e => { e.preventDefault(); });
/* ---------- インライン・フォーム ---------- */
const FORMS = {};
const TREE_FORMS = new Set(['count', 'format', 'scheme', 'slide', 'table', 'toc', 'fig', 'figref', 'newdoc', 'tplname', 'chart', 'tfind', 'marker', 'figtree', 'moveTo', 'scheck', 'sentopt', 'secref', 'skeleton', 'parked', 'aiback', 'panels']); // ツリーのまま帯で開く欄
function openForm(name) { const figForm = st.mode === 'fig' && (name === 'box' || name === 'arrow' || name === 'lanes'); if (st.mode !== 'text' && name !== 'table' && !figForm && !(st.mode === 'tree' && TREE_FORMS.has(name))) exitMode(); st.armed = false; st.form = name; if (st.mode === 'text' && FORM_GROUP[name]) st.group = FORM_GROUP[name]; if (st.mode === 'tree') st.group = null; drawSub(); drawFkeys(); }
function toggleForm(name) { if (st.form === name) closeForm(); else openForm(name); }
function closeForm() { if (!st.form) return; const was = st.form; if (was === 'parked') { st.form = null; drawIsland(); } if (was === 'tfind' && st.tree.find) st.tree.find = ''; st.form = null; if ((was === 'tfind' || was === 'scheck' || was === 'aiback') && (st.view === 'tree' || st.view === 'split')) render(); if (was === 'aiback') { st.aiBack = null; requestOverlay(); } st.formFocus = false; if (st.mode === 'tree') render(); drawSub(); drawFkeys(); focusTA(); }
/* 選択肢：プルダウン（vals = [[値, 表示], …]、cur = 今の値） */
const cycOpts = (vals, cur) => { let i = vals.findIndex(v => v[0] === cur); if (i < 0) i = 0; return vals.map((v, k) => `<option value="${esc(v[0])}"${k === i ? ' selected' : ''}>${esc(v[1])}</option>`).join(''); };
function cyc(name, vals, cur) { return `<select class="cyc" name="${name}" data-name="${name}">${cycOpts(vals, cur)}</select>`; }
function cycVal(name) { const b = sub.querySelector(`select.cyc[data-name="${name}"]`); return b ? b.value : null; }
function inp(name, val, cls = '', type = 'text', extra = '') { return `<input name="${name}" class="${cls}" type="${type}" value="${esc(val)}" ${extra}>`; }
function fval(name) { const el = sub.querySelector(`[name="${name}"]`); return el ? el.value : ''; } // input と select の両方
function drawForm() {
  sub.classList.add('form'); const F = FORMS[st.form]; sub.innerHTML = F.html();
  sub.querySelectorAll('input').forEach(i => i.addEventListener('input', () => { if (F.change) F.change(i.name); }));
  sub.querySelectorAll('select').forEach(i => i.addEventListener('change', () => { if (F.change) F.change(i.name); }));
  st.formFocus = true; const first = sub.querySelector(F.focus || 'input') || sub.querySelector('button'); if (first) { first.focus(); if (first.select) first.select(); }
  if (F.change) F.change();
}
sub.addEventListener('keydown', e => { if (!st.form) return; const F = FORMS[st.form]; if (e.key === 'Escape') { e.preventDefault(); closeForm(); return; }
  if (e.key === 'Enter' && e.target.tagName !== 'BUTTON' && !(e.target.tagName === 'TEXTAREA' && !(e.ctrlKey || e.metaKey))) { e.preventDefault(); if (F.enter) F.enter(e); } if (F.key) F.key(e); });
sub.addEventListener('change', e => { const s0 = e.target.closest && e.target.closest('select[data-msel]'); if (!s0) return; const g = st.group; MSEL[s0.dataset.msel].set(s0.value); if (st.form) return; if (st.mode === 'text' || st.mode === 'tree') { if (g && st.group === g) { disarm(); afterGroupItem(); } } drawSub(); drawFkeys(); focusTA(); });
sub.addEventListener('click', e => { const b = e.target.closest('button[data-act]'); if (!b || !st.form) return; const F = FORMS[st.form]; if (F.act) F.act(b.dataset.act, e); });
/* 書式 */
FORMS.format = {
  html() { const f = ed.doc.format; return `<span class="ttl">書式</span>
    <label>用紙 ${cyc('paper', [['A4', 'A4'], ['A5', 'A5'], ['B5', 'B5'], ['B4', 'B4'], ['A3', 'A3'], ['Letter', 'Letter'], ['custom', '自由']], FZ.PAPERS[f.paper] ? f.paper : 'custom')}</label>
    <label>向き ${cyc('landscape', [['0', '縦'], ['1', '横']], f.widthMm > f.heightMm ? '1' : '0')}</label>
    <label>幅 ${inp('widthMm', f.widthMm, '', 'number', 'step="0.1"')}</label><label>高 ${inp('heightMm', f.heightMm, '', 'number', 'step="0.1"')}</label>
    <label>文字数 ${inp('cols', f.cols, '', 'number', 'min="4" max="200"')}</label><label>行数 ${inp('rows', f.rows, '', 'number', 'min="2" max="300"')}</label>
    <label>余白 上${inp('top', f.margins.top, '', 'number', 'step="0.5"')}</label><label>右${inp('right', f.margins.right, '', 'number', 'step="0.5"')}</label><label>下${inp('bottom', f.margins.bottom, '', 'number', 'step="0.5"')}</label><label>左${inp('left', f.margins.left, '', 'number', 'step="0.5"')}</label>
    <label>本文 ${cyc('font', [['mincho', '明朝'], ['gothic', 'ゴシック']], f.font === 'gothic' ? 'gothic' : 'mincho')}</label>
    <label>明朝の書体 ${fontPicker('fontMincho', f.fontMincho || 'BIZ UDMincho')}</label><label>ゴシックの書体 ${fontPicker('fontGothic', f.fontGothic || 'BIZ UDGothic')}</label><button type="button" data-act="fonts" title="この PC に入っている書体をすべて読む（初回はブラウザが許可を求めます）">全書体を読む</button>
    <span style="flex-basis:100%;height:0"></span>
    <label title="差し込み：{file} ファイル名（保存し直すとその名前に）／{page} 頁番号／{pages} 総頁数">ヘッダ ${inp('header', f.header, 'w')}</label><label>行 ${inp('headerRows', f.headerRows, '', 'number', 'min="0" max="8"')}</label>
    <label title="差し込み：{page} 頁番号／{pages} 総頁数／{file} ファイル名">フッタ ${inp('footer', f.footer, 'w')}</label><label>行 ${inp('footerRows', f.footerRows, '', 'number', 'min="0" max="8"')}</label><label title="{page} の最初の番号（0 から）">開始番号 ${inp('pageStart', f.pageStart, '', 'number', 'min="0" max="9999"')}</label>
    <label>ぶら下げ ${cyc('hang', [['1', 'する'], ['0', 'しない']], f.hang ? '1' : '0')}</label><label>種類 ${cyc('kind', [['doc', '文書'], ['slide', '資料']], f.kind)}</label><button type="button" data-act="slide" title="資料の柱（題・機密表示・日付・頁番号）と本文欄の幅">資料の柱…</button>
    <button type="button" data-act="scheme">体系と空き…</button><button type="button" data-act="setDefault" title="${f.kind === 'slide' ? 'この版面（用紙・文字数・行数・余白・柱）を新しい資料の既定にする（書類の既定とは別）' : 'この書式を新しい書類の既定にする（資料の既定とは別）'}">${f.kind === 'slide' ? '資料の既定にする' : '書類の既定にする'}</button><button type="button" data-act="loadDefault" title="${f.kind === 'slide' ? '資料の既定の版面を当てる' : '書類の既定の書式を当てる'}">既定を当てる</button>
    <span class="info" id="fmtInfo"></span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  read() { const f = JSON.parse(JSON.stringify(ed.doc.format)); const n = k => +fval(k); /* 書体は選択欄（name=fontMincho／fontGothic）の値 */ f.paper = cycVal('paper'); f.widthMm = n('widthMm'); f.heightMm = n('heightMm'); f.landscape = cycVal('landscape') === '1'; f.cols = n('cols'); f.rows = n('rows'); f.margins = { top: n('top'), right: n('right'), bottom: n('bottom'), left: n('left') }; f.header = fval('header'); f.footer = fval('footer'); { const v = fval('pageStart'); if (v != null) f.pageStart = String(v).trim() === '' ? 1 : +v; } f.headerRows = n('headerRows'); f.footerRows = n('footerRows'); f.font = cycVal('font'); f.fontMincho = fval('fontMincho').trim() || 'BIZ UDMincho'; f.fontGothic = fval('fontGothic').trim() || 'BIZ UDGothic'; f.hang = cycVal('hang') === '1'; f.kind = cycVal('kind') || 'doc'; return f; },
  change(name) {
    const set = (k, v) => { const el = sub.querySelector(`[name="${k}"]`); if (el) el.value = v; };
    if (name === 'paper' && FZ.PAPERS[cycVal('paper')]) { let [w, h] = FZ.PAPERS[cycVal('paper')]; if (cycVal('landscape') === '1') [w, h] = [h, w]; set('widthMm', w); set('heightMm', h); }
    if (name === 'kind' && cycVal('kind') === 'slide') { const s = slideFormat(this.read()); for (const k of ['widthMm', 'heightMm', 'cols', 'rows', 'headerRows', 'footerRows']) set(k, s[k]); setCyc('paper', [['A4', 'A4'], ['A5', 'A5'], ['B5', 'B5'], ['B4', 'B4'], ['A3', 'A3'], ['Letter', 'Letter'], ['custom', '自由']], 'A4'); setCyc('landscape', [['0', '縦'], ['1', '横']], '1'); } // 資料にしたら A4 横・60×26・柱 2 行を提案（適用前に直せる）
    if (name === 'landscape') { const w = +fval('widthMm'), h = +fval('heightMm'); set('widthMm', cycVal('landscape') === '1' ? Math.max(w, h) : Math.min(w, h)); set('heightMm', cycVal('landscape') === '1' ? Math.min(w, h) : Math.max(w, h)); }
    try { const f = this.read(); const g = FZ.geometry(f); const bad = !(g.areaW > 0 && g.areaH > 0) || !(f.cols >= 4) || !(f.rows >= 2); const el = $('fmtInfo'); el.className = 'info' + (bad ? ' alert' : ''); el.textContent = bad ? '余白・文字数・行数が不正' : `1マス ${(g.cw / FZ.PT).toFixed(2)}×${(g.ch / FZ.PT).toFixed(2)}mm ／ ${g.fs.toFixed(1)}pt`; } catch { }
  },
  enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'scheme') { closeForm(); openForm('scheme'); return; } if (a === 'slide') { const f = this.read(); closeForm(); if (f.kind !== ed.doc.format.kind) ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); openForm('slide'); return; } if (a === 'setDefault') { const f = this.read(); if (f.kind === 'slide') { try { localStorage.setItem(SLIDE_DEFAULTS_KEY, JSON.stringify(pickPage(f))); } catch { } msg('この版面を資料の既定にしました（新しい資料・資料にする時に使う。書類の既定は別）'); } else { const d = { ...f }; delete d.pageAlt; saveDefaults(d); msg('この書式を書類の既定にしました（新しい書類・書類にする時に使う。資料の既定は別）'); } return; }
      if (a === 'loadDefault') { closeForm(); const slide = ed.doc.format.kind === 'slide'; ed.mutate('', () => { const cur = ed.doc.format; const f = slide ? slideFormat(cur) : JSON.parse(JSON.stringify(defaultFormat())); if (!slide) f.kind = 'doc'; if (cur.pageAlt) f.pageAlt = cur.pageAlt; ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); msg(slide ? '資料の既定の版面を当てました' : '書類の既定の書式を当てました'); return; } if (a === 'fonts') { loadFontList(true).then(() => { for (const k of ['fontMincho', 'fontGothic']) { const el = sub.querySelector(`select[name="${k}"]`); if (el) { const v = el.value; el.innerHTML = fontOptions(v); el.value = v; } } msg(st.fontList && st.fontList.length ? `書体 ${st.fontList.length} 件を一覧に読みました` : '書体の一覧を読めませんでした', !(st.fontList && st.fontList.length)); }); return; } const f = this.read(); const g = FZ.geometry(f); if (!(g.areaW > 0 && g.areaH > 0)) { msg('余白が用紙より大きい', true); return; } closeForm(); ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); msg('書式を適用'); },
};
/* 階層体系：8 階層それぞれに番号書式／記号／なし。プリセット（内蔵＋自分で保存） */
const SCHEME_KEY = 'fz.schemes';
function userSchemes() { try { const a = JSON.parse(localStorage.getItem(SCHEME_KEY) || '[]'); return Array.isArray(a) ? a.filter(p => p && p.name && (Array.isArray(p.num) || Array.isArray(p.levels))).map(p => ({ name: String(p.name), num: FZ.normalizeScheme(p.num || p.levels), title: p.title == null ? 2 : clamp(p.title | 0, 0, 8), sym: FZ.normalizeScheme(p.sym, FZ.DEFAULT_SYM), bullet: FZ.normalizeScheme(p.bullet, FZ.DEFAULT_BULLET) })) : []; } catch { return []; } }
function saveUserSchemes(a) { try { localStorage.setItem(SCHEME_KEY, JSON.stringify(a)); } catch { } }
function setCyc(name, vals, cur) { const b = sub.querySelector(`select.cyc[data-name="${name}"]`); if (!b) return; b.innerHTML = cycOpts(vals, cur); }
const SCHEME_PAL = () => [...FZ.NUMBER_KEYS, ...FZ.SYMBOL_PRESETS, ...FZ.WRAP_PAIRS, FZ.NONE_TOKEN];
FORMS.scheme = {
  presets() { return [...FZ.SCHEME_PRESETS.map(p => ({ ...p, builtin: true })), ...userSchemes()]; },
  presetVals(ps) { return [...ps.map((p, i) => [String(i), p.name + (p.builtin ? '' : '＊')]), ['-', '（自由）']]; },
  sameAs(p, f) { return p.num.join(' ') === f.scheme.join(' ') && (p.title | 0) === (f.titleLevels | 0) && p.sym.join(' ') === FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM).join(' ') && p.bullet.join(' ') === FZ.normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET).join(' '); },
  html() {
    const f = ed.doc.format, ps = this.presets(), cur = ps.findIndex(p => this.sameAs(p, f));
    const pal = k => `<button type="button" class="pal" data-act="pal" data-tok="${esc(k)}">${esc(k)}</button>`;
    const row = (ttl, key, toks) => `<span style="flex-basis:100%;height:0"></span><span class="cat" style="min-width:5.5em">${ttl}</span>` + toks.map((t, i) => `<label class="lvl">${i + 1}${inp(key + i, t, 'lv', 'text', `data-i="${i}" spellcheck="false" autocomplete="off"`)}</label>`).join('');
    return `<span class="ttl">三体系</span><label>プリセット ${cyc('preset', this.presetVals(ps), cur >= 0 ? String(cur) : '-')}</label>` +
      `<label>題のレベル数 ${cyc('title', Array.from({ length: 9 }, (_, i) => [String(i), String(i)]), String(f.titleLevels | 0))}</label>` +
      `<label>記号見出しで番号を ${cyc('reset', [['0', '続ける'], ['1', '仕切り直す']], f.symResetsNum ? '1' : '0')}</label>` +
      `<label title="本文・箇条書きから見出しに戻るとき（と、深い節から浅い節に戻るとき）に 1 行空ける。見出しから下りるときは空けない。区切り線：大きな節の前の空きの真ん中に線">戻り空き ${cyc('rgap', [['0', 'なし'], ['1', 'あり'], ['rule', 'あり＋区切り線']], f.returnGap === 'rule' ? 'rule' : f.returnGap ? '1' : '0')}</label>` +
      `<label title="本文・箇条書きの後に来る題（題レベルの数字見出し・記号見出し・表題）の前に 1 行空ける">題の前空き ${cyc('tgap', [['0', 'なし'], ['1', 'あり']], f.titleGap ? '1' : '0')}</label>` +
      `<label title="表題（文書の題）と、そのすぐ後の本文・見出しの間に 1 行空ける。表題が続くとき・すでに空行があるときは空けない">表題の後空き ${cyc('taft', [['0', 'なし'], ['1', 'あり']], f.titleAfter ? '1' : '0')}</label>` +
      `<label title="表のすぐ前が本文・見出しなどの中身なら、表の前に 1 行空ける（空行があるとき・ページの頭は空けない）">表の前空き ${cyc('tgap2', [['0', 'なし'], ['1', 'あり']], f.tableGap ? '1' : '0')}</label>` +
      `<label title="本文の段落（見出しでも箇条書きでもない段落）の行頭。見出しの頭＋1字＝見出しの番号・記号の桁から 1 字下げ（既定）、見出しの頭＝番号・記号の桁、見出しの文字＝番号の後ろの文字の桁、左端＝見出しに関係なく左端。位置を決めた行（配置の「左へ・右へ」）は従わない">本文の位置 ${cyc('bfol', [['0', '左端'], ['mark', '見出しの頭'], ['step', '見出しの頭＋1字'], ['1', '見出しの文字']], f.bodyFollow === 'mark' || f.bodyFollow === 'step' ? f.bodyFollow : f.bodyFollow ? '1' : '0')}</label>` +
      row('数字見出し', 'n', f.scheme) + row('記号見出し', 's', FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM)) + row('箇条書き', 'b', FZ.normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET)) + row('番号付き箇条書き', 'l', FZ.normalizeScheme(f.listScheme, FZ.DEFAULT_LIST)) +
      `<span style="flex-basis:100%;height:0"></span><span class="pal-row">` + FZ.NUMBER_KEYS.map(pal).join('') + `<span class="sep"></span>` + FZ.SYMBOL_PRESETS.map(pal).join('') + `<span class="sep"></span>` + FZ.WRAP_PAIRS.map(pal).join('') + pal(FZ.NONE_TOKEN) + `</span>` +
      `<span style="flex-basis:100%;height:0"></span><span class="info" id="schInfo"></span><span class="sp"></span>` +
      `<label>名前 ${inp('name', cur >= 0 && !ps[cur].builtin ? ps[cur].name : '', 'm', 'text', 'placeholder="自分の体系として保存"')}</label><button type="button" data-act="save">保存</button><button type="button" data-act="del">削除</button><button type="button" data-act="setDefault" title="この三体系を新しい文書の既定にする">既定にする</button>` +
      `<button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`;
  },
  focus: 'input.lv',
  read() { const g = k => Array.from({ length: 8 }, (_, i) => fval(k + i)); return { num: FZ.normalizeScheme(g('n')), title: clamp(+cycVal('title') | 0, 0, 8), sym: FZ.normalizeScheme(g('s'), FZ.DEFAULT_SYM), bullet: FZ.normalizeScheme(g('b'), FZ.DEFAULT_BULLET), list: FZ.normalizeScheme(g('l'), FZ.DEFAULT_LIST), reset: cycVal('reset') === '1', rgap: cycVal('rgap') === 'rule' ? 'rule' : cycVal('rgap') === '1', tgap: cycVal('tgap') === '1', taft: cycVal('taft') === '1', tblg: cycVal('tgap2') === '1', bfol: cycVal('bfol') === 'mark' || cycVal('bfol') === 'step' ? cycVal('bfol') : cycVal('bfol') === '1' }; },
  fill(p) { const set = (k, toks) => toks.forEach((t, i) => { const el = sub.querySelector(`[name="${k}${i}"]`); if (el) el.value = t; }); set('n', p.num); set('s', p.sym); set('b', p.bullet); setCyc('title', Array.from({ length: 9 }, (_, i) => [String(i), String(i)]), String(p.title | 0)); },
  change(name) {
    if (name === 'preset') { const v = cycVal('preset'); if (v !== '-') { const p = this.presets()[+v]; this.fill(p); const nm = sub.querySelector('[name="name"]'); if (nm) nm.value = p.builtin ? '' : p.name; } }
    else if (name && /^[nsb]\d$/.test(name) || name === 'title') { const ps = this.presets(), r = this.read(), k = ps.findIndex(p => p.num.join(' ') === r.num.join(' ') && (p.title | 0) === r.title && p.sym.join(' ') === r.sym.join(' ') && p.bullet.join(' ') === r.bullet.join(' ')); setCyc('preset', this.presetVals(ps), k >= 0 ? String(k) : '-'); }
    const r = this.read(); const ex = (toks, idx, anc) => { const s = FZ.schemeSample(toks, idx, anc); return s || '（印なし）'; };
    const el = $('schInfo'); if (el) el.textContent = `数字：${[0, 1, 2, 3].map(i => ex(r.num, i, Array(i).fill(1))).join('　')}（題は ${r.title} 段まで）　記号：${[0, 1, 2].map(i => ex(r.sym, i)).join('　')}　箇条：${[0, 1, 2].map(i => ex(r.bullet, i)).join('　')}`;
  },
  key(e) {
    const t = e.target; if (!t.classList || !t.classList.contains('lv')) return;
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); const pal = SCHEME_PAL(); let k = pal.indexOf(FZ.normalizeToken(t.value)); k = k < 0 ? (e.key === 'ArrowDown' ? 0 : pal.length - 1) : (k + (e.key === 'ArrowDown' ? 1 : pal.length - 1)) % pal.length; t.value = pal[k]; t.select(); this.change(t.name); }
  },
  enter() { this.act('apply'); },
  act(a, e) {
    if (a === 'cancel') { closeForm(); return; }
    if (a === 'pal') { const tok = e.target.closest('[data-tok]').dataset.tok; const slots = [...sub.querySelectorAll('input.lv')]; let k = slots.indexOf(st.schemeSlot); if (k < 0) k = 0; slots[k].value = tok; this.change(slots[k].name); const nx = slots[Math.min(slots.length - 1, k + 1)]; st.schemeSlot = nx; nx.focus(); nx.select(); return; }
    if (a === 'save') { const name = fval('name').trim(); if (!name) { msg('保存する体系の名前を入れてください', true); sub.querySelector('[name="name"]').focus(); return; } if (FZ.SCHEME_PRESETS.some(p => p.name === name)) { msg('内蔵の体系と同じ名前は使えません', true); return; } const r = this.read(); const us = userSchemes().filter(p => p.name !== name); us.push({ name, num: r.num, title: r.title, sym: r.sym, bullet: r.bullet }); saveUserSchemes(us); const ps = this.presets(); setCyc('preset', this.presetVals(ps), String(ps.findIndex(p => p.name === name))); msg('体系を保存：' + name); return; }
    if (a === 'del') { const v = cycVal('preset'); const ps = this.presets(); if (v === '-' || ps[+v].builtin) { msg('内蔵の体系は削除できません（自分で保存した体系のみ）', true); return; } const name = ps[+v].name; saveUserSchemes(userSchemes().filter(p => p.name !== name)); const ps2 = this.presets(); setCyc('preset', this.presetVals(ps2), '-'); const nm = sub.querySelector('[name="name"]'); if (nm) nm.value = ''; msg('体系を削除：' + name); return; }
    if (a === 'setDefault') { const r = this.read(); const d = defaultFormat(); d.scheme = r.num; d.titleLevels = r.title; d.symScheme = r.sym; d.bulletScheme = r.bullet; d.listScheme = r.list; d.symResetsNum = r.reset; d.returnGap = r.rgap; d.titleGap = r.tgap; d.titleAfter = r.taft; d.tableGap = r.tblg; d.bodyFollow = r.bfol; saveDefaults(d); msg('この三体系を既定にしました（新規文書に使う）'); return; }
    if (a === 'apply') { const r = this.read(); closeForm(); ed.mutate('', () => { const f = ed.doc.format; f.scheme = r.num; f.titleLevels = r.title; f.symScheme = r.sym; f.bulletScheme = r.bullet; f.listScheme = r.list; f.symResetsNum = r.reset; f.returnGap = r.rgap; f.titleGap = r.tgap; f.titleAfter = r.taft; f.tableGap = r.tblg; f.bodyFollow = r.bfol; ed.normalizeSegs(); }); msg('三体系を適用'); }
  },
};
sub.addEventListener('focusin', e => { if (e.target.classList && e.target.classList.contains('lv')) st.schemeSlot = e.target; });
/* 目次：載せる見出しの範囲（数字見出しのレベル from〜to、記号見出しは 1〜to）。今の行が目次ならその設定を変える、そうでなければ入れる */
FORMS.toc = {
  html() {
    const a = ed.line().attrs; const T = a.toc ? FZ.tocRange(a.toc, ed.doc.format) : { num: [0, Math.max(0, (ed.doc.format.titleLevels | 0) - 1)], sym: null };
    const lv = Array.from({ length: 8 }, (_, i) => [String(i + 1), String(i + 1)]);
    return `<span class="ttl">目次</span><span class="info">${a.toc ? '範囲を変える' : 'この行に目次を入れる（見出しを抜き出し、頁番号は自動）'}</span>` +
      `<label>数字見出し ${cyc('nfrom', [['0', '載せない'], ...lv], T.num ? String(T.num[0] + 1) : '0')} 〜 ${cyc('nto', lv, T.num ? String(T.num[1] + 1) : '2')}</label>` +
      `<label>記号見出し ${cyc('sym', [['0', '載せない'], ...lv.map(([k]) => [k, k + ' まで'])], T.sym ? String(T.sym[1] + 1) : '0')}</label>` +
      `<button type="button" class="pri" data-act="ok">${a.toc ? '変更' : '入れる'} Enter</button>${a.toc ? '<button type="button" data-act="remove">目次を消す</button>' : ''}<button type="button" data-act="cancel">取消 Esc</button>`;
  },
  read() { const nf = +cycVal('nfrom'), nt = +cycVal('nto'), sy = +cycVal('sym'); return { num: nf > 0 ? [nf - 1, Math.max(nf, nt) - 1] : null, sym: sy > 0 ? [0, sy - 1] : null }; },
  enter() { this.act('ok'); },
  act(a) {
    if (a === 'cancel') { closeForm(); return; }
    if (a === 'remove') { closeForm(); ed.removeToc(ed.caret.line); msg('目次を消しました'); return; }
    if (a === 'ok') { const t = this.read(); if (!t.num && !t.sym) { msg('数字見出しか記号見出しのどちらかは載せてください', true); return; } closeForm(); if (ed.line().attrs.toc) { ed.setToc(ed.caret.line, t); msg('目次の範囲を変えました'); } else { ed.insertToc(t); msg('目次を入れました（見出しを増やすと自動で増え、頁番号も付け直します）'); } focusTA(); }
  },
};
/* 表 */
/* 表：カーソルが表の中なら「この表の様式を変える」、外なら「表を引く」 */
function tableAtCaret() { if (st.mode === 'text') return FZ.tableRange(ed); const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, Math.max(0, ed.lay.geo.rows - 1)), st.rc.col); return pos ? FZ.tableRange(ed, pos.line) : null; }
FORMS.table = {
  html() { const rg = tableAtCaret(); if (rg) return `<span class="ttl">表の様式</span><span class="info">${rg[1] - rg[0] + 1} 行の表（${rg[0] + 1}〜${rg[1] + 1} 行目）の罫線・網・揃えを様式に合わせて引き直す</span><label>様式 ${cyc('style', FZ.TABLES.map(t => [t.id, t.label]), 'grid')}</label><span class="info" id="tblInfo">${esc(FZ.TABLES[0].desc)}</span><button type="button" class="pri" data-act="restyle">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`;
    return `<span class="ttl">表</span><label>列 ${inp('cols', 3, '', 'number', 'min="1" max="40"')}</label><label>行 ${inp('rows', 3, '', 'number', 'min="1" max="200"')}</label><label>列幅（マス、カンマ区切り。空なら均等） ${inp('widths', '', 'm')}</label><label>線種 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']], st.ruleKind)}</label><label>先頭行 ${cyc('header', [['1', '網掛け'], ['0', 'なし']], '1')}</label><label>様式 ${cyc('style', FZ.TABLES.map(t => [t.id, t.label]), 'grid')}</label><span class="info" id="tblInfo"></span><button type="button" class="pri" data-act="apply">表を引く Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  vals() { const cols = clamp(+fval('cols') | 0, 1, 40), rows = clamp(+fval('rows') | 0, 1, 200); const total = ed.lay.geo.cols; let widths = fval('widths').split(/[,、\s]+/).filter(Boolean).map(Number).filter(n => n > 0); if (widths.length !== cols) { const w = Math.floor(total / cols); widths = Array.from({ length: cols }, (_, i) => i === cols - 1 ? total - w * (cols - 1) : w); } return { cols, rows, widths, kind: cycVal('kind'), header: cycVal('header') === '1', style: cycVal('style') || 'grid' }; },
  change() { if (tableAtCaret()) { const t = FZ.TABLES.find(x => x.id === cycVal('style')); const el = $('tblInfo'); if (el && t) el.textContent = t.desc; return; } const t = this.vals(); const sum = t.widths.reduce((a, b) => a + b, 0); const ok = sum <= ed.lay.geo.cols; const el = $('tblInfo'); el.className = 'info' + (ok ? '' : ' alert'); el.textContent = ok ? `${t.cols}列×${t.rows}行、列幅 ${t.widths.join('・')}（計${sum}）` : `列幅の合計 ${sum} が 1行 ${ed.lay.geo.cols} 字を超過`; },
  enter() { this.act(tableAtCaret() ? 'restyle' : 'apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; }
    if (a === 'restyle') { const id = cycVal('style'); const rg = tableAtCaret(); closeForm(); if (!rg) return; if (st.mode !== 'text') { const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, ed.lay.geo.rows - 1), st.rc.col); st.mode = 'text'; st.sub = null; if (pos) ed.setCaret(pos); drawFkeys(); drawSub(); } if (FZ.applyTable(ed, id)) msg('表の様式を「' + (FZ.TABLES.find(t => t.id === id) || {}).label + '」にしました（Ctrl+Z で戻る）'); focusTA(); return; }
    const t = this.vals(); if (t.widths.reduce((x, y) => x + y, 0) > ed.lay.geo.cols) return; closeForm(); if (st.mode !== 'text') { const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, ed.lay.geo.rows - 1), st.rc.col); st.mode = 'text'; st.sub = null; if (pos) ed.setCaret(pos); drawFkeys(); drawSub(); } ed.insertTable(t.cols, t.rows, t.widths, t.header, t.kind); if (t.style && t.style !== 'grid') FZ.applyTable(ed, t.style); focusTA(); },
};
/* 検索・置換 */
const findState = { n: '', r: '', ic: false };
FORMS.find = {
  html() { const repl = st.form === 'replace'; const s = ed.sel(); if (s && ed.selInSeg()) findState.n = ed.textOf(s); return `<span class="ttl">${repl ? '置換' : '検索'}</span><label>検索 ${inp('n', findState.n, 'w')}</label>${repl ? `<label>置換 ${inp('r', findState.r, 'w')}</label>` : ''}<label>大小 ${cyc('ic', [['0', '区別'], ['1', '同一視']], findState.ic ? '1' : '0')}</label><button type="button" data-act="prev">↑ Shift+Enter</button><button type="button" class="pri" data-act="next">↓ Enter</button>${repl ? `<button type="button" data-act="one">置換</button><button type="button" data-act="all">すべて置換</button>` : ''}<span class="info" id="findInfo"></span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'input[name="n"]',
  opts() { return { ignoreCase: cycVal('ic') === '1' }; },
  change() { findState.n = fval('n'); findState.r = fval('r'); findState.ic = cycVal('ic') === '1'; const n = findState.n; if (!n) { $('findInfo').textContent = ''; return; } let c = 0; const fold = s => findState.ic ? s.toLowerCase() : s; for (const ln of ed.doc.lines) for (const s of ln.segs) { let i = 0; while ((i = fold(s.text).indexOf(fold(n), i)) >= 0) { c++; i += n.length; } } $('findInfo').textContent = c + ' 件'; },
  enter(e) { this.act(e.shiftKey ? 'prev' : (e.target.name === 'r' ? 'one' : 'next')); },
  act(a) { const n = fval('n'), r = fval('r'); if (a === 'cancel') { closeForm(); return; } if (!n) return;
    if (a === 'next' || a === 'prev') { if (!ed.find(n, { ...this.opts(), backward: a === 'prev' })) msg('見つかりません', true); else { requestRender(); scrollToCaret(); } }
    if (a === 'one') { if (!ed.replaceCurrent(n, r, this.opts())) { if (!ed.find(n, this.opts())) msg('見つかりません', true); } else { ed.find(n, this.opts()); } requestRender(); scrollToCaret(); this.change(); }
    if (a === 'all') { const c = ed.replaceAll(n, r, this.opts()); msg(c + ' 件を置換'); this.change(); }
  },
};
FORMS.replace = FORMS.find;
/* 発言者欄の幅 */
FORMS.speech = { html() { return `<span class="ttl">発言録</span><label>発言者欄の幅（マス） ${inp('n', ed.line().attrs.speakerCols || 6, '', 'number', 'min="1" max="30"')}</label><span class="hintl">「発言者：本文」の形で打つと、本文の開始位置と折返しが揃います</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; }, enter() { this.act('apply'); }, act(a) { if (a === 'apply') { const n = clamp(+fval('n') | 0, 1, 30); closeForm(); ed.setAttrs({ style: 'speech', speakerCols: n }); } else closeForm(); } };
/* 表の見出し行の網：選んで適用（押すたびに巡る切替はやめた） */
FORMS.headFill = {
  html() { const rg = FZ.tableRange(ed); let cur = 'none'; if (rg) { const B = FZ.tableBounds(ed.doc, rg[0]); const L = B[0], R = B[B.length - 1]; const f = ed.doc.fills.find(x => x.from === rg[0] && x.to === rg[0] && x.col <= L && x.col + x.cols >= R); if (f) cur = f.shade; }
    return `<span class="ttl">見出し行の網</span><label>網 ${cyc('shade', [['gray', '薄網'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['none', 'なし']], cur)}</label><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'select', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const sh = cycVal('shade'); const rg = FZ.tableRange(ed); closeForm(); if (!rg) return; const B = FZ.tableBounds(ed.doc, rg[0]); const L = B[0], R = B[B.length - 1]; ed.mutate('', () => { ed.removeFillRect(rg[0], rg[0], L, R - L); if (sh !== 'none') ed.doc.fills.push({ id: FZ.uid(), from: rg[0], to: rg[0], col: L, cols: R - L, shade: sh }); }); },
};
/* 図：箱の文字と体裁 */
FORMS.box = {
  html() { const b = figSel() || { text: '', w: 8, h: 3, kind: 'thin', shade: null, bold: false }; return `<span class="ttl">箱</span><label>文字 ${inp('text', b.text, 'w')}</label><label>幅 ${inp('w', b.w, '', 'number', 'min="2" max="200"')}</label><label>高 ${inp('h', b.h, '', 'number', 'min="1" max="200"')}</label><label>線 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']], b.kind)}</label><label>網 ${cyc('shade', [['', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['dots', '点']], b.shade || '')}</label><label>太字 ${cyc('bold', [['0', 'なし'], ['1', '太字']], b.bold ? '1' : '0')}</label><span class="hintl">文字は箱の幅で折り返し、上下左右の中央に置かれます</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="text"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); const b = figSel(); if (!fi || !b) { closeForm(); return; } const text = fval('text'), w = clamp(+fval('w') | 0, 2, 200), h = clamp(+fval('h') | 0, 1, 200), kind = cycVal('kind'), shade = cycVal('shade') || null, bold = cycVal('bold') === '1'; closeForm();
    ed.figOp(fi.line, F => { const bb = FZ.figureBox(F, b.id); if (!bb) return; const W = fi.right - fi.left; bb.text = text; bb.w = Math.min(w, W - bb.x); bb.h = h; bb.kind = kind; bb.shade = shade; bb.bold = bold; if (bb.y + bb.h > F.h) F.h = bb.y + bb.h; }); figRefresh(); },
};
/* 図：矢印のラベル・線種 */
FORMS.arrow = {
  html() { const fi = figInfo(); const a = fi && st.fig.selArrow != null ? fi.F.arrows[st.fig.selArrow] : { label: '', kind: 'thin' }; return `<span class="ttl">矢印</span><label>ラベル ${inp('label', a.label, 'm')}</label><label>線 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['dotted', '点線']], a.kind)}</label><button type="button" data-act="flip">向きを逆に</button><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="label"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); const k = st.fig ? st.fig.selArrow : null; if (!fi || k == null) { closeForm(); return; } const label = fval('label'), kind = cycVal('kind'); if (a !== 'flip') closeForm(); ed.figOp(fi.line, F => { const ar = F.arrows[k]; if (!ar) return; ar.label = label; ar.kind = kind; if (a === 'flip') { const t = ar.from; ar.from = ar.to; ar.to = t; } }); figRefresh(); },
};
/* 図：スイムレーン */
FORMS.lanes = {
  html() { const fi = figInfo(); const L = fi && fi.F.lanes; return `<span class="ttl">スイムレーン</span><label>方向 ${cyc('dir', [['', 'なし'], ['v', '縦（列に分ける）'], ['h', '横（行に分ける）']], L ? L.dir : '')}</label><label>名前（｜で区切る） ${inp('titles', L ? L.items.map(it => it.title).join('｜') : '営業｜開発｜品質', 'w')}</label><label>図の高さ ${inp('h', fi ? fi.F.h : 10, '', 'number', 'min="1" max="200"')}</label><span class="hintl">縦レーンは上に名前の帯、横レーンは左に名前（縦書き）。箱は矢印キーやドラッグでレーンへ</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="titles"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); if (!fi) { closeForm(); return; } const dir = cycVal('dir'), titles = fval('titles').split(/[|｜]/).map(t => t.trim()).filter((t, k, arr) => t || arr.length === 1), h = clamp(+fval('h') | 0, 1, 200); closeForm();
    ed.figOp(fi.line, F => { F.lanes = dir && titles.length ? { dir, items: titles.map(t => ({ title: t, size: 0 })) } : null; const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); F.h = Math.max(h, minH); }); figRefresh(); },
};
/* リンク */
FORMS.zoom = { html: () => `<span class="ttl">表示倍率</span><label>％ <input name="pct" type="number" min="25" max="400" step="5" value="${st.zoom === 'width' || st.zoom === 'page' ? Math.round(targetWidthPx() / (ed.lay.geo.W * PX) * 100) : Math.round(Number(st.zoom) * 100)}"></label><button type="button" data-act="width">幅に合わせる</button><button type="button" data-act="page">高さに合わせる</button><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`,
  focus: 'input[name="pct"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'width' || a === 'page') { st.zoom = a; closeForm(); render(); return; } const v = clamp(+fval('pct') || 100, 25, 400); st.zoom = v / 100; closeForm(); render(); } };
FORMS.link = {
  html() { const seg = ed.seg(); const cur = FZ.linkAt(seg, ed.caret.off) || FZ.linkAt(seg, ed.caret.off - 1); return `<span class="ttl">リンク</span><label>URL ${inp('url', cur ? cur.url : '', 'w', 'text', 'placeholder="https://… （空にして適用すると外す）"')}</label><span class="hintl">選択範囲に付けます（選択が無ければカーソルの語）。本文では点線の下線、Ctrl+クリックで開く。Markdown では [文字](URL)</span><button type="button" class="pri" data-act="apply">適用 Enter</button>${cur ? '<button type="button" data-act="open">開く</button>' : ''}<button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="url"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const url = fval('url').trim(); if (a === 'open') { if (url) openUrl(url); return; } closeForm(); if (!ed.setLink(url)) msg('リンクを付ける文字を選んでください', true); else msg(url ? 'リンクを付けました' : 'リンクを外しました'); },
};
/* 確認（未保存） */
let askCb = null, askVerb = '続行';
/* 字の網の文様：選んだ字（選択が無ければこの後に打つ字）に網を掛け、文様を選ぶ */
FORMS.shadeType = { html() { return `<span class="ttl">網の文様</span>${FZ.SHADES.map((sh, k) => `<button type="button" class="swb" data-act="sh:${sh.id}" title="${esc(sh.label)}">${swatch(sh.id)} ${esc(sh.name)}<span class="kk">${'1234567890QWER'[k] || ''}</span></button>`).join('')}<button type="button" data-act="off">外す</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { const k = e.key.toUpperCase(); const i = '1234567890QWER'.indexOf(k); if (i >= 0 && k.length === 1 && FZ.SHADES[i]) { e.preventDefault(); e.stopPropagation(); this.act('sh:' + FZ.SHADES[i].id); } },
  act(a) { closeForm(); if (a === 'cancel') return; if (a === 'off') { ed.mapMarks(m => m & ~(M.SHADE | M.SHT)); render(); return; } const id = a.slice(3); ed.mapMarks(m => FZ.withShadeType(m, id)); render(); msg('網の文様：' + FZ.SHADE_BY[id].label); } };
/* m×n 倍角：横 m・縦 n（1〜9）。2 倍までは横倍角・縦倍角・四倍角と同じ */
FORMS.scale = { html() { const mk = ed.sel() ? (() => { let v = null; ed.forEachMark(ed.sel(), m => { if (v == null) v = m; return m; }, true); return v | 0; })() : ed.typing | 0; return `<span class="ttl">m×n 倍角</span><label>横 ${inp('sw', FZ.scaleW(mk), '', 'number', 'min="1" max="9"')}</label><label>縦 ${inp('sh', FZ.scaleH(mk), '', 'number', 'min="1" max="9"')}</label>${[[2, 2], [3, 3], [4, 4], [3, 2], [2, 3], [6, 6]].map(([a, b]) => `<button type="button" data-act="p:${a}x${b}">${a}×${b}</button>`).join('')}<button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="p:1x1">元の大きさ</button><button type="button" data-act="cancel">取消 Esc</button><span class="info">横×縦マス。大きな字の行は縦の倍率ぶんの高さになる</span>`; }, focus: 'input',
  act(a) { if (a === 'cancel') { closeForm(); return; } let w, h; if (a.startsWith('p:')) [w, h] = a.slice(2).split('x').map(Number); else { w = +fval('sw'); h = +fval('sh'); } closeForm(); ed.mapMarks(m => FZ.withScale(m, w, h)); render(); msg(`${w}×${h} 倍角`); } };
FORMS.count = { html() { const c = countInfo(); const f = n => n.toLocaleString(); return `<span class="ttl">字数</span><span class="info">全体 <b>${f(c.all)}</b> 字（空白を除く ${f(c.noSp)} 字）　段落 ${f(c.paras)}　${f(c.pages)} 頁　原稿用紙（400 字詰め）換算 <b>${f(c.sheets)}</b> 枚（${f(c.rows)} 行）</span>${c.sel ? `<span class="info">選択 <b>${f(c.sel.n)}</b> 字（空白を除く ${f(c.sel.k)} 字）</span>` : ''}<button type="button" data-act="cancel">閉じる Esc</button>`; }, focus: 'button', act() { closeForm(); } };
FORMS.ask = { html() { return `<span class="ask">未保存の変更があります。${askVerb === '閉じる' ? '保存してから閉じますか？' : ''}</span><button type="button" class="pri" data-act="save">S 保存して${askVerb}</button><button type="button" data-act="discard">D 保存せずに${askVerb}</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button', key(e) { const k = e.key.toLowerCase(); if (k === 's' || k === 'd') { e.preventDefault(); e.stopPropagation(); this.act(k === 's' ? 'save' : 'discard'); } }, async act(a) { const cb = askCb; askCb = null; closeForm(); if (a === 'cancel') return; if (a === 'save') { const ok = await saveFile(false); if (!ok) return; } if (cb) cb(); } };
/* 外での書き換え：開いた（保存した）あとに別のアプリや別の窓が同じファイルを書き換えていたら、上書きの前に聞く */
let conflictInfo = null;
FORMS.conflict = { html() { const nm = st.file ? st.file.name : ''; const o = conflictInfo || {}; const when = o.mtime ? new Date(o.mtime).toLocaleString() : ''; return `<span class="ask">「${esc(nm)}」は${o.gone ? '見つかりません（消された・移された）' : '文机の外で書き換えられています' + (when ? '（' + when + '）' : '')}。</span><button type="button" class="pri" data-act="as">A 別名で保存</button><button type="button" data-act="over">O ${o.gone ? 'もとの場所に保存' : '上書きする'}</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button', key(e) { const k = e.key.toLowerCase(); if (k === 'a' || k === 'o') { e.preventDefault(); e.stopPropagation(); this.act(k === 'a' ? 'as' : 'over'); } }, async act(a) { closeForm(); if (a === 'cancel') return; if (a === 'over') { const ext = await readCurrentFile(st.file); if (ext != null) await histPush(st.file, ext, '外で書き換えた版'); } await saveFile(a === 'as', true); } }; // 上書きする前に、外で書き換えた版を履歴に残す
async function readCurrentFile(f) { try { if (f.handle && typeof f.handle.getFile === 'function') return await (await f.handle.getFile()).text(); if (f.path && typeof globalThis.fzReadFile === 'function') return await globalThis.fzReadFile(f.path); } catch { } return null; }
async function stampFile() { const f = st.file; if (!f || !(f.handle || f.path)) return; const t = await FZ.files.stamp(f); if (st.file === f && t > 0) f.mtime = t; }
/* 今のファイル名（柱の {file}）。原本にも取消の履歴にも入れない（列挙しない） */
function setFileName(n) { const v = n || ''; if (ed.doc.fileName === v) return; Object.defineProperty(ed.doc, 'fileName', { value: v, enumerable: false, writable: true, configurable: true }); if (/\{file\}/.test((ed.doc.format.header || '') + (ed.doc.format.footer || ''))) ed.relayout(); } // 柱に {file} があるときだけ組み直す
function openUrl(u) { const ok = FZ.safeUrl(u); if (!ok) { msg('この種類のリンクは開きません（http・https・mailto・file だけ）：' + String(u).slice(0, 40), true); return; } window.open(ok, '_blank', 'noopener'); }
function withDiscard(fn, verb = '続行') { if (!ed.dirty) { fn(); return; } askCb = fn; askVerb = verb; if (st.mode !== 'text') exitMode(); openForm('ask'); }
/* exe 版：窓の［×］・Alt+F4 → ホストが閉じる前にここへ問い合わせる。未保存の変更があれば「保存して閉じる／保存せずに閉じる／取消」を出し、決まってから閉じる。
 * ブラウザ版（.bat）は閉じる前の確認をブラウザの標準の問い合わせ（離れる／キャンセル）で出す（beforeunload。保存の選択肢は出せないが、復旧用の退避は残る） */
window.fzRequestClose = () => {
  try { if (typeof window.fzCloseAck === 'function') window.fzCloseAck(); } catch { } // 画面が応答していることをホストに知らせる
  const closeNow = () => { ed.dirty = false; clearRecovery(); try { window.fzCloseNow(); } catch { } };
  if (st.composing) { msg('変換を確定してから閉じてください', true); return; }
  withDiscard(closeNow, '閉じる'); if (st.form === 'ask') { const b = sub.querySelector('button[data-act="save"]'); if (b) b.focus(); }
};
/* ---------- 保存の版の履歴（専用機の「置き換え文書復元」）：開いたとき・保存のたびの原本を、ファイルごとに直近 10 版まで IndexedDB に残す ---------- */
const HIST_MAX = 10, HIST_BYTES = 40e6;
const histKey = f => f && (f.path || f.handle) ? 'hist:' + (f.path || 'h:' + f.name) : null;
async function histPush(f, text, kind) { const k = histKey(f); if (!k || !text) return; try { const arr = (await RDB.get(k)) || []; if (arr[0] && arr[0].text === text) return; arr.unshift({ time: Date.now(), kind, text }); const keep = []; let bytes = 0; for (const v of arr) { bytes += v.text.length * 2; if (keep.length >= HIST_MAX || (keep.length && bytes > HIST_BYTES)) break; keep.push(v); } await RDB.put(k, keep); } catch { } }
async function histList() { const k = histKey(st.file); if (!k) return []; try { return (await RDB.get(k)) || []; } catch { return []; } }
FZ.histList = histList;
async function histRestore(i) { const arr = await histList(); const v = arr[i]; if (!v) return; withDiscard(async () => { const f = st.file; let d; try { d = await parseText(v.text, 'fzk', {}); } catch (e) { msg('この版は読めませんでした：' + e.message, true); return; } ed.setDoc(d); setFileName(f ? f.name : ''); st.file = f; ed.dirty = true; closeSide(); render(); msg(`${histTime(v.time)} の版に戻しました（保存すると上書き。${K('undo')} では戻らないので、戻すなら履歴の新しい版から）`, false, 10000); }, '戻す'); }
const histTime = t => { const d = new Date(t); return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; };
/* ================= 右パネル ================= */
function toggleSide(name) { if (st.side === name) { closeSide(); return; } st.side = name; sideEl.hidden = false; sideEl.classList.toggle('wide', name === 'help'); drawSide(); drawFkeys(); geomDirty = true; requestRender(); }
function closeSide() { st.side = null; sideEl.hidden = true; st.formFocus = false; drawFkeys(); geomDirty = true; requestRender(); focusTA(); }
async function drawSide() {
  const body = $('sideBody'); const titles = { help: '取説', palette: 'コマンド一覧', hist: '版の履歴' }; $('sideTitle').textContent = titles[st.side] || '';
  if (st.side === 'hist') { if (!histKey(st.file)) { body.innerHTML = '<div class="side-empty">保存先のある文書だけ、版を残します。いったん保存すると、それから先の版が残ります。</div>'; return; } const arr = await histList(); if (st.side !== 'hist') return;
    body.innerHTML = (arr.length ? arr.map((v, i) => { const t = (v.text.split('\n---\n')[1] || '').split('\n').find(l => l.trim()) || ''; return `<div class="li hv" data-hist="${i}"><span class="t"><b>${i + 1}</b>　${esc(histTime(v.time))}　${esc(v.kind)}<br><span class="d">${esc(t.replace(/^\[[^\]]*\]/, '').slice(0, 30))}　${v.text.length.toLocaleString()} 字</span></span></div>`; }).join('') : '<div class="side-empty">まだ版がありません。</div>') + '<div class="side-empty hint">選ぶとその版に戻す（未保存の変更があれば確かめる）。保存すると上書き。ファイルごとに直近 10 版</div>'; return; }
  if (false) { const items = ed.outline(); const cur = ed.caret.line; let here = -1; items.forEach((it, k) => { const [a, b] = ed.sectionRange(it.line); if (cur >= a && cur <= b) here = k; }); body.innerHTML = (items.length ? items.map((it, k) => { const [a, b] = ed.sectionRange(it.line); const inCur = cur >= a && cur <= b; return `<div class="li lv${it.level}${inCur ? ' cur' : ''}${k === here ? ' here' : ''}" data-line="${it.line}" style="padding-left:${8 + Math.min(it.depth, 12) * 10}px"><span class="t">${esc(it.text) || '（空）'}</span><button class="b" data-act="up" title="上へ">▲</button><button class="b" data-act="down" title="下へ">▼</button><button class="b" data-act="out" title="レベル上げ">◀</button><button class="b" data-act="in" title="レベル下げ">▶</button></div>`; }).join('') : '<div class="side-empty">見出しや箇条書きの行がここに並びます。</div>') + '<div class="side-empty hint">▲▼ 節ごと移動（Alt+↑↓）　◀▶ レベル</div>'; return; }
  if (st.side === 'help') { body.innerHTML = FZ.help.toHtml(helpCtx()); return; }
  if (st.side === 'palette') { body.innerHTML = `<input class="sb-input" id="palInput" placeholder="コマンドを検索（例：中央、表、印刷）"><div id="palList"></div>`; const inpEl = $('palInput'); palFilter(''); inpEl.addEventListener('input', () => palFilter(inpEl.value)); inpEl.addEventListener('keydown', e => { if (e.key === 'ArrowDown') { palSel = Math.min(palItems.length - 1, palSel + 1); drawPal(); e.preventDefault(); } else if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); drawPal(); e.preventDefault(); } else if (e.key === 'Enter') { e.preventDefault(); const c = palItems[palSel]; closeSide(); if (c) run(c.id); } else if (e.key === 'Escape') { e.preventDefault(); closeSide(); } }); st.formFocus = true; inpEl.focus(); return; }
}
let palSel = 0, palItems = [];
function palFilter(q) { q = q.trim().toLowerCase(); palItems = CMDS.filter(c => !q || (c.label + ' ' + c.group + ' ' + c.kw + ' ' + keysOf(c)).toLowerCase().includes(q)); palSel = 0; drawPal(); }
function drawPal() { const el = $('palList'); if (!el) return; el.innerHTML = palItems.map((c, i) => `<div class="li${i === palSel ? ' cur' : ''}" data-i="${i}"><span class="t"><span class="g">${c.group}</span>${esc(c.label)}</span><span class="k">${esc(keysOf(c))}</span></div>`).join('') || '<div class="side-empty">該当なし</div>'; const cur = el.querySelector('.cur'); if (cur) cur.scrollIntoView({ block: 'nearest' }); }
$('sideBody').addEventListener('pointerdown', e => { if (e.target.closest('input')) return; e.preventDefault(); });
$('sideBody').addEventListener('click', e => {
  const go = e.target.closest('[data-go]'); if (go) { const t = document.getElementById(go.dataset.go); if (t) t.scrollIntoView({ block: 'start' }); return; } // 取説の目次
  if (e.target.closest('[data-act="manual"]')) { openManual(); return; }
  const li = e.target.closest('.li'); if (!li) return;
  if (false) { const i = +li.dataset.line; const act = e.target.dataset.act; if (act === 'up') ed.moveSection(i, -1); else if (act === 'down') ed.moveSection(i, 1); else if (act === 'out') ed.changeLevel(i, -1); else if (act === 'in') ed.changeLevel(i, 1); else { ed.setCaret({ line: i, seg: 0, off: 0 }); scrollToCaret(); } focusTA(); return; }
  if (st.side === 'palette') { const c = palItems[+li.dataset.i]; closeSide(); if (c) run(c.id); return; }
  if (st.side === 'hist' && li.dataset.hist != null) { histRestore(+li.dataset.hist); return; }
});
/* 取説の中身は fz-help.js（右の欄と取扱説明書.fzk を同じ中身から作る）。ここはキーの引き方と、全キーの一覧を渡す */
function helpIndex() {
  const ORDER = ['取説', 'ファイル', '編集', '構造', '文字', '配置', '挿入', '罫線・飾り', '見出し飾り', '表の様式', '書式', '表示', 'アウトライン', '図', '罫線'];
  const groups = {}; for (const g of ORDER) groups[g] = []; for (const c of CMDS) { const k = keysOf(c); if (!k) continue; (groups[c.group] = groups[c.group] || []).push(c); }
  const out = Object.entries(groups).filter(([, cs]) => cs.length).map(([g, cs]) => ({ group: g, rows: cs.map(c => [keysOf(c), c.label]) }));
  return out;
}
function helpCtx() { return { K: id => K(id) || '（キーなし）', A: id => { const c = cmdById(id); return (c && keysOf(c)) || '（キーなし）'; }, version: FZ.VERSION, index: helpIndex(), env: `ファイルの扱い：${FZ.files.kind}　／　${navigator.userAgent.replace(/^.*\) /, '')}` }; }
FZ.manualText = () => FZ.help.toFzk(helpCtx()); // 取扱説明書.fzk（試験と tools/build-manual.js も使う）
/* 取扱説明書を開く：別の窓で（今の文書はそのまま）。窓を開けなければ、この窓で（未保存なら確かめる） */
function openManual() { if (st.side === 'help') closeSide(); if (liveWindows() < MAX_WINDOWS) { let free = 0; for (let n = 1; n <= MAX_WINDOWS && !free; n++) if (!slotAlive(n) && n !== st.slot) free = n; const url = location.href.split('?')[0].split('#')[0] + '?w=' + free + '&open=manual'; let w = null; try { w = window.open(url, '_blank', 'popup,width=1180,height=900'); } catch { } if (w) return; }
  withDiscard(() => loadManualHere()); }
async function loadManualHere() { await loadText(FZ.manualText(), '取扱説明書.fzk', null); ed.dirty = false; status(); msg('取扱説明書を開きました（文書なので、そのまま編集・印刷できます）'); }
/* ================= 状態行 ================= */
/* 案内（専用機のガイダンス行）：今の状態で次に押せるキー */
function updateGuide() { const gd = $('stGuide'); if (!gd) return; const g = guideText(); if (gd.innerHTML !== g) gd.innerHTML = g; gd.classList.toggle('arm', !!st.armed && st.mode === 'text' && !st.form); } // 知らせ（msg）と並べて出す。狭いときは案内の方が先に縮む
function guideText() {
  const g = (...p) => p.map(([k, t]) => `<b>${esc(k)}</b> ${esc(t)}`).join('　');
  if (st.form) return g(['Enter', '決定'], ['Esc', '取消'], ['Tab', '次の欄']);
  if (st.mode === 'rule') return g(['矢印', '引く'], ['Shift+矢印', '動く'], ['Esc', '本文へ']);
  if (st.mode === 'fill') return g(['矢印', '範囲'], ['Enter', '掛ける'], ['Esc', '本文へ']);
  if (st.mode === 'tree') return g(['矢印', '移る'], ['Enter／Tab', '弟／子を足す'], ['ドラッグ', '動かす'], ['Esc', '紙面へ']);
  if (st.mode === 'fig') return st.fig && st.fig.connecting ? g(['クリック', '矢印の先の箱'], ['Esc', 'やめる']) : g(['ダブルクリック', '箱を足す・文字'], ['ドラッグ', '動かす'], ['辺の点', 'つなぐ'], ['Esc', '本文へ']);
  if (st.side === 'palette') return g(['↑↓', '選ぶ'], ['Enter', '実行'], ['Esc', '閉じる']);
  if (st.armed) return g(['1 文字', '項目を選ぶ'], ['Esc', 'やめる']);
  const a = ed.line().attrs;
  if (st.cells) return g(['Delete', '中身を消す'], ['右クリック', '網・揃え'], ['Ctrl+C', '写す'], ['Esc', 'やめる']);
  if (ed.sel()) return g(['F4', '字の飾り'], ['右クリック', '字の飾り'], ['Ctrl+C', '写す']);
  if (a.cells && FZ.inTable(ed.doc, ed.caret.line)) return g(['Tab', '次のセル'], ['右クリック', '行・列・網'], ['罫をドラッグ', '列の幅']);
  if (a.figure) return g(['クリック・Enter', '図を描く'], ['Backspace', '図を消す']);
  if (a.toc) return g(['Enter', '範囲を変える'], ['Backspace', '目次を消す']);
  if (a.list || a.style === 'num' || a.style === 'sym') return g(['Tab', '深く'], ['Shift+Tab', '浅く'], ['Shift+Enter', '項目の中で改行']);
  return g(['F1', '取説'], ['F2〜F10', 'メニュー'], ['Shift+Enter', '段落の中で改行']);
}
const MARK_LABEL = [[M.SHADOW, '影'], [M.BOLD, '太'], [M.UNDER, '下'], [M.UNDER2, '二重下'], [M.WAVE, '波'], [M.DOT, '点'], [M.SHADE, '網'], [M.CODE, 'コード'], [M.OUTLINE, '白'], [M.STRIKE, '消'], [M.STRIKE2, '二重消'], [M.WIDE, '横倍'], [M.TALL, '縦倍']];
function status() {
  syncKind(); syncView();
  const name = (st.file && st.file.name) || (ed.doc.title ? ed.doc.title + '.fzk' : '無題'); $('stFile').innerHTML = `${esc(name)}${ed.dirty ? ' <span class="dirty">●</span>' : ''}`;
  const title = `${ed.dirty ? '● ' : ''}${name} — 文机${st.slot > 1 ? ' ' + st.slot : ''}`; if (document.title !== title) { document.title = title; if (typeof globalThis.fzSetTitle === 'function') { try { globalThis.fzSetTitle(title); } catch { } } }
  if (st.mode === 'text') { const xy = ed.xy(); $('stPos').textContent = xy ? (xy.y < 0 ? `柱 ${fmtCol(xy.col + 1)} 桁` : `${xy.y + 1} 行 ${fmtCol(xy.col + 1)} 桁`) : ''; $('stPage').textContent = xy ? `${xy.page + 1} / ${ed.lay.pages.length}${ed.layoutDone ? '' : '+'} 頁` : ''; }
  else if (st.mode === 'tree') { const n = treeNodeSel(); const KN = { root: '根', title: '表題', num: '数字見出し', sym: '記号見出し', list: '箇条書き', body: '本文', block: '表・図' }; $('stPos').textContent = n ? `${KN[n.kind] || ''}${n.kind === 'num' || n.kind === 'sym' || n.kind === 'list' ? n.level + 1 : ''}　子 ${n.children.length}` : ''; $('stPage').textContent = st.tree.view ? `節 ${st.tree.view.tr.nodes.length}` : ''; }
  else if (st.mode === 'fig') { const fi = figInfo(); const n = figIds().length; const b = fi && n === 1 ? FZ.figureBox(fi.F, figIds()[0]) : null; $('stPos').textContent = b ? `箱${b.id} (${b.x},${b.y}) ${b.w}×${b.h}` : n > 1 ? `箱 ${n} 個` : fi ? `図 高さ${fi.F.h}` : ''; $('stPage').textContent = fi ? `${fi.page + 1} / ${ed.lay.pages.length} 頁` : ''; }
  else { $('stPos').textContent = `交点 ${st.rc.y} , ${st.rc.col}`; $('stPage').textContent = `${st.rc.page + 1} / ${ed.lay.pages.length} 頁`; }
  { const s = st.mode === 'text' ? ed.sel() : null; let sc = ''; if (s) { let k = 0; for (const ch of ed.textOf(s)) if (!/[\s\u3000]/.test(ch)) k++; sc = '選択 ' + k.toLocaleString() + '／'; } $('stChars').textContent = sc + ed.charCount().toLocaleString() + ' 字'; } // 選んでいれば選択の字数も（空白を除く）
  const modeEl = $('stMode'); modeEl.className = 'st mode' + (st.mode !== 'text' ? ' rule' : '');
  modeEl.textContent = st.mode === 'text' ? '本文' : st.mode === 'tree' ? `ツリー（${st.tree.depth > 0 ? st.tree.depth + ' 段' : st.tree.depth === -1 ? '文まで' : '本文まで'}）` : st.mode === 'fig' ? `図（箱${(figInfo() || { F: { boxes: [] } }).F.boxes.length}）` : st.mode === 'fill' ? `網掛け（${st.shade === 'none' ? '消す' : (FZ.SHADE_BY[st.shade] || {}).name || st.shade}）${st.ranchor ? ' 範囲指定中' : ''}` : `罫線（${({ thin: '細', thick: '太', double: '二重', dotted: '点線', arrow: '矢印' })[st.ruleKind]}）${st.sub === 'erase' ? ' 消去' : st.sub === 'rect' ? ' 囲み' : ''}`;
  const a = ed.line().attrs; const sty = (a.style === 'title' && ed.lay.headY != null) ? (ed.caret.line === ed.lay.coverTitle ? '表題（表紙）' : '表題（柱）') : a.hr ? '区切り線' : a.toc ? '目次（Enter で範囲）' : a.figure ? '図（Enter で編集）' : a.cells && FZ.inTable(ed.doc, ed.caret.line) ? '表（様式は ' + K('table') + '）' : a.style === 'num' ? `数字見出し${(a.level | 0) + 1}${(a.level | 0) < (ed.doc.format.titleLevels | 0) ? '（題）' : ''}` : a.style === 'sym' ? `記号見出し${(a.level | 0) + 1}` : { title: '表題', speech: '発言録' }[a.style] || '本文';
  const lst = a.list ? ' ' + (a.list.kind === 'arrow' ? '→' : a.list.kind === 'todo' ? '❏' : a.list.kind === 'done' ? '☑' : a.list.kind === 'cont' ? '続き' : a.list.kind === 'num' ? '番号付き箇条書き' : '箇条書き') + ((a.list.level | 0) + 1) + (a.list.kind ? '' : ' ' + FZ.normalizeScheme(ed.doc.format.bulletScheme, FZ.DEFAULT_BULLET)[Math.min(7, a.list.level | 0)]) : ''; const al = { center: ' 中央', right: ' 右', justify: ' 均等' }[a.align] || '';
  const pz = a.indent != null && FZ.nodeKind(a) ? ' 位置' + (a.indent | 0) + '固定' : a.indent ? ' 字下げ' + a.indent : ''; const lk = st.mode === 'text' ? FZ.linkAt(ed.seg(), ed.caret.off) : null; $('stStyle').textContent = sty + lst + pz + al + (a.quote ? ' 引用' + (a.quote > 1 ? a.quote : '') : '') + (a.code ? ' コード' : '') + (a.breakBefore ? ' 改頁' : '') + (a.figs ? ' 図表' + a.figs.length : '') + (lk ? ' → ' + lk.url : '');
  $('stMarks').textContent = MARK_LABEL.filter(([b]) => ed.typing & b).map(([, l]) => l).join('') || (ed.doc.format.font === 'gothic' ? 'ゴシック' : ed.doc.format.font === 'system' ? 'システム' : '明朝');
  const m = $('stMsg'); m.textContent = st.msg; m.className = 'st msg' + (st.msgAlert ? ' alert' : '');
  $('stView').textContent = st.mode === 'tree' ? 'ツリー ' + Math.round(st.tree.scale * 100) + '%' : st.zoom === 'width' ? '幅合わせ' : st.zoom === 'page' ? '頁全体' : Math.round(Number(st.zoom) * 100) + '%';
  const hm = t => { const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); };
  const sv = $('stSave'); sv.textContent = ed.dirty ? '未保存' : !st.file ? '保存先なし' : st.savedAt ? '保存済 ' + hm(st.savedAt) : '保存済';
  updateGuide(); sv.className = 'st' + (ed.dirty ? ' dirty' : '');
}
function fmtCol(c) { return Number.isInteger(c) ? String(c) : c.toFixed(1); }
$('stFile').onclick = () => run('open'); $('stView').onclick = () => { if (st.mode === 'tree') { treeZoom(0); return; } openForm('zoom'); };
/* 重い処理の前に「〜中…」を出し、画面に描かせてから始める（固まったように見せない） */
async function busy(text) { msg(text, false, 0); await new Promise(r => requestAnimationFrame(() => setTimeout(r, 0))); }
function msg(text, alert = false, ms = 5000) { st.msg = text; st.msgAlert = alert; status(); clearTimeout(st.msgTimer); if (ms) st.msgTimer = setTimeout(() => { st.msg = ''; status(); }, ms); }
const TREE_SCALES = [0.6, 0.7, 0.8, 0.9, 1, 1.15, 1.3, 1.5, 1.75, 2, 2.5];
/* ツリーの倍率：d = ±1 で 1 段、0 で等倍。選んだ節が見えるところへ */
function treeZoom(d) { const cur = st.tree.scale; let i = TREE_SCALES.findIndex(x => Math.abs(x - cur) < 1e-6); if (i < 0) i = TREE_SCALES.findIndex(x => x > cur); if (i < 0) i = TREE_SCALES.length - 1; st.tree.scale = d === 0 ? 1 : TREE_SCALES[clamp(i + d, 0, TREE_SCALES.length - 1)]; try { localStorage.setItem('fz.treeScale', String(st.tree.scale)); } catch (e) { /* 覚えられなくても動く */ } render(); drawSub(); status(); treeScrollToSel(); }
function zoomStep(d) { if (st.mode === 'tree') { treeZoom(d); return; } pageZoomStep(d); }
function pageZoomStep(d) { const steps = ['page', 'width', 0.75, 1, 1.25, 1.5, 2, 3]; let i = steps.indexOf(st.zoom); if (i < 0) { const z = Number(st.zoom); i = steps.findIndex(x => typeof x === 'number' && x > z); if (i < 0) i = steps.length - 1; if (d > 0) i--; } i = clamp(i + d, 0, steps.length - 1); st.zoom = steps[i]; render(); }
/* ================= 表示モード ================= */
new ResizeObserver(es => { for (const e of es) { if (e.target === main) { mainW = e.contentRect.width; mainH = e.contentRect.height; } } geomDirty = true; requestRender(); }).observe(main);
new ResizeObserver(() => { if (st.view === 'split') { try { localStorage.setItem('fz.treeW', String(Math.round(tpane.offsetWidth))); } catch (e) { /* 覚えられなくても動く */ } } requestRender(); }).observe(tpane);
try { const w = +localStorage.getItem('fz.treeW'); if (w >= 200) document.documentElement.style.setProperty('--tw', w + 'px'); } catch (e) { /* 既定の幅 */ }
/* 並べる：ツリーと紙面の境目をドラッグで動かす（ダブルクリックで半々） */
{ const sp = $('tsplit'); const setW = px => { const max = Math.round(window.innerWidth * 0.8); const w = Math.max(220, Math.min(max, Math.round(px))); document.documentElement.style.setProperty('--tw', w + 'px'); };
  sp.addEventListener('pointerdown', e => { if (e.button !== 0) return; e.preventDefault(); sp.setPointerCapture(e.pointerId); sp.classList.add('drag'); const x0 = e.clientX, w0 = tpane.offsetWidth;
    const mv = ev => setW(w0 + ev.clientX - x0); const up = ev => { sp.releasePointerCapture(ev.pointerId); sp.classList.remove('drag'); sp.removeEventListener('pointermove', mv); sp.removeEventListener('pointerup', up); focusTA(); };
    sp.addEventListener('pointermove', mv); sp.addEventListener('pointerup', up); });
  sp.addEventListener('dblclick', e => { e.preventDefault(); setW((window.innerWidth - ($('side') && $('side').offsetWidth || 0)) / 2); }); }
let scrollTick = false; main.addEventListener('scroll', () => { if (scrollTick) return; scrollTick = true; requestAnimationFrame(() => { scrollTick = false; skipTree = true; try { render(); } finally { skipTree = false; } }); }, { passive: true });
/* ================= ファイル ================= */
/* ================= 既定の書式・テンプレート ================= */
const DEFAULTS_KEY = 'fz.defaults', TEMPLATES_KEY = 'fz.templates';
/* 既定の書式。新しい文書と Markdown の読み込みに使う。構造から引く見た目は既定で入：戻り空き（本文から見出しに戻るとき 1 行）、本文の位置（本文を直前の見出しの文字位置に揃える）。
   保存した既定はそれに従う。ただし 1.0.10a.4 より前に保存した既定は、この 2 つを持っていなかった頃のものなので、新しい既定（入）にする */
function defaultFormat() { let d = null; try { d = JSON.parse(localStorage.getItem(DEFAULTS_KEY) || 'null'); } catch { } const base = FZ.newDoc(); base.format.returnGap = true; base.format.bodyFollow = 'step'; base.format.titleAfter = true; base.format.tableGap = true;
  if (d && typeof d === 'object') { const old = !(d._v >= 2); const dd = { ...d }; delete dd._v; if (old) { delete dd.returnGap; delete dd.bodyFollow; } base.format = FZ.normalize({ ...base, format: { ...base.format, ...dd } }).format; } return base.format; }
function saveDefaults(f) { try { localStorage.setItem(DEFAULTS_KEY, JSON.stringify({ ...f, _v: 2 })); } catch { } }
function templates() { try { const a = JSON.parse(localStorage.getItem(TEMPLATES_KEY) || '[]'); return Array.isArray(a) ? a.filter(t => t && t.name && typeof t.text === 'string') : []; } catch { return []; } }
function saveTemplates(a) { try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(a)); } catch { } }
function blankDoc() { const d = FZ.newDoc(); d.format = JSON.parse(JSON.stringify(defaultFormat())); st.file = null; ed.setDoc(d); clearRecovery(); msg('新しい文書（既定の書式）'); render(); scrollToCaret(); focusTA(); }
function docFromTemplate(t) { let d; try { d = FZ.parse(t.text); } catch (e) { msg('テンプレートを読めません：' + e.message, true); return; } st.file = null; ed.setDoc(d); ed.dirty = false; clearRecovery(); msg('テンプレート「' + t.name + '」から新しい文書'); render(); scrollToCaret(); focusTA(); }
function newDoc() { withDiscard(() => openForm('newdoc')); }
/* 資料書式の新しい文書：A4 横 60 字×26 行、本文欄 60%、柱 2 行（題・機密表示・日付と作成者・頁番号）。1 行目は表題（柱に入る） */
const SLIDE_DEFAULTS_KEY = 'fz.defaults.slide'; /* 資料の既定の版面（書類の既定とは別） */
function slidePageDefault() { try { const d = JSON.parse(localStorage.getItem(SLIDE_DEFAULTS_KEY) || 'null'); return d && typeof d === 'object' ? d : null; } catch { return null; } }
function slideFormat(base) { const f = JSON.parse(JSON.stringify(base || defaultFormat())); delete f.pageAlt; if (!f.returnGap) f.returnGap = true; if (!f.bodyFollow) f.bodyFollow = 'step'; if (f.titleAfter === undefined) f.titleAfter = true; if (f.tableGap === undefined) f.tableGap = true; Object.assign(f, { kind: 'slide', paper: 'A4', widthMm: 297, heightMm: 210, landscape: true, cols: 60, rows: 26, headerRows: 2, footerRows: 0, hfGap: 1, margins: { top: 12, right: 15, bottom: 12, left: 15 }, bodyPct: f.bodyPct || 60 });
  { const sd = slidePageDefault(); if (sd) for (const k of FZ.PAGE_KEYS) if (sd[k] !== undefined) f[k] = JSON.parse(JSON.stringify(sd[k])); } /* 資料の既定（書式の「資料の既定にする」で保存） */
  if (!f.date) { const d = new Date(); f.date = `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`; } return f; }
function slideDoc() { const d = FZ.newDoc(); d.format = slideFormat(); d.lines = [FZ.newLine('', { style: 'title' }), FZ.newLine('')]; st.file = null; ed.setDoc(d); clearRecovery(); msg('新しい資料：1 行目は柱に入る表題。画像は貼り付け・ドラッグ＆ドロップか ' + K('figOpen') + '、図番は ' + K('figRef')); render(); scrollToCaret(); focusTA(); }
FORMS.newdoc = { html() { const ts = templates(); return `<span class="ttl">新しい文書</span><button type="button" class="pri" data-act="blank">1 白紙（既定の書式）</button><button type="button" data-act="slide">S 資料（A4 横）</button>${ts.map((t, i) => `<button type="button" data-act="t${i}">${i < 8 ? (i + 2) + ' ' : ''}${esc(t.name)}</button><button type="button" class="pal" data-act="x${i}" title="このテンプレートを消す">×</button>`).join('')}<button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { const k = e.key; if (k.toLowerCase() === 's') { e.preventDefault(); this.act('slide'); } else if (k === '1') { e.preventDefault(); this.act('blank'); } else if (/^[2-9]$/.test(k)) { e.preventDefault(); this.act('t' + (+k - 2)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'blank') { closeForm(); blankDoc(); return; } if (a === 'slide') { closeForm(); slideDoc(); return; } let m; if ((m = a.match(/^t(\d+)$/))) { const t = templates()[+m[1]]; closeForm(); if (t) docFromTemplate(t); return; } if ((m = a.match(/^x(\d+)$/))) { const ts = templates(); const t = ts[+m[1]]; if (!t) return; ts.splice(+m[1], 1); saveTemplates(ts); msg('テンプレート「' + t.name + '」を消しました'); if (ts.length) drawSub(); else { closeForm(); } } } };
FORMS.tplname = { html() { return `<span class="ttl">テンプレートとして保存</span><label>名前 ${inp('name', ed.doc.title || baseTitle(), 'w')}</label><button type="button" class="pri" data-act="apply">保存 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'input[name="name"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const name = fval('name').trim(); if (!name) { msg('名前を入れてください', true); return; } const ts = templates().filter(t => t.name !== name); ts.unshift({ name, text: FZ.serialize(ed.doc) }); saveTemplates(ts.slice(0, 30)); closeForm(); msg('テンプレート「' + name + '」を保存（新規 ' + K('new') + ' で選べる）'); } };
/* 設定の書き出し・読み込み：既定の書式・体系プリセット・テンプレート・書体一覧を 1 つの JSON に */
function exportSettings() { const data = { 文机設定: FZ.VERSION, 既定の書式: defaultFormat(), 体系: userSchemes(), テンプレート: templates(), 和文番号を起こす: st.jaLift }; FZ.files.download(JSON.stringify(data, null, 1), '文机設定.json'); msg('設定を書き出しました'); }
async function importSettings() { try { const r = await FZ.files.open(); if (!r) return; const data = JSON.parse(r.text); if (!data || !data.文机設定) { msg('文机の設定ファイルではありません', true); return; } if (data.既定の書式) saveDefaults(data.既定の書式); if (Array.isArray(data.体系)) saveUserSchemes(data.体系); if (Array.isArray(data.テンプレート)) { const cur = templates(); const names = new Set(cur.map(t => t.name)); saveTemplates([...cur, ...data.テンプレート.filter(t => t && t.name && !names.has(t.name))]); } if (typeof data.和文番号を起こす === 'boolean') { st.jaLift = data.和文番号を起こす; try { localStorage.setItem('fz.jaLift', st.jaLift ? '1' : '0'); } catch { } } msg('設定を読み込みました（既定の書式・体系・テンプレート）'); } catch (e) { msg('読み込めませんでした：' + e.message, true); } }
/* 大きな文書の解析は Worker で（画面を止めない）。file:// では別ファイルの Worker を作れないので、束ねたソース（fz-worker-src.js）から Blob で作る */
const BIG_TEXT = 3000000; /* これより大きい文字列だけ Worker で解析（Worker は往復の複製に時間がかかるので、数 MB までは本スレッドの方が速い。組版は段階的なので画面は止まらない） */ let worker = null, workerSeq = 0; const workerJobs = new Map();
function getWorker() {
  if (worker || !FZ.WORKER_SRC || typeof Worker !== 'function') return worker;
  try { const url = URL.createObjectURL(new Blob([FZ.WORKER_SRC], { type: 'text/javascript' })); worker = new Worker(url); worker.onmessage = e => { const d = e.data; const job = workerJobs.get(d.id); if (!job) return; workerJobs.delete(d.id); if (d.ok) job.res(d.doc); else job.rej(new Error(d.error)); }; worker.onerror = e => { for (const j of workerJobs.values()) j.rej(new Error(e.message || 'worker error')); workerJobs.clear(); }; } catch { worker = null; }
  return worker;
}
function parseText(text, kind, opts, format) { // kind: 'md' | 'fzk' → Promise<doc>。format：貼付のときの文書の書式
  const w = text.length > BIG_TEXT ? getWorker() : null;
  if (!w) return Promise.resolve(kind === 'md' ? FZ.fromMarkdown(text, format ? { ...FZ.newDoc(), format } : null, opts) : FZ.parse(text));
  msg('読み込み中…（' + Math.round(text.length / 1024) + ' KB）', false, 0);
  return new Promise((res, rej) => { const id = ++workerSeq; workerJobs.set(id, { res, rej }); w.postMessage({ id, kind, text, opts, format: format || null }); });
}
async function loadText(text, name, ref, keepDirty) {
  const isMd = /\.(md|markdown)$/i.test(name || '');
  let doc; try { doc = await parseText(text, isMd ? 'md' : 'fzk', {}, isMd ? JSON.parse(JSON.stringify(defaultFormat())) : null); } /* Markdown は既定の書式（本文の位置・戻り空き・体系）で組む */ catch (e) { msg('開けませんでした：' + e.message, true); return; }
  if (!doc.title && name) doc.title = name.replace(/\.[^.]+$/, '');
  if (isMd && !doc.format.header && doc.format.headerRows > 0 && doc.format.kind !== 'slide') doc.format.header = '{file}'; // Markdown を開いたら柱上にファイル名（{file}：保存し直すとその名前に。既定の書式で柱上を決めていればそちら）
  if (st.jaLift && /\.(md|txt)$/i.test(name || '')) { const n = FZ.liftJaMarkers(doc); if (n) msg('和文の番号・記号を ' + n + ' 行起こしました'); }
  st.file = ref || null; st.savedAt = 0; stampFile(); ed.setDoc(doc); setFileName(String(name || '').split(/[\\/]/).pop()); if (keepDirty) ed.dirty = true; if (ref && /\.(md|markdown|txt)$/i.test(name)) { ed.dirty = true; st.file = null; msg('.fzk として保存し直してください（元のファイルは変更しません）'); } else msg('開きました');
  clearRecovery(); st.mode = 'text'; drawFkeys(); drawSub(); render(); main.scrollTop = 0; focusTA(); if (st.side === 'hist') drawSide();
  if (st.file && !keepDirty) histPush(st.file, text, '開いたとき'); // 版の履歴：開いた時点の原本
  { const n = ed.countMdStars(); if (n >= 2) msg(`文中に ** が ${n} 個、文字のまま残っています。${K('mdStars')}（編集の「** を太字に」）で太字に直せます`); } // 以前に取り込んだ文書の救済
}
function openFile() { withDiscard(async () => { try { const r = await FZ.files.open(); if (!r) return; loadText(r.text, r.name, (r.handle || r.path) ? { handle: r.handle, path: r.path, name: r.name } : null); } catch (e) { msg('開けませんでした：' + e.message, true); } }); }
async function saveFile(saveAs, force = false) {
  if (st.composing) { msg('変換を確定してから保存してください', true); return false; }
  if (!saveAs && !force && st.file && st.file.mtime) { const o = await FZ.files.outside(st.file); if (o.changed) { conflictInfo = o; openForm('conflict'); return false; } } // 外で書き換えられていたら黙って上書きしない
  const text = FZ.serialize(ed.doc); const name = baseTitle() + '.fzk';
  try { const r = await FZ.files.save(text, saveAs ? null : st.file, name); if (!r) return false; st.file = { ...r }; ed.dirty = false; st.savedAt = Date.now(); stampFile(); histPush(st.file, text, saveAs ? '名前を付けて保存' : '保存'); if (r.name && r.name !== ed.doc.fileName) { setFileName(r.name); render(); } /* 柱の {file} を保存先の名前に */ clearRecovery(); msg('保存しました ' + new Date().toLocaleTimeString()); status(); if (FZ.files.kind === 'basic') msg('ダウンロードとして保存（このブラウザは直接保存に非対応）', true); return true; }
  catch (e) { msg('保存できませんでした：' + e.message, true); return false; }
}
/* 自動保存：5 分ごと。保存先（ファイルの参照）が決まっていて未保存の変更があるときだけ、同じファイルに上書きする。保存先が無い文書は復旧用の退避だけ */
const AUTOSAVE_MS = 5 * 60 * 1000;
setInterval(async () => { if (!ed.dirty || st.composing || !st.file || !(st.file.handle || st.file.path)) return; try { if (st.file.mtime) { const o = await FZ.files.outside(st.file); if (o.changed) { msg(`「${st.file.name}」が外で書き換えられたので自動保存しませんでした（${K('save')} で上書きか別名かを選べます）`, true, 0); return; } } const atext = FZ.serialize(ed.doc); await FZ.files.save(atext, st.file, st.file.name, { auto: true }); ed.dirty = false; st.savedAt = Date.now(); stampFile(); histPush(st.file, atext, '自動保存'); clearRecovery(); msg('自動保存 ' + new Date().toLocaleTimeString()); status(); } catch (e) { msg('自動保存できませんでした：' + e.message, true); } }, AUTOSAVE_MS);
let recTimer; function scheduleRecovery() { clearTimeout(recTimer); recTimer = setTimeout(saveRecovery, clamp(700 + ed.doc.lines.length / 10, 700, 15000)); } // 大きい文書ほど間隔を空ける（直列化が重い）
/* ---------- 複数の窓（最大 8） ----------
 * 窓ごとに番号（1〜8）を取り、復旧データを窓ごとに分ける（fz.recover.N）。生きている窓は 4 秒ごとに印（fz.slot.N）を更新し、
 * 15 秒更新の無い番号は空きとみなす。新しい窓は空いている一番小さい番号を取るので、落ちた窓の未保存の文書は次に開いた窓が引き継ぐ */
const MAX_WINDOWS = 8, SLOT_TTL = 15000; const WIN_ID = Math.random().toString(36).slice(2);
function slotInfo(n) { try { return JSON.parse(localStorage.getItem('fz.slot.' + n) || 'null'); } catch { return null; } }
function slotAlive(n) { const s = slotInfo(n); return !!(s && s.id !== WIN_ID && Date.now() - s.time < SLOT_TTL); }
function liveWindows() { let k = 0; for (let n = 1; n <= MAX_WINDOWS; n++) if (slotAlive(n) || st.slot === n) k++; return k; }
function claimSlot() { let pick = 0; const want = +(new URLSearchParams(location.search).get('w') || 0); if (want >= 1 && want <= MAX_WINDOWS && !slotAlive(want)) pick = want; for (let n = 1; n <= MAX_WINDOWS && !pick; n++) if (!slotAlive(n)) pick = n; st.slot = pick || 0; beat(); return st.slot; }
function beat() { if (!st.slot) return; try { localStorage.setItem('fz.slot.' + st.slot, JSON.stringify({ id: WIN_ID, time: Date.now() })); } catch { } }
const RECOVER_KEY = () => st.slot ? 'fz.recover.' + st.slot : 'fz.recover.x';
function newWindow() { if (liveWindows() >= MAX_WINDOWS) { msg(`窓は ${MAX_WINDOWS} つまでです。どれかを閉じてください`, true); return; } let free = 0; for (let n = 1; n <= MAX_WINDOWS && !free; n++) if (!slotAlive(n) && n !== st.slot) free = n; const url = location.href.split('?')[0].split('#')[0] + '?w=' + free; const w = window.open(url, '_blank', 'popup,width=1180,height=900'); if (!w) msg('新しい窓を開けませんでした（ポップアップが止められています）。文机を起動.bat をもう一度実行しても開けます', true); }
setInterval(beat, 4000);
window.addEventListener('pagehide', () => { try { const s = slotInfo(st.slot); if (s && s.id === WIN_ID) localStorage.removeItem('fz.slot.' + st.slot); } catch { } });
/* 復旧データの置き場。まず localStorage（同期で読めるので起動してすぐ戻せる）。上限（全窓あわせて 5MB ほど）を超える文書・画像は、
   全文を IndexedDB（上限が大きい）に置き、localStorage には印（full: 'idb'）と画像を除いた本文を残す。起動時は本文をすぐ戻し、画像はあとから IndexedDB から足す */
const RDB = (() => { let dbp = null;
  const open = () => dbp || (dbp = new Promise((res, rej) => { try { const r = indexedDB.open('fuzukue', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('blocked')); } catch (e) { rej(e); } }).catch(e => { dbp = null; throw e; }));
  const tx = (mode, f) => open().then(db => new Promise((res, rej) => { const t = db.transaction('kv', mode); const q = f(t.objectStore('kv')); t.oncomplete = () => res(q && q.result); t.onerror = t.onabort = () => rej(t.error); }));
  return { get: k => tx('readonly', x => x.get(k)), put: (k, v) => tx('readwrite', x => x.put(v, k)), del: k => tx('readwrite', x => x.delete(k)) }; })();
FZ.RDB = RDB; let idbHeld = false;
function saveRecovery() { if (!ed.dirty) return; const text = FZ.serialize(ed.doc); const key = RECOVER_KEY(); const rec = { text, name: st.file ? st.file.name : '', time: Date.now() };
  try { localStorage.setItem(key, JSON.stringify(rec)); if (idbHeld) { idbHeld = false; RDB.del(key).catch(() => { }); } return; } catch { }
  idbHeld = true; RDB.put(key, rec).catch(() => { }); const body = text.split('\n===\n#添付')[0] + '\n';
  try { localStorage.setItem(key, JSON.stringify({ ...rec, text: body, full: 'idb' })); } catch { try { localStorage.setItem(key, JSON.stringify({ ...rec, text: '', full: 'idb' })); } catch { } } }
function clearRecovery() { const key = RECOVER_KEY(); try { localStorage.removeItem(key); } catch { } idbHeld = false; RDB.del(key).catch(() => { }); }
/* 起動時：印が IndexedDB を指していたら全文を読み、画像を足す（本文が localStorage に無ければ文書ごと戻す） */
function restoreFromIdb(mark) { const key = RECOVER_KEY(); idbHeld = true;
  return RDB.get(key).then(v => { if (!v || !v.text || (v.time || 0) < (mark.time || 0)) { if (!mark.text) msg('前回の未保存の文書を IndexedDB から戻せませんでした', true, 0); else msg('前回の続きを復元（画像は戻せませんでした）', true, 8000); return; }
    const full = FZ.parse(v.text); if (mark.text) { ed.doc.images = { ...full.images, ...ed.doc.images }; ed.relayout(); render(); msg('前回の続きを復元（画像も戻しました）', false, 6000); }
    else { ed.setDoc(full); ed.dirty = true; st.file = v.name ? { name: v.name } : null; setFileName(v.name || ''); render(); msg('前回の続きを復元（未保存）', false, 8000); } }).catch(() => msg('前回の未保存の文書を IndexedDB から戻せませんでした', true, 0)); }
window.addEventListener('beforeunload', e => { saveRecovery(); if (ed.dirty) { e.preventDefault(); e.returnValue = ''; } });
/* ================= 書体 ================= */
/* 画面の書体：文書の書式（明朝の書体・ゴシックの書体）を CSS 変数に流す。同梱フォントは持たず、PC に入っている書体を使う */
let fontSig = '';
function applyFonts() {
  const f = ed.doc.format; const mi = f.fontMincho || 'BIZ UDMincho', go = f.fontGothic || 'BIZ UDGothic'; const sig = mi + '|' + go; if (sig === fontSig) return; fontSig = sig;
  const q = n => '"' + String(n).replace(/"/g, '') + '"';
  const al = n => { const o = FZ.officeFont ? FZ.officeFont(n) : { latin: n, ea: n }; return [q(n), q(o.latin), q(o.ea)].join(','); }; // 画面でも Windows の正式名（BIZ UD明朝 Medium など）で探せるように
  document.documentElement.style.setProperty('--mincho', `${al(mi)},"BIZ UDMincho","BIZ UDMincho Medium","BIZ UD明朝 Medium","Yu Mincho","游明朝","MS Mincho",serif`);
  document.documentElement.style.setProperty('--gothic', `${al(go)},"BIZ UDGothic","BIZ UDゴシック","Yu Gothic","游ゴシック","MS Gothic",sans-serif`);
}
/* インストール済み書体の一覧：Local Font Access API（Edge／Chrome、許可が要る）→ 無ければ候補を描画幅で判定 */
const FONT_CANDIDATES = ['BIZ UDMincho', 'BIZ UDMincho Medium', 'BIZ UD明朝 Medium', 'BIZ UDPMincho', 'BIZ UDPMincho Medium', 'BIZ UDGothic', 'BIZ UDゴシック', 'BIZ UDPGothic', '游明朝', '游ゴシック', 'ＭＳ 明朝', 'ＭＳ ゴシック', 'メイリオ', 'UD デジタル 教科書体 N-R', 'Yu Mincho', 'Yu Gothic', 'Yu Gothic UI', 'Meiryo', 'Meiryo UI', 'MS Mincho', 'MS PMincho', 'MS Gothic', 'MS PGothic', 'MS UI Gothic', 'UD Digi Kyokasho N-R', 'UD Digi Kyokasho NK-R', 'UD Digi Kyokasho NP-R', 'HGMinchoE', 'HGPMinchoE', 'HGGothicE', 'HGPGothicE', 'HGGothicM', 'HGSoeiKakugothicUB', 'HGMaruGothicMPRO', 'HGKyokashotai', 'HGSeikaishotaiPRO', 'HGGyoshotai', 'Noto Sans JP', 'Noto Serif JP', 'Noto Sans CJK JP', 'Noto Serif CJK JP', 'Source Han Sans', 'Source Han Serif', 'IPAexMincho', 'IPAexGothic', 'IPAMincho', 'IPAGothic', 'Hiragino Mincho ProN', 'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Hiragino Maru Gothic ProN', 'Klee', 'Toppan Bunkyu Mincho', 'Toppan Bunkyu Gothic', 'Tsukushi A Round Gothic', 'YuKyokasho', 'Osaka', 'Consolas', 'Courier New', 'Arial', 'Segoe UI', 'Georgia', 'Times New Roman'];
function fontAvailable(name) { const c = document.createElement('canvas').getContext('2d'); const t = 'あいう漢字Wgmi12'; const w = fam => { c.font = `20px ${fam}`; return c.measureText(t).width; }; const a = w('monospace'), b = w('serif'); const q = `"${name}"`; return w(`${q},monospace`) !== a || w(`${q},serif`) !== b; }
/* full：Local Font Access API で全書体を読む（許可が要る）。既定は候補の描画幅で判定（許可不要・すぐ終わる） */
async function loadFontList(full) {
  let names = null;
  if (full && typeof window.queryLocalFonts === 'function') { try { const fonts = await window.queryLocalFonts(); names = [...new Set(fonts.map(x => x.family))]; } catch (e) { names = null; } }
  if (!names || !names.length) names = FONT_CANDIDATES.filter(fontAvailable);
  const ja = n => /[\u3040-\u30ff\u4e00-\u9fff]|Mincho|Gothic|Kyokasho|Meiryo|Hiragino|Noto (Sans|Serif) (JP|CJK)|Source Han|IPA|BIZ|UD /i.test(n);
  names.sort((a, b) => (ja(b) - ja(a)) || a.localeCompare(b, 'ja')); st.fontList = names; try { localStorage.setItem('fz.fontList', JSON.stringify(names)); } catch { }
}
/* 書体の選択欄：一覧（和文の書体が先）＋今の値。一覧が無ければ開いたときに候補から判定する */
function fontOptions(cur) { const list = st.fontList && st.fontList.length ? st.fontList : FONT_CANDIDATES.filter(fontAvailable); if (!st.fontList || !st.fontList.length) st.fontList = list; const all = list.includes(cur) ? list : [cur, ...list]; const o = FZ.officeFont ? FZ.officeFont(cur) : { latin: cur, ea: cur }; const have = list.includes(cur) || [cur, o.latin, o.ea].some(fontAvailable); return all.map(n => `<option value="${esc(n)}"${n === cur ? ' selected' : ''} style="font-family:'${esc(n).replace(/'/g, '')}'">${esc(n)}${n === cur && !list.includes(cur) ? (have ? (o.ea !== cur ? '（= ' + esc(o.ea) + '）' : '') : '（この PC に無い）') : ''}</option>`).join(''); }
function fontPicker(name, cur) { return `<select name="${name}" class="font">${fontOptions(cur)}</select>`; }
try { st.fontList = JSON.parse(localStorage.getItem('fz.fontList') || 'null') || null; } catch { }
try { st.jaLift = localStorage.getItem('fz.jaLift') === '1'; } catch { }
/* ================= 図版の画像（資料書式） =================
 * 原本は base64 のまま持ち、表示・印刷は Blob の URL で。白黒の印刷イメージに合わせて、画像は灰色に落として網点（45°、1.5pt）にする。
 * 真っ黒・真っ白に近い所はそのまま（グラフの線や文字が崩れない）。網点化は非同期で、できるまでは元の画像を出す */
const IMGC = new Map(); const HT_S = 4, HT_PITCH = 1.5;
function b64ToBlob(img) { const bin = atob(img.data); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: img.mime }); }
function imgRec(name, img) { let r = IMGC.get(name); if (!r || r.data !== img.data) { if (r) { URL.revokeObjectURL(r.url); for (const h of r.ht.values()) if (h.url && h.url !== r.url) URL.revokeObjectURL(h.url); } r = { data: img.data, url: URL.createObjectURL(b64ToBlob(img)), ht: new Map() }; IMGC.set(name, r); } return r; }
const htKey = (w, h) => Math.round(w * 2) + 'x' + Math.round(h * 2);
function imageHref(name, img, w, h) {
  let r; try { r = imgRec(name, img); } catch { return `data:${img.mime};base64,${img.data}`; }
  const k = htKey(w, h); let e = r.ht.get(k); if (e && e.url) return e.url;
  if (!e) { e = {}; r.ht.set(k, e); e.p = halftoneImage(r.url, w, h).then(u => { e.url = u; }).catch(() => { e.url = r.url; }).then(() => { pageCache = pageCache.map(() => ''); requestRender(); }); }
  return r.url;
}
async function prepareImages() { const lay = ed.lay, ps = []; for (const pg of lay.pages) for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) { const img = lay.images && lay.images[im.file]; if (!img) continue; const w = im.w * lay.geo.cw, h = im.h * lay.geo.ch; imageHref(im.file, img, w, h); const e = IMGC.get(im.file) && IMGC.get(im.file).ht.get(htKey(w, h)); if (e && e.p) ps.push(e.p); } await Promise.all(ps); }
async function halftoneImage(url, wPt, hPt) {
  const im = new Image(); im.src = url; await im.decode(); const nw = im.naturalWidth || 300, nh = im.naturalHeight || 225;
  const sc = Math.min(wPt / nw, hPt / nh); const W = Math.max(1, Math.round(nw * sc * HT_S)), H = Math.max(1, Math.round(nh * sc * HT_S));
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.drawImage(im, 0, 0, W, H);
  const d = ctx.getImageData(0, 0, W, H), px = d.data; const P = HT_PITCH * HT_S, R = Math.SQRT1_2;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const o = (y * W + x) * 4; const ink = 1 - (0.299 * px[o] + 0.587 * px[o + 1] + 0.114 * px[o + 2]) / 255; let black;
    if (ink < 0.06) black = false; else if (ink > 0.94) black = true;
    else { const u = R * (x + y) / P, v = R * (y - x) / P; const X = 2 * (u - Math.floor(u)) - 1, Y = 2 * (v - Math.floor(v)) - 1; const ax = Math.abs(X), ay = Math.abs(Y); const s = ax + ay <= 1 ? 1 - (X * X + Y * Y) : (ax - 1) * (ax - 1) + (ay - 1) * (ay - 1) - 1; black = ink > (1 - s) / 2; } // ユークリッドの網点
    const c = black ? 0 : 255; px[o] = px[o + 1] = px[o + 2] = c; px[o + 3] = black ? 255 : 0; }
  ctx.putImageData(d, 0, 0); const blob = await new Promise(res => cv.toBlob(res, 'image/png')); return URL.createObjectURL(blob);
}
/* 画像を選ぶ（PNG／JPEG／GIF／SVG／WebP）→ { name, mime, data } */
function pickImage() { return new Promise(res => { const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/png,image/jpeg,image/gif,image/svg+xml,image/webp'; inp.onchange = () => { const f = inp.files[0]; if (!f) return res(null); readImageBlob(f, f.name).then(res, e => { msg('画像を読めませんでした：' + e.message, true); res(null); }); }; inp.click(); }); }
function readImageBlob(blob, name = '') { return new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => { const m = String(fr.result).match(/^data:([^;,]+);base64,(.*)$/); if (!m || !/^image\//.test(m[1])) return rej(new Error('画像ではありません')); res({ name, mime: m[1], data: m[2] }); }; fr.onerror = () => rej(fr.error || new Error('読めません')); fr.readAsDataURL(blob); }); }
function addImageFigure(r) { const nm = ed.addImage(r.mime, r.data, r.name); const id = ed.addFigure({ file: nm, kind: '図', title: '' }); st.figSel = id; openForm('fig');
  const mb = r.data.length * 3 / 4 / 1048576; msg((ed.doc.format.kind === 'slide' ? '図表欄に置きました' : '行の下に置きました') + '：題を入れて Enter' + (mb > 3 ? `（画像が ${mb.toFixed(1)}MB と大きいので、原本も大きくなります）` : ''), mb > 3); }
/* 画面上の図版（画像と番号・題の行）に当たったか */
function figHit(g) { const pg = ed.lay.pages[g.page]; if (!pg) return null; for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) if (g.col >= im.col && g.col < im.col + im.w && g.row >= im.y - 1 && g.row < im.y + im.h) return im; return null; }
FORMS.fig = {
  cur() { return ed.figById(st.figSel); },
  html() { const x = this.cur(); if (!x) return `<span class="ttl">図表</span><span class="info alert">図表がありません</span><button type="button" data-act="cancel">閉じる Esc</button>`; const fg = x.fg; const n = ed.lay.figNums && ed.lay.figNums.get(fg.id); const L = ed.figList(); const idx = L.findIndex(y => y.fg.id === fg.id);
    return `<span class="ttl">図表 ${esc(n ? n.label : '')}（${idx + 1}/${L.length}）</span><label>種別 ${cyc('kind', [['図', '図'], ['表', '表']], fg.kind)}</label><label>題 ${inp('title', fg.title, 'w')}</label><label>幅 ${cyc('width', [['100', '欄いっぱい'], ['75', '75%'], ['50', '50%（2 つ並ぶ）']], String(fg.width))}</label>
      <button type="button" data-act="prev" title="前の図表を開く">← 前</button><button type="button" data-act="next" title="次の図表を開く">次 →</button><button type="button" data-act="up" title="順番を 1 つ前へ（番号も変わる）">↑ 前へ送る</button><button type="button" data-act="down" title="順番を 1 つ後ろへ">↓ 後へ送る</button><button type="button" data-act="ref" title="本文の今の位置に「${esc(n ? n.label : '図')}」を入れる">図番</button><button type="button" data-act="replace" title="画像を別のものに差し替える">差し替え…</button><button type="button" data-act="del">削除</button>
      <span class="info" title="${ed.doc.format.kind === 'slide' ? '' : '文書の書式では本文の流れ（行の下）に置く。資料書式なら右の図表欄'}">${esc(fg.file || '（画像なし）')}</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'input[name="title"]', enter() { this.act('apply'); },
  read() { return { kind: cycVal('kind'), title: fval('title').trim(), width: +cycVal('width') }; },
  save() { const x = this.cur(); if (!x) return; const v = this.read(); if (v.kind !== x.fg.kind || v.title !== x.fg.title || v.width !== x.fg.width) ed.setFig(x.fg.id, v); },
  act(a) { const x = this.cur(); if (a === 'cancel' || !x) { closeForm(); return; }
    if (a === 'apply') { this.save(); closeForm(); return; }
    this.save();
    if (a === 'prev' || a === 'next') { const L = ed.figList(); const i = L.findIndex(y => y.fg.id === x.fg.id); const t = L[i + (a === 'next' ? 1 : -1)]; if (t) { st.figSel = t.fg.id; drawSub(); } else msg(a === 'next' ? '最後の図表です' : '最初の図表です'); return; }
    if (a === 'up' || a === 'down') { if (!ed.moveFig(x.fg.id, a === 'up' ? -1 : 1)) msg('これ以上動かせません'); drawSub(); return; }
    if (a === 'del') { ed.removeFig(x.fg.id); closeForm(); msg('図表を削除しました（Ctrl+Z で戻す。文中の図番は「図 ?」になります）'); return; }
    if (a === 'ref') { closeForm(); ed.insertRef(x.fg.id); return; }
    if (a === 'replace') { pickImage().then(r => { if (!r) return; const nm = ed.addImage(r.mime, r.data, r.name); ed.setFig(x.fg.id, { file: nm }); drawSub(); }); return; } } };
/* ツリーで探す（G3）：当たった節に印、Enter で次の節へ（畳まれた所・深さの外なら開いて見せる） */
const treeNorm = t => String(t || '').normalize('NFKC').toLowerCase();
function treeFindHits() { const q = treeNorm(st.tree.find).trim(); if (!q) return []; const tr = FZ.tree.build(ed.doc, { body: true, figs: true, sentences: st.tree.depth === -1, figLabel: fg => fg.title || '' }); const all = [...tr.nodes, ...(tr.figs || []), ...(tr.sents || [])].filter(n => !n.root && treeNorm(n.text).includes(q)); all.sort((a, b) => a.line - b.line || (a.kind === 'sent' ? a.si + 1 : 0) - (b.kind === 'sent' ? b.si + 1 : 0)); return all; }
function treeFindStep(d) { const hits = treeFindHits(); if (!hits.length) { msg('見つかりません', true); return; } const cur = treeNodeSel(); const keys = hits.map(treeKey); let k = keys.indexOf(st.tree.sel);
  if (k < 0) { const L = cur && cur.line != null ? cur.line : -1; k = d > 0 ? hits.findIndex(n => n.line > L) : (() => { let j = -1; hits.forEach((n, i) => { if (n.line < L) j = i; }); return j; })(); if (k < 0) k = d > 0 ? 0 : hits.length - 1; } else k = (k + d + hits.length) % hits.length;
  const n = hits[k]; const body = n.kind === 'body' || n.kind === 'block' || n.kind === 'fig'; if (n.kind === 'sent' && st.tree.depth !== -1) st.tree.depth = -1; else if (body && st.tree.depth > 0) st.tree.depth = 0; else if (st.tree.depth > 0 && st.tree.depth !== 9) st.tree.depth = 9;
  for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); }
  st.tree.sel = keys[k]; render(); treeScrollToSel(); const info = sub.querySelector('.tfinfo'); if (info) info.textContent = `${k + 1}/${hits.length} 件`; status(); }
FORMS.tfind = {
  html() { const q = st.tree.find || ''; const h = treeFindHits(); const k = h.map(treeKey).indexOf(st.tree.sel);
    return `<span class="ttl">ツリーで探す</span><label>${inp('q', q, 'w')}</label><button type="button" data-act="prev" title="前の節（Shift+Enter）">↑ 前</button><button type="button" data-act="next" title="次の節（Enter）">次 ↓</button><span class="info tfinfo">${q ? (h.length ? (k >= 0 ? `${k + 1}/` : '') + `${h.length} 件` : '見つかりません') : '見出し・箇条書き・本文・図表の題'}</span><span class="hintl">当たった節に破線の印。紙面の検索・置換は Esc で紙面へ戻ってから</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'input[name="q"]',
  change(name) { if (name !== 'q') return; st.tree.find = fval('q'); render(); const h = treeFindHits(); const info = sub.querySelector('.tfinfo'); if (info) info.textContent = st.tree.find.trim() ? (h.length ? `${h.length} 件` : '見つかりません') : ''; },
  enter(e) { this.act(e && e.shiftKey ? 'prev' : 'next'); },
  act(a) { if (a === 'cancel') { st.tree.find = ''; closeForm(); render(); return; } if (a === 'next' || a === 'prev') treeFindStep(a === 'next' ? 1 : -1); } };
/* 構造から図（R3）：節と子（見出し・箇条書き）を箱と矢印の構成図に自動で並べる。手で直すのは微調整だけ */
function figTreeRoot() { if (st.mode === 'tree') { const n = treeNodeSel(); const v = st.tree.view; return n && !n.root && n.kind !== 'body' && n.kind !== 'sent' && n.kind !== 'block' && n.kind !== 'fig' ? n : v ? v.top : null; }
  const tr = FZ.tree.build(ed.doc, {}); const L = ed.caret.line; let best = null; for (const n of tr.nodes) if (n.line <= L && n.end >= L && !n.root && (n.kind === 'num' || n.kind === 'sym' || n.kind === 'title') && (!best || n.depth > best.depth)) best = n; if (!best) best = tr.root.children.length === 1 ? tr.root.children[0] : tr.root; return best; }
function figFromTree(dir, maxDepth) {
  const root = figTreeRoot(); if (!root) return; const kids = n => (n.children || []).filter(c => c.kind === 'num' || c.kind === 'sym' || c.kind === 'list' || c.kind === 'title');
  if (!kids(root).length) { msg('この節には子（見出し・箇条書き）がありません', true); return; }
  let N = 0; const mk = (n, d) => { N++; const o = { src: n, d, children: [] }; if (d < maxDepth) for (const c of kids(n)) { if (N >= 40) break; o.children.push(mk(c, d + 1)); } return o; }; const T = mk(root, 0);
  const endLine = root.root ? ed.doc.lines.length - 1 : root.end; const host = ed.lay.lineMap[Math.min(endLine, ed.lay.lineMap.length - 1)]; const r0 = host && host.segs[0].rows[0]; const W = Math.max(16, r0 ? Math.floor(r0.right - r0.left) : ed.lay.geo.cols); const maxH = Math.max(8, ed.lay.geo.rows - 2);
  let depthN = 0; const walk = (o) => { depthN = Math.max(depthN, o.d + 1); o.children.forEach(walk); }; walk(T);
  const label = o => String(o.src.root ? (ed.doc.title || '文書') : o.src.text || '').replace(/\s+/g, ' ').trim().slice(0, 28) || '（空）';
  const tryLayout = d0 => { const gapD = d0 === 'h' ? 3 : 2, gapS = 1; const colW = d0 === 'h' ? Math.max(6, Math.min(16, Math.floor((W - gapD * (depthN - 1)) / depthN))) : 12;
    const size = o => { const tw = FZ.textWidth(label(o)); const w = Math.max(4, Math.min(colW, Math.ceil(tw) + 2)); const lines = Math.max(1, Math.ceil(tw / Math.max(1, w - 2))); return { w, h: Math.min(4, lines) + 2 }; };
    const L = FZ.tree.layout(T, { dir: d0, visible: o => o.children, size, gapDepth: gapD, gapSib: gapS }); return { L, size }; };
  let use = dir, R = tryLayout(dir); const fits = R2 => R2.L.W <= W && R2.L.H + 2 <= maxH;
  if (!fits(R) && dir === 'v') { const R2 = tryLayout('h'); if (fits(R2) || R2.L.W <= W) { use = 'h'; R = R2; } }
  if (R.L.W > W + 0.5) { msg(`構成図が欄の幅（${W} 字）に収まりません。深さを浅くしてください`, true); return; }
  const boxes = [], arrows = [], ids = new Map(); let id = 0, H = 0; const all = []; const walk2 = o => { all.push(o); o.children.forEach(walk2); }; walk2(T);
  for (const o of all) { const p = R.L.pos.get(o); const x = Math.max(0, Math.min(W - p.w, Math.round(p.x))), y = Math.round(p.y) + 1; ids.set(o, ++id); boxes.push({ id, x, y, w: p.w, h: p.h, text: label(o), kind: o === T ? 'thick' : 'thin', shade: o === T ? 'gray' : null, bold: o === T || o.d === 1 }); H = Math.max(H, y + p.h + 1); }
  for (const o of all) for (const c of o.children) arrows.push({ from: ids.get(o), to: ids.get(c), label: '', kind: 'thin' });
  if (H > maxH) { msg(`構成図が 1 頁に収まりません（${H} 行）。深さを浅くするか、下の節で作ってください`, true); return; }
  const fig = FZ.normalizeFigure({ h: H, boxes, arrows, lanes: null }); let at = -1;
  ed.mutate('', () => { at = endLine + 1; while (at < ed.doc.lines.length && FZ.inTable(ed.doc, at)) at++; ed.insertLine(at, { segs: [FZ.newSeg(0, '')], attrs: { figure: fig } }); if (at + 1 >= ed.doc.lines.length) ed.insertLine(at + 1, FZ.newLine()); ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; });
  if (st.mode === 'tree') { st.tree.sel = ed.doc.lines[at]; treeRefresh(); } else { render(); scrollToCaret(true); }
  msg(`「${label(T)}」の構成図を節の後ろに入れました（${all.length} 個の箱。${use === 'h' ? '左から右へ' : '上から下へ'}${use !== dir ? '：上から下では幅に収まらないため' : ''}）。箱の位置は図の中で直せます（Enter）`, false, 8000); }
FORMS.figtree = {
  html() { const r = figTreeRoot(); const name = r ? String(r.root ? (ed.doc.title || '文書') : r.text).slice(0, 20) : ''; return `<span class="ttl">構成図を作る</span><span class="info">「${esc(name)}」と子の見出し・箇条書き</span><label>深さ ${cyc('depth', [['1', '子まで'], ['2', '孫まで'], ['3', '3 段まで']], String(st.figTreeDepth || 2))}</label><button type="button" class="pri" data-act="h"><span class="kk">1</span>左から右へ</button><button type="button" data-act="v"><span class="kk">2</span>上から下へ</button><span class="hintl">節の後ろに図として入る。並べ直しは図の中で</span><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'button.pri', key(e) { if (e.key === '1' || e.key === '2') { e.preventDefault(); this.act(e.key === '1' ? 'h' : 'v'); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a !== 'h' && a !== 'v') return; const d = +cycVal('depth') || 2; st.figTreeDepth = d; closeForm(); figFromTree(a, d); } };
/* 送り先を選んで移す（S3）：見出しの一覧から移し先。紙面はカーソルの節（範囲なら複数）、ツリーは選んだ節 */
function moveTargets() { const tr = FZ.tree.build(ed.doc, {}); const out = [{ n: tr.root, label: '（文書のいちばん上の段）', depth: 0, obj: null }]; for (const n of tr.nodes) if (n.kind === 'title' || n.kind === 'num' || n.kind === 'sym') out.push({ n, label: (treeMarker(n) ? treeMarker(n) + ' ' : '') + n.text, depth: n.depth, obj: n.obj }); return out; }
FORMS.moveTo = {
  html() { const q = st.moveQ || ''; const all = moveTargets(); const nq = treeNorm(q); const L = all.filter(t => !nq || treeNorm(t.label).includes(nq)).slice(0, 300); if (st.moveIdx == null || st.moveIdx >= L.length) st.moveIdx = 0;
    return `<span class="ttl">送り先を選んで移す</span><label>${inp('q', q, 'w', 'text', 'placeholder="見出しの文字で絞る"')}</label><label>${cyc('rel', [['child', '子の末尾へ'], ['before', 'その前へ'], ['after', 'その後へ']], 'child')}</label><span class="hintl">↑↓ で選び Enter（子と本文ごと移る）</span><button type="button" data-act="cancel">取消 Esc</button><div class="mvlist">${L.map((t, i) => `<button type="button" class="mv${i === st.moveIdx ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'}</div>`; },
  list() { const nq = treeNorm(st.moveQ || ''); return moveTargets().filter(t => !nq || treeNorm(t.label).includes(nq)).slice(0, 300); },
  focus: 'input[name="q"]',
  change(name) { if (name === 'q') { st.moveQ = fval('q'); st.moveIdx = 0; const box = sub.querySelector('.mvlist'); if (box) { const L = this.list(); box.innerHTML = L.map((t, i) => `<button type="button" class="mv${i === 0 ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'; } } if (name === 'rel') st.moveRel = cycVal('rel'); },
  key(e) { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const L = sub.querySelectorAll('.mvlist .mv'); if (!L.length) return; st.moveIdx = Math.max(0, Math.min(L.length - 1, (st.moveIdx || 0) + (e.key === 'ArrowDown' ? 1 : -1))); L.forEach((b, i) => b.classList.toggle('on', i === st.moveIdx)); L[st.moveIdx].scrollIntoView({ block: 'nearest' }); } },
  enter() { this.act('m' + (st.moveIdx || 0)); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^m(\d+)$/); if (!m) return; const t = this.list()[+m[1]]; if (!t) return; const rel = t.obj ? (cycVal('rel') || 'child') : 'child'; st.moveRel = cycVal('rel') || st.moveRel; closeForm();
    const go = () => { const v = st.tree.view; const tr = v.tr; const target = t.obj ? tr.byObj.get(t.obj) : tr.root; if (!target) { msg('移し先が見つかりません', true); return; } treeMoveSel(list => FZ.tree.move(ed, tr, list, target, rel)); };
    if (st.mode === 'tree') { go(); return; } const u0 = ed.undoStack.length; withCaretNode(go, { noSent: true }); if (ed.undoStack.length !== u0) msg(`「${t.label.slice(0, 20)}」の${{ child: '子の末尾', before: '前', after: '後' }[rel]}へ移しました（Ctrl+Z で戻す）`); } };
/* 節の参照（S5）：見出しを選ぶと本文に「2. 構成」。中身は見出しの名札への参照なので、並べ替え・番号の付け替えに追う */
FORMS.secref = {
  list() { const nq = treeNorm(st.secQ || ''); return moveTargets().filter(t => t.obj && (!nq || treeNorm(t.label).includes(nq))).slice(0, 300); },
  html() { const L = this.list(); if (st.secIdx == null || st.secIdx >= L.length) st.secIdx = 0; return `<span class="ttl">節の参照を入れる</span><label>${inp('q', st.secQ || '', 'w', 'text', 'placeholder="見出しの文字で絞る"')}</label><span class="hintl">↑↓ で選び Enter。本文に「番号 題」が入り、並べ替えても追う</span><button type="button" data-act="cancel">取消 Esc</button><div class="mvlist">${L.map((t, i) => `<button type="button" class="mv${i === st.secIdx ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見出しがありません</span>'}</div>`; },
  focus: 'input[name="q"]',
  change(name) { if (name !== 'q') return; st.secQ = fval('q'); st.secIdx = 0; const box = sub.querySelector('.mvlist'); if (box) box.innerHTML = this.list().map((t, i) => `<button type="button" class="mv${i === 0 ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'; },
  key(e) { FORMS.moveTo.key.call(this, e); if (e.key === 'ArrowDown' || e.key === 'ArrowUp') st.secIdx = st.moveIdx; },
  enter() { this.act('m' + (st.secIdx || 0)); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^m(\d+)$/); if (!m) return; const t = this.list()[+m[1]]; if (!t) return; st.secQ = ''; closeForm();
    let an = t.obj.attrs.anchor; if (!an) { const used = new Set(ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean)); let k = 1; while (used.has('h' + k)) k++; an = 'h' + k; ed.mutate('', () => { t.obj.attrs.anchor = an; }); }
    ed.insertRef('§' + an); msg(`節の参照を入れました：${(ed.lay.figNums && ed.lay.figNums.get('§' + an) || {}).label || t.label}（見出しが動いても番号が追う）`); } };
/* 構成の型（S6）：骨組み（見出しと、何を書くかの手引き）を流し込む。霞が関の資料は体系も「霞が関」に */
const SKELETONS = [
  { id: 'report', name: '報告書', kasumi: false, body: '[表題]〇〇に関する報告\n[番号1]目的\n（何を報告し、何を決めてほしいかを 1 文で）\n[番号1]背景\n（なぜ今この報告か）\n[番号1]現状\n（数字と事実で）\n[番号1]課題\n（現状と目標の差）\n[番号1]対応策\n[項目1]（案 1）\n[項目1]（案 2）\n[番号1]今後の予定\n（いつ・誰が・何を）\n' },
  { id: 'plan', name: '企画書', kasumi: false, body: '[表題]〇〇の企画\n[番号1]企画の概要\n（ひと言で何をするか）\n[番号1]背景と課題\n[番号1]ねらい\n（目的と目標の数字）\n[番号1]内容\n[番号2]具体策\n[項目1]（施策）\n[番号1]体制とスケジュール\n[番号1]費用と効果\n[番号1]リスクと対応\n' },
  { id: 'minutes', name: '議事録', kasumi: false, body: '[表題]〇〇会議　議事録\n日時：\n場所：\n出席者：\n[番号1]議題\n[項目1]（議題 1）\n[番号1]議事の概要\n[番号1]決定事項\n[項目1]（決めたこと）\n[番号1]今後の対応\n[項目1]（担当・期限・内容）\n' },
  { id: 'prep', name: '提案（結論から：PREP）', kasumi: false, body: '[表題]〇〇の提案\n[番号1]結論\n（提案を 1 文で）\n[番号1]理由\n[項目1]（理由 1）\n[項目1]（理由 2）\n[番号1]具体例・根拠\n[番号1]結論（再掲）と依頼\n' },
  { id: 'kasumi1', name: '霞が関：説明資料（1 枚もの）', kasumi: true, body: '[表題]〇〇について（案）\n[番号1]背景・経緯\n[項目1]（いつ・何があったか）\n[番号1]現状と課題\n[記号1]現状\n[項目1]（数字・事実）\n[記号1]課題\n[項目1]（何が問題か）\n[番号1]対応の方向性\n[項目1]（基本的な考え方）\n[番号1]具体的な取組\n[番号2]（取組 1）\n[項目1]（内容）\n[番号2]（取組 2）\n[項目1]（内容）\n[番号1]今後のスケジュール\n[項目1]〇月　（予定）\n' },
  { id: 'kasumi2', name: '霞が関：論点整理（検討会資料）', kasumi: true, body: '[表題]〇〇に関する論点整理（案）\n[番号1]検討の経緯\n[項目1]（これまでの検討会の開催状況）\n[番号1]主な論点\n[番号2]論点 1：〇〇をどう考えるか\n[記号1]これまでの主な意見\n[項目1]（意見）\n[記号1]考えられる対応\n[項目1]（案）\n[番号2]論点 2：〇〇の範囲\n[記号1]これまでの主な意見\n[項目1]（意見）\n[番号1]今後の検討の進め方\n[項目1]（次回までに整理すること）\n' },
  { id: 'kasumi3', name: '霞が関：事業概要（予算要求）', kasumi: true, body: '[表題]〇〇事業\n[番号1]事業の目的・必要性\n[項目1]（政策目標と、なぜ国が行うか）\n[番号1]事業の概要\n[項目1]（何を・どのように）\n[番号1]事業スキーム\n[項目1]国　→　（補助・委託先）　→　（対象）\n[番号1]期待される効果（成果目標）\n[項目1]（KPI と目標年度）\n[番号1]予算額\n[項目1]令和〇年度要求額　〇〇億円（前年度　〇〇億円）\n' },
  { id: 'kasumi4', name: '霞が関：報告書（答申・中間とりまとめ）', kasumi: true, body: '[表題]〇〇について（中間とりまとめ）\n[記号1]はじめに\n（審議の経緯と、この文書の位置づけ）\n[番号1]現状と課題\n[番号2]（項目）\n[番号1]基本的な考え方\n[番号1]具体的な方策\n[番号2]（方策 1）\n[番号2]（方策 2）\n[番号1]今後の進め方\n[記号1]おわりに\n' },
];
FORMS.skeleton = {
  html() { return `<span class="ttl">構成の型</span>${SKELETONS.map((t, i) => `<button type="button" class="${t.kasumi ? 'kasumi' : ''}" data-act="t${i}"><span class="kk">${i + 1}</span>${esc(t.name)}</button>`).join('')}<label>${cyc('where', [['here', 'カーソルの後ろに'], ['new', '新しい文書で']], st.skelWhere || (ed.doc.lines.length <= 1 && !ed.doc.lines[0].segs[0].text ? 'new' : 'here'))}</label><span class="hintl">見出しと「何を書くか」の手引き（ ）が入る。霞が関の型は体系も「霞が関」（1. （1） ① と ○ ・）に</span><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'button', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('t' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^t(\d+)$/); const t = m && SKELETONS[+m[1]]; if (!t) return; const where = cycVal('where') || 'here'; st.skelWhere = where; closeForm(); if (st.mode === 'tree') exitTree(false);
    const preset = t.kasumi ? FZ.SCHEME_PRESETS.find(p => p.name === '霞が関') : null; const src = FZ.parse('#fzk 2\n---\n' + t.body);
    const applyPreset = f => { if (!preset) return; f.scheme = FZ.normalizeScheme(preset.num); f.symScheme = FZ.normalizeScheme(preset.sym, FZ.DEFAULT_SYM); f.bulletScheme = FZ.normalizeScheme(preset.bullet, FZ.DEFAULT_BULLET); f.titleLevels = preset.title; };
    if (where === 'new') { const go = () => { const d = FZ.newDoc(); d.format = JSON.parse(JSON.stringify(ed.doc.format)); applyPreset(d.format); d.lines = src.lines; d.title = ''; ed.setDoc(FZ.normalize(d)); st.file = null; render(); msg(`「${t.name}」の型で新しい文書を作りました（（ ）の手引きを書き換える）`); }; withDiscard(go, '新しくする'); return; }
    let at = ed.caret.line + 1; while (at < ed.doc.lines.length && FZ.inTable(ed.doc, at)) at++; if (ed.doc.lines.some(l => l.attrs.style === 'title') && src.lines[0] && src.lines[0].attrs.style === 'title') src.lines.shift(); /* 題のある文書へは題の行を除いて */ ed.mutate('', () => { src.lines.forEach((ln, k) => ed.insertLine(at + k, ln)); if (preset) applyPreset(ed.doc.format); ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; }); render(); scrollToCaret(true);
    msg(`「${t.name}」の骨組みを入れました（${src.lines.length} 行${preset ? '・体系を「霞が関」に' : ''}。Ctrl+Z で戻す）`, false, 7000); } };
/* 保留の島（S4）：使うか決めていない節・文を文書の外に退避。原本には残り、組版・書き出し・AI に渡す Markdown には出ない */
const parkLabel = lines => String((lines.find(l => l.segs.some(sg => sg.text.trim())) || lines[0]).segs.map(sg => sg.text).join(' ')).replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕').replace(/\s+/g, ' ').trim().slice(0, 30) || '（空）';
function parkPush(lines) { const used = new Set((ed.doc.parked || []).map(p => p.id)); let k = 1; while (used.has('p' + k)) k++; (ed.doc.parked = ed.doc.parked || []).push({ id: 'p' + k, label: parkLabel(lines), lines: JSON.parse(JSON.stringify(lines)) }); }
function parkSel() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode();
  const doRanges = (ranges, sentNode) => { if (sentNode) { const n = sentNode; const seg = n.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); const x = ss[n.si]; if (!x) return false; ed.mutate('', () => { { const t0 = x.text.replace(/^[ 　]+/, ''), off = x.start + (x.text.length - t0.length), t1 = t0.replace(/[ 　]+$/, ''); const sg2 = FZ.newSeg(0, t1); sg2.marks = seg.marks.slice(off, off + t1.length); parkPush([{ segs: [sg2], attrs: {} }]); } ed.spliceSeg(seg, x.start, x.end, '', []); }); return true; }
    if (!ranges.length) return false; ed.mutate('', () => { for (const [a, b] of ranges.sort((p, q) => q[0] - p[0])) { parkPush(ed.doc.lines.slice(a, b + 1)); FZ.tree.removeRange(ed, a, b); } }); return true; };
  let done = false;
  if (st.mode === 'tree') { const sel = treeSelected().filter(n => !n.root && n !== st.tree.view.top && n.kind !== 'fig'); const sent = sel.length === 1 && sel[0].kind === 'sent' ? sel[0] : null; const tops = sel.filter(n => n.kind !== 'sent' && !sel.some(m => m !== n && FZ.tree.isAncestor(m, n)));
    done = doRanges(tops.map(n => [n.line, n.end]), sent); if (done) treeRefresh(); }
  else { const s2 = ed.sel(); if (sentSelOk()) { const tr = FZ.tree.build(ed.doc, { body: true, sentences: true }); const ln = ed.doc.lines[ed.caret.line]; const n = tr.sents.find(x => x.obj === ln && x.si === st.sentSel.si); if (n) done = doRanges([], n); st.sentSel = null; ed.anchor = null; }
    else if (s2 && s2.a.line !== s2.b.line) done = doRanges([[s2.a.line, s2.b.line]]);
    else { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(ed.doc.lines[ed.caret.line]); if (n && !(n.root || n === tr.root)) done = doRanges([[n.line, n.end]]); }
    if (done) { render(); requestOverlay(); } }
  msg(done ? `保留の島へ送りました（${(ed.doc.parked || []).length} 件。${K('parkList')} で見る・戻す。書き出しには出ない）` : '保留へ送るものがありません（節・文・範囲を選ぶ）', !done); }
/* 島の全文：保留した行を書き出しと同じ字（番号・記号つき）で */
/* 島の全文（HTML）：番号・記号と段の字下げ付きで読める形に（番号は島の中で数え直す） */
function parkHtml(p) { const f = ed.doc.format, S = FZ.normalizeScheme(f.scheme), SY = FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM), BU = FZ.normalizeScheme(f.bulletScheme || FZ.DEFAULT_BULLET, FZ.DEFAULT_BULLET), LS = FZ.normalizeScheme(f.listScheme || FZ.DEFAULT_LIST, FZ.DEFAULT_LIST);
  const cnt = [], lc = [], out = []; let base = 0;
  for (const ln of p.lines) { const a = ln.attrs, t = FZ.expandRefsText(ed.doc, ln.segs.map(sg => sg.text).join('　')); let mk = '', ind = base, bold = false;
    if (a.style === 'title') { bold = true; ind = 0; base = 0; }
    else if (a.style === 'num') { const lv = Math.min(7, a.level | 0); if (a.restart) cnt[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; cnt.length = lv + 1; cnt[lv] = (cnt[lv] || 0) + 1; mk = FZ.schemeMarker(S, lv, cnt[lv], cnt.slice(0, lv)).trim(); ind = lv; base = lv + 2; bold = true; }
    else if (a.style === 'sym') { const lv = Math.min(7, a.level | 0); mk = FZ.schemeMarker(SY, lv, 0).trim(); ind = base + lv; bold = true; }
    else if (a.list) { const lv = Math.min(7, a.list.level | 0), k = a.list.kind; lc.length = lv + 1; if (k === 'num') lc[lv] = (lc[lv] || 0) + 1; mk = k === 'cont' ? '' : k === 'arrow' ? '→' : k === 'todo' ? '❏' : k === 'done' ? '☑' : k === 'num' ? FZ.schemeMarker(LS, lv, lc[lv]).trim() : FZ.schemeMarker(BU, lv, 0).trim(); ind = base + lv * 2 + (k === 'cont' ? 1.5 : 0); }
    if (!a.list) lc.length = 0;
    out.push(`<div class="il${bold ? ' b' : ''}" style="padding-left:${ind}em">${mk ? `<span class="mk">${esc(mk)}</span>` : ''}${esc(t) || '&nbsp;'}</div>`); }
  return out.join(''); }
function drawIsland() { const el = $('island'); const on = st.form === 'parked'; document.body.classList.toggle('island', on); if (!on) { el.innerHTML = ''; return; } const P = ed.doc.parked || [];
  el.innerHTML = `<div class="islt">保留の島<span class="info">${P.length ? `${P.length} 件。戻す＝今の節（ツリーは選んだ節）の後ろへ。数字キー 1〜9 でも戻せる` : '保留しているものはありません（F3→P で送る）'}</span></div>` + P.map((p, i) => `<div class="isl"><div class="islh"><span class="no">${i + 1}</span><b>${esc(p.label)}</b><span class="info">${p.lines.length} 行</span><button type="button" data-isl="b${i}" title="今の節の後ろに戻す">戻す</button><button type="button" data-isl="x${i}" title="保留から消す">消す</button></div><div class="islb">${parkHtml(p)}</div></div>`).join(''); }
$('island').addEventListener('pointerdown', e => { const b = e.target.closest('button[data-isl]'); if (!b) return; e.preventDefault(); if (st.form === 'parked') FORMS.parked.act(b.dataset.isl); });
FORMS.parked = {
  html() { const P = ed.doc.parked || []; return `<span class="ttl">保留の島</span><span class="info">${P.length ? `${P.length} 件：全文は画面の下に` : '保留しているものはありません（F3→P で送る）'}</span><span class="hintl">保留は原本に残り、組版・書き出し・AI に渡す Markdown には出ない</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('b' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^([bx])(\d+)$/); if (!m) return; const P = ed.doc.parked || []; const p = P[+m[2]]; if (!p) return;
    if (m[1] === 'x') { ed.mutate('', () => { ed.doc.parked.splice(+m[2], 1); if (!ed.doc.parked.length) delete ed.doc.parked; }); drawSub(); msg('保留から消しました（Ctrl+Z で戻す）'); return; }
    let at; if (st.mode === 'tree') { const n = treeNodeSel(); at = n && !n.root ? n.end + 1 : ed.doc.lines.length; } else { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(ed.doc.lines[ed.caret.line]); at = n ? n.end + 1 : ed.caret.line + 1; }
    const lines = JSON.parse(JSON.stringify(p.lines)); ed.mutate('', () => { lines.forEach((ln, k) => ed.insertLine(at + k, ln)); ed.doc.parked.splice(+m[2], 1); if (!ed.doc.parked.length) delete ed.doc.parked; if (st.mode !== 'tree') { ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; } });
    if (st.mode === 'tree') { st.tree.sel = ed.doc.lines[at]; treeRefresh(); } else render(); drawSub(); msg(`「${p.label}」を戻しました`); } };
/* ================= AI からの戻し（X3） =================
   写した範囲（行の番号の列＋その時の全行の署名）を覚え、戻ってきた Markdown と比べて、違う所（塊）を 1 つずつ取り込む／捨てる。
   直す行はその場で直す（飾り・揃え・罫・傍点など Markdown に無いものが残る）。塊ごとに Ctrl+Z で戻せる */
const docSigs = () => ed.doc.lines.map(l => FZ.lineSig(ed.doc, l));
function rangeIdx(a, b) { const r = []; for (let k = Math.max(0, a); k <= b; k++) r.push(k); return r; }
function rememberScope(idx, what) { st.aiScope = idx ? { idx, snap: docSigs(), what } : { whole: true, what: '文書全体' }; }
function scopeNow(sc) { if (!sc) return null; const n = ed.doc.lines.length; if (sc.whole) return rangeIdx(0, n - 1); const idx = FZ.remapIdx(sc.idx, sc.snap, docSigs()).filter(i => i < n); return idx.length ? idx : null; }
const AI_KIND = { add: '足す', del: '消す', chg: '直す' };
/* 比べる範囲の候補：写した範囲・カーソル（ツリーは選んだ節）の節・文書全体 */
function aiCandidates() { const out = [], n = ed.doc.lines.length; const last = scopeNow(st.aiScope); if (last) out.push({ key: 'last', name: '写した範囲' + (st.aiScope.whole ? '（文書全体）' : '（' + st.aiScope.what + '）'), idx: last });
  let sec = null; if (st.mode === 'tree') { const t = treeNodeSel(); if (t && !t.root && t.obj && t.kind !== 'sent') { const a = ed.doc.lines.indexOf(t.obj); if (a >= 0) sec = { a, b: a + (t.end - t.line), text: t.text }; } } else { const b = sectionAt(ed.caret.line); if (b) sec = { a: b.line, b: b.end, text: b.text }; }
  if (sec) out.push({ key: 'sec', name: '「' + String(sec.text).slice(0, 12) + '」の節', idx: rangeIdx(sec.a, sec.b) });
  out.push({ key: 'doc', name: '文書全体', idx: rangeIdx(0, n - 1) }); return out; }
/* AI の返事から Markdown を取り出す（```markdown で囲まれていれば中身） */
function aiUnwrap(md) { md = String(md || '').replace(/\r\n?/g, '\n'); const m = md.match(/```(?:markdown|md)[ \t]*\n([\s\S]*?)\n```/i) || md.match(/^\s*```[ \t]*\n([\s\S]*?)\n```\s*$/); return m ? m[1] : md; }
function aiParse(md) { const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(ed.doc.format)); const anchors = ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean), figs = ed.figList().map(x => x.fg.id); return FZ.fromGfm(aiUnwrap(md), base, { refTargets: { anchors, figs } }); }
function aiCompare(md, pick) { if (!String(md || '').trim()) { msg('貼り付けた Markdown がありません', true); return false; }
  let B; try { B = aiParse(md); } catch (e) { msg('読めませんでした：' + e.message, true); return false; }
  if (!B.lines.some(l => FZ.lineSig(B, l) !== '|')) { msg('貼り付けたものに中身がありません（Markdown の本文を貼ってください）', true); return false; } /* 空を比べると「すべて消す」になる */
  const sigA = docSigs(); const cands = aiCandidates(); let best = null;
  for (const c of (pick && pick !== 'auto' ? cands.filter(x => x.key === pick) : cands)) { const B2 = JSON.parse(JSON.stringify(B)); FZ.alignLevels(ed.doc, c.idx, B2); const sigB = B2.lines.map(l => FZ.lineSig(B2, l)); const H = FZ.diffDocs(ed.doc, c.idx, B2, sigA, sigB); const cost = H.reduce((t, h) => t + h.size, 0);
    if (!best || cost < best.cost) best = { c, B: B2, sigB, cost }; } /* 自動：違いのいちばん少ない範囲（同じなら写した範囲・狭い範囲を先に） */
  if (!best) { msg('比べる範囲がありません', true); return false; }
  st.aiBack = { B: best.B, sigB: best.sigB, idx: best.c.idx, snap: sigA, skip: new Set(), i: 0, hunks: [], name: best.c.name, auto: !pick || pick === 'auto', taken: 0, md };
  aiSync(); aiShow(); return true; }
function aiSync() { const S = st.aiBack; if (!S) return; const now = docSigs(); S.idx = [...new Set(FZ.remapIdx(S.idx, S.snap, now))].filter(i => i < ed.doc.lines.length); S.snap = now; /* 文書が他の操作で変わっていても（Ctrl+Z など）範囲を付け替える */
  S.hunks = FZ.diffDocs(ed.doc, S.idx, S.B, now, S.sigB).filter(h => !S.skip.has(h.key)); if (S.i >= S.hunks.length) S.i = Math.max(0, S.hunks.length - 1); }
const aiLine = h => Math.min(h.rem.length ? h.rem[0] : Math.max(0, h.at - 1), ed.doc.lines.length - 1); /* 足す所：その前の行（の末尾）に */
function aiShow() { const S = st.aiBack; const h = S && S.hunks[S.i]; if (!h) { render(); return; } const L = aiLine(h);
  if (st.mode === 'tree') { const v = st.tree.view; let n = null; if (v) for (let k = L; k >= 0 && !n; k--) n = v.tr.byObj.get(ed.doc.lines[k]) || null; if (n) { for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); } st.tree.sel = n.obj; } render(); treeScrollToSel(); }
  else { const ln = ed.doc.lines[L], end = !h.rem.length && h.at > 0; const sg = end ? ln.segs.length - 1 : 0; ed.anchor = null; ed.caret = { line: L, seg: sg, off: end ? ln.segs[sg].text.length : 0, vcol: null, vrow: 0 }; ed.onCaret(); render(); scrollToCaret(true); requestOverlay(); } }
/* 範囲の付け替え（自分で取り込んだ時）：塊の窓 [s0, e0] が新しい行に置き換わり、後ろは d だけずれる */
function aiShiftIdx(idx, h, d) { const s0 = h.rem.length ? h.rem[0] : h.at, e0 = h.rem.length ? h.rem[h.rem.length - 1] : h.at - 1; const out = new Set(); for (const i of idx) { if (i < s0) out.add(i); else if (i > e0) out.add(i + d); } for (let k = s0; k <= e0 + d; k++) out.add(k); return [...out].filter(i => i >= 0).sort((x, y) => x - y); }
function aiTake(all) { const S = st.aiBack; if (!S) return; aiSync(); const list = all ? S.hunks.slice() : [S.hunks[S.i]].filter(Boolean); if (!list.length) return;
  const sigA = docSigs(); let idx = S.idx, first = 0; const keepMode = st.mode;
  ed.mutate('', () => { for (const h of list.slice().reverse()) { const n0 = ed.doc.lines.length; first = FZ.applyHunk(ed, S.B, h, { sigA, sigB: S.sigB }); idx = aiShiftIdx(idx, h, ed.doc.lines.length - n0); } }); /* 下から：上の塊の位置は変わらない */
  S.idx = idx; S.snap = docSigs(); S.taken += list.length; aiSync(); if (keepMode === 'tree') treeRefresh();
  if (S.hunks.length) aiShow(); else { if (keepMode !== 'tree') { ed.anchor = null; ed.caret = { line: Math.min(first, ed.doc.lines.length - 1), seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); } render(); }
  drawSub(); msg(`${list.length} 件を取り込みました（Ctrl+Z で戻す）${S.hunks.length ? `：残り ${S.hunks.length} 件` : '：違いはもうありません'}`); }
function aiDrop() { const S = st.aiBack; const h = S && S.hunks[S.i]; if (!h) return; S.skip.add(h.key); aiSync(); aiShow(); drawSub(); }
function aiStep(d) { const S = st.aiBack; if (!S || !S.hunks.length) return; S.i = (S.i + d + S.hunks.length) % S.hunks.length; aiShow(); drawSub(); }
/* 塊の中身を短く：直すは「頭…〔今→案〕…尻」 */
function aiPreview(h) { const S = st.aiBack; const tx = (doc, l) => FZ.expandRefsText(doc, l.segs.map(sg => sg.text).join(' ')).replace(/\s+/g, ' ').trim(); const isC = (doc, l) => FZ.lineSig(doc, l) !== '|';
  const A = h.rem.map(i => ed.doc.lines[i]).filter(l => isC(ed.doc, l)).map(l => tx(ed.doc, l)), Bt = []; for (let j = h.b[0]; j < h.b[1]; j++) if (S.sigB[j] !== '|') Bt.push(tx(S.B, S.B.lines[j]));
  const cut = (t, n) => [...t].length > n ? [...t].slice(0, n).join('') + '…' : t; const more = (L) => L.length > 1 ? `<span class="info">（ほか ${L.length - 1} 行）</span>` : '';
  const full = (A.length ? '今：' + A.join(' / ') : '') + (A.length && Bt.length ? '\n' : '') + (Bt.length ? '案：' + Bt.join(' / ') : '');
  let html; if (h.kind === 'chg' && A.length && Bt.length) { const a = A[0], b = Bt[0]; const n = Math.min(a.length, b.length); let p = 0; while (p < n && a[p] === b[p]) p++; let q = 0; while (q < n - p && a[a.length - 1 - q] === b[b.length - 1 - q]) q++;
      const hira = c => /[\u3041-\u309f]/.test(c || ''), kan = c => /[\u4e00-\u9fff\u3005]/.test(c || ''); while (q > 0 && hira(a[a.length - q]) && (kan(a[a.length - q - 1]) || kan(b[b.length - q - 1]))) q--; /* 送り仮名は語に含めて見せる（「重い→大きい」） */
      const pre = a.slice(0, p), mid1 = a.slice(p, a.length - q), mid2 = b.slice(p, b.length - q), suf = a.slice(a.length - q); const pr = [...pre].length > 10 ? '…' + [...pre].slice(-10).join('') : pre, su = [...suf].length > 10 ? [...suf].slice(0, 10).join('') + '…' : suf;
      html = `${esc(pr)}${mid1 ? `<del>${esc(cut(mid1, 24))}</del>` : ''}${mid2 ? `<ins>${esc(cut(mid2, 24))}</ins>` : ''}${esc(su)}${more(A.length > Bt.length ? A : Bt)}`; }
  else if (h.kind === 'add') html = `<ins>${esc(cut(Bt[0] || '', 40))}</ins>${more(Bt)}`; else html = `<del>${esc(cut(A[0] || '', 40))}</del>${more(A)}`;
  return { html, full }; }
FORMS.aiback = {
  html() { const S = st.aiBack;
    if (!S) { const cs = aiCandidates(); return `<span class="ttl">AI から戻す</span><label>範囲 ${cyc('scope', [['auto', '自動（いちばん合う所）'], ...cs.map(c => [c.key, c.name])], st.aiPick || 'auto')}</label><textarea name="md" class="chdata aimd" rows="3" spellcheck="false" placeholder="AI が直した Markdown をここに貼る（${K('aiCopySec')} で写して渡したもの）"></textarea><button type="button" data-act="file" title="Markdown ファイルから読む">ファイル…</button><span class="hintl">貼って Ctrl+Enter で比べる。違う所を 1 つずつ見て取り込む・捨てる（飾り・罫は今のまま）</span><button type="button" class="pri" data-act="cmp">比べる</button><button type="button" data-act="cancel">閉じる Esc</button>`; }
    const h = S.hunks[S.i]; const tail = `<span class="info">範囲：${esc(S.name)}${S.auto ? '（自動）' : ''}${S.skip.size ? `・捨てた ${S.skip.size}` : ''}${S.taken ? `・取り込んだ ${S.taken}` : ''}</span><button type="button" data-act="back" title="貼り直す・範囲を選び直す">貼り直す</button><button type="button" data-act="cancel">閉じる Esc</button>`;
    if (!h) return `<span class="ttl">AI からの戻し</span><span class="info">違いはありません${S.taken || S.skip.size ? '（すべて見終わりました）' : '（同じ中身です）'}</span>${tail}`;
    const pv = aiPreview(h); return `<span class="ttl">AI からの戻し</span><span class="info"><b>${S.i + 1}</b>/${S.hunks.length}　${AI_KIND[h.kind]}</span><span class="aiprev" title="${esc(pv.full)}">${pv.html}</span><button type="button" data-act="prev" title="前の違い（↑）">↑</button><button type="button" data-act="next" title="次の違い（↓）">↓</button><button type="button" class="pri" data-act="take" title="この違いを取り込む（Enter）">取り込む</button><button type="button" data-act="drop" title="この違いを捨てる（Delete）">捨てる</button><button type="button" data-act="all" title="残りの違いをすべて取り込む（1 回の Ctrl+Z で戻る）">残りを全部</button>${tail}`; },
  get focus() { return st.aiBack ? 'button.pri' : 'textarea'; },
  enter(e) { if (!st.aiBack) { if (e && e.target && e.target.tagName === 'TEXTAREA' || (e && (e.ctrlKey || e.metaKey))) this.act('cmp'); return; } this.act('take'); },
  key(e) { if (!st.aiBack) return; const tag = e.target && e.target.tagName;
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); if (ed.undo()) { aiSync(); if (st.mode === 'tree') treeRefresh(); aiShow(); drawSub(); msg('元に戻しました'); } return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); if (ed.redo()) { aiSync(); if (st.mode === 'tree') treeRefresh(); aiShow(); drawSub(); } return; }
    if (tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'INPUT') return;
    if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') { e.preventDefault(); this.act('prev'); } else if (e.key === 'ArrowDown' || e.key === 'ArrowRight') { e.preventDefault(); this.act('next'); } else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); this.act('drop'); } },
  change(name) { if (name === 'scope') st.aiPick = cycVal('scope'); },
  act(a) { if (a === 'cancel') { closeForm(); return; }
    if (a === 'cmp') { const md = fval('md'); st.aiPick = cycVal('scope') || 'auto'; if (aiCompare(md, st.aiPick)) { drawSub(); const S = st.aiBack; msg(S.hunks.length ? `違いが ${S.hunks.length} 件あります：Enter で取り込む、Delete で捨てる、↑↓ で移る` : '違いはありません'); } return; }
    if (a === 'file') { const inp2 = document.createElement('input'); inp2.type = 'file'; inp2.accept = '.md,.markdown,.txt,text/markdown,text/plain'; inp2.onchange = async () => { const f = inp2.files[0]; if (!f) return; const t = await f.text(); const ta2 = sub.querySelector('textarea[name="md"]'); if (ta2) ta2.value = t; this.act('cmp'); }; inp2.click(); return; }
    if (a === 'back') { const md = st.aiBack ? st.aiBack.md : ''; st.aiBack = null; drawSub(); const ta2 = sub.querySelector('textarea[name="md"]'); if (ta2) ta2.value = md || ''; render(); return; }
    if (a === 'take') aiTake(false); else if (a === 'all') aiTake(true); else if (a === 'drop') aiDrop(); else if (a === 'prev') aiStep(-1); else if (a === 'next') aiStep(1); } };
function aiReturn() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); if (st.form === 'aiback') { closeForm(); return; } st.aiBack = null; openForm('aiback'); }
/* ================= 霞が関型の区画（V3） =================
   見出しに attrs.panels（2〜4）：その子の節（見出し・項目）を横に並べた枠の区画に組む。区画の見出しは帯（黒地白抜き／網／下線） */
function panelTarget(up) { const tr = FZ.tree.build(ed.doc, {}); let n = null;
  if (st.panelObj && up) { n = tr.byObj.get(st.panelObj); if (n) n = n.parent; }
  else if (st.mode === 'tree') { const t = treeNodeSel(); n = t && t.obj ? tr.byObj.get(t.obj) || null : null; } else n = FZ.tree.nodeAt(tr, ed.caret.line);
  const isHead = x => x && (x.kind === 'title' || x.kind === 'num' || x.kind === 'sym'); const kids = x => x.children.filter(c => c.kind !== 'body' && c.kind !== 'block');
  if (!up) { for (let p = n; p && !p.root; p = p.parent) if (p.obj && p.obj.attrs.panels) return p; } /* 区画の中なら、その区画の見出し */
  while (n && !n.root && !(isHead(n) && kids(n).length >= 2)) n = n.parent; return n && !n.root ? n : null; }
function openPanels() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); const n = panelTarget(false); st.panelObj = n ? n.obj : null; if (!n) { msg('区画にできる節がありません（子の見出し・項目を 2 つ以上持つ見出しで）', true); return; } toggleForm('panels'); }
FORMS.panels = {
  node() { const tr = FZ.tree.build(ed.doc, {}); return st.panelObj ? tr.byObj.get(st.panelObj) || null : null; },
  html() { const n = this.node(); if (!n) return `<span class="ttl">区画</span><span class="info alert">区画にできる節がありません</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    const a = n.obj.attrs, m = n.children.filter(c => c.kind !== 'body' && c.kind !== 'block').length;
    const cur = String(a.panels || 0), cols = a.panels === 'v' ? 1 : a.panels === 'h' ? m : (a.panels | 0), rows = cols ? Math.ceil(m / cols) : 0;
    return `<span class="ttl">区画</span><span class="info">「${esc(String(n.text).slice(0, 14))}」の子 ${m} 個${cols ? `（${rows} 段×${cols} 列）` : ''}を</span><label>並べ方 ${cyc('n', [['0', '並べない'], ['h', '横に並べる'], ['v', '縦に並べる'], ['2', '縦横 2 列'], ['3', '縦横 3 列'], ['4', '縦横 4 列'], ['5', '縦横 5 列'], ['6', '縦横 6 列']], cur)}</label><label>見出し ${cyc('head', [['dark', '黒地白抜き'], ['gray', '網'], ['line', '下線']], a.panelHead || 'dark')}</label><label>つなぎ ${cyc('link', [['', 'なし'], ['arrow', '矢印（→）'], ['tri', '三角（▶）']], a.panelLink || '')}</label><button type="button" data-act="up" title="一つ上の見出しを区画の親に">一つ上へ</button><span class="hintl">子の節がそれぞれ枠の区画になる（霞が関の 1 枚もの）。中身は文書のまま・ツリーでも直せる</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'select', change(name) { if (name !== 'n' && name !== 'head' && name !== 'link') return; const n = this.node(); if (!n) return; const raw = cycVal('n'), v = raw === 'h' || raw === 'v' ? raw : (+raw || 0), h = cycVal('head'), lk = cycVal('link') || ''; const a = n.obj.attrs;
    if ((a.panels || 0) === v && (a.panelHead || 'dark') === h && (a.panelLink || '') === lk) return; const L = ed.doc.lines.indexOf(n.obj);
    ed.mutate('', () => { if (v) a.panels = v; else delete a.panels; if (h && h !== 'dark') a.panelHead = h; else delete a.panelHead; if (lk) a.panelLink = lk; else delete a.panelLink; }); if (st.mode === 'tree') treeRefresh(); else render(); if (L >= 0) msg(v ? `「${String(n.text).slice(0, 12)}」の子を${v === 'h' ? '横に並べた' : v === 'v' ? '縦に並べた' : ` ${v} 列の`}区画にしました（Ctrl+Z で戻す）` : '区画をやめました'); drawSub(); },
  enter() { closeForm(); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'up') { const n = panelTarget(true); if (n) { st.panelObj = n.obj; drawSub(); } else msg('これより上に区画にできる見出しはありません', true); } } };
/* 構造の点検（S2） */
const KEITAI = /(です|ます|でした|ました|ません|でしょう|ください|ましょう)[。．]?[」』）)]*$/, JOTAI = /(である|だ|た|ない|る|う|い|ぬ|か)[。．][」』）)]*$/;
function structIssues() { const tr = FZ.tree.build(ed.doc, { body: true }); const out = []; const add = (n, kind, msg2, extra = {}) => out.push({ line: n.line, obj: n.obj, kind, msg: msg2, ...extra });
  for (const n of tr.nodes) { if (n.kind === 'title' || n.kind === 'num' || n.kind === 'sym' || n.kind === 'list') { const sameFam = n.children.filter(c => c.kind === 'num' || c.kind === 'sym' || c.kind === 'list');
      if (sameFam.length === 1 && n.kind !== 'title') add(n, 'one', '子が 1 つだけ（分けるなら 2 つ以上、でなければ上の段に含める）');
      if ((n.kind === 'num' || n.kind === 'sym') && !n.children.length) add(n, 'empty', '中身がない（本文・箇条書き・子の見出しが無い）');
      if (n.kind === 'num' && n.parent && n.parent.kind === 'num' && n.level > n.parent.level + 1) add(n, 'jump', `段が飛んでいる（${n.parent.level + 1} 段の下に ${n.level + 1} 段）`);
      if (n.kind === 'num' && (!n.parent || n.parent.kind !== 'num') && n.level > 0 && !tr.nodes.some(m => m.kind === 'num' && m.level < n.level && m.line < n.line)) add(n, 'jump', `段が飛んでいる（上に浅い番号見出しが無いのに ${n.level + 1} 段）`);
      if (n.obj && typeof n.obj.attrs.restart === 'number') { const sib = n.parent.children.filter(c => c.kind === n.kind && c.level === n.level); const k = sib.indexOf(n); if (k > 0 && n.obj.attrs.restart > k + 1) add(n, 'jump', `番号が飛ぶ（${k + 1} の所が ${n.obj.attrs.restart}）`); } } }
  const sents = []; for (const n of tr.nodes) { if ((n.kind !== 'body' && n.kind !== 'list') || !n.obj || n.obj.segs.length !== 1) continue; const ss = FZ.tree.sentences(n.obj.segs[0].text); ss.forEach((x, k) => sents.push({ n, x, k })); }
  for (const e of sents) { const len = [...e.x.text.replace(/[\u{F0000}-\u{FFFFD}]/gu, '図')].length; if (len > 80) add(e.n, 'long', `長い文（${len} 字。80 字までが読みやすい）`, { si: e.k, a: e.x.start, b: e.x.start + e.x.text.length }); }
  const cls = sents.map(e => { const t = e.x.text.trim(); return KEITAI.test(t) ? 'k' : JOTAI.test(t) ? 'j' : null; }); const nk = cls.filter(c => c === 'k').length, nj = cls.filter(c => c === 'j').length;
  if (nk && nj) { const minor = nk >= nj ? 'j' : 'k'; sents.forEach((e, i) => { if (cls[i] === minor) add(e.n, 'style', `文末が${minor === 'j' ? '常体（だ・である）' : '敬体（です・ます）'}（この文書は${minor === 'j' ? '敬体' : '常体'}が多い）`, { si: e.k, a: e.x.start, b: e.x.start + e.x.text.length }); }); }
  out.sort((p, q) => p.line - q.line || (p.a || 0) - (q.a || 0)); return out; }
const CHECK_NAMES = { one: '子が 1 つ', empty: '中身なし', long: '長い文', style: '文末の不統一', jump: '段・番号の飛び' };
function checkStep(d) { const L = structIssues(); if (!L.length) { msg('気になる所はありません'); return; } st.checkIdx = st.checkIdx == null ? (d > 0 ? 0 : L.length - 1) : (st.checkIdx + d + L.length) % L.length; const it = L[st.checkIdx];
  if (st.mode === 'tree') { const v = st.tree.view; const n = v && v.tr.byObj.get(it.obj); if (n) { for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); } if ((n.kind === 'body') && st.tree.depth > 0) st.tree.depth = 0; st.tree.sel = it.obj; render(); treeScrollToSel(); } }
  else { const L2 = ed.doc.lines.indexOf(it.obj); if (L2 >= 0) { if (it.a != null) { ed.anchor = { line: L2, seg: 0, off: it.a }; ed.caret = { line: L2, seg: 0, off: it.b, vcol: null, vrow: 0 }; st.sentSel = { obj: it.obj, si: it.si, a: it.a, b: it.b, n: 2 }; } else { ed.anchor = null; ed.caret = { line: L2, seg: 0, off: 0, vcol: null, vrow: 0 }; } ed.onCaret(); scrollToCaret(true); requestOverlay(); } }
  const info = sub.querySelector('.ckinfo'); if (info) info.textContent = `${st.checkIdx + 1}/${L.length}：${CHECK_NAMES[it.kind]}　${it.msg}`; }
FORMS.scheck = {
  html() { const L = structIssues(); const by = {}; for (const it of L) by[it.kind] = (by[it.kind] || 0) + 1; st.checkIdx = null;
    return `<span class="ttl">構造の点検</span><span class="info">${L.length ? Object.keys(CHECK_NAMES).filter(k => by[k]).map(k => `${CHECK_NAMES[k]} <b>${by[k]}</b>`).join('　') : '気になる所はありません'}</span><button type="button" data-act="prev">↑ 前</button><button type="button" class="pri" data-act="next">次 ↓</button><span class="info ckinfo">${L.length ? `${L.length} 件：Enter で順に見る（ツリーでは節に「！」）` : ''}</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.pri', enter(e) { this.act(e && e.shiftKey ? 'prev' : 'next'); },
  act(a) { if (a === 'cancel') { closeForm(); if (st.mode === 'tree') render(); return; } if (a === 'next' || a === 'prev') checkStep(a === 'next' ? 1 : -1); } };
/* 文の分け方（S7） */
FORMS.sentopt = {
  html() { const o = FZ.tree.sentOpts; return `<span class="ttl">文の分け方</span><label>「．」も文末に ${cyc('period', [['0', 'しない'], ['1', 'する']], o.period ? '1' : '0')}</label><label>箇条書きの中の文 ${cyc('lists', [['0', '分けない'], ['1', '分ける']], o.lists ? '1' : '0')}</label><span class="hintl">ツリーの深さ「文」・文を選ぶ・構造の点検に効く（この機械の設定）</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'select', enter() { this.act('apply'); },
  act(a) { if (a !== 'apply') { closeForm(); return; } FZ.tree.sentOpts = { period: cycVal('period') === '1', lists: cycVal('lists') === '1' }; try { localStorage.setItem('fz.sentOpts', JSON.stringify(FZ.tree.sentOpts)); } catch (e) { /* 保存できなくても今は効く */ } closeForm(); render(); msg('文の分け方を変えました'); } };
try { const o = JSON.parse(localStorage.getItem('fz.sentOpts') || 'null'); if (o) FZ.tree.sentOpts = { period: !!o.period, lists: !!o.lists }; } catch (e) { /* 既定のまま */ }
/* 番号・記号の形（今の節の種類と段。この段のものすべて） */
FORMS.marker = {
  node() { if (st.mode === 'tree') return treeNodeSel(); const tr = FZ.tree.build(ed.doc, { body: true }); return tr.byObj.get(ed.doc.lines[ed.caret.line]) || null; },
  choices() { const n = this.node(); const m = n && treeMarkerNow(n); if (!m) return null; const ch = treeMarkerChoices(m.k); if (!ch.includes(m.tok)) ch.unshift(m.tok); return { m, ch }; },
  html() { const c = this.choices(); if (!c) return `<span class="ttl">番号・記号の形</span><span class="info alert">番号見出し・記号見出し・箇条書きの行（節）で使います</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    return `<span class="ttl">${esc(c.m.name)}${c.m.lv + 1} の形</span>${c.ch.map((t, i) => `<button type="button" class="pal${t === c.m.tok ? ' on' : ''}" data-act="t${i}" title="${esc(t === FZ.NONE_TOKEN ? '番号・記号なし' : t)}">${i < 9 ? `<span class="kk">${i + 1}</span>` : ''}${esc(t === FZ.NONE_TOKEN ? 'なし' : t)}</button>`).join('')}<span class="hintl">この段のものすべてが変わる。全体は ${K('scheme')}</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.on', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('t' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^t(\d+)$/); const c = this.choices(); if (!m || !c) return; const tok = c.ch[+m[1]]; if (!tok) return;
    if (st.mode === 'tree') treeSetMarker(tok); else withCaretNode(() => treeSetMarker(tok), { noSent: true }); drawSub(); } };
/* ================= グラフ ================= */
/* 表の範囲（今の行を含む表）→ { a, b, rows: [[セルの文字]] } */
function tableAt(line) { const doc = ed.doc; if (!FZ.inTable(doc, line)) return null; let a = line, b = line; while (a > 0 && FZ.inTable(doc, a - 1)) a--; while (b + 1 < doc.lines.length && FZ.inTable(doc, b + 1)) b++;
  const cols = doc.format.cols; const rows = []; for (let k = a; k <= b; k++) { const ln = doc.lines[k]; rows.push(FZ.cellsAt(doc, k, cols).map(c => ln.segs.filter(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6).map(s => s.text).join('').trim())); } return { a, b, rows }; }
function chartCmd() {
  if (st.mode === 'tree') exitTree(false); else if (st.mode !== 'text') exitMode();
  const here = (ed.line().attrs.figs || []).find(fg => fg.chart); if (here) { st.figSel = here.id; openForm('chart'); return; }
  let t = tableAt(ed.caret.line); if (!t && ed.caret.line > 0 && !ed.line().segs.some(sg => sg.text.trim())) t = tableAt(ed.caret.line - 1); /* 表のすぐ下の空行（Excel のセルを貼った直後）でも、その表から */
  if (t) { if (!FZ.chartable(t.rows)) { msg('この表には数がありません（グラフにできるのは数の入った表）', true); return; }
    const chart = FZ.chartFromGrid(t.rows); const host = t.b + 1; let id; ed.mutate('', () => { if (host >= ed.doc.lines.length || FZ.inTable(ed.doc, host)) ed.insertLine(host, FZ.newLine()); const at = ed.doc.lines[host].attrs; id = ed.newFigId(); (at.figs = at.figs || []).push({ id, kind: '図', title: '', file: '', width: 100, chart }); }); /* 図版は表のすぐ下の行に付ける（表の行に付けると文書の書式では置き場が無い） */ st.figSel = id; st.chartData = false; openForm('chart'); msg('表からグラフを作りました（表はそのまま）：種類・題を選んで Enter。データの向きが違えば「行と列を入れ替え」'); return; }
  const id = ed.addFigure({ kind: '図', title: '', chart: FZ.chartSample() }); st.figSel = id; st.chartData = true; openForm('chart');
  msg('見本のデータでグラフを入れました：データの欄に Excel のセルを貼るか書き換えて Ctrl+Enter（表の中で ' + K('chart') + ' なら表から作る）', false, 8000); }
const chartTSV = c => FZ.chartToGrid(c).map(r => r.join('\t')).join('\n');
FORMS.chart = {
  cur() { const x = ed.figById(st.figSel); return x && x.fg.chart ? x : null; },
  html() { const x = this.cur(); if (!x) return `<span class="ttl">グラフ</span><span class="info alert">グラフがありません</span><button type="button" data-act="cancel">閉じる Esc</button>`; const fg = x.fg, c = fg.chart; const n = ed.lay.figNums && ed.lay.figNums.get(fg.id);
    const L = ed.figList().filter(y => y.fg.chart); const idx = L.findIndex(y => y.fg.id === fg.id);
    return `<span class="ttl">グラフ ${esc(n ? n.label : '')}${L.length > 1 ? `（${idx + 1}/${L.length}）` : ''}</span><label>種類 ${cyc('type', FZ.CHART_TYPES, c.type)}</label><label>題 ${inp('title', fg.title, 'w')}</label><label>種別 ${cyc('kind', [['図', '図'], ['表', '表']], fg.kind)}</label><label>幅 ${cyc('width', [['100', '欄いっぱい'], ['75', '75%'], ['50', '50%']], String(fg.width))}</label>
      <label>単位 ${inp('unit', c.unit, 's')}</label><label>凡例 ${cyc('legend', FZ.CHART_LEGENDS, c.legend)}</label><label>値 ${cyc('labels', [['1', '出す'], ['0', '出さない']], c.labels ? '1' : '0')}</label><label>縦横 ${cyc('ratio', [['0.4', '横長'], ['0.5', 'やや横長'], ['0.6', '標準'], ['0.75', '4:3'], ['1', '正方形']], String(c.ratio))}</label>
      <button type="button" data-act="swap" title="系列と項目を入れ替える（Excel の「行/列の切り替え」）">行と列を入れ替え</button><button type="button" data-act="data" title="データの欄を出す／隠す">${st.chartData ? 'データを隠す' : 'データ…'}</button><button type="button" data-act="ref" title="本文の今の位置に図番を入れる">図番</button><button type="button" data-act="del">削除</button>
      ${st.chartData ? `<textarea name="data" class="chdata" rows="${Math.min(8, Math.max(3, c.series.length + 1))}" spellcheck="false">${esc(chartTSV(c))}</textarea><span class="hintl">1 行目：（角）・項目…／2 行目から：系列の名前・値…。タブ区切り（Excel のセルをそのまま貼れる）。Ctrl+Enter で反映</span>` : ''}
      <button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'select[name="type"]', enter(e) { if (e && e.target && e.target.tagName === 'TEXTAREA') { this.save(); drawSub(); const t2 = sub.querySelector('textarea[name="data"]'); if (t2) t2.focus(); msg('データを反映しました'); return; } this.act('apply'); }, /* データの欄の Ctrl+Enter は反映だけ（欄は開いたまま） */
  read(x) { const c = x.fg.chart; const nc = { ...c, type: cycVal('type'), unit: fval('unit').trim(), legend: cycVal('legend'), labels: cycVal('labels') === '1', ratio: +cycVal('ratio') || 0.6 };
    const ta2 = sub.querySelector('textarea[name="data"]'); if (ta2 && ta2.value.trim() && ta2.value.replace(/\r/g, '').trim() !== chartTSV(c)) { const rows = FZ.parseTSV(ta2.value.replace(/\|/g, '\t')).map(r => r.map(v => String(v).trim())); if (rows.length) { const d = FZ.normalizeChart({ ...nc, _rows: rows }); d.series.forEach((sr, k) => { if (c.series[k]) sr.shade = c.series[k].shade; }); Object.assign(nc, { corner: d.corner, cats: d.cats, series: d.series }); } }
    return { kind: cycVal('kind'), title: fval('title').trim(), width: +cycVal('width'), chart: FZ.normalizeChart(nc) }; },
  save() { const x = this.cur(); if (!x) return false; const v = this.read(x); if (v.kind === x.fg.kind && v.title === x.fg.title && v.width === x.fg.width && JSON.stringify(v.chart) === JSON.stringify(x.fg.chart)) return false; ed.setFig(x.fg.id, v); return true; },
  change(name) { if (['type', 'legend', 'labels', 'ratio', 'kind', 'width'].includes(name)) this.save(); }, /* 選択はその場で紙面に */
  act(a) { const x = this.cur(); if (a === 'cancel' || !x) { closeForm(); return; }
    if (a === 'apply') { this.save(); closeForm(); return; }
    this.save(); const y = this.cur(); if (!y) { closeForm(); return; }
    if (a === 'swap') { ed.setFig(y.fg.id, { chart: FZ.chartTranspose(y.fg.chart) }); drawSub(); return; }
    if (a === 'data') { st.chartData = !st.chartData; drawSub(); const t2 = sub.querySelector('textarea[name="data"]'); if (t2) t2.focus(); return; }
    if (a === 'ref') { closeForm(); ed.insertRef(y.fg.id); return; }
    if (a === 'del') { ed.removeFig(y.fg.id); closeForm(); msg('グラフを削除しました（Ctrl+Z で戻す）'); return; } } };
FORMS.figref = {
  html() { const L = ed.figList(); const nums = ed.lay.figNums; return `<span class="ttl">図番を入れる</span>${L.map((x, i) => { const n = nums && nums.get(x.fg.id); return `<button type="button" data-act="r${i}">${i < 9 ? (i + 1) + ' ' : ''}${esc(n ? n.label : x.fg.kind)}${x.fg.title ? '　' + esc(x.fg.title) : ''}</button>`; }).join('')}<span class="hintl">番号は図表の順番に追従します</span><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('r' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^r(\d+)$/); if (!m) return; const x = ed.figList()[+m[1]]; closeForm(); if (x) ed.insertRef(x.fg.id); } };
FORMS.slide = {
  html() { const f = ed.doc.format; return `<span class="ttl">資料の柱と欄</span><label>本文欄の幅 ${inp('bodyPct', f.bodyPct, '', 'number', 'min="20" max="100" step="5"')}%</label><label>仕切り ${cyc('divider', [['none', 'なし'], ['thin', '細'], ['dotted', '点線']], f.divider)}</label>
    <label>柱の題 ${cyc('headTitle', [['page', '頁ごと（表題の行）'], ['doc', '通し（題名）']], f.headTitle)}</label><label>題名 ${inp('title', ed.doc.title, 'w')}</label><label>機密表示 ${inp('secret', f.secret, 'm')}</label><label>作成日 ${inp('date', f.dateAuto ? FZ.todayJa() : f.date, 'm')}</label><button type="button" data-act="today" title="作成日の欄を今日の日付にする">今日</button><label>${cyc('dateAuto', [['0', '固定'], ['1', '自動（毎日今日に）']], f.dateAuto ? '1' : '0')}</label><label>作成者 ${inp('author', f.author, 'm')}</label>
    <label>頁番号 ${cyc('pageMark', [['box', '四角'], ['circle', '丸'], ['none', 'なし']], f.pageMark)}</label><label>柱の罫 ${cyc('headRule', [['thin', '細'], ['thick', '太']], f.headRule)}</label>
    <label>表紙 ${cyc('cover', [['0', 'なし'], ['1', 'あり']], f.cover ? '1' : '0')}</label><label>表紙の頁番号 ${cyc('coverNum', [['0', '出さない'], ['1', '出す']], f.coverNum ? '1' : '0')}</label><label>開始番号 ${inp('pageStart', f.pageStart, '', 'number', 'min="0" max="9999" step="1"')}</label>
    <span class="hintl">頁ごと：表題の行が柱に入る（無いページは前の題）。表紙あり：最初のページは柱なし、最初の表題は紙面の題（大きくするなら倍角）。開始番号 0：表紙を数えず本文が 1 から</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="bodyPct"]', enter() { this.act('apply'); },
  act(a) { if (a === 'today') { const el = sub.querySelector('input[name="date"]'); if (el) { el.value = FZ.todayJa(); el.focus(); } return; } if (a !== 'apply') { closeForm(); return; } const f = JSON.parse(JSON.stringify(ed.doc.format)); Object.assign(f, { kind: 'slide', dateAuto: cycVal('dateAuto') === '1', bodyPct: +fval('bodyPct') || 60, divider: cycVal('divider'), headTitle: cycVal('headTitle'), secret: fval('secret').trim(), date: fval('date').trim(), author: fval('author').trim(), pageMark: cycVal('pageMark'), headRule: cycVal('headRule'), cover: cycVal('cover') === '1', coverNum: cycVal('coverNum') === '1', pageStart: fval('pageStart').trim() === '' ? 1 : +fval('pageStart') }); if (f.headerRows < 1) f.headerRows = 2; const title = fval('title').trim();
    closeForm(); ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.doc.title = title; ed.normalizeSegs(); }); msg('資料の柱と欄を変えました'); } };
/* ================= 印刷 ================= */
/* 印刷・PDF は常に「印刷イメージ」：白黒＋網点（画面の二値表示と同じ描画）、全ページを描いてから印刷する
   （画面は見えているページしか描いていないので、そのまま印刷すると見えていないページが白紙になる） */
async function doPrint() {
  try { finishLayout(); await prepareImages(); } catch { } // 図版の画像の網点化を待つ
  let s = $('printStyle'); if (!s) { s = document.createElement('style'); s.id = 'printStyle'; document.head.append(s); }
  const g = ed.lay.geo; s.textContent = `@page{size:${g.W}pt ${g.H}pt;margin:0}`;
  renderForPrint();
  const restore = () => { pageCache = pageCache.map(() => ''); render(); window.removeEventListener('afterprint', restore); };
  window.addEventListener('afterprint', restore);
  setTimeout(() => { window.print(); setTimeout(restore, 0); }, 60);
}
function renderForPrint() {
  finishLayout(); const lay = ed.lay, n = lay.pages.length;
  while (wraps.length > n) { wraps.pop().remove(); pageCache.pop(); }
  while (wraps.length < n) { const d = document.createElement('div'); d.className = 'pgwrap'; d.dataset.page = wraps.length; pagesEl.append(d); wraps.push(d); pageCache.push(''); }
  for (let p = 0; p < n; p++) { wraps[p].style.height = ''; wraps[p].innerHTML = FZ.renderPage(lay, p, { grid: false, font: ed.doc.format.font, mono: true, imageHref }); pageCache[p] = ''; const svg = wraps[p].querySelector('svg'); if (svg && FZ.rasterizeFills) FZ.rasterizeFills(svg); } // 網は画像にして印刷（PDF 出力とプレビューが速い）
}
/* ================= 起動 ================= */
ed.onChange = () => { requestRender(); syncTA(); scrollToCaret(); scheduleRecovery(); if (!st.form && st.mode !== 'tree') drawSub(); };
/* 段階的な組版：巨大な文書は最初の画面だけ同期で組み、残りは空き時間に少しずつ。終わるまで状態行の頁数に「+」が付く */
let layoutTimer = 0;
function continueLayoutLater() { if (layoutTimer) return; const go = () => { layoutTimer = 0; if (ed.layoutDone) return; const done = ed.continueLayout(14); requestRender(); if (!done) continueLayoutLater(); }; layoutTimer = (typeof requestIdleCallback === 'function') ? requestIdleCallback(go, { timeout: 60 }) : setTimeout(go, 0); }
function finishLayout() { if (ed.layoutDone) return; while (!ed.continueLayout(200)) { } render(); }
ed.onLayoutPending = continueLayoutLater;
ed.onCaret = () => { requestOverlay(); syncTA(); scrollToCaret(); if (!st.form && st.mode !== 'tree') drawSub(); treeFollowCaret(); };
function boot() {
  document.body.classList.add('mono');
  drawFkeys(); drawSub();
  claimSlot();
  let restored = null; try { restored = JSON.parse(localStorage.getItem(RECOVER_KEY()) || 'null'); if (!restored && st.slot === 1) { restored = JSON.parse(localStorage.getItem('fz.recover') || 'null'); if (restored) { localStorage.setItem(RECOVER_KEY(), JSON.stringify(restored)); localStorage.removeItem('fz.recover'); } } } catch { } // 1.0.9e までの復旧データは窓 1 が引き継ぐ
  if (restored && restored.text) { try { ed.setDoc(FZ.parse(restored.text)); ed.dirty = true; st.file = restored.name ? { name: restored.name } : null; setFileName(restored.name || ''); msg('前回の続きを復元（未保存）', false, 8000); } catch { } }
  if (new URLSearchParams(location.search).get('open') === 'manual' && !(restored && (restored.text || restored.full === 'idb'))) loadManualHere(); // 取説の「文書で開く」から開いた窓
  const initial = typeof window.fzInitialFile === 'function'; if (restored && restored.full === 'idb' && !initial) restoreFromIdb(restored); // 大きい文書・画像は IndexedDB から（exe 版で起動引数のファイルがあるときは退避が先）
  if (!st.slot) msg(`窓が ${MAX_WINDOWS} つを超えました。この窓は復旧データを残しません`, true, 0);
  else { let orphan = 0; for (let n = 1; n <= MAX_WINDOWS; n++) { if (n === st.slot || slotAlive(n)) continue; try { if (localStorage.getItem('fz.recover.' + n)) orphan++; } catch { } } if (orphan && !restored) msg(`閉じた窓の未保存の文書が ${orphan} 件あります（${K('newWindow')} 新しい窓 で開くと復元します）`, false, 10000); }
  render(); focusTA(); syncTA();
  if (initial) openInitialFile(restored && (restored.text || restored.full === 'idb') ? restored : null); // exe 版：ダブルクリック・「送る」で渡されたファイル
  if (FZ.files.kind === 'basic') msg('このブラウザは直接保存に非対応（Edge／Chrome 推奨）', true, 0);
  document.fonts && document.fonts.ready.then(() => { geomDirty = true; render(); });
}
/* exe 版の起動引数のファイルを開く。この窓に前回の未保存の文書が復元されていたら、空いている窓の番号へ退避してから開く（ファイルの「新しい窓」で復元できる） */
async function openInitialFile(restored) {
  let r; try { r = await window.fzInitialFile(); } catch (e) { msg('開けませんでした：' + e, true); r = null; } if (!r || r.text == null) { if (restored && restored.full === 'idb') restoreFromIdb(restored); return; }
  if (restored) { let park = 0; for (let n = 1; n <= MAX_WINDOWS && !park; n++) { if (n === st.slot || slotAlive(n)) continue; try { if (!localStorage.getItem('fz.recover.' + n)) park = n; } catch { } }
    if (!park) { msg(`「${r.name}」を開く前に、復元した未保存の文書を保存してください（${K('open')} で開き直せます）`, true, 0); return; }
    try { localStorage.setItem('fz.recover.' + park, JSON.stringify(restored)); } catch { msg('未保存の文書を退避できませんでした。保存してから開いてください', true, 0); return; }
    if (restored.full === 'idb') { try { const v = await RDB.get(RECOVER_KEY()); if (v) await RDB.put('fz.recover.' + park, v); } catch { } } } // IndexedDB の全文も退避先へ写す（開いたあとの消去より前に）
  await loadText(r.text, r.name, { path: r.path, name: r.name }); if (restored) msg(`「${r.name}」を開きました。前回の未保存の文書は ${K('newWindow')} 新しい窓 で復元できます`, false, 10000);
}
boot();
FZ.app = { ed, st, run, render, treeModel, flush, openForm, toggleGroup, toggleSide, renderForPrint, loadText, drawSub, drawFkeys, prepareImages, officeDoc, cmds: () => CMDS.map(c => ({ id: c.id, label: c.label, group: c.group, keys: c.keys, path: (menuPaths().get(c.id) || []).join(" / "), kw: c.kw })), keysOf: id => { const c = cmdById(id); return c ? keysOf(c) : ''; }, GROUPS };
})(window.FZ);
