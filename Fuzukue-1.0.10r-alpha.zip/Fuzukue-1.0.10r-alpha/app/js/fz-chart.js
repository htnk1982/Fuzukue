/* 文机 — グラフ（図版の一種）
 * 図版に chart を持たせる：fig = { id, kind:'図'|'表', title, file:'', width, chart }
 *   chart = { type, corner, cats: [文字], series: [{ name, values: [数|null], shade }], unit, legend, labels, ratio }
 * 描き方は白黒：系列は網の文様（棒・積み上げ・帯・円）か線種と印（折れ線）で分ける。
 * 原本は「#グラフ」「#データ」「#グラフ設定」の指示行。PowerPoint・Word には編集できるグラフ（データは埋め込みの Excel）で渡す。Markdown は表（前に種類の注記） */
(function (FZ) {
'use strict';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const TYPES = [['bar', '棒'], ['barh', '横棒'], ['stack', '積み上げ'], ['line', '折れ線'], ['pie', '円'], ['band', '帯']];
const TN = Object.fromEntries(TYPES), TK = Object.fromEntries(TYPES.map(([k, v]) => [v, k]));
const LEG = [['auto', '自動'], ['bottom', '下'], ['right', '右'], ['top', '上'], ['none', 'なし']];
const LN = Object.fromEntries(LEG), LK = Object.fromEntries(LEG.map(([k, v]) => [v, k]));
/* 系列の網：黒・白・中・斜線・点・濃網…（隣どうしが白黒ではっきり分かれる順） */
const PALETTE = ['dark', 'none', 'mid', 'hatch', 'dots', 'deep', 'hatch2', 'grid', 'horz', 'check', 'gray', 'vert'];
/* 折れ線の線種と印 */
const LINES = [{ dash: '', mk: 'circle', fill: true, ppt: 'solid' }, { dash: '3 1.6', mk: 'circle', fill: false, ppt: 'dash' }, { dash: '0.8 1.3', mk: 'square', fill: true, ppt: 'sysDot' }, { dash: '4 1.4 1 1.4', mk: 'square', fill: false, ppt: 'dashDot' }, { dash: '', mk: 'tri', fill: false, ppt: 'solid' }, { dash: '2 1.8', mk: 'tri', fill: true, ppt: 'sysDash' }];
FZ.CHART_TYPES = TYPES; FZ.CHART_LEGENDS = LEG; FZ.CHART_PALETTE = PALETTE; FZ.CHART_NAMES = TN;
const DARK = new Set(['dark', 'deep']); // 白い字を載せる網

/* ---------- 数 ---------- */
/* 表の文字 → 数。全角・桁区切り・単位（% 円 億円 人 …）・△ ▲（負）・(123)（負）を読む。数でなければ null */
function parseNum(v) {
  if (v == null) return null; if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  let s = String(v).normalize('NFKC').trim(); if (!s) return null; let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1).trim(); }
  if (/^[△▲]/.test(s)) { neg = !neg; s = s.slice(1).trim(); }
  s = s.replace(/[,\s]/g, '').replace(/^[¥$€£]/, '');
  const m = s.match(/^([+\-−‐])?(\d+(?:\.\d+)?|\.\d+)(?:e([+-]?\d+))?([^\d.]*)$/i); if (!m) return null;
  let x = parseFloat(m[2] + (m[3] ? 'e' + m[3] : '')); if (m[1] && m[1] !== '+') x = -x; if (neg) x = -x; return Number.isFinite(x) ? x : null;
}
FZ.parseChartNum = parseNum;
const decimalsOf = vals => { let d = 0; for (const v of vals) { if (v == null) continue; const s = String(Math.abs(v)); const k = s.indexOf('.'); if (k >= 0 && !/e/i.test(s)) d = Math.max(d, s.length - k - 1); } return Math.min(d, 3); };
const fmt = (v, d) => (v < 0 ? '−' : '') + Math.abs(v).toLocaleString('ja-JP', { minimumFractionDigits: d, maximumFractionDigits: d });
FZ.chartFmt = fmt;

/* ---------- 形を整える ---------- */
const shadeOk = id => id === 'none' || (id && id !== 'text' && FZ.SHADE_BY && FZ.SHADE_BY[id]);
const shadeFromName = nm => { if (!nm || nm === '-') return null; if (nm === '白') return 'none'; const id = FZ.SHADE_KEYS && FZ.SHADE_KEYS[nm]; return shadeOk(id) ? id : (shadeOk(nm) ? nm : null); };
function normalizeChart(c) {
  c = c && typeof c === 'object' ? { ...c } : {};
  if (Array.isArray(c._rows) && c._rows.length) { const [h, ...rs] = c._rows; c.corner = h[0] || ''; c.cats = h.slice(1); c.series = rs.map((r, k) => ({ name: r[0] || '', values: r.slice(1), shade: shadeFromName(c._shades && c._shades[k]) })); }
  const type = TN[c.type] ? c.type : (TK[c.type] || 'bar');
  const cats = (Array.isArray(c.cats) ? c.cats : []).slice(0, 120).map(x => String(x ?? '').replace(/[\r\n]+/g, ' '));
  const series = (Array.isArray(c.series) ? c.series : []).filter(Boolean).slice(0, 24).map(s => ({ name: String(s.name ?? '').replace(/[\r\n]+/g, ' '), values: (Array.isArray(s.values) ? s.values : []).map(parseNum), shade: shadeOk(s.shade) ? s.shade : null }));
  const n = Math.max(1, cats.length, ...series.map(s => s.values.length)); while (cats.length < n) cats.push('');
  if (!series.length) series.push({ name: '', values: [], shade: null });
  for (const s of series) { s.values = s.values.slice(0, n); while (s.values.length < n) s.values.push(null); }
  return { type, corner: String(c.corner ?? ''), cats, series, unit: String(c.unit ?? ''), legend: LN[c.legend] ? c.legend : 'auto', labels: c.labels !== false, ratio: clamp(+c.ratio || 0.6, 0.3, 1.5) };
}
FZ.normalizeChart = normalizeChart;
FZ.chartShade = (c, k) => (c.series[k] && c.series[k].shade) || PALETTE[k % PALETTE.length];
const sliceShade = j => PALETTE[j % PALETTE.length];

/* ---------- 表（行×セルの文字）との行き来 ---------- */
/* グラフ → 表：1 行目は［角・項目…］、2 行目から［系列の名前・値…］ */
FZ.chartToGrid = c => [[c.corner, ...c.cats], ...c.series.map(s => [s.name, ...s.values.map(v => v == null ? '' : String(v))])];
/* 表 → グラフ。見出しの行・列があるかを中身から見分け、系列の向きは Excel と同じ（データの行が列より多ければ列が系列）。base.byCols で向きを決め打ち */
FZ.chartFromGrid = function (rows, base = {}) {
  let R = (rows || []).map(r => (r || []).map(x => String(x ?? '').replace(/\s+/g, ' ').trim()));
  while (R.length && R[R.length - 1].every(x => !x)) R.pop(); while (R.length && R[0].every(x => !x)) R.shift();
  let C = Math.max(0, ...R.map(r => r.length)); R = R.map(r => { const a = r.slice(0, C); while (a.length < C) a.push(''); return a; });
  for (let j = C - 1; j >= 0; j--) if (R.every(r => !r[j])) { R.forEach(r => r.splice(j, 1)); C--; }
  if (!R.length || !C) return normalizeChart(base);
  const isNum = x => x !== '' && parseNum(x) != null; const yearish = x => /^(19|20)\d\d(年度?|年|度)?$/.test(x);
  const headRow = R.length > 1 && (R[0][0] === '' || R[0].slice(1).some(x => x && !isNum(x)) || R[0].slice(C > 1 ? 1 : 0).every(yearish));
  const headCol = C > 1 && (R.slice(headRow ? 1 : 0).some(r => r[0] && !isNum(r[0])) || (headRow && R[0][0] !== '' && !isNum(R[0][0])) || R.slice(headRow ? 1 : 0).every(r => yearish(r[0])));
  const body = R.slice(headRow ? 1 : 0).map(r => r.slice(headCol ? 1 : 0)); if (!body.length || !body[0].length) return normalizeChart(base);
  const nr = body.length, nc = body[0].length; const byCols = base.byCols != null ? !!base.byCols : nr > nc;
  const rowLab = k => headCol ? R[(headRow ? 1 : 0) + k][0] : '', colLab = j => headRow ? R[0][(headCol ? 1 : 0) + j] : '';
  let cats, series;
  if (!byCols) { cats = Array.from({ length: nc }, (_, j) => colLab(j) || String(j + 1)); series = body.map((r, k) => ({ name: rowLab(k) || (nr > 1 ? '系列' + (k + 1) : ''), values: r })); }
  else { cats = Array.from({ length: nr }, (_, k) => rowLab(k) || String(k + 1)); series = Array.from({ length: nc }, (_, j) => ({ name: colLab(j) || (nc > 1 ? '系列' + (j + 1) : ''), values: body.map(r => r[j]) })); }
  const timeish = cats.length >= 8 && cats.filter(x => /^(19|20)\d\d|[年月期度]|^Q\d|^\d{1,2}$/.test(x)).length >= cats.length * 0.7;
  delete base.byCols; return normalizeChart({ type: timeish ? 'line' : 'bar', ...base, corner: headRow && headCol ? R[0][0] : '', cats, series });
};
/* 表の中身が数のグラフにできるか（数のセルが 2 つ以上） */
FZ.chartable = rows => { let n = 0; for (const r of rows || []) for (const x of r) if (parseNum(x) != null) n++; return n >= 2; };
FZ.chartTranspose = c => normalizeChart({ ...c, cats: c.series.map(s => s.name), series: c.cats.map((cat, j) => ({ name: cat, values: c.series.map(s => s.values[j]) })) });
FZ.chartSample = () => normalizeChart({ type: 'bar', corner: '', cats: ['2023年度', '2024年度', '2025年度'], series: [{ name: '国内', values: [120, 135, 150] }, { name: '海外', values: [80, 95, 130] }], unit: '億円' });

/* ---------- 原本の指示行 ---------- */
const escC = t => String(t).replace(/\|/g, '｜').replace(/[\r\n]+/g, ' ');
const escId = u => String(u).replace(/[\s<>]/g, c => encodeURIComponent(c)), unescId = u => String(u).replace(/%(20|09|3C|3E)/gi, m => decodeURIComponent(m));
FZ.chartLines = function (fg) {
  const c = fg.chart; const tt = String(fg.title || '').replace(/[\r\n]+/g, ' ').trim(); const wd = fg.width !== 100 || /^\d+[%％]$/.test(tt.split(' ')[0] || '') ? ' ' + fg.width + '%' : '';
  const L = ['#グラフ ' + escId(fg.id) + ' ' + fg.kind + ' ' + TN[c.type] + wd + (tt ? ' ' + tt : '')];
  for (const row of FZ.chartToGrid(c)) L.push('#データ | ' + row.map(escC).join(' | ') + ' |');
  const opt = []; if (c.unit) opt.push('単位=' + c.unit.replace(/ /g, '%20')); if (c.legend !== 'auto') opt.push('凡例=' + LN[c.legend]); if (!c.labels) opt.push('値=なし'); if (Math.abs(c.ratio - 0.6) > 1e-6) opt.push('縦横=' + Math.round(c.ratio * 100));
  if (c.series.some(s => s.shade)) opt.push('網=' + c.series.map(s => s.shade ? (s.shade === 'none' ? '白' : FZ.SHADE_NAMES[s.shade]) : '-').join(','));
  if (opt.length) L.push('#グラフ設定 ' + opt.join(' '));
  return L;
};
/* 「#グラフ 」の後 → 図版（データは続く #データ 行で埋める） */
FZ.chartFigFromLine = function (rest) {
  const toks = String(rest).trim().split(/[ \t]+/); if (toks.length < 3) return null;
  const kind = toks[1] === '表' ? '表' : '図', type = TK[toks[2]] || (TN[toks[2]] ? toks[2] : 'bar'); let k = 3, width = 100;
  const wm = toks[3] && toks[3].match(/^(\d+)[%％]$/); if (wm) { width = [50, 75, 100].includes(+wm[1]) ? +wm[1] : 100; k = 4; }
  return { id: unescId(toks[0]), kind, title: toks.slice(k).join(' '), file: '', width, chart: { type, _rows: [] } };
};
/* #データ・#グラフ設定 を組み立て中の図版へ。該当しなければ false */
FZ.chartDirective = function (raw, fg) {
  let m; const c = fg && fg.chart; if (!c) return false;
  if ((m = raw.match(/^#データ\s*\|(.*)\|\s*$/))) { (c._rows = c._rows || []).push(m[1].split('|').map(x => x.trim())); return true; }
  if ((m = raw.match(/^#グラフ設定\s+(.*)$/))) { for (const t of m[1].trim().split(/\s+/)) { const q = t.indexOf('='); if (q < 0) continue; const k = t.slice(0, q), v = t.slice(q + 1);
      if (k === '単位') c.unit = v.replace(/%20/g, ' '); else if (k === '凡例') c.legend = LK[v] || 'auto'; else if (k === '値') c.labels = v !== 'なし'; else if (k === '縦横') c.ratio = (+v || 60) / 100; else if (k === '網') c._shades = v.split(','); } return true; }
  return false;
};
/* Markdown：種類の注記（<!-- グラフ：棒 単位=億円 … -->）＋表 */
FZ.chartNote = c => '<!-- グラフ：' + TN[c.type] + (c.unit ? ' 単位=' + c.unit.replace(/ /g, '%20') : '') + (c.legend !== 'auto' ? ' 凡例=' + LN[c.legend] : '') + (!c.labels ? ' 値=なし' : '') + (Math.abs(c.ratio - 0.6) > 1e-6 ? ' 縦横=' + Math.round(c.ratio * 100) : '') + (c.series.some(s => s.shade) ? ' 網=' + c.series.map(s => s.shade ? (s.shade === 'none' ? '白' : FZ.SHADE_NAMES[s.shade]) : '-').join(',') : '') + ' -->';
FZ.chartFromNote = function (note, rows) { const m = String(note).match(/^<!--\s*グラフ[:：]\s*(\S+)(.*?)-->\s*$/); if (!m) return null; const fg = { chart: { type: TK[m[1]] || 'bar', _rows: rows } }; if (m[2].trim()) FZ.chartDirective('#グラフ設定 ' + m[2].trim(), fg); return normalizeChart(fg.chart); };

/* ---------- 描く（図形の一覧。画面・印刷の SVG と当たり判定が同じものを使う） ---------- */
/* 目盛：lo〜hi を 1・2・5 の刻みで */
function niceTicks(lo, hi, maxN) {
  if (!(hi > lo)) hi = lo + 1; const raw = (hi - lo) / Math.max(1, maxN); const p = Math.pow(10, Math.floor(Math.log10(raw))); const f = raw / p; const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
  const a = Math.floor(lo / step + 1e-9) * step, b = Math.ceil(hi / step - 1e-9) * step; const out = []; for (let v = a; v <= b + step * 1e-6; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : +v.toPrecision(12));
  return { ticks: out, step, lo: a, hi: b };
}
const tw = (s, size) => FZ.textWidth(String(s)) * size; // 文字の幅（pt）
/* 長い項目名を幅 w（pt）に収まるよう 2 行まで折る（溢れは …） */
function wrapLabel(s, size, w, maxLines = 2) {
  s = String(s); if (tw(s, size) <= w || w <= size) return [s]; const out = []; let cur = '';
  for (const g of FZ.graphemes(s)) { if (tw(cur + g.text, size) > w && cur) { out.push(cur); cur = ''; if (out.length >= maxLines) break; } cur += g.text; }
  if (out.length < maxLines) out.push(cur); else { const last = out[maxLines - 1]; out[maxLines - 1] = last.slice(0, Math.max(1, last.length - 1)) + '…'; }
  return out;
}
FZ.chartShapes = function (c, W, H, fs) {
  const S = []; const base = clamp(fs * 0.82, 6, 12), small = base * 0.92, pad = base * 0.55;
  const ns = c.series.length, nc = c.cats.length; const type = c.type;
  const allVals = c.series.flatMap(s => s.values).filter(v => v != null); const dec = decimalsOf(allVals);
  let top = pad * 0.6, bottom = H - pad * 0.6, left = pad * 0.6, right = W - pad * 0.6;
  const text = (x, y, t, o = {}) => S.push({ t: 'text', x, y, text: String(t), size: o.size || base, anchor: o.anchor || 'start', white: !!o.white, halo: !!o.halo, bold: !!o.bold });
  /* 凡例 */
  const legItems = type === 'pie' ? [] : c.series.map((s, k) => ({ name: s.name || ('系列' + (k + 1)), k }));
  let leg = c.legend === 'auto' ? (type === 'pie' ? 'none' : ns > 1 ? 'bottom' : 'none') : c.legend;
  if (type === 'pie' && leg !== 'none') c.cats.forEach((cat, j) => legItems.push({ name: cat || String(j + 1), j }));
  if (!legItems.length) leg = 'none';
  const sw = base * 1.5, sh = base * 0.85, gapI = base * 1.1;
  const legSwatch = (it, x, y) => { if (type === 'line' && it.k != null) { const L = LINES[it.k % LINES.length]; S.push({ t: 'line', x1: x, y1: y, x2: x + sw, y2: y, sw: it.k === 0 ? 1.3 : 1, dash: L.dash }); S.push({ t: 'mark', x: x + sw / 2, y, mk: L.mk, fill: L.fill, size: base * 0.42, s: it.k }); }
    else S.push({ t: 'rect', x, y: y - sh / 2, w: sw, h: sh, fill: it.j != null ? sliceShade(it.j) : FZ.chartShade(c, it.k), sw: 0.5, s: it.k, j: it.j, leg: true }); };
  if (leg === 'bottom' || leg === 'top') {
    const rows = [[]]; let x = 0; const avail = right - left; for (const it of legItems) { const w = sw + base * 0.35 + tw(it.name, small); if (x > 0 && x + w > avail) { rows.push([]); x = 0; } rows[rows.length - 1].push({ it, w }); x += w + gapI; }
    const rh = base * 1.45, lh = rows.length * rh; let y0 = leg === 'bottom' ? bottom - lh : top;
    for (const r of rows) { const tot = r.reduce((t, e) => t + e.w, 0) + gapI * (r.length - 1); let xx = left + (avail - tot) / 2; const cy = y0 + rh / 2;
      for (const e of r) { legSwatch(e.it, xx, cy); text(xx + sw + base * 0.35, cy + small * 0.36, e.it.name, { size: small }); xx += e.w + gapI; } y0 += rh; }
    if (leg === 'bottom') bottom -= lh + pad * 0.4; else top += lh + pad * 0.4;
  } else if (leg === 'right') {
    const lw = Math.min((right - left) * 0.4, sw + base * 0.35 + Math.max(...legItems.map(it => tw(it.name, small)))); const rh = base * 1.45; let y = (top + bottom) / 2 - legItems.length * rh / 2 + rh / 2; const x = right - lw;
    for (const it of legItems) { legSwatch(it, x, y); text(x + sw + base * 0.35, y + small * 0.36, it.name, { size: small }); y += rh; } right -= lw + pad;
  }
  /* 単位 */
  if (c.unit && type !== 'pie' && type !== 'band') { text(left, top + small * 0.9, '（' + c.unit + '）', { size: small }); top += small * 1.45; }
  if (type === 'pie') return pieShapes(c, S, text, { left, right, top, bottom, base, small, pad, dec, leg });
  if (type === 'band') return bandShapes(c, S, text, { left, right, top, bottom, base, small, pad, dec });
  const horiz = type === 'barh';
  /* 値の範囲 */
  let mn = Infinity, mx = -Infinity;
  if (type === 'stack') for (let j = 0; j < nc; j++) { let p = 0, q = 0; for (const s of c.series) { const v = s.values[j]; if (v == null) continue; if (v >= 0) p += v; else q += v; } mn = Math.min(mn, q); mx = Math.max(mx, p); }
  else for (const v of allVals) { mn = Math.min(mn, v); mx = Math.max(mx, v); }
  if (!Number.isFinite(mn)) { mn = 0; mx = 1; }
  let lo = Math.min(0, mn), hi = Math.max(0, mx); if (type === 'line' && mn > 0 && mn > mx * 0.55) lo = mn - (mx - mn) * 0.25;
  const valLabelRoom = c.labels ? base * 1.1 : base * 0.3;
  if (!horiz) {
    const plotH0 = bottom - top; const T = niceTicks(lo, hi, clamp(Math.round(plotH0 / (base * 2.6)), 2, 8)); lo = T.lo; hi = T.hi; const tdec = decimalsOf([T.step]);
    const labs = T.ticks.map(v => fmt(v, tdec)); left += Math.max(...labs.map(l => tw(l, small))) + pad * 0.6;
    const bandW = (right - left) / nc; const catLines = c.cats.map(t => wrapLabel(t, small, bandW * 0.96)); const nl = Math.max(1, ...catLines.map(l => l.length));
    bottom -= nl * small * 1.2 + pad * 0.3; const plotTop = top + (c.labels ? valLabelRoom * 0.6 : 0);
    const Y = v => bottom - (v - lo) / (hi - lo) * (bottom - plotTop);
    T.ticks.forEach((v, k) => { const y = Y(v); if (v !== 0) S.push({ t: 'line', x1: left, y1: y, x2: right, y2: y, sw: 0.3, dash: '0.6 1.2' }); text(left - pad * 0.4, y + small * 0.35, labs[k], { size: small, anchor: 'end' }); });
    S.push({ t: 'line', x1: left, y1: Y(Math.max(lo, Math.min(hi, 0))), x2: right, y2: Y(Math.max(lo, Math.min(hi, 0))), sw: 0.6 });
    catLines.forEach((ls, j) => ls.forEach((l, q) => text(left + (j + 0.5) * bandW, bottom + pad * 0.3 + small * (q + 1) * 1.1, l, { size: small, anchor: 'middle' })));
    if (type === 'bar') { const gw = bandW * (ns > 1 ? 0.78 : 0.6), bw = gw / ns;
      for (let j = 0; j < nc; j++) for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null) continue; const x = left + j * bandW + (bandW - gw) / 2 + k * bw; const y1 = Y(Math.max(v, 0)), y2 = Y(Math.min(v, 0));
        S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill: FZ.chartShade(c, k), sw: 0.5, s: k, j, hit: true });
        if (c.labels) { const lab = fmt(v, dec); const size = Math.max(base * 0.6, Math.min(small, bw * 1.15 / Math.max(1, FZ.textWidth(lab)))); text(x + bw / 2, v >= 0 ? y1 - size * 0.3 : y2 + size * 1.05, lab, { size, anchor: 'middle' }); } } }
    else if (type === 'stack') { const bw = bandW * 0.56;
      for (let j = 0; j < nc; j++) { let p = 0, q = 0; const x = left + j * bandW + (bandW - bw) / 2;
        for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null || v === 0) continue; const a = v >= 0 ? p : q, b = a + v; if (v >= 0) p = b; else q = b; const y1 = Y(Math.max(a, b)), y2 = Y(Math.min(a, b)); const sh2 = FZ.chartShade(c, k);
          S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill: sh2, sw: 0.5, s: k, j, hit: true });
          if (c.labels && y2 - y1 > small * 1.15) { const lab = fmt(v, dec); if (tw(lab, small) < bw * 0.98) text(x + bw / 2, (y1 + y2) / 2 + small * 0.36, lab, { size: small, anchor: 'middle', white: DARK.has(sh2), halo: !DARK.has(sh2) && sh2 !== 'none' }); } }
        if (c.labels && ns > 1 && p > 0) text(x + bw / 2, Y(p) - small * 0.3, fmt(p, dec), { size: small, anchor: 'middle', bold: true }); } }
    else { // 折れ線
      const X = j => left + (j + 0.5) * bandW;
      c.series.forEach((s, k) => { const L = LINES[k % LINES.length]; let d = '', pen = false; const pts = [];
        s.values.forEach((v, j) => { if (v == null) { pen = false; return; } const x = X(j), y = Y(v); d += (pen ? 'L' : 'M') + x.toFixed(2) + ' ' + y.toFixed(2); pen = true; pts.push({ x, y, v, j }); });
        if (d) S.push({ t: 'path', d, fill: 'none', sw: k === 0 ? 1.4 : 1.05, dash: L.dash, s: k, pts, hit: true });
        for (const p of pts) S.push({ t: 'mark', x: p.x, y: p.y, mk: L.mk, fill: L.fill, size: base * 0.44, s: k, j: p.j, hit: true });
        if (c.labels && ns <= 3) for (const p of pts) text(p.x, k % 2 ? p.y + small * 1.35 : p.y - small * 0.55, fmt(p.v, dec), { size: small * 0.95, anchor: 'middle', halo: true }); }); }
    return S;
  }
  /* 横棒：項目は上から下へ、値の軸は下 */
  const catW = Math.min((right - left) * 0.36, Math.max(...c.cats.map(t => tw(t, small))) + pad * 0.6);
  const T = niceTicks(lo, hi, clamp(Math.round((right - left - catW) / (base * 4.5)), 2, 7)); lo = T.lo; hi = T.hi; const tdec = decimalsOf([T.step]); const labs = T.ticks.map(v => fmt(v, tdec));
  bottom -= small * 1.4; const lab0 = c.labels ? Math.max(...allVals.map(v => tw(fmt(v, dec), small))) + pad * 0.3 : 0; right -= Math.min(lab0, (right - left) * 0.2); left += catW;
  const Xv = v => left + (v - lo) / (hi - lo) * (right - left); const bandH = (bottom - top) / nc;
  T.ticks.forEach((v, k) => { const x = Xv(v); if (v !== 0) S.push({ t: 'line', x1: x, y1: top, x2: x, y2: bottom, sw: 0.3, dash: '0.6 1.2' }); text(x, bottom + small * 1.15, labs[k], { size: small, anchor: 'middle' }); });
  S.push({ t: 'line', x1: Xv(Math.max(lo, Math.min(hi, 0))), y1: top, x2: Xv(Math.max(lo, Math.min(hi, 0))), y2: bottom, sw: 0.6 });
  c.cats.forEach((t, j) => { const ls = wrapLabel(t, small, catW - pad * 0.6); const cy = top + (j + 0.5) * bandH; ls.forEach((l, q) => text(left - pad * 0.5, cy + small * 0.36 + (q - (ls.length - 1) / 2) * small * 1.1, l, { size: small, anchor: 'end' })); });
  const gh = bandH * (ns > 1 ? 0.78 : 0.6), bh = gh / ns;
  for (let j = 0; j < nc; j++) for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null) continue; const y = top + j * bandH + (bandH - gh) / 2 + k * bh; const x1 = Xv(Math.min(v, 0)), x2 = Xv(Math.max(v, 0));
    S.push({ t: 'rect', x: x1, y, w: Math.max(0.01, x2 - x1), h: bh, fill: FZ.chartShade(c, k), sw: 0.5, s: k, j, hit: true });
    if (c.labels) { const size = Math.max(base * 0.6, Math.min(small, bh * 0.95)); text(v >= 0 ? x2 + pad * 0.3 : x1 - pad * 0.3, y + bh / 2 + size * 0.36, fmt(v, dec), { size, anchor: v >= 0 ? 'start' : 'end' }); } }
  return S;
};
/* 帯グラフ（100% の横棒）：項目ごとに 1 本、系列の構成比 */
function bandShapes(c, S, text, g) {
  let { left, right, top, bottom, base, small, pad, dec } = g; const nc = c.cats.length, ns = c.series.length;
  const catW = Math.min((right - left) * 0.3, Math.max(0, ...c.cats.map(t => tw(t, small))) + pad * 0.6); left += catW;
  const bandH = (bottom - top) / nc; const bh = Math.min(bandH * 0.62, base * 2.6);
  for (let j = 0; j < nc; j++) { const vals = c.series.map(s => Math.max(0, s.values[j] || 0)); const tot = vals.reduce((a, b) => a + b, 0); const pctIn = Math.abs(tot - 100) < 1.5; const cy = top + (j + 0.5) * bandH; let x = left;
    const ls = wrapLabel(c.cats[j], small, catW - pad * 0.6); ls.forEach((l, q) => text(left - pad * 0.5, cy + small * 0.36 + (q - (ls.length - 1) / 2) * small * 1.1, l, { size: small, anchor: 'end' }));
    if (!tot) continue;
    vals.forEach((v, k) => { if (!v) return; const w = (right - left) * v / tot; const sh2 = FZ.chartShade(c, k); S.push({ t: 'rect', x, y: cy - bh / 2, w, h: bh, fill: sh2, sw: 0.5, s: k, j, hit: true });
      if (c.labels) { const lab = pctIn ? fmt(v, dec) + '%' : fmt(Math.round(v / tot * 1000) / 10, v / tot < 0.1 ? 1 : 0) + '%'; if (tw(lab, small) < w * 0.96) text(x + w / 2, cy + small * 0.36, lab, { size: small, anchor: 'middle', white: DARK.has(sh2), halo: !DARK.has(sh2) && sh2 !== 'none' }); }
      x += w; }); }
  return S;
}
/* 円：最初の系列。12 時から時計回り。入る切れは中に名前と率、入らない切れは外に引き出し線（左右それぞれ上下に重ならないよう詰め直す） */
function pieShapes(c, S, text, g) {
  const { left, right, top, bottom, base, small, pad, leg } = g; const vals = c.series[0].values.map(v => Math.max(0, v || 0)); const tot = vals.reduce((a, b) => a + b, 0);
  const cx = (left + right) / 2, cy = (top + bottom) / 2; const W2 = (right - left) / 2, H2 = (bottom - top) / 2;
  if (!tot) { S.push({ t: 'circle', cx, cy, r: Math.max(4, Math.min(W2, H2) - pad), sw: 0.5 }); return S; }
  const sl = []; let a = -Math.PI / 2;
  vals.forEach((v, j) => { if (!v) return; const da = v / tot * Math.PI * 2; const pct = Math.round(v / tot * 1000) / 10; const name = leg === 'none' ? (c.cats[j] || '') : ''; const pl = fmt(pct, pct < 10 ? 1 : 0) + '%'; sl.push({ j, a0: a, a1: a + da, da, mid: a + da / 2, name, pl, sh: sliceShade(j) }); a += da; });
  const fits = (x, r) => { const w = Math.max(tw(x.pl, small), x.name ? tw(x.name, small) : 0) * 1.08, h = small * (x.name ? 2.4 : 1.3); return x.da >= 0.3 && 2 * r * 0.6 * Math.sin(Math.min(Math.PI / 2, x.da / 2)) > w && r * 0.75 > h; };
  const r0 = Math.max(4, Math.min(W2 - pad, H2 - pad * 0.4)); let r = r0;
  if (c.labels) { const outs = sl.filter(x => !fits(x, r)); if (outs.length) { const ow = Math.max(...outs.map(x => tw((x.name ? x.name + ' ' : '') + x.pl, small))); r = Math.max(4, Math.min(W2 - ow - base * 1.6, H2 - small * 0.9)); } }
  /* 狭くて円が小さくなりすぎる時は、円の右に「網・名前・率」の一覧（凡例に率を添えたもの） */
  if (c.labels && r < r0 * 0.7) { const sw = base * 1.5, sh = base * 0.85, rh = small * 1.45; const items = sl.map(x => ({ x, t: (c.cats[x.j] || String(x.j + 1)) + ' ' + x.pl })); const lw = sw + base * 0.35 + Math.max(...items.map(e => tw(e.t, small)));
    const rr = Math.max(4, Math.min(H2 - pad * 0.4, ((right - left) - lw - base * 0.8) / 2)); const ccx = left + rr + pad * 0.2; const lx = ccx + rr + base * 0.8; let y = cy - items.length * rh / 2 + rh / 2;
    for (const x of sl) S.push({ t: 'wedge', cx: ccx, cy, r: rr, a0: x.a0, a1: x.a1, fill: x.sh, sw: 0.6, s: 0, j: x.j, hit: true });
    for (const e of items) { S.push({ t: 'rect', x: lx, y: y - sh / 2, w: sw, h: sh, fill: e.x.sh, sw: 0.5, j: e.x.j, leg: true }); text(lx + sw + base * 0.35, y + small * 0.36, e.t, { size: small }); y += rh; }
    return S; }
  for (const x of sl) S.push({ t: 'wedge', cx, cy, r, a0: x.a0, a1: x.a1, fill: x.sh, sw: 0.6, s: 0, j: x.j, hit: true });
  if (!c.labels) return S;
  const outs = { l: [], r: [] };
  for (const x of sl) { if (fits(x, r)) { const tx = cx + Math.cos(x.mid) * r * 0.6, ty = cy + Math.sin(x.mid) * r * 0.6; const o = { size: small, anchor: 'middle', white: DARK.has(x.sh), halo: !DARK.has(x.sh) && x.sh !== 'none' };
      if (x.name) { text(tx, ty - small * 0.2, x.name, o); text(tx, ty + small * 1.0, x.pl, o); } else text(tx, ty + small * 0.36, x.pl, o); continue; }
    const side = Math.cos(x.mid) >= 0 ? 'r' : 'l'; outs[side].push({ x, y: cy + Math.sin(x.mid) * r * 1.15 }); }
  const gap = small * 1.25;
  for (const side of ['l', 'r']) { const L = outs[side].sort((p, q) => p.y - q.y); const lo = top + small * 0.6, hi = bottom - small * 0.3;
    for (let k = 0; k < L.length; k++) L[k].y = Math.max(L[k].y, k ? L[k - 1].y + gap : lo); /* 上から詰める */
    for (let k = L.length - 1; k >= 0; k--) L[k].y = Math.min(L[k].y, k < L.length - 1 ? L[k + 1].y - gap : hi); /* 下からはみ出しを戻す */
    for (const e of L) { const x = e.x, rs = side === 'r'; const x1 = cx + Math.cos(x.mid) * r * 0.92, y1 = cy + Math.sin(x.mid) * r * 0.92; const x2 = cx + (rs ? 1 : -1) * Math.max(Math.abs(Math.cos(x.mid)) * r * 1.1, r * 0.35 + Math.sqrt(Math.max(0, r * r * 1.21 - (e.y - cy) * (e.y - cy))) * 0.7); const x3 = x2 + (rs ? base * 0.6 : -base * 0.6);
      S.push({ t: 'line', x1, y1, x2, y2: e.y, sw: 0.4 }, { t: 'line', x1: x2, y1: e.y, x2: x3, y2: e.y, sw: 0.4 }); text(x3 + (rs ? 2 : -2), e.y + small * 0.36, (x.name ? x.name + ' ' : '') + x.pl, { size: small, anchor: rs ? 'start' : 'end' }); } }
  return S;
}
/* SVG（ページの座標 X, Y に幅 W・高さ H）。F：文様の id → 塗り（url(#…)）。cls：字の書体のクラス */
const n2 = v => String(Math.round(v * 100) / 100);
const escX = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
FZ.chartSvg = function (c, X, Y, W, H, o = {}) {
  const F = o.F || {}; const fill = id => id === 'none' ? '#fff' : (F[id] || '#000'); const out = []; const shapes = FZ.chartShapes(c, W, H, o.fs || 10.5); const cls = o.cls || 'fgr', bcls = o.bcls || 'fg';
  const markPath = (m) => { const s = m.size; if (m.mk === 'square') return `<rect x="${n2(m.x - s)}" y="${n2(m.y - s)}" width="${n2(2 * s)}" height="${n2(2 * s)}"`; if (m.mk === 'tri') return `<polygon points="${n2(m.x)},${n2(m.y - s * 1.15)} ${n2(m.x + s * 1.1)},${n2(m.y + s * 0.8)} ${n2(m.x - s * 1.1)},${n2(m.y + s * 0.8)}"`; return `<circle cx="${n2(m.x)}" cy="${n2(m.y)}" r="${n2(s)}"`; };
  for (const s of shapes) {
    if (s.t === 'rect') out.push(`<rect x="${n2(s.x)}" y="${n2(s.y)}" width="${n2(s.w)}" height="${n2(s.h)}" fill="${fill(s.fill)}"/><rect x="${n2(s.x)}" y="${n2(s.y)}" width="${n2(s.w)}" height="${n2(s.h)}" fill="none" stroke="#000" stroke-width="${s.sw}"/>`); // 網（印刷では画像に置き換わる）と枠を分ける
    else if (s.t === 'line') out.push(`<line x1="${n2(s.x1)}" y1="${n2(s.y1)}" x2="${n2(s.x2)}" y2="${n2(s.y2)}" stroke="#000" stroke-width="${s.sw}"${s.dash ? ` stroke-dasharray="${s.dash}"` : ''}/>`);
    else if (s.t === 'path') out.push(`<path d="${s.d}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"${s.dash ? ` stroke-dasharray="${s.dash}"` : ''}/>`);
    else if (s.t === 'mark') out.push(markPath(s) + ` fill="${s.fill ? '#000' : '#fff'}" stroke="#000" stroke-width="0.6"/>`);
    else if (s.t === 'circle') out.push(`<circle cx="${n2(s.cx)}" cy="${n2(s.cy)}" r="${n2(s.r)}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-dasharray="2 1.5"/>`);
    else if (s.t === 'wedge') { const full = s.a1 - s.a0 >= Math.PI * 2 - 1e-6; const p0x = s.cx + Math.cos(s.a0) * s.r, p0y = s.cy + Math.sin(s.a0) * s.r, p1x = s.cx + Math.cos(s.a1) * s.r, p1y = s.cy + Math.sin(s.a1) * s.r; const lg = s.a1 - s.a0 > Math.PI ? 1 : 0;
      const d = full ? `M${n2(s.cx - s.r)} ${n2(s.cy)}a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(2 * s.r)} 0a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(-2 * s.r)} 0Z` : `M${n2(s.cx)} ${n2(s.cy)}L${n2(p0x)} ${n2(p0y)}A${n2(s.r)} ${n2(s.r)} 0 ${lg} 1 ${n2(p1x)} ${n2(p1y)}Z`;
      if (s.fill === 'none' || !F[s.fill]) out.push(`<path d="${d}" fill="${fill(s.fill)}" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"/>`);
      else { const cid = (o.uid || 'ch') + '_w' + s.j; out.push(`<clipPath id="${cid}"><path d="${d}"/></clipPath><rect x="${n2(s.cx - s.r - 1)}" y="${n2(s.cy - s.r - 1)}" width="${n2(2 * s.r + 2)}" height="${n2(2 * s.r + 2)}" fill="${fill(s.fill)}" clip-path="url(#${cid})"/><path d="${d}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"/>`); } } /* 網の切れは矩形を扇で切り抜く（印刷で網を画像にするのは矩形だけ） */
    else if (s.t === 'text') out.push(`<text class="${s.bold ? bcls : cls}" x="${n2(s.x)}" y="${n2(s.y)}" font-size="${n2(s.size)}"${s.anchor !== 'start' ? ` text-anchor="${s.anchor}"` : ''} fill="${s.white ? '#fff' : '#000'}"${s.halo ? ' stroke="#fff" stroke-width="' + n2(s.size * 0.28) + '" paint-order="stroke" stroke-linejoin="round"' : ''}>${escX(s.text)}</text>`);
  }
  return `<g class="chart" transform="translate(${n2(X)} ${n2(Y)})">${out.join('')}</g>`;
};
/* 当たり判定：グラフの中の点 (x, y)（pt、グラフの左上が原点）→ { s: 系列, j: 項目 }（円の切れは j だけ意味がある） */
FZ.chartHit = function (c, W, H, fs, x, y) {
  const shapes = FZ.chartShapes(c, W, H, fs); let best = null;
  for (let q = shapes.length - 1; q >= 0; q--) { const s = shapes[q]; if (!s.hit && !s.leg) continue;
    if (s.t === 'rect' && x >= s.x - 1 && x <= s.x + s.w + 1 && y >= s.y - 1 && y <= s.y + s.h + 1) return { s: s.s ?? null, j: s.j ?? null };
    if (s.t === 'mark' && Math.hypot(x - s.x, y - s.y) <= s.size + 2.5) return { s: s.s, j: s.j };
    if (s.t === 'wedge') { const dx = x - s.cx, dy = y - s.cy; if (Math.hypot(dx, dy) > s.r + 1) continue; let a = Math.atan2(dy, dx); while (a < s.a0) a += Math.PI * 2; if (a <= s.a1) return { s: 0, j: s.j }; }
    if (s.t === 'path' && s.pts) for (let k = 1; k < s.pts.length; k++) { const A = s.pts[k - 1], B = s.pts[k]; const vx = B.x - A.x, vy = B.y - A.y; const t = clamp(((x - A.x) * vx + (y - A.y) * vy) / (vx * vx + vy * vy || 1), 0, 1); const d = Math.hypot(A.x + vx * t - x, A.y + vy * t - y); if (d < 2.5 && (!best || d < best.d)) best = { s: s.s, j: null, d }; }
  }
  return best ? { s: best.s, j: null } : null;
};
/* 系列 k の図形の外枠（選んだ系列を画面で示す）：[{ x, y, w, h }]（pt） */
FZ.chartSeriesBoxes = function (c, W, H, fs, k, j) {
  const out = []; for (const s of FZ.chartShapes(c, W, H, fs)) { if (s.leg) continue;
    if (c.type === 'pie') { if (s.t === 'wedge' && s.j === j) out.push({ x: s.cx - s.r, y: s.cy - s.r, w: 2 * s.r, h: 2 * s.r }); continue; }
    if (s.s !== k) continue; if (s.t === 'rect') out.push({ x: s.x, y: s.y, w: s.w, h: s.h }); else if (s.t === 'mark') out.push({ x: s.x - s.size, y: s.y - s.size, w: s.size * 2, h: s.size * 2 }); }
  return out;
};

/* ---------- PowerPoint・Word：編集できるグラフ（c:chartSpace）と埋め込みの Excel ---------- */
const colName = k => { let s = ''; k++; while (k > 0) { const m = (k - 1) % 26; s = String.fromCharCode(65 + m) + s; k = Math.floor((k - 1) / 26); } return s; };
const xe = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
/* 書き出す値：帯は構成比（0〜1）にする（Office の 100% 積み上げの値ラベルは元の値を出すため） */
function exportValues(c) {
  if (c.type !== 'band') return c.series.map(s => s.values);
  const tot = c.cats.map((_, j) => c.series.reduce((t, s) => t + Math.max(0, s.values[j] || 0), 0)); return c.series.map(s => s.values.map((v, j) => v == null ? null : tot[j] ? Math.max(0, v) / tot[j] : 0));
}
FZ.chartXlsx = function (c) {
  const V = exportValues(c); const pct = c.type === 'band'; const rows = [];
  const cellS = (r, k, t) => `<c r="${colName(k)}${r}" t="inlineStr"><is><t xml:space="preserve">${xe(t)}</t></is></c>`, cellN = (r, k, v) => `<c r="${colName(k)}${r}"${pct ? ' s="1"' : ''}><v>${v}</v></c>`;
  rows.push(`<row r="1">${cellS(1, 0, c.corner)}${c.series.map((s, k) => cellS(1, k + 1, s.name || '系列' + (k + 1))).join('')}</row>`);
  c.cats.forEach((cat, j) => rows.push(`<row r="${j + 2}">${cellS(j + 2, 0, cat)}${c.series.map((s, k) => V[k][j] == null ? '' : cellN(j + 2, k + 1, V[k][j])).join('')}</row>`));
  const NSM = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', NSR = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', H = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  const files = [
    { name: '[Content_Types].xml', data: `${H}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>` },
    { name: '_rels/.rels', data: `${H}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${NSR}/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: 'xl/workbook.xml', data: `${H}<workbook xmlns="${NSM}" xmlns:r="${NSR}"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>` },
    { name: 'xl/_rels/workbook.xml.rels', data: `${H}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${NSR}/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="${NSR}/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: `${H}<styleSheet xmlns="${NSM}"><fonts count="1"><font><sz val="11"/><name val="Yu Gothic"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="9" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>` },
    { name: 'xl/worksheets/sheet1.xml', data: `${H}<worksheet xmlns="${NSM}"><sheetData>${rows.join('')}</sheetData></worksheet>` },
  ];
  return FZ.zip(files);
};
/* o = { latin, ea, sz（1/100 pt）, ext: 埋め込みの Excel の関係 ID } */
FZ.chartXml = function (c, o = {}) {
  const sz = o.sz || 900; const font = `<a:latin typeface="${xe(o.latin || 'Yu Gothic')}"/><a:ea typeface="${xe(o.ea || o.latin || 'Yu Gothic')}"/>`;
  const txPr = (size = sz, white = false, bold = false) => `<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${size}" b="${bold ? 1 : 0}"><a:solidFill><a:srgbClr val="${white ? 'FFFFFF' : '000000'}"/></a:solidFill>${font}</a:defRPr></a:pPr><a:endParaRPr lang="ja-JP"/></a:p></c:txPr>`;
  const solid = hex => `<a:solidFill><a:srgbClr val="${hex}"/></a:solidFill>`; const ln = (w = 6350, dash) => `<a:ln w="${w}">${solid('000000')}${dash && dash !== 'solid' ? `<a:prstDash val="${dash}"/>` : ''}</a:ln>`;
  const fillX = id => id === 'none' ? solid('FFFFFF') : id === 'dark' ? solid('000000') : `<a:pattFill prst="${(FZ.SHADE_BY[id] || {}).ppt || 'pct30'}"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>`;
  const V = exportValues(c); const dec = decimalsOf(c.series.flatMap(s => s.values)); const numCode = c.type === 'band' ? '0%' : dec ? '#,##0.' + '0'.repeat(dec) : '#,##0';
  const nC = c.cats.length; const catRef = `Sheet1!$A$2:$A$${nC + 1}`;
  const strCache = arr => `<c:strCache><c:ptCount val="${arr.length}"/>${arr.map((t, i) => `<c:pt idx="${i}"><c:v>${xe(t)}</c:v></c:pt>`).join('')}</c:strCache>`;
  const numCache = arr => `<c:numCache><c:formatCode>${c.type === 'band' ? '0%' : 'General'}</c:formatCode><c:ptCount val="${arr.length}"/>${arr.map((v, i) => v == null ? '' : `<c:pt idx="${i}"><c:v>${v}</c:v></c:pt>`).join('')}</c:numCache>`;
  const legK = c.legend === 'auto' ? (c.type === 'pie' ? 'none' : c.series.length > 1 ? 'bottom' : 'none') : c.legend;
  const dl = (pos, white, extra = '') => c.labels ? `<c:dLbls><c:numFmt formatCode="${extra === 'pie' ? '0%' : numCode}" sourceLinked="0"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>${txPr(sz, white)}${pos ? `<c:dLblPos val="${pos}"/>` : ''}<c:showLegendKey val="0"/><c:showVal val="${extra === 'pie' ? 0 : 1}"/><c:showCatName val="${extra === 'pie' && legK === 'none' ? 1 : 0}"/><c:showSerName val="0"/><c:showPercent val="${extra === 'pie' ? 1 : 0}"/><c:showBubbleSize val="0"/>${extra === 'pie' ? `<c:separator>${legK === 'none' ? '\n' : ' '}</c:separator><c:showLeaderLines val="1"/>` : ''}</c:dLbls>` : '';
  const serHead = k => `<c:idx val="${k}"/><c:order val="${k}"/><c:tx><c:strRef><c:f>Sheet1!$${colName(k + 1)}$1</c:f>${strCache([c.series[k].name || '系列' + (k + 1)])}</c:strRef></c:tx>`;
  const catVal = k => `<c:cat><c:strRef><c:f>${catRef}</c:f>${strCache(c.cats)}</c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$${colName(k + 1)}$2:$${colName(k + 1)}$${nC + 1}</c:f>${numCache(V[k])}</c:numRef></c:val>`;
  const AX1 = 50010001, AX2 = 50010002; let plot = '', axes = '';
  const horiz = c.type === 'barh' || c.type === 'band';
  const unitTitle = c.unit && c.type !== 'pie' && c.type !== 'band' ? `<c:title><c:tx><c:rich><a:bodyPr rot="0" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${sz}" b="0">${font}</a:defRPr></a:pPr><a:r><a:rPr lang="ja-JP" sz="${sz}" b="0">${font}</a:rPr><a:t>（${xe(c.unit)}）</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>` : '';
  const catAx = `<c:catAx><c:axId val="${AX1}"/><c:scaling><c:orientation val="${horiz ? 'maxMin' : 'minMax'}"/></c:scaling><c:delete val="0"/><c:axPos val="${horiz ? 'l' : 'b'}"/><c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="low"/><c:spPr><a:noFill/>${ln(9525)}</c:spPr>${txPr()}<c:crossAx val="${AX2}"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>`;
  const valAx = `<c:valAx><c:axId val="${AX2}"/><c:scaling><c:orientation val="minMax"/>${c.type === 'band' ? '<c:max val="1"/><c:min val="0"/>' : ''}</c:scaling><c:delete val="${c.type === 'band' ? 1 : 0}"/><c:axPos val="${horiz ? 'b' : 'l'}"/><c:majorGridlines><c:spPr><a:ln w="3175">${solid('808080')}<a:prstDash val="sysDot"/></a:ln></c:spPr></c:majorGridlines>${unitTitle}<c:numFmt formatCode="${c.type === 'band' ? '0%' : '#,##0'}" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>${txPr()}<c:crossAx val="${AX1}"/><c:crosses val="${horiz ? 'max' : 'autoZero'}"/><c:crossBetween val="between"/></c:valAx>`;
  if (c.type === 'bar' || c.type === 'barh' || c.type === 'stack' || c.type === 'band') {
    const grouping = c.type === 'stack' ? 'stacked' : c.type === 'band' ? 'percentStacked' : 'clustered'; const stacked = grouping !== 'clustered';
    const sers = c.series.map((s, k) => { const sh = FZ.chartShade(c, k); return `<c:ser>${serHead(k)}<c:spPr>${fillX(sh)}${ln(6350)}</c:spPr><c:invertIfNegative val="0"/>${dl(stacked ? 'ctr' : 'outEnd', stacked && DARK.has(sh))}${catVal(k)}</c:ser>`; }).join('');
    plot = `<c:barChart><c:barDir val="${horiz ? 'bar' : 'col'}"/><c:grouping val="${grouping}"/><c:varyColors val="0"/>${sers}<c:gapWidth val="${stacked ? 80 : c.series.length > 1 ? 40 : 70}"/>${stacked ? '<c:overlap val="100"/>' : ''}<c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:barChart>`; axes = catAx + valAx;
  } else if (c.type === 'line') {
    const sers = c.series.map((s, k) => { const L = LINES[k % LINES.length]; return `<c:ser>${serHead(k)}<c:spPr><a:ln w="${k === 0 ? 19050 : 15875}" cap="rnd">${solid('000000')}${L.ppt !== 'solid' ? `<a:prstDash val="${L.ppt}"/>` : ''}<a:round/></a:ln></c:spPr><c:marker><c:symbol val="${L.mk === 'tri' ? 'triangle' : L.mk}"/><c:size val="6"/><c:spPr>${solid(L.fill ? '000000' : 'FFFFFF')}${ln(9525)}</c:spPr></c:marker>${c.series.length <= 3 ? dl(k % 2 ? 'b' : 't', false) : ''}${catVal(k)}<c:smooth val="0"/></c:ser>`; }).join('');
    plot = `<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${sers}<c:marker val="1"/><c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:lineChart>`; axes = catAx + valAx;
  } else { // 円
    const dpts = c.cats.map((_, j) => `<c:dPt><c:idx val="${j}"/><c:bubble3D val="0"/><c:spPr>${fillX(sliceShade(j))}${ln(7620)}</c:spPr></c:dPt>`).join('');
    plot = `<c:pieChart><c:varyColors val="1"/><c:ser>${serHead(0)}${dpts}${dl('bestFit', false, 'pie')}${catVal(0)}</c:ser><c:firstSliceAng val="0"/></c:pieChart>`;
  }
  const legPos = { bottom: 'b', right: 'r', top: 't' }; const leg = legK;
  const legend = leg !== 'none' ? `<c:legend><c:legendPos val="${legPos[leg]}"/><c:overlay val="0"/>${txPr()}</c:legend>` : '';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="ja-JP"/><c:roundedCorners val="0"/><c:chart><c:autoTitleDeleted val="1"/><c:plotArea><c:layout/>${plot}${axes}<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr></c:plotArea>${legend}<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:spPr>${solid('FFFFFF')}<a:ln><a:noFill/></a:ln></c:spPr>${txPr()}${o.ext ? `<c:externalData r:id="${o.ext}"><c:autoUpdate val="0"/></c:externalData>` : ''}</c:chartSpace>`;
};
FZ.CHART_CT = 'application/vnd.openxmlformats-officedocument.drawingml.chart+xml';
FZ.XLSX_CT = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
