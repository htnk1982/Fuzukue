/* 文机 — Word（.docx）書き出し
 * 方針：Word の「自然な」文書にする。版面は行グリッド（docGrid linesAndChars）、見出しは見出しスタイル、
 * 章番号・箇条書きは Word の自動番号（階層体系をそのまま多段階リストに）、表は表、図は図形（グループ）。 */
(function (FZ) {
  'use strict';
  const M = FZ.M, esc = FZ.xmlEsc; const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const TW = pt => Math.round(pt * 20), EMU = pt => Math.round(pt * 12700);
  const BORDER_SZ = { thin: 4, thick: 12, double: 4, dotted: 4, none: 0 };
  const borderXml = (side, kind) => !kind || kind === 'none' ? `<w:${side} w:val="nil"/>` : `<w:${side} w:val="${kind === 'double' ? 'double' : kind === 'dotted' ? 'dotted' : 'single'}" w:sz="${BORDER_SZ[kind] || 4}" w:space="0" w:color="000000"/>`;
  /* 網の文様 → Word の網かけ（w:shd）。網点は灰色の塗り（Word の pct は粗く見えるので）、線・格子・点は Word の文様、墨は黒 */
  const GRAY = { text: 'D9D9D9', light: 'F2F2F2', gray: 'D9D9D9', mid: 'BFBFBF', deep: '8C8C8C' };
  const shdXml = shade => { const sh = FZ.SHADE_BY[shade] || FZ.SHADE_BY.gray; if (sh.kind === 'solid') return '<w:shd w:val="clear" w:color="auto" w:fill="000000"/>'; if (sh.kind === 'dot') return `<w:shd w:val="clear" w:color="auto" w:fill="${GRAY[sh.id] || 'D9D9D9'}"/>`; return `<w:shd w:val="${sh.word}" w:color="000000" w:fill="FFFFFF"/>`; };
  FZ.docxShd = shdXml; // 試験用

  FZ.toDocx = function (doc, opts = {}) { const fileName = doc.fileName || ''; doc = FZ.forExport(doc, { flow: true });
    const model = FZ.exportModel(doc), f = model.format, geo = model.lay.geo, cw = geo.cw, ch = geo.ch;
    const sizeHalf = Math.max(8, Math.floor(cw * 2 + 1e-6)); // 字の大きさはマスより大きくしない（大きいと 1 行に入る字数が減り、行と頁がずれる）。足りない分は文字グリッドの字送りで補う
    const [bodyFont, boldFont] = FZ.docFonts(f);
    const fontsXml = font => { const o = FZ.officeFont(font); return `<w:rFonts w:ascii="${esc(o.latin)}" w:hAnsi="${esc(o.latin)}" w:eastAsia="${esc(o.ea)}" w:cs="${esc(o.latin)}"/>`; }; // Office の正式名（BIZ UD明朝 Medium など）
    /* ---- ハイパーリンク（関係 ID を URL ごとに） ---- */
    const linkRels = new Map(); const relFor = url => { if (!linkRels.has(url)) linkRels.set(url, 'rIdL' + (linkRels.size + 1)); return linkRels.get(url); };
    /* ---- run ---- */
    function rPr(marks, o = {}) {
      const p = []; const font = (marks & (M.BOLD | M.CODE)) ? boldFont : (o.font || bodyFont); p.push(fontsXml(font)); // 文中のコードはゴシック（等幅のまま）
      if (marks & M.BOLD) p.push('<w:b/><w:bCs/>'); if (marks & M.STRIKE) p.push('<w:strike/>'); if (marks & M.STRIKE2) p.push('<w:dstrike/>'); if (marks & M.OUTLINE) p.push('<w:outline/>');
      if (marks & M.SHADOW) p.push('<w:shadow/>'); // 影文字（白抜きと組むと影付きの白抜き）
      const cdark = FZ.shadeOfMarks(marks) === 'dark'; if ((o.dark || cdark) && !(marks & M.OUTLINE)) p.push('<w:color w:val="FFFFFF"/>'); else if (o.link) p.push('<w:color w:val="0563C1"/>');
      const sx = FZ.scaleW(marks), sy = FZ.scaleH(marks); // m×n 倍角：字の大きさ×縦、字幅の比率＝横÷縦
      if (sx !== sy) p.push(`<w:w w:val="${Math.round(sx / sy * 100)}"/>`);
      if (sy > 1) p.push(`<w:sz w:val="${sizeHalf * sy}"/><w:szCs w:val="${sizeHalf * sy}"/>`);
      if (marks & M.UNDER2) p.push('<w:u w:val="double"/>'); else if (marks & M.WAVE) p.push('<w:u w:val="wave"/>'); else if (marks & M.UNDER) p.push('<w:u w:val="single"/>'); else if (o.link) p.push('<w:u w:val="single"/>');
      const sh = (marks & M.SHADE) ? FZ.shadeOfMarks(marks) : (marks & M.CODE) ? 'light' : (o.shade && !o.lineFill ? o.shade : null); if (sh) p.push(shdXml(sh));
      if (marks & M.DOT) p.push('<w:em w:val="dot"/>');
      if (o.noBold && !(marks & M.BOLD)) p.push('<w:b w:val="0"/><w:bCs w:val="0"/>'); // 細字の題（見出しスタイルの太字を打ち消す）
      if (o.spc) p.push(`<w:spacing w:val="${o.spc}"/>`);
      return `<w:rPr>${p.join('')}</w:rPr>`;
    }
    /* 字送りの補正：Word の字の大きさは半ポイント刻みでマスより小さいことがあるので、足りない分を字間（w:spacing、1/20pt）で足して 1 字＝1 マス（半角は半マス）にする。
       文字グリッドに頼らない（Word と他の実装で半角の扱いが違うため） */
    const spcFor = (half, marks) => { const fsPt = sizeHalf / 2; const wide = FZ.scaleW(marks); const cell = (half ? cw / 2 : cw) * wide; const nat = (half ? fsPt / 2 : fsPt) * wide; return Math.round((cell - nat) * 20); };
    const splitHalf = t => { const out = []; let cur = '', h = null; for (const ch of t) { const hh = FZ.isHalf(ch.codePointAt(0)); if (h !== null && hh !== h) { out.push([cur, h]); cur = ''; } cur += ch; h = hh; } if (cur) out.push([cur, h]); return out; };
    function runs(seg, shadeMap, o = {}) {
      let off = 0; const parts = [];
      for (const r of FZ.runsOf(seg, shadeMap)) { const dark = o.dark || r.shade === 'dark'; const pr = rPr(r.marks, { ...o, dark, shade: r.shade, link: !!(r.marks & M.LINK) });
        const prOf = half => { const spc = spcFor(half, r.marks); return spc ? rPr(r.marks, { ...o, dark, shade: r.shade, link: !!(r.marks & M.LINK), spc }) : pr; };
        let x = r.text.split('\t').map((t, k) => (k ? '<w:r>' + pr + '<w:tab/></w:r>' : '') + (t ? splitHalf(t).map(([u, half]) => `<w:r>${prOf(half)}<w:t xml:space="preserve">${esc(u)}</w:t></w:r>`).join('') : '')).join('');
        const lk = (r.marks & M.LINK) ? FZ.linkAt(seg, off) : null; if (lk && !lk.image && FZ.safeUrl(lk.url)) x = `<w:hyperlink r:id="${relFor(lk.url)}"${lk.title ? ` w:tooltip="${esc(lk.title)}"` : ''}>${x}</w:hyperlink>`;
        parts.push(x); off += r.text.length; }
      return parts.join('');
    }
    /* ---- 番号づけ（numbering.xml） ---- */
    const scheme = FZ.normalizeScheme(f.scheme), bullets = FZ.normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET); const TL = clamp(f.titleLevels | 0, 0, 8);
    const lvlXml = (idx, tok, headingStyle) => {
      const sp = FZ.levelSpec(tok); let fmt = 'none', text = '', rpr = '';
      if (sp.type === 'num') { const ex = FZ.NUMBER_EXPORT[sp.key]; fmt = ex.word[0]; text = ex.word[1].replace('%n', '%' + (idx + 1)); if (ex.compound) { const anc = []; for (let k = 0; k < idx; k++) if (FZ.levelSpec(scheme[k]).type === 'num') anc.push('%' + (k + 1)); text = [...anc, '%' + (idx + 1)].join('.') + '　'; } }
      else if (sp.type === 'sym' || sp.type === 'wrap') { fmt = 'bullet'; text = sp.type === 'wrap' ? sp.open : sp.s; const sf = FZ.symbolFont(text) || boldFont; rpr = `<w:rPr>${fontsXml(sf)}</w:rPr>`; }
      return `<w:lvl w:ilvl="${idx}"><w:start w:val="1"/><w:numFmt w:val="${fmt}"/>${headingStyle ? `<w:pStyle w:val="${headingStyle}"/>` : ''}<w:suff w:val="nothing"/><w:lvlText w:val="${esc(text)}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${TW(cw * 2 * (headingStyle ? 0 : 1))}" w:hanging="${TW(cw * 2 * (headingStyle ? 0 : 1))}"/></w:pPr>${rpr}</w:lvl>`;
    };
    const bulletAbs = (id, ch) => `<w:abstractNum w:abstractNumId="${id}"><w:multiLevelType w:val="hybridMultilevel"/>${Array.from({ length: 9 }, (_, k) => `<w:lvl w:ilvl="${k}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:suff w:val="nothing"/><w:lvlText w:val="${ch}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${TW(cw * 2)}" w:hanging="${TW(cw * 2)}"/></w:pPr><w:rPr>${fontsXml(FZ.symbolFont(ch) || boldFont)}</w:rPr></w:lvl>`).join('')}</w:abstractNum>`;
    const abs1 = `<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="multilevel"/>${scheme.map((tok, idx) => lvlXml(idx, tok, idx < TL ? 'Heading' + (idx + 1) : null)).join('')}<w:lvl w:ilvl="8"><w:start w:val="1"/><w:numFmt w:val="none"/><w:suff w:val="nothing"/><w:lvlText w:val=""/><w:lvlJc w:val="left"/></w:lvl></w:abstractNum>`;
    /* 箇条書きの体系：レベルごとの記号（なし は番号書式 none） */
    const abs5 = `<w:abstractNum w:abstractNumId="5"><w:multiLevelType w:val="hybridMultilevel"/>${Array.from({ length: 9 }, (_, k) => { const sp = FZ.levelSpec(bullets[Math.min(k, 7)]); const ch = sp.type === 'sym' ? sp.s : sp.type === 'wrap' ? sp.open : ''; return `<w:lvl w:ilvl="${k}"><w:start w:val="1"/><w:numFmt w:val="${ch ? 'bullet' : 'none'}"/><w:suff w:val="nothing"/><w:lvlText w:val="${esc(ch)}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${TW(cw * 2)}" w:hanging="${TW(cw * 2)}"/></w:pPr><w:rPr>${fontsXml(FZ.symbolFont(ch) || boldFont)}</w:rPr></w:lvl>`; }).join('')}</w:abstractNum>`;
    /* 番号付き箇条書きの体系（実体は番号の列ごとに作る：FZ.listNumbering の fresh） */
    const listSch = FZ.normalizeScheme(f.listScheme, FZ.DEFAULT_LIST); const LNUM = FZ.listNumbering(doc);
    const abs6 = `<w:abstractNum w:abstractNumId="6"><w:multiLevelType w:val="multilevel"/>${listSch.map((tok, idx) => { const sp = FZ.levelSpec(tok); let fmt = 'none', text = ''; if (sp.type === 'num') { const ex = FZ.NUMBER_EXPORT[sp.key]; fmt = ex.word[0]; text = ex.compound ? '%' + (idx + 1) + '　' : ex.word[1].replace('%n', '%' + (idx + 1)); } else if (sp.type === 'sym' || sp.type === 'wrap') { fmt = 'bullet'; text = sp.type === 'wrap' ? sp.open : sp.s; }
      return `<w:lvl w:ilvl="${idx}"><w:start w:val="1"/><w:numFmt w:val="${fmt}"/><w:lvlRestart w:val="${idx}"/><w:suff w:val="nothing"/><w:lvlText w:val="${esc(text)}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${TW(cw * 2)}" w:hanging="${TW(cw * 2)}"/></w:pPr></w:lvl>`; }).join('')}<w:lvl w:ilvl="8"><w:start w:val="1"/><w:numFmt w:val="none"/><w:suff w:val="nothing"/><w:lvlText w:val=""/><w:lvlJc w:val="left"/></w:lvl></w:abstractNum>`;
    let curList = null;
    const listNumIdFor = b => { const lv = b.listIdx | 0; if (curList == null || LNUM.fresh[b.i]) { const id = nextNum++; nums.push(`<w:num w:numId="${id}"><w:abstractNumId w:val="6"/>${overrides(lv, Math.max(1, LNUM.ord[b.i]))}</w:num>`); curList = id; } return curList; };
    const nums = [`<w:num w:numId="1"><w:abstractNumId w:val="1"/></w:num>`, `<w:num w:numId="2"><w:abstractNumId w:val="2"/></w:num>`, `<w:num w:numId="3"><w:abstractNumId w:val="3"/></w:num>`, `<w:num w:numId="4"><w:abstractNumId w:val="4"/></w:num>`, `<w:num w:numId="5"><w:abstractNumId w:val="5"/></w:num>`];
    let nextNum = 6, curNum = 1, restartLv = null;
    /* 各リスト実体で既に使った階層。深い階層だけが先に出た後に浅い階層が初めて出るとき（引用中の箇条書きの後に 1. が来る等）は
       新しい実体に切り替える。そうしないと LibreOffice 等が親階層を暗黙に 1 つ数え、最初の 1. が 2. になる。
       見出し番号をスタイルに載せている実体 1 は見出しが親階層を担うので対象外。 */
    /* LibreOffice は同じ abstractNum を共有する実体を一つの連番として扱うので、startOverride を明示して切り離す（Word は実体ごとに独立） */
    const overrides = (fromLv, startAt) => Array.from({ length: 9 - fromLv }, (_, k) => `<w:lvlOverride w:ilvl="${fromLv + k}"><w:startOverride w:val="${k ? 1 : startAt}"/></w:lvlOverride>`).join('');
    const seen = new Map([[1, new Set(Array.from({ length: TL }, (_, k) => k))]]);
    const numIdFor = b => { // 数字見出し（段落レベル）の番号実体
      const lv = b.numLevel | 0;
      if (restartLv != null && lv < restartLv) { curNum = 1; restartLv = null; }
      if (b.attrs.restart) { const id = nextNum++; const startAt = typeof b.attrs.restart === 'number' ? b.attrs.restart : 1; nums.push(`<w:num w:numId="${id}"><w:abstractNumId w:val="1"/>${overrides(lv, startAt)}</w:num>`); curNum = id; restartLv = lv; seen.set(id, new Set([lv])); return id; }
      let s = seen.get(curNum) || (seen.set(curNum, new Set()), seen.get(curNum));
      if (!(TL > 0 && curNum === 1) && s.size && lv < Math.min(...s)) { const id = nextNum++; nums.push(`<w:num w:numId="${id}"><w:abstractNumId w:val="1"/>${overrides(0, 1)}</w:num>`); curNum = id; restartLv = null; s = new Set(); seen.set(id, s); }
      s.add(lv); return curNum;
    };
    /* ---- 段落 ---- */
    const chars = v => Math.round(v * 100);
    /* 字下げ：Word は *Chars（文字数単位）を優先、他の実装は twips を使うので両方書く */
    const ind = (left, hang, first) => `<w:ind w:left="${TW(left * cw)}" w:leftChars="${chars(left)}"${hang > 0 ? ` w:hanging="${TW(hang * cw)}" w:hangingChars="${chars(hang)}"` : ''}${first > 0 ? ` w:firstLine="${TW(first * cw)}" w:firstLineChars="${chars(first)}"` : ''}/>`;
    function indXml(b) {
      const a = b.attrs; const qo = (a.quote | 0) * 2; if (qo) { const r = indXml0(b); return r ? r.replace(/w:left="(\d+)" w:leftChars="(\d+)"/, (m, l, c) => `w:left="${+l + TW(qo * cw)}" w:leftChars="${+c + chars(qo)}"`) : ind(qo, 0, 0); }
      return indXml0(b);
    }
    function indXml0(b) {
      const a = b.attrs; if (a.align === 'center' || a.align === 'right') return a.indent ? ind(a.indent, 0, 0) : '';
      if (b.marker || a.list || b.node === 'num') { const m = b.marker ? b.marker.col : b.firstL; return ind(b.firstL, Math.max(0, b.firstL - m), 0); }
      if (a.style === 'speech') return ind(b.contL, b.contL, 0);
      if (b.firstL === 0 && b.contL === 0) return '';
      if (b.firstL >= b.contL) return ind(b.contL, 0, b.firstL - b.contL);
      return ind(b.contL, b.contL - b.firstL, 0);
    }
    /* ---- 画像（図表）：本文の流れの中の行内の図（中央揃え）。幅は図表の設定（欄いっぱい／75%／50%）、高さは縦横比のまま、版面の高さに収める ---- */
    const IMG_EXT = { 'image/png': 'png', 'image/jpeg': 'jpeg', 'image/gif': 'gif' }; // Word がそのまま開ける形式
    const media = new Map(); const b64u8 = b64 => { if (typeof atob === 'function') { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; } return new Uint8Array(Buffer.from(b64, 'base64')); };
    /* グラフ：編集できるグラフ（word/charts/chartN.xml）＋データの Excel（word/embeddings）。大きさは欄の幅×縦横の比 */
    const charts = [];
    function chartParaXml(lk, b) {
      const c = lk.chart; const n = charts.length + 1; const ofont = FZ.officeFont(boldFont); /* グラフの字はゴシック */
      charts.push({ n, rid: 'rIdC' + n, xml: FZ.chartXml(c, { latin: ofont.latin, ea: ofont.ea, sz: Math.max(700, Math.round(sizeHalf * 50 * 0.85)), ext: 'rId1' }), xlsx: FZ.chartXlsx(c) });
      const avail = f.cols * cw, maxH = f.rows * ch * 0.92; const pc = Math.max(10, Math.min(100, lk.width || 100)); let wPt = avail * pc / 100, hPt = wPt * (c.ratio || 0.6); if (hPt > maxH) { wPt *= maxH / hPt; hPt = maxH; }
      const EMU = v => Math.round(v * 12700); const id = shapeId++;
      return `<w:p><w:pPr><w:keepLines/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${EMU(wPt)}" cy="${EMU(hPt)}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="${id}" name="グラフ ${id}" descr="${esc(b.seg.text)}"/><wp:cNvGraphicFramePr/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rIdC${n}"/></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
    }
    function imageParaXml(lk, b) {
      if (lk.chart && FZ.chartXml) return chartParaXml(lk, b);
      const img = doc.images && doc.images[lk.url]; const ext = img && IMG_EXT[img.mime];
      if (!ext) return `<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r>${rPr(0)}<w:t xml:space="preserve">${esc(`［画像：${lk.url}${img ? '（この形式は Word に書き出せません。PNG・JPEG・GIF にしてください）' : '（画像がありません）'}］`)}</w:t></w:r></w:p>`;
      if (!media.has(lk.url)) { let data; try { data = b64u8(img.data); } catch { data = null; } if (!data) return ''; media.set(lk.url, { rid: 'rIdImg' + (media.size + 1), file: `image${media.size + 1}.${ext}`, ext, data }); }
      const m = media.get(lk.url); const sz = FZ.imageSize(img); const avail = f.cols * cw, maxH = f.rows * ch * 0.92; const pc = Math.max(10, Math.min(100, lk.width || 100));
      let wPt = avail * pc / 100, hPt = wPt * sz.h / Math.max(1, sz.w); if (hPt > maxH) { wPt *= maxH / hPt; hPt = maxH; }
      const EMU = v => Math.round(v * 12700); const id = shapeId++; const name = esc(lk.url);
      return `<w:p><w:pPr><w:keepLines/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${EMU(wPt)}" cy="${EMU(hPt)}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="${id}" name="図 ${id}" descr="${esc(b.seg.text)}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${id}" name="${name}" descr="${esc(b.seg.text)}"/><pic:cNvPicPr><a:picLocks noChangeAspect="1"/></pic:cNvPicPr></pic:nvPicPr><pic:blipFill><a:blip r:embed="${m.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${EMU(wPt)}" cy="${EMU(hPt)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>`;
    }
    function paraXml(b) {
      { const ls = b.seg && b.seg.links; if (ls && ls.length === 1 && ls[0].image && ls[0].start === 0 && ls[0].end >= b.seg.text.length) return imageParaXml(ls[0], b); } // 図表の画像の行
      const a = b.attrs, p = []; const style = a.style === 'title' ? 'Title' : (b.node === 'num' && b.isTitle) ? 'Heading' + Math.min(9, b.numLevel + 1) : b.node === 'sym' ? 'FzSym' + Math.min(8, b.symLevel + 1) : null;
      if (style) p.push(`<w:pStyle w:val="${style}"/>`);
      if (a.keep === 'next' && !style) p.push('<w:keepNext/>'); if (a.keep === 'free' && style) p.push('<w:keepNext w:val="0"/>'); /* 題の「送らない」（K-12） */ if (a.keep === 'line') p.push('<w:keepLines/>'); if (a.breakBefore) p.push('<w:pageBreakBefore/>');
      if (b.node === 'num' && !b.isTitle) p.push(`<w:numPr><w:ilvl w:val="${Math.min(8, b.numLevel)}"/><w:numId w:val="${numIdFor(b)}"/></w:numPr>`); // 段落レベルの数字見出し：Word の自動番号
      if (a.list && b.listKind !== 'cont') p.push(`<w:numPr><w:ilvl w:val="${Math.min(8, b.listIdx)}"/><w:numId w:val="${b.listKind === 'num' ? listNumIdFor(b) : b.listKind === 'arrow' ? 2 : b.listKind === 'todo' ? 3 : b.listKind === 'done' ? 4 : 5}"/></w:numPr>`); // 番号付き箇条書きは Word の自動番号（番号の列ごとの実体）
      const bd = ['top', 'left', 'bottom', 'right'].filter(s => b.rules[s]).map(s => borderXml(s, b.rules[s])); if (b.gap === 'rule' && !b.rules.top) bd.unshift(`<w:top w:val="single" w:sz="4" w:space="${Math.min(31, Math.round(ch / 2))}" w:color="000000"/>`); /* 節の区切り線：空き 1 行の真ん中（段落前の間隔 半行＋罫の間隔 半行） */ if (a.quote && !b.rules.left) bd.push(`<w:left w:val="single" w:sz="18" w:space="${Math.round(cw * 0.8)}" w:color="000000"/>`); if (bd.length) p.push(`<w:pBdr>${bd.join('')}</w:pBdr>`);
      if (b.lineFill) p.push(shdXml(b.lineFill)); else if (a.code) p.push(shdXml('light'));
      { const sp = []; if (b.gap) sp.push(`w:before="${TW(b.gap === 'rule' && !b.rules.top ? ch / 2 : ch)}"`); if (b.tall) sp.push(`w:line="${TW(ch * 2)}" w:lineRule="exact"`); if (sp.length) p.push(`<w:spacing ${sp.join(' ')}/>`); } // 見出しの前の空き：段落前の間隔 1 行分
      const ind = indXml(b); if (ind) p.push(ind);
      const jc = { center: 'center', right: 'right', justify: 'distribute' }[a.align]; if (jc) p.push(`<w:jc w:val="${jc}"/>`);
      let body = '';
      if (a.style === 'speech') { const k = FZ.speechSplit(b.seg.text); if (k > 0) { const s1 = { text: b.seg.text.slice(0, k), marks: b.seg.marks.slice(0, k) }, s2 = { text: b.seg.text.slice(k), marks: b.seg.marks.slice(k) }; body = runs(s1, null, { dark: b.dark && b.lineFill === 'dark' }) + `<w:r>${rPr(0)}<w:tab/></w:r>` + runs(s2, null, { dark: b.dark && b.lineFill === 'dark' }); } }
      if (!body) body = runs(b.seg, b.shade, { dark: b.lineFill === 'dark', lineFill: b.lineFill, noBold: !!(style && a.thin) });
      if (b.node === 'sym' && b.marker && b.marker.text) body = `<w:r>${rPr(M.BOLD | (b.marker.marks | 0), { dark: b.lineFill === 'dark' })}<w:t xml:space="preserve">${esc(b.marker.text)}</w:t></w:r>` + body; // 記号見出し：記号を本文に焼く
      if (b.node === 'sym' && b.symClose) body += `<w:r>${rPr(M.BOLD | (b.marker ? b.marker.marks | 0 : 0), { dark: b.lineFill === 'dark' })}<w:t xml:space="preserve">${esc(b.symClose)}</w:t></w:r>`; // 囲み見出しの閉じ
      return `<w:p><w:pPr>${p.join('')}</w:pPr>${body}</w:p>`;
    }
    /* ---- 書き出し専用の図形（D = { w, h（pt）, rects: [{ x, y, w, h, lines, bold, fill, stroke, sw, dash, round, fs }], lines: [{ x1, y1, x2, y2, stroke, sw }] }）：Word で動かせる・直せる箱と線のまとまり ---- */
    function imageRid(key) { const img = doc.images && doc.images[key]; const ext = img && IMG_EXT[img.mime]; if (!ext) return null; if (!media.has(key)) { let data; try { data = b64u8(img.data); } catch { data = null; } if (!data) return null; media.set(key, { rid: 'rIdImg' + (media.size + 1), file: `image${media.size + 1}.${ext}`, ext, data }); } return media.get(key).rid; }
    function drawingXml(b) { const D = b.D, P = v => Math.round(v * 12700); const sp = []; const fx = fontsXml(boldFont); /* ツリーはゴシック */
      for (const l of D.lines || []) { const id = shapeId++; const fh = l.x2 < l.x1, fv = l.y2 < l.y1; sp.push(`<wps:wsp><wps:cNvPr id="${id}" name="線${id}"/><wps:cNvSpPr/><wps:spPr><a:xfrm${fh ? ' flipH="1"' : ''}${fv ? ' flipV="1"' : ''}><a:off x="${P(Math.min(l.x1, l.x2))}" y="${P(Math.min(l.y1, l.y2))}"/><a:ext cx="${P(Math.abs(l.x2 - l.x1))}" cy="${P(Math.abs(l.y2 - l.y1))}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/><a:ln w="${P(l.sw || 0.5)}"><a:solidFill><a:srgbClr val="${l.stroke || '7F7F7F'}"/></a:solidFill></a:ln></wps:spPr><wps:bodyPr/></wps:wsp>`); }
      for (const r of D.rects || []) { const id = shapeId++; const sz = Math.max(10, Math.round((r.fs || 10.5) * 2)); const rp = `<w:rPr>${fx}${r.bold ? '<w:b/><w:bCs/>' : ''}<w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/></w:rPr>`;
        const paras = (r.lines && r.lines.length ? r.lines : ['']).map(t => `<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="${Math.round((r.lh || r.fs * 1.4 || 14) * 20)}" w:lineRule="exact"/></w:pPr>${t ? `<w:r>${rp}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>` : ''}</w:p>`).join('');
        const blip = r.image ? imageRid(r.image) : null; /* 絵の箱（ツリーの図表の中身）：画像で塗る */
        sp.push(`<wps:wsp><wps:cNvPr id="${id}" name="${esc(String(r.name || (r.lines && r.lines[0]) || '箱').slice(0, 30))}"/><wps:cNvSpPr/><wps:spPr><a:xfrm><a:off x="${P(r.x)}" y="${P(r.y)}"/><a:ext cx="${P(r.w)}" cy="${P(r.h)}"/></a:xfrm><a:prstGeom prst="${r.round ? 'roundRect' : 'rect'}"><a:avLst>${r.round ? '<a:gd name="adj" fmla="val 8000"/>' : ''}</a:avLst></a:prstGeom>${blip ? `<a:blipFill><a:blip r:embed="${blip}"/><a:stretch><a:fillRect/></a:stretch></a:blipFill>` : r.fill ? `<a:solidFill><a:srgbClr val="${r.fill}"/></a:solidFill>` : '<a:noFill/>'}<a:ln w="${P(r.sw || 0.6)}"><a:solidFill><a:srgbClr val="${r.stroke || '000000'}"/></a:solidFill>${r.dash ? '<a:prstDash val="sysDash"/>' : ''}</a:ln></wps:spPr><wps:txbx><w:txbxContent>${paras}</w:txbxContent></wps:txbx><wps:bodyPr wrap="square" lIns="${P(r.pl || 4)}" tIns="${P(r.pt || 2)}" rIns="${P(2)}" bIns="0" anchor="t"><a:noAutofit/></wps:bodyPr></wps:wsp>`); }
      const CX = P(D.w), CY = P(D.h), docPrId = shapeId++;
      return `<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>${D.breakBefore ? '<w:pageBreakBefore/>' : ''}</w:pPr><w:r><mc:AlternateContent><mc:Choice Requires="wpg"><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${CX}" cy="${CY}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="${docPrId}" name="${esc(D.name || '図' + docPrId)}"/><wp:cNvGraphicFramePr/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"><wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${CX}" cy="${CY}"/><a:chOff x="0" y="0"/><a:chExt cx="${CX}" cy="${CY}"/></a:xfrm></wpg:grpSpPr>${sp.join('')}</wpg:wgp></a:graphicData></a:graphic></wp:inline></w:drawing></mc:Choice><mc:Fallback><w:t>［図］</w:t></mc:Fallback></mc:AlternateContent></w:r></w:p>`; }
    /* ---- 表 ---- */
    function tableXml(b) {
      const widths = b.grid.slice(1).map((c, k) => TW((c - b.grid[k]) * cw));
      const rows = b.rows.map((r, ri) => {
        const tcs = r.cells.map(c => {
          const w = TW((c.right - c.left) * cw); const tcPr = [`<w:tcW w:w="${w}" w:type="dxa"/>`]; if (c.span > 1) tcPr.push(`<w:gridSpan w:val="${c.span}"/>`);
          tcPr.push(`<w:tcBorders>${borderXml('top', c.borders.t)}${borderXml('left', c.borders.l)}${borderXml('bottom', c.borders.b)}${borderXml('right', c.borders.r)}</w:tcBorders>`);
          if (c.shade) tcPr.push(shdXml(c.shade)); tcPr.push('<w:vAlign w:val="top"/>');
          const jc = { center: 'center', right: 'right', justify: 'distribute' }[c.align]; const pPr = (r.tall ? `<w:spacing w:line="${TW(ch * 2)}" w:lineRule="exact"/>` : '') + (jc ? `<w:jc w:val="${jc}"/>` : '');
          const body = c.segs.map(s => runs(s, null, { dark: c.shade === 'dark' })).join('') || '';
          return `<w:tc><w:tcPr>${tcPr.join('')}</w:tcPr><w:p>${pPr ? `<w:pPr>${pPr}</w:pPr>` : ''}${body}</w:p></w:tc>`;
        }).join('');
        return `<w:tr><w:trPr><w:cantSplit/>${ri === 0 && b.repeatHead ? '<w:tblHeader/>' : ''}</w:trPr>${tcs}</w:tr>`;
      }).join('');
      return `<w:tbl><w:tblPr><w:tblW w:w="${TW((b.right - b.left) * cw)}" w:type="dxa"/><w:tblInd w:w="${TW(b.left * cw)}" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="0000" w:firstRow="0" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="0"/></w:tblPr><w:tblGrid>${widths.map(w => `<w:gridCol w:w="${w}"/>`).join('')}</w:tblGrid>${rows}</w:tbl>`;
    }
    /* ---- 目次：TOC フィールド（文机の組版結果を結果として焼く。Word で F9 を押すと Word の見出しで引き直す） ---- */
    function tocXml(b) {
      const T = b.toc; const lo = Math.min(T.num ? T.num[0] + 1 : 99, T.sym ? TL + T.sym[0] + 1 : 99), hi = Math.max(T.num ? T.num[1] + 1 : 0, T.sym ? TL + T.sym[1] + 1 : 0); const range = `${clamp(lo, 1, 9)}-${clamp(Math.max(lo, hi), 1, 9)}`;
      const begin = `<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \\o "${range}" \\h \\z \\u </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r>`, end = '<w:r><w:fldChar w:fldCharType="end"/></w:r>';
      const es = b.entries.length ? b.entries : [{ indent: 0, marker: '', text: '（目次：載せる見出しがありません）', page: '' }];
      return es.map((e, k) => `<w:p><w:pPr><w:pStyle w:val="TOC${Math.min(9, (e.indent | 0) + 1)}"/></w:pPr>${k === 0 ? begin : ''}<w:r>${rPr(0)}<w:t xml:space="preserve">${esc(e.close ? e.marker + e.text + e.close : (e.marker ? e.marker + ' ' : '') + e.text)}</w:t></w:r><w:r>${rPr(0)}<w:tab/></w:r><w:r>${rPr(0)}<w:t>${esc(String(e.page || ''))}</w:t></w:r>${k === es.length - 1 ? end : ''}</w:p>`).join('');
    }
    /* ---- 図（DrawingML グループ） ---- */
    let shapeId = 100;
    function figureXml(b) {
      const F = b.F, W = b.right - b.left, H = F.h; const CX = EMU(W * cw), CY = EMU(H * ch); const X = x => EMU(x * cw), Y = y => EMU(y * ch);
      const sp = [];
      const txt = (text, marks, dark, align = 'ctr') => { const lines = String(text).split('\n'); return `<wps:txbx><w:txbxContent>${lines.map(t => `<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="${TW(ch)}" w:lineRule="exact"/><w:jc w:val="${align === 'l' ? 'left' : 'center'}"/></w:pPr>${t ? `<w:r>${rPr(marks, { dark })}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>` : ''}</w:p>`).join('')}</w:txbxContent></wps:txbx>`; };
      const lnXml = (kind, arrow) => { const w = kind === 'thick' ? 19050 : kind === 'arrow' ? 9525 : 6350; return `<a:ln w="${w}"${kind === 'double' ? ' cmpd="dbl"' : ''}><a:solidFill><a:srgbClr val="000000"/></a:solidFill>${kind === 'dotted' ? '<a:prstDash val="sysDash"/>' : ''}${arrow ? '<a:tailEnd type="triangle" w="med" len="med"/>' : ''}</a:ln>`; };
      const fillXml = shade => !shade ? '<a:noFill/>' : shade === 'dark' ? '<a:solidFill><a:srgbClr val="000000"/></a:solidFill>' : shade === 'gray' ? '<a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill>' : shade === 'hatch' ? '<a:pattFill prst="wdUpDiag"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>' : '<a:pattFill prst="pct20"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>';
      const rect = (x, y, w, h, kind, shade, text, marks, align) => { const id = shapeId++; sp.push(`<wps:wsp><wps:cNvPr id="${id}" name="箱${id}"/><wps:cNvSpPr/><wps:spPr><a:xfrm><a:off x="${X(x)}" y="${Y(y)}"/><a:ext cx="${X(w)}" cy="${Y(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fillXml(shade)}${kind ? lnXml(kind) : '<a:ln><a:noFill/></a:ln>'}</wps:spPr>${text != null ? txt(text, marks, shade === 'dark', align) : ''}<wps:bodyPr wrap="square" lIns="${EMU(cw * 0.25)}" tIns="0" rIns="${EMU(cw * 0.25)}" bIns="0" anchor="ctr"><a:noAutofit/></wps:bodyPr></wps:wsp>`); };
      const line = (x1, y1, x2, y2, kind, arrow) => { const id = shapeId++; const fh = x2 < x1, fv = y2 < y1; sp.push(`<wps:wsp><wps:cNvPr id="${id}" name="線${id}"/><wps:cNvSpPr/><wps:spPr><a:xfrm${fh ? ' flipH="1"' : ''}${fv ? ' flipV="1"' : ''}><a:off x="${X(Math.min(x1, x2))}" y="${Y(Math.min(y1, y2))}"/><a:ext cx="${X(Math.abs(x2 - x1))}" cy="${Y(Math.abs(y2 - y1))}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/>${lnXml(kind, arrow)}</wps:spPr><wps:bodyPr/></wps:wsp>`); };
      const lanes = FZ.laneGeom(F, W, H);
      if (lanes) {
        rect(0, 0, W, H, 'thin', null, null);
        if (lanes.dir === 'v') { rect(0, 0, W, 1, null, 'gray', null); line(0, 1, W, 1, 'thin'); lanes.bands.forEach((bd, k) => { if (k > 0) line(bd.from, 0, bd.from, H, 'thin'); rect(bd.from, 0, bd.to - bd.from, 1, null, null, bd.title, M.BOLD); }); }
        else { rect(0, 0, 2, H, null, 'gray', null); line(2, 0, 2, H, 'thin'); lanes.bands.forEach((bd, k) => { if (k > 0) line(0, bd.from, W, bd.from, 'thin'); rect(0, bd.from, 2, bd.to - bd.from, null, null, [...bd.title].join('\n'), M.BOLD); }); }
      }
      for (const bx of F.boxes) rect(bx.x, bx.y, bx.w, bx.h, bx.kind, bx.shade, bx.text, bx.bold ? M.BOLD : 0);
      for (const a of F.arrows) { const A = FZ.figureBox(F, a.from), B = FZ.figureBox(F, a.to); if (!A || !B) continue; const segs = FZ.figureRoute(A, B);
        segs.forEach((s, k) => { const last = k === segs.length - 1; if (s.k === 'h') line(s.dir === 'l' ? s.to : s.from, s.y, s.dir === 'l' ? s.from : s.to, s.y, last ? 'arrow' : a.kind, last); else line(s.col, s.dir === 'u' ? s.y2 : s.y1, s.col, s.dir === 'u' ? s.y1 : s.y2, last ? 'arrow' : a.kind, last); });
        if (a.label) { let best = segs[0], len = -1; for (const s of segs) { const l = s.k === 'h' ? s.to - s.from : s.y2 - s.y1; if (l > len) { len = l; best = s; } } const tw = FZ.textWidth(a.label) + 1;
          if (best.k === 'h') { const row = Math.floor(best.y) - 1 >= 0 ? Math.floor(best.y) - 1 : Math.floor(best.y) + 1; rect((best.from + best.to) / 2 - tw / 2, row, tw, 1, null, null, a.label, 0); } else rect(best.col + 0.5, Math.floor((best.y1 + best.y2) / 2), tw, 1, null, null, a.label, 0, 'l'); }
      }
      const docPrId = shapeId++;
      return `<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><mc:AlternateContent><mc:Choice Requires="wpg"><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${CX}" cy="${CY}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="${docPrId}" name="図${docPrId}"/><wp:cNvGraphicFramePr/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"><wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${CX}" cy="${CY}"/><a:chOff x="0" y="0"/><a:chExt cx="${CX}" cy="${CY}"/></a:xfrm></wpg:grpSpPr>${sp.join('')}</wpg:wgp></a:graphicData></a:graphic></wp:inline></w:drawing></mc:Choice><mc:Fallback><w:t>［図］</w:t></mc:Fallback></mc:AlternateContent></w:r></w:p>`;
    }
    /* ---- 本文 ---- */
    const body = []; let curCols = 1;
    /* 版面を Word に正確に渡す：本文の高さ＝行数×行送り＋半行（行数ちょうどが入り、1 行多くは入らない）、幅＝字数×字送り＋半字。
       柱と本文の間の空き（柱空き）も余白に含める（含めないと 1 頁の行数が 2 行増えて頁がずれる）。字送りは字間の補正（spcFor）で 1 マスに合わせる */
    const PG = (() => { const line = TW(ch), pgW = TW(geo.W), pgH = TW(geo.H); const top = Math.floor(TW(f.margins.top * FZ.PT + (geo.headerRows + geo.hGap) * ch)); const left = Math.floor(TW(f.margins.left * FZ.PT));
      const bodyH = line * f.rows + Math.floor(line / 2), bodyW = Math.round(cw * 20 * f.cols) + Math.floor(cw * 10);
      return { line, top, left, bottom: Math.max(0, pgH - top - bodyH), right: Math.max(0, pgW - left - bodyW) }; })();
    const sectXml = (colsN, cont) => `<w:sectPr>${f.headerRows > 0 && f.header ? '<w:headerReference w:type="default" r:id="rIdH"/>' : ''}${f.footerRows > 0 && f.footer ? '<w:footerReference w:type="default" r:id="rIdF"/>' : ''}${cont ? '<w:type w:val="continuous"/>' : ''}<w:pgSz w:w="${TW(geo.W)}" w:h="${TW(geo.H)}"${geo.W > geo.H ? ' w:orient="landscape"' : ''}/><w:pgMar w:top="${PG.top}" w:right="${PG.right}" w:bottom="${PG.bottom}" w:left="${PG.left}" w:header="${TW(f.margins.top * FZ.PT)}" w:footer="${TW(f.margins.bottom * FZ.PT)}" w:gutter="0"/>${(f.pageStart == null ? 1 : f.pageStart) !== 1 ? `<w:pgNumType w:start="${f.pageStart}"/>` : ''}${colsN > 1 ? `<w:cols w:num="${colsN}" w:space="${TW(cw * 2)}"/>` : ''}<w:docGrid w:type="lines" w:linePitch="${PG.line}"/></w:sectPr>`;
    let lastPara = false; /* 段落の中の改行（attrs.join）：前の段落に <w:br/> でつなぐ */
    for (const b of model.blocks) {
      const c = Math.max(1, b.columns | 0); if (c !== curCols) { body.push(`<w:p><w:pPr>${sectXml(curCols, true)}</w:pPr></w:p>`); curCols = c; lastPara = false; }
      if (b.type === 'para') { const x = paraXml(b); const k = x.indexOf('</w:pPr>'); if (b.attrs && b.attrs.join && lastPara && k > 0 && !x.includes('<w:drawing>') && body[body.length - 1].endsWith('</w:p>') && !body[body.length - 1].includes('<w:drawing>')) body[body.length - 1] = body[body.length - 1].slice(0, -6) + '<w:r><w:br/></w:r>' + x.slice(k + 8, -6) + '</w:p>'; else body.push(x); lastPara = true; continue; }
      lastPara = false;
      if (b.type === 'drawing') { body.push(drawingXml(b)); continue; }
      if (false) {} else if (b.type === 'table') { if (b.gap) body.push(`<w:p><w:pPr><w:spacing w:after="0" w:line="${TW(ch)}" w:lineRule="exact"/></w:pPr></w:p>`); body.push(tableXml(b)); } /* 表の前空き：Word の表は段落前の間隔を持てないので 1 行分の空の段落 */ else if (b.type === 'figure') body.push(figureXml(b)); else if (b.type === 'toc') body.push(tocXml(b));
    }
    const NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" mc:Ignorable="w14"';
    const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${NS}><w:body>${body.join('')}${sectXml(curCols, curCols !== 1 || body.some(x => x.includes('<w:sectPr>')))}</w:body></w:document>`;
    /* ---- スタイル ---- */
    const headingStyle = (id, name, lvl) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/>${lvl >= 0 && lvl < TL ? `<w:numPr><w:ilvl w:val="${lvl}"/><w:numId w:val="1"/></w:numPr>` : ''}${lvl >= 0 ? `<w:outlineLvl w:val="${Math.min(8, lvl)}"/>` : ''}</w:pPr><w:rPr>${fontsXml(boldFont)}<w:b/><w:bCs/></w:rPr></w:style>`;
    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr>${fontsXml(bodyFont)}<w:kern w:val="0"/><w:sz w:val="${sizeHalf}"/><w:szCs w:val="${sizeHalf}"/><w:lang w:val="en-US" w:eastAsia="ja-JP" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:wordWrap w:val="0"/><w:overflowPunct w:val="${f.hang ? 1 : 0}"/><w:autoSpaceDE w:val="0"/><w:autoSpaceDN w:val="0"/><w:adjustRightInd w:val="0"/><w:spacing w:after="0" w:line="${TW(ch)}" w:lineRule="exact"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/><w:pPr><w:widowControl w:val="0"/></w:pPr></w:style>${headingStyle('Title', 'Title', -1) + Array.from({ length: 8 }, (_, k) => `<w:style w:type="paragraph" w:styleId="FzSym${k + 1}"><w:name w:val="記号見出し ${k + 1}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:outlineLvl w:val="${Math.min(8, TL + k)}"/></w:pPr><w:rPr>${fontsXml(boldFont)}<w:b/><w:bCs/></w:rPr></w:style>`).join('')}${Array.from({ length: Math.max(3, TL) }, (_, k) => headingStyle('Heading' + (k + 1), 'heading ' + (k + 1), k)).join('')}${Array.from({ length: 9 }, (_, k) => `<w:style w:type="paragraph" w:styleId="TOC${k + 1}"><w:name w:val="toc ${k + 1}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="39"/><w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="${TW(f.cols * cw)}"/></w:tabs>${k ? ind(k, 0, 0) : ''}</w:pPr></w:style>`).join('')}<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style><w:style w:type="paragraph" w:styleId="Header"><w:name w:val="header"/><w:basedOn w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Footer"><w:name w:val="footer"/><w:basedOn w:val="Normal"/></w:style></w:styles>`;
    const numberingXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">${abs1}${bulletAbs(2, '→')}${bulletAbs(3, '❏')}${bulletAbs(4, '☑')}${abs5}${abs6}${nums.join('')}</w:numbering>`;
    const settingsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:defaultTabStop w:val="${TW(cw * 4)}"/><w:characterSpacingControl w:val="doNotCompress"/><w:compat><w:balanceSingleByteDoubleByteWidth/><w:doNotExpandShiftReturn/><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>`;
    /* ---- 柱 ---- */
    const hfXml = (tag, text, jc, styleId) => { const parts = String(text).replace(/\{file\}/g, fileName).split(/(\{page\}|\{pages\})/); const rs = parts.map(t => t === '{page}' ? `<w:fldSimple w:instr=" PAGE "><w:r>${rPr(0)}<w:t>1</w:t></w:r></w:fldSimple>` : t === '{pages}' ? `<w:fldSimple w:instr=" NUMPAGES "><w:r>${rPr(0)}<w:t>1</w:t></w:r></w:fldSimple>` : t ? `<w:r>${rPr(0)}<w:t xml:space="preserve">${esc(t)}</w:t></w:r>` : '').join(''); return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:${tag} xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:p><w:pPr><w:pStyle w:val="${styleId}"/><w:jc w:val="${jc}"/></w:pPr>${rs}</w:p></w:${tag}>`; };
    const hasH = f.headerRows > 0 && !!f.header, hasF = f.footerRows > 0 && !!f.footer;
    /* ---- パッケージ ---- */
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;
    const docRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rIdN" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/><Relationship Id="rIdT" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>${hasH ? '<Relationship Id="rIdH" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>' : ''}${hasF ? '<Relationship Id="rIdF" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>' : ''}${[...linkRels.entries()].map(([url, id]) => `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${esc(FZ.uriForOffice(url))}" TargetMode="External"/>`).join('')}${[...media.values()].map(m => `<Relationship Id="${m.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${m.file}"/>`).join('')}${charts.map(x => `<Relationship Id="${x.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="charts/chart${x.n}.xml"/>`).join('')}</Relationships>`;
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${[...new Set([...media.values()].map(m => m.ext))].map(e => `<Default Extension="${e}" ContentType="image/${e}"/>`).join('')}<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>${hasH ? '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' : ''}${hasF ? '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' : ''}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>${charts.length ? '<Default Extension="xlsx" ContentType="' + FZ.XLSX_CT + '"/>' : ''}${charts.map(x => `<Override PartName="/word/charts/chart${x.n}.xml" ContentType="${FZ.CHART_CT}"/>`).join('')}</Types>`;
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${esc(doc.title || '')}</dc:title><dc:creator>文机</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</dcterms:created></cp:coreProperties>`;
    const files = [{ name: '[Content_Types].xml', data: ct }, { name: '_rels/.rels', data: rels }, { name: 'word/document.xml', data: documentXml }, { name: 'word/styles.xml', data: stylesXml }, { name: 'word/numbering.xml', data: numberingXml }, { name: 'word/settings.xml', data: settingsXml }, { name: 'word/_rels/document.xml.rels', data: docRels }, { name: 'docProps/core.xml', data: core }];
    for (const m of media.values()) files.push({ name: 'word/media/' + m.file, data: m.data });
    for (const x of charts) files.push({ name: `word/charts/chart${x.n}.xml`, data: x.xml }, { name: `word/charts/_rels/chart${x.n}.xml.rels`, data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/package" Target="../embeddings/Microsoft_Excel_Worksheet${x.n}.xlsx"/></Relationships>` }, { name: `word/embeddings/Microsoft_Excel_Worksheet${x.n}.xlsx`, data: x.xlsx });
    if (hasH) files.push({ name: 'word/header1.xml', data: hfXml('hdr', f.header, 'left', 'Header') }); if (hasF) files.push({ name: 'word/footer1.xml', data: hfXml('ftr', f.footer, 'center', 'Footer') });
    return opts.files ? files : FZ.zip(files); // opts.files：中身の一覧を返す（画面は圧縮つきの FZ.zipAsync で包む）
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
