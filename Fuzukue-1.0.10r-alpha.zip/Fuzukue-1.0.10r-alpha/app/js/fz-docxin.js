/* 文机 — Word（.docx）の取り込み（X5：取り込みで構造を起こす）
 * 見出しスタイル（見出し 1〜9・Heading・アウトライン レベル）→ 数字見出しの段、表題スタイル → 表題、Word の箇条書き・段落番号 → 箇条書き・番号付き箇条書き、
 * 表 → 表、太字 → 太字、ハイパーリンク → リンク、画像 → 図版。いったん文机 Markdown にして FZ.fromGfm で組む（見出しの手書きの番号はそこで外れる）。
 * 見出しスタイルが無い文書は、平文の番号（1. （1） ① ア 第1 など）から節を起こす（FZ.liftJaMarkers）。
 * zip は中央ディレクトリを読み、deflate は DecompressionStream（ブラウザ・Node 18+）で開く */
(function (FZ) {
  'use strict';
  const u16 = (b, o) => b[o] | (b[o + 1] << 8), u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
  async function inflateRaw(data) { const ds = new DecompressionStream('deflate-raw'); const w = ds.writable.getWriter(); w.write(data); w.close(); const out = []; const r = ds.readable.getReader(); let n = 0; for (;;) { const { value, done } = await r.read(); if (done) break; out.push(value); n += value.length; } const u = new Uint8Array(n); let o = 0; for (const c of out) { u.set(c, o); o += c.length; } return u; }
  /* zip の中身：名前 → () => Promise<Uint8Array> */
  FZ.unzip = function (buf) { const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf); let e = -1; for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) if (u32(b, i) === 0x06054b50) { e = i; break; } if (e < 0) throw new Error('zip ではありません');
    const n = u16(b, e + 10), cd = u32(b, e + 16); const out = new Map(); let p = cd; const dec = new TextDecoder();
    for (let k = 0; k < n && u32(b, p) === 0x02014b50; k++) { const method = u16(b, p + 10), csize = u32(b, p + 20), nl = u16(b, p + 28), xl = u16(b, p + 30), cl = u16(b, p + 32), lho = u32(b, p + 42); const name = dec.decode(b.subarray(p + 46, p + 46 + nl)); p += 46 + nl + xl + cl;
      out.set(name, async () => { const ds = lho + 30 + u16(b, lho + 26) + u16(b, lho + 28); const raw = b.subarray(ds, ds + csize); if (method === 0) return raw.slice(); if (method === 8) return inflateRaw(raw); throw new Error('この圧縮は読めません'); }); }
    return out; };
  /* 小さな XML の木（docx の部品だけ読めればよい） */
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }; const unent = s => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] ?? m));
  function xml(text) { const root = { name: '#root', attrs: {}, kids: [] }; const st = [root]; const re = /<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|<\?[\s\S]*?\?>|<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|([^<]+)/g; let m;
    while ((m = re.exec(text))) { if (m[6] != null) { if (st.length > 1) st[st.length - 1].kids.push({ text: unent(m[6]) }); continue; } if (m[5] != null) { st[st.length - 1].kids.push({ text: m[5] }); continue; } if (!m[2]) continue;
      if (m[1]) { while (st.length > 1 && st.pop().name !== m[2]); continue; } const attrs = {}; m[3].replace(/([\w:.-]+)\s*=\s*("([^"]*)"|'([^']*)')/g, (_, k, __, a, b2) => { attrs[k] = unent(a ?? b2); }); const el = { name: m[2], attrs, kids: [] }; st[st.length - 1].kids.push(el); if (!m[4]) st.push(el); }
    return root; }
  const kids = (el, name) => (el && el.kids || []).filter(k => k.name === name), kid = (el, name) => (el && el.kids || []).find(k => k.name === name);
  const all = (el, name, out = []) => { for (const k of el.kids || []) { if (k.name === name) out.push(k); if (k.kids) all(k, name, out); } return out; };
  const on = el => !!el && !['0', 'false', 'off'].includes(String(el.attrs['w:val'] ?? '1'));
  const toB64 = u => { if (typeof btoa === 'function') { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); } return Buffer.from(u).toString('base64'); };
  const HEADNUM = /^\s*(?:第[0-9０-９一二三四五六七八九十百]+[章節条項部編款]?|[0-9０-９]+(?:[.．][0-9０-９]+)*[.．)）]?|[（(][0-9０-９]+[）)]|[①-⑳]|[ア-ン][.．)）])[\s　]*/;
  const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp' };

  FZ.fromDocx = async function (buf, base) {
    const z = FZ.unzip(buf); const txt = async n => z.has(n) ? new TextDecoder().decode(await z.get(n)()) : '';
    const docX = xml(await txt('word/document.xml')); const body = all(docX, 'w:body')[0]; if (!body) throw new Error('Word の本文が見つかりません');
    /* スタイル：id → { name, outline, base, list }。見出しは名前（heading n／見出し n）かアウトライン レベル */
    const styles = new Map(); { const sx = xml(await txt('word/styles.xml')); for (const s of all(sx, 'w:style')) { const id = s.attrs['w:styleId']; const nm = (kid(s, 'w:name') || { attrs: {} }).attrs['w:val'] || ''; const pp = kid(s, 'w:pPr'); const ol = pp && kid(pp, 'w:outlineLvl'); const np = pp && kid(pp, 'w:numPr'); styles.set(id, { name: nm, outline: ol ? +ol.attrs['w:val'] : null, base: (kid(s, 'w:basedOn') || { attrs: {} }).attrs['w:val'], numId: np && kid(np, 'w:numId') ? kid(np, 'w:numId').attrs['w:val'] : null, ilvl: np && kid(np, 'w:ilvl') ? +kid(np, 'w:ilvl').attrs['w:val'] : null }); } }
    const styleOf = id => { let s = styles.get(id), g = 0; const r = { name: s ? s.name : '', outline: null, numId: null, ilvl: null }; while (s && g++ < 10) { if (r.outline == null && s.outline != null) r.outline = s.outline; if (r.numId == null && s.numId) { r.numId = s.numId; r.ilvl = s.ilvl; } s = s.base ? styles.get(s.base) : null; } return r; };
    /* 番号：numId → 段ごとの書式（bullet か数字か） */
    const numFmt = new Map(); { const nx = xml(await txt('word/numbering.xml')); const abs = new Map(); for (const a of all(nx, 'w:abstractNum')) { const lv = new Map(); for (const l of kids(a, 'w:lvl')) lv.set(+l.attrs['w:ilvl'], (kid(l, 'w:numFmt') || { attrs: {} }).attrs['w:val'] || 'bullet'); abs.set(a.attrs['w:abstractNumId'], lv); } for (const n of all(nx, 'w:num')) { const ai = kid(n, 'w:abstractNumId'); if (ai) numFmt.set(n.attrs['w:numId'], abs.get(ai.attrs['w:val']) || new Map()); } }
    const rels = new Map(); { const rx = xml(await txt('word/_rels/document.xml.rels')); for (const r of all(rx, 'Relationship')) rels.set(r.attrs.Id, { target: r.attrs.Target, ext: r.attrs.TargetMode === 'External' }); }
    const images = {}; let imgN = 0; const imgName = async rid => { const r = rels.get(rid); if (!r || r.ext) return null; const path = 'word/' + r.target.replace(/^\.?\//, '').replace(/^\.\.\//, ''); const ext = (path.split('.').pop() || '').toLowerCase(); if (!MIME[ext] || !z.has(path)) return null; const name = 'word' + (++imgN) + '.' + ext; images[name] = { mime: MIME[ext], data: toB64(await z.get(path)()) }; return name; };
    const esc = t => t.replace(/([\\`*_[\]<>|])/g, '\\$1');
    const lines = []; let anyHead = false, title = null;
    async function runsText(p) { let s = ''; const walk = async (el, bold, link) => { for (const k of el.kids || []) { if (k.text != null) continue;
        if (k.name === 'w:r') { const rp = kid(k, 'w:rPr'); const b = bold || on(rp && kid(rp, 'w:b')); for (const c of k.kids || []) { if (c.name === 'w:t') { const t = c.kids.map(x => x.text || '').join(''); s += b && t.trim() ? '**' + esc(t) + '**' : esc(t); } else if (c.name === 'w:tab') s += '　'; else if (c.name === 'w:br') s += ' '; else if (c.name === 'w:drawing' || c.name === 'w:pict') { const bl = all(c, 'a:blip')[0] || all(c, 'v:imagedata')[0]; const rid = bl && (bl.attrs['r:embed'] || bl.attrs['r:id']); const nm = rid ? await imgName(rid) : null; if (nm) s += '\n\n![図](' + nm + ')\n\n'; } } }
        else if (k.name === 'w:hyperlink') { const r = rels.get(k.attrs['r:id']); const save = s; s = ''; await walk(k, bold, true); const inner = s; s = save + (r && r.ext ? '[' + inner + '](' + r.target + ')' : inner); }
        else if (k.name === 'w:del' || k.name === 'w:pPr' || k.name === 'w:rPr') continue; else if (k.kids) await walk(k, bold, link); } }; await walk(p, false, false); return s.replace(/\*\*\*\*/g, '').trim(); }
    async function para(p) { const pp = kid(p, 'w:pPr'); const sid = pp && kid(pp, 'w:pStyle') ? kid(pp, 'w:pStyle').attrs['w:val'] : 'Normal'; const S = styleOf(sid); const nm = S.name.toLowerCase();
      const ol = pp && kid(pp, 'w:outlineLvl') ? +kid(pp, 'w:outlineLvl').attrs['w:val'] : S.outline; const hm = nm.match(/^(?:heading|見出し)\s*(\d)$/); const level = hm ? +hm[1] - 1 : ol != null && ol < 9 ? ol : null;
      const text = await runsText(p); if (!text) { lines.push(''); return; }
      if (/^(title|表題|タイトル)$/.test(nm) && !title) { title = text.replace(/\*\*/g, ''); lines.push('', '# ' + title, ''); return; }
      if (level != null) { anyHead = true; lines.push('', '#'.repeat(Math.min(6, level + 2)) + ' ' + text.replace(/\*\*/g, '').replace(HEADNUM, ''), ''); return; } /* 手書きの番号は外す（文机が振る） */
      const np = pp && kid(pp, 'w:numPr'); const numId = np && kid(np, 'w:numId') ? kid(np, 'w:numId').attrs['w:val'] : S.numId; const nameLv = (nm.match(/^(?:list bullet|list number|箇条書き|段落番号)\s*(\d)$/) || [])[1]; const ilvl = np && kid(np, 'w:ilvl') ? +kid(np, 'w:ilvl').attrs['w:val'] : nameLv ? +nameLv - 1 : (S.ilvl || 0); /* 「箇条書き 2」のような段はスタイルの名前の数字 */
      if (numId && numId !== '0') { const fm = (numFmt.get(numId) || new Map()).get(ilvl) || (/number/.test(nm) ? 'decimal' : 'bullet'); const bullet = fm === 'bullet' || fm === 'none'; lines.push('  '.repeat(ilvl) + (bullet ? '- ' : '1. ') + text); return; }
      { const lm = nm.match(/^(list bullet|箇条書き|list number|段落番号)\s*(\d)?$/); if (lm) { const lv = Math.max(0, (+lm[2] || 1) - 1); lines.push('  '.repeat(lv) + (/bullet|箇条/.test(lm[1]) ? '- ' : '1. ') + text); return; } }
      const prev = lines[lines.length - 1]; if (prev && /^\s*([-*+]|\d+\.)\s|^\||^#/.test(prev)) lines.push(''); else if (prev && prev.trim() && !/^\s*!\[/.test(prev)) lines[lines.length - 1] = prev + '\\'; /* 前も本文：改行（行を分ける） */ /* 箇条書き・表・見出しの後は段落を切る。本文どうしは空行を入れない（Word の段落 1 つ＝1 行） */
      lines.push(text.split('\n').map(x => x.replace(/^(\s*)([#>+\-]|\d+[.)])/, '$1\\$2')).join('\n')); }
    async function table(t) { const rows = []; for (const tr of kids(t, 'w:tr')) { const r = []; for (const tc of kids(tr, 'w:tc')) { const ps = all(tc, 'w:p'); const parts = []; for (const p of ps) { const x = await runsText(p); if (x) parts.push(x.replace(/\n+/g, ' ')); } r.push(parts.join(' ').replace(/\|/g, '\\|')); } if (r.length) rows.push(r); }
      if (!rows.length) return; const nc = Math.max(...rows.map(r => r.length)); lines.push(''); rows.forEach((r, k) => { lines.push('| ' + Array.from({ length: nc }, (_, c) => r[c] || '').join(' | ') + ' |'); if (k === 0) lines.push('|' + Array.from({ length: nc }, () => ' --- ').join('|') + '|'); }); lines.push(''); }
    const walkBody = async el => { for (const k of el.kids || []) { if (k.name === 'w:p') await para(k); else if (k.name === 'w:tbl') await table(k); else if (k.name === 'w:sdt') { const c = kid(k, 'w:sdtContent'); if (c) await walkBody(c); } } };
    await walkBody(body);
    const md = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
    const doc = FZ.fromGfm(md, base || FZ.newDoc(), { brSplit: true }); /* Word の段落どうしは改行でつないだ：読む時は別の段落に */ doc.images = { ...(doc.images || {}), ...images }; if (title && !doc.title) doc.title = title;
    let lifted = 0; if (!anyHead && FZ.liftJaMarkers) { /* 見出しスタイルの無い文書：平文の番号から節を起こす。番号の形にいちばん合う体系（標準・公用文・契約書…）を選んでから */
      const keys = []; for (const ln of doc.lines) { if (ln.segs.length !== 1) continue; const mk = FZ.jaMarkerAt(ln.segs[0].text); if (mk && mk.kind === 'num') keys.push(mk.key); }
      if (keys.length) { const score = num => keys.filter(k => num.includes(k)).length; const cur = FZ.normalizeScheme(doc.format.scheme); let best = null, bs = score(cur); for (const p of FZ.SCHEME_PRESETS) { const sc = score(p.num); if (sc > bs) { bs = sc; best = p; } } if (best) { doc.format.scheme = FZ.normalizeScheme(best.num); doc.format.titleLevels = best.title; } }
      lifted = FZ.liftJaMarkers(doc) || 0; }
    return { doc: FZ.normalize(doc), md, headings: anyHead, lifted, images: imgN };
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
