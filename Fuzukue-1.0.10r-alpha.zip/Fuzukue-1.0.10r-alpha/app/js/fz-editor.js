/* 文机 エディタ：文書への編集操作（カーソル・選択・Undo・罫線・網掛け・検索） */
(function (FZ) {
'use strict';
const M = FZ.M, G = FZ.graphemes;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const half = v => Math.round(v * 2) / 2;
const cmp = (a, b) => a.line - b.line || a.seg - b.seg || a.off - b.off;
const isSpace = t => /^[\s　]+$/.test(t);

class Editor {
  constructor() { this.syncLines = 2000; this.job = null; this.onLayoutPending = null;
    this.doc = FZ.newDoc(); this.caret = { line: 0, seg: 0, off: 0, vcol: null, vrow: 0 }; this.anchor = null; this.goal = null;
    this.typing = 0; this.undoStack = []; this.redoStack = []; this.lastKey = ''; this.lastTime = 0;
    this.dirty = false; this.onChange = () => {}; this.onCaret = () => {};
    this.relayout();
  }
  /* ---------- 基本 ---------- */
  setDoc(doc) { this.doc = FZ.normalize(doc); this.caret = { line: 0, seg: 0, off: 0, vcol: null, vrow: 0 }; this.anchor = null; this.undoStack = []; this.redoStack = []; this.dirty = false; this.lastKey = ''; this.relayout(); this.onChange('doc'); }
  /* 組版：前回の組版を渡し、変わった所だけ置き直す。巨大な文書では、カーソルの少し先までを同期で組んで（画面に出せる）、残りは continueLayout で少しずつ進める */
  relayout() {
    const job = FZ.layoutJob(this.doc, {}, this.lay); this.job = null;
    const want = Math.min(this.doc.lines.length, Math.max(this.caret.line, this.anchor ? this.anchor.line : 0) + this.syncLines);
    while (!job.done && job.placed < want) job.run(500);
    this.lay = job.finish();
    if (!job.done) { this.job = job; if (this.onLayoutPending) this.onLayoutPending(); }
  }
  /* 途中の組版を ms ミリ秒ぶん進める。戻り値：終わったか */
  continueLayout(ms = 12) { const job = this.job; if (!job) return true; const t0 = Date.now(); while (!job.done && Date.now() - t0 < ms) job.run(250); this.lay = job.finish(); if (job.done) this.job = null; return job.done; }
  get layoutDone() { return !this.job; }
  line(i = this.caret.line) { return this.doc.lines[i]; }
  seg(p = this.caret) { return this.doc.lines[p.line].segs[p.seg]; }
  get lineCount() { return this.doc.lines.length; }
  /* 取消の履歴：行ごとの JSON 文字列の配列。行の内容の署名（組版が計算したもの）が同じなら前回の文字列を使い回すので、
     キー 1 打ごとに全文を文字列化しない。履歴どうしでも文字列を共有する（巨大な文書で履歴 300 個が数百 MB にならない） */
  snapshot() { const L = this.lay, ok = L && L.csigA && L.csigA.length === this.doc.lines.length; const lines = new Array(this.doc.lines.length);
    for (let i = 0; i < lines.length; i++) { const ln = this.doc.lines[i]; const sig = ok ? L.csigA[i] + ':' + L.csigB[i] : FZ.contentSig(ln); const c = ln._j; if (c && c.sig === sig) { lines[i] = c.json; continue; } const json = JSON.stringify(ln); Object.defineProperty(ln, '_j', { value: { sig, json }, enumerable: false, writable: true, configurable: true }); lines[i] = json; }
    return { lines, meta: JSON.stringify({ rules: this.doc.rules, fills: this.doc.fills, format: this.doc.format, title: this.doc.title, parked: this.doc.parked || [] }), caret: { ...this.caret } }; }
  restore(s) { const d = JSON.parse(s.meta); Object.assign(this.doc, d); const cur = this.doc.lines, L = this.lay, ok = L && L.csigA && L.csigA.length === cur.length;
    this.doc.lines = s.lines.map((j, i) => { const c = cur[i]; if (c && c._j && c._j.json === j && ok && c._j.sig === L.csigA[i] + ':' + L.csigB[i]) return c; // 今の行と同じ内容ならそのまま（折返しの覚えも残る）
      const ln = JSON.parse(j); Object.defineProperty(ln, '_j', { value: { sig: null, json: j }, enumerable: false, writable: true, configurable: true }); return ln; });
    this.caret = { ...s.caret }; this.anchor = null; this.clampCaret(); }
  pushUndo(key = '') { const now = Date.now(); if (key && key === this.lastKey && now - this.lastTime < 900) { this.lastTime = now; return; } this.undoStack.push(this.snapshot()); const n = this.doc.lines.length; const cap = n > 20000 ? 60 : n > 5000 ? 150 : 300; while (this.undoStack.length > cap) this.undoStack.shift(); this.redoStack = []; this.lastKey = key; this.lastTime = now; }
  breakUndo() { this.lastKey = ''; }
  mutate(key, fn) { this.pushUndo(key); const r = fn(); this.afterMutate(); return r; }
  afterMutate() { this.fixBlocks(); this.goal = null; this.clampCaret(); this.relayout(); this.dirty = true; this.onChange('edit'); }
  /* 目次の行は本文を持たない。範囲の削除や結合で文字が乗ったら、その文字を次の行に逃がす（黙って消さない） */
  fixBlocks() { const L = this.doc.lines; for (let i = 0; i < L.length; i++) { const ln = L[i]; if (!ln.attrs.toc && !ln.attrs.hr) continue; const text = ln.segs.map(s => s.text).join(''); if (!text && ln.segs.length === 1) continue; const segs = ln.segs; ln.segs = [FZ.newSeg(0, '')]; L.splice(i + 1, 0, { segs: segs.length === 1 ? segs : [FZ.newSeg(0, text)], attrs: {} }); if (this.caret.line === i && this.caret.off > 0) { this.caret.line = i + 1; } } }
  undo() { if (!this.undoStack.length) return false; this.redoStack.push(this.snapshot()); this.restore(this.undoStack.pop()); this.breakUndo(); this.relayout(); this.dirty = true; this.onChange('edit'); return true; }
  redo() { if (!this.redoStack.length) return false; this.undoStack.push(this.snapshot()); this.restore(this.redoStack.pop()); this.breakUndo(); this.relayout(); this.dirty = true; this.onChange('edit'); return true; }
  clampCaret() { const c = this.caret; c.line = clamp(c.line | 0, 0, this.doc.lines.length - 1); const ln = this.doc.lines[c.line]; c.seg = clamp(c.seg | 0, 0, ln.segs.length - 1); c.off = clamp(c.off | 0, 0, ln.segs[c.seg].text.length); if (this.anchor) { const a = this.anchor; a.line = clamp(a.line | 0, 0, this.doc.lines.length - 1); const l2 = this.doc.lines[a.line]; a.seg = clamp(a.seg | 0, 0, l2.segs.length - 1); a.off = clamp(a.off | 0, 0, l2.segs[a.seg].text.length); } }
  setCaret(p, extend = false) { this.goal = null; if (extend) { if (!this.anchor) this.anchor = { line: this.caret.line, seg: this.caret.seg, off: this.caret.off }; } else this.anchor = null; this.caret = { line: p.line, seg: p.seg, off: p.off, vcol: p.vcol ?? null, vrow: p.vrow | 0 }; this.clampCaret(); if (this.anchor && cmp(this.anchor, this.caret) === 0 && !extend) this.anchor = null; this.onCaret(); }
  sel() { if (!this.anchor) return null; const a = this.anchor, b = this.caret; if (cmp(a, b) === 0) return null; return cmp(a, b) < 0 ? { a: { ...a }, b: { line: b.line, seg: b.seg, off: b.off } } : { a: { line: b.line, seg: b.seg, off: b.off }, b: { ...a } }; }
  selInSeg() { const s = this.sel(); return s && s.a.line === s.b.line && s.a.seg === s.b.seg ? s : null; }
  /* ---------- 文字列 ---------- */
  textOf(range) {
    const { a, b } = range; const out = [];
    for (let i = a.line; i <= b.line; i++) {
      const parts = [];
      this.doc.lines[i].segs.forEach((s, k) => {
        if ((i === a.line && k < a.seg) || (i === b.line && k > b.seg)) return;
        const from = (i === a.line && k === a.seg) ? a.off : 0, to = (i === b.line && k === b.seg) ? b.off : s.text.length;
        parts.push(s.text.slice(from, to));
      });
      out.push(parts.join('\t'));
    }
    return out.join('\n');
  }
  /* ---------- 行の挿入・削除（罫線・網掛けの追従） ---------- */
  insertLine(k, line, within = false) {
    this.doc.lines.splice(k, 0, line);
    for (const r of this.doc.rules) { if (r.axis === 'h') { if (r.line >= k) r.line++; } else { if (r.from >= k) { r.from++; r.to++; } else if (r.to >= k || (within && r.to === k - 1)) r.to++; } }
    for (const x of this.doc.fills) { if (x.from >= k) { x.from++; x.to++; } else if (x.to >= k) x.to++; }
  }
  removeLine(k) {
    if (this.doc.lines.length <= 1) { this.doc.lines[0] = FZ.newLine(); return; }
    this.doc.lines.splice(k, 1);
    const keepR = [];
    for (const r of this.doc.rules) { if (r.axis === 'h') { if (r.line > k) r.line--; keepR.push(r); } else { if (r.from > k) { r.from--; r.to--; } else if (r.to >= k) r.to--; if (r.to >= r.from) keepR.push(r); } }
    this.doc.rules = keepR; this.doc.fills = this.doc.fills.filter(x => { if (x.from > k) { x.from--; x.to--; } else if (x.to >= k) x.to--; return x.to >= x.from; });
    this.dedupeRules();
  }
  dedupeRules() { const seen = new Set(); this.doc.rules = this.doc.rules.filter(r => { const key = r.axis === 'h' ? `h${r.line}:${r.from}:${r.to}:${r.kind}` : `v${r.col}:${r.from}:${r.to}:${r.kind}`; if (seen.has(key)) return false; seen.add(key); return true; }); }
  /* 表から外れた行のセルを一本化 */
  normalizeSegs() {
    this.doc.lines.forEach((ln, i) => {
      if (FZ.inTable(this.doc, i)) { // セルの左端に揃える
        const cells = FZ.cellsAt(this.doc, i); for (const s of ln.segs) { const c = cells.find(c => s.col >= c.left && s.col < c.right) || cells[cells.length - 1]; s.col = c.left; }
        // 同じセルに複数セグメント：結合
        const byCol = new Map(); for (const s of ln.segs) { if (byCol.has(s.col)) { const t = byCol.get(s.col); t.text += s.text; t.marks.push(...s.marks); } else byCol.set(s.col, s); } ln.segs = [...byCol.values()].sort((a, b) => a.col - b.col);
      } else if (ln.segs.length > 1 || ln.segs[0].col > 0 || (ln.attrs.cells && !FZ.vRulesAt(this.doc, i).length)) {
        delete ln.attrs.cells;
        const seg = FZ.newSeg(0, ''); let col = 0;
        for (const s of ln.segs) { const pad = Math.max(0, s.col - col); const padText = '　'.repeat(Math.floor(pad)) + (pad % 1 ? ' ' : ''); seg.text += padText; for (let q = 0; q < padText.length; q++) seg.marks.push(0); seg.text += s.text; seg.marks.push(...s.marks); col = s.col + this.widthOf(s); }
        ln.segs = [seg];
      }
    });
  }
  widthOf(seg) { let w = 0; for (const g of G(seg.text)) w += FZ.gWidth(g, seg.marks[g.start] | 0); return w; }
  /* ---------- 原始操作 ---------- */
  spliceSeg(seg, start, end, text, marks) { const ins = marks || FZ.marksFor(text, this.typing & ~FZ.M.LINK); seg.text = seg.text.slice(0, start) + text + seg.text.slice(end); seg.marks.splice(start, end - start, ...ins); if (seg.links) { FZ.spliceLinks(seg, start, end, text.length); FZ.syncLinks(seg); } }
  deleteRange(r) { // 戻り値：削除後のカーソル位置
    const { a, b } = r; const L = this.doc.lines;
    if (a.line === b.line && a.seg === b.seg) { this.spliceSeg(L[a.line].segs[a.seg], a.off, b.off, ''); return { ...a }; }
    const tableA = FZ.inTable(this.doc, a.line) || L[a.line].segs.length > 1, tableB = FZ.inTable(this.doc, b.line) || L[b.line].segs.length > 1;
    if (a.line === b.line) { // 同じ行の別セル：各セルの範囲を消す（結合しない）
      const ln = L[a.line]; ln.segs.forEach((s, k) => { if (k === a.seg) this.spliceSeg(s, a.off, s.text.length, ''); else if (k === b.seg) this.spliceSeg(s, 0, b.off, ''); else if (k > a.seg && k < b.seg) this.spliceSeg(s, 0, s.text.length, ''); }); return { ...a };
    }
    if (tableA || tableB) { // 表をまたぐ：各行の該当部分のみ消し、行は結合しない
      for (let i = a.line; i <= b.line; i++) { const ln = L[i]; ln.segs.forEach((s, k) => { if (i === a.line) { if (k === a.seg) this.spliceSeg(s, a.off, s.text.length, ''); else if (k > a.seg) this.spliceSeg(s, 0, s.text.length, ''); } else if (i === b.line) { if (k === b.seg) this.spliceSeg(s, 0, b.off, ''); else if (k < b.seg) this.spliceSeg(s, 0, s.text.length, ''); } else this.spliceSeg(s, 0, s.text.length, ''); }); }
      return { ...a };
    }
    const sa = L[a.line].segs[a.seg], sb = L[b.line].segs[b.seg];
    const tail = sb.text.slice(b.off), tailM = sb.marks.slice(b.off);
    const la = (sa.links || []).filter(l => l.start < a.off).map(l => ({ ...l, end: Math.min(l.end, a.off) })), lb = (sb.links || []).filter(l => l.end > b.off).map(l => ({ ...l, start: Math.max(l.start, b.off) - b.off + a.off, end: l.end - b.off + a.off }));
    sa.text = sa.text.slice(0, a.off) + tail; sa.marks = sa.marks.slice(0, a.off).concat(tailM); if (la.length || lb.length) { sa.links = [...la, ...lb]; FZ.syncLinks(sa); } else { delete sa.links; FZ.syncLinks(sa); }
    this.moveFigs(b.line, a.line); // 残る後ろの部分に付いていた図版は前の行へ（間の行の図版は文と一緒に消える）
    for (let i = b.line; i > a.line; i--) this.removeLine(i);
    return { line: a.line, seg: a.seg, off: a.off };
  }
  /* 図版を行 from から行 to へ移す（行の結合・分割で） */
  moveFigs(from, to) { const A = this.doc.lines[from].attrs, B = this.doc.lines[to].attrs; if (!A.figs || from === to) return; B.figs = (B.figs || []).concat(A.figs); delete A.figs; }
  deleteSelection() { const s = this.sel(); if (!s) return false; const p = this.deleteRange(s); this.anchor = null; this.caret = { ...p, vcol: null, vrow: 0 }; return true; }
  /* 仮想位置（空白詰め・仮想行）を実体化 */
  materialize() {
    const c = this.caret;
    if (c.vrow > 0) { const n = c.vrow; const col = c.vcol; for (let k = 0; k < n; k++) this.insertLine(this.doc.lines.length, FZ.newLine()); c.line = this.doc.lines.length - 1; c.seg = 0; c.off = 0; c.vrow = 0; c.vcol = col; }
    if (c.vcol != null) {
      const seg = this.seg(); const xy = FZ.posToXY(this.lay, { line: c.line, seg: c.seg, off: seg.text.length }); const endCol = xy ? xy.row.endCol : 0;
      const need = Math.max(0, c.vcol - endCol); if (need > 0) { const pad = '　'.repeat(Math.floor(need)) + (need % 1 ? ' ' : ''); this.spliceSeg(seg, seg.text.length, seg.text.length, pad, FZ.marksFor(pad, 0)); }
      c.off = seg.text.length; c.vcol = null;
    }
  }
  /* ---------- 文字入力 ---------- */
  insertText(text, opts = {}) {
    text = FZ.cleanText(String(text)).replace(/\r\n?/g, '\n');
    this.mutate(opts.key || 'type', () => {
      this.deleteSelection(); this.materialize();
      const parts = text.split('\n');
      parts.forEach((part, k) => {
        if (k > 0) this.splitLine();
        const cells = FZ.inTable(this.doc, this.caret.line) ? part.split('\t') : [part.replace(/\t/g, '　　')];
        cells.forEach((cell, q) => { if (q > 0) this.nextCell(false); const seg = this.seg(); const marks = FZ.marksFor(cell, this.typing); this.spliceSeg(seg, this.caret.off, this.caret.off, cell, marks); this.caret.off += cell.length; });
      });
    });
  }
  /* textarea の変化を取り込む（IME中も呼ばれる） */
  applyDiff(newText, selEnd, opts = {}) {
    const seg = this.seg(); const old = seg.text; if (old === newText) { this.caret.off = clamp(selEnd, 0, newText.length); this.anchor = null; this.onCaret(); return; }
    let p = 0; const n = Math.min(old.length, newText.length); while (p < n && old[p] === newText[p]) p++;
    let s = 0; while (s < n - p && old[old.length - 1 - s] === newText[newText.length - 1 - s]) s++;
    const inserted = newText.slice(p, newText.length - s);
    if (/[\r\n\t]/.test(inserted)) { // 改行・タブが混入した場合は行分割として扱う
      this.pushUndo(''); this.spliceSeg(seg, p, old.length - s, ''); this.caret.off = p; this.anchor = null; this.insertText(inserted.replace(/\r/g, ''), { key: '' }); return;
    }
    if (this.caret.vrow > 0 || this.caret.vcol != null) { // 仮想位置への入力：実体化してから末尾に足す
      this.mutate(opts.composing ? 'comp' : 'type', () => { this.anchor = null; this.materialize(); const sg = this.seg(); this.spliceSeg(sg, sg.text.length, sg.text.length, inserted, FZ.marksFor(inserted, this.typing)); this.caret.off = sg.text.length; });
      return;
    }
    this.mutate(opts.composing ? 'comp' : 'type', () => {
      this.spliceSeg(seg, p, old.length - s, inserted, FZ.marksFor(inserted, this.typing));
      this.caret.off = clamp(selEnd, 0, seg.text.length); this.caret.vcol = null; this.anchor = null;
    });
  }
  splitLine() {
    const c = this.caret; const ln = this.line(); const seg = this.seg();
    if (FZ.inTable(this.doc, c.line) || ln.segs.length > 1) { // 表：行を追加し、カーソル以降をその行の同じセルへ
      const nl = { segs: ln.segs.map(s => FZ.newSeg(s.col, '')), attrs: { cells: true } };
      const target = nl.segs[c.seg]; target.text = seg.text.slice(c.off); target.marks = seg.marks.slice(c.off); seg.text = seg.text.slice(0, c.off); seg.marks = seg.marks.slice(0, c.off);
      const tops = this.doc.rules.filter(r => r.axis === 'h' && r.line === c.line).map(r => ({ ...r }));
      this.insertLine(c.line + 1, nl, true); for (const r of tops) this.doc.rules.push({ ...r, id: FZ.uid(), line: c.line + 1 }); this.dedupeRules(); c.line++; c.off = 0; c.vcol = null; return;
    }
    const a = ln.attrs; const bx = this.boxAt(c.line);
    // 囲み（箱）の最後の行が空で Enter：囲みの外へ出る（箱を 1 行縮め、この行を箱の下に置く）
    if (bx && c.line === bx.to && c.line > bx.from && seg.text === '' && !(a.list && (a.list.level | 0) > 0)) { this.leaveBox(bx, c.line); c.seg = 0; c.off = 0; c.vcol = null; return; }
    if (a.join && c.off === 0) { delete a.join; if (a.list && a.list.kind === 'cont') a.list = this.ownerItem(c.line); return; } /* 段落の中の改行の行頭で Enter：ここで段落（項目）を分ける */
    if (a.list && seg.text === '' && c.off === 0) { if ((a.list.level | 0) > 0) a.list = { ...a.list, level: a.list.level - 1 }; else delete a.list; return; }
    if (c.off === 0 && seg.text !== '') { // 行頭で Enter：上に空の行を入れる。この行（見出し・属性・罫・網・図版）はそのまま下へ
      const up = { segs: [FZ.newSeg(0, '')], attrs: {} }; const inside = bx && c.line > bx.from;
      if (a.list) up.attrs.list = { ...a.list, ...(a.list.kind === 'done' ? { kind: 'todo' } : {}) };
      if (a.list || inside) { if (a.indent != null) up.attrs.indent = a.indent; if (a.hanging != null) up.attrs.hanging = a.hanging; }
      this.insertLine(c.line, up); c.line++; c.seg = 0; c.off = 0; c.vcol = null; return;
    }
    const nl = { segs: [FZ.newSeg(0, seg.text.slice(c.off))], attrs: { ...a } }; nl.segs[0].marks = seg.marks.slice(c.off);
    const boxTitle = bx && c.line === bx.from && bx.to > bx.from - 1 && this.doc.fills.some(f => f.from === c.line && f.to === c.line && f.col <= bx.L && f.col + f.cols >= bx.R);
    if (boxTitle) { delete nl.attrs.keep; delete nl.attrs.deco; nl.attrs.list = { level: 0 }; } // 囲み記事の題で Enter：下は本文（記号の箇条書き）
    if (a.figs) { if (c.off === 0 && seg.text !== '') delete a.figs; else delete nl.attrs.figs; } // 図版は文の付いている側に残る（行頭で Enter なら下の行へ）
    if (seg.links) { const cut = c.off; nl.segs[0].links = seg.links.filter(l => l.end > cut).map(l => ({ ...l, start: Math.max(0, l.start - cut), end: l.end - cut })); seg.links = seg.links.filter(l => l.start < cut).map(l => ({ ...l, end: Math.min(l.end, cut) })); FZ.syncLinks(nl.segs[0]); }
    seg.text = seg.text.slice(0, c.off); seg.marks = seg.marks.slice(0, c.off); if (seg.links) FZ.syncLinks(seg);
    if (nl.attrs.join) { delete nl.attrs.join; if (nl.attrs.list && nl.attrs.list.kind === 'cont') nl.attrs.list = this.ownerItem(c.line); } /* 改行の行の途中で Enter：後ろは新しい段落（項目） */
    if (nl.attrs.style === 'title' || FZ.isHeading(nl.attrs)) { if (FZ.isHeading(nl.attrs) && seg.text === '' && c.off === 0) {/* 空の見出しで Enter：見出しを外す */ } delete nl.attrs.style; delete nl.attrs.level; } delete nl.attrs.breakBefore;
    if (nl.attrs.style === 'speech' && this.typing & M.BOLD) {/* keep */ }
    this.insertLine(c.line + 1, nl, !!(bx && c.line === bx.to)); c.line++; c.seg = 0; c.off = 0; c.vcol = null; // 箱の最後の行で Enter：箱を下へ広げる
    if (a.style === 'title' || (FZ.isHeading(a) && this.isTitleLike(a))) this.typing &= ~M.BOLD;
  }
  /* 行 i を囲む箱：左右の縦罫が同じ範囲で、その上下を横罫が閉じている（表の中は除く）。{ from, to, L, R } | null */
  boxAt(i) {
    const d = this.doc; if (FZ.inTable(d, i)) return null;
    const vs = d.rules.filter(r => r.axis === 'v' && r.from <= i && r.to >= i).sort((x, y) => x.col - y.col); if (vs.length < 2) return null;
    for (let p = 0; p < vs.length; p++) for (let q = vs.length - 1; q > p; q--) { const l = vs[p], r = vs[q]; if (l.from !== r.from || l.to !== r.to) continue;
      const closes = y => d.rules.some(h => h.axis === 'h' && h.line === y && h.from <= l.col + 1e-6 && h.to >= r.col - 1e-6);
      if (closes(l.from) && closes(l.to + 1)) return { from: l.from, to: l.to, L: l.col, R: r.col }; }
    return null;
  }
  /* 箱の最後の行 i を箱の外へ：縦罫を 1 行縮め、下辺の横罫を i の上へ。行の字下げ・箇条書きを外す */
  leaveBox(bx, i) {
    const d = this.doc;
    for (const r of d.rules) { if (r.axis === 'v' && r.to === i && r.from <= i && r.col >= bx.L - 1e-6 && r.col <= bx.R + 1e-6) r.to = i - 1; else if (r.axis === 'h' && r.line === i + 1 && r.from <= bx.L + 1e-6 && r.to >= bx.R - 1e-6) r.line = i; }
    d.rules = d.rules.filter(r => r.axis !== 'v' || r.to >= r.from);
    for (const f of d.fills) if (f.to === i && f.from < i && f.col >= bx.L - 1e-6 && f.col + f.cols <= bx.R + 1e-6) f.to = i - 1;
    const at = d.lines[i].attrs; delete at.indent; delete at.hanging; delete at.list; delete at.keep;
    this.dedupeRules();
  }
  enter() { this.mutate('', () => { this.deleteSelection(); this.caret.vcol = null; this.materialize(); this.splitLine(); }); this.breakUndo(); }
  /* 段落・項目の中の改行（Shift+Enter）：次の行は同じ段落（項目）の続き（attrs.join）。見出し・表・コードなどでは Enter と同じ */
  softBreak() { const ln0 = this.line(), a0 = ln0.attrs; if (FZ.inTable(this.doc, this.caret.line) || ln0.segs.length > 1 || a0.style || a0.code || a0.figure || a0.toc || a0.hr || a0.deco) { this.enter(); return; }
    this.mutate('', () => { this.deleteSelection(); this.caret.vcol = null; this.materialize(); const c = this.caret, ln = this.line(), a = ln.attrs, seg = this.seg();
      const nl = { segs: [FZ.newSeg(0, seg.text.slice(c.off))], attrs: { join: true } }; nl.segs[0].marks = seg.marks.slice(c.off);
      for (const k of ['indent', 'hanging', 'quote', 'align']) if (a[k] != null) nl.attrs[k] = a[k]; if (a.list) nl.attrs.list = { kind: 'cont', level: a.list.level | 0 };
      if (seg.links) { const cut = c.off; nl.segs[0].links = seg.links.filter(l => l.end > cut).map(l => ({ ...l, start: Math.max(0, l.start - cut), end: l.end - cut })); seg.links = seg.links.filter(l => l.start < cut).map(l => ({ ...l, end: Math.min(l.end, cut) })); FZ.syncLinks(nl.segs[0]); }
      seg.text = seg.text.slice(0, c.off); seg.marks = seg.marks.slice(0, c.off); if (seg.links) FZ.syncLinks(seg);
      const bx = this.boxAt(c.line); this.insertLine(c.line + 1, nl, !!(bx && c.line === bx.to)); c.line++; c.seg = 0; c.off = 0; c.vcol = null; });
    this.breakUndo(); }
  /* 続きの行（cont）の持ち主の項目の種類 → 新しい項目の list */
  ownerItem(i) { const L = this.doc.lines; const cur = L[i].attrs.list || { level: 0 }; for (let k = i - 1; k >= 0; k--) { const l = L[k].attrs.list; if (!l) break; if (l.kind === 'cont') continue; if ((l.level | 0) !== (cur.level | 0)) { if ((l.level | 0) < (cur.level | 0)) break; continue; } const kind = l.kind === 'done' ? 'todo' : l.kind; return kind && kind !== 'item' ? { kind, level: cur.level | 0 } : { level: cur.level | 0 }; } return { level: cur.level | 0 }; }
  backspace() {
    const c = this.caret; if (this.sel()) { this.mutate('', () => this.deleteSelection()); return; }
    if (c.vrow > 0) { c.vrow--; if (c.vrow === 0) { c.vcol = null; this.caret.off = this.seg().text.length; } this.onCaret(); return; }
    if (c.vcol != null) { const xy = FZ.posToXY(this.lay, { ...c, vcol: null }); c.vcol = half(c.vcol - 0.5); if (!xy || c.vcol <= xy.col) c.vcol = null; this.onCaret(); return; }
    const seg = this.seg(), ln = this.line();
    if (c.off > 0) { const gs = G(seg.text); const g = gs.find(g => g.end === c.off) || gs.find(g => g.start < c.off && g.end >= c.off); this.mutate('bs', () => { this.spliceSeg(seg, g.start, c.off, ''); c.off = g.start; }); return; }
    if (c.seg > 0) { c.seg--; c.off = this.seg().text.length; this.onCaret(); return; }
    const a = ln.attrs;
    if (!a.join) { /* 段落の中の改行（Shift+Enter）の行頭は、段や字下げを外さず前の行につなぐ */
    if (a.list) { this.mutate('', () => { if ((a.list.level | 0) > 0) a.list = { ...a.list, level: a.list.level - 1 }; else delete a.list; }); return; }
    if (a.indent) { this.mutate('', () => { delete a.indent; }); return; }
    if (a.align && a.align !== 'left') { this.mutate('', () => { delete a.align; }); return; } }
    if (c.line === 0) return;
    const table = FZ.inTable(this.doc, c.line) || ln.segs.length > 1, prevTable = FZ.inTable(this.doc, c.line - 1) || this.doc.lines[c.line - 1].segs.length > 1;
    if (table) { if (ln.segs.every(s => !s.text)) { this.mutate('', () => { this.removeLine(c.line); c.line--; const l2 = this.line(); c.seg = l2.segs.length - 1; c.off = l2.segs[c.seg].text.length; this.normalizeSegs(); }); } else { c.line--; const l2 = this.line(); c.seg = l2.segs.length - 1; c.off = l2.segs[c.seg].text.length; this.onCaret(); } return; }
    if (prevTable) { c.line--; const l2 = this.line(); c.seg = l2.segs.length - 1; c.off = l2.segs[c.seg].text.length; this.onCaret(); return; }
    this.mutate('', () => { const prev = this.doc.lines[c.line - 1].segs[0]; const at = prev.text.length; prev.text += seg.text; prev.marks.push(...seg.marks); if (seg.links) { prev.links = [...(prev.links || []), ...seg.links.map(l => ({ ...l, start: l.start + at, end: l.end + at }))]; FZ.syncLinks(prev); } if (!this.doc.lines[c.line - 1].attrs.style && ln.attrs.style && prev.text === seg.text) { const pf = this.doc.lines[c.line - 1].attrs.figs; this.doc.lines[c.line - 1].attrs = { ...ln.attrs }; delete this.doc.lines[c.line - 1].attrs.figs; if (pf) this.doc.lines[c.line - 1].attrs.figs = pf; } this.moveFigs(c.line, c.line - 1); this.removeLine(c.line); c.line--; c.seg = 0; c.off = at; });
  }
  del() {
    const c = this.caret; if (this.sel()) { this.mutate('', () => this.deleteSelection()); return; }
    if (c.vcol != null || c.vrow > 0) return;
    const seg = this.seg(), ln = this.line();
    if (c.off < seg.text.length) { const g = G(seg.text).find(g => g.start === c.off) || G(seg.text).find(g => g.start <= c.off && g.end > c.off); this.mutate('del', () => { this.spliceSeg(seg, g.start, g.end, ''); c.off = g.start; }); return; }
    if (c.seg < ln.segs.length - 1) { c.seg++; c.off = 0; this.onCaret(); return; }
    if (c.line >= this.doc.lines.length - 1) return;
    const table = FZ.inTable(this.doc, c.line) || ln.segs.length > 1, nextTable = FZ.inTable(this.doc, c.line + 1) || this.doc.lines[c.line + 1].segs.length > 1;
    if (table || nextTable) { c.line++; c.seg = 0; c.off = 0; this.onCaret(); return; }
    this.mutate('', () => { const nx = this.doc.lines[c.line + 1].segs[0]; const at = seg.text.length; seg.text += nx.text; seg.marks.push(...nx.marks); if (nx.links) { seg.links = [...(seg.links || []), ...nx.links.map(l => ({ ...l, start: l.start + at, end: l.end + at }))]; FZ.syncLinks(seg); } this.moveFigs(c.line + 1, c.line); this.removeLine(c.line + 1); });
  }
  /* ---------- 表のセル移動 ---------- */
  nextCell(mut = true) {
    const c = this.caret, ln = this.line(); if (!FZ.inTable(this.doc, c.line)) return false;
    const cells = FZ.cellsAt(this.doc, c.line); const cur = cells.findIndex(x => ln.segs[c.seg].col >= x.left && ln.segs[c.seg].col < x.right);
    if (cur < cells.length - 1) { const target = cells[cur + 1]; let k = ln.segs.findIndex(s => s.col === target.left); if (k < 0) { ln.segs.push(FZ.newSeg(target.left, '')); ln.segs.sort((a, b) => a.col - b.col); k = ln.segs.findIndex(s => s.col === target.left); } c.seg = k; c.off = 0; c.vcol = null; }
    else if (c.line < this.doc.lines.length - 1 && FZ.inTable(this.doc, c.line + 1)) { c.line++; c.seg = 0; c.off = 0; c.vcol = null; }
    else return false;
    if (mut) this.onCaret(); return true;
  }
  prevCell() {
    const c = this.caret, ln = this.line(); if (!FZ.inTable(this.doc, c.line)) return false;
    const cells = FZ.cellsAt(this.doc, c.line); const cur = cells.findIndex(x => ln.segs[c.seg].col >= x.left && ln.segs[c.seg].col < x.right);
    if (cur > 0) { const target = cells[cur - 1]; let k = ln.segs.findIndex(s => s.col === target.left); if (k < 0) { ln.segs.push(FZ.newSeg(target.left, '')); ln.segs.sort((a, b) => a.col - b.col); k = ln.segs.findIndex(s => s.col === target.left); } c.seg = k; c.off = ln.segs[k].text.length; c.vcol = null; }
    else if (c.line > 0 && FZ.inTable(this.doc, c.line - 1)) { c.line--; const l2 = this.line(); c.seg = l2.segs.length - 1; c.off = l2.segs[c.seg].text.length; c.vcol = null; }
    else return false;
    this.onCaret(); return true;
  }
  /* 縦罫線をセル境界にする（文字は見た目の位置で各セルへ分配） */
  cellify(i = this.caret.line) {
    const ln = this.doc.lines[i]; if (ln.attrs.cells || !FZ.vRulesAt(this.doc, i).length) return false;
    const lm = this.lay.lineMap[i]; const row0 = lm && lm.segs[0] && lm.segs[0].rows[0]; const cells = FZ.cellsAt(this.doc, i); const seg = ln.segs[0];
    const segs = cells.map(c => FZ.newSeg(c.left, ''));
    if (row0) { for (const g of row0.glyphs) { if (g.marker) continue; const k = Math.max(0, cells.findIndex(c => g.col >= c.left - 1e-6 && g.col < c.right - 1e-6)); const t = segs[k]; if (!t.text && g.col > cells[k].left + 1e-6) { const pad = g.col - cells[k].left; const pt = '　'.repeat(Math.floor(pad)) + (pad % 1 ? ' ' : ''); t.text += pt; for (let q = 0; q < pt.length; q++) t.marks.push(0); } t.text += g.text; for (let q = g.start; q < g.end; q++) t.marks.push(seg.marks[q] | 0); } const restOff = row0.endOff; if (restOff < seg.text.length) { const t = segs[segs.length - 1]; t.text += seg.text.slice(restOff); t.marks.push(...seg.marks.slice(restOff)); } }
    else { segs[0].text = seg.text; segs[0].marks = seg.marks.slice(); }
    ln.segs = segs.filter((s, k) => k === 0 || s.text || true); ln.attrs.cells = true; const c = this.caret; if (c.line === i) { c.seg = 0; c.off = 0; c.vcol = null; }
    return true;
  }
  tab(shift) {
    const c = this.caret;
    if (!FZ.inTable(this.doc, c.line) && FZ.vRulesAt(this.doc, c.line).length && !this.line().attrs.cells) { this.mutate('', () => { this.cellify(c.line); }); }
    if (FZ.inTable(this.doc, c.line)) { this.pushUndo(''); if (shift) this.prevCell(); else this.nextCell(); this.afterMutateSoft(); return; }
    if (this.line().attrs.list || FZ.isHeading(this.line().attrs)) { this.indent(shift ? -1 : 1); return; }
    if (c.off === 0 && !this.sel() && c.vcol == null && !c.vrow) { this.posShift(shift ? -1 : 1); return; } // 本文の行頭：位置（K-8）
    if (shift) return;
    this.mutate('', () => { this.deleteSelection(); this.materialize(); const xy = FZ.posToXY(this.lay, c); const col = xy ? xy.col : 0; const next = Math.floor(col / 4) * 4 + 4; const need = next - col; const pad = '　'.repeat(Math.floor(need)) + (need % 1 ? ' ' : ''); this.spliceSeg(this.seg(), c.off, c.off, pad, FZ.marksFor(pad, 0)); c.off += pad.length; });
  }
  afterMutateSoft() { this.relayout(); this.onChange('edit'); }
  /* ---------- 修飾・段落 ---------- */
  toggleMark(bit) {
    const s = this.sel();
    /* 題の行（表題・記号見出し・題のレベルの数字見出し）の太字は行の見た目：F5 の太字は行全体の「細字」の切替になる（K-1） */
    if (bit === M.BOLD) { const [a, b] = this.selectedLines(); let titles = 0, others = 0; for (let i = a; i <= b; i++) { if (this.isTitleLike(this.doc.lines[i].attrs)) titles++; else others++; }
      if (titles && !others) { const anyThin = (() => { for (let i = a; i <= b; i++) if (this.doc.lines[i].attrs.thin) return true; return false; })(); this.mutate('', () => { for (let i = a; i <= b; i++) { const at = this.doc.lines[i].attrs; if (anyThin) delete at.thin; else at.thin = true; } }); return; } }
    const extra = bit === M.SHADE ? M.SHT : (bit === M.WIDE || bit === M.TALL) ? (M.SZW | M.SZH) : 0; // 網を外すときは文様も、横倍・縦倍を切り替えるときは m×n の倍率も外す
    if (!s) { const on0 = !(this.typing & bit); this.typing = on0 ? ((this.typing & ~extra) | bit) : (this.typing & ~(bit | extra)); this.onCaret(); return; }
    const on = !this.allMarked(s, bit);
    this.mutate('', () => this.forEachMark(s, m => on ? ((m & ~extra) | bit) : (m & ~(bit | extra))));
    this.typing = on ? (this.typing | bit) : (this.typing & ~bit);
  }
  /* 修飾を関数で変える（選択範囲の字、選択が無ければこの後に打つ字）。網の文様・m×n 倍角に使う */
  mapMarks(fn) { const s = this.sel(); if (!s) { this.typing = fn(this.typing | 0); this.onCaret(); return; } this.mutate('', () => this.forEachMark(s, fn)); }
  setMarks(mask) { const s = this.sel(); if (!s) { this.typing = mask; this.onCaret(); return; } this.mutate('', () => this.forEachMark(s, () => mask)); this.typing = mask; }
  allMarked(s, bit) { let all = true, any = false; this.forEachMark(s, m => { any = true; if (!(m & bit)) all = false; return m; }, true); return any && all; }
  forEachMark(s, fn, dry = false) {
    for (let i = s.a.line; i <= s.b.line; i++) { const ln = this.doc.lines[i]; ln.segs.forEach((sg, k) => { if (i === s.a.line && k < s.a.seg) return; if (i === s.b.line && k > s.b.seg) return; const from = (i === s.a.line && k === s.a.seg) ? s.a.off : 0, to = (i === s.b.line && k === s.b.seg) ? s.b.off : sg.text.length; for (let q = from; q < to; q++) { const v = fn(sg.marks[q] | 0); if (!dry) sg.marks[q] = v; } }); }
  }
  selectedLines() { const s = this.sel(); return s ? [s.a.line, s.b.line] : [this.caret.line, this.caret.line]; }
  setAttrs(patch) { const [a, b] = this.selectedLines(); this.mutate('', () => { for (let i = a; i <= b; i++) { const at = this.doc.lines[i].attrs; for (const [k, v] of Object.entries(patch)) { if (v == null) delete at[k]; else at[k] = v; } } }); }
  toggleAttr(k, v) { const cur = this.line().attrs[k]; this.setAttrs({ [k]: (JSON.stringify(cur) === JSON.stringify(v)) ? null : v }); }
  /* 項目：kind なし＝階層体系の項目の入／切（→❏の行なら記号を外して項目に戻す）。
   * kind 'arrow'|'todo'＝行頭記号の上書きを切替（項目でない行に付けたときは、外すと元の本文に戻る） */
  /* 題として太字が既定の行か（表題・記号見出し・題のレベルの数字見出し） */
  isTitleLike(a) { const f = this.doc.format; return a.style === 'title' || a.style === 'sym' || (a.style === 'num' && (a.level | 0) < (f.titleLevels | 0)); }
  /* 見出しの種類を付け外し：'num'（数字見出し）／'sym'（記号見出し）。同じ種類なら外す。箇条書きの下には見出しを置けない → 外してから付ける。レベルは直前の同じ種類の見出しと同じ */
  setHeading(kind) {
    const [a, b] = this.selectedLines(); const cur = this.line().attrs;
    if (cur.style === kind) { this.setAttrs({ style: null, level: null }); return; }
    let lv = 0; for (let i = a - 1; i >= 0; i--) { const at = this.doc.lines[i].attrs; if (at.style === kind) { lv = at.level | 0; break; } if (at.style === 'title') break; }
    this.mutate('', () => { for (let i = a; i <= b; i++) { const at = this.doc.lines[i].attrs; delete at.list; at.style = kind; at.level = lv; } }); // 題の太字は組版が付ける（文字には焼かない。K-1）
  }
  setList(kind) {
    const cur = this.line().attrs.list; const lv = cur ? clamp(cur.level | 0, 0, 7) : 0;
    if (FZ.isHeading(this.line().attrs)) { this.setAttrs({ style: null, level: null, list: { level: 0, ...(kind && kind !== 'todo' ? { kind } : kind === 'todo' ? { kind: 'todo' } : {}) } }); return; } // 見出しを箇条書きに
    if (!kind) { this.setAttrs({ list: !cur ? { level: 0 } : cur.kind ? { level: lv } : null }); return; }
    if (kind === 'todo' && cur && (cur.kind === 'todo' || cur.kind === 'done')) { this.setAttrs({ list: cur.auto ? null : { level: lv } }); return; } // ❏・☑ の行で押す：外す（入切）
    if (kind === 'done' && cur && cur.kind === 'done') { this.setAttrs({ list: { level: lv, kind: 'todo', ...(cur.auto ? { auto: true } : {}) } }); return; } // ☑ の行で「完了」：❏ に戻す
    if (kind === 'done' && cur && cur.kind === 'todo') { this.setAttrs({ list: { level: lv, kind: 'done', ...(cur.auto ? { auto: true } : {}) } }); return; }
    if (!cur) this.setAttrs({ list: { level: 0, kind, auto: true } });
    else if (cur.kind === kind) this.setAttrs({ list: cur.auto ? null : { level: lv } });
    else this.setAttrs({ list: { level: lv, kind } });
  }
  /* 引用：入切（深い引用は Markdown から読んだものをそのまま持つ） */
  cycleQuote() { const q = this.line().attrs.quote | 0; this.setAttrs({ quote: q ? null : 1 }); }
  toggleCode() { const c = this.line().attrs.code; this.setAttrs({ code: c ? null : true }); }
  /* 選択範囲（無ければカーソルのある語）にリンクを付ける／外す（url が空） */
  setLink(url) {
    let s = this.sel(); if (!s || !this.selInSeg()) { const seg = this.seg(), c = this.caret; const cur = FZ.linkAt(seg, c.off) || FZ.linkAt(seg, c.off - 1); if (cur) s = { a: { line: c.line, seg: c.seg, off: cur.start }, b: { line: c.line, seg: c.seg, off: cur.end } }; else { this.selectWord(); s = this.sel(); if (!s) return false; } }
    const seg = this.doc.lines[s.a.line].segs[s.a.seg]; const from = s.a.off, to = s.b.off; if (to <= from) return false;
    this.mutate('', () => { seg.links = (seg.links || []).filter(l => l.end <= from || l.start >= to); if (url) seg.links.push({ start: from, end: to, url }); FZ.syncLinks(seg); this.anchor = null; });
    return true;
  }
  /* 現在の項目の直下に、1 階層深い子項目を作る */
  childItem(kind) {
    const c = this.caret; this.mutate('', () => { this.anchor = null; this.materialize(); const ln = this.line(); const cur = ln.attrs.list; const lv = cur ? clamp((cur.level | 0) + 1, 0, 7) : 0;
      const nl = { segs: [FZ.newSeg(0, '')], attrs: { list: { level: lv, ...(kind === 'arrow' || kind === 'todo' || kind === 'num' ? { kind } : !kind && cur && cur.kind === 'num' ? { kind: 'num' } : {}) } } }; /* 番号付きの項目の子は番号付き（a） b）…） */ this.insertLine(c.line + 1, nl); c.line++; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; });
  }
  /* レベル（構造）：見出し・箇条書きのレベルだけを上下する。位置には触らない。本文の行にはレベルが無いので何もしない（戻り値 false） */
  indent(delta) { const [a, b] = this.selectedLines(); let any = false; for (let i = a; i <= b; i++) { const at = this.doc.lines[i].attrs; if (at.list || FZ.isHeading(at)) any = true; } if (!any) return false;
    this.mutate('', () => { for (let i = a; i <= b; i++) { const at = this.doc.lines[i].attrs; if (at.list) at.list = { ...at.list, level: clamp((at.list.level | 0) + delta, 0, 7) }; else if (FZ.isHeading(at)) at.level = clamp((at.level | 0) + delta, 0, 7); } }); return true; } // 文字の太字には触らない（題の太字は組版。K-1）
  /* 位置（見た目）：行頭の桁。見出し・箇条書きは印の桁、本文は 1 行目の桁。組版の結果から今の桁を読む */
  startCol(i) { const ln = this.doc.lines[i]; const lm = this.lay && this.lay.lineMap[i]; const row = lm && lm.segs[0] && lm.segs[0].rows[0]; if (!row) return ln.attrs.indent | 0; const mk = row.glyphs.filter(g => g.marker && !g.tail); return Math.round(((mk.length ? Math.min(...mk.map(g => g.col)) : row.startCol) - row.left) * 2) / 2; }
  posMovable(i) { const ln = this.doc.lines[i]; const at = ln.attrs; return !(at.figure || at.toc || FZ.inTable(this.doc, i) || at.align === 'center' || at.align === 'right'); }
  /* 位置を delta 桁動かす（選んだ行それぞれ、今の桁から）。見出し・箇条書きは位置を固定し、以後レベルを変えても動かない。本文はぶら下げも一緒に動く */
  posShift(delta) { const [a, b] = this.selectedLines(); const cols = this.lay ? this.lay.geo.bodyCols : this.doc.format.cols; const cur = []; for (let i = a; i <= b; i++) cur[i] = this.posMovable(i) ? this.startCol(i) : null; if (cur.every(c => c == null)) return false;
    this.mutate('', () => { for (let i = a; i <= b; i++) { if (cur[i] == null) continue; const at = this.doc.lines[i].attrs; const nx = clamp(Math.round(cur[i]) + delta, 0, cols - 4); const d = nx - Math.round(cur[i]);
      if (FZ.nodeKind(at)) at.indent = nx; else { if (nx) at.indent = nx; else delete at.indent; if (at.hanging != null) at.hanging = clamp(at.hanging + d, 0, cols - 4); } } }); return true; }
  /* 位置を自動に戻す：見出し・箇条書きはレベルから決まる桁、本文は左端 */
  posReset() { const [a, b] = this.selectedLines(); let any = false; for (let i = a; i <= b; i++) if (this.doc.lines[i].attrs.indent != null) any = true; if (!any) return false; this.mutate('', () => { for (let i = a; i <= b; i++) delete this.doc.lines[i].attrs.indent; }); return true; }
  /* ---------- 図ブロック ---------- */
  /* 現在行の直後（空行なら置き換え）に図を入れ、箱を 1 つ置く。戻り値：図の行番号 */
  insertFigure(h = 10) {
    const c = this.caret; let at = -1;
    this.mutate('', () => { this.anchor = null; this.materialize(); const ln = this.line(); const empty = ln.segs.length === 1 && ln.segs[0].text === '' && !FZ.inTable(this.doc, c.line) && !ln.attrs.figure && !ln.attrs.cells;
      const fig = FZ.normalizeFigure({ h, boxes: [{ id: 1, x: 0, y: 1, w: 8, h: 3, text: '開始' }], arrows: [], lanes: null });
      if (empty) { at = c.line; ln.attrs = { figure: fig }; ln.segs = [FZ.newSeg(0, '')]; }
      else { at = c.line + 1; this.insertLine(at, { segs: [FZ.newSeg(0, '')], attrs: { figure: fig } }); }
      if (at + 1 >= this.doc.lines.length) this.insertLine(at + 1, FZ.newLine());
      c.line = at; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; });
    return at;
  }
  /* 目次ブロックを入れる（空行ならその行、そうでなければ次の行）。戻り値：行番号 */
  insertToc(toc) {
    const c = this.caret; let at = -1;
    this.mutate('', () => { this.anchor = null; this.materialize(); const ln = this.line(); const empty = ln.segs.length === 1 && ln.segs[0].text === '' && !FZ.inTable(this.doc, c.line) && !ln.attrs.figure && !ln.attrs.cells && !ln.attrs.toc;
      const t = FZ.normalizeToc(toc);
      if (empty) { at = c.line; ln.attrs = { toc: t }; ln.segs = [FZ.newSeg(0, '')]; }
      else { at = c.line + 1; this.insertLine(at, { segs: [FZ.newSeg(0, '')], attrs: { toc: t } }); }
      if (at + 1 >= this.doc.lines.length) this.insertLine(at + 1, FZ.newLine());
      c.line = at; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; });
    return at;
  }
  /* 区切り線（K-6）：空行ならその行を区切り線に、そうでなければ次に入れる。その下に本文の空行を置いてカーソルを移す */
  insertHr() { const c = this.caret; this.mutate('', () => { this.anchor = null; this.materialize(); const ln = this.line(); const empty = ln.segs.length === 1 && ln.segs[0].text === '' && !FZ.inTable(this.doc, c.line) && !ln.attrs.figure && !ln.attrs.cells && !ln.attrs.toc && !ln.attrs.hr;
    let at; if (empty) { at = c.line; ln.attrs = { hr: true }; ln.segs = [FZ.newSeg(0, '')]; } else { at = c.line + 1; this.insertLine(at, { segs: [FZ.newSeg(0, '')], attrs: { hr: true } }); }
    if (at + 1 >= this.doc.lines.length || this.doc.lines[at + 1].attrs.hr) this.insertLine(at + 1, FZ.newLine()); c.line = at + 1; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; }); }
  /* 位置の付いていない本文の行の先頭で Tab／Shift+Tab：位置を右へ／左へ（K-8）。行の途中の Tab は今までどおり空白 */
  setToc(i, toc) { const ln = this.doc.lines[i]; if (!ln || !ln.attrs.toc) return false; this.mutate('', () => { ln.attrs.toc = FZ.normalizeToc(toc); }); return true; }
  removeToc(i) { const ln = this.doc.lines[i]; if (!ln || !ln.attrs.toc) return false; this.mutate('', () => { delete ln.attrs.toc; ln.segs = [FZ.newSeg(0, '')]; }); return true; }
  /* 図を変更する（fn に figure を渡す）。終了後に正規化 */
  figOp(i, fn, key = '') { const ln = this.doc.lines[i]; if (!ln || !ln.attrs.figure) return false; this.mutate(key, () => { fn(ln.attrs.figure); ln.attrs.figure = FZ.normalizeFigure(ln.attrs.figure); }); return true; }
  /* 図を本文の空行に戻す（箱が無いときだけ） */
  removeFigure(i) { const ln = this.doc.lines[i]; if (!ln || !ln.attrs.figure) return false; this.mutate('', () => { delete ln.attrs.figure; ln.segs = [FZ.newSeg(0, '')]; }); return true; }
  /* ---------- 罫線 ---------- */
  /* ---------- 図版（資料書式・画像） ----------
     図版は行の属性 attrs.figs（その行が載ったページの図表欄に積まれる）。画像は doc.images に名前で持つ（取消の履歴の外。消さずに残し、保存のときに使っている分だけ書く） */
  figList() { const out = []; this.doc.lines.forEach((ln, i) => (ln.attrs.figs || []).forEach((fg, k) => out.push({ line: i, k, fg }))); return out; }
  figById(id) { return this.figList().find(x => x.fg.id === id) || null; }
  newFigId() { const used = new Set(this.figList().map(x => x.fg.id)); let n = 1; while (used.has('f' + n)) n++; return 'f' + n; }
  addImage(mime, data, name = '') { const imgs = this.doc.images || (this.doc.images = {}); data = String(data).replace(/\s+/g, ''); for (const [k, v] of Object.entries(imgs)) if (v.data === data) return k;
    const ext = ({ 'image/png': '.png', 'image/jpeg': '.jpg', 'image/gif': '.gif', 'image/svg+xml': '.svg', 'image/webp': '.webp' })[mime] || '.img'; let base = String(name || '').replace(/[\s\\/:*?"<>|]+/g, '_').replace(/\.[^.]*$/, ''); if (!base) base = '画像';
    let nm = name ? base + ext : base + '1' + ext; for (let n = 2; imgs[nm]; n++) nm = base + n + ext; imgs[nm] = { mime, data }; return nm; }
  addFigure(fig, line = this.caret.line) { const id = this.newFigId(); this.mutate('', () => { const at = this.doc.lines[line].attrs; (at.figs = at.figs || []).push({ id, kind: fig.kind === '表' ? '表' : '図', title: String(fig.title || ''), file: fig.chart ? '' : String(fig.file || ''), width: [50, 75, 100].includes(+fig.width) ? +fig.width : 100, ...(fig.chart && FZ.normalizeChart ? { chart: FZ.normalizeChart(fig.chart) } : {}) }); }); return id; } // chart：グラフ（fz-chart.js）
  setFig(id, patch) { const x = this.figById(id); if (!x) return false; this.mutate('', () => { Object.assign(x.fg, patch); if (![50, 75, 100].includes(+x.fg.width)) x.fg.width = 100; x.fg.kind = x.fg.kind === '表' ? '表' : '図'; }); return true; }
  removeFig(id) { const x = this.figById(id); if (!x) return false; this.mutate('', () => { const at = this.doc.lines[x.line].attrs; at.figs.splice(x.k, 1); if (!at.figs.length) delete at.figs; }); return true; }
  moveFig(id, dir) { const L = this.figList(); const idx = L.findIndex(x => x.fg.id === id); const t = L[idx + dir]; if (idx < 0 || !t) return false; const me = L[idx];
    this.mutate('', () => { const A = this.doc.lines[me.line].attrs, B = this.doc.lines[t.line].attrs; if (me.line === t.line) { [A.figs[me.k], A.figs[t.k]] = [A.figs[t.k], A.figs[me.k]]; return; } A.figs.splice(me.k, 1); if (!A.figs.length) delete A.figs; B.figs.splice(dir < 0 ? t.k : t.k + 1, 0, me.fg); }); return true; } // 前後の図版と入れ替え（別の行なら、その行へ移る）
  insertRef(id) { this.insertText(FZ.refChar(this.doc, id), { key: '' }); }
  /* 文中に文字として残った Markdown の **…** を太字に、対にならない ** を消す（選択範囲の行、無ければ文書全体）。コードの行・コードの字は触らない。戻り値：直した数 */
  countMdStars(from = 0, to = this.doc.lines.length - 1) { let n = 0; for (let i = from; i <= to; i++) { const ln = this.doc.lines[i]; if (ln.attrs.code) continue; for (const sg of ln.segs) { const m = sg.text.match(/\*\*/g); if (m) n += m.length; } } return n; }
  cleanMdStars() { const s = this.sel(); const [a, b] = s ? [s.a.line, s.b.line] : [0, this.doc.lines.length - 1]; if (!this.countMdStars(a, b)) return 0; let n = 0;
    this.mutate('', () => { for (let i = a; i <= b; i++) { const ln = this.doc.lines[i]; if (ln.attrs.code) continue;
      for (const sg of ln.segs) { const isCode = q => (sg.marks[q] & M.CODE) !== 0; const pairs = []; const re = /\*\*(?=[^*\s　])([^*]*?[^*\s　])\*\*/g; let m; while ((m = re.exec(sg.text))) { if (isCode(m.index)) continue; pairs.push([m.index, m.index + m[0].length]); }
        for (let k = pairs.length - 1; k >= 0; k--) { const [p0, p1] = pairs[k]; for (let q = p0 + 2; q < p1 - 2; q++) if (!isCode(q)) sg.marks[q] |= M.BOLD; this.spliceSeg(sg, p1 - 2, p1, '', []); this.spliceSeg(sg, p0, p0 + 2, '', []); n++; }
        const stray = []; const re2 = /\*{2,}/g; while ((m = re2.exec(sg.text))) if (!isCode(m.index)) stray.push([m.index, m.index + m[0].length]); for (let k = stray.length - 1; k >= 0; k--) { this.spliceSeg(sg, stray[k][0], stray[k][1], '', []); n++; } } }
      this.anchor = null; this.clampCaret(); }); return n; }
  addHRule(line, from, to, kind = 'thin', dir) { if (to <= from) return; const r = { id: FZ.uid(), axis: 'h', line, from, to, kind }; if (kind === 'arrow') r.dir = dir || 'r'; this.doc.rules.push(r); this.coalesce(); return r.id; }
  addVRule(from, to, col, kind = 'thin', dir) { if (to < from) return; const r = { id: FZ.uid(), axis: 'v', from, to, col, kind }; if (kind === 'arrow') r.dir = dir || 'd'; this.doc.rules.push(r); this.coalesce(); this.normalizeSegs(); return r.id; }
  coalesce() {
    let changed = true; const R = this.doc.rules;
    while (changed) { changed = false; outer: for (let i = 0; i < R.length; i++) for (let j = i + 1; j < R.length; j++) { const a = R[i], b = R[j]; if (a.axis !== b.axis || a.kind !== b.kind) continue;
      if (a.axis === 'h' && a.line === b.line && a.from <= b.to && b.from <= a.to) { a.from = Math.min(a.from, b.from); a.to = Math.max(a.to, b.to); if (b.dir) a.dir = b.dir; a.id = b.id; R.splice(j, 1); changed = true; break outer; }
      if (a.axis === 'v' && a.col === b.col && a.from <= b.to + 1 && b.from <= a.to + 1) { a.from = Math.min(a.from, b.from); a.to = Math.max(a.to, b.to); if (b.dir) a.dir = b.dir; a.id = b.id; R.splice(j, 1); changed = true; break outer; } } }
    // 同じ位置に異なる線種：後勝ち（重なった範囲を前から削る）
    for (let i = 0; i < R.length; i++) for (let j = 0; j < R.length; j++) { if (i === j) continue; const a = R[i], b = R[j]; if (a.axis !== b.axis || a.kind === b.kind) continue; if (a.axis === 'h' && a.line === b.line && a.from < b.to && b.from < a.to && j > i) this.cutH(a, b.from, b.to); if (a.axis === 'v' && a.col === b.col && a.from <= b.to && b.from <= a.to && j > i) this.cutV(a, b.from, b.to); }
    this.doc.rules = this.doc.rules.filter(r => r.axis === 'h' ? r.to > r.from : r.to >= r.from);
  }
  cutH(r, from, to) { // r から [from,to) を取り除く
    const R = this.doc.rules; if (from <= r.from && to >= r.to) { r.to = r.from; return; }
    if (from > r.from && to < r.to) { R.push({ ...r, id: FZ.uid(), from: to }); r.to = from; return; }
    if (from <= r.from) r.from = Math.max(r.from, to); else r.to = Math.min(r.to, from);
  }
  cutV(r, from, to) { const R = this.doc.rules; if (from <= r.from && to >= r.to) { r.to = r.from - 1; return; } if (from > r.from && to < r.to) { R.push({ ...r, id: FZ.uid(), from: to + 1 }); r.to = from - 1; return; } if (from <= r.from) r.from = to + 1; else r.to = from - 1; }
  eraseH(line, from, to) { for (const r of this.doc.rules) if (r.axis === 'h' && r.line === line) this.cutH(r, from, to); this.doc.rules = this.doc.rules.filter(r => r.axis === 'h' ? r.to > r.from : r.to >= r.from); }
  eraseV(from, to, col) { for (const r of this.doc.rules) if (r.axis === 'v' && r.col === col) this.cutV(r, from, to); this.doc.rules = this.doc.rules.filter(r => r.axis === 'h' ? r.to > r.from : r.to >= r.from); this.normalizeSegs(); }
  eraseRuleById(id) { this.mutate('', () => { this.doc.rules = this.doc.rules.filter(r => r.id !== id); this.normalizeSegs(); }); }
  /* 物理座標の単位区間を論理行へ：横線は行 y の上辺、縦線は行 y を含む論理行 */
  hAnchorAt(page, y) { const p = this.lay.pages[page]; if (!p) return null; const es = p.rowmap.get(y); if (es && es.length) { const e = es[0]; if (e.k !== 0) return null; return e.line; } const end = this.lay.endPos; if (page === end.page && y === end.y) return this.doc.lines.length; return null; }
  vAnchorAt(page, y) { const p = this.lay.pages[page]; if (!p) return null; const es = p.rowmap.get(y); if (es && es.length) return es[0].line; return null; }
  insertTable(cols, rows, widths, header, kind = 'thin') {
    const c = this.caret;
    this.mutate('', () => {
      this.anchor = null; this.materialize(); let at = c.line; const ln = this.line();
      if (ln.segs[0].text || ln.segs.length > 1 || FZ.inTable(this.doc, at)) { at = c.line + 1; }
      const bounds = [0]; let x = 0; for (let k = 0; k < cols; k++) { x += widths[k]; bounds.push(x); }
      for (let r = 0; r < rows; r++) this.insertLine(at + r, { segs: bounds.slice(0, -1).map(b => FZ.newSeg(b, '')), attrs: { cells: true } });
      if (at + rows >= this.doc.lines.length || FZ.inTable(this.doc, at + rows)) this.insertLine(at + rows, FZ.newLine());
      for (let r = at; r <= at + rows; r++) this.addHRule(r, 0, bounds[cols], kind);
      for (const b of bounds) this.addVRule(at, at + rows - 1, b, kind);
      if (header) this.doc.fills.push({ id: FZ.uid(), col: 0, cols: bounds[cols], from: at, to: at, shade: 'gray' });
      c.line = at; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0;
    });
  }
  /* ---------- 網掛け ---------- */
  addFill(from, to, col, cols, shade) { this.mutate('', () => { if (shade === 'none') { this.removeFillRect(from, to, col, cols); return; } this.removeFillRect(from, to, col, cols); this.doc.fills.push({ id: FZ.uid(), from, to, col, cols, shade }); }); }
  removeFillRect(from, to, col, cols) { const keep = []; for (const f of this.doc.fills) { const ov = !(f.to < from || f.from > to || f.col + f.cols <= col || f.col >= col + cols); if (!ov) { keep.push(f); continue; } if (f.from < from) keep.push({ ...f, id: FZ.uid(), to: from - 1 }); if (f.to > to) keep.push({ ...f, id: FZ.uid(), from: to + 1 }); const y1 = Math.max(f.from, from), y2 = Math.min(f.to, to); if (f.col < col) keep.push({ ...f, id: FZ.uid(), from: y1, to: y2, cols: col - f.col }); if (f.col + f.cols > col + cols) keep.push({ ...f, id: FZ.uid(), from: y1, to: y2, col: col + cols, cols: f.col + f.cols - col - cols }); } this.doc.fills = keep; }
  /* ---------- 移動 ---------- */
  xy(p = this.caret) { if (p.vrow > 0) { const e = this.lay.endPos; const geo = this.lay.geo; const y = Math.min(e.y + p.vrow - 1, (geo.draft ? Infinity : geo.rows - 1)); return { page: e.page, y: Math.max(0, y), h: 1, col: p.vcol ?? 0 }; } return FZ.posToXY(this.lay, p); }
  moveH(dir, extend) {
    const c = this.caret, seg = this.seg(); const ln = this.line();
    if (c.vrow > 0 || c.vcol != null) { const xy = this.xy(); const right = this.boundRight(); if (dir > 0) { if (xy.col + 0.5 < right) { c.vcol = half((c.vcol ?? xy.col) + 0.5); } else if (c.vrow > 0) { c.vrow++; c.vcol = 0; } else { this.moveToLineStart(c.line + 1); } } else { c.vcol = half((c.vcol ?? xy.col) - 0.5); const e = this.xy({ ...c, vcol: null }); if (c.vrow === 0 && e && c.vcol <= e.col) c.vcol = null; if (c.vrow > 0 && c.vcol < 0) c.vcol = 0; } if (!extend) this.anchor = null; this.goal = null; this.onCaret(); return; }
    if (extend && !this.anchor) this.anchor = { line: c.line, seg: c.seg, off: c.off }; if (!extend) this.anchor = null;
    const gs = G(seg.text);
    if (dir > 0) { if (c.off < seg.text.length) { const g = gs.find(g => g.start === c.off) || gs.find(g => g.start < c.off && g.end > c.off); c.off = g.end; } else if (c.seg < ln.segs.length - 1) { c.seg++; c.off = 0; } else { this.moveToLineStart(c.line + 1); } }
    else { if (c.off > 0) { const g = gs.find(g => g.end === c.off) || gs.find(g => g.start < c.off && g.end >= c.off); c.off = g.start; } else if (c.seg > 0) { c.seg--; c.off = this.seg().text.length; } else if (c.line > 0) { c.line--; const l2 = this.line(); c.seg = l2.segs.length - 1; c.off = l2.segs[c.seg].text.length; } }
    this.goal = null; this.onCaret();
  }
  boundRight() { const c = this.caret; if (c.vrow > 0) return this.lay.geo.bodyCols; const xy = FZ.posToXY(this.lay, { ...c, vcol: null }); return xy ? xy.row.right : this.lay.geo.cols; }
  moveToLineStart(i) { const c = this.caret; if (i >= this.doc.lines.length) { if (c.vrow > 0) { c.vrow++; c.vcol = 0; } else { c.vcol = null; } return; } c.line = i; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; }
  moveV(dir, extend) {
    const c = this.caret; const xy = this.xy(); if (!xy) return;
    if (extend && !this.anchor) this.anchor = { line: c.line, seg: c.seg, off: c.off }; if (!extend) this.anchor = null;
    const goal = this.goal ?? xy.col; this.goal = goal;
    let page = xy.page, y = xy.y + (dir > 0 ? xy.h : -1);
    const ROWS = this.lay.geo.rows; const HY = this.lay.headY; const hasHead = p => HY != null && this.lay.pages[p] && this.lay.pages[p].rowmap.has(HY); // 柱に引き上げた表題の行（資料書式）
    const go = (pg, yy, free = true) => { const pos = FZ.xyToPos(this.lay, pg, yy, goal); if (!pos) return; c.line = pos.line; c.seg = pos.seg; c.off = pos.off; c.vcol = free ? pos.vcol : null; c.vrow = 0; this.onCaret(); };
    if (xy.y < 0 && dir > 0) { this.goal = null; /* 柱の題（1.5 倍）から本文へは、文字のある所まで（自由カーソルにしない） */ const f = this.findRow(page, 0, 1); if (f) { go(f.page, f.y, false); return; } if (page + 1 < this.lay.pages.length) { if (hasHead(page + 1)) { go(page + 1, HY); return; } const f2 = this.findRow(page + 1, 0, 1); if (f2) go(f2.page, f2.y, false); } return; }
    if (xy.y >= 0 && y < 0 && hasHead(page)) { go(page, HY); return; }
    if (xy.y < 0 && dir < 0 && page > 0) { const f = this.findRow(page - 1, ROWS - 1, -1); if (f) go(f.page, f.y); else if (hasHead(page - 1)) go(page - 1, HY); return; }
    if (y >= ROWS && dir > 0 && hasHead(page + 1)) { go(page + 1, HY); return; }
    if (y < 0) { if (page === 0) { c.line = 0; c.seg = 0; c.off = 0; c.vcol = null; c.vrow = 0; this.onCaret(); return; } page--; y = ROWS - 1; }
    if (y >= ROWS) { if (page >= this.lay.pages.length - 1) return; page++; y = 0; }
    // 下方向で空き：仮想行
    let found = this.findRow(page, y, dir);
    if (!found && dir > 0 && page < this.lay.endPos.page) { if (hasHead(page + 1)) { go(page + 1, HY); return; } found = this.findRow(page + 1, 0, 1); } // 改頁などでページの下が空いている：次のページの頭へ
    if (!found) { if (dir > 0) { const e = this.lay.endPos; if ((page === e.page && y >= e.y) || page > e.page) { const vr = (page === e.page) ? y - e.y + 1 : 0; if (vr > 0 && (this.lay.geo.draft || e.y + vr - 1 < ROWS)) { c.line = this.doc.lines.length - 1; c.seg = 0; c.off = this.seg().text.length; c.vrow = vr; c.vcol = goal; this.onCaret(); } } } return; }
    const pos = FZ.xyToPos(this.lay, found.page, found.y, goal); if (!pos) return;
    c.line = pos.line; c.seg = pos.seg; c.off = pos.off; c.vcol = pos.vcol; c.vrow = 0; this.onCaret();
  }
  findRow(page, y, dir) { // y にある行が無ければ dir 方向に探す（ページ内）
    const p = this.lay.pages[page]; if (!p) return null; const ROWS = this.lay.geo.rows;
    for (let yy = y; yy >= 0 && yy < ROWS; yy += dir) { if (p.rowmap.has(yy)) return { page, y: yy }; if (this.lay.geo.draft && yy > this.lay.endPos.y + 2) break; }
    return null;
  }
  home(extend) { const c = this.caret; const xy = this.xy(); if (!xy || !xy.row) { c.vcol = null; c.off = 0; } else { if (extend && !this.anchor) this.anchor = { line: c.line, seg: c.seg, off: c.off }; if (!extend) this.anchor = null; c.off = xy.row.startOff; c.vcol = null; } this.goal = null; this.onCaret(); }
  end(extend) { const c = this.caret; const xy = this.xy(); if (!xy || !xy.row) { c.vcol = null; } else { if (extend && !this.anchor) this.anchor = { line: c.line, seg: c.seg, off: c.off }; if (!extend) this.anchor = null; c.off = xy.row.endOff; c.vcol = null; } this.goal = null; this.onCaret(); }
  docStart(extend) { this.setCaret({ line: 0, seg: 0, off: 0 }, extend); }
  docEnd(extend) { const i = this.doc.lines.length - 1; const ln = this.doc.lines[i]; this.setCaret({ line: i, seg: ln.segs.length - 1, off: ln.segs[ln.segs.length - 1].text.length }, extend); }
  selectAll() { this.anchor = { line: 0, seg: 0, off: 0 }; const i = this.doc.lines.length - 1; const ln = this.doc.lines[i]; this.caret = { line: i, seg: ln.segs.length - 1, off: ln.segs[ln.segs.length - 1].text.length, vcol: null, vrow: 0 }; this.onCaret(); }
  selectWord() { const c = this.caret, seg = this.seg(); if (!seg.text) return; let ws = null; try { ws = [...new Intl.Segmenter('ja', { granularity: 'word' }).segment(seg.text)]; } catch { } let a = 0, b = seg.text.length; if (ws) { const w = ws.find(x => c.off >= x.index && c.off < x.index + x.segment.length) || ws[ws.length - 1]; a = w.index; b = w.index + w.segment.length; } this.anchor = { line: c.line, seg: c.seg, off: a }; c.off = b; c.vcol = null; this.onCaret(); }
  selectLine() { const c = this.caret, ln = this.line(); this.anchor = { line: c.line, seg: 0, off: 0 }; c.seg = ln.segs.length - 1; c.off = ln.segs[c.seg].text.length; c.vcol = null; this.onCaret(); }
  /* ---------- 検索・置換 ---------- */
  find(needle, opts = {}) {
    if (!needle) return null; const L = this.doc.lines; const fold = s => opts.ignoreCase ? s.toLowerCase() : s; const n = fold(needle);
    const start = opts.from || (this.sel() && !opts.backward ? this.sel().b : this.caret);
    const order = [];
    for (let i = 0; i < L.length; i++) L[i].segs.forEach((s, k) => order.push({ line: i, seg: k }));
    const idx = order.findIndex(o => o.line === start.line && o.seg === start.seg);
    const scan = (o, from, to) => { const t = fold(L[o.line].segs[o.seg].text); const r = opts.backward ? t.lastIndexOf(n, to) : t.indexOf(n, from); if (r >= 0 && (opts.backward ? r + n.length <= to + n.length : true)) return { line: o.line, seg: o.seg, off: r }; return null; };
    for (let step = 0; step <= order.length; step++) {
      const j = opts.backward ? (idx - step + order.length * 2) % order.length : (idx + step) % order.length; const o = order[j];
      let r;
      if (step === 0) r = opts.backward ? scan(o, 0, Math.max(0, start.off - 1 - n.length + 1)) : scan(o, start.off, 0); else r = opts.backward ? scan(o, 0, Infinity) : scan(o, 0, 0);
      if (r) { this.anchor = r; this.caret = { line: r.line, seg: r.seg, off: r.off + needle.length, vcol: null, vrow: 0 }; this.onCaret(); return r; }
    }
    return null;
  }
  replaceCurrent(needle, repl, opts = {}) { const s = this.sel(); if (!s) return false; const t = this.textOf(s); if ((opts.ignoreCase ? t.toLowerCase() : t) !== (opts.ignoreCase ? needle.toLowerCase() : needle)) return false; this.insertText(repl); return true; }
  replaceAll(needle, repl, opts = {}) { if (!needle) return 0; let n = 0; this.mutate('', () => { for (const ln of this.doc.lines) for (const s of ln.segs) { let i = 0; const fold = x => opts.ignoreCase ? x.toLowerCase() : x; while ((i = fold(s.text).indexOf(fold(needle), i)) >= 0) { const m = s.marks[i] | 0; this.spliceSeg(s, i, i + needle.length, repl, FZ.marksFor(repl, m)); i += repl.length; n++; } } }); return n; }
  /* ---------- 統計 ---------- */
  /* 文字数（空白を除く）。数えた結果はセグメントに覚えて、文字列が同じ（同じ文字列オブジェクト）なら数え直さない。巨大な文書でもキー入力ごとに全行を切り直さない */
  charCount() { let n = 0; for (const ln of this.doc.lines) for (const s of ln.segs) { const m = s._cc; if (m && m.t === s.text) { n += m.n; continue; } let c = 0; for (const ch of s.text) if (!isSpace(ch)) c++; /* 符号位置で数える（書記素の切り出しは巨大な文書で重い） */ Object.defineProperty(s, '_cc', { value: { t: s.text, n: c }, enumerable: false, writable: true, configurable: true }); n += c; } return n; }
  /* ---------- アウトライン操作 ---------- */
  /* アウトラインの深さ：表題 0、数字見出し 1〜8、記号見出し 9〜16、箇条書き 17〜24（順位 数字 ＞ 記号 ＞ 箇条書き） */
  outlineLevel(a) { return a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : a.list ? 17 + (a.list.level | 0) : 99; }
  outline() { const items = []; this.doc.lines.forEach((ln, i) => { const a = ln.attrs; const lv = this.outlineLevel(a); if (lv < 99) items.push({ line: i, level: lv, depth: a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 2 + (a.level | 0) : 3 + (a.list.level | 0), text: ln.segs.map(s => s.text).join(' ').slice(0, 40), kind: a.list ? 'list' : a.style === 'sym' ? 'sym' : 'head' }); }); return items; }
  sectionRange(i) { const a = this.doc.lines[i].attrs; const lvOf = at => this.outlineLevel(at); const lv = lvOf(a); let e = i; for (let j = i + 1; j < this.doc.lines.length; j++) { const l2 = lvOf(this.doc.lines[j].attrs); if (l2 <= lv) break; if (a.list && !this.doc.lines[j].attrs.list) break; e = j; } return [i, e]; }
  moveSection(i, dir) {
    const [a, b] = this.sectionRange(i); const L = this.doc.lines; const lvOf = at => this.outlineLevel(at); const lv = lvOf(L[i].attrs);
    if (dir < 0) { if (a === 0) return; let s = a - 1; while (s > 0 && lvOf(L[s].attrs) > lv) s--; if (lvOf(L[s].attrs) > lv) s = 0; // 直前の同じレベル以上の節の頭
      this.mutate('', () => { const at = this.moveBlock(a, b, s); this.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; this.anchor = null; });
    } else { if (b >= L.length - 1) return; const [, nb] = this.sectionRange(b + 1); let e = nb; if (lvOf(L[b + 1].attrs) > lv || lvOf(L[b + 1].attrs) === 99) e = b + 1;
      this.mutate('', () => { const at = this.moveBlock(a, b, e + 1); this.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; this.anchor = null; });
    }
  }
  /* 行の並べ替え：order＝新しい並びの元の行番号（全行の順列）。罫・網は行に付いたまま一緒に動く。
   * 横罫は「行 L の上」か「行 L-1 の下」（その位置で縦罫が終わる＝表・囲みの下辺）に付けて動かす。縦罫・網は行ごとに写して、続く行どうしをまとめ直す */
  reorderLines(order) {
    const d = this.doc, N = d.lines.length; if (order.length !== N) return null; const newIdx = new Array(N); order.forEach((o, k) => { newIdx[o] = k; });
    const ends = []; for (const r of d.rules) if (r.axis === 'v') ends.push(r);
    const runs = (rows, mk) => { const out = []; rows.sort((x, y) => x - y); let s0 = null, p = null; for (const y of rows) { if (s0 != null && y === p + 1) { p = y; continue; } if (s0 != null) out.push(mk(s0, p)); s0 = p = y; } if (s0 != null) out.push(mk(s0, p)); return out; };
    const rules = [];
    for (const r of d.rules) {
      if (r.axis === 'h') { const L = r.line; const bottom = L > 0 && (L >= N || ends.some(v => v.to === L - 1 && v.col >= r.from - 1e-6 && v.col <= r.to + 1e-6));
        const nl = bottom ? newIdx[Math.min(L, N) - 1] + 1 : newIdx[L]; rules.push({ ...r, line: nl }); continue; }
      const rows = []; for (let y = Math.max(0, r.from); y <= Math.min(N - 1, r.to); y++) rows.push(newIdx[y]);
      for (const x of runs(rows, (a, b) => ({ ...r, id: FZ.uid(), from: a, to: b }))) rules.push(x);
    }
    const fills = []; for (const f of d.fills) { const rows = []; for (let y = Math.max(0, f.from); y <= Math.min(N - 1, f.to); y++) rows.push(newIdx[y]); for (const x of runs(rows, (a, b) => ({ ...f, id: FZ.uid(), from: a, to: b }))) fills.push(x); }
    d.lines = order.map(o => d.lines[o]); d.rules = rules; d.fills = fills; this.dedupeRules(); this.normalizeSegs();
    return newIdx;
  }
  /* 行の塊 [a,b] を at（元の行番号。その行の前へ。行数なら末尾）へ動かす。動いた先頭の新しい行番号を返す */
  moveBlock(a, b, at) { const N = this.doc.lines.length; if (at >= a && at <= b + 1) return a; const idx = [...Array(N).keys()]; const block = idx.slice(a, b + 1); const rest = idx.filter(i => i < a || i > b); const pos = rest.indexOf(at); const order = pos < 0 ? [...rest, ...block] : [...rest.slice(0, pos), ...block, ...rest.slice(pos)]; const newIdx = this.reorderLines(order); return newIdx[a]; }
  fixRulesAfterReorder() { // 並べ替え後は罫線の整合を保証できないため、範囲外になったものだけ除去
    const n = this.doc.lines.length; this.doc.rules = this.doc.rules.filter(r => r.axis === 'h' ? r.line <= n : r.to < n); this.doc.fills = this.doc.fills.filter(f => f.to < n); this.normalizeSegs();
  }
  changeLevel(i, delta) { const a = this.doc.lines[i].attrs; this.mutate('', () => { if (a.list) a.list = { ...a.list, level: clamp((a.list.level | 0) + delta, 0, 7) }; else if (FZ.isHeading(a)) a.level = clamp((a.level | 0) + delta, 0, 7); }); }
}
FZ.Editor = Editor;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
