/* 文机 — 図ブロック（フローチャート）
 * 1 論理行が高さ h 行の「図」を占め、その中に文字入りの箱・箱をつなぐ矢印・スイムレーンを置く。
 * 座標は図の左上を原点とするマス目（x: 列、y: 行）。描画は既存の罫線・網・文字の仕組みに乗せる。
 *   attrs.figure = { h, boxes: [{ id, x, y, w, h, text, kind, shade, bold }], arrows: [{ from, to, label, kind }], lanes: { dir: 'v'|'h', items: [{ title, size }] } | null } */
(function (FZ) {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const half = v => Math.round(v * 2) / 2;
  const M = FZ.M;

  function normalizeFigure(F) {
    const f = F && typeof F === 'object' ? F : {};
    const out = { h: clamp(f.h | 0 || 8, 1, 200), boxes: [], arrows: [], lanes: null };
    const ids = new Set();
    for (const b of Array.isArray(f.boxes) ? f.boxes : []) {
      if (!b) continue; let id = b.id | 0; if (!id || ids.has(id)) { id = 1; while (ids.has(id)) id++; } ids.add(id);
      out.boxes.push({ id, x: Math.max(0, +b.x || 0), y: Math.max(0, b.y | 0), w: clamp(+b.w || 6, 2, 200), h: clamp(b.h | 0 || 3, 1, 200), text: String(b.text ?? ''), kind: ['thin', 'thick', 'double', 'dotted'].includes(b.kind) ? b.kind : 'thin', shade: b.shade && b.shade !== 'text' && FZ.SHADE_BY && FZ.SHADE_BY[b.shade] ? b.shade : null, bold: !!b.bold });
    }
    for (const a of Array.isArray(f.arrows) ? f.arrows : []) { if (!a || !ids.has(a.from | 0) || !ids.has(a.to | 0) || (a.from | 0) === (a.to | 0)) continue; out.arrows.push({ from: a.from | 0, to: a.to | 0, label: String(a.label ?? ''), kind: ['thin', 'thick', 'dotted'].includes(a.kind) ? a.kind : 'thin' }); }
    if (f.lanes && (f.lanes.dir === 'v' || f.lanes.dir === 'h') && Array.isArray(f.lanes.items) && f.lanes.items.length) out.lanes = { dir: f.lanes.dir, items: f.lanes.items.map(it => ({ title: String((it && it.title) ?? ''), size: Math.max(0, +(it && it.size) || 0) })) };
    return out;
  }
  FZ.normalizeFigure = normalizeFigure;
  const box = (F, id) => F.boxes.find(b => b.id === id);
  FZ.figureBox = box;

  /* レーンの帯：{ dir, titleBand, bands: [{ from, to, title }] }（図の座標系） */
  function laneGeom(F, W, H) {
    const L = F.lanes; if (!L) return null;
    const total = L.dir === 'v' ? W : H; const given = L.items.reduce((t, it) => t + (it.size || 0), 0);
    let sizes = L.items.map(it => it.size || 0);
    if (!given || Math.abs(given - total) > 1e-6) { const n = L.items.length, base = Math.floor(total / n); sizes = L.items.map((_, k) => k === n - 1 ? total - base * (n - 1) : base); }
    const bands = []; let at = 0; L.items.forEach((it, k) => { bands.push({ from: at, to: at + sizes[k], title: it.title }); at += sizes[k]; });
    return { dir: L.dir, titleBand: L.dir === 'v' ? 1 : 2, bands };
  }
  FZ.laneGeom = laneGeom;

  /* 文字列を幅 w マスで貪欲に折り返す（簡易：禁則なし） */
  function wrapText(text, w) {
    const rows = []; let cur = '', cw = 0;
    for (const g of FZ.graphemes(text)) { const gw = FZ.textWidth(g.text); if (g.text === '\n') { rows.push(cur); cur = ''; cw = 0; continue; } if (cw + gw > w + 1e-6 && cur) { rows.push(cur); cur = ''; cw = 0; } cur += g.text; cw += gw; }
    rows.push(cur); return rows;
  }
  function centeredGlyphs(text, left, width, dy, marks, out, line) {
    const tw = FZ.textWidth(text); let col = half(left + (width - tw) / 2);
    for (const g of FZ.graphemes(text)) { const w = FZ.textWidth(g.text); if (!/^[\s　]$/.test(g.text)) out.push({ text: g.text, col, w, marks, dy, fig: true }); col += w; }
  }

  /* 矢印の経路：直交する 1〜3 区間。[{ kind: 'h', y, from, to, dir } | { kind: 'v', col, y1, y2, dir }]（最後の区間に矢じり） */
  function route(A, B) {
    const ax1 = A.x, ax2 = A.x + A.w, ay1 = A.y, ay2 = A.y + A.h, acx = half(A.x + A.w / 2), acy = ay1 + A.h / 2;
    const bx1 = B.x, bx2 = B.x + B.w, by1 = B.y, by2 = B.y + B.h, bcx = half(B.x + B.w / 2), bcy = by1 + B.h / 2;
    const segs = [];
    // 横の隙間と縦の隙間のうち大きい方の向きに出る（接している箱は縦／横のもう一方で結ぶ）
    const gx = bx1 >= ax2 ? bx1 - ax2 : ax1 >= bx2 ? ax1 - bx2 : -1, gy = by1 >= ay2 ? by1 - ay2 : ay1 >= by2 ? ay1 - by2 : -1;
    const horiz = gx > gy || (gx === gy && gx > 0 && Math.abs(acy - bcy) <= Math.abs(acx - bcx));
    if (horiz && bx1 >= ax2) { // 右へ
      if (Math.abs(acy - bcy) < 1e-6) segs.push({ k: 'h', y: acy, from: ax2, to: bx1, dir: 'r' });
      else { const mx = half((ax2 + bx1) / 2); segs.push({ k: 'h', y: acy, from: ax2, to: mx }, { k: 'v', col: mx, y1: Math.min(acy, bcy), y2: Math.max(acy, bcy) }, { k: 'h', y: bcy, from: mx, to: bx1, dir: 'r' }); }
    } else if (horiz && ax1 >= bx2) { // 左へ
      if (Math.abs(acy - bcy) < 1e-6) segs.push({ k: 'h', y: acy, from: bx2, to: ax1, dir: 'l' });
      else { const mx = half((bx2 + ax1) / 2); segs.push({ k: 'h', y: acy, from: mx, to: ax1 }, { k: 'v', col: mx, y1: Math.min(acy, bcy), y2: Math.max(acy, bcy) }, { k: 'h', y: bcy, from: bx2, to: mx, dir: 'l' }); }
    } else if (gy >= 0 && by1 >= ay2) { // 下へ
      if (Math.abs(acx - bcx) < 1e-6) segs.push({ k: 'v', col: acx, y1: ay2, y2: by1, dir: 'd' });
      else { const my = half((ay2 + by1) / 2); segs.push({ k: 'v', col: acx, y1: ay2, y2: my }, { k: 'h', y: my, from: Math.min(acx, bcx), to: Math.max(acx, bcx) }, { k: 'v', col: bcx, y1: my, y2: by1, dir: 'd' }); }
    } else if (gy >= 0 && ay1 >= by2) { // 上へ
      if (Math.abs(acx - bcx) < 1e-6) segs.push({ k: 'v', col: acx, y1: by2, y2: ay1, dir: 'u' });
      else { const my = half((by2 + ay1) / 2); segs.push({ k: 'v', col: acx, y1: my, y2: ay1 }, { k: 'h', y: my, from: Math.min(acx, bcx), to: Math.max(acx, bcx) }, { k: 'v', col: bcx, y1: by2, y2: my, dir: 'u' }); }
    } else { // 重なり：中心から中心へ縦に
      if (bcy >= acy) segs.push({ k: 'v', col: bcx, y1: ay2, y2: Math.max(ay2, by1), dir: 'd' }); else segs.push({ k: 'v', col: bcx, y1: Math.min(ay1, by2), y2: ay1, dir: 'u' });
    }
    const out = segs.filter(sg => sg.k === 'h' ? sg.to > sg.from : sg.y2 > sg.y1); const last = out[out.length - 1];
    if (last && !last.dir) last.dir = last.k === 'h' ? (bcx > acx ? 'r' : 'l') : (bcy > acy ? 'd' : 'u'); // 長さ 0 の区間を省いたときも矢じりは残す
    return out;
  }
  FZ.figureRoute = route;

  /* 図の描画要素（図の座標系、dy/y は図の先頭行からの行オフセット）。left/right は図の占める列範囲 */
  function figureLayout(F, left, right) {
    const W = right - left, H = F.h; const glyphs = [], hrules = [], vrules = [], fills = []; let serial = 0;
    const X = x => left + x;
    const lanes = laneGeom(F, W, H);
    if (lanes) {
      const kind = 'thin';
      hrules.push({ id: ++serial, y: 0, from: X(0), to: X(W), kind }, { id: ++serial, y: H, from: X(0), to: X(W), kind });
      vrules.push({ id: ++serial, col: X(0), y1: 0, y2: H, kind }, { id: ++serial, col: X(W), y1: 0, y2: H, kind });
      if (lanes.dir === 'v') {
        fills.push({ id: ++serial, col: X(0), cols: W, y1: 0, y2: 1, shade: 'gray' });
        hrules.push({ id: ++serial, y: 1, from: X(0), to: X(W), kind });
        lanes.bands.forEach((b, k) => { if (k > 0) vrules.push({ id: ++serial, col: X(b.from), y1: 0, y2: H, kind }); centeredGlyphs(b.title, X(b.from), b.to - b.from, 0, M.BOLD, glyphs); });
      } else {
        fills.push({ id: ++serial, col: X(0), cols: 2, y1: 0, y2: H, shade: 'gray' });
        vrules.push({ id: ++serial, col: X(2), y1: 0, y2: H, kind });
        lanes.bands.forEach((b, k) => { if (k > 0) hrules.push({ id: ++serial, y: b.from, from: X(0), to: X(W), kind }); const chars = FZ.graphemes(b.title).map(g => g.text).filter(t => !/^[\s　]$/.test(t)); const n = Math.min(chars.length, b.to - b.from); const y0 = b.from + Math.floor((b.to - b.from - n) / 2); for (let q = 0; q < n; q++) { const w = FZ.textWidth(chars[q]); glyphs.push({ text: chars[q], col: half(X(1) - w / 2), w, marks: M.BOLD, dy: y0 + q, fig: true }); } });
      }
    }
    for (const b of F.boxes) {
      const x1 = X(b.x), x2 = X(b.x + b.w), y1 = b.y, y2 = b.y + b.h;
      if (b.shade) fills.push({ id: ++serial, col: x1, cols: b.w, y1, y2, shade: b.shade });
      hrules.push({ id: ++serial, y: y1, from: x1, to: x2, kind: b.kind }, { id: ++serial, y: y2, from: x1, to: x2, kind: b.kind });
      vrules.push({ id: ++serial, col: x1, y1, y2, kind: b.kind }, { id: ++serial, col: x2, y1, y2, kind: b.kind });
      const pad = b.w >= 4 ? 1 : 0.5, iw = b.w - 2 * pad; const rows = wrapText(b.text, Math.max(0.5, iw)).slice(0, b.h);
      const y0 = y1 + Math.floor((b.h - rows.length) / 2);
      rows.forEach((t, k) => centeredGlyphs(t, x1 + pad, iw, y0 + k, b.bold ? M.BOLD : 0, glyphs));
    }
    F.arrows.forEach((a, idx) => {
      const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return;
      const segs = route(A, B); const last = segs.length - 1;
      segs.forEach((s, k) => {
        const kind = k === last ? 'arrow' : a.kind; // 最後の区間だけ矢じり
        if (s.k === 'h') hrules.push({ id: ++serial, y: s.y, from: X(s.from), to: X(s.to), kind, dir: s.dir, arrow: idx });
        else vrules.push({ id: ++serial, col: X(s.col), y1: s.y1, y2: s.y2, kind, dir: s.dir, arrow: idx });
      });
      if (a.label) { // 最長区間の脇に
        let best = segs[0], len = -1; for (const s of segs) { const l = s.k === 'h' ? s.to - s.from : s.y2 - s.y1; if (l > len) { len = l; best = s; } }
        const tw = FZ.textWidth(a.label);
        if (best.k === 'h') { const row = Math.floor(best.y) - 1 >= 0 ? Math.floor(best.y) - 1 : Math.floor(best.y) + 1; centeredGlyphs(a.label, X(best.from), best.to - best.from, row, 0, glyphs); }
        else { const row = Math.floor((best.y1 + best.y2) / 2); let col = X(best.col) + 1; for (const g of FZ.graphemes(a.label)) { const w = FZ.textWidth(g.text); glyphs.push({ text: g.text, col, w, marks: 0, dy: row, fig: true }); col += w; } }
      }
    });
    return { glyphs, hrules, vrules, fills };
  }
  FZ.figureLayout = figureLayout;

  /* 当たり判定：図の座標 (x, y) にある箱（後から描いたものを優先） */
  FZ.figureHit = function (F, x, y) { for (let k = F.boxes.length - 1; k >= 0; k--) { const b = F.boxes[k]; if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b; } return null; };
  /* 新しい箱の置き場所：選択中の箱の右（入らなければ下）、無ければ左上 */
  FZ.figureFreeSpot = function (F, W, sel, w = 8, h = 3) {
    const lanes = laneGeom(F, W, F.h); const minX = lanes && lanes.dir === 'h' ? 3 : 0, minY = lanes && lanes.dir === 'v' ? 2 : 0;
    const free = (x, y) => F.boxes.every(b => x + w <= b.x || x >= b.x + b.w || y + h <= b.y || y >= b.y + b.h);
    if (sel) { const cands = [[sel.x + sel.w + 3, sel.y], [sel.x, sel.y + sel.h + 2], [sel.x - w - 3, sel.y], [sel.x, sel.y - h - 2]]; for (const [x, y] of cands) if (x >= minX && y >= minY && x + w <= W && y + h <= F.h && free(x, y)) return { x, y }; }
    for (let y = minY; y + h <= F.h; y++) for (let x = minX; x + w <= W; x++) if (free(x, y)) return { x, y };
    return { x: minX, y: Math.max(minY, F.h - h) };
  };

  /* ---------- 画面で直接いじるための当たり判定と操作 ---------- */
  /* 矢印の当たり：点 (x, y) から各区間までの距離が tol 以内の矢印の番号（近いもの）。無ければ -1 */
  FZ.figureArrowHit = function (F, x, y, tol = 0.45) {
    let best = -1, bd = tol;
    F.arrows.forEach((a, k) => { const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return;
      for (const sg of route(A, B)) { let d; if (sg.k === 'h') { const cx = clamp(x, sg.from, sg.to); d = Math.hypot(x - cx, (y - sg.y) * 0.9); } else { const cy = clamp(y, sg.y1, sg.y2); d = Math.hypot(x - sg.col, (y - cy) * 0.9); } if (d <= bd) { bd = d; best = k; } } });
    return best;
  };
  /* 矢印のラベルの置き場所（図の座標）：最長区間の中ほど */
  FZ.figureArrowMid = function (F, k) { const a = F.arrows[k]; if (!a) return null; const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return null; let best = null, len = -1; for (const s of route(A, B)) { const l = s.k === 'h' ? s.to - s.from : s.y2 - s.y1; if (l > len) { len = l; best = s; } } if (!best) return null; return best.k === 'h' ? { x: (best.from + best.to) / 2, y: best.y, horiz: true } : { x: best.col, y: (best.y1 + best.y2) / 2, horiz: false }; };
  /* 大きさを変えるつまみ（四隅と辺の中ほど）と、矢印を引き出す点（辺の中ほどの外側） */
  FZ.figureHandles = b => [['nw', b.x, b.y], ['n', b.x + b.w / 2, b.y], ['ne', b.x + b.w, b.y], ['e', b.x + b.w, b.y + b.h / 2], ['se', b.x + b.w, b.y + b.h], ['s', b.x + b.w / 2, b.y + b.h], ['sw', b.x, b.y + b.h], ['w', b.x, b.y + b.h / 2]].map(([id, x, y]) => ({ id, x, y }));
  FZ.figurePorts = b => [['n', b.x + b.w / 2, b.y - 0.55], ['e', b.x + b.w + 0.7, b.y + b.h / 2], ['s', b.x + b.w / 2, b.y + b.h + 0.55], ['w', b.x - 0.7, b.y + b.h / 2]].map(([id, x, y]) => ({ id, x, y }));
  /* つまみ id でドラッグしたときの新しい箱（元の箱 o、つまみの移動 dx, dy）。幅は 0.5 刻み・2 以上、高さは 1 刻み・1 以上、図の中に収める */
  FZ.figureResize = function (o, id, dx, dy, W, H) {
    let x1 = o.x, y1 = o.y, x2 = o.x + o.w, y2 = o.y + o.h;
    if (id.includes('w')) x1 = clamp(half(o.x + dx), 0, x2 - 2); if (id.includes('e')) x2 = clamp(half(x2 + dx), x1 + 2, W);
    if (id.includes('n')) y1 = clamp(Math.round(o.y + dy), 0, y2 - 1); if (id.includes('s')) y2 = clamp(Math.round(y2 + dy), y1 + 1, H);
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  };
  /* 揃える・等間隔：ids の箱を mode（left|center|right|top|middle|bottom|dh|dv）で */
  FZ.figureAlign = function (F, ids, mode) {
    const bs = ids.map(id => box(F, id)).filter(Boolean); if (bs.length < 2) return false;
    const L = Math.min(...bs.map(b => b.x)), R = Math.max(...bs.map(b => b.x + b.w)), T = Math.min(...bs.map(b => b.y)), Bt = Math.max(...bs.map(b => b.y + b.h));
    if (mode === 'left') for (const b of bs) b.x = L; else if (mode === 'right') for (const b of bs) b.x = half(R - b.w); else if (mode === 'center') { const c = (L + R) / 2; for (const b of bs) b.x = Math.max(0, half(c - b.w / 2)); }
    else if (mode === 'top') for (const b of bs) b.y = T; else if (mode === 'bottom') for (const b of bs) b.y = Math.max(0, Bt - b.h); else if (mode === 'middle') { const c = (T + Bt) / 2; for (const b of bs) b.y = Math.max(0, Math.round(c - b.h / 2)); }
    else if (mode === 'dh' || mode === 'dv') { if (bs.length < 3) return false; const h = mode === 'dh'; const s = bs.slice().sort((p, q) => h ? p.x - q.x : p.y - q.y); const total = s.reduce((t, b) => t + (h ? b.w : b.h), 0); const span = h ? R - L : Bt - T; const gap = (span - total) / (s.length - 1); let at = h ? L : T; for (const b of s) { if (h) { b.x = half(at); at += b.w + gap; } else { b.y = Math.round(at); at += b.h + gap; } } }
    else return false;
    return true;
  };
  /* 複製：ids の箱を写して右下へずらす（写した箱の間の矢印も写す）。新しい id の配列を返す */
  FZ.figureDuplicate = function (F, ids, W) {
    const src = ids.map(id => box(F, id)).filter(Boolean); if (!src.length) return []; let next = F.boxes.reduce((m, b) => Math.max(m, b.id), 0); const map = new Map(); const out = [];
    for (const b of src) { const nb = { ...b, id: ++next, x: clamp(b.x + 2, 0, Math.max(0, W - b.w)), y: b.y + 1 }; map.set(b.id, nb.id); F.boxes.push(nb); out.push(nb.id); if (nb.y + nb.h > F.h) F.h = nb.y + nb.h; }
    for (const a of F.arrows.slice()) if (map.has(a.from) && map.has(a.to)) F.arrows.push({ ...a, from: map.get(a.from), to: map.get(a.to) });
    return out;
  };
  /* ---------- Mermaid flowchart との往復（生成 AI との受け渡し） ---------- */
  FZ.figureToMermaid = function (F, W) {
    const lanes = laneGeom(F, W, F.h); const spreadX = Math.max(0, ...F.boxes.map(b => b.x + b.w)), spreadY = Math.max(0, ...F.boxes.map(b => b.y + b.h));
    const dir = lanes ? (lanes.dir === 'v' ? 'LR' : 'TD') : (spreadX >= spreadY * 2.5 ? 'LR' : 'TD');
    const L = ['flowchart ' + dir]; const q = t => '"' + String(t).replace(/"/g, '#quot;').replace(/\n/g, ' ') + '"';
    const node = b => 'b' + b.id + '[' + q(b.text || ' ') + ']';
    if (lanes) {
      lanes.bands.forEach((band, k) => { L.push('  subgraph L' + (k + 1) + '[' + q(band.title || ('レーン' + (k + 1))) + ']'); for (const b of F.boxes) { const c = lanes.dir === 'v' ? b.x + b.w / 2 : b.y + b.h / 2; if (c >= band.from && c < band.to) L.push('    ' + node(b)); } L.push('  end'); });
      for (const b of F.boxes) { const inAny = lanes.bands.some(band => { const c = lanes.dir === 'v' ? b.x + b.w / 2 : b.y + b.h / 2; return c >= band.from && c < band.to; }); if (!inAny) L.push('  ' + node(b)); }
    } else for (const b of F.boxes) L.push('  ' + node(b));
    for (const a of F.arrows) L.push('  b' + a.from + (a.kind === 'dotted' ? ' -.->' : a.kind === 'thick' ? ' ==>' : ' -->') + (a.label ? '|' + q(a.label) + '|' : '') + ' b' + a.to);
    return L;
  };
  FZ.figureFromMermaid = function (text, W) {
    const lines = String(text).split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('%%'));
    if (!lines.length || !/^(flowchart|graph)\b/i.test(lines[0])) return null;
    const dirTok = (lines[0].match(/^(?:flowchart|graph)\s+(\w+)/i) || [])[1] || 'TD'; const LR = /^(LR|RL)$/i.test(dirTok);
    const nodes = new Map(), order = [], edges = [], groups = []; let cur = null;
    const unq = t => t.replace(/^"|"$/g, '').replace(/#quot;/g, '"').replace(/<br\s*\/?>/gi, '\n');
    const NODE = /^([A-Za-z0-9_\u3040-\u30ff\u4e00-\u9fff]+)\s*(?:\[\[([^\]]*)\]\]|\[\(([^)]*)\)\]|\(\(([^)]*)\)\)|\[([^\]]*)\]|\(([^)]*)\)|\{\{([^}]*)\}\}|\{([^}]*)\}|>([^\]]*)\]|\[\/([^\]]*)\/\])?$/;
    const touch = (tok) => { const m = tok.trim().match(NODE); if (!m) return null; const id = m[1]; const label = m.slice(2).find(x => x != null); if (!nodes.has(id)) { nodes.set(id, { id, text: label != null ? unq(label) : id, shape: /\{/.test(tok) ? 'decision' : /\(\(/.test(tok) ? 'round' : 'rect' }); order.push(id); if (cur) cur.push(id); } else if (label != null) nodes.get(id).text = unq(label); return id; };
    for (let k = 1; k < lines.length; k++) {
      let l = lines[k];
      if (/^subgraph\b/i.test(l)) { const m = l.match(/^subgraph\s+(?:([^\[\s]+)\s*)?(?:\[([^\]]*)\])?\s*(.*)$/i); const title = unq((m && (m[2] || m[3] || m[1])) || ''); cur = []; cur.title = title; groups.push(cur); continue; }
      if (/^end$/i.test(l)) { cur = null; continue; }
      if (/^(classDef|class|style|linkStyle|click|direction)\b/i.test(l)) continue;
      l = l.replace(/--\s*([^-|>]+?)\s*-->/g, '-->|$1|').replace(/-\.\s*([^-.|>]+?)\s*\.->/g, '-.->|$1|').replace(/==\s*([^=|>]+?)\s*==>/g, '==>|$1|');
      const parts = l.split(/\s*(-{2,}>|<-{2,}|-{3,}|-\.+->|\.-+>|={2,}>|={3,})\s*(?:\|([^|]*)\|)?\s*/);
      if (parts.length === 1) { for (const t of l.split(/\s*&\s*/)) touch(t); continue; }
      let prev = parts[0].split(/\s*&\s*/).map(touch).filter(Boolean);
      for (let p = 1; p < parts.length; p += 3) { const op = parts[p], label = parts[p + 1] != null ? unq(parts[p + 1]) : '', right = (parts[p + 2] || '').split(/\s*&\s*/).map(touch).filter(Boolean); const kind = /\./.test(op) ? 'dotted' : /=/.test(op) ? 'thick' : 'thin'; const headed = />/.test(op); for (const a of prev) for (const b of right) if (a !== b) edges.push(/^</.test(op) ? { from: b, to: a, label, kind } : { from: a, to: b, label, kind, headed }); prev = right; }
    }
    if (!order.length) return null;
    const idOf = new Map(order.map((id, k) => [id, k + 1]));
    const tw = id => Math.max(2, FZ.textWidth(nodes.get(id).text.split('\n').reduce((a, b) => FZ.textWidth(b) > FZ.textWidth(a) ? b : a, '')));
    const boxes = []; let h = 1;
    const mk = (id, x, y, w, bh) => { const n = nodes.get(id); boxes.push({ id: idOf.get(id), x, y, w, h: bh, text: n.text, kind: n.shape === 'decision' ? 'double' : 'thin', shade: n.shape === 'round' ? 'gray' : null, bold: false }); };
    let lanes = null;
    if (groups.length) { // サブグラフ → 縦レーン。各レーンの中で上から並べる
      const n = groups.length, lw = Math.floor(W / n); const inGroup = new Set(groups.flat());
      groups.forEach((g, k) => { const x0 = k * lw + 1, w = Math.max(4, lw - 2); g.forEach((id, j) => { const bh = Math.max(3, Math.ceil(tw(id) / Math.max(1, w - 2)) + 2); mk(id, x0, 2 + j * 5, w, bh); h = Math.max(h, 2 + j * 5 + bh + 1); }); });
      let extra = 0; for (const id of order) if (!inGroup.has(id)) { mk(id, 1, h + extra * 5, Math.max(6, Math.min(W - 2, tw(id) + 2)), 3); extra++; } if (extra) h += extra * 5;
      lanes = { dir: 'v', items: groups.map(g => ({ title: g.title || '', size: 0 })) };
    } else {
      const w = Math.max(6, Math.min(14, Math.max(...order.map(tw)) + 2)), gap = LR ? 4 : 3, perRow = Math.max(1, Math.floor((W + gap) / (w + gap)));
      order.forEach((id, k) => { const col = LR ? k % perRow : 0, row = LR ? Math.floor(k / perRow) : k; const bh = Math.max(3, Math.ceil(tw(id) / Math.max(1, w - 2)) + 2); const x = LR ? col * (w + gap) : Math.max(0, Math.floor((W - w) / 2)); const y = LR ? 1 + row * 6 : 1 + row * (3 + 2); mk(id, x, y, w, bh); h = Math.max(h, y + bh + 1); });
    }
    const arrows = edges.map(e => ({ from: idOf.get(e.from), to: idOf.get(e.to), label: e.label || '', kind: e.kind })).filter(a => a.from && a.to);
    return normalizeFigure({ h, boxes, arrows, lanes });
  };
  /* ---------- 原本形式（指示行） ---------- */
  const KN = { thin: '細', thick: '太', double: '二重', dotted: '点線' }, KK = { 細: 'thin', 太: 'thick', 二重: 'double', 点線: 'dotted' };
  const SN = FZ.SHADE_NAMES || { gray: '薄', dark: '濃', hatch: '斜線', dots: '点' }, SK = Object.assign({ 無: null }, FZ.SHADE_KEYS || { 薄: 'gray', 濃: 'dark', 斜線: 'hatch', 点: 'dots' });
  const escT = t => String(t).replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
  const unescT = t => String(t).replace(/\\n/g, '\n').replace(/\\\\/g, '\\');
  FZ.figureToLines = function (F) {
    const L = [];
    if (F.lanes) L.push('#レーン ' + (F.lanes.dir === 'v' ? '縦' : '横') + ' ' + F.lanes.items.map(it => it.size || 0).join(',') + ' ' + F.lanes.items.map(it => it.title.replace(/\|/g, '｜')).join('|'));
    for (const b of F.boxes) L.push('#箱 ' + b.id + ' ' + b.x + ',' + b.y + ' ' + b.w + 'x' + b.h + ' ' + (KN[b.kind] || '細') + ' ' + (SN[b.shade] || '無') + (b.bold ? '太字' : '') + ' ' + escT(b.text));
    for (const a of F.arrows) L.push('#矢印 ' + a.from + '→' + a.to + ' ' + (KN[a.kind] || '細') + (a.label ? ' ' + escT(a.label) : ''));
    return L;
  };
  /* 指示行 1 本を解釈して pending の図に加える。該当しなければ false */
  FZ.figureDirective = function (raw, fig) {
    let m;
    if ((m = raw.match(/^#箱\s+(\d+)\s+(\d+(?:\.5)?),(\d+)\s+(\d+(?:\.5)?)x(\d+)\s+(\S+)\s+(\S+)(?:\s(.*))?$/))) { const shadeTok = m[7].replace(/太字$/, ''); fig.boxes.push({ id: +m[1], x: +m[2], y: +m[3], w: +m[4], h: +m[5], kind: KK[m[6]] || 'thin', shade: SK[shadeTok] ?? null, bold: /太字$/.test(m[7]), text: unescT(m[8] || '') }); return true; }
    if ((m = raw.match(/^#矢印\s+(\d+)→(\d+)(?:\s+(\S+))?(?:\s(.*))?$/))) { fig.arrows.push({ from: +m[1], to: +m[2], kind: KK[m[3]] || 'thin', label: unescT(m[4] || '') }); return true; }
    if ((m = raw.match(/^#レーン\s+(縦|横)\s+(\S*)\s*(.*)$/))) { const sizes = m[2].split(',').map(Number); const titles = m[3].split('|'); fig.lanes = { dir: m[1] === '縦' ? 'v' : 'h', items: titles.map((t, k) => ({ title: t, size: sizes[k] || 0 })) }; return true; }
    return false;
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
