/* 文机 ファイル入出力：Tauri → File System Access API → 旧来（input/download）の順に対応 */
(function (FZ) {
'use strict';
const FILTERS = [{ name: '文机の原本', extensions: ['fzk', 'txt', 'md', 'json'] }];
const ACCEPT = { description: '文机の原本', accept: { 'text/plain': ['.fzk', '.txt', '.md', '.json'] } };
const tauri = () => globalThis.__TAURI__ || null;
const host = () => (globalThis.fzHost && typeof globalThis.fzOpenFile === 'function') ? globalThis : null; // Go + WebView2 の単一 exe 版
const hasFSA = typeof window !== 'undefined' && 'showOpenFilePicker' in window;

const files = {
  kind: host() ? 'host' : tauri() ? 'tauri' : hasFSA ? 'fsa' : 'basic',
  async open() {
    if (host()) { const r = await globalThis.fzOpenFile(); if (!r) return null; return { name: r.name, path: r.path, text: r.text }; }
    if (tauri()) { const T = tauri(); const path = await T.dialog.open({ multiple: false, filters: FILTERS }); if (!path) return null; const text = await T.fs.readTextFile(path); return { name: baseName(path), path, text }; }
    if (hasFSA) { try { const [h] = await window.showOpenFilePicker({ types: [ACCEPT], multiple: false }); const f = await h.getFile(); return { name: f.name, handle: h, text: await f.text() }; } catch (e) { if (e.name === 'AbortError') return null; throw e; } }
    return new Promise(res => { const inp = document.getElementById('fileInput'); inp.value = ''; inp.onchange = async () => { const f = inp.files[0]; if (!f) return res(null); res({ name: f.name, text: await f.text() }); }; inp.click(); });
  },
  async save(text, ref, suggested, opts = {}) { // ref: {handle|path} 既存参照。無ければ saveAs。opts.auto：自動保存（保存先を聞かない）
    if (ref && ref.handle && !ref.path && (host() || tauri())) { try { const w = await ref.handle.createWritable(); await w.write(text); await w.close(); return { name: ref.handle.name, handle: ref.handle }; } catch (e) { if (opts.auto) throw e; ref = null; } } // ドロップで開いたファイル：参照に書けなければ保存先を聞く
    if (host()) { let path = ref && ref.path; if (!path) { path = await globalThis.fzSaveFile(suggested || '文書.fzk'); if (!path) return null; } await globalThis.fzWriteFile(path, text); return { name: baseName(path), path }; }
    if (tauri()) { const T = tauri(); let path = ref && ref.path; if (!path) { path = await T.dialog.save({ defaultPath: suggested, filters: FILTERS }); if (!path) return null; } await T.fs.writeTextFile(path, text); return { name: baseName(path), path }; }
    if (hasFSA) { let h = ref && ref.handle; if (!h) { try { h = await window.showSaveFilePicker({ suggestedName: suggested, types: [ACCEPT] }); } catch (e) { if (e.name === 'AbortError') return null; throw e; } } const w = await h.createWritable(); await w.write(text); await w.close(); return { name: h.name, handle: h }; }
    download(text, suggested); return { name: suggested };
  },
  async saveAs(text, suggested) { return this.save(text, null, suggested); },
  /* ファイルの更新日時（ミリ秒）。分からなければ 0。外での書き換えを見つけるのに使う */
  async stamp(ref) {
    try { if (!ref) return 0;
      if (ref.handle && typeof ref.handle.getFile === 'function') { const f = await ref.handle.getFile(); return f.lastModified || 0; }
      if (ref.path && host() && typeof globalThis.fzStat === 'function') { const r = await globalThis.fzStat(ref.path); return (r && r.mtime) || 0; }
    } catch (e) { return -1; } // 消えた・動いた・読めない
    return 0;
  },
  /* 開いた（保存した）あとに文机の外で書き換えられたか：ref.mtime と今の更新日時を比べる。{ changed, mtime, gone } */
  async outside(ref) { if (!ref || !ref.mtime) return { changed: false }; const t = await this.stamp(ref); if (t === -1) return { changed: true, gone: true }; if (!t) return { changed: false }; return { changed: Math.abs(t - ref.mtime) > 1000, mtime: t }; },
  download,
};
/* text は文字列か Uint8Array（docx/pptx などのバイナリ） */
function download(text, name) {
  const bin = text instanceof Uint8Array;
  if (host()) { globalThis.fzSaveFile(name).then(p => { if (!p) return; if (bin) { if (typeof globalThis.fzWriteBinary === 'function') return globalThis.fzWriteBinary(p, toB64(text)); throw new Error('このホストはバイナリ保存に未対応です（host を再ビルドしてください）'); } return globalThis.fzWriteFile(p, text); }).catch(e => alert('保存できませんでした：' + e)); return; }
  const type = bin ? (/\.docx$/i.test(name) ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : /\.pptx$/i.test(name) ? 'application/vnd.openxmlformats-officedocument.presentationml.presentation' : 'application/octet-stream') : 'text/plain;charset=utf-8';
  const blob = new Blob([text], { type }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 20000); }
function toB64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function baseName(p) { return String(p).split(/[\\/]/).pop(); }
FZ.files = files;
})(window.FZ = window.FZ || {});
