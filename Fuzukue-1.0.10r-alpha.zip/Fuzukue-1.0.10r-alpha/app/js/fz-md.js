/* 文机 — GFM（GitHub Flavored Markdown）構文解析器
 * 仕様 https://github.github.com/gfm/ の 2 段階アルゴリズム（ブロック構造 → インライン）を自前で実装。
 * 出力は mdast 風の木（FZ.md.parse）。付属の HTML 描画（FZ.md.toHtml）は仕様例との照合試験に使う。
 * 対応：見出し（ATX／Setext）、段落、区切り線、字下げコード、囲いコード、HTML ブロック、リンク参照定義、引用、
 *       リスト（箇条・番号・タスク）、表、強調、打消し、コードスパン、リンク・画像（参照形式含む）、自動リンク（拡張含む）、
 *       生 HTML、文字参照、バックスラッシュ、ハード／ソフト改行。 */
(function (FZ) {
  'use strict';
  const C_TAB = 9, C_SPACE = 32, C_GREATERTHAN = 62, C_LESSTHAN = 60, C_OPEN_BRACKET = 91, C_CLOSE_BRACKET = 93, C_BANG = 33, C_BACKSLASH = 92, C_AMPERSAND = 38, C_OPEN_PAREN = 40, C_CLOSE_PAREN = 41, C_COLON = 58, C_SINGLEQUOTE = 39, C_DOUBLEQUOTE = 34, C_ASTERISK = 42, C_UNDERSCORE = 95, C_BACKTICK = 96, C_TILDE = 126, C_NEWLINE = 10;
  const CODE_INDENT = 4;

  /* ---------- 木 ---------- */
  class Node { // 双方向リスト（unlink／insert が O(1)）。children は配列のスナップショット
    constructor(type, pos) { this.type = type; this.parent = null; this._first = null; this._last = null; this._next = null; this._prev = null; this.pos = pos || null; this.open = true; this.lastLineBlank = false; this.lastLineChecked = false; this.strings = []; this.literal = null; }
    get firstChild() { return this._first; } get lastChild() { return this._last; } get next() { return this._next; } get prev() { return this._prev; }
    get children() { const a = []; for (let c = this._first; c; c = c._next) a.push(c); return a; }
    set children(arr) { for (let c = this._first; c; c = c._next) c.parent = null; this._first = this._last = null; for (const n of arr) { n.parent = null; n._prev = n._next = null; this.append(n); } }
    append(n) { n.unlink(); n.parent = this; n._prev = this._last; n._next = null; if (this._last) this._last._next = n; else this._first = n; this._last = n; return n; }
    insertAfter(n) { n.unlink(); n.parent = this.parent; n._prev = this; n._next = this._next; if (this._next) this._next._prev = n; else if (this.parent) this.parent._last = n; this._next = n; }
    unlink() { if (this._prev) this._prev._next = this._next; else if (this.parent) this.parent._first = this._next; if (this._next) this._next._prev = this._prev; else if (this.parent) this.parent._last = this._prev; this.parent = null; this._prev = this._next = null; }
    isContainer() { return /^(document|block_quote|list|item|paragraph|heading|emph|strong|strikethrough|link|image|table|table_row|table_cell)$/.test(this.type); }
  }
  FZ.mdNode = Node;

  /* ---------- 共通：文字参照・エスケープ ---------- */
  const ENTITY_RE = /^&(?:#x[0-9a-f]{1,6}|#[0-9]{1,7}|[a-z][a-z0-9]{1,31});/i;
  const ESCAPABLE = '[!"#$%&\'()*+,./:;<=>?@[\\\\\\]^_`{|}~-]';
  const reEntityOrEscapedChar = new RegExp('\\\\' + ESCAPABLE + '|' + ENTITY_RE.source.slice(1), 'gi');
  function decodeEntity(s) { // "&name;" | "&#123;" | "&#x1F;" → 文字（無効なら元のまま）
    const m = s.match(/^&(#x([0-9a-f]{1,6})|#([0-9]{1,7})|([a-z][a-z0-9]{1,31}));$/i); if (!m) return s;
    if (m[2] != null || m[3] != null) { let cp = m[2] != null ? parseInt(m[2], 16) : parseInt(m[3], 10); if (!cp || cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) cp = 0xfffd; return String.fromCodePoint(cp); }
    const v = FZ.HTML_ENTITIES && FZ.HTML_ENTITIES[m[4]]; return v != null ? v : s;
  }
  const unescapeString = s => /[\\&]/.test(s) ? s.replace(reEntityOrEscapedChar, x => x[0] === '\\' ? x[1] : decodeEntity(x)) : s;
  FZ.mdUnescape = unescapeString;
  const normalizeURI = uri => { try { return encodeURI(decodeURI(uri)).replace(/%25([0-9A-Fa-f]{2})/g, '%$1'); } catch { return uri.replace(/[\u0000-\u001f \u007f"<>\\^`{|}]|[^\x00-\x7f]/g, c => encodeURIComponent(c)); } };
  const normalizeLabel = s => { s = String(s); if (s.startsWith('[') && s.endsWith(']')) s = s.slice(1, -1); return s.trim().replace(/[ \t\r\n]+/g, ' ').toLowerCase().toUpperCase(); };
  const isSpaceOrTab = c => c === C_SPACE || c === C_TAB;
  const peek = (s, pos) => pos < s.length ? s.charCodeAt(pos) : -1;
  const rePunct = /^[!-\/:-@\[-`\{-~\p{P}\p{S}]/u; // ASCII 記号 ＋ Unicode 句読点・記号
  const isPunct = c => c != null && c !== '' && rePunct.test(c);
  const isWhitespaceChar = c => c === '' || c == null || /^\s/u.test(c);

  /* ---------- インライン ---------- */
  /* インライン用の正規表現は sticky（y）にして、部分文字列を作らずに現在位置から照合する */
  const Y = re => new RegExp(re.source.replace(/^\^/, ''), re.flags.replace(/[gy]/g, '') + 'y');
  const reLinkTitle = new RegExp('^(?:"(\\\\' + ESCAPABLE + '|[^"\\x00])*"|\'(\\\\' + ESCAPABLE + '|[^\'\\x00])*\'|\\((\\\\' + ESCAPABLE + '|[^()\\x00])*\\))');
  const reLinkDestinationBraces = /^(?:<(?:[^<>\n\\\x00]|\\.)*>)/;
  const reEscapable = new RegExp('^' + ESCAPABLE);
  const reEntityHere = new RegExp('^' + ENTITY_RE.source.slice(1), 'i');
  const reTicks = /`+/, reTicksHere = /^`+/, reEllipses = /\.\.\./g, reDash = /--+/g;
  const reEmailAutolink = /^<([a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*)>/;
  const reAutolink = /^<[A-Za-z][A-Za-z0-9.+-]{1,31}:[^<>\x00-\x20]*>/;
  const reCJK = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\u3000-\u303F\uFF00-\uFFEF]/u; // 和文の字（漢字・かな・全角の約物と英数）
  const reSpnl = /^ *(?:\n *)?/, reWhitespaceChar = /^[ \t\n\x0b\x0c\x0d]/, reUnicodeWhitespaceChar = /^\s/u, reFinalSpace = / *$/, reInitialSpace = /^ */, reSpaceAtEndOfLine = /^ *(?:\n|$)/, reLinkLabel = /^\[(?:[^\\\[\]]|\\.){0,1000}\]/s, reMain = /^[^\n`\[\]\\!<&*_'"~]+/, reMainAutolink = /^(?:[^\n`\[\]\\!<&*_'"~A-Za-z0-9._+-]+|[A-Za-z0-9._+-]+(?![A-Za-z0-9._+-]*@|:\/\/)(?=[^A-Za-z0-9._+-]|$))/;
  const TAGNAME = '[A-Za-z][A-Za-z0-9-]*', ATTRIBUTENAME = '[a-zA-Z_:][a-zA-Z0-9:._-]*', UNQUOTEDVALUE = "[^\"'=<>`\\x00-\\x20]+", SINGLEQUOTEDVALUE = "'[^']*'", DOUBLEQUOTEDVALUE = '"[^"]*"';
  const ATTRIBUTEVALUE = '(?:' + UNQUOTEDVALUE + '|' + SINGLEQUOTEDVALUE + '|' + DOUBLEQUOTEDVALUE + ')', ATTRIBUTEVALUESPEC = '(?:\\s*=\\s*' + ATTRIBUTEVALUE + ')', ATTRIBUTE = '(?:\\s+' + ATTRIBUTENAME + ATTRIBUTEVALUESPEC + '?)';
  const OPENTAG = '<' + TAGNAME + ATTRIBUTE + '*\\s*/?>', CLOSETAG = '</' + TAGNAME + '\\s*[>]', HTMLCOMMENT = '<!-->|<!--->|<!--[\\s\\S]*?-->', PROCESSINGINSTRUCTION = '[<][?][\\s\\S]*?[?][>]', DECLARATION = '<![A-Za-z]+[^>]*>', CDATA = '<!\\[CDATA\\[[\\s\\S]*?\\]\\]>';
  const HTMLTAG = '(?:' + OPENTAG + '|' + CLOSETAG + '|' + HTMLCOMMENT + '|' + PROCESSINGINSTRUCTION + '|' + DECLARATION + '|' + CDATA + ')';
  const reHtmlTag = new RegExp('^' + HTMLTAG);
  FZ.mdHtmlTagRe = reHtmlTag;
  const yLinkTitle = Y(reLinkTitle), yLinkDestinationBraces = Y(reLinkDestinationBraces), yEntityHere = Y(reEntityHere), yTicksHere = Y(reTicksHere), gTicks = /`+/g, yEmailAutolink = Y(reEmailAutolink), yAutolink = Y(reAutolink), ySpnl = Y(reSpnl), yInitialSpace = Y(reInitialSpace), ySpaceAtEndOfLine = Y(reSpaceAtEndOfLine), yLinkLabel = Y(reLinkLabel), yMain = Y(reMain), yMainAutolink = Y(reMainAutolink), yHtmlTag = Y(reHtmlTag);
  // 拡張自動リンク（www. / http(s):// / メール）
  const reExtWww = /^www\.[\p{L}\p{N}_-]+(?:\.[\p{L}\p{N}_-]+)*[^\s<]*/u, reExtUrl = /^(?:https?|ftp):\/\/[\p{L}\p{N}_-]+(?:\.[\p{L}\p{N}_-]+)*[^\s<]*/u, reExtEmail = /^[A-Za-z0-9._+-]+@[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)+/;
  const yExtWww = Y(reExtWww), yExtUrl = Y(reExtUrl), yExtEmail = Y(reExtEmail), yAutolinkStart = /(?:www\.|(?:https?|ftp):\/\/|[A-Za-z0-9._+-]+@)/y;

  /* 隣り合う text 節を結合（木を扱いやすくする） */
  function mergeText(node) { let ch = node.firstChild; while (ch) { const nx = ch.next; if (ch.type === 'text' && ch.prev && ch.prev.type === 'text') { ch.prev.literal += ch.literal; ch.unlink(); } else if (ch.firstChild) mergeText(ch); ch = nx; } }
  class InlineParser {
    constructor(refmap, opts) { this.refmap = refmap || {}; this.opts = opts || {}; }
    parse(block) {
      this.subject = block.strings.join('\n').trim(); this.pos = 0; this.delimiters = null; this.brackets = null;
      while (this.parseInline(block)) { /* 続ける */ }
      block.strings = []; this.processEmphasis(null);
      if (this.delimNodes) { for (const nd of this.delimNodes) if (/^\*{2,}$/.test(nd.literal || '')) nd.literal = ''; this.delimNodes = null; } // opts.stripStars：対にならずに残った ** は表示から消す（文机の取り込み用）
      mergeText(block);
    }
    text(s) { const n = new Node('text'); n.literal = s; return n; }
    match(re) { // re は sticky（y）か global（g：前方検索）
      re.lastIndex = this.pos; const m = re.exec(this.subject); if (m === null) return null; this.pos = m.index + m[0].length; return m[0]; }
    peek() { return this.pos < this.subject.length ? this.subject.charCodeAt(this.pos) : -1; }
    spnl() { this.match(ySpnl); return true; }
    parseBackticks(block) {
      const ticks = this.match(yTicksHere); if (ticks === null) return false;
      const afterOpen = this.pos; let matched;
      while ((matched = this.match(gTicks)) !== null) {
        if (matched === ticks) { const node = new Node('code'); let c = this.subject.slice(afterOpen, this.pos - ticks.length).replace(/\n/gm, ' '); if (c.length > 0 && c.match(/[^ ]/) !== null && c[0] === ' ' && c[c.length - 1] === ' ') c = c.slice(1, -1); node.literal = c; block.append(node); return true; }
      }
      this.pos = afterOpen; block.append(this.text(ticks)); return true;
    }
    parseBackslash(block) {
      const subj = this.subject; this.pos += 1;
      if (this.peek() === C_NEWLINE) { this.pos += 1; block.append(new Node('linebreak')); }
      else if (reEscapable.test(subj.charAt(this.pos))) { block.append(this.text(subj.charAt(this.pos))); this.pos += 1; }
      else block.append(this.text('\\'));
      return true;
    }
    parseAutolink(block) {
      let m;
      if ((m = this.match(yEmailAutolink))) { const dest = m.slice(1, m.length - 1); const node = new Node('link'); node.destination = normalizeURI('mailto:' + dest); node.title = ''; node.append(this.text(dest)); block.append(node); return true; }
      if ((m = this.match(yAutolink))) { const dest = m.slice(1, m.length - 1); const node = new Node('link'); node.destination = normalizeURI(dest); node.title = ''; node.append(this.text(dest)); block.append(node); return true; }
      return false;
    }
    parseHtmlTag(block) { const m = this.match(yHtmlTag); if (m === null) return false; const node = new Node('html_inline'); node.literal = m; block.append(node); return true; }
    scanDelims(cc) {
      let numdelims = 0; const startpos = this.pos;
      if (cc === C_SINGLEQUOTE || cc === C_DOUBLEQUOTE) { numdelims++; this.pos++; } else while (this.peek() === cc) { numdelims++; this.pos++; }
      if (numdelims === 0) return null;
      const charBefore = startpos === 0 ? '\n' : this.subject.charAt(startpos - 1); const cc_after = this.peek(); const charAfter = cc_after === -1 ? '\n' : String.fromCodePoint(cc_after);
      const afterIsWhitespace = reUnicodeWhitespaceChar.test(charAfter), afterIsPunctuation = isPunct(charAfter), beforeIsWhitespace = reUnicodeWhitespaceChar.test(charBefore), beforeIsPunctuation = isPunct(charBefore);
      let leftFlanking = !afterIsWhitespace && (!afterIsPunctuation || beforeIsWhitespace || beforeIsPunctuation);
      let rightFlanking = !beforeIsWhitespace && (!beforeIsPunctuation || afterIsWhitespace || afterIsPunctuation);
      /* 和文向けの緩和（opts.cjk。文机の取り込み用。仕様例の照合では切）：和文の字の隣では、約物の隣でも強調の開き・閉じになれる。
         生成 AI の和文 Markdown に多い「**国内：**主力の…」「文中の**「重要」**です」が、仕様どおりだと ** のまま残るため */
      if (this.opts.cjk && (cc === C_ASTERISK || cc === C_TILDE)) { if (!leftFlanking && !afterIsWhitespace && reCJK.test(charBefore)) leftFlanking = true; if (!rightFlanking && !beforeIsWhitespace && reCJK.test(charAfter)) rightFlanking = true; }
      let canOpen, canClose;
      if (cc === C_UNDERSCORE) { canOpen = leftFlanking && (!rightFlanking || beforeIsPunctuation); canClose = rightFlanking && (!leftFlanking || afterIsPunctuation); }
      else if (cc === C_SINGLEQUOTE || cc === C_DOUBLEQUOTE) { canOpen = leftFlanking && !rightFlanking; canClose = rightFlanking; }
      else { canOpen = leftFlanking; canClose = rightFlanking; }
      this.pos = startpos; return { numdelims, canOpen, canClose };
    }
    handleDelim(cc, block) {
      const res = this.scanDelims(cc); if (!res) return false;
      const numdelims = res.numdelims, startpos = this.pos; this.pos += numdelims;
      const contents = this.subject.slice(startpos, this.pos); const node = this.text(contents); block.append(node); if (this.opts.stripStars && cc === C_ASTERISK) (this.delimNodes = this.delimNodes || []).push(node);
      if (cc === C_TILDE && (numdelims > 2)) return true; // ~~~ は打消しにならない
      this.delimiters = { cc, numdelims, origdelims: numdelims, node, previous: this.delimiters, next: null, canOpen: res.canOpen, canClose: res.canClose };
      if (this.delimiters.previous !== null) this.delimiters.previous.next = this.delimiters;
      return true;
    }
    removeDelimiter(delim) { if (delim.previous !== null) delim.previous.next = delim.next; if (delim.next === null) this.delimiters = delim.previous; else delim.next.previous = delim.previous; }
    processEmphasis(stack_bottom) {
      const openers_bottom = {}; for (const cc of [C_UNDERSCORE, C_ASTERISK, C_TILDE]) openers_bottom[cc] = [stack_bottom, stack_bottom, stack_bottom, stack_bottom, stack_bottom, stack_bottom];
      let closer = this.delimiters; while (closer !== null && closer.previous !== stack_bottom) closer = closer.previous;
      while (closer !== null) {
        const closercc = closer.cc;
        if (!closer.canClose) { closer = closer.next; continue; }
        let opener = closer.previous, opener_found = false; const odd_match = false;
        const bottomIdx = (closer.canOpen ? 3 : 0) + (closer.origdelims % 3);
        while (opener !== null && opener !== stack_bottom && opener !== openers_bottom[closercc][bottomIdx]) {
          const oddMatch = (closer.canOpen || opener.canClose) && closer.origdelims % 3 !== 0 && (opener.origdelims + closer.origdelims) % 3 === 0;
          if (opener.cc === closer.cc && opener.canOpen && !oddMatch && !(closercc === C_TILDE && opener.numdelims !== closer.numdelims)) { opener_found = true; break; }
          opener = opener.previous;
        }
        const old_closer = closer;
        if (closercc === C_ASTERISK || closercc === C_UNDERSCORE || closercc === C_TILDE) {
          if (!opener_found) closer = closer.next;
          else {
            const use_delims = closercc === C_TILDE ? closer.numdelims : (closer.numdelims >= 2 && opener.numdelims >= 2 ? 2 : 1);
            const opener_inl = opener.node, closer_inl = closer.node;
            opener.numdelims -= use_delims; closer.numdelims -= use_delims; opener_inl.literal = opener_inl.literal.slice(0, opener_inl.literal.length - use_delims); closer_inl.literal = closer_inl.literal.slice(0, closer_inl.literal.length - use_delims);
            const emph = new Node(closercc === C_TILDE ? 'strikethrough' : use_delims === 1 ? 'emph' : 'strong');
            // opener と closer の間の節を emph に移す
            let tmp = opener_inl.next; while (tmp && tmp !== closer_inl) { const nx = tmp.next; if (emph.type === 'strong' && tmp.type === 'strong') { let g = tmp.firstChild; while (g) { const gn = g.next; emph.append(g); g = gn; } tmp.unlink(); } else emph.append(tmp); tmp = nx; } // GFM：強調の入れ子は平らに
            opener_inl.insertAfter(emph);
            // 間の区切りは捨てる
            let tempstack = closer.previous; while (tempstack !== null && tempstack !== opener) { const nx = tempstack.previous; this.removeDelimiter(tempstack); tempstack = nx; }
            if (opener.numdelims === 0) { opener_inl.unlink(); this.removeDelimiter(opener); }
            if (closer.numdelims === 0) { closer_inl.unlink(); const tempstack2 = closer.next; this.removeDelimiter(closer); closer = tempstack2; }
          }
        } else closer = closer.next;
        if (!opener_found) { openers_bottom[closercc][bottomIdx] = old_closer.previous; if (!old_closer.canOpen) this.removeDelimiter(old_closer); }
      }
      while (this.delimiters !== null && this.delimiters !== stack_bottom) this.removeDelimiter(this.delimiters);
    }
    parseLinkTitle() { const title = this.match(yLinkTitle); if (title === null) return null; return unescapeString(title.slice(1, -1)); }
    parseLinkDestination() {
      let res = this.match(yLinkDestinationBraces);
      if (res === null) {
        if (this.peek() === C_LESSTHAN) return null;
        const savepos = this.pos; let openparens = 0, c;
        while ((c = this.peek()) !== -1) {
          if (c === C_BACKSLASH && reEscapable.test(this.subject.charAt(this.pos + 1))) { this.pos += 1; if (this.peek() !== -1) this.pos += 1; }
          else if (c === C_OPEN_PAREN) { this.pos += 1; openparens += 1; }
          else if (c === C_CLOSE_PAREN) { if (openparens < 1) break; else { this.pos += 1; openparens -= 1; } }
          else if (reWhitespaceChar.exec(String.fromCharCode(c)) !== null) break;
          else this.pos += 1;
        }
        if (this.pos === savepos && c !== C_CLOSE_PAREN) return null; if (openparens !== 0) return null;
        res = this.subject.slice(savepos, this.pos); return normalizeURI(unescapeString(res));
      }
      return normalizeURI(unescapeString(res.slice(1, -1)));
    }
    parseLinkLabel() { const m = this.match(yLinkLabel); if (m === null || m.length > 1001) return 0; return m.length; }
    parseOpenBracket(block) { const startpos = this.pos; this.pos += 1; const node = this.text('['); block.append(node); this.addBracket(node, startpos, false); return true; }
    parseBang(block) { const startpos = this.pos; this.pos += 1; if (this.peek() === C_OPEN_BRACKET) { this.pos += 1; const node = this.text('!['); block.append(node); this.addBracket(node, startpos + 1, true); } else block.append(this.text('!')); return true; }
    parseCloseBracket(block) {
      this.pos += 1; const startpos = this.pos; let opener = this.brackets;
      if (opener === null) { block.append(this.text(']')); return true; }
      if (!opener.active) { block.append(this.text(']')); this.removeBracket(); return true; }
      const is_image = opener.image; const savepos = this.pos; let matched = false, dest, title, reflabel;
      if (this.peek() === C_OPEN_PAREN) {
        this.pos++;
        if (this.spnl() && (dest = this.parseLinkDestination()) !== null && this.spnl() && ((reWhitespaceChar.test(this.subject.charAt(this.pos - 1)) && (title = this.parseLinkTitle())) || true) && this.spnl() && this.peek() === C_CLOSE_PAREN) { this.pos += 1; matched = true; }
        else this.pos = savepos;
      }
      if (!matched) {
        const beforelabel = this.pos; const n = this.parseLinkLabel();
        if (n > 2) reflabel = this.subject.slice(beforelabel, beforelabel + n); else if (!opener.bracketAfter) reflabel = this.subject.slice(opener.index, startpos);
        if (n === 0) this.pos = savepos;
        if (reflabel) { const link = this.refmap[normalizeLabel(reflabel)]; if (link) { dest = link.destination; title = link.title; matched = true; } }
      }
      if (matched) {
        const node = new Node(is_image ? 'image' : 'link'); node.destination = dest; node.title = title || '';
        let tmp = opener.node.next; while (tmp) { const nx = tmp.next; node.append(tmp); tmp = nx; }
        block.append(node); this.processEmphasis(opener.previousDelimiter); this.removeBracket(); opener.node.unlink();
        if (!is_image) { let op = this.brackets; while (op !== null) { if (!op.image) op.active = false; op = op.previous; } }
        return true;
      }
      this.removeBracket(); this.pos = startpos; block.append(this.text(']')); return true;
    }
    addBracket(node, index, image) { if (this.brackets !== null) this.brackets.bracketAfter = true; this.brackets = { node, previous: this.brackets, previousDelimiter: this.delimiters, index, image, active: true }; }
    removeBracket() { this.brackets = this.brackets.previous; }
    parseEntity(block) { const m = this.match(yEntityHere); if (m) { block.append(this.text(decodeEntity(m))); return true; } return false; }
    parseString(block) { const m = this.match(this.opts.gfmAutolink ? yMainAutolink : yMain); if (m) { block.append(this.text(m)); return true; } return false; }
    parseNewline(block) {
      this.pos += 1; const lastc = block.lastChild;
      if (lastc && lastc.type === 'text' && lastc.literal[lastc.literal.length - 1] === ' ') { const hardbreak = lastc.literal[lastc.literal.length - 2] === ' '; lastc.literal = lastc.literal.replace(reFinalSpace, ''); block.append(new Node(hardbreak ? 'linebreak' : 'softbreak')); }
      else block.append(new Node('softbreak'));
      this.match(yInitialSpace); return true;
    }
    /* 拡張自動リンク：直前が空白・行頭・( * _ ~ のときだけ */
    parseExtAutolink(block, cc) {
      if (!this.opts.gfmAutolink) return false;
      const before = this.pos === 0 ? '' : this.subject.charAt(this.pos - 1); if (!(before === '' || /[\s(*_~]/.test(before))) return false;
      const S = this.subject, P = this.pos; const ex = re => { re.lastIndex = P; return re.exec(S); }; let m = null, isWww = false, isMail = false;
      if (cc === 119 /* w */) { m = ex(yExtWww); isWww = !!m; } else if (cc === 104 /* h */ || cc === 102 /* f */) m = ex(yExtUrl);
      if (!m) { m = ex(yExtEmail); isMail = !!m; }
      if (!m) return false; let url = m[0];
      if (!isMail) { // 末尾の句読点・不釣合いの ) ・ 文字参照の ; を外す
        for (;;) { const last = url[url.length - 1]; if (/[?!.,:*_~'"]/.test(last)) { url = url.slice(0, -1); continue; }
          if (last === ')') { const opens = (url.match(/\(/g) || []).length, closes = (url.match(/\)/g) || []).length; if (closes > opens) { url = url.slice(0, -1); continue; } }
          if (last === ';') { const mm = url.match(/&[a-zA-Z0-9]+;$/); if (mm) { url = url.slice(0, -mm[0].length); continue; } }
          break; }
        if (isWww && !/^www\.[^.]+\./.test(url + '.')) return false;
        if (/\.$/.test(url.split('/')[0]) || /_/.test(url.replace(/\/.*$/, '').split('.').slice(-2).join('.'))) return false; // ドメイン末尾の _ は不可
      } else { if (/[-_]$/.test(url)) return false; const after = S.charAt(P + url.length); if (after === '-' || after === '_') return false; }
      if (!url) return false;
      const node = new Node('link'); node.destination = normalizeURI(isMail ? 'mailto:' + url : isWww ? 'http://' + url : url); node.title = ''; node.append(this.text(url)); node.autolink = true; block.append(node); this.pos += url.length; return true;
    }
    parseInline(block) {
      const c = this.peek(); if (c === -1) return false; let res = false;
      switch (c) {
        case C_NEWLINE: res = this.parseNewline(block); break;
        case C_BACKSLASH: res = this.parseBackslash(block); break;
        case C_BACKTICK: res = this.parseBackticks(block); break;
        case C_ASTERISK: case C_UNDERSCORE: res = this.handleDelim(c, block); break;
        case C_TILDE: res = this.opts.strikethrough === false ? false : this.handleDelim(c, block); break;
        case C_OPEN_BRACKET: res = this.parseOpenBracket(block); break;
        case C_BANG: res = this.parseBang(block); break;
        case C_CLOSE_BRACKET: res = this.parseCloseBracket(block); break;
        case C_LESSTHAN: res = this.parseAutolink(block) || this.parseHtmlTag(block); break;
        case C_AMPERSAND: res = this.parseEntity(block); break;
        default: if (this.opts.gfmAutolink && /[A-Za-z0-9._+-]/.test(String.fromCharCode(c)) && (this.pos === 0 || /[\s(*_~]/.test(this.subject.charAt(this.pos - 1))) && (yAutolinkStart.lastIndex = this.pos, yAutolinkStart.test(this.subject))) res = this.parseExtAutolink(block, c); if (!res) res = this.parseString(block);
      }
      if (!res) { this.pos += 1; block.append(this.text(String.fromCodePoint(c))); }
      return true;
    }
  }

  /* ---------- ブロック ---------- */
  const reHtmlBlockOpen = [/./, /^<(?:script|pre|textarea|style)(?:\s|>|$)/i, /^<!--/, /^<[?]/, /^<![A-Za-z]/, /^<!\[CDATA\[/, /^<[\/]?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[123456]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul)(?:\s|[/]?[>]|$)/i, new RegExp('^(?:' + OPENTAG + '|' + CLOSETAG + ')\\s*$', 'i')];
  const reHtmlBlockClose = [/./, /<\/(?:script|pre|textarea|style)>/i, /-->/, /\?>/, />/, /\]\]>/];
  const reThematicBreak = /^(?:\*[ \t]*){3,}$|^(?:_[ \t]*){3,}$|^(?:-[ \t]*){3,}$/, reMaybeSpecial = /^[#`~*+_=<>0-9-|]/, reNonSpace = /[^ \t\f\v\r\n]/, reBulletListMarker = /^[*+-]/, reOrderedListMarker = /^(\d{1,9})([.)])/, reATXHeadingMarker = /^#{1,6}(?:[ \t]+|$)/, reCodeFence = /^`{3,}(?!.*`)|^~{3,}/, reClosingCodeFence = /^(?:`{3,}|~{3,})(?=[ \t]*$)/, reSetextHeadingLine = /^(?:=+|-+)[ \t]*$/, reLineEnding = /\r\n|\n|\r/;
  const reTableDelimRow = /^\|?\s*:?-+:?\s*(?:\|\s*:?-+:?\s*)*\|?\s*$/;
  const isBlank = s => !reNonSpace.test(s);
  const endsWithBlankLine = block => { while (block) { if (block.lastLineBlank) return true; const t = block.type; if (!block.lastLineChecked && (t === 'list' || t === 'item')) { block.lastLineChecked = true; block = block.lastChild; } else { block.lastLineChecked = true; break; } } return false; };
  function splitTableRow(line) { // | を区切りに（\| はエスケープ。コードスパン内でも \| は | になる）
    let s = line.trim(); if (s.startsWith('|')) s = s.slice(1); if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
    const cells = []; let cur = '', i = 0; while (i < s.length) { const c = s[i]; if (c === '\\' && s[i + 1] === '|') { cur += '|'; i += 2; continue; } if (c === '\\' && i + 1 < s.length) { cur += c + s[i + 1]; i += 2; continue; } if (c === '|') { cells.push(cur); cur = ''; i++; continue; } cur += c; i++; }
    cells.push(cur); return cells.map(c => c.trim());
  }

  const blocks = {
    document: { continue: () => 0, finalize: () => { }, canContain: t => t !== 'item', acceptsLines: false },
    list: { continue: () => 0, finalize: (parser, block) => { let item = block.firstChild; while (item) { if (endsWithBlankLine(item) && item.next) { block.listData.tight = false; break; } let sub = item.firstChild; while (sub) { if (endsWithBlankLine(sub) && (item.next || sub.next)) { block.listData.tight = false; break; } sub = sub.next; } item = item.next; } }, canContain: t => t === 'item', acceptsLines: false },
    block_quote: { continue: (parser) => { const ln = parser.currentLine; if (!parser.indented && peek(ln, parser.nextNonspace) === C_GREATERTHAN) { parser.advanceNextNonspace(); parser.advanceOffset(1, false); if (isSpaceOrTab(peek(ln, parser.offset))) parser.advanceOffset(1, true); } else return 1; return 0; }, finalize: () => { }, canContain: t => t !== 'item', acceptsLines: false },
    item: { continue: (parser, container) => { if (parser.blank) { if (container.firstChild == null) return 1; parser.advanceNextNonspace(); } else if (parser.indent >= container.listData.markerOffset + container.listData.padding) parser.advanceOffset(container.listData.markerOffset + container.listData.padding, true); else return 1; return 0; }, finalize: () => { }, canContain: t => t !== 'item', acceptsLines: false },
    heading: { continue: () => 1, finalize: () => { }, canContain: () => false, acceptsLines: false },
    thematic_break: { continue: () => 1, finalize: () => { }, canContain: () => false, acceptsLines: false },
    code_block: { continue: (parser, container) => { const ln = parser.currentLine, indent = parser.indent; if (container.isFenced) { const match = indent <= 3 && ln.charAt(parser.nextNonspace) === container.fenceChar && ln.slice(parser.nextNonspace).match(reClosingCodeFence); if (match && match[0].length >= container.fenceLength) { parser.lastLineLength = parser.offset + indent + match[0].length; parser.finalize(container, parser.lineNumber); return 2; } let i = container.fenceOffset; while (i > 0 && isSpaceOrTab(peek(ln, parser.offset))) { parser.advanceOffset(1, true); i--; } } else { if (indent >= CODE_INDENT) parser.advanceOffset(CODE_INDENT, true); else if (parser.blank) parser.advanceNextNonspace(); else return 1; } return 0; },
      finalize: (parser, block) => { if (block.isFenced) { const content = block.strings.join('\n'); const nl = content.indexOf('\n'); const first = nl === -1 ? content : content.slice(0, nl), rest = nl === -1 ? '' : content.slice(nl + 1); block.info = unescapeString(first.trim()); block.literal = rest.length ? rest + '\n' : ''; } else { block.literal = block.strings.join('\n').replace(/(\n *)+$/, '') + '\n'; } block.strings = []; }, canContain: () => false, acceptsLines: true },
    html_block: { continue: (parser, container) => parser.blank && (container.htmlBlockType === 6 || container.htmlBlockType === 7) ? 1 : 0, finalize: (parser, block) => { block.literal = block.strings.join('\n').replace(/(\n *)+$/, ''); block.strings = []; }, canContain: () => false, acceptsLines: true },
    paragraph: { continue: (parser) => parser.blank ? 1 : 0, finalize: (parser, block) => { let pos, hasRef = false; while (peek(block.strings.join('\n'), 0) === C_OPEN_BRACKET && (pos = parser.inlineParser_parseReference(block.strings.join('\n'), parser.refmap))) { const joined = block.strings.join('\n').slice(pos); block.strings = joined === '' ? [] : joined.split('\n'); hasRef = true; if (!block.strings.length) break; } if (hasRef && !reNonSpace.test(block.strings.join(''))) block.unlink(); }, canContain: () => false, acceptsLines: true },
    table: { continue: (parser, container) => { if (parser.blank) return 1; const ln = parser.currentLine.slice(parser.nextNonspace); if (parser.indented) return 1; if (/^(?:>|#{1,6}(?:\s|$)|```|~~~|<|(?:\*|-|_)[ \t]*(?:\1[ \t]*){2,}$)/.test(ln) && !/\|/.test(ln)) return 1; return 0; }, finalize: () => { }, canContain: () => false, acceptsLines: true },
  };

  class BlockParser {
    constructor(opts) { this.opts = opts || {}; }
    inlineParser_parseReference(s, refmap) { // リンク参照定義を 1 つ読む → 消費した長さ（0 なら無し）
      const ip = new InlineParser(refmap, this.opts); ip.subject = s; ip.pos = 0; const startpos = ip.pos;
      const matchChars = ip.parseLinkLabel(); if (matchChars === 0) return 0; const rawlabel = ip.subject.slice(0, matchChars);
      if (ip.peek() !== C_COLON) { ip.pos = startpos; return 0; } ip.pos++; ip.spnl();
      const dest = ip.parseLinkDestination(); if (dest === null) { ip.pos = startpos; return 0; }
      const beforetitle = ip.pos; ip.spnl(); let title = null; if (ip.pos !== beforetitle) title = ip.parseLinkTitle(); if (title === null) { title = ''; ip.pos = beforetitle; }
      let atLineEnd = true; if (ip.match(ySpaceAtEndOfLine) === null) { if (title === '') atLineEnd = false; else { title = ''; ip.pos = beforetitle; atLineEnd = ip.match(ySpaceAtEndOfLine) !== null; } }
      if (!atLineEnd) { ip.pos = startpos; return 0; }
      const normlabel = normalizeLabel(rawlabel); if (normlabel === '') { ip.pos = startpos; return 0; }
      if (!refmap[normlabel]) refmap[normlabel] = { destination: dest, title };
      return ip.pos - startpos;
    }
    addLine() { if (this.partiallyConsumedTab) { this.offset += 1; const charsToTab = 4 - (this.column % 4); this.tip.strings.push(' '.repeat(charsToTab) + this.currentLine.slice(this.offset)); } else this.tip.strings.push(this.currentLine.slice(this.offset)); }
    addChild(tag, offset) { while (!blocks[this.tip.type].canContain(tag)) this.finalize(this.tip, this.lineNumber - 1); const node = new Node(tag, [[this.lineNumber, offset + 1], [0, 0]]); this.tip.append(node); this.tip = node; return node; }
    closeUnmatchedBlocks() { if (!this.allClosed) { while (this.oldtip !== this.lastMatchedContainer) { const parent = this.oldtip.parent; this.finalize(this.oldtip, this.lineNumber - 1); this.oldtip = parent; } this.allClosed = true; } }
    finalize(block, lineNumber) { const above = block.parent; block.open = false; block.pos[1] = [lineNumber, this.lastLineLength]; blocks[block.type].finalize(this, block); this.tip = above; }
    advanceOffset(count, columns) {
      const currentLine = this.currentLine; let charsToTab, charsToAdvance, c;
      while (count > 0 && (c = currentLine[this.offset])) {
        if (c === '\t') { charsToTab = 4 - (this.column % 4); if (columns) { this.partiallyConsumedTab = charsToTab > count; charsToAdvance = charsToTab > count ? count : charsToTab; this.column += charsToAdvance; this.offset += this.partiallyConsumedTab ? 0 : 1; count -= charsToAdvance; } else { this.partiallyConsumedTab = false; this.column += charsToTab; this.offset += 1; count -= 1; } }
        else { this.partiallyConsumedTab = false; this.offset += 1; this.column += 1; count -= 1; }
      }
    }
    advanceNextNonspace() { this.offset = this.nextNonspace; this.column = this.nextNonspaceColumn; this.partiallyConsumedTab = false; }
    findNextNonspace() { const currentLine = this.currentLine; let i = this.offset, cols = this.column, c; while ((c = currentLine.charAt(i)) !== '') { if (c === ' ') { i++; cols++; } else if (c === '\t') { i++; cols += 4 - (cols % 4); } else break; } this.blank = c === '\n' || c === '\r' || c === ''; this.nextNonspace = i; this.nextNonspaceColumn = cols; this.indent = this.nextNonspaceColumn - this.column; this.indented = this.indent >= CODE_INDENT; }
    parseListMarker(container) {
      const rest = this.currentLine.slice(this.nextNonspace); let match, nextc; const data = { type: null, tight: true, bulletChar: null, start: null, delimiter: null, padding: null, markerOffset: this.indent };
      if (this.indent >= 4) return null;
      if ((match = rest.match(reBulletListMarker))) { data.type = 'bullet'; data.bulletChar = match[0][0]; }
      else if ((match = rest.match(reOrderedListMarker)) && (container.type !== 'paragraph' || match[1] === '1')) { data.type = 'ordered'; data.start = parseInt(match[1], 10); data.delimiter = match[2]; }
      else return null;
      nextc = peek(this.currentLine, this.nextNonspace + match[0].length); if (!(nextc === -1 || nextc === C_TAB || nextc === C_SPACE)) return null;
      if (container.type === 'paragraph' && !this.currentLine.slice(this.nextNonspace + match[0].length).match(reNonSpace)) return null;
      this.advanceNextNonspace(); this.advanceOffset(match[0].length, true); const spacesStartCol = this.column, spacesStartOffset = this.offset;
      do { this.advanceOffset(1, true); nextc = peek(this.currentLine, this.offset); } while (this.column - spacesStartCol < 5 && isSpaceOrTab(nextc));
      const blank_item = peek(this.currentLine, this.offset) === -1; const spaces_after_marker = this.column - spacesStartCol;
      if (spaces_after_marker >= 5 || spaces_after_marker < 1 || blank_item) { data.padding = match[0].length + 1; this.column = spacesStartCol; this.offset = spacesStartOffset; if (isSpaceOrTab(peek(this.currentLine, this.offset))) this.advanceOffset(1, true); } else data.padding = match[0].length + spaces_after_marker;
      return data;
    }
    listsMatch(a, b) { return a.type === b.type && a.delimiter === b.delimiter && a.bulletChar === b.bulletChar; }
    /* ブロック開始の判定（1=コンテナ開始、2=葉ブロック開始、0=無し） */
    tryStarts(container) {
      let depth = 0; for (let n = this.tip; n; n = n.parent) depth++; if (depth > 120) return 0; // 入れ子の深さに上限（再帰保護）
      const starts = [
        () => { if (!this.indented && peek(this.currentLine, this.nextNonspace) === C_GREATERTHAN) { this.advanceNextNonspace(); this.advanceOffset(1, false); if (isSpaceOrTab(peek(this.currentLine, this.offset))) this.advanceOffset(1, true); this.closeUnmatchedBlocks(); this.addChild('block_quote', this.nextNonspace); return 1; } return 0; },
        () => { let match; if (!this.indented && (match = this.currentLine.slice(this.nextNonspace).match(reATXHeadingMarker))) { this.advanceNextNonspace(); this.advanceOffset(match[0].length, false); this.closeUnmatchedBlocks(); const c = this.addChild('heading', this.nextNonspace); c.level = match[0].trim().length; c.strings = [this.currentLine.slice(this.offset).replace(/^[ \t]*#+[ \t]*$/, '').replace(/[ \t]+#+[ \t]*$/, '')]; this.advanceOffset(this.currentLine.length - this.offset); return 2; } return 0; },
        () => { let match; if (!this.indented && (match = this.currentLine.slice(this.nextNonspace).match(reCodeFence))) { const fenceLength = match[0].length; this.closeUnmatchedBlocks(); const c = this.addChild('code_block', this.nextNonspace); c.isFenced = true; c.fenceLength = fenceLength; c.fenceChar = match[0][0]; c.fenceOffset = this.indent; this.advanceNextNonspace(); this.advanceOffset(fenceLength, false); return 2; } return 0; },
        () => { if (!this.indented && peek(this.currentLine, this.nextNonspace) === C_LESSTHAN) { const s = this.currentLine.slice(this.nextNonspace); for (let blockType = 1; blockType <= 7; blockType++) if (reHtmlBlockOpen[blockType].test(s) && (blockType < 7 || (container.type !== 'paragraph' && !(!this.allClosed && !this.blank && this.tip.type === 'paragraph')))) { this.closeUnmatchedBlocks(); const b = this.addChild('html_block', this.offset); b.htmlBlockType = blockType; return 2; } } return 0; },
        () => { let match; if (!this.indented && container.type === 'paragraph' && (match = this.currentLine.slice(this.nextNonspace).match(reSetextHeadingLine))) { this.closeUnmatchedBlocks(); let pos; while (peek(container.strings.join('\n'), 0) === C_OPEN_BRACKET && (pos = this.inlineParser_parseReference(container.strings.join('\n'), this.refmap))) { const joined = container.strings.join('\n').slice(pos); container.strings = joined === '' ? [] : joined.split('\n'); if (!container.strings.length) break; } if (container.strings.length > 0 && reNonSpace.test(container.strings.join(''))) { const heading = new Node('heading', container.pos); heading.level = match[0][0] === '=' ? 1 : 2; heading.strings = container.strings; container.insertAfter(heading); container.unlink(); this.tip = heading; this.advanceOffset(this.currentLine.length - this.offset, false); return 2; } return 0; } return 0; },
        () => { if (!this.indented && reThematicBreak.test(this.currentLine.slice(this.nextNonspace))) { this.closeUnmatchedBlocks(); this.addChild('thematic_break', this.nextNonspace); this.advanceOffset(this.currentLine.length - this.offset, false); return 2; } return 0; },
        () => { let data; if ((!this.indented || container.type === 'list') && (data = this.parseListMarker(container))) { this.closeUnmatchedBlocks(); if (this.tip.type !== 'list' || !this.listsMatch(container.listData, data)) { container = this.addChild('list', this.nextNonspace); container.listData = data; } container = this.addChild('item', this.nextNonspace); container.listData = data; return 1; } return 0; },
        () => { if (this.indented && this.tip.type !== 'paragraph' && !this.blank) { this.advanceOffset(CODE_INDENT, true); this.closeUnmatchedBlocks(); const c = this.addChild('code_block', this.offset); c.isFenced = false; return 2; } return 0; },
      ];
      for (const st of starts) { const r = st(); if (r) return r; }
      return 0;
    }
    incorporateLine(ln) {
      let all_matched = true, container = this.doc; this.oldtip = this.tip; this.offset = 0; this.column = 0; this.blank = false; this.partiallyConsumedTab = false; this.lineNumber += 1;
      if (ln.indexOf('\u0000') !== -1) ln = ln.replace(/\0/g, '\uFFFD');
      this.currentLine = ln;
      let lastChild;
      while ((lastChild = container.lastChild) && lastChild.open) {
        container = lastChild; this.findNextNonspace();
        switch (blocks[container.type].continue(this, container)) { case 0: break; case 1: all_matched = false; break; case 2: return; default: throw new Error('continue returned illegal value'); }
        if (!all_matched) { container = container.parent; break; }
      }
      this.allClosed = container === this.oldtip; this.lastMatchedContainer = container;
      let matchedLeaf = container.type !== 'paragraph' && container.type !== 'table' && blocks[container.type].acceptsLines;
      while (!matchedLeaf) {
        this.findNextNonspace();
        if (!this.indented && !reMaybeSpecial.test(ln.slice(this.nextNonspace))) { this.advanceNextNonspace(); break; }
        const res = this.tryStarts(container);
        if (res === 1) { container = this.tip; } else if (res === 2) { container = this.tip; matchedLeaf = true; } else { this.advanceNextNonspace(); break; }
      }
      // 表：段落 1 行目の直後に区切り行が来たら表へ
      if (this.opts.table !== false && !this.blank && this.indent < 4 && this.tip.type === 'paragraph' && this.tip === container && this.tip.strings.length === 1 && reTableDelimRow.test(ln.slice(this.offset))) {
        const head = splitTableRow(this.tip.strings[0]), delim = splitTableRow(ln.slice(this.offset));
        if (head.length === delim.length && delim.every(d => /^:?-+:?$/.test(d))) {
          const tbl = new Node('table', this.tip.pos); tbl.align = delim.map(d => d.startsWith(':') && d.endsWith(':') ? 'center' : d.endsWith(':') ? 'right' : d.startsWith(':') ? 'left' : null);
          const row = new Node('table_row'); row.open = false; row.isHeader = true; row.cells = head; tbl.append(row); this.tip.insertAfter(tbl); this.tip.unlink(); this.tip = tbl; this.lastLineLength = ln.length; return;
        }
      }
      if (this.tip.type === 'table' && container === this.tip) {
        if (this.blank) { this.finalize(this.tip, this.lineNumber - 1); } else { const row = new Node('table_row'); row.open = false; row.cells = splitTableRow(ln.slice(this.offset)); this.tip.append(row); this.lastLineLength = ln.length; return; }
      }
      if (!this.allClosed && !this.blank && this.tip.type === 'paragraph') { this.addLine(); }
      else {
        this.closeUnmatchedBlocks();
        if (this.blank && container.lastChild) container.lastChild.lastLineBlank = true;
        const t = container.type;
        const lastLineBlank = this.blank && !(t === 'block_quote' || (t === 'code_block' && container.isFenced) || (t === 'item' && !container.firstChild && container.pos[0][0] === this.lineNumber));
        let cont = container; while (cont) { cont.lastLineBlank = lastLineBlank; cont = cont.parent; }
        if (blocks[t].acceptsLines) { this.addLine(); if (t === 'html_block' && container.htmlBlockType >= 1 && container.htmlBlockType <= 5 && reHtmlBlockClose[container.htmlBlockType].test(this.currentLine.slice(this.offset))) { this.lastLineLength = ln.length; this.finalize(container, this.lineNumber); } }
        else if (this.offset < ln.length && !this.blank) { container = this.addChild('paragraph', this.offset); this.advanceNextNonspace(); this.addLine(); }
      }
      this.lastLineLength = ln.length;
    }
    processInlines(block) {
      const ip = new InlineParser(this.refmap, this.opts);
      const walk = (node) => { for (const ch of [...node.children]) { if (ch.type === 'paragraph' || ch.type === 'heading') ip.parse(ch); else if (ch.type === 'table') { for (const row of ch.children) { const cells = row.cells.slice(0, ch.align.length); while (cells.length < ch.align.length) cells.push(''); row.children = []; cells.forEach((c, k) => { const cell = new Node('table_cell'); cell.align = ch.align[k]; cell.isHeader = !!row.isHeader; cell.strings = [c]; row.append(cell); ip.parse(cell); }); } } else walk(ch); } };
      walk(block);
      // タスク項目：項目の最初の段落が [ ] / [x] で始まる
      const tasks = (node) => { for (const ch of node.children) { if (ch.type === 'item' && ch.firstChild && ch.firstChild.type === 'paragraph') { const p = ch.firstChild, t = p.firstChild; if (t && t.type === 'text') { const m = t.literal.match(/^\[([ xX])\](?: |$)/); if (m && (t.literal.length > m[0].length || p.children.length > 1 || m[0].endsWith(' '))) { ch.checked = m[1] !== ' '; ch.task = true; t.literal = t.literal.slice(m[0].length); if (!t.literal) t.unlink(); } } } if (ch.children) tasks(ch); } }; tasks(block);
    }
    parse(input) {
      this.doc = new Node('document', [[1, 1], [0, 0]]); this.tip = this.doc; this.refmap = {}; this.lineNumber = 0; this.lastLineLength = 0; this.offset = 0; this.column = 0; this.lastMatchedContainer = this.doc; this.currentLine = '';
      const lines = input.split(reLineEnding); let len = lines.length; if (input.charCodeAt(input.length - 1) === C_NEWLINE) len -= 1;
      for (let i = 0; i < len; i++) this.incorporateLine(lines[i]);
      while (this.tip) this.finalize(this.tip, len);
      this.processInlines(this.doc); return this.doc;
    }
  }
  const DEFAULTS = { gfmAutolink: true, table: true, strikethrough: true };
  FZ.md = { parse: (text, opts) => new BlockParser({ ...DEFAULTS, ...(opts || {}) }).parse(String(text)), Node };

  /* ---------- HTML 描画（仕様例との照合用） ---------- */
  const escH = (s, quotes) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const filterTags = s => s.replace(/<(\/?)(title|textarea|style|xmp|iframe|noembed|noframes|script|plaintext)(?=[\s>\/])/gi, '&lt;$1$2');
  function toHtml(node, opts = {}) {
    const tagfilter = !!opts.tagfilter; const out = []; let disableTags = 0;
    const lit = s => { out.push(s); }; const tag = (name, attrs, selfclosing) => { if (disableTags > 0) return; let s = '<' + name; for (const [k, v] of attrs || []) s += ' ' + k + '="' + v + '"'; out.push(s + (selfclosing ? ' />' : '>')); };
    const cr = () => { if (out.length && !out[out.length - 1].endsWith('\n')) out.push('\n'); };
    const render = (n, entering) => {
      const grandparent = n.parent && n.parent.parent; const tight = (grandparent && grandparent.type === 'list' && grandparent.listData.tight) || (n.parent && n.parent.type === 'item' && n.parent.parent.listData.tight);
      switch (n.type) {
        case 'document': break;
        case 'text': lit(escH(n.literal)); break;
        case 'softbreak': lit('\n'); break;
        case 'linebreak': tag('br', [], true); cr(); break;
        case 'emph': tag(entering ? 'em' : '/em'); break;
        case 'strong': tag(entering ? 'strong' : '/strong'); break;
        case 'strikethrough': tag(entering ? 'del' : '/del'); break;
        case 'html_inline': lit(tagfilter ? filterTags(n.literal) : n.literal); break;
        case 'code': tag('code'); lit(escH(n.literal)); tag('/code'); break;
        case 'link': if (entering) { const attrs = [['href', escH(n.destination)]]; if (n.title) attrs.push(['title', escH(n.title)]); tag('a', attrs); } else tag('/a'); break;
        case 'image': if (entering) { if (disableTags === 0) lit('<img src="' + escH(n.destination) + '" alt="'); disableTags += 1; } else { disableTags -= 1; if (disableTags === 0) { if (n.title) lit('" title="' + escH(n.title)); lit('" />'); } } break;
        case 'paragraph': if (tight) break; if (entering) { cr(); tag('p'); } else { tag('/p'); cr(); } break;
        case 'heading': if (entering) { cr(); tag('h' + n.level); } else { tag('/h' + n.level); cr(); } break;
        case 'thematic_break': cr(); tag('hr', [], true); cr(); break;
        case 'code_block': { const info = n.info ? n.info.split(/\s+/) : []; const attrs = []; if (info.length && info[0].length) attrs.push(['class', 'language-' + escH(info[0])]); cr(); tag('pre'); tag('code', attrs); lit(escH(n.literal)); tag('/code'); tag('/pre'); cr(); break; }
        case 'html_block': cr(); lit(tagfilter ? filterTags(n.literal) : n.literal); cr(); break;
        case 'block_quote': if (entering) { cr(); tag('blockquote'); cr(); } else { cr(); tag('/blockquote'); cr(); } break;
        case 'list': { const tagname = n.listData.type === 'bullet' ? 'ul' : 'ol'; if (entering) { const attrs = []; if (n.listData.start != null && n.listData.start !== 1) attrs.push(['start', String(n.listData.start)]); cr(); tag(tagname, attrs); cr(); } else { cr(); tag('/' + tagname); cr(); } break; }
        case 'item': if (entering) { tag('li'); if (n.task) lit('<input ' + (n.checked ? 'checked="" ' : '') + 'disabled="" type="checkbox"> '); } else { tag('/li'); cr(); } break;
        case 'table': if (entering) { cr(); tag('table'); cr(); } else { if (n.children.length > 1) { tag('/tbody'); cr(); } tag('/table'); cr(); } break;
        case 'table_row': if (entering) { if (n.isHeader) { tag('thead'); cr(); } else if (n.prev && n.prev.isHeader) { tag('tbody'); cr(); } tag('tr'); cr(); } else { tag('/tr'); cr(); if (n.isHeader) { tag('/thead'); cr(); } } break;
        case 'table_cell': { const t = n.isHeader ? 'th' : 'td'; if (entering) tag(t, n.align ? [['align', n.align]] : []); else { tag('/' + t); cr(); } break; }
      }
    };
    const walk = (n) => { render(n, true); if (n.isContainer()) { for (const ch of n.children) walk(ch); render(n, false); } };
    walk(node); return out.join('');
  }
  FZ.md.toHtml = toHtml;
  // 公開：ユーティリティ
  FZ.md.normalizeLabel = normalizeLabel; FZ.md.splitTableRow = splitTableRow;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
