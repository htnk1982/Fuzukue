/* 文机 — 表の編集：行・列の挿入と削除、列の幅（境の罫を動かす）、セルの範囲（網・揃え・中身・太字）
 * 表は「attrs.cells の続く行」＋「縦罫（セルの境）」＋「横罫（行の境）」＋「網」。ここでは罫・網・セルの段（seg）をまとめて付け替える。
 * 様式どおりの表（FZ.tableMatch が名前を返す表）は、形を変えたあと同じ様式で罫・網を引き直す（見出し行・合計行の罫も正しく付く）。 */
(function (FZ) {
  'use strict';
  const M = FZ.M;
  const EPS = 1e-6;
  const T = FZ.tbl = {};

  /* 表の範囲・列の境（全行の縦罫の位置の和。結合して一部の行に無い境も含む）・様式 */
  function info(ed, i = ed.caret.line) {
    const rg = FZ.tableRange(ed, i); if (!rg) return null; const [a, b] = rg; const d = ed.doc;
    const set = new Set(); for (const r of d.rules) if (r.axis === 'v' && r.from <= b && r.to >= a) set.add(r.col);
    const B = [...set].sort((x, y) => x - y); if (B.length < 2) return null;
    return { a, b, B, L: B[0], R: B[B.length - 1], n: B.length - 1, match: FZ.tableMatch ? FZ.tableMatch(d, a, b) : null };
  }
  T.info = info;
  const present = (d, i, col) => d.rules.some(r => r.axis === 'v' && Math.abs(r.col - col) < EPS && r.from <= i && r.to >= i);
  /* 行 i で列 j を含むセルの段（seg）の番号。無ければ -1 */
  function segAt(d, i, B, j) { const ln = d.lines[i]; let best = -1; ln.segs.forEach((s, k) => { if (s.col <= B[j] + EPS && (best < 0 || s.col > ln.segs[best].col)) best = k; }); return best; }
  T.segAt = segAt;
  /* カーソルのある列（境の番号） */
  T.colOf = (ed, I = info(ed)) => { if (!I) return -1; const s = ed.seg(); let j = I.B.findIndex(c => Math.abs(c - s.col) < EPS); if (j < 0) j = I.B.filter(c => c <= s.col).length - 1; return Math.max(0, Math.min(I.n - 1, j)); };

  /* 様式どおりの表なら、範囲 [a,b] の罫・網を消して同じ様式で引き直す */
  function reapply(ed, a, b, m) {
    if (!m) return; const d = ed.doc; const set = new Set(); for (const r of d.rules) if (r.axis === 'v' && r.from <= b && r.to >= a) set.add(r.col); const B = [...set].sort((x, y) => x - y); if (B.length < 2) return; const L = B[0], R = B[B.length - 1];
    d.rules = d.rules.filter(r => !((r.axis === 'v' && B.includes(r.col) && r.from >= a && r.to <= b) || (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= R + EPS)));
    ed.removeFillRect(a, b, L, R - L);
    FZ.applyTablePure(d, a, b, B, m.preset, m.headFill, m.sideFill);
  }
  /* 表の中の行の区切りの線種（見出し行の下・外枠を除いた中の罫のうち多いもの。無ければ null＝引かない） */
  function innerKind(d, a, b, L, R) { const cnt = new Map(); for (const r of d.rules) if (r.axis === 'h' && r.line > a + 1 && r.line <= b && r.from <= L + EPS && r.to >= R - EPS) cnt.set(r.kind, (cnt.get(r.kind) || 0) + 1); let best = null, n = 0; for (const [k, c] of cnt) if (c > n) { best = k; n = c; } if (best) return best; if (b > a + 1) return null; /* 本文の行の間に罫が無い表 */ const hs = d.rules.find(r => r.axis === 'h' && r.line === a + 1 && r.from <= L + EPS && r.to >= R - EPS); return hs ? hs.kind : null; }

  /* ---------- 行 ---------- */
  T.insertRow = function (ed, below) {
    const I = info(ed); if (!I) return false; const d = ed.doc, c = ed.caret, i = c.line; const { a, b, L, R, match } = I;
    ed.mutate('', () => {
      const src = d.lines[i]; const nl = { segs: src.segs.map(s => FZ.newSeg(s.col, '')), attrs: { cells: true } }; if (src.attrs.cellAlign) nl.attrs.cellAlign = src.attrs.cellAlign.slice();
      const kind = innerKind(d, a, b, L, R); const k = below ? i + 1 : i;
      const starting = below ? [] : d.rules.filter(r => r.axis === 'v' && r.from === i && r.col >= L - EPS && r.col <= R + EPS);
      const topRules = d.rules.filter(r => r.axis === 'h' && r.line === k && r.from >= L - EPS && r.to <= R + EPS);
      ed.insertLine(k, nl, below);
      for (const r of starting) r.from = i; // 上に足すとき：この行から始まる縦罫を新しい行まで伸ばす
      if (below && i === a && b > a) { for (const r of topRules) r.line = a + 1; if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: a + 2, from: L, to: R, kind }); } // 見出し行の下に足す：見出しの下の罫は見出しに付けたまま
      else if (!below && i === a) { for (const r of topRules) r.line = a; if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: a + 1, from: L, to: R, kind }); } // 先頭の上に足す：外枠の上辺は表の上に
      else if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: k, from: L, to: R, kind });
      ed.dedupeRules(); reapply(ed, a, b + 1, match);
      ed.normalizeSegs(); c.line = k; c.seg = 0; c.off = 0; c.vcol = null; ed.anchor = null; // 足した行の先頭のセルへ（行の見出しから打てる）
    });
    return true;
  };
  T.deleteRow = function (ed) {
    const I = info(ed); if (!I) return false; const d = ed.doc, c = ed.caret, i = c.line; const { a, b, L, R, match } = I;
    if (a === b) return T.deleteTable(ed);
    ed.mutate('', () => {
      const atTop = d.rules.filter(r => r.axis === 'h' && r.line === i && r.from >= L - EPS && r.to <= R + EPS), below = d.rules.filter(r => r.axis === 'h' && r.line === i + 1 && r.from >= L - EPS && r.to <= R + EPS);
      const drop = new Set((i === a ? below : atTop).map(r => r.id)); // 先頭の行を消す：外枠の上辺を残す。ほかの行：その行の下の罫を残す
      d.rules = d.rules.filter(r => !drop.has(r.id));
      ed.removeLine(i); reapply(ed, a, b - 1, match);
      c.line = Math.min(i, b - 1); const ln = d.lines[c.line]; c.seg = Math.min(c.seg, ln.segs.length - 1); c.off = 0; c.vcol = null; ed.anchor = null;
      ed.normalizeSegs();
    });
    return true;
  };
  T.deleteTable = function (ed) {
    const I = info(ed); if (!I) return false; const d = ed.doc; const { a, b, B, L, R } = I;
    ed.mutate('', () => {
      d.rules = d.rules.filter(r => !((r.axis === 'v' && B.includes(r.col) && r.from >= a && r.to <= b) || (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= R + EPS)));
      ed.removeFillRect(a, b, L, R - L);
      for (let i = b; i > a; i--) ed.removeLine(i);
      d.lines[a] = FZ.newLine(); ed.caret = { line: a, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; // 表のあった所は空の行 1 つに
    });
    return true;
  };

  /* ---------- 列：組み替え（cols＝新しい列 [{src: 元の列 | null, w, splitOf?}]） ---------- */
  function regrid(ed, I, cols, newKind) {
    const d = ed.doc; const { a, b, B, L, n } = I; const m = cols.length;
    const NB = [L]; for (const c of cols) NB.push(NB[NB.length - 1] + c.w);
    /* 新しい境 c（1..m-1）の素性：元の境 q か、全行に引く新しい境 'all' */
    const ident = [{ old: 0 }]; for (let c = 1; c < m; c++) { const x = cols[c - 1], y = cols[c];
      if (x.src != null && y.src != null) ident.push({ old: y.src });
      else if (x.src != null) ident.push(y.splitOf === x.src ? { all: true } : { old: x.src + 1 });
      else ident.push(x.splitOf === y.src && y.src != null ? { all: true } : { old: y.src != null ? y.src : n }); }
    ident.push({ old: n });
    const oldToNew = q => { const c = ident.findIndex(t => t.old === q); if (c >= 0) return NB[c]; let best = NB[0]; for (const x of NB) if (Math.abs(x - B[q]) < Math.abs(best - B[q])) best = x; return best; };
    // 元の縦罫の線種（行×境）
    const kindAt = []; for (let i = a; i <= b; i++) kindAt.push(new Array(n + 1).fill(null));
    const keep = []; for (const r of d.rules) { if (r.axis !== 'v') { keep.push(r); continue; } const q = B.findIndex(x => Math.abs(x - r.col) < EPS); if (q < 0 || r.to < a || r.from > b) { keep.push(r); continue; }
      for (let i = Math.max(a, r.from); i <= Math.min(b, r.to); i++) kindAt[i - a][q] = r.kind; if (r.from < a) keep.push({ ...r, id: FZ.uid(), to: a - 1 }); if (r.to > b) keep.push({ ...r, id: FZ.uid(), from: b + 1 }); }
    d.rules = keep;
    const has = (i, c) => { const t = ident[c]; if (t.all) return true; return kindAt[i - a][t.old] != null; };
    const kindOf = (i, c) => { const t = ident[c]; return t.all ? newKind : kindAt[i - a][t.old]; };
    for (let c = 0; c <= m; c++) { let run = null; for (let i = a; i <= b + 1; i++) { const k = i <= b && has(i, c) ? kindOf(i, c) : null; if (run && run.kind === k) { run.to = i; continue; } if (run && run.kind != null) d.rules.push({ id: FZ.uid(), axis: 'v', col: NB[c], from: run.from, to: run.to, kind: run.kind }); run = { from: i, to: i, kind: k }; } }
    // セルの段：元の列ごとに中身を新しい列へ（消える列の中身は捨てる。結合セルは残る列の先頭へ）
    for (let i = a; i <= b; i++) {
      const ln = d.lines[i]; const ca = ln.attrs.cellAlign; ln.segs.forEach((s, k) => { s._al = ca ? ca[k] || null : null; });
      const presOld = q => kindAt[i - a][q] != null; const out = [];
      for (const s of ln.segs) { const q = B.findIndex(x => Math.abs(x - s.col) < EPS); if (q < 0 || q >= n) { if (s.col >= B[n] - EPS || s.col < L - EPS) out.push(s); continue; }
        let qe = q + 1; while (qe < n && !presOld(qe)) qe++; let target = -1; for (let src = q; src < qe && target < 0; src++) { const c = cols.findIndex(x => x.src === src); if (c >= 0) target = c; }
        if (target < 0) continue; s.col = NB[target]; out.push(s); }
      for (let c = 0; c < m; c++) if ((c === 0 || has(i, c)) && !out.some(s => Math.abs(s.col - NB[c]) < EPS)) { const s = FZ.newSeg(NB[c], ''); s._al = null; out.push(s); }
      out.sort((x, y) => x.col - y.col); ln.segs = out; if (ca || out.some(s => s._al)) { ln.attrs.cellAlign = out.map(s => s._al || null); if (!ln.attrs.cellAlign.some(Boolean)) delete ln.attrs.cellAlign; } for (const s of out) delete s._al;
    }
    // 横罫・網の端
    const mapX = x => { const q = B.findIndex(y => Math.abs(y - x) < EPS); return q < 0 ? x : oldToNew(q); };
    for (const r of d.rules) if (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= B[n] + EPS) { r.from = mapX(r.from); r.to = mapX(r.to); }
    d.rules = d.rules.filter(r => r.axis !== 'h' || r.to > r.from);
    for (const f of d.fills) if (f.from <= b && f.to >= a && f.col >= L - EPS && f.col + f.cols <= B[n] + EPS) { const x1 = mapX(f.col), x2 = mapX(f.col + f.cols); f.col = x1; f.cols = x2 - x1; }
    d.fills = d.fills.filter(f => f.cols > 0);
    return NB;
  }
  const widths = I => I.B.slice(1).map((x, k) => x - I.B[k]);
  function commonKind(d, I) { const cnt = new Map(); for (const r of d.rules) if (r.axis === 'v' && r.from <= I.b && r.to >= I.a && r.col > I.L + EPS && r.col < I.R - EPS) cnt.set(r.kind, (cnt.get(r.kind) || 0) + 1); let best = 'thin', c = 0; for (const [k, v] of cnt) if (v > c) { best = k; c = v; } return best; }
  T.insertCol = function (ed, right) {
    const I = info(ed); if (!I) return false; const j = T.colOf(ed, I); const W = widths(I); const d = ed.doc;
    let cols = W.map((w, k) => ({ src: k, w })); let at;
    if (W[j] >= 4) { const nw = Math.floor(W[j] / 2); cols[j].w = W[j] - nw; at = right ? j + 1 : j; cols.splice(at, 0, { src: null, w: nw, splitOf: j }); }
    else { let q = -1; W.forEach((w, k) => { if (w >= 4 && (q < 0 || w > W[q])) q = k; }); if (q < 0) return 'narrow'; const nw = Math.floor(W[q] / 2); cols[q].w -= nw; at = right ? j + 1 : j; cols.splice(at, 0, { src: null, w: nw }); }
    ed.mutate('', () => { const kind = commonKind(d, I); const NB = regrid(ed, I, cols, kind); reapply(ed, I.a, I.b, I.match); ed.normalizeSegs(); const ln = ed.line(); const k = ln.segs.findIndex(s => Math.abs(s.col - NB[at]) < EPS); ed.caret.seg = k >= 0 ? k : 0; ed.caret.off = 0; ed.caret.vcol = null; ed.anchor = null; });
    return true;
  };
  T.deleteCol = function (ed) {
    const I = info(ed); if (!I) return false; if (I.n <= 1) return T.deleteTable(ed); const j = T.colOf(ed, I); const W = widths(I); const d = ed.doc;
    const cols = W.map((w, k) => ({ src: k, w })); const nb = j > 0 ? j - 1 : j + 1; cols[nb].w += W[j]; cols.splice(j, 1);
    ed.mutate('', () => { const NB = regrid(ed, I, cols, commonKind(d, I)); reapply(ed, I.a, I.b, I.match); ed.normalizeSegs(); const at = Math.min(j, cols.length - 1); const ln = ed.line(); const k = ln.segs.findIndex(s => Math.abs(s.col - NB[at]) < EPS); ed.caret.seg = k >= 0 ? k : 0; ed.caret.off = 0; ed.caret.vcol = null; ed.anchor = null; });
    return true;
  };
  /* 列の幅：境 k（0..n）を x へ。隣の境と 2 マス以上あける。右端は版面の右端まで */
  T.boundaryRange = function (ed, I, k) { const cols = ed.doc.format.cols; const lo = k === 0 ? 0 : I.B[k - 1] + 2, hi = k === I.n ? cols : I.B[k + 1] - 2; return [lo, hi]; };
  T.moveBoundary = function (ed, I, k, x) {
    const d = ed.doc; const { a, b, B } = I; const [lo, hi] = T.boundaryRange(ed, I, k); x = Math.max(lo, Math.min(hi, Math.round(x * 2) / 2)); const old = B[k]; if (Math.abs(x - old) < EPS) return false;
    ed.mutate('', () => {
      const add = []; for (const r of d.rules) { if (r.axis === 'v' && Math.abs(r.col - old) < EPS && r.from <= b && r.to >= a) { if (r.from < a) add.push({ ...r, id: FZ.uid(), to: a - 1 }); if (r.to > b) add.push({ ...r, id: FZ.uid(), from: b + 1 }); r.from = Math.max(r.from, a); r.to = Math.min(r.to, b); r.col = x; }
        else if (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= I.L - EPS && r.to <= I.R + EPS) { if (Math.abs(r.from - old) < EPS) r.from = x; if (Math.abs(r.to - old) < EPS) r.to = x; } }
      d.rules.push(...add);
      for (let i = a; i <= b; i++) for (const s of d.lines[i].segs) if (Math.abs(s.col - old) < EPS) s.col = x;
      for (const f of d.fills) if (f.from <= b && f.to >= a) { const r2 = f.col + f.cols; if (Math.abs(f.col - old) < EPS) { f.col = x; f.cols = r2 - x; } else if (Math.abs(r2 - old) < EPS) f.cols = x - f.col; }
      d.fills = d.fills.filter(f => f.cols > 0); ed.normalizeSegs();
    });
    return true;
  };

  /* ---------- セルの範囲 { la, lb, ca, cb }（行・列の番号） ---------- */
  T.rectOf = function (ed, p, q) { const I = info(ed, p.line); if (!I || q.line < I.a || q.line > I.b) return null; return { la: Math.min(p.line, q.line), lb: Math.max(p.line, q.line), ca: Math.min(p.col, q.col), cb: Math.max(p.col, q.col), I }; };
  /* 範囲の段（seg）を順に */
  function eachSeg(ed, R, fn) { const d = ed.doc, B = R.I.B; for (let i = R.la; i <= R.lb; i++) { const ln = d.lines[i]; ln.segs.forEach((s, k) => { if (s.col >= B[R.ca] - EPS && s.col < B[R.cb + 1] - EPS) fn(s, k, ln, i); }); } }
  T.eachSeg = eachSeg;
  T.fillCells = (ed, R, shade) => { const B = R.I.B; ed.addFill(R.la, R.lb, B[R.ca], B[R.cb + 1] - B[R.ca], shade); };
  T.alignCells = (ed, R, al) => ed.mutate('', () => eachSeg(ed, R, (s, k, ln) => { const ca = ln.attrs.cellAlign ? ln.attrs.cellAlign.slice() : ln.segs.map(() => null); while (ca.length < ln.segs.length) ca.push(null); ca[k] = al === 'left' ? null : al; ln.attrs.cellAlign = ca; if (!ca.some(Boolean)) delete ln.attrs.cellAlign; }));
  T.clearCells = (ed, R) => ed.mutate('', () => eachSeg(ed, R, s => { s.text = ''; s.marks = []; delete s.links; }));
  T.boldCells = (ed, R) => { let all = true; eachSeg(ed, R, s => { for (const m of s.marks) if (!((m | 0) & M.BOLD)) all = false; }); ed.mutate('', () => eachSeg(ed, R, s => { s.marks = s.marks.map(m => all ? (m & ~M.BOLD) : (m | M.BOLD)); })); return !all; };
  T.cellsText = (ed, R) => { const d = ed.doc, B = R.I.B, out = []; for (let i = R.la; i <= R.lb; i++) { const row = []; for (let j = R.ca; j <= R.cb; j++) { const k = segAt(d, i, B, j); const s = k >= 0 ? d.lines[i].segs[k] : null; row.push(s && Math.abs(s.col - B[j]) < EPS ? s.text : ''); } out.push(row.join('\t')); } return out.join('\n'); };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
