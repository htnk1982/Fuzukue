/* 文机 — 最小の ZIP 書き出し（無圧縮・CRC32・UTF-8 名）。docx / pptx の器に使う */
(function (FZ) {
  'use strict';
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u8) { let c = 0xffffffff; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
  const enc = new TextEncoder();
  /* files: [{ name, data: string|Uint8Array }] → Uint8Array（無圧縮。同期で要る所：試験・作業者） */
  FZ.zip = function (files) { return build(files.map(f => { const data = typeof f.data === 'string' ? enc.encode(f.data) : f.data; return { name: f.name, data, crc: crc32(data), usize: data.length, method: 0 }; })); };
  /* 圧縮つき（deflate-raw、ブラウザの CompressionStream）：XML は 1/10 ほどになる。画像（もう圧縮済み）と、縮まなかったものは無圧縮のまま。CompressionStream が無ければ無圧縮 */
  const canDeflate = (() => { try { return typeof CompressionStream === 'function' && !!new CompressionStream('deflate-raw'); } catch (e) { return false; } })();
  async function deflate(u8) { const cs = new CompressionStream('deflate-raw'); const w = cs.writable.getWriter(); w.write(u8); w.close(); const chunks = []; let n = 0; const r = cs.readable.getReader(); for (;;) { const { done, value } = await r.read(); if (done) break; chunks.push(value); n += value.length; } const out = new Uint8Array(n); let p = 0; for (const c of chunks) { out.set(c, p); p += c.length; } return out; }
  FZ.zipAsync = async function (files) {
    const ents = files.map(f => { const raw = typeof f.data === 'string' ? enc.encode(f.data) : f.data; return { name: f.name, data: raw, crc: crc32(raw), usize: raw.length, method: 0 }; });
    if (canDeflate) { const todo = ents.filter(e => e.usize > 256 && !/\.(png|jpe?g|gif|webp)$/i.test(e.name)); let k = 0; // 4 本ずつ並べて縮める（一度に全部だと流れの作り過ぎで遅くなる）
      await Promise.all([0, 1, 2, 3].map(async () => { while (k < todo.length) { const e = todo[k++]; try { const z = await deflate(e.data); if (z.length < e.usize) { e.data = z; e.method = 8; } } catch (err) { /* 無圧縮のまま */ } } })); }
    return build(ents);
  };
  FZ.zip.canDeflate = canDeflate;
  function build(ents) {
    const parts = [], central = []; let offset = 0;
    const dosTime = (() => { const d = new Date(); return { t: ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xffff, d: (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xffff }; })();
    const u16 = (v) => [v & 0xff, (v >>> 8) & 0xff], u32 = (v) => [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff];
    for (const e of ents) {
      const name = enc.encode(e.name), data = e.data, crc = e.crc, ver = e.method ? 20 : 10;
      const local = new Uint8Array([...u32(0x04034b50), ...u16(ver), ...u16(0x0800), ...u16(e.method), ...u16(dosTime.t), ...u16(dosTime.d), ...u32(crc), ...u32(data.length), ...u32(e.usize), ...u16(name.length), ...u16(0), ...name]);
      parts.push(local, data);
      central.push(new Uint8Array([...u32(0x02014b50), ...u16(20), ...u16(ver), ...u16(0x0800), ...u16(e.method), ...u16(dosTime.t), ...u16(dosTime.d), ...u32(crc), ...u32(data.length), ...u32(e.usize), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset), ...name]));
      offset += local.length + data.length;
    }
    const cdSize = central.reduce((t, c) => t + c.length, 0);
    const end = new Uint8Array([...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(ents.length), ...u16(ents.length), ...u32(cdSize), ...u32(offset), ...u16(0)]);
    const total = offset + cdSize + end.length; const out = new Uint8Array(total); let p = 0;
    for (const x of parts) { out.set(x, p); p += x.length; } for (const x of central) { out.set(x, p); p += x.length; } out.set(end, p);
    return out;
  }
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
