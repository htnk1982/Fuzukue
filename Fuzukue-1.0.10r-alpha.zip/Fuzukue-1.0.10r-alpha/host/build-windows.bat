@echo off
rem Build Fuzukue.exe (single file, uses the Windows built-in WebView2). Requires only Go.
rem   One-time:  winget install GoLang.Go     (then open a NEW cmd window)
setlocal
cd /d "%~dp0"
where go >nul 2>nul || (
  echo Go is not installed. Run:   winget install GoLang.Go
  echo Then close this window, open a new one, and run this file again.
  pause & exit /b 1
)
echo [1/4] copying app files...
if exist app rmdir /s /q app
xcopy /e /i /q ..\app app >nul
echo [2/4] fetching Go modules (first time only)...
go get github.com/jchv/go-webview2@latest golang.org/x/sys@latest || (pause & exit /b 1)
go mod tidy || (pause & exit /b 1)
echo [3/4] embedding icon and manifest...
go run github.com/akavel/rsrc@v0.10.2 -ico app.ico -manifest app.manifest -arch amd64 -o rsrc.syso || echo (icon/manifest skipped)
echo [4/4] building...
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-s -w -H windowsgui" -o ..\Fuzukue.exe . || (pause & exit /b 1)
echo.
echo Done:  %~dp0..\Fuzukue.exe
for %%F in (..\Fuzukue.exe) do echo Size:  %%~zF bytes
pause
