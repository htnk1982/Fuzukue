// 文机（Fuzukue）Windows ホスト：WebView2（Windows 標準）に同梱の編集画面を載せる単一 exe。
// 純 Go（CGO 不要）。ファイル操作はネイティブダイアログと OS のファイル API で行う。
//go:build windows

package main

import (
	"embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"io/fs"
	"log"
	"net/url"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"

	webview2 "github.com/jchv/go-webview2"
	"github.com/jchv/go-webview2/pkg/edge"
	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/registry"
)

//go:embed app
var appFS embed.FS

// 版：同梱の app/js/fz-core.js の FZ.VERSION から読む（exe の版と編集画面の版を食い違わせない）
var appVersion = func() string {
	b, err := appFS.ReadFile("app/js/fz-core.js")
	if err == nil {
		if m := regexp.MustCompile(`FZ\.VERSION = '([^']+)'`).FindSubmatch(b); m != nil {
			return string(m[1])
		}
	}
	return "dev"
}()

// 展開先の名前：版＋同梱ファイルの指紋。同じ版のまま作り直しても、古い展開を使い続けない
func appStamp() string {
	h := fnv.New32a()
	_ = fs.WalkDir(appFS, "app", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		b, err := appFS.ReadFile(p)
		if err != nil {
			return err
		}
		h.Write([]byte(p))
		h.Write(b)
		return nil
	})
	return fmt.Sprintf("%s-%08x", appVersion, h.Sum32())
}

var (
	user32                        = windows.NewLazySystemDLL("user32.dll")
	procMessageBoxW               = user32.NewProc("MessageBoxW")
	procSetProcessDpiAwarenessCtx = user32.NewProc("SetProcessDpiAwarenessContext")
)

func messageBox(text, title string, flags uint32) {
	t, _ := windows.UTF16PtrFromString(text)
	c, _ := windows.UTF16PtrFromString(title)
	procMessageBoxW.Call(0, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), uintptr(flags))
}

// 同梱ファイルを %LOCALAPPDATA%\Fuzukue\app\<version> に展開（無いときだけ）
func extractApp() (string, error) {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "Fuzukue", "app", appStamp())
	marker := filepath.Join(dir, ".complete")
	if _, err := os.Stat(marker); err == nil {
		return dir, nil
	}
	err := fs.WalkDir(appFS, "app", func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel := strings.TrimPrefix(p, "app")
		rel = strings.TrimPrefix(rel, "/")
		target := filepath.Join(dir, filepath.FromSlash(rel))
		if d.IsDir() {
			return os.MkdirAll(target, 0o755)
		}
		data, err := appFS.ReadFile(p)
		if err != nil {
			return err
		}
		return os.WriteFile(target, data, 0o644)
	})
	if err != nil {
		return "", err
	}
	_ = os.WriteFile(marker, []byte("ok"), 0o644)
	return dir, nil
}

func fileURL(p string) string {
	p = filepath.ToSlash(p)
	if !strings.HasPrefix(p, "/") {
		p = "/" + p
	}
	u := url.URL{Scheme: "file", Path: p}
	return u.String()
}

// webview2 パッケージが隠しているブラウザ本体を取り出す（設定変更のため）
func chromiumOf(w webview2.WebView) (ch *edge.Chromium) {
	defer func() {
		if r := recover(); r != nil {
			ch = nil
		}
	}()
	v := reflect.ValueOf(w)
	if v.Kind() == reflect.Ptr {
		v = v.Elem()
	}
	f := v.FieldByName("browser")
	if !f.IsValid() || !f.CanAddr() {
		return nil
	}
	f = reflect.NewAt(f.Type(), unsafe.Pointer(f.UnsafeAddr())).Elem()
	c, _ := f.Interface().(*edge.Chromium)
	return c
}

type fileResult struct {
	Name string `json:"name"`
	Path string `json:"path"`
	Text string `json:"text,omitempty"`
}

type dirEntry struct {
	Name  string `json:"name"`
	Path  string `json:"path"`
	Mtime int64  `json:"mtime"`
	Size  int64  `json:"size"`
}

func main() {
	log.SetFlags(0)
	// 関連付け：Fuzukue.exe --register（.fzk をダブルクリックで開く）／--unregister（元に戻す）。現在のユーザーだけ（管理者権限は不要）
	initialPath := ""
	for _, a := range os.Args[1:] {
		switch strings.ToLower(a) {
		case "--register", "/register":
			if err := registerAssoc(); err != nil {
				messageBox("関連付けできませんでした：\n"+err.Error(), "文机", 0x10)
			} else {
				messageBox(".fzk を文机に関連付けました。\nエクスプローラーで .fzk をダブルクリックすると文机で開きます。\n（exe を別の場所へ移したら、もう一度実行してください）", "文机", 0x40)
			}
			return
		case "--unregister", "/unregister":
			if err := unregisterAssoc(); err != nil {
				messageBox("関連付けを外せませんでした：\n"+err.Error(), "文机", 0x10)
			} else {
				messageBox(".fzk の関連付けを外しました。", "文机", 0x40)
			}
			return
		default:
			if initialPath == "" && !strings.HasPrefix(a, "-") {
				initialPath = a
			}
		}
	}
	// 高 DPI：PER_MONITOR_AWARE_V2
	if procSetProcessDpiAwarenessCtx.Find() == nil {
		procSetProcessDpiAwarenessCtx.Call(^uintptr(3)) // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4
	}
	dir, err := extractApp()
	if err != nil {
		messageBox("編集画面の展開に失敗しました：\n"+err.Error(), "文机", 0x10)
		return
	}
	dataPath := filepath.Join(filepath.Dir(filepath.Dir(dir)), "webview2")
	_ = os.MkdirAll(dataPath, 0o755)

	w := webview2.NewWithOptions(webview2.WebViewOptions{
		Debug:     false,
		AutoFocus: true,
		DataPath:  dataPath,
		WindowOptions: webview2.WindowOptions{
			Title:  "文机",
			Width:  1180,
			Height: 900,
			IconId: 1,
			Center: true,
		},
	})
	if w == nil {
		messageBox("WebView2 ランタイムが見つかりません。\nWindows 11 では標準搭載、Windows 10 では Microsoft Edge の更新で入ります。\nhttps://developer.microsoft.com/microsoft-edge/webview2/ から「Evergreen Bootstrapper」を実行してください。", "文机", 0x10)
		return
	}
	defer w.Destroy()
	hwnd := uintptr(w.Window())
	// 窓の位置と大きさ：前回閉じたときのものに戻す（無い・画面の外なら既定の大きさで真ん中）
	if p := loadPlacement(); p != nil {
		applyPlacement(hwnd, p)
	} else {
		w.SetSize(1180, 900, webview2.HintNone)
	}
	// ブラウザ由来の挙動を抑える：右クリックメニュー、状態バー、Ctrl+ホイール拡大、F5/F3/F12 等のブラウザ用アクセラレータ
	if ch := chromiumOf(w); ch != nil {
		if s, err := ch.GetSettings(); err == nil && s != nil {
			_ = s.PutAreDefaultContextMenusEnabled(false)
			_ = s.PutIsStatusBarEnabled(false)
			_ = s.PutIsZoomControlEnabled(false)
			_ = s.PutAreBrowserAcceleratorKeysEnabled(false)
			_ = s.PutIsPinchZoomEnabled(false)
			_ = s.PutIsSwipeNavigationEnabled(false)
		}
	}

	// ---- JS から呼ぶホスト関数（Promise を返す） ----
	w.Bind("fzHostInfo", func() map[string]string {
		return map[string]string{"host": "go-webview2", "version": appVersion}
	})
	w.Bind("fzOpenFile", func() (*fileResult, error) {
		p := openFileDialog(hwnd, "文机の原本を開く", "文机の原本 (*.fzk;*.txt;*.md;*.json)\x00*.fzk;*.txt;*.md;*.json\x00すべてのファイル (*.*)\x00*.*\x00\x00", "")
		if p == "" {
			return nil, nil
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return nil, err
		}
		return &fileResult{Name: filepath.Base(p), Path: p, Text: string(b)}, nil
	})
	w.Bind("fzSaveFile", func(suggested string) (string, error) {
		filter := "文机の原本 (*.fzk)\x00*.fzk\x00テキスト (*.txt)\x00*.txt\x00Markdown (*.md)\x00*.md\x00\x00"
		switch strings.ToLower(filepath.Ext(suggested)) {
		case ".docx":
			filter = "Word 文書 (*.docx)\x00*.docx\x00\x00"
		case ".pptx":
			filter = "PowerPoint (*.pptx)\x00*.pptx\x00\x00"
		case ".md":
			filter = "Markdown (*.md)\x00*.md\x00\x00"
		case ".txt":
			filter = "テキスト (*.txt)\x00*.txt\x00\x00"
		}
		p := saveFileDialog(hwnd, "保存", filter, suggested)
		return p, nil
	})
	// バイナリ（docx/pptx）：base64 で受け取って書く
	w.Bind("fzWriteBinary", func(p string, b64 string) error {
		b, err := base64.StdEncoding.DecodeString(b64)
		if err != nil {
			return err
		}
		return writeAtomic(p, b, false)
	})
	// 更新日時（ミリ秒）と大きさ：保存の前に「外で書き換えられていないか」を確かめる
	w.Bind("fzStat", func(p string) (map[string]int64, error) {
		fi, err := os.Stat(p)
		if err != nil {
			return nil, err
		}
		return map[string]int64{"mtime": fi.ModTime().UnixMilli(), "size": fi.Size()}, nil
	})
	w.Bind("fzReadFile", func(p string) (string, error) {
		b, err := os.ReadFile(p)
		return string(b), err
	})
	w.Bind("fzWriteFile", func(p string, text string) error {
		return writeAtomic(p, []byte(text), true)
	})
	w.Bind("fzPickFolder", func() (string, error) {
		return browseFolder(hwnd, "文書のフォルダを選ぶ"), nil
	})
	w.Bind("fzListDir", func(p string) ([]dirEntry, error) {
		ents, err := os.ReadDir(p)
		if err != nil {
			return nil, err
		}
		out := []dirEntry{}
		for _, e := range ents {
			if e.IsDir() {
				continue
			}
			n := strings.ToLower(e.Name())
			if !(strings.HasSuffix(n, ".fzk") || strings.HasSuffix(n, ".txt") || strings.HasSuffix(n, ".md")) {
				continue
			}
			info, err := e.Info()
			if err != nil {
				continue
			}
			out = append(out, dirEntry{Name: e.Name(), Path: filepath.Join(p, e.Name()), Mtime: info.ModTime().UnixMilli(), Size: info.Size()})
		}
		return out, nil
	})
	w.Bind("fzConfirm", func(text string) bool {
		t, _ := windows.UTF16PtrFromString(text)
		c, _ := windows.UTF16PtrFromString("文机")
		r, _, _ := procMessageBoxW.Call(hwnd, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), 0x31) // OKCANCEL | WARNING
		return r == 1
	})
	w.Bind("fzSetTitle", func(t string) { w.SetTitle(t) })
	// 閉じる前の確認：［×］・Alt+F4 は画面に問い合わせ（未保存なら保存するか聞く）、画面が決めたら閉じる
	w.Bind("fzCloseAck", func() { closeAcked.Store(true) })
	w.Bind("fzCloseNow", func() {
		allowClose.Store(true)
		procPostMessageW.Call(hwnd, wmClose, 0, 0)
	})
	installCloseGuard(w, hwnd)
	// 起動引数のファイル（ダブルクリック・ドロップで exe に渡されたもの）。一度だけ返す
	w.Bind("fzInitialFile", func() (*fileResult, error) {
		p := initialPath
		initialPath = ""
		if p == "" {
			return nil, nil
		}
		if abs, err := filepath.Abs(p); err == nil {
			p = abs
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return nil, err
		}
		return &fileResult{Name: filepath.Base(p), Path: p, Text: string(b)}, nil
	})

	// 起動前に注入：ホストの存在を知らせる
	w.Init("window.fzHost = { kind: 'go-webview2', version: " + jsonString(appVersion) + " };")
	w.Navigate(fileURL(filepath.Join(dir, "index.html")))
	w.Run()
}

// ---------- 関連付け（HKCU\Software\Classes） ----------
const progID = "Fuzukue.Document"

func setKey(path, name, value string) error {
	k, _, err := registry.CreateKey(registry.CURRENT_USER, path, registry.SET_VALUE)
	if err != nil {
		return err
	}
	defer k.Close()
	return k.SetStringValue(name, value)
}

var (
	shell32Assoc       = windows.NewLazySystemDLL("shell32.dll")
	procSHChangeNotify = shell32Assoc.NewProc("SHChangeNotify")
)

func registerAssoc() error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	if abs, err := filepath.Abs(exe); err == nil {
		exe = abs
	}
	// 文書のアイコン（白地に黒の「文」）：同梱の画像を版に左右されない場所へ書き出して指す
	fileIcon := `"` + exe + `",0`
	if b, err := appFS.ReadFile("app/img/fuzukue_file.ico"); err == nil {
		base := os.Getenv("LOCALAPPDATA")
		if base == "" {
			base = os.TempDir()
		}
		dir := filepath.Join(base, "Fuzukue")
		_ = os.MkdirAll(dir, 0o755)
		p := filepath.Join(dir, "fuzukue_file.ico")
		if err := os.WriteFile(p, b, 0o644); err == nil {
			fileIcon = `"` + p + `"`
		}
	}
	cls := `Software\Classes\`
	steps := [][3]string{
		{cls + `.fzk`, "", progID},
		{cls + `.fzk\OpenWithProgids`, progID, ""},
		{cls + progID, "", "文机の原本"},
		{cls + progID + `\DefaultIcon`, "", fileIcon},
		{cls + progID + `\shell\open`, "", "文机で開く"},
		{cls + progID + `\shell\open\command`, "", `"` + exe + `" "%1"`},
		{cls + `Applications\` + filepath.Base(exe) + `\shell\open\command`, "", `"` + exe + `" "%1"`},
		{cls + `Applications\` + filepath.Base(exe) + `\SupportedTypes`, ".fzk", ""},
		{cls + `Applications\` + filepath.Base(exe) + `\SupportedTypes`, ".md", ""},
		{cls + `Applications\` + filepath.Base(exe) + `\SupportedTypes`, ".txt", ""},
	}
	for _, s := range steps {
		if err := setKey(s[0], s[1], s[2]); err != nil {
			return err
		}
	}
	procSHChangeNotify.Call(0x08000000, 0, 0, 0) // SHCNE_ASSOCCHANGED：アイコンを更新
	return nil
}

func deleteTree(root registry.Key, path string) error {
	k, err := registry.OpenKey(root, path, registry.ENUMERATE_SUB_KEYS)
	if err != nil {
		return nil // 無ければ何もしない
	}
	names, _ := k.ReadSubKeyNames(-1)
	k.Close()
	for _, n := range names {
		if err := deleteTree(root, path+`\`+n); err != nil {
			return err
		}
	}
	return registry.DeleteKey(root, path)
}

func unregisterAssoc() error {
	exe, _ := os.Executable()
	cls := `Software\Classes\`
	// .fzk が文机を指しているときだけ外す（他のアプリに付け替えていたら触らない）
	if k, err := registry.OpenKey(registry.CURRENT_USER, cls+`.fzk`, registry.QUERY_VALUE); err == nil {
		v, _, _ := k.GetStringValue("")
		k.Close()
		if v == progID {
			if err := deleteTree(registry.CURRENT_USER, cls+`.fzk`); err != nil {
				return err
			}
		}
	}
	if err := deleteTree(registry.CURRENT_USER, cls+progID); err != nil {
		return err
	}
	if exe != "" {
		_ = deleteTree(registry.CURRENT_USER, cls+`Applications\`+filepath.Base(exe))
	}
	procSHChangeNotify.Call(0x08000000, 0, 0, 0)
	return nil
}

// ---------- 閉じる前の確認（窓のプロシージャを差し替えて WM_CLOSE を先に受ける） ----------
const wmClose = 0x0010

var (
	procCallWindowProcW   = user32.NewProc("CallWindowProcW")
	procSetWindowLongPtrW = user32.NewProc("SetWindowLongPtrW")
	procPostMessageW      = user32.NewProc("PostMessageW")
	origWndProc           uintptr
	allowClose            atomic.Bool // 画面が「閉じてよい」と言った
	closeAcked            atomic.Bool // 画面が問い合わせを受け取った
	closeAskedAt          time.Time   // 最後に問い合わせた時刻（窓のスレッドだけが触る）
)

func installCloseGuard(w webview2.WebView, hwnd uintptr) {
	cb := syscall.NewCallback(func(h, msg, wp, lp uintptr) uintptr {
		if msg == wmClose && allowClose.Load() {
			savePlacement(h) // 閉じる直前の位置と大きさを覚える
		}
		if msg == wmClose && !allowClose.Load() {
			// 画面が応答しない（問い合わせて 3 秒たっても受け取りの返事が無い）ときは、2 度目の［×］でそのまま閉じる
			if !closeAskedAt.IsZero() && !closeAcked.Load() && time.Since(closeAskedAt) > 3*time.Second {
				allowClose.Store(true)
				savePlacement(h)
			} else {
				closeAskedAt = time.Now()
				closeAcked.Store(false)
				w.Eval("window.fzRequestClose ? window.fzRequestClose() : (window.fzCloseNow && window.fzCloseNow())")
				return 0
			}
		}
		r, _, _ := procCallWindowProcW.Call(origWndProc, h, msg, wp, lp)
		return r
	})
	gwlpWndProc := -4
	origWndProc, _, _ = procSetWindowLongPtrW.Call(hwnd, uintptr(gwlpWndProc), cb)
}

// ---------- 窓の位置と大きさを覚える ----------
// 閉じるときに GetWindowPlacement の「普通の大きさの位置」と最大化を %LOCALAPPDATA%\Fuzukue\window.json に書き、次の起動で戻す。
// 画面の構成が変わって窓がどの画面にも掛からないときは使わない。2 つ目の起動は、開いている文机の窓の数だけ少しずらす
var (
	procGetWindowPlacement = user32.NewProc("GetWindowPlacement")
	procSetWindowPlacement = user32.NewProc("SetWindowPlacement")
	procMonitorFromRect    = user32.NewProc("MonitorFromRect")
	procFindWindowExW      = user32.NewProc("FindWindowExW")
)

type winRect struct{ Left, Top, Right, Bottom int32 }
type winPoint struct{ X, Y int32 }
type windowPlacement struct {
	Length  uint32
	Flags   uint32
	ShowCmd uint32
	MinPos  winPoint
	MaxPos  winPoint
	Normal  winRect
}
type savedPlacement struct {
	Left      int32 `json:"left"`
	Top       int32 `json:"top"`
	Right     int32 `json:"right"`
	Bottom    int32 `json:"bottom"`
	Maximized bool  `json:"maximized"`
}

func placementFile() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	return filepath.Join(base, "Fuzukue", "window.json")
}

func loadPlacement() *savedPlacement {
	b, err := os.ReadFile(placementFile())
	if err != nil {
		return nil
	}
	var p savedPlacement
	if json.Unmarshal(b, &p) != nil || p.Right-p.Left < 400 || p.Bottom-p.Top < 300 {
		return nil
	}
	r := winRect{p.Left, p.Top, p.Right, p.Bottom}
	if m, _, _ := procMonitorFromRect.Call(uintptr(unsafe.Pointer(&r)), 0); m == 0 { // MONITOR_DEFAULTTONULL
		return nil
	}
	return &p
}

func savePlacement(hwnd uintptr) {
	var wp windowPlacement
	wp.Length = uint32(unsafe.Sizeof(wp))
	if r, _, _ := procGetWindowPlacement.Call(hwnd, uintptr(unsafe.Pointer(&wp))); r == 0 {
		return
	}
	n := wp.Normal
	if n.Right-n.Left < 400 || n.Bottom-n.Top < 300 {
		return
	}
	maxed := wp.ShowCmd == 3 || (wp.ShowCmd == 2 && wp.Flags&2 != 0) // 最大化のまま、または最大化から最小化した（WPF_RESTORETOMAXIMIZED）
	b, err := json.Marshal(savedPlacement{n.Left, n.Top, n.Right, n.Bottom, maxed})
	if err != nil {
		return
	}
	_ = os.MkdirAll(filepath.Dir(placementFile()), 0o755)
	_ = os.WriteFile(placementFile(), b, 0o644)
}

func applyPlacement(hwnd uintptr, p *savedPlacement) {
	others := int32(0) // ほかに開いている文机の窓（同じ窓の種類）の数
	cls, _ := windows.UTF16PtrFromString("webview")
	for h := uintptr(0); ; {
		h, _, _ = procFindWindowExW.Call(0, h, uintptr(unsafe.Pointer(cls)), 0)
		if h == 0 {
			break
		}
		if h != hwnd {
			others++
		}
	}
	d := 32 * (others % 8)
	var wp windowPlacement
	wp.Length = uint32(unsafe.Sizeof(wp))
	wp.ShowCmd = 1 // SW_SHOWNORMAL
	if p.Maximized && others == 0 {
		wp.ShowCmd = 3 // SW_SHOWMAXIMIZED
	}
	wp.Normal = winRect{p.Left + d, p.Top + d, p.Right + d, p.Bottom + d}
	procSetWindowPlacement.Call(hwnd, uintptr(unsafe.Pointer(&wp)))
}

func jsonString(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}

// ---------- ネイティブダイアログ（comdlg32 / shell32） ----------
var (
	comdlg32              = windows.NewLazySystemDLL("comdlg32.dll")
	procGetOpenFileNameW  = comdlg32.NewProc("GetOpenFileNameW")
	procGetSaveFileNameW  = comdlg32.NewProc("GetSaveFileNameW")
	shell32               = windows.NewLazySystemDLL("shell32.dll")
	procSHBrowseForFolder = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDL  = shell32.NewProc("SHGetPathFromIDListW")
	ole32                 = windows.NewLazySystemDLL("ole32.dll")
	procCoTaskMemFree     = ole32.NewProc("CoTaskMemFree")
)

type openFileNameW struct {
	lStructSize       uint32
	hwndOwner         uintptr
	hInstance         uintptr
	lpstrFilter       *uint16
	lpstrCustomFilter *uint16
	nMaxCustFilter    uint32
	nFilterIndex      uint32
	lpstrFile         *uint16
	nMaxFile          uint32
	lpstrFileTitle    *uint16
	nMaxFileTitle     uint32
	lpstrInitialDir   *uint16
	lpstrTitle        *uint16
	flags             uint32
	nFileOffset       uint16
	nFileExtension    uint16
	lpstrDefExt       *uint16
	lCustData         uintptr
	lpfnHook          uintptr
	lpTemplateName    *uint16
	pvReserved        uintptr
	dwReserved        uint32
	flagsEx           uint32
}

const (
	ofnOverwritePrompt = 0x00000002
	ofnHideReadOnly    = 0x00000004
	ofnNoChangeDir     = 0x00000008
	ofnPathMustExist   = 0x00000800
	ofnFileMustExist   = 0x00001000
	ofnExplorer        = 0x00080000
)

// NUL 区切りのフィルタ文字列を UTF-16 へ（syscall.StringToUTF16 は NUL を含む文字列で panic するため自前で）
func utf16Filter(f string) *uint16 {
	u := utf16.Encode([]rune(f))
	u = append(u, 0)
	return &u[0]
}

func openFileDialog(hwnd uintptr, title, filter, initial string) string {
	buf := make([]uint16, 32768)
	if initial != "" {
		if u, err := windows.UTF16FromString(initial); err == nil {
			copy(buf, u)
		}
	}
	ofn := openFileNameW{}
	ofn.lStructSize = uint32(unsafe.Sizeof(ofn))
	ofn.hwndOwner = hwnd
	ofn.lpstrFilter = utf16Filter(filter)
	ofn.nFilterIndex = 1
	ofn.lpstrFile = &buf[0]
	ofn.nMaxFile = uint32(len(buf))
	ofn.lpstrTitle, _ = windows.UTF16PtrFromString(title)
	ofn.flags = ofnExplorer | ofnFileMustExist | ofnPathMustExist | ofnHideReadOnly | ofnNoChangeDir
	r, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

func saveFileDialog(hwnd uintptr, title, filter, suggested string) string {
	buf := make([]uint16, 32768)
	if suggested != "" {
		if u, err := windows.UTF16FromString(suggested); err == nil {
			copy(buf, u)
		}
	}
	ofn := openFileNameW{}
	ofn.lStructSize = uint32(unsafe.Sizeof(ofn))
	ofn.hwndOwner = hwnd
	ofn.lpstrFilter = utf16Filter(filter)
	ofn.nFilterIndex = 1
	ofn.lpstrFile = &buf[0]
	ofn.nMaxFile = uint32(len(buf))
	ofn.lpstrTitle, _ = windows.UTF16PtrFromString(title)
	ofn.lpstrDefExt, _ = windows.UTF16PtrFromString("fzk")
	ofn.flags = ofnExplorer | ofnOverwritePrompt | ofnPathMustExist | ofnHideReadOnly | ofnNoChangeDir
	r, _, _ := procGetSaveFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

type browseInfoW struct {
	hwndOwner      uintptr
	pidlRoot       uintptr
	pszDisplayName *uint16
	lpszTitle      *uint16
	ulFlags        uint32
	lpfn           uintptr
	lParam         uintptr
	iImage         int32
}

func browseFolder(hwnd uintptr, title string) string {
	disp := make([]uint16, 260)
	bi := browseInfoW{hwndOwner: hwnd, pszDisplayName: &disp[0], ulFlags: 0x1 | 0x40 | 0x10} // RETURNONLYFSDIRS | NEWDIALOGSTYLE | EDITBOX
	bi.lpszTitle, _ = windows.UTF16PtrFromString(title)
	pidl, _, _ := procSHBrowseForFolder.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return ""
	}
	defer procCoTaskMemFree.Call(pidl)
	buf := make([]uint16, 32768)
	r, _, _ := procSHGetPathFromIDL.Call(pidl, uintptr(unsafe.Pointer(&buf[0])))
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

// writeAtomic：一時ファイルに書いて、ディスクに落としてから（Sync）名前を付け替える。
// 書いている途中で電源が落ちても、元のファイルが半端に壊れることはない（元のまま残るか、新しい中身になるか）。
// keepBak：原本の上書きでは、直前の中身を「名前.bak」として 1 世代残す（専用機の「置き換え文書復元」）
func writeAtomic(p string, b []byte, keepBak bool) error {
	tmp := p + ".tmp~"
	f, err := os.OpenFile(tmp, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o644)
	if err != nil {
		return err
	}
	if _, err := f.Write(b); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}
	if err := f.Close(); err != nil {
		os.Remove(tmp)
		return err
	}
	if keepBak {
		if _, err := os.Stat(p); err == nil {
			bak := p + ".bak"
			os.Remove(bak)
			if err := os.Rename(p, bak); err == nil {
				if err := os.Rename(tmp, p); err != nil {
					os.Rename(bak, p) // 付け替えに失敗したら元に戻す
					os.Remove(tmp)
					return err
				}
				return nil
			}
		}
	}
	return os.Rename(tmp, p)
}
