/* 書き出し例を作り直す：samples/見本.fzk → samples/書き出し例/見本.docx・.pptx・.md（Word・PowerPoint は圧縮つき） */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const fs = require('fs'), path = require('path'); const FZ = globalThis.FZ;
(async () => { const dir = path.resolve(__dirname, '../samples'); const names = process.argv.slice(2).length ? process.argv.slice(2) : ['見本'];
  for (const n of names) { const d = FZ.parse(fs.readFileSync(path.join(dir, n + '.fzk'), 'utf8')); const out = path.join(dir, '書き出し例');
    fs.writeFileSync(path.join(out, n + '.docx'), await FZ.zipAsync(FZ.toDocx(d, { files: true }))); fs.writeFileSync(path.join(out, n + '.pptx'), await FZ.zipAsync(FZ.toPptx(d, { files: true }))); fs.writeFileSync(path.join(out, n + '.md'), FZ.toGfm(d)); console.log(n, 'docx・pptx・md'); } })();
