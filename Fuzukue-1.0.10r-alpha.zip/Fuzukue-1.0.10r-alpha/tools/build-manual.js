/* 取扱説明書.fzk を作る：画面（app/index.html）を開き、F1 の取説と同じ中身から原本を書き出して samples/ に置く。
 * キーはメニューの表から引くので、割り当てを変えたら走らせ直す（tools/dist.sh も走らせる。test-110c が古さを見張る） */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage();
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(300);
  const text = await page.evaluate(() => { localStorage.clear(); return FZ.manualText(); });
  const out = path.resolve(__dirname, '../samples/取扱説明書.fzk'); fs.writeFileSync(out, text);
  console.log('取扱説明書.fzk', text.split('\n').length, '行'); await browser.close();
})();
