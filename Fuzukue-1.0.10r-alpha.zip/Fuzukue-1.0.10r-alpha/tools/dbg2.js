const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  const r = await page.evaluate(() => {
    localStorage.clear(); const ed = FZ.app.ed; const d = FZ.newDoc(); d.lines = ['一', '二行目です', '三'].map(t => FZ.newLine(t)); ed.setDoc(d); ed.addFill(1, 1, 0, 20, 'dark'); FZ.app.render();
    const pg = ed.lay.pages[0]; const svg = document.querySelector('.pgwrap svg').innerHTML;
    return { fills: pg.fills, hasWh: svg.includes('wh'), snippet: svg.slice(svg.indexOf('<g class="txt">'), svg.indexOf('<g class="txt">') + 400) };
  });
  console.log(JSON.stringify(r, null, 1));
  // autoCellify debug
  const r2 = await page.evaluate(() => {
    const ed = FZ.app.ed; const d = FZ.newDoc(); d.lines = ['', '', ''].map(t => FZ.newLine(t)); ed.setDoc(d);
    ed.mutate('', () => { ed.addHRule(0, 0, 8); ed.addHRule(2, 0, 8); ed.addVRule(0, 1, 0); ed.addVRule(0, 1, 8); }); FZ.app.render();
    ed.setCaret({ line: 0, seg: 0, off: 0, vcol: 2 });
    return { vr: FZ.vRulesAt(ed.doc, 0).map(r => r.col + ':' + r.from + '-' + r.to), cells: FZ.cellsAt(ed.doc, 0), inTable: FZ.inTable(ed.doc, 0), attrs: ed.line().attrs };
  });
  console.log(JSON.stringify(r2));
  await page.keyboard.type('開');
  console.log(await page.evaluate(() => ({ attrs: FZ.app.ed.doc.lines[0].attrs, segs: FZ.app.ed.doc.lines[0].segs.map(s => s.col + ':' + s.text) })));
  await browser.close();
})();
