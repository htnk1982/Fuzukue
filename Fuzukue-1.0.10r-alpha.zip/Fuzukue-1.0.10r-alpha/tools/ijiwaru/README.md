# いじわるテスト（adversarial tests）

壊れた入力・境界値・意地悪な組合せを与えて、例外・データ消失・意味の変化を拾う。合否判定ではなく観察用（結果は 結果-*.json に落ちる）。

- `node tools/ijiwaru/md.js [case]`   … GFM 読み込み → fzk2 → 再解析 → GFM 書き出し → 再読み込み（73 件）
- `node tools/ijiwaru/fzk.js`         … fzk 2 解析器に壊れた原本を与える（27 件）
- `node tools/ijiwaru/office.js [dir]`… Office 書き出しの XML 妥当性（制御文字・URL・空文書・20 列表など）
- `node tools/ijiwaru/app.js`         … アプリ（Playwright）：貼付の誤爆、表題化、リンク編集の境界、巨大文書の応答

所見と対策は いじわるテスト報告.md を参照。
