/* いじわるテスト 4：アプリ側（貼付の誤爆、表題化、リンク編集の境界、巨大文書の反応、取消） */
const { chromium } = require('playwright');
const S = __dirname;
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + require('path').resolve(__dirname, '../../app/index.html') + ''); await page.waitForTimeout(400);
  const log = (...a) => console.log(...a);
  const reset = () => page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); FZ.app.ed.setDoc(d); FZ.app.render(); });
  const paste = (text) => page.evaluate((md) => { const dt = new DataTransfer(); dt.setData('text/plain', md); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, text);
  const dump = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => JSON.stringify(l.attrs) + '|' + l.segs.map(s => s.text).join('⟨桁⟩')));

  // 1. メール本文風のプレーンテキスト（1 行に「- 」がある）を貼る → 行が結合されるか
  await reset();
  await paste('山田様\nお世話になっております。\n下記の件、ご確認ください。\n- 納期：11/5\n以上、よろしくお願いします。\n');
  await page.waitForTimeout(60); log('--- 1 mail paste'); log((await dump()).join('\n'));

  // 2. 文書の途中に「# 見出し」1 つの Markdown を貼る → 表題になるか
  await reset();
  await page.evaluate(() => { FZ.app.ed.insertText('既存の本文'); FZ.app.ed.enter(); });
  await paste('# 章の見出し\n\n本文です。\n');
  await page.waitForTimeout(60); log('--- 2 paste heading mid-doc'); log((await dump()).join('\n')); log('title=', await page.evaluate(() => FZ.app.ed.doc.title));

  // 3. 引用行の上に Markdown を貼る／表の中に貼る
  await reset();
  await page.evaluate(() => { FZ.app.ed.insertText('引用の行'); FZ.app.ed.cycleQuote(); FZ.app.ed.setCaret({ line: 0, seg: 0, off: 4 }); });
  await paste('- a\n- b\n');
  await page.waitForTimeout(60); log('--- 3 paste into quote'); log((await dump()).join('\n'));

  // 4. リンクの境界：リンク直前・直後に入力、リンク全体を選択して削除、行分割、取消
  await reset();
  await paste('前 [リンク](https://x.jp) 後\n\n- 2行目\n'); await page.waitForTimeout(60);
  const lk0 = await page.evaluate(() => FZ.app.ed.doc.lines[0].segs[0].links[0]); log('--- 4 link', JSON.stringify(lk0));
  await page.evaluate((l) => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: l.start }); FZ.app.flush(); }, lk0); await page.keyboard.type('X'); await page.waitForTimeout(30);
  let s = await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; return { text: s.text, links: s.links, lm: s.marks.map(m => m & FZ.M.LINK ? 'L' : '.').join('') }; }); log('type at start:', JSON.stringify(s));
  await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; FZ.app.ed.setCaret({ line: 0, seg: 0, off: s.links[0].end }); FZ.app.flush(); }); await page.keyboard.type('Y'); await page.waitForTimeout(30);
  s = await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; return { text: s.text, links: s.links, lm: s.marks.map(m => m & FZ.M.LINK ? 'L' : '.').join('') }; }); log('type at end:', JSON.stringify(s));
  // 行分割（リンクの中で Enter）
  await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; FZ.app.ed.setCaret({ line: 0, seg: 0, off: s.links[0].start + 1 }); FZ.app.flush(); }); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  log('after split:', (await page.evaluate(() => FZ.app.ed.doc.lines.slice(0, 2).map(l => JSON.stringify({ t: l.segs[0].text, links: l.segs[0].links, lm: l.segs[0].marks.map(m => m & FZ.M.LINK ? 'L' : '.').join('') })))).join('\n'));
  await page.keyboard.press('Backspace'); await page.waitForTimeout(30);
  log('after join:', await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; return JSON.stringify({ t: s.text, links: s.links, lm: s.marks.map(m => m & FZ.M.LINK ? 'L' : '.').join('') }); }));
  // 取消を全部戻す
  for (let k = 0; k < 10; k++) await page.keyboard.press('Control+z'); await page.waitForTimeout(30);
  log('after undo x10:', (await dump()).slice(0, 2).join(' / '));
  // リンク文字を全選択して削除 → リンクが残骸として残らないか
  await reset(); await paste('前 [リンク](https://x.jp) 後\n\n- 2行目\n'); await page.waitForTimeout(60);
  await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; const l = s.links[0]; FZ.app.ed.setCaret({ line: 0, seg: 0, off: l.start }); FZ.app.ed.anchor = { line: 0, seg: 0, off: l.end }; FZ.app.flush(); });
  await page.keyboard.press('Delete'); await page.waitForTimeout(30);
  log('after delete link text:', await page.evaluate(() => { const s = FZ.app.ed.doc.lines[0].segs[0]; return JSON.stringify({ t: s.text, links: s.links, lm: s.marks.map(m => m & FZ.M.LINK ? 'L' : '.').join('') }); }));
  // 5. 表の中で Markdown 貼付・リンク設定・引用切替
  await reset();
  await paste('| a | b |\n|---|---|\n| 1 | 2 |\n'); await page.waitForTimeout(60);
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 1, seg: 0, off: 1 }); FZ.app.flush(); });
  await page.keyboard.press('F6'); await page.keyboard.press('o'); await page.waitForTimeout(30);
  await page.keyboard.press('F6'); await page.keyboard.press('p'); await page.waitForTimeout(30);
  log('--- 5 quote/code on table row:', (await dump()).slice(0, 3).join('\n'));
  await paste('- x\n- y\n'); await page.waitForTimeout(60); log('paste list into table:', (await dump()).join('\n'));
  // 6. 巨大 Markdown 貼付の時間と、その後の 1 文字入力の時間
  await reset();
  const big = Array.from({ length: 1500 }, (_, i) => (i % 10 === 0 ? `## 見出し ${i}` : i % 10 === 5 ? `- 項目 ${i}\n  - 子 ${i}` : `段落 ${i} の本文です。**強調**と[リンク](https://x.jp/${i})を含みます。`)).join('\n\n');
  let t0 = Date.now(); await paste(big); await page.waitForFunction(() => FZ.app.ed.doc.lines.length > 1000); await page.evaluate(() => FZ.app.flush()); const tPaste = Date.now() - t0;
  const nl = await page.evaluate(() => FZ.app.ed.doc.lines.length);
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 500, seg: 0, off: 2 }); FZ.app.flush(); });
  t0 = Date.now(); await page.keyboard.type('あいうえお'); await page.evaluate(() => FZ.app.flush()); const tType = Date.now() - t0;
  t0 = Date.now(); await page.evaluate(() => FZ.toGfm(FZ.app.ed.doc)); const tMd = Date.now() - t0;
  t0 = Date.now(); await page.evaluate(() => FZ.serialize(FZ.app.ed.doc)); const tFzk = Date.now() - t0;
  t0 = Date.now(); const dl = await page.evaluate(() => FZ.toDocx(FZ.app.ed.doc).length); const tDocx = Date.now() - t0;
  log(`--- 6 big: lines=${nl} paste=${tPaste}ms type5=${tType}ms toGfm=${tMd}ms serialize=${tFzk}ms docx=${tDocx}ms (${dl} bytes)`);
  // 7. 引用を 9 回押す／コード行で Tab／項目で引用
  await reset(); await page.evaluate(() => { FZ.app.ed.insertText('x'); FZ.app.flush(); });
  for (let k = 0; k < 10; k++) { await page.keyboard.press('F6'); await page.keyboard.press('o'); }
  await page.waitForTimeout(30); log('--- 7 quote x10:', (await dump())[0]);
  await page.keyboard.press('F6'); await page.keyboard.press('p'); await page.keyboard.press('Tab'); await page.waitForTimeout(30); log('code+tab:', (await dump())[0]);
  // 8. 「[重要]」で始まる段落を保存→開く
  await reset(); await page.evaluate(() => { FZ.app.ed.insertText('[重要]この件は至急'); FZ.app.ed.enter(); FZ.app.ed.insertText('#ハッシュタグ で始まる行'); FZ.app.ed.enter(); FZ.app.ed.insertText('C:\\Users\\yuta\\文書'); FZ.app.ed.enter(); FZ.app.ed.insertText('| で始まる行'); FZ.app.flush(); });
  const fzk = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc)); log('--- 8 fzk:\n' + fzk.split('\n---\n')[1]);
  const back = await page.evaluate((t) => FZ.parse(t).lines.map(l => l.segs[0].text), fzk); log('back:', JSON.stringify(back));
  await page.screenshot({ path: S + '/ij4.png', clip: { x: 0, y: 0, width: 1180, height: 400 } });
  console.log('errors:', errors);
  await browser.close();
})();
