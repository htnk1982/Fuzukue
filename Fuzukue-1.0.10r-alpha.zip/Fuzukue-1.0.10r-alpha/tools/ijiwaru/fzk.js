// いじわるテスト 2：fzk 2 の解析器に壊れた・意地悪な入力を与える
for (const f of ['fz-core','fz-figure','fz-styles','fz-entities','fz-md','fz-gfm','fz-zip','fz-export','fz-docx','fz-pptx']) require(__dirname + '/../../app/js/' + f + '.js');
const FZ = globalThis.FZ;
const H = '#fzk 2\n題名: t\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n';
const cases = {
  noHeader: '#fzk 2\n本文だけ',
  noSep: '#fzk 2\n題名: x\n本文',
  headerOnly: '#fzk 2\n題名: x\n---\n',
  v1: '#fzk 1\n題名: v1\n---\n<太>太い</太><桁10>二列目',
  unknownKeys: '#fzk 2\n謎の鍵: 値\n題名: 値:コロン入り\n文字数: abc\n行数: -5\n用紙: B9 斜め\n余白: 1 2\n階層: ほげ ふが\n開始階層: 99\n---\n本文',
  weirdNumbers: H + '[項目99]深すぎ\n[項目0]ゼロ\n[引用99]深い引用\n[段組99]段組\n[字下げ999]字下げ\n[図0]\n[図-1]\n[列揃え左右左右左右左右左右左右]表外',
  conflict: H + '[中央 右 均等]揃え競合\n[項目1 見出し]項目かつ見出し\n[引用 コード 項目2]全部\n[表題 表題]重複\n[続き1]親なし続き\n[再開5]項目でない再開',
  unknownTokens: H + '[謎 とくべつ 項目1]未知トークン\n[]空属性\n[ ]空白属性\n[項目1 ]末尾空白',
  tagsBroken: H + '<太字>閉じない\n</太字>開いてない\n<太字><傍点>交差</太字></傍点>\n<太字>二重<太字>太字</太字>まだ太字？</太字>\n<リンク>URLなし</リンク>\n<リンク https://x.jp>閉じないリンク\n<リンク https://a.jp>外<リンク https://b.jp>内</リンク>外</リンク>\n<画像 a.png></画像>\n<謎タグ>未知</謎タグ>\n< 太字>空白入り</ 太字>\n<太字 >後ろ空白</太字 >\n<桁3.7>小数桁\n<桁999>範囲外桁\n<桁5>前<桁2>逆順\n',
  escapes: H + '\\\\バックスラッシュ\n\\[角括弧]\n\\<山\n\\|パイプ\n末尾バックスラッシュ\\\n\\x 未知のエスケープ\n\\#井桁\n\\\\<太字>エスケープ後にタグ</太字>\n',
  badUrl: H + '<リンク https://x.jp/%E4>壊れた%</リンク>\n<リンク https://x.jp/%ZZ>非16進</リンク>\n<リンク javascript:alert(1)>JS</リンク>\n<リンク data:text/html,<b>x</b>>データ</リンク>\n<リンク file:///C:/Windows>ファイル</リンク>\n<リンク ' + 'x'.repeat(3000) + '>長い</リンク>\n',
  tableBroken: H + '#表\n| 列なし |\n#表 列 0 様式 格子\n| 一つだけ |\n#表 列 40,0,10 様式 謎様式 見出し謎\n| a | b |\n| a | b | c | d |\n| a |\n#列 0,5\n| 列上書き | はみ出し |\n#列 abc\n| 壊れた列 |\n#表 列 0,10,20\n[見出し]| 見出し属性の行 |\n#表 列 0,10,20\n行がない\n#表 列 0,10,20\n#表 列 0,10,20\n| 連続 |\n',
  tableNested: H + '#表 列 0,10,20 様式 格子\n| <太字>a | b</太字> |\n| <リンク https://x.jp>l \\| r</リンク> | \\| |\n| <桁5>桁タグ | x |\n',
  articleBroken: H + '#囲み ×0\n題\n#囲み ×99\n題\n本文\n#囲み ×2\n',
  rulesBroken: H + '#罫 横 50-10 細\n本文\n#罫 横 -5-999 謎\n本文\n#罫 縦 99 ×0 細\n#罫 縦 0 ×-1 細\n#網 10-5 ×2 謎\n#網 0-40 ×999 薄\n本文\n#罫 横 0-40 矢印↑\n#罫 縦 5 ×3 矢印→\n',
  figureBroken: H + '#箱 1 0,0 0x0 細 無 ゼロ箱\n#箱 1 0,0 5x2 細 無 重複ID\n#箱 abc 1,1 5x2 細 無 非数ID\n#箱 2 100,100 5x2 細 無 画面外\n#矢印 1→99 細\n#矢印 99→1 細\n#矢印 1→1 細 自己\n#レーン 縦 0 L\n[図3]\n#箱 1 0,0 5x2 細 無 図なし\n本文\n',
  decoBroken: H + '[見出し 飾り:存在しない]x\n[飾り:ベタ白抜き]見出しでない行に飾り\n[見出し 飾り:ベタ白抜き 飾り:罫囲み]二重飾り\n',
  hashLines: H + '#コメント？\n# 見出し風\n#fzk 2\n#表\n#謎 指示\n本文',
  longDoc: H + Array.from({length: 20000}, (_, i) => (i % 7 === 0 ? '[見出し]' : i % 11 === 0 ? '[項目1]' : '') + 'あ'.repeat(30 + (i % 20))).join('\n'),
  giantLine: H + 'あ'.repeat(200000),
  manyRules: H + Array.from({length: 3000}, () => '#罫 横 0-40 細\n本文').join('\n'),
  crlfTabs: '#fzk 2\r\n題名: x\r\n---\r\n本文\t タブ\r\n\t[見出し]タブ始まり\r\n',
  bomV2: '\uFEFF#fzk 2\n---\n本文',
  nullBytes: H + '本文\u0000ヌル\u0001制御',
  fullwidthAttrs: H + '［見出し］全角括弧\n[見出し　中央]全角空白区切り\n[項目１]全角数字\n',
  linkInHeading: H + '[見出し]<リンク https://x.jp>リンク見出し</リンク>\n[表題 中央]<傍点>傍点の表題</傍点>\n',
  cellAttr: H + '[セル]単独セル\n[セル 中央]a<桁10>b\n',
};
const results = [];
for (const [k, v] of Object.entries(cases)) {
  const r = { name: k }; const t0 = Date.now();
  try {
    const doc = FZ.parse(v); r.lines = doc.lines.length; r.rules = doc.rules.length;
    const s1 = FZ.serialize(doc); const doc2 = FZ.parse(s1); const s2 = FZ.serialize(doc2); r.stable = s1 === s2; r.fzk = s1; if (!r.stable) r.s2 = s2;
    const lay = FZ.layout(doc2); r.pages = lay.pages.length;
    const md = FZ.toGfm(doc2); r.md = md; FZ.fromGfm(md);
    if (k !== 'longDoc' && k !== 'giantLine' && k !== 'manyRules') { FZ.toDocx(doc2); FZ.toPptx(doc2); }
  } catch (e) { r.error = (e && e.stack || String(e)).split('\n').slice(0, 3).join(' | '); }
  r.ms = Date.now() - t0; results.push(r);
  console.log(`${r.error ? 'ERR ' : 'ok  '}${k.padEnd(16)} lines=${r.lines} rules=${r.rules} pages=${r.pages} stable=${r.stable} ${r.ms}ms${r.error ? '\n   ' + r.error : ''}`);
}
require('fs').writeFileSync(__dirname + '/結果-' + require('path').basename(__filename, '.js') + '.json', JSON.stringify(results.map(r => ({ ...r, fzk: r.fzk && r.fzk.length > 20000 ? r.fzk.slice(0, 2000) + '…' : r.fzk, md: r.md && r.md.length > 20000 ? r.md.slice(0, 2000) + '…' : r.md })), null, 1));
