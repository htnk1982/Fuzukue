// いじわるテスト 1：GFM 読み込み → fzk2 → 再解析 → GFM 書き出し → 再読み込み。例外・不安定・意味の欠落を拾う
for (const f of ['fz-core','fz-figure','fz-styles','fz-entities','fz-md','fz-gfm','fz-zip','fz-export','fz-docx','fz-pptx']) require(__dirname + '/../../app/js/' + f + '.js');
const FZ = globalThis.FZ;
const cases = {
  empty: '',
  ws: '   \n\n\t\n',
  fmOnly: '---\ntitle: x\n---\n',
  bom: '﻿# 見出し\n本文',
  crlf: '# 見出し\r\n\r\n本文1\r\n本文2\r\n\r\n- a\r\n- b\r\n',
  cr: '# 見出し\r\r本文\r',
  tabs: '\t字下げコード\n\n- a\n\t- b\n\t\t- c\n',
  longLine: 'あ'.repeat(5000),
  manyLines: Array.from({length: 3000}, (_, i) => `段落 ${i} の本文です。`).join('\n\n'),
  deepList: Array.from({length: 12}, (_, i) => ' '.repeat(i*2) + '- L' + i).join('\n'),
  deepOl: Array.from({length: 12}, (_, i) => ' '.repeat(i*3) + '1. L' + i).join('\n'),
  deepQuote: '> '.repeat(12) + '深い引用',
  quoteListQuote: '> - 項目\n>   > 引用の中のリストの中の引用\n>   > - さらにリスト',
  listInQuoteInList: '- a\n  > 引用\n  > - b\n    > - c\n',
  htmlScript: '<script>alert(1)</script>\n\n本文 <script>alert(2)</script> 終わり\n\n<img src=x onerror=alert(3)>',
  htmlComment: '<!-- コメント -->\n\n本文<!-- 中 -->本文',
  htmlMixed: '<div align="center">中央</div>\n\n<b>太</b><i>斜</i><sup>上</sup><sub>下</sub><kbd>Ctrl</kbd><ruby>漢<rt>かん</rt></ruby><span style="color:red">赤</span><a href="https://x.jp">a タグ</a>',
  htmlUnclosed: '<u>下線が閉じない\n\n次の段落も下線？',
  details: '<details>\n<summary>概要</summary>\n\n中身\n\n</details>',
  emphCjk: 'これは**強調**です。これは**強調。**です。**「鍵括弧」**も。*傍点*と***両方***。',
  emphNest: '**太字の中に*傍点*がある**。*傍点の中に**太字**がある*。~~打消し**太字**~~。',
  emphUnbalanced: '**開いたまま *もう一つ\n\n__下線風__ と _単独_',
  emphAdjacent: '**a****b** と **a** **b** と **a**x**b**',
  links: '[通常](https://x.jp) [題付き](https://x.jp "題") [参照][r] [折畳][] <https://auto.jp> <mail@x.jp> https://bare.jp www.bare.jp\n\n[r]: https://ref.jp\n[折畳]: https://col.jp\n',
  linkNest: '[**太字リンク**](https://x.jp) **[太字の中のリンク](https://x.jp)** [a [b] c](https://x.jp) [括弧 (1)](https://x.jp/a_(b)) [空]()',
  linkWeird: '[改行\nあり](https://x.jp) [日本語URL](https://例え.jp/あ い) [javascript](javascript:alert(1)) [相対](./a.md) [アンカー](#sec)',
  imageLink: '[![代替](img.png)](https://x.jp) ![](noalt.png) ![題](img.png "題")',
  tableRagged: '| a | b | c |\n|---|---|---|\n| 1 |\n| 1 | 2 | 3 | 4 | 5 |\n',
  tablePipes: '| a \\| b | `c|d` | [l|r](https://x.jp) |\n|---|---|---|\n| x | y | z |\n',
  tableNoPipes: 'a | b\n--|--\n1 | 2\n',
  tableWide: '| ' + Array.from({length: 20}, (_, i) => '列' + i).join(' | ') + ' |\n|' + '---|'.repeat(20) + '\n| ' + Array.from({length: 20}, (_, i) => 'データ' + i).join(' | ') + ' |\n',
  tableLongCell: '| 項目 | 説明 |\n|---|---|\n| a | ' + 'とても長い説明文が入ります。'.repeat(10) + ' |\n',
  tableEmpty: '| a | b |\n|---|---|\n',
  tableInline: '| **太** | *点* | ~~消~~ | `码` | <u>下</u> |\n|:--|:-:|--:|---|---|\n| 1 | 2 | 3 | 4 | 5 |\n',
  tableAfterPara: '段落\n| a | b |\n|---|---|\n| 1 | 2 |\n',
  tableBr: '| a | b |\n|---|---|\n| 1<br>2 | 3 |\n',
  listMarkers: '- a\n* b\n+ c\n\n1. x\n2) y\n\n0. zero\n999999999. big\n1234567890. notlist\n',
  listLoose: '- a\n\n- b\n\n  続き\n\n- c\n',
  listBlocks: '1. 見出し付き\n   # 中の見出し\n   ```\n   code\n   ```\n   | a | b |\n   |---|---|\n   | 1 | 2 |\n   > 引用\n2. 次',
  listTasks: '- [ ] a\n- [x] b\n- [X] c\n- [ ]d\n-  [ ] e\n- [ ] \n- [ ] [リンク](https://x.jp)',
  listStart: '5. five\n6. six\n\n- 中断\n\n7. seven\n\n   3. nested three\n   4. four\n',
  listArrow: '- → 結論\n- ⇒ 二重矢印\n- -> ASCII\n- =>太\n- →\n',
  listOnlySub: '      - 深い開始\n   - 浅く\n- 最浅',
  headings: '# A\n# B\n## C\n#### D\n##### E\n###### F\n####### G\n#\n# 末尾 ###\nSetext\n======\nSetext2\n------\n# **太字** と [リンク](https://x.jp) と `code`',
  headingsOnly: '# A\n## B\n### C\n',
  codeFences: '~~~\nチルダ\n~~~\n\n````md\n```\n中に三つ\n```\n````\n\n```\n閉じない',
  codeIndent: '    インデント\n    コード\n\n本文\n\n        深い\n',
  codeInfo: '```js {.cls} title="x"\nconsole.log(1)\n```\n\n```\t\nタブ情報\n```',
  codeLong: '```\n' + 'x'.repeat(300) + '\n' + '\t'.repeat(3) + 'tabs\n```',
  mermaidOdd: '```mermaid\nsequenceDiagram\n  A->>B: hi\n```\n\n```mermaid\ngraph LR\n  A[開始] --> B{判断?}\n  B -->|はい| C[処理 (括弧) | 縦棒]\n  B -->|いいえ| A\n  subgraph S\n  C --> D[終]\n  end\n```\n\n```mermaid\nflowchart TD\n' + Array.from({length: 30}, (_, i) => `  N${i}[箱${i}] --> N${i+1}[箱${i+1}]`).join('\n') + '\n```',
  entities: '&amp; &lt; &gt; &quot; &copy; &#169; &#x1F600; &#0; &unknown; &nbsp;x &#xD800;',
  unicode: '😀 絵文字 👨‍👩‍👧 結合 é 合成 ́ ゼロ幅​スペース ﻿ 全角　スペース ｱｲｳ 半角カナ ①②③ ㈱ ﾞ',
  hardBreaks: '二つ空白  \n改行\\\n改行<br>改行<br/>改行<BR>末尾\\',
  fzkLike: '[見出し]これは Markdown の本文\n\n#表 列 0,10 様式 格子\n\n\\#罫 横 0-40 細\n\n<太字>タグ風</太字>\n\n| パイプ | 入り |\n\n#fzk 2\n\n題名: 偽\n\n---\n\n[項目1]偽の項目',
  fzkLikeInline: '文中の [角括弧] と <山括弧> と \\ バックスラッシュ と | パイプ と #井桁',
  fmOther: '---\nauthor: me\ndate: 2026-10-31\ntitle: "引用符付き"\ntags: [a, b]\n---\n# 本文の見出し\n本文',
  fmNotTop: '本文\n---\ntitle: x\n---\n',
  tomlFm: '+++\ntitle = "x"\n+++\n本文',
  hrVariants: '***\n___\n- - -\n* * *\n---\n\n段落\n---\n',
  footnote: '脚注[^1]あり。\n\n[^1]: 脚注の本文。',
  fullwidthIndent: '　　全角字下げの段落。\n　　二行目。\n\n　・全角箇条書き\n　・もう一つ',
  nbsp: '  NBSP 字下げ\n\n- NBSP リスト',
  mixedIndent: '- a\n   - 3 spaces\n     - 5 spaces\n        - 8 spaces\n',
  blockquoteLazy: '> 引用\n遅延継続\n> - リスト\n遅延継続2',
  quoteCode: '> ```js\n> code\n> ```\n> | a |\n> |---|\n> | 1 |',
  pageBreak: '前\n\n<!-- 改頁 -->\n\n後\n\n<div style="page-break-after: always"></div>\n\n後2',
  controlChars: '制御\u0001文字\u000B垂直タブ\u001F と \u007F DEL と ]]> と & < >',
  veryLongWord: 'https://example.com/' + 'a'.repeat(300) + ' 後続',
  numberedNoSpace: '1.項目\n2.項目\n\n１．全角番号\n２．全角番号\n\n（１）括弧全角\n（２）括弧全角\n\n①丸数字\n②丸数字',
  setextVsHr: 'A\n---\nB\n\n- - -\n',
  linkRefCase: '[Foo][]\n\n[foo]: https://x.jp\n\n[ΑΓΩ]\n\n[αγω]: https://greek.jp',
  autolinkTrail: 'www.x.jp. と https://x.jp) と https://x.jp/(a) と https://x.jp&amp; と https://x.jp/&lt;',
  html5: '<video src="a.mp4"></video>\n\n<iframe src="https://x"></iframe>\n\n<svg><circle r="1"/></svg>\n\n<math>x</math>',
};
const results = [];
function run(name, md) {
  const r = { name };
  const t0 = Date.now();
  try {
    const doc = FZ.fromGfm(md); r.lines = doc.lines.length;
    const s1 = FZ.serialize(doc); r.fzk = s1;
    const doc2 = FZ.parse(s1); const s2 = FZ.serialize(doc2); r.stable = s1 === s2; if (!r.stable) r.s2 = s2;
    const lay = FZ.layout(doc2); r.pages = lay.pages.length;
    const md2 = FZ.toGfm(doc2); r.md = md2;
    const doc3 = FZ.fromGfm(md2); const s3 = FZ.serialize(doc3); r.md3stable = FZ.toGfm(doc3) === md2; r.s3 = s3;
    const dx = FZ.toDocx(doc2); const px = FZ.toPptx(doc2); r.docx = dx.length; r.pptx = px.length;
  } catch (e) { r.error = (e && e.stack || String(e)).split('\n').slice(0, 3).join(' | '); }
  r.ms = Date.now() - t0; results.push(r); return r;
}
const only = process.argv[2];
for (const [k, v] of Object.entries(cases)) { if (only && k !== only) continue; const r = run(k, v); console.log(`${r.error ? 'ERR ' : 'ok  '}${k.padEnd(16)} lines=${r.lines} pages=${r.pages} stable=${r.stable} md3=${r.md3stable} ${r.ms}ms${r.error ? '\n   ' + r.error : ''}`); }
require('fs').writeFileSync(__dirname + '/結果-' + require('path').basename(__filename, '.js') + '.json', JSON.stringify(results, null, 1));
