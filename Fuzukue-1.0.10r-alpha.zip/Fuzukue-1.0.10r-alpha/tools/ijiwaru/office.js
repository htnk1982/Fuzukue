// いじわるテスト 3：Office 書き出しの XML 妥当性・URL
for (const f of ['fz-core','fz-figure','fz-styles','fz-entities','fz-md','fz-gfm','fz-zip','fz-export','fz-docx','fz-pptx']) require(__dirname + '/../../app/js/' + f + '.js');
const FZ = globalThis.FZ; const fs = require('fs'); const out = process.argv[2] || __dirname;
const md = `# 制御\u0001文字\u000B垂直\u0000ヌル\u007F削除 ]]> & < > " '

[URL に & と空白](https://x.jp/a?b=1&c=2 "題 \u0001") [日本語](https://例え.jp/あ) [空白](<https://x.jp/a b>) [js](javascript:alert(1)) [長い](https://x.jp/${'a'.repeat(2500)}) [引用符](https://x.jp/"quote") [山括弧](https://x.jp/<b>)

![画像](img.png)

| a | b |
|---|---|
| \u0002 | 💩 |

> \uD83D 孤立サロゲート \uDC00 の行
`;
const doc = FZ.fromGfm(md);
fs.writeFileSync(out + '/ij.docx', Buffer.from(FZ.toDocx(doc))); fs.writeFileSync(out + '/ij.pptx', Buffer.from(FZ.toPptx(doc)));
// 空文書・表だけ・図だけ・引用8段・20列表・9段リスト
const docs = { empty: FZ.newDoc(), tableOnly: FZ.fromGfm('| a | b |\n|---|---|\n| 1 | 2 |\n'), figOnly: FZ.fromGfm('```mermaid\nflowchart LR\nA-->B\n```'), deepQuote: FZ.fromGfm('> '.repeat(8) + 'x\n\n' + '> '.repeat(8) + '- y'), wide: FZ.fromGfm('| ' + Array.from({length: 20}, (_, i) => 'c' + i).join(' | ') + ' |\n|' + '---|'.repeat(20) + '\n| ' + Array.from({length: 20}, (_, i) => 'd' + i).join(' | ') + ' |\n'), deepList: FZ.fromGfm(Array.from({length: 12}, (_, i) => ' '.repeat(i*2) + '- L' + i).join('\n')), headingNum: FZ.parse('#fzk 2\n見出し番号: あり\n---\n[見出し]A\n[項目1]a\n[項目2]b\n[見出し2]B\n[項目1]c\n') };
for (const [k, d] of Object.entries(docs)) { try { fs.writeFileSync(out + `/ij-${k}.docx`, Buffer.from(FZ.toDocx(d))); fs.writeFileSync(out + `/ij-${k}.pptx`, Buffer.from(FZ.toPptx(d))); console.log('ok', k); } catch (e) { console.log('ERR', k, e.message); } }
