/* 資料見本.fzk を作る（グラフはデータで持つ。写真は tools/sample-img の画像を添付） */
const fs = require('fs'), path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-styles']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; const dir = path.join(__dirname, 'sample-img');
const b64 = f => fs.readFileSync(path.join(dir, f)).toString('base64');
const src = `#fzk 2
題名: 2026年度 上期 営業報告
用紙: A4 横
文字数: 60
行数: 26
余白: 12 15 12 15
柱行: 2 0
書式: 資料
本文幅: 60%
柱の題: 頁ごと
頁番号: 四角
作成者: 営業企画部
作成日: 2026年11月2日
機密: 社外秘
---
[表題]上期の売上は前年比 3% 増、海外が牽引
[番号1]概況
上期の売上高は 229 億円（前年比 3% 増）。<図番 sales>のとおり、国内は横ばい、海外は 8% 増。
#グラフ sales 図 折れ線 売上の推移
#データ |  | 2021 | 2022 | 2023 | 2024 | 2025 |
#データ | 国内 | 128 | 140 | 141 | 141 | 134 |
#データ | 海外 | 70 | 78 | 82 | 88 | 95 |
#グラフ設定 単位=億円
[項目1]国内：主力の更新需要が一巡し、134 億円（前年比 5% 減）
[項目1]海外：アジアの新規顧客が伸び、95 億円（同 8% 増）
[番号1]構成
製品別の構成比は<図番 mix>のとおり。上位 2 製品で 75% を占める。
#グラフ mix 図 円 50% 製品別の構成比
#データ |  | 製品A | 製品B | 製品C | その他 |
#データ | 構成比 | 45 | 30 | 15 | 10 |
#図版 site 図 展示会の様子 photo.jpg 50%
[記号1]課題
[項目1]国内の更新需要の後の柱が無い
[項目1]海外は為替の影響が大きい
[表題]下期の重点施策
[番号1]国内：既存顧客の深耕
[項目1]保守契約の更新時に上位機種を提案
[項目1]販売店向けの勉強会を月 1 回
[番号1]海外：拠点の拡充
[項目1]ベトナムに駐在員事務所（12 月）
[項目1]為替予約で利益を確定
[番号1]数値目標
<図番 tgt>に示すとおり、下期は 240 億円を目指す。
#グラフ tgt 図 棒 75% 上期の実績と下期の目標
#データ |  | 上期実績 | 下期目標 |
#データ | 国内 | 134 | 140 |
#データ | 海外 | 95 | 100 |
#グラフ設定 単位=億円
===
#添付 photo.jpg image/jpeg
${b64('photo.jpg')}
`;
const d = FZ.parse(src); const out = FZ.serialize(d);
fs.writeFileSync(path.join(__dirname, '..', 'samples', '資料見本.fzk'), out);
console.log('written', out.length, 'bytes; figures', d.lines.filter(l => l.attrs.figs).length);
