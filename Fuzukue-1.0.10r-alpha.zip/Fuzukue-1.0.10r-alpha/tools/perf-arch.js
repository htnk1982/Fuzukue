/* 速さの実測（1.0.10b.8 の検査）：実際に近い文書（見出し・本文・箇条書き・ページをまたぐ表・図表・画像）で、
 * 開く・全体の組版・1 打鍵（先頭／中ほど／末尾）・改行・取消・書き出し・描画を測る。1 打鍵の内訳（前処理＋署名／組版／描画）も出す */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const png = fs.readFileSync(path.join(__dirname, 'sample-img', 'chart.png')).toString('base64');
  const sizes = (process.argv[2] || '60,300,1000').split(',').map(Number);
  for (const pagesWanted of sizes) {
    const r = await page.evaluate(async ({ pagesWanted, png }) => {
      localStorage.clear(); const L = []; let figs = 0; const target = pagesWanted * 36; let i = 0;
      while (L.length < target) { const k = i % 40;
        if (k === 0) L.push('[番号1]第' + i + '章　概況');
        else if (k === 1) L.push('この章では、文机の組版の速さを確かめるために、実際の文書に近い段落を並べる。段落は 2〜3 行に折り返し、禁則とぶら下げも働く。番号' + i + '。');
        else if (k >= 2 && k < 6) L.push('[項目1]箇条書きの項目 ' + i + '：短い説明を添える');
        else if (k === 6) { L.push('#表 列 0,10,22,40 様式 統計表'); L.push('| 支店 | 売上 | 備考 |'); for (let t = 0; t < 14; t++) L.push('| 支店' + t + ' | ' + (t * 137 + 100) + ' | 前年並み |'); }
        else if (k === 8 && figs < 40) { L.push('図の説明の段落。<図番 f' + figs + '>のとおり推移した。'); L.push('#図版 f' + figs + ' 図 売上の推移 chart.png 50%'); figs++; }
        else if (k === 20) L.push('[記号1]課題');
        else L.push('本文の段落。文机は文字数×行数の版面に文章を流し込む。段落の途中に文を足せば後ろが押し下がる。' + i);
        i++; }
      const text = '#fzk 2\n文字数: 40\n行数: 36\n戻り空き: あり\n表題の後空き: あり\n表の前空き: あり\n本文位置: 見出しの頭から1字\n---\n[表題]速さの試験\n' + L.join('\n') + '\n===\n#添付 chart.png image/png\n' + png + '\n';
      const ed = FZ.app.ed; const t = (f) => { const t0 = performance.now(); f(); return performance.now() - t0; };
      let t0 = performance.now(); await FZ.app.loadText(text, '速さ.fzk'); FZ.app.flush(); const openMs = performance.now() - t0;
      await new Promise(r => { const c = () => ed.layoutDone ? r() : setTimeout(c, 20); c(); }); const totalOpen = performance.now() - t0;
      const N = ed.doc.lines.length, P = ed.lay.pages.length;
      const fullMs = t(() => FZ.layout(ed.doc));
      // 1 打鍵：前処理＋署名（layoutJob を作るだけ）・組版（relayout 全体）・描画
      const prepMs = t(() => FZ.layoutJob(ed.doc, {}, ed.lay));
      const key = (line) => { ed.setCaret({ line, seg: 0, off: 1 }); FZ.app.flush(); const s = []; for (let k = 0; k < 8; k++) { const a = performance.now(); ed.insertText('あ'); const b = performance.now(); FZ.app.flush(); const c = performance.now(); s.push([b - a, c - b]); } return { edit: s.reduce((x, y) => x + y[0], 0) / s.length, render: s.reduce((x, y) => x + y[1], 0) / s.length }; };
      const kTop = key(3), kMid = key(Math.floor(N / 2)), kEnd = key(N - 3);
      ed.setCaret({ line: Math.floor(N / 2), seg: 0, off: 2 }); const enterMs = t(() => { for (let k = 0; k < 5; k++) { ed.enter(); FZ.app.flush(); } }) / 5;
      const bsMs = t(() => { for (let k = 0; k < 5; k++) { ed.backspace(); FZ.app.flush(); } }) / 5;
      const undoMs = t(() => { for (let k = 0; k < 5; k++) { ed.undo(); FZ.app.flush(); } }) / 5;
      const serMs = t(() => FZ.serialize(ed.doc)); const mdMs = t(() => FZ.toGfm(ed.doc)); const docxMs = t(() => FZ.toDocx(ed.doc)); const pptxMs = t(() => FZ.toPptx(ed.doc));
      const main = document.getElementById('main'); const scrollMs = t(() => { for (let k = 1; k <= 10; k++) { main.scrollTop = main.scrollHeight * k / 11; FZ.app.render(); } }) / 10;
      const heap = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : null;
      return { pages: P, lines: N, openFirstMs: openMs | 0, openAllMs: totalOpen | 0, fullLayoutMs: fullMs | 0, prepassMs: +prepMs.toFixed(1), keyTop: kTop.edit.toFixed(1) + '+' + kTop.render.toFixed(1), keyMid: kMid.edit.toFixed(1) + '+' + kMid.render.toFixed(1), keyEnd: kEnd.edit.toFixed(1) + '+' + kEnd.render.toFixed(1), enterMs: enterMs.toFixed(1), backspaceMs: bsMs.toFixed(1), undoMs: undoMs.toFixed(1), serializeMs: serMs | 0, mdMs: mdMs | 0, docxMs: docxMs | 0, pptxMs: pptxMs | 0, scrollRenderMs: scrollMs.toFixed(1), heapMB: heap };
    }, { pagesWanted, png });
    console.log(JSON.stringify(r));
  }
  console.log('errors', errors); await browser.close();
})();
