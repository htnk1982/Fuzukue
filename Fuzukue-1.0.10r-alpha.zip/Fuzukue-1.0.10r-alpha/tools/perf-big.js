const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  await page.goto('file://' + require('path').resolve(__dirname, '../app/index.html') + ''); await page.waitForTimeout(400);
  for (const n of [1500, 10000, 38000]) {
    const r = await page.evaluate(async (n) => {
      localStorage.clear(); const d = FZ.newDoc(); d.lines = []; for (let i = 0; i < n; i++) { const k = i % 7; d.lines.push(k === 0 ? { segs: [FZ.newSeg(0, '見出し' + i)], attrs: { style: 'num', level: 0 } } : k === 3 ? { segs: [FZ.newSeg(0, '項目' + i)], attrs: { list: { level: 0 } } } : FZ.newLine('これは性能測定のための段落です。番号' + i + '。文字数×行数の版面に文章を流し込み、禁則を処理しながら折り返します。')); }
      const t00 = performance.now(); FZ.app.ed.setDoc(d); FZ.app.render(); FZ.app.flush(); const open = performance.now() - t00;
      const ed = FZ.app.ed; await new Promise(r => { const c = () => ed.layoutDone ? r() : setTimeout(c, 20); c(); }); ed.setCaret({ line: Math.floor(n / 2), seg: 0, off: 3 }); FZ.app.flush(); // 段階的な組版が終わってから測る
      const tl = performance.now(); FZ.layout(ed.doc); const layoutMs = performance.now() - tl;
      const tu = performance.now(); ed.pushUndo('x'); ed.breakUndo(); const undoMs = performance.now() - tu;
      const t0 = performance.now(); for (let i = 0; i < 10; i++) { ed.insertText('あ'); FZ.app.flush(); } const per = (performance.now() - t0) / 10;
      const t1 = performance.now(); for (let i = 0; i < 10; i++) { ed.moveH(1); FZ.app.flush(); } const perMove = (performance.now() - t1) / 10;
      return { n, pages: ed.lay.pages.length, openMs: open.toFixed(0), layoutMs: layoutMs.toFixed(0), undoSnapMs: undoMs.toFixed(1), msPerKey: per.toFixed(1), msPerMove: perMove.toFixed(1) };
    }, n);
    console.log(r);
  }
  await browser.close();
})();
