const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + require('path').resolve(__dirname, '../app/index.html') + ''); await page.waitForTimeout(400);
  const r = await page.evaluate(async () => {
    const n = 38000; const L = []; for (let i = 0; i < n; i++) { const k = i % 7; L.push(k === 0 ? '[番号1]見出し' + i : k === 3 ? '[項目1]項目' + i : 'これは性能測定のための段落です。番号' + i + '。文字数×行数の版面に文章を流し込み、禁則を処理しながら折り返します。'); }
    const text = '#fzk 2\n文字数: 40\n行数: 36\n---\n' + L.join('\n') + '\n';
    let t0 = performance.now(); const d1 = FZ.parse(text); const tParseMain = performance.now() - t0;
    t0 = performance.now(); const d2 = FZ.normalize(d1); const tNorm = performance.now() - t0;
    t0 = performance.now(); await FZ.app.loadText(text, '大.fzk'); const tFirst = performance.now() - t0; const pagesFirst = FZ.app.ed.lay.pages.length;
    const t1 = performance.now(); FZ.app.ed.insertText('あ'); FZ.app.flush(); const typeMs = performance.now() - t1;
    await new Promise(r => { const chk = () => FZ.app.ed.layoutDone ? r() : setTimeout(chk, 20); chk(); }); const tAll = performance.now() - t0;
    FZ.app.flush(); const st2 = document.getElementById('status').textContent.replace(/\s+/g, ' ');
    return { tParseMain: tParseMain.toFixed(0), tNorm: tNorm.toFixed(0), tFirst: tFirst.toFixed(0), pagesFirst, typeMs: typeMs.toFixed(0), tAll: tAll.toFixed(0), pages: FZ.app.ed.lay.pages.length, st2: st2.slice(0, 60) };
  });
  console.log(r, errors);
  await browser.close();
})();
