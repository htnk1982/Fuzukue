const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  for (const n of [180, 1500]) {
    const r = await page.evaluate(async (n) => {
      localStorage.clear(); const d = FZ.newDoc(); d.lines = []; for (let i = 0; i < n; i++) d.lines.push(FZ.newLine('これは性能測定のための段落です。番号' + i + '。文字数×行数の版面に文章を流し込み、禁則を処理しながら折り返します。')); FZ.app.ed.setDoc(d); FZ.app.render();
      const ed = FZ.app.ed; ed.setCaret({ line: Math.floor(n / 2), seg: 0, off: 3 }); FZ.app.flush();
      const t0 = performance.now(); for (let i = 0; i < 20; i++) { ed.insertText('あ'); FZ.app.flush(); } const per = (performance.now() - t0) / 20;
      const t1 = performance.now(); for (let i = 0; i < 20; i++) { ed.moveH(1); FZ.app.flush(); } const perMove = (performance.now() - t1) / 20;
      return { pages: ed.lay.pages.length, msPerKey: per.toFixed(1), msPerMove: perMove.toFixed(1) };
    }, n);
    console.log(r);
  }
  await browser.close();
})();
