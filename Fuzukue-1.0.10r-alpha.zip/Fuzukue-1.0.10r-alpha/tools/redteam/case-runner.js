/* レッドチーム：1 件を別のプロセスで動かす（固まっても止められるように）。引数：base64 の原本。結果を JSON で出す */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-render']) require('../../app/js/' + f + '.js');
const FZ = globalThis.FZ; const src = require('fs').readFileSync(process.argv[2], 'utf8'); const kind = process.argv[3] || 'fzk';
const out = { ok: true, steps: [] }; const T = (name, f) => { const t0 = Date.now(); try { const r = f(); out.steps.push([name, Date.now() - t0]); return r; } catch (e) { out.ok = false; out.err = name + ': ' + (e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : e); throw e; } };
try {
  const d = T('parse', () => kind === 'md' ? FZ.fromGfm(src) : FZ.parse(src));
  const lay = T('layout', () => FZ.layout(d)); out.pages = lay.pages.length; out.lines = d.lines.length;
  T('render', () => { for (let p = 0; p < Math.min(3, lay.pages.length); p++) FZ.renderPage(lay, p, { grid: true, mono: true }); });
  const s1 = T('serialize', () => FZ.serialize(d)); const s2 = T('reparse', () => FZ.serialize(FZ.parse(s1))); out.stable = s1 === s2; if (!out.stable) { let k = 0; while (k < s1.length && s1[k] === s2[k]) k++; out.diff = [s1.slice(Math.max(0, k - 40), k + 40), s2.slice(Math.max(0, k - 40), k + 40)]; }
  T('gfm', () => FZ.toGfm(d)); T('docx', () => FZ.toDocx(d)); T('pptx', () => FZ.toPptx(d));
  T('edit', () => { const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(s1)); const n = ed.doc.lines.length; for (let k = 0; k < 20; k++) { const li = (k * 7919) % n; const ln = ed.doc.lines[li]; ed.setCaret({ line: li, seg: 0, off: Math.min(1, ln.segs[0].text.length) }); if (ln.attrs.figure || ln.attrs.toc || ln.attrs.hr) continue; if (k % 3 === 0) ed.enter(); else if (k % 3 === 1) ed.insertText('あ'); else ed.backspace(); } for (let k = 0; k < 10; k++) ed.undo(); });
} catch (e) { }
process.stdout.write(JSON.stringify(out));
