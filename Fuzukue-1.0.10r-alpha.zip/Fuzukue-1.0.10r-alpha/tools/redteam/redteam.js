/* レッドチーム試験：壊れた原本・極端な値・悪意のある文字・巨大な段落で、例外・固まり・往復の崩れが無いか。1 件ずつ別プロセス（10 秒で打ち切り） */
const { spawnSync } = require('child_process'); const path = require('path'); const fs = require('fs'); const os = require('os'); const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'fzrt-'));
const H = (x = '') => '#fzk 2\n' + x + '---\n';
const big = (n, s) => Array.from({ length: n }, () => s).join('');
const cases = {
  'cols=100000': H('文字数: 100000\n') + '本文\n', 'rows=0': H('行数: 0\n') + '本文\n', 'rows=100000': H('行数: 100000\n') + '本文\n', 'cols=1 rows=1': H('文字数: 1\n行数: 1\n') + '本文が長い\n[表題]題\n',
  'paper huge': H('用紙: 幅 99999 高 99999\n') + 'x\n', 'margins negative': H('余白: -50 -50 -50 -50\n') + 'x\n', 'header rows 999': H('柱行: 999 999\n柱上: {page}\n') + 'x\n', 'hfgap 999': H('柱空き: 999\n') + 'x\n',
  'indent 99999': H() + '[字下げ99999]本文\n[ぶら下げ99999 字下げ3]本文が長くて折り返す文章\n', 'figure h 99999': H() + '[図99999]\n#箱 1 0,0 5x2 細 無 a\n', 'level 99': H() + '[番号99]見出し\n[記号99]記号\n[項目99]項目\n[番号項目99]番号\n',
  'quote 99999': H() + '[引用99999]引用\n', 'speech 99999': H() + '[発言99999]話者：本文\n', 'toc reversed': H() + '[目次9-1]\n[番号1]a\n', 'restart huge': H() + '[番号1 再開999999999999]a\n[番号項目1 再開-5]b\n',
  'vrule span huge': H() + '#罫 縦 5 ×999999999 細\nx\ny\n', 'hrule range wild': H() + '#罫 横 -500-999999 太\nx\n', 'fill wild': H() + '#網 -5-999999 ×999999 濃\nx\n', 'rule kinds unknown': H() + '#罫 横 0-10 ？？\n#罫 縦 abc ×x 細\nx\n',
  'table 1000 cols': H() + '#表 列 ' + Array.from({ length: 1001 }, (_, i) => i).join(',') + ' 様式 格子\n| a | b |\n', 'table ragged': H() + '#表 列 0,10,40 様式 格子\n| a |\n| a | b | c | d | e |\n|\n| \n', 'table huge cell': H() + '#表 列 0,10,40 様式 格子\n| ' + big(20000, 'あ') + ' | b |\n| c | d |\n',
  'combining storm': H() + 'a' + big(3000, '́') + 'b\n', 'zwj emoji': H() + big(500, '👨‍👩‍👧‍👦') + '\n', 'lone surrogates': H() + 'a\ud800b\udc00c' + big(100, '\ud83d') + '\n', 'control chars': H() + 'a\u0000b\u000bc\u0007d\u001be f g\n', 'bidi': H() + '‮abc‭漢字‏​﻿\n', 'bom': '﻿' + H() + '本文\n', 'cr only': '#fzk 2\r---\r本文1\r本文2\r',
  'html injection': H() + '</text><script>alert(1)</script><img src=x onerror=alert(1)>"\'&<>\n[表題]<b>題</b>\n', 'link javascript': H() + '<リンク javascript:alert(1)>押す</リンク>\n<リンク data:text/html,<script>x</script>>データ</リンク>\n',
  'attachment broken': H() + '本文\n#図版 a 図 題 x.png\n===\n#添付 x.png image/png\n!!!not base64!!!\n#添付 y.svg image/svg+xml\n' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>').toString('base64') + '\n#添付 z.html text/html\nPGgxPmhpPC9oMT4=\n',
  'refs dangling': H() + '本文<図番 nope><図番 ><図番 a b c>\n', 'figure refs PUA raw': H() + '本文󰀀󰀅\n', 'garbage lines': H() + Array.from({ length: 3000 }, (_, i) => String.fromCharCode(...Array.from({ length: 30 }, (_, k) => 32 + ((i * 131 + k * 7919) % 30000)))).join('\n') + '\n',
  'deep nesting 5000': H() + Array.from({ length: 5000 }, (_, i) => '[項目' + (1 + i % 8) + ']項目' + i).join('\n') + '\n', 'headings 10000': H() + Array.from({ length: 10000 }, (_, i) => '[番号' + (1 + i % 3) + ']見出し' + i).join('\n') + '\n',
  'one paragraph 200k': H() + big(4000, '長い段落を貼り付けた。改行が無い。、') + '\n', 'many short lines 60000': H() + Array.from({ length: 60000 }, (_, i) => 'l' + i).join('\n') + '\n',
  'figure boxes wild': H() + '[図5]\n#箱 1 -99,-99 9999x9999 太 濃 巨大\n#箱 2 2,2 0x0 細 無 零\n#矢印 1→2 細\n#矢印 1→99 細\n#レーン 縦 0,0,0 a|b|c\n',
  'slide extreme': '#fzk 2\n書式: 資料\n本文幅: 1%\n柱の題: 頁ごと\n---\n[表題]' + big(500, '題') + '\n' + Array.from({ length: 30 }, (_, i) => '[表題]題' + i).join('\n') + '\n',
  'md: deep blockquote': ['md', big(3000, '>') + ' x\n'], 'md: huge table': ['md', '| ' + Array.from({ length: 300 }, (_, i) => 'h' + i).join(' | ') + ' |\n|' + big(300, '---|') + '\n' + Array.from({ length: 300 }, () => '| ' + big(300, 'x | ')).join('\n') + '\n'], 'md: emphasis storm': ['md', big(20000, '*a_') + '\n'], 'md: link storm': ['md', big(5000, '[a](') + '\n'], 'md: html': ['md', '<script>alert(1)</script>\n\n<img src=x onerror=alert(1)>\n\n[x](javascript:alert(1))\n'],
};
const res = []; let bad = 0;
for (const [name, v] of Object.entries(cases)) {
  const [kind, src] = Array.isArray(v) ? v : ['fzk', v]; const t0 = Date.now();
  const fp = path.join(TMP, 'c.txt'); fs.writeFileSync(fp, src); const p = spawnSync(process.execPath, [path.join(__dirname, 'case-runner.js'), fp, kind], { timeout: 20000, maxBuffer: 1 << 26 });
  const ms = Date.now() - t0; let r = null; try { r = JSON.parse(String(p.stdout)); } catch { }
  const verdict = p.error && p.error.code === 'ETIMEDOUT' ? 'HANG' : !r ? 'CRASH ' + String(p.stderr).split('\n').slice(0, 4).join(' | ').slice(0, 300) : !r.ok ? 'THROW ' + r.err.slice(0, 300) : r.stable === false ? 'UNSTABLE ' + JSON.stringify(r.diff).slice(0, 200) : ms > 8000 ? 'SLOW' : 'ok';
  if (verdict !== 'ok') bad++; res.push(name.padEnd(24) + ' ' + (ms + 'ms').padStart(8) + '  ' + verdict + (r && r.steps ? '  [' + r.steps.filter(s => s[1] > 300).map(s => s.join(' ')).join(', ') + ']' : '') + (r ? '  pages=' + r.pages : ''));
}
console.log(res.join('\n')); console.log('redteam bad=' + bad); process.exit(bad ? 1 : 0);
