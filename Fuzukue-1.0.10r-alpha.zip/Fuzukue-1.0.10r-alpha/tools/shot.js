const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = []; page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(800);
  await page.screenshot({ path: '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/shot1.png' });
  console.log('errors:', errors); console.log('status:', await page.$eval('#status', e => e.innerText.replace(/\n/g,' | ')));
  await browser.close();
})();
