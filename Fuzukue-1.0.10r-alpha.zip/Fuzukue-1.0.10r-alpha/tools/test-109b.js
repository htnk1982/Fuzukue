/* 1.0.9b：戻り空き・題の前空き、目次、A-5（項目の中の引用）、A-13（飾り行の書き出し）、C-3（和文の番号を起こす） */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info) : '')); } };
const H = (rows, extra = '') => '#fzk 2\n文字数: 40\n行数: ' + rows + '\n' + extra + '---\n';
const rowsOf = d => { const lay = FZ.layout(d); return lay.lineMap.map(lm => lm.rows.map(r => r.page + '/' + r.y).join(',')); };
// 1 戻り空き：本文・箇条書き・深い見出しの後の見出しの前に 1 行。空行の後・ページ頭・文書の先頭・浅い見出しの直後は空けない
{ const d = FZ.parse(H(12, '戻り空き: あり\n') + '[番号1]背景\n本文\n[番号2]市場\n本文2\n[番号2]競合\n[番号1]課題\n\n[番号1]空行の後\n[項目1]a\n[項目2]b\n[記号1]記号\n本文3\n[番号1]最後\n');
  const g = FZ.headingGaps(d); ok(JSON.stringify(g.map((x, i) => x ? i : -1).filter(i => i >= 0)) === '[2,4,5,10,12]', 'returnGap lines', g);
  const r = rowsOf(d); ok(r[0] === '0/0' && r[1] === '0/1' && r[2] === '0/3' && r[4] === '0/6' && r[5] === '0/8' && r[7] === '0/10', 'returnGap rows', r);
  ok(r[9] === '1/0' && r[10] === '1/2', 'gap not at page top, gap after bullets', r);
  const s1 = FZ.serialize(d); ok(s1.includes('戻り空き: あり') && FZ.parse(s1).format.returnGap === true, 'returnGap fzk');
  const str = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok((str.match(/w:before="\d+"/g) || []).length === 5, 'docx spacing before', (str.match(/w:before="\d+"/g) || []).length);
  // 直後の見出し：1. の直後の （1） は戻りでない
  const d2 = FZ.parse(H(12, '戻り空き: あり\n') + '[番号1]A\n[番号2]B\n[番号2]C\n[記号1]S\n[番号2]D\n'); const g2 = FZ.headingGaps(d2); ok(JSON.stringify(g2) === '[false,false,false,false,true]', 'heading after shallower heading: no gap; num after sym: gap', g2); }
// 2 題の前空き：本文・箇条書きの後の題（題レベル・記号見出し・表題）だけ。段落レベルの数字見出しは対象外
{ const d = FZ.parse(H(20, '題の前空き: あり\n') + '[番号1]A\n本文\n[番号3]段落\n本文\n[番号3]段落2\n[番号2]B\n[記号1]S\n本文\n[表題]題\n'); const g = FZ.headingGaps(d);
  ok(JSON.stringify(g) === '[false,false,false,false,false,true,false,false,true]', 'titleGap: only after body/bullets (1.0.10a.3: a one-line numbered paragraph is content, so B after it gets the gap)', g);
  const d2 = FZ.parse(H(20, '題の前空き: あり\n') + '[番号1]A\n本文\n[番号1]B\n[項目1]a\n[記号1]S\n本文\n[番号3]段落\n'); const g2 = FZ.headingGaps(d2); ok(JSON.stringify(g2) === '[false,false,true,false,true,false,false]', 'titleGap after body / bullets, not paragraph level', g2); }
// 3 目次：抽出・字下げ・頁番号・原本・編集・書き出し
{ const d = FZ.parse(H(10) + '[表題]報告\n[目次1-2 目次記号1-1]\n[番号1]背景\n本文\n[番号2]市場\n[記号1]現状\n[番号2]競合\n[番号1]課題\n[番号3]段落\n');
  const lay = FZ.layout(d); const es = lay.tocs[1]; ok(es && es.map(e => e.line + ':' + e.indent + ':' + e.page).join(' ') === '2:0:1 4:1:1 5:2:2 6:1:2 7:0:2', 'toc entries', es);
  ok(lay.lineMap[1].rows[0].h === 5 && lay.lineMap[2].rows[0].y === 6, 'toc occupies 5 rows', lay.lineMap[1].rows);
  const row1 = lay.pages[0].glyphs.filter(g => g.toc && g.y === 1).map(g => g.text).join(''); ok(/^1\. 背景…+1$/.test(row1), 'toc row text', row1);
  const s1 = FZ.serialize(d); ok(s1.includes('[目次1-2 目次記号1-1]') && FZ.serialize(FZ.parse(s1)) === s1, 'toc fzk stable', s1.split('---\n')[1]);
  ok(JSON.stringify(FZ.parse(H(10) + '[目次]x').lines[0].attrs.toc) === '{"num":null,"sym":null}' && FZ.parse(H(10) + '[目次]x').lines[0].segs[0].text === '', 'toc default & no text');
  const str = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok(str.includes('TOC \\o "1-3"') && str.includes('w:styleId="TOC2"') && /TOC1"\/><\/w:pPr><w:r><w:fldChar w:fldCharType="begin"/.test(str) && (str.match(/fldCharType="end"/g) || []).length === 1, 'docx toc field', str.match(/TOC \\o "[^"]*"/));
  const md = FZ.toGfm(d); ok(md.includes('- 1\\. 背景\n  - （1） 市場\n    - ■ 現状\n  - （2） 競合\n- 2\\. 課題'), 'gfm toc as nested list', md);
  const px = Buffer.from(FZ.toPptx(d)).toString('utf8'); ok(px.includes('name="目次"') && px.includes('name="目次頁"'), 'pptx toc boxes');
  // 編集：入れる・範囲を変える・消す
  const ed = new FZ.Editor(); ed.setDoc(FZ.newDoc()); ed.insertText('章'); ed.setHeading('num'); ed.enter(); const at = ed.insertToc({ num: [0, 2], sym: null }); ok(at === 1 && ed.doc.lines[1].attrs.toc && ed.doc.lines[1].attrs.toc.num[1] === 2, 'insertToc', ed.doc.lines[1].attrs);
  ok(ed.setToc(1, { num: null, sym: [0, 0] }) && ed.doc.lines[1].attrs.toc.sym[0] === 0 && ed.doc.lines[1].attrs.toc.num === null, 'setToc'); ok(ed.removeToc(1) && !ed.doc.lines[1].attrs.toc, 'removeToc');
  // 見出しが無い目次は 1 行の案内
  const d3 = FZ.parse(H(10) + '[目次]\n本文\n'); const l3 = FZ.layout(d3); ok(l3.lineMap[0].rows[0].h === 1 && l3.pages[0].glyphs.some(g => g.toc && g.text === '（'), 'empty toc placeholder');
  // 見出しが多くてページをまたぐ
  const many = Array.from({ length: 15 }, (_, k) => '[番号1]見出し' + k).join('\n'); const d4 = FZ.parse(H(10) + '[目次1-1]\n' + many + '\n'); const l4 = FZ.layout(d4); ok(l4.lineMap[0].rows.length === 2 && l4.lineMap[0].rows[0].h === 10 && l4.lineMap[0].rows[1].h === 5, 'toc spans pages', l4.lineMap[0].rows); }
// 4 A-5：項目の中の引用・引用の中の項目の中の引用。往復で構造が保たれる
{ const md = '- a\n  > quoted\n  > more\n- b\n  - d\n    > dq\n  - e\n\n> - qa\n>   > deep\n> - qb\n>   - qc\n';
  const d = FZ.fromGfm(md); const out = FZ.toGfm(d); const d2 = FZ.fromGfm(out); const A = JSON.stringify(d.lines.map(l => [l.attrs, l.segs.map(s => s.text).join('')])), B = JSON.stringify(d2.lines.map(l => [l.attrs, l.segs.map(s => s.text).join('')]));
  ok(A === B, 'A-5 round trip', out); ok(/^- a\n\n  > quoted more\n- b/.test(out) && out.includes('> - qa\n>\n>   > deep\n> - qb\n>   - qc'), 'A-5 prefix order', out);
  const d5 = FZ.fromGfm('- a\n  ```js\n  x\n  ```\n- b\n'); const o5 = FZ.toGfm(d5); ok(o5.includes('- a\n\n  ```js\n  x\n  ```\n- b'), 'code in item keeps indent', o5); }
// 5 A-13：飾り行・倍角の行は # 見出し、飾りの罫は区切り線にしない
{ const t = require('fs').readFileSync(__dirname + '/../samples/新聞風見本.fzk', 'utf8'); const d = FZ.parse(t); const md = FZ.toGfm(d);
  const heads = md.split('\n').filter(l => /^#/.test(l)); ok(heads.length >= 12 && heads.some(l => l === '## 罫囲みの見出し') && heads.some(l => l === '## 横倍角の見出し'), 'A-13 deco headings', heads);
  ok(!md.split('\n').some(l => l === '---'), 'A-13 no hr from deco rules', md.split('\n').filter(l => l === '---').length);
  const d2 = FZ.fromGfm('前\n\n---\n\n後\n'); const o2 = FZ.toGfm(d2); ok(o2.includes('---'), 'real hr kept', o2); }
// 6 C-3：和文の番号・記号を起こす（任意機能）
{ const d = FZ.fromPlain('１．背景\n1.5倍になった\n（１）市場\n　・子\n・親\n－ ハイフン\n-ダッシュなし\n■ 現状\n②飛び\n第3章 無い形\n2026年11月1日\na）英\nア　カナ\nアイス\n');
  ok(FZ.jaMarkerCount(FZ.toPlain(d)) === 10, 'C-3 count (第3章 も数える)', FZ.jaMarkerCount(FZ.toPlain(d))); const n = FZ.liftJaMarkers(d); ok(n === 9, 'C-3 changed', n);
  const a = d.lines.map(l => JSON.stringify(l.attrs) + '|' + l.segs[0].text);
  ok(a[0] === '{"style":"num","level":0}|背景' && a[1] === '{}|1.5倍になった' && a[2] === '{"style":"num","level":1}|市場' && a[3] === '{"list":{"level":1}}|子' && a[4] === '{"list":{"level":0}}|親' && a[5] === '{"list":{"level":0}}|ハイフン' && a[6] === '{}|-ダッシュなし' && a[7] === '{"style":"sym","level":0}|現状' && a[8] === '{"restart":2,"style":"num","level":2}|飛び' && a[9] === '{}|第3章 無い形' && a[10] === '{}|2026年11月1日' && a[11] === '{"style":"num","level":5}|英' && a[12] === '{"style":"num","level":3}|カナ' && a[13] === '{}|アイス', 'C-3 lift', a);
  const d2 = FZ.fromPlain('第1章 総則\n1 目的\n（1）この規程は\nア 定義\n'); d2.format.scheme = FZ.normalizeScheme(FZ.SCHEME_PRESETS[2].num); FZ.liftJaMarkers(d2); ok(d2.lines.slice(0, 4).map(l => l.attrs.level).join() === '0,1,2,3', 'C-3 公用文 scheme', d2.lines.map(l => l.attrs)); }
// 7 囲み見出し：記号見出しの体系に 【】《》〈〉 の対。開きが印、閉じは本文の後ろ。行末で入らなければ前の字を連れて折り返す。キャレットの末尾は閉じの前。倍角・太字に追従。Markdown 往復・Word・PowerPoint・目次・和文起こし
{ const H2 = '#fzk 2\n文字数: 10\n行数: 20\n記号見出し: 【】 《》 ■ ○ ▲ △ ◇ □\n---\n';
  const d = FZ.parse(H2 + '[記号1]現状\n[記号2]ちょうど八文字の題\n[記号1]<横倍角>倍</横倍角>\n');
  const lay = FZ.layout(d); const rows = i => lay.lineMap[i].segs[0].rows; const txt = r => r.glyphs.map(g => g.text).join('');
  ok(txt(rows(0)[0]) === '【現状】' && rows(0)[0].carets[rows(0)[0].carets.length - 1].col === 3, 'wrap heading glyphs & end caret before close', [txt(rows(0)[0]), rows(0)[0].carets]);
  ok(rows(1).length === 2 && txt(rows(1)[1]) === '題》', 'close bracket carried to next row with kinsoku', rows(1).map(txt));
  ok(rows(2)[0].glyphs.every(g => g.marks & FZ.M.WIDE) && rows(2)[0].glyphs[0].w === 2, 'brackets follow double width', rows(2)[0].glyphs.map(g => [g.text, g.w, g.marks]));
  ok(FZ.serialize(d).includes('記号見出し: 【】 《》 ■'), 'wrap tokens in fzk header');
  const md = FZ.toGfm(d); ok(md.includes('# 【現状】') && md.includes('## 《ちょうど八文字の題》'), 'gfm export brackets', md);
  const back = FZ.fromGfm(md, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(d.format)) }); ok(back.lines[0].attrs.style === 'sym' && back.lines[0].attrs.level === 0 && back.lines[0].segs[0].text === '現状' && back.lines[1].attrs.level === 1 && back.lines[1].segs[0].text === 'ちょうど八文字の題', 'gfm import strips both brackets', back.lines.map(l => [l.attrs, l.segs[0].text]));
  const dx = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok(/【<\/w:t>/.test(dx) && /】<\/w:t>/.test(dx), 'docx bakes both brackets'); const px = Buffer.from(FZ.toPptx(d)).toString('utf8'); ok(px.includes('【</a:t>') && px.includes('】</a:t>'), 'pptx bakes both brackets');
  const d2 = FZ.parse(H2.replace('文字数: 10', '文字数: 30') + '[目次 目次記号1-1]\n[記号1]現状\n'); const l2 = FZ.layout(d2); const row = l2.pages[0].glyphs.filter(g => g.toc && g.y === 0).map(g => g.text).join(''); ok(/^【現状】…+1$/.test(row), 'toc entry wraps text', row);
  const p = FZ.fromPlain('【現状】\n本文\n《詳細》\n【】\n'); p.format.symScheme = FZ.normalizeScheme(['【】', '《》'], FZ.DEFAULT_SYM); FZ.liftJaMarkers(p); ok(p.lines[0].attrs.style === 'sym' && p.lines[0].segs[0].text === '現状' && p.lines[2].attrs.level === 1 && !p.lines[3].attrs.style, 'C-3 lifts bracket headings', p.lines.map(l => [l.attrs, l.segs[0].text]));
  ok(FZ.schemeSample(['【】'], 0) === '【題】' && FZ.levelSpec('【】').type === 'wrap' && FZ.levelSpec('■').type === 'sym', 'levelSpec wrap'); }
console.log(`109b fails=${fails}`, 'errors:', errors);
