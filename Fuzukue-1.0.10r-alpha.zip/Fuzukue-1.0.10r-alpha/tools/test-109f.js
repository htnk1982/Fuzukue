/* 1.0.9f：概念と見た目の切り分け（K-1/2/3/5/6/7/8/10/12）と、Markdown の空行・網・Word・書体の改修 */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-render']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, M = FZ.M; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info).slice(0, 500) : '')); } };
const H = (extra = '') => '#fzk 2\n文字数: 40\n行数: 30\n' + extra + '---\n';
const mkEd = text => { const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(text)); return ed; };
const glyphBold = (lay, i) => { const gs = []; for (const p of lay.pages) for (const g of p.glyphs) if (g.line === i && !g.marker) gs.push(g); return gs.length > 0 && gs.every(g => g.marks & M.BOLD); };
const docx = d => Buffer.from(FZ.toDocx(d)).toString('utf8');

// K-1 題の太字は組版が付ける
{ const ed = mkEd(H() + '見出しにする行\n本文\n');
  ed.setHeading('num'); ok(glyphBold(ed.lay, 0) && !ed.line().segs[0].marks.some(m => m & M.BOLD), 'K-1 heading bold by layout, not baked');
  ed.setHeading('num'); ok(!glyphBold(ed.lay, 0), 'K-1 removing heading removes bold');
  const ed2 = mkEd(H() + '[番号3]段落で<太字>ここだけ</太字>太字\n'); ed2.indent(-1); ed2.indent(-1); ok(glyphBold(ed2.lay, 0), 'K-1 title level is bold'); ed2.indent(1); ed2.indent(1);
  const m = ed2.line().segs[0].marks.map(x => x & M.BOLD ? 1 : 0).join(''); ok(m === '000111100', 'K-1 partial bold survives level changes', m);
  const d = FZ.parse(H() + '[番号2]節\n'); ok(glyphBold(FZ.layout(d), 0), 'K-1 level 2 is title (titleLevels 2)'); d.format.titleLevels = 1; ok(!glyphBold(FZ.layout(d), 0), 'K-1 titleLevels change applies to existing lines');
  const ed3 = mkEd(H() + '[番号1]章\n'); ed3.setCaret({ line: 0, seg: 0, off: 0 }); ed3.setCaret({ line: 0, seg: 0, off: 1 }, true); ed3.toggleMark(M.BOLD); ok(ed3.line().attrs.thin === true && !glyphBold(ed3.lay, 0), 'K-1 F5 bold on a title line toggles 細字', ed3.line().attrs);
  const s = FZ.serialize(ed3.doc); ok(s.includes('[番号1 細字]章') && FZ.serialize(FZ.parse(s)) === s, 'K-1 細字 token', s.split('---\n')[1]);
  ok(/<w:b w:val="0"\/>/.test(docx(ed3.doc)), 'K-1 docx: thin title cancels heading-style bold');
  ed3.toggleMark(M.BOLD); ok(!ed3.line().attrs.thin && glyphBold(ed3.lay, 0), 'K-1 toggle back');
  const legacy = FZ.normalize({ format: FZ.newDoc().format, lines: [{ segs: [{ col: 0, text: '旧', marks: [M.BOLD] }], attrs: { style: 'num', level: 0 } }] }); ok(legacy.lines[0].segs[0].marks[0] === 0, 'K-1 legacy baked bold stripped on normalize');
  const md = FZ.fromGfm('# 題\n\n## 背景\n\n### ■ 現状\n'); ok(md.lines.every(l => l.segs[0].marks.every(x => !(x & M.BOLD))), 'K-1 Markdown import does not bake heading bold'); }
// K-2 空行は空きだけ
{ const d = FZ.parse(H() + '[項目1]親\n[項目2]子1\n\n[項目2]子2\n'); const lay = FZ.layout(d); const col = i => lay.lineMap[i].segs[0].rows[0].glyphs.find(g => g.marker).col;
  ok(col(1) === col(3), 'K-2 blank line keeps nesting position', [col(1), col(3)]);
  const back = FZ.fromGfm(FZ.toGfm(d)); const l3 = back.lines.find(l => l.segs[0].text === '子2'); ok(l3 && l3.attrs.list.level === 1, 'K-2 Markdown round trip keeps level', back.lines.map(l => [l.attrs, l.segs[0].text])); }
// K-3／K-10 飾りは行の属性
{ const d = FZ.parse(H() + '#罫 横 0-40 細\n箱の中の文\n#罫 横 0-40 細\n後\n'); ok(!d.lines[0].attrs.deco, 'K-3 hand-drawn rules are not a decoration'); const s = FZ.serialize(d); ok(!/飾り/.test(s) && /#罫 横/.test(s), 'K-3 hand-drawn rules stay rules', s.split('---\n')[1]); const md = FZ.toGfm(d); ok(!/^#/m.test(md) && !/^---$/m.test(md), 'K-3/K-6 hand-drawn rules: no heading, no ---', md);
  const ed = mkEd(H() + '[字下げ4]見出し\n本文\n'); FZ.applyHeading(ed, 'box'); const a = ed.doc.lines[0].attrs; ok(a.deco === '罫囲み' && a.indent === 4 && ed.doc.rules.length === 0, 'K-3/K-10 deco attr, position kept, no doc rules', [a, ed.doc.rules.length]);
  const pg = ed.lay.pages[0]; ok(pg.hrules.filter(r => r.deco && r.id.startsWith('deco0')).length === 2 && pg.vrules.filter(r => r.deco).length === 2, 'K-3 layout draws the box', [pg.hrules.length, pg.vrules.length]);
  ok(/<w:pBdr><w:top /.test(docx(ed.doc)), 'K-3 docx box borders from the name');
  FZ.applyHeading(ed, 'h'); ok(ed.doc.lines[0].attrs.deco === '横倍角' && ed.doc.lines[0].segs[0].marks.every(m => m & M.WIDE), 'K-3 size deco sets WIDE'); FZ.applyHeading(ed, 'box'); ok(ed.doc.lines[0].segs[0].marks.every(m => m & M.WIDE), 'K-10 box keeps the WIDE set before');
  FZ.applyHeading(ed, 'clear'); ok(!ed.doc.lines[0].attrs.deco && !ed.doc.lines[0].segs[0].marks.some(m => m & M.WIDE) && ed.doc.lines[0].attrs.indent === 4, 'K-3 clear removes deco and sizes, keeps position');
  const s2 = FZ.serialize(mkEd(H() + '[飾り:ベタ白抜き]題\n').doc); ok(s2.includes('[飾り:ベタ白抜き]題') && FZ.layout(FZ.parse(s2)).pages[0].fills.some(f => f.shade === 'dark' && f.deco), 'K-3 fzk name round trip and layout fill'); }
// K-12 次と同頁
{ const d = FZ.parse(H().replace('行数: 30', '行数: 5') + '一\n二\n三\n四\n[番号1 送らない]題\n本文\n'); const lay = FZ.layout(d); ok(lay.lineMap[4].rows[0].page === 0, 'K-12 送らない: title stays at page end', lay.lineMap[4].rows[0]);
  const d2 = FZ.parse(H().replace('行数: 30', '行数: 5') + '一\n二\n三\n四\n[番号1]題\n本文\n'); ok(FZ.layout(d2).lineMap[4].rows[0].page === 1, 'K-12 default: title moves with next');
  ok(FZ.serialize(d).includes('[番号1 送らない]') && /<w:keepNext w:val="0"\/>/.test(docx(d)), 'K-12 token and docx'); }
// K-6 区切り線
{ const d = FZ.fromGfm('前\n\n---\n\n後\n'); const hl = d.lines.find(l => l.attrs.hr); ok(hl && hl.segs[0].text === '' && !d.rules.length, 'K-6 --- imports as an hr line', d.lines.map(l => l.attrs));
  ok(/\n---\n/.test(FZ.toGfm(d)) && FZ.serialize(d).includes('[区切り]'), 'K-6 export --- and token');
  const lay = FZ.layout(d); ok(lay.pages[0].hrules.some(r => r.deco && /^hr/.test(r.id)), 'K-6 layout draws the rule');
  const ed = mkEd(H() + '本文\n'); ed.setCaret({ line: 0, seg: 0, off: 2 }); ed.insertHr(); ok(ed.doc.lines[1].attrs.hr && ed.caret.line === 2 && ed.doc.lines.length === 3, 'K-6 insertHr', ed.doc.lines.map(l => l.attrs)); }
// K-5 文中のコードと網掛け
{ const d = FZ.fromGfm('これは `npm install` と <mark>強調</mark> です\n'); const sg = d.lines[0].segs[0]; const i1 = sg.text.indexOf('npm'), i2 = sg.text.indexOf('強調');
  ok((sg.marks[i1] & M.CODE) && !(sg.marks[i1] & M.SHADE) && (sg.marks[i2] & M.SHADE), 'K-5 import: ` → CODE, <mark> → SHADE', sg.marks);
  const md = FZ.toGfm(d); ok(md.includes('`npm install`') && md.includes('<mark>強調</mark>'), 'K-5 export', md); const s = FZ.serialize(d); ok(s.includes('<コード>npm install</コード>') && FZ.serialize(FZ.parse(s)) === s, 'K-5 fzk tag', s.split('---\n')[1]); }
// K-7 本文を見出しの文字位置に揃える
{ const d = FZ.parse(H('本文位置: 見出しに揃える\n') + '[番号1]章\n本文\n[番号2]節\n本文2\n[字下げ0]左端に固定\n'); const lay = FZ.layout(d); const sc = i => lay.lineMap[i].segs[0].rows[0].startCol;
  ok(sc(1) === 2 && sc(3) === 4 && sc(4) === 0, 'K-7 body follows heading text start; explicit position wins', [sc(1), sc(3), sc(4)]); ok(FZ.serialize(d).includes('本文位置: 見出しに揃える'), 'K-7 header key'); }
// K-8 本文の行頭の Tab は位置
{ const ed = mkEd(H() + '本文の行\n'); ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.tab(false); ed.tab(false); ok(ed.line().attrs.indent === 2 && ed.line().segs[0].text === '本文の行', 'K-8 Tab Tab at line start = right right', ed.line());
  ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.tab(true); ok(ed.line().attrs.indent === 1, 'K-8 Shift+Tab = left'); ed.setCaret({ line: 0, seg: 0, off: 2 }); ed.tab(false); ok(/　/.test(ed.line().segs[0].text), 'K-8 mid-line Tab still inserts spaces'); }
// Markdown 読み込みの空行
{ const d = FZ.fromGfm('# 題\n\n## 背景\n\n本文。\n\n- a\n- b\n\n本文。\n\n## 表\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\n表の後。\n\n### ■ 記号\n\n本文。\n');
  const k = d.lines.map(l => l.attrs.style ? 'H' : l.attrs.list ? 'L' : l.attrs.cells ? 'T' : l.segs[0].text === '' ? '_' : 'P').join(''); ok(k === 'HHPLLP_HTT_P_HP', 'md spacing: no blank after headings / before lists; blank after tables and before headings', k); }
// Word：和欧間の自動空き・約物の詰め・柱空き・字の大きさ
{ const d = FZ.parse(H() + 'Excel と KPI は 12.5% 改善\n'); const x = docx(d);
  ok(x.includes('<w:autoSpaceDE w:val="0"/>') && x.includes('<w:autoSpaceDN w:val="0"/>') && x.includes('<w:wordWrap w:val="0"/>') && x.includes('doNotCompress'), 'Word: no auto space, mid-word wrap, no punctuation compression');
  const lay = FZ.layout(d), g = lay.geo; const m = x.match(/<w:pgMar w:top="(\d+)" w:right="(\d+)" w:bottom="(\d+)"/); const body = 20 * g.H - m[1] - m[3]; const line = Math.round(g.ch * 20);
  ok(body >= line * g.rows && body < line * (g.rows + 1), 'Word: body height fits exactly the rows (header gap included)', [body, line * g.rows]);
  const sz = +x.match(/<w:sz w:val="(\d+)"\/>/)[1]; ok(sz / 2 <= g.cw + 1e-6, 'Word: font size not larger than the cell', [sz / 2, g.cw]);
  ok(FZ.officeFont('BIZ UDMincho').ea === 'BIZ UD明朝 Medium' && x.includes('w:eastAsia="BIZ UD明朝 Medium"') && Buffer.from(FZ.toPptx(d)).toString('utf8').includes('typeface="BIZ UD明朝 Medium"'), 'Office font names'); }
// 網掛けの文字：続く字は 1 つの矩形、文字の網は薄い網
{ const d = FZ.parse(H() + '本文は<網掛け>網掛けの文字が続く</網掛け>です\n'); const svg = FZ.renderPage(FZ.layout(d), 0, { mono: true }); const rects = svg.match(/<rect [^>]*fill="url\(#s_text_0\)"\/>/g) || [];
  ok(rects.length === 1, 'shade: one merged rect per run', rects.length); ok(/id="s_text_0"[^>]*width="1.35"/.test(svg), 'shade: fine light screen'); }
console.log(`109f fails=${fails}`, 'errors:', errors);
