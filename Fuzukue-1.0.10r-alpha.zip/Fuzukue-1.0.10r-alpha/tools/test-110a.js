/* 1.0.10a：資料書式（版面の分割・柱・題の方式）、図版（図表欄・本文の流れ）、図番、画像の添付 */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-render']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, M = FZ.M; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info).slice(0, 500) : '')); } };
/* 100×75 の PNG（中身は真っ黒）と、幅 1000×高さ 10 の PNG の頭だけ（大きさの読み取りの試験） */
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAGQAAABLCAIAAAAJerXgAAAAMklEQVR4nO3BAQ0AAADCoPdPbQ8HFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPwYW7wAAX0VKLkAAAAASUVORK5CYII=';
const wide = (() => { const b = Buffer.from(PNG, 'base64'); b.writeUInt32BE(1000, 16); b.writeUInt32BE(10, 20); return b.toString('base64'); })();
const HEAD = (extra = '') => `#fzk 2\n題名: 報告\n用紙: A4 横\n文字数: 60\n行数: 26\n柱行: 2 0\n書式: 資料\n本文幅: 60%\n作成者: 営業部\n作成日: 2026年11月1日\n機密: 社外秘\n${extra}---\n`;
const ATT = (name = '画像1.png', data = PNG) => `===\n#添付 ${name} image/png\n${data}\n`;
const mkEd = text => { const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(text)); return ed; };
const lineText = (lay, i) => lay.lineMap[i].segs[0].rows.map(r => r.glyphs.map(g => g.text).join('')).join('');
const headText = pg => pg.head ? pg.head.glyphs.map(g => g.text).join('') : '';

// ---- 原本：書式の鍵・図版・添付・図番の往復 ----
{ const src = HEAD('仕切り: 点線\n柱の罫: 太\n頁番号: 丸\n') + '[表題]売上\n本文<図番 a>と<図番 b>。\n#図版 a 図 売上の 推移 画像1.png\n#図版 b 表 指標 画像1.png 50%\n' + ATT();
  const d = FZ.parse(src); const f = d.format;
  ok(f.kind === 'slide' && f.bodyPct === 60 && f.divider === 'dotted' && f.headRule === 'thick' && f.pageMark === 'circle' && f.author === '営業部' && f.date === '2026年11月1日' && f.secret === '社外秘', 'format keys parsed', f);
  ok(d.lines.length === 2 && d.lines[1].attrs.figs.length === 2, 'figs attach to previous line', d.lines.map(l => l.attrs));
  const fa = d.lines[1].attrs.figs[0], fb = d.lines[1].attrs.figs[1]; ok(fa.title === '売上の 推移' && fa.width === 100 && fb.kind === '表' && fb.width === 50, 'fig fields', [fa, fb]);
  ok(d.images['画像1.png'] && d.images['画像1.png'].data === PNG, 'attachment read');
  ok(FZ.isRefChar(Array.from(d.lines[1].segs[0].text)[2]) && d.refs.ids.join() === 'a,b', 'refs become one char each', d.refs);
  const s = FZ.serialize(d); ok(FZ.serialize(FZ.parse(s)) === s, 'round trip stable'); ok(s.includes('本文<図番 a>と<図番 b>。') && /#図版 b 表 指標 画像1\.png 50%/.test(s) && s.includes('#添付 画像1.png image/png'), 'serialized forms', s.split('---\n')[1]);
  ok(FZ.imageSize(d.images['画像1.png']).w === 100 && FZ.imageSize(d.images['画像1.png']).h === 75, 'png size'); ok(FZ.imageSize({ mime: 'image/png', data: wide }).w === 1000, 'png size header');
  ok(FZ.imageSize({ mime: 'image/png', data: '%%%壊れた' }).w === 4, 'broken base64 falls back to 4:3');
  // 使っていない画像は書かない／=== の本文行は区切りにならない
  const d2 = FZ.parse(HEAD() + '===\n\\#添付 は本文\n本文\n' + ATT('未使用.png')); ok(d2.lines.map(l => l.segs[0].text).join('|') === '===|#添付 は本文|本文' && !FZ.serialize(d2).includes('#添付 未使用'), 'body === and unused attachments', d2.lines.map(l => l.segs[0].text));
  ok(FZ.serialize(FZ.parse(FZ.serialize(d2))) === FZ.serialize(d2), 'body === round trip');
  // 外字（BMP の私用領域）は図番にしない
  const eudc = ''; const d3 = FZ.parse(HEAD() + '外字' + eudc + 'です\n'); ok(d3.lines[0].segs[0].text === '外字' + eudc + 'です' && FZ.serialize(d3).includes('外字' + eudc + 'です'), 'EUDC char stays text');
  const d4 = FZ.parse(HEAD() + '迷子<図番 zz>\n'); const l4 = FZ.layout(d4); ok(lineText(l4, 0) === '迷子図 ?', 'unknown ref shows 図 ?', lineText(l4, 0)); ok(FZ.serialize(d4).includes('<図番 zz>'), 'unknown ref kept');
  const dup = FZ.normalize({ format: FZ.newDoc().format, lines: [{ segs: [FZ.newSeg(0, 'a')], attrs: { figs: [{ id: 'x', file: '' }, { id: 'x', file: '' }] } }] }); ok(dup.lines[0].attrs.figs[1].id === 'x_2', 'duplicate fig ids renamed', dup.lines[0].attrs.figs); }

// ---- 版面：本文欄・柱・題の引き上げ ----
{ const body = Array.from({ length: 40 }, (_, k) => '本文の行' + k + '、本文欄の幅で折り返すはずの長い文章をここに置いておく。').join('\n');
  const d = FZ.parse(HEAD() + '[表題]第一の題\n' + body + '\n[表題]第二の題\n短い\n');
  const lay = FZ.layout(d), geo = lay.geo; ok(geo.bodyCols === 36 && geo.sideLeft === 37 && geo.side, 'geometry body/side', [geo.bodyCols, geo.sideLeft]);
  let over = 0; for (const p of lay.pages) for (const g of p.glyphs) if (g.y >= 0 && g.col + g.w > geo.bodyCols + 1e-6 && !g.marker) over++; ok(over === 0, 'body text stays within body column', over);
  ok(lay.lineMap[0].rows[0].y === -geo.bodyTop && lay.pages[0].titleLine === 0, 'title lifted into header', lay.lineMap[0].rows[0]);
  const gT = lay.pages[0].glyphs.filter(g => g.line === 0); ok(gT.length === 4 && gT.every(g => g.sx === 1.5 && (g.marks & M.BOLD)), 'title glyphs 1.5x bold', gT.map(g => [g.sx, g.marks]));
  ok(lay.lineMap[1].rows[0].y === 0, 'first body line at top', lay.lineMap[1].rows[0]);
  const t2 = d.lines.length - 2; const p2 = lay.lineMap[t2].rows[0].page; ok(lay.pages[p2].titleLine === t2 && lay.lineMap[t2 + 1].rows[0].y === 0 && lay.lineMap[t2 + 1].rows[0].page === p2, 'second title starts new page', [p2, lay.lineMap[t2 + 1].rows[0]]);
  ok(lay.pages.length >= 3, 'multi pages', lay.pages.length);
  const mid = lay.pages[1]; ok(mid.titleLine == null && headText(mid).startsWith('第一の題'), 'page without title inherits', headText(mid));
  ok(headText(lay.pages[0]).includes('社外秘') && headText(lay.pages[0]).includes('2026年11月1日') && headText(lay.pages[0]).includes('営業部') && headText(lay.pages[1]).endsWith('2'), 'header info and page number', headText(lay.pages[1]));
  { const pb = lay.pages[0].head.boxes.find(b => b.col === geo.cols - 3); ok(pb && Math.abs(pb.y + pb.h / 2 - (-geo.bodyTop + geo.headerRows / 2)) < 1e-9, 'page box centered on header middle line', pb); }
  { const da = FZ.parse(HEAD().replace('作成日: 2026年11月1日', '作成日: 自動') + '[表題]題\n本文\n'); ok(da.format.dateAuto && headText(FZ.layout(da).pages[0]).includes(FZ.todayJa()) && FZ.serialize(da).includes('作成日: 自動') && FZ.serialize(FZ.parse(FZ.serialize(da))) === FZ.serialize(da), 'date auto shows today and round trips'); }
  ok(lay.pages[0].head.boxes.length === 2 && lay.pages[0].head.rules.length === 1 && lay.pages[0].head.rules[0].y === -geo.bodyTop + geo.headerRows, 'header boxes and rule', lay.pages[0].head);
  const svg = FZ.renderPage(lay, 0, { mono: true }); ok(svg.includes('第') && /<rect x="[\d.]+" y="[\d.]+" width="[\d.]+" height="[\d.]+" fill="none" stroke="#000" stroke-width="0.6"\/>/.test(svg), 'render header');
  // 長い題は … で切る
  const d5 = FZ.parse(HEAD() + '[表題]' + 'とても長い題'.repeat(12) + '\n本文\n'); const l5 = FZ.layout(d5); const tg = l5.pages[0].glyphs.filter(g => g.line === 0); const ell = tg.find(g => g.text === '…');
  ok(ell && tg.every(g => g.col + g.w <= l5.geo.cols + 1e-6) && Math.max(...tg.map(g => g.col + g.w)) <= l5.pages[0].head.boxes[0].col, 'long title truncated before info', [ell && ell.col, l5.pages[0].head.boxes[0]]);
  // 柱の題「通し」：題名を出し、表題は本文に
  const d6 = FZ.parse(HEAD('柱の題: 題名\n') + '[表題]本文の表題\n本文\n'); const l6 = FZ.layout(d6); ok(headText(l6.pages[0]).startsWith('報告') && l6.lineMap[0].rows[0].y === 0, 'headTitle doc', [headText(l6.pages[0]), l6.lineMap[0].rows[0]]);
  ok(FZ.serialize(d6).includes('柱の題: 題名') && FZ.parse(FZ.serialize(d6)).format.headTitle === 'doc', 'headTitle round trip');
  // 文書の書式では何も変わらない
  const d7 = FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n---\n[表題]題\n本文\n'); const l7 = FZ.layout(d7); ok(l7.geo.bodyCols === 40 && !l7.pages[0].head && l7.lineMap[0].rows[0].y === 0, 'doc kind unchanged'); }

// ---- 図表欄：積む・並べる・溢れる ----
{ const figs = n => Array.from({ length: n }, (_, k) => `#図版 f${k} 図 図その${k} 画像1.png`).join('\n');
  const d = FZ.parse(HEAD() + '本文<図番 f1>\n' + figs(1) + '\n#図版 h1 表 半分 画像1.png 50%\n#図版 h2 図 半分2 画像1.png 50%\n' + ATT());
  const lay = FZ.layout(d), geo = lay.geo, side = lay.pages[0].side;
  ok(side.images.length === 3 && side.images.every(im => im.col >= geo.sideLeft && im.col + im.w <= geo.cols + 1e-6), 'figures in side column', side.images.map(i => [i.col, i.w]));
  const [a, h1, h2] = side.images; ok(h1.y === h2.y && h2.col > h1.col && h1.w === h2.w && h1.w * 2 + 1 === geo.cols - geo.sideLeft, 'two 50% side by side fill the column', [h1, h2]);
  ok(a.h === Math.round(23 * geo.cw * 0.75 / geo.ch), 'image rows from aspect', [a.h, geo.cw, geo.ch]);
  const cap = side.glyphs.map(g => g.text).join(''); ok(cap.includes('図 1　図その0') && cap.includes('表 1　半分') && cap.includes('図 2　半分2'), 'captions numbered per kind', cap);
  ok(lineText(lay, 0) === '本文図 ?', 'ref to missing id', lineText(lay, 0));
  const d2 = FZ.parse(HEAD() + '本文<図番 f0>と<図番 h2>\n' + figs(1) + '\n#図版 h2 図 半分2 画像1.png 50%\n' + ATT()); ok(lineText(FZ.layout(d2), 0) === '本文図 1と図 2', 'refs show numbers', lineText(FZ.layout(d2), 0));
  // 溢れ：図版 6 枚（各 13 行＋題）→ 1 ページに 1 枚ずつ、本文の後ろに図表だけのページ
  const d3 = FZ.parse(HEAD() + '本文だけ\n' + figs(6) + '\n' + ATT()); const l3 = FZ.layout(d3);
  ok(l3.bodyPages === 1 && l3.pages.length === 6 && l3.pages.slice(1).every(p => p.overflow && p.side.images.length === 1), 'overflow figures make extra pages', [l3.bodyPages, l3.pages.length, l3.pages.map(p => p.side.images.length)]);
  ok(headText(l3.pages[5]).endsWith('6'), 'overflow pages get header', headText(l3.pages[5]));
  // 本文が次のページに送られれば図版も付いていく
  const d4 = FZ.parse(HEAD() + Array.from({ length: 30 }, (_, k) => '行' + k).join('\n') + '\n' + figs(1) + '\n' + ATT()); const l4 = FZ.layout(d4); ok(l4.pages[1].side.images.length === 1 && l4.pages[0].side.images.length === 0, 'figure follows its line to page 2');
  // ページより高い図版は縮めて置く
  const d5 = FZ.parse(HEAD() + '縦長\n#図版 t 図 縦長 tall.png\n' + ATT('tall.png', (() => { const b = Buffer.from(PNG, 'base64'); b.writeUInt32BE(10, 16); b.writeUInt32BE(1000, 20); return b.toString('base64'); })())); const l5 = FZ.layout(d5); const im5 = l5.pages[0].side.images[0];
  ok(im5 && im5.y + im5.h <= l5.geo.rows && l5.pages.length === 1, 'tall figure shrinks to page', im5);
  // 30 枚
  const d6 = FZ.parse(HEAD() + Array.from({ length: 10 }, (_, k) => '行' + k + '\n' + `#図版 a${k} 図 x 画像1.png 50%\n#図版 b${k} 表 y 画像1.png 50%\n#図版 c${k} 図 z 画像1.png 75%`).join('\n') + '\n' + ATT()); const l6 = FZ.layout(d6);
  ok(l6.pages.reduce((n, p) => n + p.side.images.length, 0) === 30, '30 figures all placed', l6.pages.map(p => p.side.images.length));
  // 画像が無い図版：破線の枠
  const d7 = FZ.parse(HEAD() + '本文\n#図版 x 図 なし -\n'); const l7 = FZ.layout(d7); const sv = FZ.renderPage(l7, 0, { mono: true }); ok(sv.includes('（画像なし）') && l7.pages[0].side.images.length === 1, 'missing image placeholder');
  const sv2 = FZ.renderPage(lay, 0, { mono: true }); ok((sv2.match(/<image class="figimg"/g) || []).length === 3, 'images rendered', (sv2.match(/<image/g) || []).length);
  const d8 = FZ.parse(HEAD('仕切り: 細\n') + '本文\n'); const l8 = FZ.layout(d8); ok(l8.pages[0].side.rules.length === 1 && l8.pages[0].side.rules[0].col === 36.5, 'divider rule'); }

// ---- 文書の書式：図版は本文の流れに ----
{ const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n---\n前の行\n#図版 a 図 流れの図 画像1.png 50%\n後の行\n' + ATT()); const lay = FZ.layout(d); const im = lay.pages[0].images[0];
  ok(im && im.y === 2 && im.w === 19 && im.col === 10.5, 'inline figure position', im);
  ok(lay.lineMap[1].rows[0].y === im.y + im.h, 'next line below figure', [lay.lineMap[1].rows[0].y, im]);
  ok(lay.pages[0].glyphs.filter(g => g.figcap).map(g => g.text).join('') === '図 1　流れの図', 'inline caption'); }

// ---- 編集：行の分割・結合で図版が迷子にならない／取消 ----
{ const ed = mkEd(HEAD() + 'あいうえお\n#図版 a 図 題 画像1.png\nかきく\n' + ATT());
  ed.setCaret({ line: 0, seg: 0, off: 2 }); ed.enter(); ok(ed.doc.lines[0].attrs.figs && !ed.doc.lines[1].attrs.figs, 'split mid: figs stay on first part');
  ed.backspace(); ok(ed.doc.lines.length === 2 && ed.doc.lines[0].attrs.figs.length === 1, 'join keeps figs');
  ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.enter(); ok(!ed.doc.lines[0].attrs.figs && ed.doc.lines[1].attrs.figs, 'split at start: figs move down with text');
  ed.undo(); ok(ed.doc.lines[0].attrs.figs && ed.doc.lines.length === 2, 'undo restores');
  ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.backspace(); ok(ed.doc.lines.length === 1 && ed.doc.lines[0].attrs.figs, 'backspace join from next line keeps figs');
  ed.undo(); ed.setCaret({ line: 0, seg: 0, off: 5 }); ed.del(); ok(ed.doc.lines[0].attrs.figs.length === 1, 'del join keeps figs');
  const ed2 = mkEd(HEAD() + '一\n二\n#図版 a 図 題 画像1.png\n三\n' + ATT()); ed2.setCaret({ line: 0, seg: 0, off: 1 }); ed2.setCaret({ line: 1, seg: 0, off: 1 }, true); ed2.deleteSelection(); ok(ed2.doc.lines[0].attrs.figs && ed2.doc.lines[0].attrs.figs[0].id === 'a', 'range delete moves tail figs', ed2.doc.lines.map(l => l.attrs));
  // 図版の操作
  const ed3 = mkEd(HEAD() + '一\n二\n' + ATT()); const nm = ed3.addImage('image/png', PNG, ''); ok(nm === '画像1.png', 'addImage dedupes by data', nm); const nm2 = ed3.addImage('image/png', wide, 'グラフ 1.png'); ok(nm2 === 'グラフ_1.png', 'addImage name', nm2);
  ed3.setCaret({ line: 0, seg: 0, off: 0 }); const id1 = ed3.addFigure({ file: nm, title: 'A' }); ed3.setCaret({ line: 1, seg: 0, off: 0 }); const id2 = ed3.addFigure({ file: nm2, title: 'B', kind: '表' }); const id3 = ed3.addFigure({ file: nm, title: 'C' });
  ok(id1 === 'f1' && id2 === 'f2' && ed3.figList().length === 3, 'addFigure ids'); ed3.setCaret({ line: 0, seg: 0, off: 1 }); ed3.insertRef(id3); ok(lineText(ed3.lay, 0) === '一図 2', 'insertRef label', lineText(ed3.lay, 0));
  ed3.moveFig(id3, -1); ed3.moveFig(id3, -1); ok(ed3.figList()[0].fg.id === id3 && ed3.doc.lines[0].attrs.figs[0].id === id3 && lineText(ed3.lay, 0) === '一図 1', 'moveFig up across lines renumbers refs', [ed3.figList().map(x => x.line + x.fg.id), lineText(ed3.lay, 0)]);
  ed3.setFig(id2, { kind: '図', width: 75, title: 'B2' }); ok(ed3.figById(id2).fg.width === 75 && ed3.figById(id2).fg.kind === '図', 'setFig');
  ed3.removeFig(id3); ok(lineText(ed3.lay, 0) === '一図 ?', 'removed fig ref shows ?'); ed3.undo(); ok(lineText(ed3.lay, 0) === '一図 1', 'undo remove');
  // 図番は 1 字として動く・消える
  ed3.setCaret({ line: 0, seg: 0, off: 1 }); ed3.moveH(1); ok(ed3.caret.off === 3, 'caret skips ref as one char', ed3.caret.off); ed3.backspace(); ok(ed3.doc.lines[0].segs[0].text === '一', 'backspace removes whole ref');
  const s = FZ.serialize(ed3.doc); ok(s.includes('グラフ_1.png image/png') && FZ.serialize(FZ.parse(s)) === s, 'editor doc round trip'); }

// ---- 柱の表題への上下移動 ----
{ const ed = mkEd(HEAD() + '[表題]題\n一行目\n二行目\n[表題]次\n三\n'); ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.moveV(-1); ok(ed.caret.line === 0, 'up from first body row to header title', ed.caret);
  ed.moveV(1); ok(ed.caret.line === 1, 'down from header title to body', ed.caret); ed.setCaret({ line: 2, seg: 0, off: 0 }); ed.moveV(1); ok(ed.caret.line === 3, 'down across page into next header title', ed.caret); ed.moveV(-1); ok(ed.caret.line === 2, 'up from header title to previous page', ed.caret);
  ed.setCaret({ line: 0, seg: 0, off: 1 }); ed.insertText('目'); ok(ed.doc.lines[0].segs[0].text === '題目' && ed.lay.lineMap[0].rows[0].y < 0, 'typing in header title'); }

// ---- 差分組版の同値（資料書式・図版・図番） ----
{ let seed = 11; const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const canon = lay => JSON.stringify({ P: lay.pages.map(p => ({ g: p.glyphs.map(g => [g.line, g.off, g.col, g.y, g.text, g.sx]).sort(), rm: [...p.rowmap.entries()].sort((a, b) => a[0] - b[0]).map(([y, es]) => [y, es.map(e => [e.line, e.k, e.startCol, e.endCol])]), side: p.side ? [p.side.images.map(i => [i.id, i.col, i.y, i.w, i.h]), p.side.glyphs.map(g => g.text).join('')] : null, head: headText(p), t: p.titleLine })), L: lay.lineMap.map(lm => lm.rows.map(r => [r.page, r.y, r.h])) });
  let mism = 0, steps = 0;
  for (let trial = 0; trial < 6; trial++) { const lines = []; for (let k = 0; k < 60; k++) { const r = rnd(); lines.push(r < 0.08 ? '[表題]題' + k : r < 0.2 ? '[番号1]見出し' + k : '本文' + k + (rnd() < 0.3 ? '<図番 f' + (k % 7) + '>' : '') + 'の文章が続く。'.repeat(1 + Math.floor(rnd() * 4))); if (rnd() < 0.15) lines.push(`#図版 f${k} ${rnd() < 0.5 ? '図' : '表'} 題${k} 画像1.png ${rnd() < 0.5 ? '50%' : '100%'}`); }
    const ed = mkEd(HEAD() + lines.join('\n') + '\n' + ATT());
    for (let s = 0; s < 30; s++) { const li = Math.floor(rnd() * ed.doc.lines.length); ed.setCaret({ line: li, seg: 0, off: 0 }); const op = rnd();
      if (op < 0.4) ed.insertText('あいう'); else if (op < 0.55) ed.enter(); else if (op < 0.7) ed.backspace(); else if (op < 0.8 && ed.figList().length) ed.moveFig(ed.figList()[0].fg.id, 1); else if (op < 0.9) ed.setHeading('num'); else ed.addFigure({ file: '画像1.png', title: 'new' });
      steps++; const a = canon(ed.lay), b = canon(FZ.layout(ed.doc)); if (a !== b) { mism++; if (mism < 3) ok(false, `inc mismatch trial ${trial} step ${s}`); } } }
  ok(mism === 0, 'incremental layout equals full layout', { mism, steps }); }

// ---- 書き出し ----
{ const d = FZ.parse(HEAD() + '[表題]題\n本文<図番 a>参照\n#図版 a 図 売上 画像1.png\n' + ATT()); const md = FZ.toGfm(d);
  ok(md.includes('本文図 1参照') && md.includes('**図 1　売上**') && md.includes('![図 1　売上](画像1.png)'), 'markdown: refs and figures', md);
  const pl = FZ.toPlain(d); ok(!/[\u{F0000}-\u{FFFFD}]/u.test(pl) && pl.includes('図 1　売上'), 'plain text expanded', pl);
  let e1 = null; try { FZ.toDocx(d); FZ.toPptx(d); } catch (e) { e1 = e.message; } ok(!e1, 'docx/pptx do not throw', e1);
  const ex = FZ.expandRefs(d, { text: 'x' + FZ.refChar(d, 'a') + 'yz', marks: [1, 2, 2, 3, 4], links: [{ start: 3, end: 5, url: 'u' }] }); ok(ex.text === 'x図 1yz' && ex.marks.join('') === '122234' && ex.links[0].start === 4 && ex.links[0].end === 6, 'expandRefs keeps marks and links', ex); }

// ---- PowerPoint：資料の版面のまま（柱＝タイトル・機密表示・日付・頁番号、図表欄＝画像と番号・題） ----
{ const part = (u8, name) => { const s = Buffer.from(u8).toString('latin1'); name = Buffer.from(name, 'utf8').toString('latin1'); const k = s.indexOf(name + '<?xml'); if (k < 0) return null; const a = k + name.length; /* 無圧縮の ZIP：ローカルヘッダの名前の直後が中身 */ const b = s.indexOf('PK\u0003\u0004', a); return Buffer.from(s.slice(a, b < 0 ? undefined : b), 'latin1').toString('utf8'); };
  const d = FZ.parse(HEAD('仕切り: 細\n') + '[表題]売上の<下線>現状</下線>\n本文<図番 a>参照\n#図版 a 図 売上 画像1.png\n#図版 b 表 指標 画像1.png 50%\n#図版 c 図 ベクタ vec.svg 50%\n[表題]次の題\n二枚目\n' + ATT() + '#添付 vec.svg image/svg+xml\nPHN2Zz48L3N2Zz4=\n');
  const lay = FZ.layout(d); const u8 = FZ.toPptx(d); const s1 = part(u8, 'ppt/slides/slide1.xml'), s2 = part(u8, 'ppt/slides/slide2.xml'), all = Buffer.from(u8).toString('utf8');
  ok(s1 && s2 && !part(u8, 'ppt/slides/slide3.xml') && lay.pages.length === 2, 'one slide per page', lay.pages.length);
  ok(/<p:ph type="title"\/>/.test(s1) && s1.indexOf('<p:ph type="title"/>') < s1.indexOf('本文'), 'title placeholder first');
  ok(/<a:t>売上の<\/a:t>/.test(s1) && /u="sng"[^>]*>(?:(?!<\/a:rPr>).)*<\/a:rPr><a:t>現状<\/a:t>/.test(s1), 'title text keeps user marks', s1.slice(s1.indexOf('タイトル 1'), s1.indexOf('タイトル 1') + 900));
  ok(s1.includes('<a:t>社外秘</a:t>') && s1.includes('<a:t>営業部</a:t>') && s1.includes('<a:t>2026年11月1日</a:t>') && s1.includes('type="slidenum"'), 'header info shapes');
  ok((s1.match(/<p:pic>/g) || []).length === 2 && s1.includes('descr="図 1　売上"') && s1.includes('descr="表 1　指標"'), 'native pictures with alt text', (s1.match(/<p:pic>/g) || []).length);
  ok(s1.includes('この形式の画像は書き出せません'), 'svg falls back to placeholder');
  ok(s1.includes('<a:t>本文図 1参照</a:t>') && !/[\u{F0000}-\u{FFFFD}]/u.test(all), 'refs expanded in pptx');
  ok(all.includes('<Default Extension="png" ContentType="image/png"/>') && all.includes('ppt/media/image1.png') && !all.includes('ppt/media/image2'), 'media packaged once');
  ok(/<p:sp><p:nvSpPr><p:cNvPr id="\d+" name="タイトル 1"\/>/.test(s2) && s2.includes('<a:t>次の題</a:t>') && s2.includes('<a:t>2</a:t></a:fld>'), 'second slide title and number');
  const vline = s1.match(/<p:cxnSp>(?:(?!<\/p:cxnSp>).)*<\/p:cxnSp>/g) || []; ok(vline.length >= 2, 'divider and header rule lines', vline.length);
  const layoutX = part(u8, 'ppt/slideLayouts/slideLayout1.xml'); ok(layoutX.includes('type="titleOnly"') && layoutX.includes('<p:ph type="title"/>'), 'layout has title placeholder');
  // 通し（題名）・文書の書式（図版は行の下に画像）
  const d2 = FZ.parse(HEAD('柱の題: 題名\n') + '[表題]本文の表題\n本文\n'); const t2 = part(FZ.toPptx(d2), 'ppt/slides/slide1.xml'); ok(/タイトル 1(?:(?!<\/p:sp>).)*<a:t>報告<\/a:t>/.test(t2) && t2.includes('<a:t>本文の表題</a:t>'), 'headTitle doc: doc title in header, title line in body');
  const d3 = FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n---\n前\n#図版 a 図 流れの図 画像1.png\n後\n' + ATT()); const t3 = part(FZ.toPptx(d3), 'ppt/slides/slide1.xml'); ok(t3.includes('<p:pic>') && !t3.includes('<p:ph type="title"') && t3.includes('<a:t>図 1　流れの図</a:t>'), 'doc kind: inline picture, no title placeholder');
  // 本文の箱は文章の構造の単位：見出し（レベルを問わない）＋その本文・箇条書きで 1 箱。空行で切らない。ページをまたぐ段落はページごとに分け、続きの箱は「（続き）」
  const boxes = xml => (xml.match(/<p:sp>(?:(?!<\/p:sp>).)*<\/p:sp>/g) || []).map(sp => ({ name: (sp.match(/name="([^"]*)"/) || [])[1], paras: (sp.match(/<a:p>(?:(?!<\/a:p>).)*<\/a:p>/g) || []).map(pp => (pp.match(/<a:t>([^<]*)<\/a:t>/g) || []).map(t => t.slice(5, -6)).join('')) })).filter(x => x.paras.length && !/^(タイトル 1|機密表示|作成日・作成者|頁番号|スライド番号プレースホルダー \d+)$/.test(x.name));
  const ds = FZ.parse(HEAD() + '[表題]題\n導入の文\n[番号1]背景\n[番号2]市場\n市場の本文\n[項目1]国内\n\n[番号2]競合\n競合の本文\n[番号3]価格\n価格の本文\n[記号1]課題\n課題の本文\n[引用]引用も節の中\n[番号1]方針\n' + '方針の本文が長く続く。'.repeat(90) + '\n[項目1]方針の箇条\n');
  const us = FZ.toPptx(ds); const b1 = boxes(part(us, 'ppt/slides/slide1.xml')), b2 = boxes(part(us, 'ppt/slides/slide2.xml'));
  const sig = b1.map(x => x.name + ':' + x.paras.length).join(' / ');
  ok(sig === '本文:1 / 1. 背景:1 / （1） 市場:3 / （2） 競合:2 / ① 価格:2 / ■課題:3 / 2. 方針:2', 'one text box per heading section', sig);
  ok(b1.find(x => x.name === '（1） 市場').paras.join('|') === '（1） 市場|市場の本文|・国内', 'section box: heading + body + bullets, trailing blank dropped', b1.find(x => x.name === '（1） 市場'));
  ok(b2.length === 1 && b2[0].name === '2. 方針（続き）' && b2[0].paras[b2[0].paras.length - 1] === '・方針の箇条', 'page-spanning section continues in a named box', b2.map(x => x.name));
  { const s2b = b1.find(x => x.name === '2. 方針') || { paras: [] }; const p1 = s2b.paras[1], p2 = b2[0].paras[0]; ok(p1 + p2 === '方針の本文が長く続く。'.repeat(90) && p1.length > 0 && p2.length > 0, 'paragraph split exactly at the page break', [p1.length, p2.length]); }
  ok(/name="（2） 競合"\/>(?:(?!<\/p:sp>).)*<a:spAutoFit\/>/.test(part(us, 'ppt/slides/slide1.xml')), 'section boxes grow with text');
  // 溢れた図表だけのページもスライドに
  const d4 = FZ.parse(HEAD() + '本文だけ\n' + Array.from({ length: 4 }, (_, k) => `#図版 f${k} 図 図${k} 画像1.png`).join('\n') + '\n' + ATT()); const u4 = FZ.toPptx(d4); ok(part(u4, 'ppt/slides/slide4.xml') && (part(u4, 'ppt/slides/slide4.xml').match(/<p:pic>/g) || []).length === 1, 'overflow pages become slides'); }

console.log('110a fails=' + fails, 'errors:', errors);
process.exit(fails ? 1 : 0);
