/* 1.0.10a.3：Markdown の ** の取り込み（和文の緩和・余りの除去・残った ** の救済）、番号付き箇条書き、節の前の空きと区切り線 */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-render']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, M = FZ.M; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info).slice(0, 500) : '')); } };
const H = (extra = '') => '#fzk 2\n文字数: 40\n行数: 30\n' + extra + '---\n';
const mkEd = text => { const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(text)); return ed; };
const rowText = (lay, i) => lay.lineMap[i].segs[0].rows[0].glyphs.map(g => g.text).join('');
const boldOf = sg => sg.marks.map(m => m & M.BOLD ? 'B' : '.').join('');
const part = (u8, name) => { const s = Buffer.from(u8).toString('latin1'); name = Buffer.from(name, 'utf8').toString('latin1'); const k = s.indexOf(name + '<?xml'); if (k < 0) return null; const a = k + name.length; const b = s.indexOf('PK\u0003\u0004', a); return Buffer.from(s.slice(a, b < 0 ? undefined : b), 'latin1').toString('utf8'); };

// ---- 1 ** の取り込み ----
{ const d = FZ.fromGfm('- **国内：**主力の需要\n- 文中の**「重要」**です。\n- **重要。**次の文\n- 閉じ忘れの**強調\n- 普通の **太字** です\n- 価格は~~千円~~**八百円**に\n');
  const L = d.lines.map(l => l.segs[0]);
  ok(L[0].text === '国内：主力の需要' && boldOf(L[0]) === 'BBB.....', 'bold ending with CJK punctuation', [L[0].text, boldOf(L[0])]);
  ok(L[1].text === '文中の「重要」です。' && boldOf(L[1]) === '...BBBB...', 'bold starting with CJK bracket', [L[1].text, boldOf(L[1])]);
  ok(L[2].text === '重要。次の文' && boldOf(L[2]) === 'BBB...', 'bold ending with 。');
  ok(L[3].text === '閉じ忘れの強調' && !/\*/.test(L[3].text), 'stray ** removed', L[3].text);
  ok(L[4].text === '普通の 太字 です' && boldOf(L[4]) === '....BB...', 'ordinary bold unchanged');
  ok(L[5].text === '価格は千円八百円に' && (L[5].marks[3] & M.STRIKE) && (L[5].marks[5] & M.BOLD), 'strike then bold');
  const html = FZ.md.parse('**国内：**主力'); let lit = ''; const walk = n => { if (n.type === 'text') lit += n.literal; for (let c = n.firstChild; c; c = c.next) walk(c); }; walk(html); ok(lit.includes('**'), 'spec mode (no cjk option) keeps strict rules', lit);
  // 以前に取り込んだ文書の ** を太字に
  const ed = mkEd(H() + '・**国内：**主力\n文中の**「重要」**です**余り\n<コード>a**b**c</コード>は残す\n[コード]x = 2**3**4\n');
  ok(ed.countMdStars() === 7, 'count stars', ed.countMdStars()); const n = ed.cleanMdStars(); ok(n === 3, 'clean stars count', n);
  ok(ed.doc.lines[0].segs[0].text === '・国内：主力' && boldOf(ed.doc.lines[0].segs[0]) === '.BBB..', 'clean: pair to bold', boldOf(ed.doc.lines[0].segs[0]));
  ok(ed.doc.lines[1].segs[0].text === '文中の「重要」です余り', 'clean: stray removed', ed.doc.lines[1].segs[0].text);
  ok(ed.doc.lines[2].segs[0].text === 'a**b**cは残す' && ed.doc.lines[3].segs[0].text === 'x = 2**3**4', 'clean: code untouched');
  ed.undo(); ok(ed.doc.lines[0].segs[0].text === '・**国内：**主力', 'clean undo'); }

// ---- 2 番号付き箇条書き ----
{ const d = FZ.parse(H() + '[番号1]方針\n本文\n[番号項目1]一つ目\n[番号項目1]二つ目\n[番号項目2]子\n[番号項目2]子2\n[続き1]続きの段落\n[番号項目1]三つ目\n\n[番号項目1]空行の後も続く\n本文で切れる\n[番号項目1]また1\n[項目1]記号\n[番号項目1]記号の後は1から\n[番号項目1 再開5]五\n[番号1]見出しで切れる\n[番号項目1]1から\n');
  const lay = FZ.layout(d); const mk = i => lay.lineMap[i].segs[0].rows[0].glyphs.filter(g => g.marker).map(g => g.text).join('').trim();
  ok([2, 3, 4, 5, 7, 9, 11, 13, 14, 16].map(mk).join(' ') === '1） 2） a） b） 3） 4） 1） 1） 5） 1）', 'numbering rules', [2, 3, 4, 5, 7, 9, 11, 13, 14, 16].map(mk));
  const s = FZ.serialize(d); ok(s.includes('[番号項目2]子') && s.includes('[番号項目1 再開5]五') && FZ.serialize(FZ.parse(s)) === s, 'fzk token round trip');
  ok(!s.includes('番号箇条書き:'), 'default list scheme not written'); const d2 = FZ.parse(H('番号箇条書き: ① （a） ⅰ） 1） a） ⅰ） 1） a）\n') + '[番号項目1]x\n[番号項目2]y\n'); const l2 = FZ.layout(d2);
  ok(l2.lineMap[0].segs[0].rows[0].glyphs[0].text === '①' && FZ.serialize(d2).includes('番号箇条書き: ① （a）'), 'custom list scheme', FZ.serialize(d2).split('---')[0]);
  // Markdown：番号付きリスト ↔ 番号付き箇条書き（以前は数字見出しの段落レベル）
  const md = '## 方針\n\n本文。\n\n1. 一つ目\n2. 二つ目\n   - 記号\n   1. 子\n3. 三つ目\n\n本文。\n\n5. 五から\n';
  const g = FZ.fromGfm(md); const lists = g.lines.filter(l => l.attrs.list).map(l => (l.attrs.list.kind || 'b') + l.attrs.list.level + (l.attrs.restart ? 'r' + l.attrs.restart : ''));
  ok(lists.join(' ') === 'num0 num0 b1 num1 num0 num0r5', 'md ordered → numbered list items', lists);
  const back = FZ.toGfm(g); ok(back.includes('1. 一つ目\n2. 二つ目\n   - 記号\n   1. 子\n3. 三つ目') && back.includes('\n5. 五から'), 'md export numbered list', back);
  ok(JSON.stringify(FZ.fromGfm(back).lines.map(l => l.attrs)) === JSON.stringify(g.lines.map(l => l.attrs)), 'md round trip');
  const p = FZ.parse(H() + '[番号1]章\n[番号2]節\n[番号1]章2\n[番号2]節2\n[番号3]段落の見出し\n本文\n'); const pm = FZ.toGfm(p); ok(/### ① 段落の見出し/.test(pm) && !/^\d+\. /m.test(pm), 'paragraph-level numbered headings stay headings in md', pm);
  ok(JSON.stringify(FZ.fromGfm(pm).lines.map(l => [l.attrs.style, l.attrs.level])) === JSON.stringify(p.lines.map(l => [l.attrs.style, l.attrs.level])), 'heading levels round trip', FZ.fromGfm(pm).lines.map(l => l.attrs));
  // Word：番号の列ごとの番号の実体
  const wu = FZ.toDocx(FZ.parse(H() + '[番号項目1]a\n[番号項目1]b\n[番号項目2]c\n本文\n[番号項目1 再開5]e\n')); const w = Buffer.from(wu).toString('utf8'); const wd = part(wu, 'word/document.xml');
  ok(/<w:abstractNum w:abstractNumId="6">/.test(w) && /w:lvlText w:val="%1）"/.test(w) && /w:lvlText w:val="%2）"/.test(w), 'docx list abstract numbering', w.match(/abstractNumId="6">.{0,300}/));
  const ids = (wd.match(/<w:numPr><w:ilvl w:val="\d"\/><w:numId w:val="(\d+)"\/><\/w:numPr>/g) || []).map(x => x.match(/numId w:val="(\d+)"/)[1]); ok(ids.length === 4 && ids[0] === ids[1] && ids[1] === ids[2] && ids[3] !== ids[0], 'docx instances per list', ids);
  ok(new RegExp(`<w:num w:numId="${ids[3]}"><w:abstractNumId w:val="6"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="5"/>`).test(w), 'docx restart value', ids);
  // 操作
  const ed = mkEd(H() + '行\n'); ed.setList('num'); ok(ed.line().attrs.list.kind === 'num', 'setList num'); ed.childItem(); ok(ed.line().attrs.list.kind === 'num' && ed.line().attrs.list.level === 1, 'child of numbered is numbered');
  ed.setCaret({ line: 0, seg: 0, off: 1 }); ed.setList(); ok(!ed.doc.lines[0].attrs.list.kind, 'F6→5 turns numbered into bullet'); ed.setList('num'); ed.setList('num'); ok(!ed.doc.lines[0].attrs.list || ed.doc.lines[0].attrs.list.kind !== 'num', 'toggle numbered off');
  // 構造の単位：番号付き箇条書きは中身（節を割らない）
  const u = FZ.structUnits(FZ.parse(H() + '[番号1]章\n[番号項目1]a\n[番号項目1]b\n')); ok(u.join('') === '100', 'numbered items are content', u.join('')); }

// ---- 3 節の前の空きと区切り線 ----
{ const d = FZ.parse(H('戻り空き: 区切り線\n') + '[番号1]背景\n本文\n[番号2]市場\n本文2\n[番号2]競合\n本文3\n[番号1]方針\n本文4\n[番号3]一行の番号\n[番号3]もう一つ\n[番号1]次\n[区切り]\n[番号1]区切り線の後\n');
  const g = FZ.headingGaps(d); ok(JSON.stringify(g) === JSON.stringify([false, false, true, false, true, false, 'rule', false, false, false, 'rule', false, false]), 'gaps: return from body; rule before top-level sections; leaf numbered lines are content; none after hr', g);
  const lay = FZ.layout(d); const sec = lay.pages[0].hrules.filter(r => r.sec); const y6 = lay.lineMap[6].rows[0].y, y10 = lay.lineMap[10].rows[0].y;
  ok(sec.length === 2 && sec[0].y === y6 - 0.5 && sec[1].y === y10 - 0.5 && sec[0].from === 0 && sec[0].to === 40, 'rule in the middle of the gap row', [sec, y6, y10]);
  ok(FZ.serialize(d).includes('戻り空き: 区切り線') && FZ.parse(FZ.serialize(d)).format.returnGap === 'rule', 'fzk round trip');
  const w = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok((w.match(/<w:top w:val="single" w:sz="4" w:space="\d+"/g) || []).length === 2, 'docx top border for section rule', (w.match(/<w:top [^>]*>/g) || []).length);
  const pp = part(FZ.toPptx(d), 'ppt/slides/slide1.xml'); ok((pp.match(/<p:cxnSp>/g) || []).length >= 2, 'pptx section rule lines');
  // 戻り空き：見出しから下りるときは空けない、深い節から浅い節に戻るときは空ける
  const d2 = FZ.parse(H('戻り空き: あり\n') + '[番号1]A\n[番号2]B\n本文\n[番号1]C\n[番号2]D\n[番号1]E\n'); ok(JSON.stringify(FZ.headingGaps(d2)) === JSON.stringify([false, false, false, true, false, true]), 'descend no gap, return gap', FZ.headingGaps(d2));
  // 区切り（行の種類）は空きとして数える
  const d3 = FZ.parse(H('戻り空き: あり\n') + '[番号1]A\n本文\n[区切り]\n[番号1]B\n'); ok(JSON.stringify(FZ.headingGaps(d3)) === JSON.stringify([false, false, false, false]), 'hr row itself separates');
  // PowerPoint：段落の揃え（1.0.10a.2 で欠けていた）／Word：分割禁止・改頁（1.0.9f から欠けていた）
  const d4 = FZ.parse(H() + '[中央]中央の行\n[分割禁止]禁止\n[改頁]改頁\n'); const p4 = part(FZ.toPptx(d4), 'ppt/slides/slide1.xml'); ok(/algn="ctr"/.test(p4), 'pptx paragraph alignment');
  const w4 = Buffer.from(FZ.toDocx(d4)).toString('utf8'); ok(w4.includes('<w:keepLines/>') && w4.includes('<w:pageBreakBefore/>'), 'docx keepLines and pageBreakBefore'); }

// ---- 4 本文の位置：見出しの頭（既定）／見出しの文字／左端。書き出しの字下げにも載せる ----
{ const col = (m, i) => { const d = FZ.parse(H('本文位置: ' + m + '\n') + '[番号1]原則\n本文A\n[番号2]市場\n本文B\n[記号1]課題\n本文C\n[番号2 字下げ6]位置固定\n本文D\n'); const lay = FZ.layout(d); return [1, 3, 5, 7].map(k => lay.lineMap[k].segs[0].rows[0].glyphs[0].col).join(','); };
  ok(col('見出しの頭から1字') === '1,2,5,7' && col('見出しの頭') === '0,1,4,6' && col('見出しに揃える') === '2,4,5,9' && col('左端') === '0,0,0,0', 'body position modes', [col('見出しの頭から1字'), col('見出しの頭'), col('見出しに揃える'), col('左端')]);
  { const d0 = FZ.parse(H('本文位置: 見出しの頭から1字\n') + '前文\n[表題]題\n表題の後\n[番号1]章\n本文\n'); const l0 = FZ.layout(d0); ok([0, 2, 4].map(k => l0.lineMap[k].segs[0].rows[0].glyphs[0].col).join(',') === '0,0,1' && d0.format.bodyFollow === 'step' && FZ.serialize(d0).includes('本文位置: 見出しの頭から1字'), 'step: no indent before any heading or after a title', [0, 2, 4].map(k => l0.lineMap[k].segs[0].rows[0].glyphs[0].col)); }
  const d = FZ.parse(H('本文位置: 見出しの頭\n') + '[番号2]市場\n本文B\n'); ok(d.format.bodyFollow === 'mark' && FZ.serialize(d).includes('本文位置: 見出しの頭') && FZ.parse(H('本文位置: 見出しに揃える\n') + 'x\n').format.bodyFollow === true, 'fzk keys');
  const m = FZ.exportModel(d); ok(m.blocks[1].firstL === 1 && m.blocks[1].contL === 1, 'export model carries the body indent', [m.blocks[1].firstL, m.blocks[1].contL]);
  const w = part(FZ.toDocx(d), 'word/document.xml'); ok(/w:leftChars="100"/.test(w), 'docx body indent', (w.match(/<w:ind [^>]*>/g) || []));
  const pp = part(FZ.toPptx(d), 'ppt/slides/slide1.xml'); ok(new RegExp(`marL="${Math.round(FZ.layout(d).geo.cw * 12700)}"`).test(pp), 'pptx body indent'); }

console.log('110a3 fails=' + fails, 'errors:', errors);
process.exit(fails ? 1 : 0);
