/* 1.0.10b（画面）：表題の後空きの既定、ファイルのドラッグ＆ドロップ、exe 版の起動引数のファイル */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
  const open = async (init) => { const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
    if (init) await page.addInitScript(init); await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400); return page; };
  let page = await open(); await page.evaluate(() => localStorage.clear());
  // 1 表題の後空き：新規（白紙）・Markdown の取り込みで既定オン、三体系の画面で切り替え
  let r = await page.evaluate(async () => { const app = FZ.app; await app.loadText('# 報告書\n\n本文です。\n\n## 方針\n\n本文\n', 'a.md'); const ed = app.ed; return { ta: ed.doc.format.titleAfter, st: ed.doc.lines[0].attrs.style, y: [0, 1].map(i => ed.lay.lineMap[i].rows[0].y) }; });
  if (!r.ta || r.st !== 'title' || r.y[1] - r.y[0] !== 2) bad('md import: blank row after title', r);
  await page.keyboard.press('F2'); await page.keyboard.press('n'); await page.waitForTimeout(80); await page.keyboard.press('1'); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ ta: FZ.app.ed.doc.format.titleAfter, tg: FZ.app.ed.doc.format.tableGap, ser: FZ.serialize(FZ.app.ed.doc).includes('表題の後空き: あり') && FZ.serialize(FZ.app.ed.doc).includes('表の前空き: あり') }));
  if (!r.ta || !r.tg || !r.ser) bad('new blank doc has titleAfter and tableGap', r);
  r = await page.evaluate(() => { FZ.app.run('scheme'); const el = document.querySelector('#sub [data-name="taft"]') && document.querySelector('#sub [data-name="tgap2"]'); return { form: FZ.app.st.form, has: !!el }; });
  if (r.form !== 'scheme' || !r.has) bad('scheme form has 表題の後空き', r);
  await page.keyboard.press('Escape');
  // 古い既定（_v:2、titleAfter なし）でも既定オン
  r = await page.evaluate(async () => { localStorage.setItem('fz.defaults', JSON.stringify({ cols: 40, _v: 2 })); await FZ.app.loadText('# 題\n\n本文\n', 'b.md'); return FZ.app.ed.doc.format.titleAfter; });
  if (r !== true) bad('old saved defaults still get titleAfter', r);
  await page.evaluate(() => localStorage.clear());
  // 2 ドロップ：原本を開く
  const drop = (files, at) => page.evaluate(({ files, at }) => { const dt = new DataTransfer(); for (const f of files) dt.items.add(new File([f.b64 ? Uint8Array.from(atob(f.b64), c => c.charCodeAt(0)) : f.text], f.name, { type: f.type || '' }));
    const tg = at ? document.elementFromPoint(at.x, at.y) : document.body; const o = { dataTransfer: dt, bubbles: true, cancelable: true, clientX: at ? at.x : 10, clientY: at ? at.y : 10 };
    const ov = new DragEvent('dragover', o); tg.dispatchEvent(ov); const hint = document.getElementById('dropHint'); const shown = !!hint && hint.classList.contains('on'); const ev = new DragEvent('drop', o); tg.dispatchEvent(ev); return { prevented: ov.defaultPrevented && ev.defaultPrevented, shown }; }, { files, at });
  r = await drop([{ name: '議事録.fzk', text: '#fzk 2\n---\n[表題]議事録\n一行目\n' }]); await page.waitForTimeout(200);
  let s = await page.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs[0].text, file: FZ.app.st.file && FZ.app.st.file.name, hint: document.getElementById('dropHint').classList.contains('on') }));
  if (!r.prevented || !r.shown || s.t !== '議事録' || s.hint) bad('drop .fzk opens it', { r, s });
  // 未保存なら確かめる
  await page.keyboard.press('End'); await page.keyboard.type('追記'); await drop([{ name: 'x.md', text: '# 別\n' }]); await page.waitForTimeout(200);
  s = await page.evaluate(() => ({ form: FZ.app.st.form, t: FZ.app.ed.doc.lines[0].segs[0].text })); if (s.form !== 'ask' || s.t !== '議事録追記') bad('drop asks before discarding', s);
  await page.keyboard.press('Escape'); await page.waitForTimeout(80);
  // 画像：放した行に図表
  const png = fs.readFileSync(path.join(__dirname, 'sample-img', 'chart.png')).toString('base64');
  await page.evaluate(() => { FZ.app.ed.dirty = false; }); await page.evaluate(async () => FZ.app.loadText('#fzk 2\n---\n一行目\n二行目\n三行目\n', 'c.fzk'));
  const pt = await page.evaluate(() => { const ed = FZ.app.ed; const svg = document.querySelector('.pgwrap svg'); const rc = svg.getBoundingClientRect(); const geo = ed.lay.geo; const sc = rc.width / geo.W; return { x: rc.left + (geo.left + geo.cw * 2) * sc, y: rc.top + (geo.top + geo.ch * (geo.bodyTop + 2.5)) * sc }; });
  r = await drop([{ name: 'chart.png', type: 'image/png', b64: png }], pt); await page.waitForTimeout(300);
  s = await page.evaluate(() => ({ form: FZ.app.st.form, figs: (FZ.app.ed.doc.lines[2].attrs.figs || []).length, imgs: Object.keys(FZ.app.ed.doc.images || {}).length }));
  if (s.form !== 'fig' || s.figs !== 1 || s.imgs !== 1) bad('drop image onto line 3', s);
  await page.keyboard.press('Escape');
  // 開けない種類
  await drop([{ name: '資料.doc', text: 'x' }]); await page.waitForTimeout(100); s = await page.evaluate(() => FZ.app.st.msg);
  if (!/Markdown/.test(s)) bad('doc drop message', s.slice(0, 200));
  await drop([{ name: '資料.docx', text: 'x' }]); await page.waitForTimeout(300); s = await page.evaluate(() => FZ.app.st.msg);
  if (!/Word を取り込めませんでした/.test(s)) bad('broken docx drop message', s.slice(0, 200));
  await page.close();
  // 3 exe 版：起動引数のファイル
  page = await open(() => { window.fzInitialFile = () => Promise.resolve({ name: '引数.fzk', path: 'C:\\\\docs\\\\引数.fzk', text: '#fzk 2\n---\n[表題]引数のファイル\n' }); });
  await page.waitForTimeout(300); s = await page.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs[0].text, p: FZ.app.st.file && FZ.app.st.file.path }));
  if (s.t !== '引数のファイル' || !/引数\.fzk$/.test(s.p || '')) bad('initial file opens', s);
  await page.close();
  // 復元があるときは空いている番号へ退避してから開く
  page = await open(() => { if (!sessionStorage.getItem('t')) { sessionStorage.setItem('t', '1'); localStorage.clear(); localStorage.setItem('fz.recover.1', JSON.stringify({ text: '#fzk 2\n---\n未保存の文書\n', name: '', time: Date.now() })); } window.fzInitialFile = () => Promise.resolve({ name: 'b.fzk', path: 'C:\\\\b.fzk', text: '#fzk 2\n---\n開いた文書\n' }); });
  await page.waitForTimeout(400); s = await page.evaluate(() => { const parked = []; for (let n = 1; n <= 8; n++) { const v = localStorage.getItem('fz.recover.' + n); if (v && v.includes('未保存の文書')) parked.push(n); } return { t: FZ.app.ed.doc.lines[0].segs[0].text, slot: FZ.app.st.slot, parked }; });
  if (s.t !== '開いた文書' || !s.parked.length || s.parked.includes(s.slot)) bad('recovery parked before opening initial file', s);
  // 3b Markdown を開いたら柱上にファイル名（既定の書式で柱上を決めていればそちら。.fzk は原本どおり）
  s = await page.evaluate(async () => { const app = FZ.app; localStorage.removeItem('fz.defaults'); FZ.app.ed.dirty = false; await app.loadText('# 報告\n\n本文\n', '月次報告.md'); const hf = app.ed.lay.pages[0].hf.map(h => h.text || (h.glyphs || []).map(g => g.text).join('')).join('|');
    const a = { header: app.ed.doc.format.header, hfHas: JSON.stringify(app.ed.lay.pages[0].hf).includes('月') };
    localStorage.setItem('fz.defaults', JSON.stringify({ ...FZ.newDoc().format, header: '社内用', _v: 2 })); app.ed.dirty = false; await app.loadText('# x\n', 'b.md'); a.custom = app.ed.doc.format.header;
    app.ed.dirty = false; await app.loadText('#fzk 2\n---\n本文\n', 'c.fzk'); a.fzk = app.ed.doc.format.header; localStorage.removeItem('fz.defaults'); return a; });
  if (s.header !== '{file}' || !s.hfHas || s.custom !== '社内用' || s.fzk !== '') bad('md file name in header', s);
  // {file} は保存し直すとその名前に（保存の口を差し替えて確かめる）
  s = await page.evaluate(async () => { const app = FZ.app; app.ed.dirty = false; await app.loadText('# 報告\n\n本文\n', '月次報告.md'); const hf = () => app.ed.lay.pages[0].hf.map(g => g.text || '').join('');
    const before = hf().includes('月次報告.md'); const orig = FZ.files.save; FZ.files.save = async () => ({ name: '月次報告_確定.fzk', handle: {} }); app.run('save'); await new Promise(r => setTimeout(r, 150)); FZ.files.save = orig;
    const ser = FZ.serialize(app.ed.doc); return { before, after: hf().includes('月次報告_確定.fzk'), ser: ser.includes('柱上: {file}') && !ser.includes('月次報告_確定') }; });
  if (!s.before || !s.after || !s.ser) bad('{file} follows the saved name', s);
  await page.close();
  // 4 閉じる前の確認（exe 版の［×］：ホストが fzRequestClose を呼ぶ）
  page = await open(() => { window.__closed = 0; window.__acked = 0; window.fzCloseNow = () => { window.__closed++; }; window.fzCloseAck = () => { window.__acked++; }; });
  s = await page.evaluate(() => { window.fzRequestClose(); return { closed: window.__closed, acked: window.__acked, form: FZ.app.st.form }; });
  if (s.closed !== 1 || s.acked !== 1 || s.form) bad('clean document closes at once', s);
  await page.keyboard.type('変更'); await page.waitForTimeout(50);
  s = await page.evaluate(() => { window.fzRequestClose(); return { closed: window.__closed, form: FZ.app.st.form, text: document.getElementById('sub').textContent }; });
  if (s.closed !== 1 || s.form !== 'ask' || !/保存して閉じる/.test(s.text) || !/保存せずに閉じる/.test(s.text)) bad('dirty document asks before closing', s);
  await page.keyboard.press('Escape'); await page.waitForTimeout(50); s = await page.evaluate(() => ({ closed: window.__closed, dirty: FZ.app.ed.dirty }));
  if (s.closed !== 1 || !s.dirty) bad('cancel keeps the window', s);
  await page.evaluate(() => window.fzRequestClose()); await page.waitForTimeout(30); await page.keyboard.press('d'); await page.waitForTimeout(80);
  s = await page.evaluate(() => { let rec = 0; for (let n = 1; n <= 8; n++) if (localStorage.getItem('fz.recover.' + n)) rec++; return { closed: window.__closed, dirty: FZ.app.ed.dirty, rec }; });
  if (s.closed !== 2 || s.dirty || s.rec) bad('discard closes and leaves no recovery data', s);
  await page.close();
  // ブラウザ版：未保存なら beforeunload で標準の確認
  page = await open(); await page.keyboard.type('x'); await page.waitForTimeout(50);
  s = await page.evaluate(() => { const e = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(e); return e.defaultPrevented; }); if (!s) bad('beforeunload prevents when dirty');
  await browser.close();
  console.log('110a7-app fails=' + fails, 'errors:', errors); process.exit(fails ? 1 : 0);
})();
