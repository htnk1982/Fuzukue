/* 1.0.10b：表題の後の空き（既定）、表の行の高さ（四倍角を戻す）、ページをまたぐ表の見出し行の繰り返し */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-render']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info).slice(0, 500) : '')); } };
const H = (extra = '') => '#fzk 2\n文字数: 40\n行数: 30\n' + extra + '---\n';
const Y = (lay, i) => lay.lineMap[i].rows[0].y;

// ---- 1 表題の後空き ----
{ const d = FZ.parse(H('表題の後空き: あり\n') + '[表題]題\n本文\n[番号1]章\n本文\n\n[表題]二つ目\n[表題]副題\n本文\n[表題]空行あり\n\n本文\n[表題]見出しが続く\n[番号1]章\n');
  ok(JSON.stringify(FZ.headingGaps(d)) === JSON.stringify([false, true, false, false, false, false, false, true, false, false, false, false, true]), 'gaps after title (not between titles, not doubled)', FZ.headingGaps(d));
  const s = FZ.serialize(d); ok(s.includes('表題の後空き: あり') && FZ.serialize(FZ.parse(s)) === s, 'serialize round trip');
  ok(!FZ.serialize(FZ.parse(H() + 'x\n')).includes('表題の後空き'), 'off by default in .fzk (not written)');
  const lay = FZ.layout(d); ok(Y(lay, 0) === 0 && Y(lay, 1) === 2 && Y(lay, 2) === 3, 'layout: one blank row after title', [0, 1, 2].map(i => Y(lay, i)));
  const m = FZ.exportModel(d); ok(m.blocks[1].gap === true, 'export model gap');
  const w = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok(/<w:spacing w:before="\d+"\/>/.test(w), 'docx space before');
  // 資料：表題は柱に上がるので、本文の頭は空けない
  const sl = FZ.parse('#fzk 2\n書式: 資料\n表題の後空き: あり\n---\n[表題]題\n本文\n'); const ls = FZ.layout(sl); ok(Y(ls, 0) < 0 && Y(ls, 1) === 0, 'slide: lifted title, body starts at top', [Y(ls, 0), Y(ls, 1)]);
  // ページの末尾の表題：次と同頁で送られ、送った先で空ける
  const p = FZ.parse(H('表題の後空き: あり\n') + '\n'.repeat(29) + '[表題]末尾の題\n本文\n'); const lp = FZ.layout(p); const r0 = lp.lineMap[29].rows[0], r1 = lp.lineMap[30].rows[0];
  ok(r0.page === 1 && r0.y === 0 && r1.page === 1 && r1.y === 2, 'title at page end moves with its body', [r0.page, r0.y, r1.page, r1.y]);
  // 戻り空きと重ねない
  const g = FZ.parse(H('表題の後空き: あり\n戻り空き: あり\n') + '本文\n[表題]題\n[番号1]章\n本文\n[番号1]次\n'); ok(JSON.stringify(FZ.headingGaps(g)) === JSON.stringify([false, true, true, false, true]), 'with return gap', FZ.headingGaps(g)); }

// ---- 2 表の行の高さ：一部のセルを四倍角にして戻すと高さが戻る（別のセルが四倍角の高さを引きずらない） ----
{ const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(H() + '前\n')); ed.setCaret({ line: 0, seg: 0, off: 1 }); ed.insertTable(3, 3, [10, 10, 20], true);
  ed.setCaret({ line: 2, seg: 0, off: 0 }); ed.insertText('値あいうえ'); ed.setCaret({ line: 2, seg: 1, off: 0 }); ed.insertText('次');
  const hOf = () => ed.lay.lineMap[2].rows[0].h; const M = FZ.M; const sel = (o) => { ed.setCaret({ line: 2, seg: 0, off: 0 }); ed.setCaret({ line: 2, seg: 0, off: o }, true); };
  sel(2); ed.mutate('', () => ed.forEachMark(ed.sel(), m => m | M.WIDE | M.TALL)); ok(hOf() === 2, 'quad part → row height 2', hOf());
  sel(5); ed.mutate('', () => ed.forEachMark(ed.sel(), m => m & ~(M.WIDE | M.TALL))); ok(hOf() === 1, 'quad off → row height back to 1', hOf());
  ok(JSON.stringify(ed.lay.lineMap[2].rows.map(r => r.h)) === JSON.stringify(FZ.layout(ed.doc).lineMap[2].rows.map(r => r.h)), 'same as full layout'); }

// ---- 3 ページをまたぐ表：見出し行の繰り返し（既定）・前のページの下を閉じる・切替 ----
{ let rows = ''; for (let k = 0; k < 40; k++) rows += '| 行' + k + ' | ' + (k * 10) + ' | 備考 |\n';
  const src = H() + '前置き\n' + '\n'.repeat(10) + '#表 列 0,10,20,40 様式 統計表\n| 項目 | 数値 | 備考 |\n' + rows + '後\n';
  const d = FZ.parse(src); const lay = FZ.layout(d); const tl = d.lines.findIndex(l => l.attrs.cells); const p1 = lay.pages[1];
  const fr = lay.lineMap.findIndex((l, q) => q > tl && l.rows[0].page === 1);
  ok(p1.repeats.length === 1 && p1.repeats[0].next === fr && lay.lineMap[fr].rows[0].y === 1, 'header copied to the top of page 2', p1.repeats);
  ok(p1.glyphs.filter(g => g.rep).map(g => g.text).join('') === '項目数値備考', 'copied header text');
  ok(p1.hrules.some(r => r.rep && r.y === 0 && r.kind === 'thick') && p1.hrules.some(r => r.rep && r.y === 1), 'header rules copied (top thick, bottom)', p1.hrules.filter(r => r.y <= 1));
  const p0 = lay.pages[0]; const lastY = lay.lineMap[fr - 1].rows[0].y + 1;
  ok(p0.hrules.some(r => r.closing && r.y === lastY && r.kind === 'thick'), 'table closed at the bottom of page 1 with the outer rule', p0.hrules.filter(r => r.closing));
  ok(p0.vrules.every(r => r.y2 <= lastY), 'vertical rules end at the last row on page 1', [...new Set(p0.vrules.map(r => r.y2))]);
  ok(!lay.pages[0].repeats.length, 'no repeat on the first page');
  // 見出し行は 1 行目の表の行と同じページに（見出しだけがページ末に残らない）
  const d2 = FZ.parse(H() + '\n'.repeat(29) + '#表 列 0,10,20,40 様式 格子\n| 項目 | 数値 | 備考 |\n| a | 1 | x |\n'); const l2 = FZ.layout(d2); const t2 = d2.lines.findIndex(l => l.attrs.cells);
  ok(l2.lineMap[t2].rows[0].page === l2.lineMap[t2 + 1].rows[0].page, 'header row keeps with the first row', [l2.lineMap[t2].rows[0], l2.lineMap[t2 + 1].rows[0]]);
  // 切替：繰り返さない表（原本 [見出し繰り返しなし]）
  d.lines[tl].attrs.noRepeat = true; const s2 = FZ.serialize(d); ok(s2.includes('[見出し繰り返しなし]| 項目') && FZ.serialize(FZ.parse(s2)) === s2, 'noRepeat round trip');
  const l3 = FZ.layout(d); ok(l3.pages.every(pg => !pg.repeats.length) && l3.lineMap[fr].rows[0].y === 0, 'no repeat when switched off');
  // 書き出し：Word のタイトル行、PowerPoint の続きのスライドに見出し行
  const d4 = FZ.parse(src); const w = Buffer.from(FZ.toDocx(d4)).toString('utf8'); ok((w.match(/<w:tblHeader\/>/g) || []).length === 1, 'docx tblHeader');
  const z = Buffer.from(FZ.toPptx(d4)).toString('latin1'); const k2 = z.indexOf('ppt/slides/slide2.xml<?xml'); ok(k2 > 0 && Buffer.from(z.slice(k2, z.indexOf('PK\u0003\u0004', k2)), 'latin1').toString('utf8').includes('項目'), 'pptx slide 2 table starts with the header row');
  // 増分の組版：見出しを直すと、写しも直る
  const ed = new FZ.Editor(); ed.onChange = () => { }; ed.onCaret = () => { }; ed.setDoc(FZ.parse(src)); ed.setCaret({ line: tl, seg: 0, off: 0 }); ed.insertText('新');
  ok(ed.lay.pages[1].glyphs.filter(g => g.rep).map(g => g.text).join('') === '新項目数値備考', 'incremental: copy follows header edit', ed.lay.pages[1].glyphs.filter(g => g.rep).map(g => g.text).join(''));
  ed.setCaret({ line: tl + 3, seg: 0, off: 0 }); ed.enter(); ok(ed.lay.pages[1].repeats.length === 1 && ed.lay.pages[1].glyphs.filter(g => g.rep).length === 7, 'incremental: rows inserted above keep the copy', ed.lay.pages[1].repeats); }

// ---- 4 表の前空き：表のすぐ前が中身なら 1 行（空行の後・続く表・ページの頭は空けない） ----
{ const src = H('表の前空き: あり\n') + '前の行\n#表 列 0,20,40 様式 格子\n| a | b |\n| c | d |\n\n#表 列 0,20,40 様式 格子\n| e | f |\n[番号1]見出し\n#表 列 0,20,40 様式 格子\n| g | h |\n';
  const d = FZ.parse(src); ok(JSON.stringify(FZ.headingGaps(d)) === JSON.stringify([false, true, false, false, false, false, true]), 'table gaps', FZ.headingGaps(d));
  const lay = FZ.layout(d); ok(d.lines.map((l, i) => lay.lineMap[i].rows[0].y).join(',') === '0,2,3,4,5,6,8', 'table gap rows', d.lines.map((l, i) => lay.lineMap[i].rows[0].y).join(','));
  const s = FZ.serialize(d); ok(s.includes('表の前空き: あり') && FZ.serialize(FZ.parse(s)) === s && !FZ.serialize(FZ.parse(H() + 'x\n')).includes('表の前空き'), 'tableGap round trip, off when absent');
  const w = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok((w.match(/w:lineRule="exact"\/><\/w:pPr><\/w:p><w:tbl>/g) || []).length === 2, 'docx empty paragraph before tables');
  const d0 = FZ.parse(H() + '#表 列 0,20,40 様式 格子\n| a | b |\n'); d0.format.tableGap = true; ok(!FZ.headingGaps(d0)[0], 'no gap at document top'); }

// ---- 5 PowerPoint の頁番号：スライド番号のプレースホルダー（自動採番。足す・消す・並べ替えで振り直る） ----
{ const part2 = (u8, name) => { const z = Buffer.from(u8).toString('latin1'); const k = z.indexOf(name + '<?xml'); if (k < 0) return ''; return Buffer.from(z.slice(k + name.length, z.indexOf('PK\u0003\u0004', k)), 'latin1').toString('utf8'); };
  const sl = FZ.parse('#fzk 2\n書式: 資料\n頁番号: 丸\n---\n[表題]一枚目\n本文\n[表題]二枚目\n本文\n'); const u = FZ.toPptx(sl);
  const m = part2(u, 'ppt/slideMasters/slideMaster1.xml'), l = part2(u, 'ppt/slideLayouts/slideLayout1.xml'), s2 = part2(u, 'ppt/slides/slide2.xml');
  ok(/<p:ph type="sldNum" sz="quarter" idx="4"\/>/.test(m) && /<p:ph type="sldNum" sz="quarter" idx="12"\/>/.test(l) && /type="slidenum">[^]*?<a:t>‹#›<\/a:t>/.test(l), 'master and layout have the slide number placeholder');
  ok(/<p:hf hdr="0" ftr="0" dt="0"\/>/.test(m) && /<p:hf hdr="0" ftr="0" dt="0"\/>/.test(l), 'header/footer settings: slide number on');
  ok(/<p:ph type="sldNum" sz="quarter" idx="12"\/>/.test(s2) && /type="slidenum">[^]*?<a:t>2<\/a:t><\/a:fld>/.test(s2) && /prst="ellipse"/.test(s2) && !/name="頁番号"/.test(s2), 'slide 2: number in the placeholder (circle), no plain text box');
  const d = FZ.parse('#fzk 2\n---\n' + Array.from({ length: 80 }, (_, k) => '行' + k).join('\n') + '\n'); const u2 = FZ.toPptx(d); const t2 = part2(u2, 'ppt/slides/slide2.xml');
  ok(/<p:ph type="sldNum"/.test(t2) && /type="slidenum">[^]*?<a:t>2<\/a:t><\/a:fld>/.test(t2) && !/<a:t> \/ <\/a:t>/.test(t2) && !/name="柱下"/.test(t2), 'document footer {page} / {pages} → slide number placeholder', t2.match(/<p:sp>(?:(?!<\/p:sp>).)*sldNum(?:(?!<\/p:sp>).)*<\/p:sp>/g));
  const d3 = FZ.parse('#fzk 2\n柱下: 社外秘\n---\n本文\n'); const m3 = part2(FZ.toPptx(d3), 'ppt/slideMasters/slideMaster1.xml'); ok(!/type="sldNum"/.test(m3) && /sldNum="0"/.test(m3), 'no page number → no placeholder, slide number off'); }

// ---- 6 Word の画像・PowerPoint の総数・柱の {file} ----
{ const part2 = (u8, name) => { const z = Buffer.from(u8).toString('latin1'); const k = z.indexOf(name + '<?xml'); if (k < 0) return ''; return Buffer.from(z.slice(k + name.length, z.indexOf('PK\u0003\u0004', k)), 'latin1').toString('utf8'); };
  const fs = require('fs'), path = require('path'); const b64 = n => fs.readFileSync(path.join(__dirname, 'sample-img', n)).toString('base64');
  const src = H() + '前の文\n#図版 a 図 売上の推移 chart.png 75%\n後の文\n#図版 b 図 写真 photo.jpg\n#図版 c 図 線画 line.svg\n終わり\n===\n#添付 chart.png image/png\n' + b64('chart.png') + '\n#添付 photo.jpg image/jpeg\n' + b64('photo.jpg') + '\n#添付 line.svg image/svg+xml\n' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"/>').toString('base64') + '\n';
  const d = FZ.parse(src); ok(Object.keys(d.images).length === 3 && d.lines.filter(l => l.attrs.figs).length >= 2, 'figures parsed', [Object.keys(d.images), d.lines.map(l => l.attrs.figs && l.attrs.figs.map(f => f.id))]);
  const u = FZ.toDocx(d); const z = Buffer.from(u).toString('latin1'); const w = part2(u, 'word/document.xml'), rels = part2(u, 'word/_rels/document.xml.rels'), ct = part2(u, '[Content_Types].xml');
  ok(z.includes('word/media/image1.png') && z.includes('word/media/image2.jpeg'), 'docx media parts');
  ok((w.match(/<pic:pic /g) || []).length === 2 && /r:embed="rIdImg1"/.test(w) && /Target="media\/image1.png"/.test(rels) && /Extension="png" ContentType="image\/png"/.test(ct) && /Extension="jpeg" ContentType="image\/jpeg"/.test(ct), 'docx inline pictures with relationships and content types');
  const cx = +(w.match(/<wp:extent cx="(\d+)"/) || [])[1]; const full = 40 * FZ.layout(d).geo.cw * 12700; ok(Math.abs(cx - full * 0.75) < full * 0.02, 'picture width follows the figure width (75%)', [cx, full]);
  ok(w.includes('図 1　売上の推移') && /［画像：line.svg（この形式は Word に書き出せません/.test(w), 'caption kept; unsupported format noted');
  // PowerPoint：{pages} を省いて番号だけ
  const dp = FZ.parse('#fzk 2\n柱上: {file} {pages}頁\n---\n' + Array.from({ length: 70 }, (_, k) => '行' + k).join('\n') + '\n'); Object.defineProperty(dp, 'fileName', { value: '報告.fzk', enumerable: false });
  const s2 = part2(FZ.toPptx(dp), 'ppt/slides/slide2.xml'); const ph = (s2.match(/<p:sp>(?:(?!<\/p:sp>).)*sldNum(?:(?!<\/p:sp>).)*<\/p:sp>/) || [''])[0];
  ok(/<a:t>2<\/a:t><\/a:fld>/.test(ph) && !/ \/ /.test(ph) && !/<a:t>2<\/a:t>(?:(?!<\/a:p>).)*<a:t>\d/.test(ph), 'pptx footer: slide number only (no total)', ph.replace(/<a:rPr.*?<\/a:rPr>/g, ''));
  ok(s2.includes('<a:t>報告.fzk </a:t>') || s2.includes('報告.fzk'), 'pptx header {file}');
  // 組版の柱：{file}
  const lay = FZ.layout(dp); ok(lay.pages[0].hf.map(g => g.text).join('').startsWith('報告.fzk'), 'layout header {file}', lay.pages[0].hf.map(g => g.text).join(''));
  const wd = part2(FZ.toDocx(dp), 'word/header1.xml'); ok(wd.includes('報告.fzk') && !wd.includes('{file}'), 'docx header {file}'); }

console.log('110a7 fails=' + fails, 'errors:', errors);
process.exit(fails ? 1 : 0);
