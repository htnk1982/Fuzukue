/* 1.0.10b.5：クリップボードの振り分け（Excel・スプレッドシートのセル → 表、図・画像 → 図表、Word の文章 → 文字） */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  const png = fs.readFileSync(path.join(__dirname, 'sample-img', 'chart.png')).toString('base64');
  const XL = body => `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta name=Generator content="Microsoft Excel 15"></head><body>${body}</body></html>`;
  const PP = body => `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:p="urn:schemas-microsoft-com:office:powerpoint"><head><meta name=Generator content="Microsoft PowerPoint 15"></head><body>${body}</body></html>`;
  const WD = body => `<html xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta name=Generator content="Microsoft Word 15"></head><body>${body}</body></html>`;
  const paste = (o) => page.evaluate(({ o, png }) => { const ed = FZ.app.ed; FZ.app.st.form = null; ed.setDoc(FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n---\n前\n')); ed.setCaret({ line: 0, seg: 0, off: 1 }); FZ.app.render(); FZ.app.st.lastPasteShift = !!o.shift;
    const dt = new DataTransfer(); if (o.text != null) dt.setData('text/plain', o.text); if (o.html) dt.setData('text/html', o.html); if (o.img) { const bin = atob(png); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); dt.items.add(new File([u], 'image.png', { type: 'image/png' })); }
    document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); return 1; }, { o, png });
  const waitFigs = n => page.waitForFunction(n => FZ.app.ed.doc.lines.reduce((t, l) => t + (l.attrs.figs ? l.attrs.figs.length : 0), 0) >= n, n, { timeout: 3000 }).catch(() => { });
  const state = () => page.evaluate(() => { const d = FZ.app.ed.doc; return { cells: d.lines.filter(l => l.attrs.cells).map(l => l.segs.map(s => s.text).join('|')), align: d.lines.filter(l => l.attrs.cells).map(l => (l.attrs.cellAlign || []).join(',')), figs: d.lines.reduce((t, l) => t + (l.attrs.figs ? l.attrs.figs.length : 0), 0), text: d.lines.map(l => l.segs.map(s => s.text).join('')).join('/'), form: FZ.app.st.form, msg: FZ.app.st.msg || '' }; });
  // 1 Excel のセル（画面の絵付き）→ 表。数値の列は右揃え
  await paste({ text: '支店\t売上\r\n東京\t1,200\r\n大阪\t980\r\n', html: XL('<table><tr><td>支店</td><td>売上</td></tr><tr><td>東京</td><td>1,200</td></tr></table>'), img: true }); await page.waitForTimeout(150);
  let r = await state(); if (r.cells.length !== 3 || r.cells[1] !== '東京|1,200' || r.figs !== 0 || !/right/.test(r.align[1])) bad('excel range → table', r);
  // 2 セルの中の改行（引用符）
  await paste({ text: '項目\t説明\r\nA\t"一行目\n二行目"\r\n', html: XL('<table><tr><td>x</td></tr></table>') }); await page.waitForTimeout(150);
  r = await state(); if (r.cells.length !== 2 || r.cells[1] !== 'A|一行目 二行目') bad('quoted cell with newline', r);
  // 3 Excel の 1 列 → 表、セル 1 つ → 文字（改行を付けない）
  await paste({ text: '東京\r\n大阪\r\n名古屋\r\n', html: XL('<table><tr><td>東京</td></tr></table>') }); await page.waitForTimeout(150); r = await state(); if (r.cells.length !== 3) bad('excel single column → table', r);
  await paste({ text: '1,200\r\n', html: XL('<table><tr><td>1,200</td></tr></table>') }); await page.waitForTimeout(100); r = await state(); if (r.cells.length || r.text !== '前1,200') bad('excel single cell → text', r);
  // 4 Ctrl+Shift+V：文字のまま
  await paste({ text: 'a\tb\r\nc\td\r\n', html: XL('<table><tr><td>a</td></tr></table>'), shift: true }); await page.waitForTimeout(100); r = await state(); if (r.cells.length) bad('shift paste keeps text', r);
  // 5 Excel のグラフ（表の無い HTML＋画像）→ 図
  await paste({ text: '', html: XL('<img src="file:///clip_image001.png">'), img: true }); await waitFigs(1); await page.waitForTimeout(50); r = await state(); if (r.figs !== 1 || r.form !== 'fig') bad('excel chart → figure', r);
  // 6 PowerPoint の図形（中の文字付き）→ 図
  await paste({ text: '工程A\r\n工程B', html: PP('<p>工程A</p>'), img: true }); await waitFigs(1); await page.waitForTimeout(50); r = await state(); if (r.figs !== 1 || /工程/.test(r.text)) bad('powerpoint shapes → figure', r);
  // 7 Word の文章（絵付き）→ 文字
  await paste({ text: '本文の文章です。', html: WD('<p>本文の文章です。</p>'), img: true }); await page.waitForTimeout(150); r = await state(); if (r.figs !== 0 || r.text !== '前本文の文章です。') bad('word text stays text', r);
  // 8 画面の切り取り・ブラウザの画像（文字なし）→ 図
  await paste({ img: true }); await waitFigs(1); await page.waitForTimeout(50); r = await state(); if (r.figs !== 1) bad('image only → figure', r);
  // 9 Google スプレッドシート → 表
  await paste({ text: 'a\tb\nc\td', html: '<google-sheets-html-origin><table><tr><td>a</td></tr></table>' }); await page.waitForTimeout(150); r = await state(); if (r.cells.length !== 2) bad('sheets → table', r);
  // 10 ブラウザの文章の TSV（出どころ不明）は従来どおり 2 行以上のタブ区切りで表
  await paste({ text: 'x\ty\n1\t2\n' }); await page.waitForTimeout(150); r = await state(); if (r.cells.length !== 2) bad('plain TSV → table (as before)', r);
  // 11 Excel の書式：太字・下線・取消線・揃え・背景（白黒の 3 段）。結合セル。既定の見出しの網の代わりに Excel の網
  const XLS = `<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta name=Generator content="Microsoft Excel 15"><style>
.xl65
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	background:#D9E1F2;
	mso-pattern:black none;}
.xl66
	{mso-style-parent:style0;
	mso-number-format:"\#\,\#\#0";}
.xl67
	{mso-style-parent:style0;
	color:white;
	font-weight:700;
	background:#4472C4;}
.xl68
	{text-decoration:underline;
	text-underline-style:single;}
</style></head><body><table><tr><td class=xl65>支店</td><td class=xl65>売上</td><td class=xl65>備考</td></tr>
<tr><td class=xl68>東京</td><td class=xl66 align=right>1,200</td><td style='text-decoration:line-through'>旧</td></tr>
<tr><td class=xl67 colspan=2>合計</td><td align=center>済</td></tr></table></body></html>`;
  await paste({ text: '支店\t売上\t備考\r\n東京\t1,200\t旧\r\n合計\t\t済\r\n', html: XLS, img: true }); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const M = FZ.M; const L = d.lines.map((l, i) => [l, i]).filter(([l]) => l.attrs.cells);
    const mk = (li, k) => { const sg = L[li][0].segs.slice().sort((a, b) => a.col - b.col)[k]; return sg ? (sg.marks[0] | 0) : -1; };
    return { n: L.length, b0: !!(mk(0, 0) & M.BOLD), u10: !!(mk(1, 0) & M.UNDER), s12: !!(mk(1, 2) & M.STRIKE), b20: !!(mk(2, 0) & M.BOLD), al0: L[0][0].attrs.cellAlign, al1: L[1][0].attrs.cellAlign, al2: L[2][0].attrs.cellAlign,
      fills: d.fills.map(x => ({ from: x.from - L[0][1], shade: x.shade, col: x.col, cols: x.cols })), text2: L[2][0].segs.map(s => s.text).join('|'), msg: FZ.app.st.lastPaste && FZ.app.st.lastPaste.kind }; });
  if (r.n !== 3 || !r.b0 || !r.u10 || !r.s12 || !r.b20 || JSON.stringify(r.al0) !== '["center","center","center"]' || !r.al1 || r.al1[1] !== 'right' || !r.al2 || r.al2[2] !== 'center') bad('excel formats → bold/underline/strike/align', r);
  if (!(r.fills.some(x => x.from === 0 && x.shade === 'light' && x.col === 0) && r.fills.some(x => x.from === 2 && x.shade === 'dark') && r.fills.length === 2) || r.text2 !== '合計||済') bad('excel fills → grayscale, merged cells', r);
  // 12 Ctrl+Alt+V：直前の表を見た目のまま図に。Ctrl+Z で表に戻る
  await page.focus('#ta'); await page.keyboard.press('Control+Alt+v'); await page.waitForTimeout(300); r = await state();
  if (r.cells.length !== 0 || r.figs !== 1 || r.form !== 'fig') bad('Ctrl+Alt+V → picture', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(50); await page.focus('#ta'); for (let k = 0; k < 4 && (await state()).cells.length === 0; k++) { await page.keyboard.press('Control+z'); await page.waitForTimeout(60); }
  r = await state(); if (r.cells.length !== 3 || r.figs !== 0) bad('undo back to table', r);
  // 13 図の無いコピー（スプレッドシート）では図にできない旨
  await paste({ text: 'a\tb\nc\td', html: '<google-sheets-html-origin><table><tr><td>a</td><td>b</td></tr><tr><td>c</td><td>d</td></tr></table>' }); await page.waitForTimeout(150);
  await page.focus('#ta'); await page.keyboard.press('Control+Alt+v'); await page.waitForTimeout(150); r = await state(); if (r.cells.length !== 2 || !/図にできません/.test(r.msg)) bad('no picture available', r);
  // 14 Word・PowerPoint の書き出し：SVG・WebP を PNG にして図で入れる
  r = await page.evaluate(async () => {
    const cv = document.createElement('canvas'); cv.width = 40; cv.height = 20; const c = cv.getContext('2d'); c.fillStyle = '#336'; c.fillRect(0, 0, 40, 20); const webp = cv.toDataURL('image/webp').replace(/^data:[^,]*,/, '');
    const svg = btoa('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100"><rect x="10" y="10" width="180" height="80" fill="none" stroke="black" stroke-width="4"/></svg>');
    const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n---\n前\n#図版 a 図 線画 line.svg\n中\n#図版 b 図 写真 pic.webp\n後\n===\n#添付 line.svg image/svg+xml\n' + svg + '\n#添付 pic.webp image/webp\n' + webp + '\n');
    const o = await FZ.app.officeDoc(d); const sz = FZ.imageSize(o.images['line.svg']);
    const dx = new TextDecoder('latin1').decode(FZ.toDocx(o)); const px = new TextDecoder('latin1').decode(FZ.toPptx(o));
    return { mimes: Object.values(o.images).map(x => x.mime), conv: o._converted, svgW: sz.w, svgH: sz.h, docxMedia: (dx.match(/word\/media\/image\d\.png/g) || []).length, docxNote: dx.includes('書き出せません'), pptxMedia: (px.match(/ppt\/media\/image\d\.png/g) || []).length, orig: d.images['line.svg'].mime };
  });
  if (r.mimes.join() !== 'image/png,image/png' || r.conv !== 2 || r.svgW !== 2000 || r.svgH !== 1000 || r.docxMedia < 2 || r.docxNote || r.pptxMedia < 2 || r.orig !== 'image/svg+xml') bad('svg/webp → png for Office export', r);
  await browser.close();
  console.log('110b-paste fails=' + fails, 'errors:', errors); process.exit(fails ? 1 : 0);
})();
