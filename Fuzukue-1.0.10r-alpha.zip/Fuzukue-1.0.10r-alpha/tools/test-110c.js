/* 1.0.10c：取説（F1）の作り直しと取扱説明書.fzk、構えの見せ方・案内（ガイダンス行）、右の欄のキーの印、状態行の語、アウトラインの操作、書き出し中、表の下端の罫 */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
  const url = 'file://' + path.resolve(__dirname, '../app/index.html');
  const open = async (q = '') => { const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); }); await page.goto(url + q); await page.waitForTimeout(400); return page; };
  let page = await open(); await page.evaluate(() => localStorage.clear());
  // 1 取説：見出し・目次・節・キーの枠、キャッチコピーなし、引けないキーなし
  await page.keyboard.press('F1'); await page.waitForTimeout(300);
  let r = await page.evaluate(() => { const b = document.getElementById('sideBody'); const img = b.querySelector('.hhead img'); return { wide: document.getElementById('side').classList.contains('wide'), logo: !!img && img.naturalWidth > 0, toc: b.querySelectorAll('.htoc a').length, secs: b.querySelectorAll('section').length, rows: b.querySelectorAll('section dl dt').length, kbd: b.querySelectorAll('kbd').length, text: b.textContent, details: b.querySelectorAll('details').length, f1: document.querySelector('#fkeys .fk[data-cmd="help"]').className }; });
  if (!r.wide || !r.logo || r.toc !== r.secs || r.secs < 12 || r.rows < 80 || r.kbd < 80 || r.details < 8) bad('help structure', { ...r, text: undefined });
  if (/マス目に、そのまま/.test(r.text) || /キーなし/.test(r.text)) bad('help has catch copy or unresolved keys', r.text.match(/.{20}(マス目に|キーなし).{20}/));
  if (!r.text.includes('F5→1 / Ctrl+B') || !r.text.includes('画面のつくり') || !r.text.includes('困ったとき')) bad('help content', r.text.slice(0, 200));
  if (!/\bpon\b/.test(r.f1) || /\bon\b/.test(r.f1)) bad('F1 key marked as open pane, not lit group', r.f1);
  r = await page.evaluate(async () => { const b = document.getElementById('sideBody'); b.scrollTop = 0; b.querySelector('.htoc a[data-go="h-file"]').click(); await new Promise(r => setTimeout(r, 50)); const t = document.getElementById('h-file').getBoundingClientRect().top - b.getBoundingClientRect().top; return { top: b.scrollTop, t }; });
  if (!(r.top > 200) || Math.abs(r.t) > 4) bad('help toc jumps to section', r);
  await page.keyboard.press('F1'); await page.waitForTimeout(80);
  // 2 取扱説明書：取説と同じ中身＋見本、原本として安定、同梱の samples/取扱説明書.fzk と同じ
  const man = await page.evaluate(() => FZ.manualText());
  const shipped = fs.readFileSync(path.resolve(__dirname, '../samples/取扱説明書.fzk'), 'utf8'); if (shipped !== man) bad('samples/取扱説明書.fzk is stale: run node tools/build-manual.js');
  for (const need of ['[目次1-1]', '#囲み ×3', '#箱 1', '#レーン', '[区切り]', '様式 新聞', '[飾り:罫囲み]', '[発言4]', '[番号項目1]', '[☑1]', '<横倍角><縦倍角>四倍角', '[番号1 改頁]キーの一覧']) if (!man.includes(need)) bad('manual lacks ' + need);
  if (/キーなし|マス目に、そのまま/.test(man)) bad('manual has unresolved keys or catch copy');
  r = await page.evaluate(() => { const S = FZ.help.sections(id => FZ.app.keysOf(id).split(' / ')[0], id => FZ.app.keysOf(id)); const m = FZ.manualText(); const miss = []; for (const s of S) { if (!m.includes(s.title)) miss.push(s.title); for (const [w] of s.rows) if (!m.includes(w.replace(/\|/g, '\\|'))) miss.push(w); } const d = FZ.parse(m); const s1 = FZ.serialize(d); return { miss, stable: s1 === FZ.serialize(FZ.parse(s1)), pages: FZ.layout(d).pages.length }; });
  if (r.miss.length || !r.stable || r.pages < 10) bad('manual = help sections, stable, paginated', r);
  // 3 取扱説明書を開く：別の窓（URL に open=manual）。窓が開けなければこの窓で
  r = await page.evaluate(async () => { const calls = []; const wo = window.open; window.open = (u) => { calls.push(u); return {}; }; FZ.app.run('manual'); window.open = wo; return calls; });
  if (r.length !== 1 || !/open=manual/.test(r[0])) bad('manual opens a new window', r);
  r = await page.evaluate(async () => { const wo = window.open; window.open = () => null; FZ.app.ed.dirty = false; FZ.app.run('manual'); window.open = wo; await new Promise(r => setTimeout(r, 400)); return { t: FZ.app.ed.doc.lines[0].segs.map(s => s.text).join(''), dirty: FZ.app.ed.dirty, file: document.getElementById('stFile').textContent }; });
  if (!r.t.includes('取扱説明書') || r.dirty || !r.file.includes('取扱説明書')) bad('manual falls back to this window', r);
  const p2 = await open('?w=3&open=manual'); await p2.waitForTimeout(500);
  r = await p2.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs.map(s => s.text).join(''), pages: FZ.app.ed.lay.pages.length })); if (!r.t.includes('取扱説明書')) bad('?open=manual window loads the manual', r); await p2.close();
  // 4 構え：帯の左端・状態行の案内が反転、Esc で戻る
  await page.evaluate(async () => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n本文\n')); FZ.app.render(); }); await page.focus('#ta');
  await page.keyboard.press('F5'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ body: document.body.classList.contains('armed'), sub: document.getElementById('sub').classList.contains('armed'), g: document.getElementById('stGuide').textContent, arm: document.getElementById('stGuide').classList.contains('arm'), bl: getComputedStyle(document.getElementById('sub')).borderLeftWidth }));
  if (!r.body || !r.sub || !/項目を選ぶ/.test(r.g) || !r.arm || parseFloat(r.bl) < 3) bad('armed state is visible', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(40);
  r = await page.evaluate(() => ({ body: document.body.classList.contains('armed'), g: document.getElementById('stGuide').textContent, arm: document.getElementById('stGuide').classList.contains('arm') }));
  if (r.body || r.arm || !/F1 取説/.test(r.g)) bad('guide back to normal after Esc', r);
  // 案内は場面で変わる：表の中・見出し・欄
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n[番号1]題\n#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |\n')); app.render(); const out = {}; app.ed.setCaret({ line: 0, seg: 0, off: 0 }); out.head = document.getElementById('stGuide').textContent; app.ed.setCaret({ line: 1, seg: 0, off: 0 }); out.table = document.getElementById('stGuide').textContent; app.openForm('zoom'); out.form = document.getElementById('stGuide').textContent; return out; });
  if (!/深く/.test(r.head) || !/次のセル/.test(r.table) || !/決定/.test(r.form)) bad('guide follows context', r); await page.keyboard.press('Escape');
  // 5 状態行の語：倍率・保存の状態
  r = await page.evaluate(async () => { const app = FZ.app; app.st.zoom = 'width'; await app.loadText('#fzk 2\n---\n本文\n', 'x.fzk', null); app.render(); const a = { view: document.getElementById('stView').textContent, save: document.getElementById('stSave').textContent }; app.ed.insertText('あ'); app.render(); a.dirty = document.getElementById('stSave').textContent;
    const h = { kind: 'file', name: 'x.fzk', getFile: async () => ({ lastModified: 1, name: 'x.fzk' }), createWritable: async () => ({ write: async () => { }, close: async () => { } }) }; app.st.file = { name: 'x.fzk', handle: h }; await app.run('save'); await new Promise(r => setTimeout(r, 60)); a.saved = document.getElementById('stSave').textContent; app.st.zoom = 'page'; app.render(); a.page = document.getElementById('stView').textContent; app.st.zoom = 'width'; app.render(); return a; });
  if (r.view !== '幅合わせ' || r.save !== '保存先なし' || r.dirty !== '未保存' || !/^保存済 \d{1,2}:\d\d$/.test(r.saved) || r.page !== '頁全体') bad('status words', r);
  // 6 アウトラインは 1.0.10e でツリーに置き換え（右の欄には出さない。詳しくは test-110e）
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n[番号1]一\n本文\n[番号2]一の一\n本文\n[番号1]二\n本文\n')); app.render(); app.ed.setCaret({ line: 3, seg: 0, off: 0 }); app.run('outlinePanel'); await new Promise(r => setTimeout(r, 50)); const o = { mode: app.st.mode, side: !document.getElementById('side').hidden }; app.run('outlinePanel'); o.back = app.st.mode; return o; });
  if (r.mode !== 'tree' || r.side || r.back !== 'text') bad('outline command opens the tree, not a side panel', r);
  // 7 書き出し中：Word の前に知らせを出す
  r = await page.evaluate(async () => { const seen = []; const el = document.getElementById('stMsg'); const mo = new MutationObserver(() => seen.push(el.textContent)); mo.observe(el, { childList: true, characterData: true, subtree: true }); const dl = FZ.files.download; FZ.files.download = () => { }; await FZ.app.run('exportDocx'); await new Promise(r => setTimeout(r, 300)); FZ.files.download = dl; mo.disconnect(); return seen; });
  if (!r.some(t => /Word に書き出し中/.test(t)) || !r.some(t => /書き出しました/.test(t))) bad('busy message before Word export', r);
  // 8 表の下端の罫：表の次の行に前の空き（戻り空き）があっても、罫は表の下に付く
  r = await page.evaluate(() => { const d = FZ.parse('#fzk 2\n戻り空き: あり\n---\n[番号1]一\n本文\n#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |\n[番号1]二\n本文\n'); const L = FZ.layout(d); const pg = L.pages[0]; const v = pg.vrules.find(x => x.col === 0); const hb = pg.hrules.filter(x => x.line === 4); return { vEnd: v && v.y2, hb: hb.map(x => x.y) }; });
  if (!r.hb.length || r.hb.some(y => y !== r.vEnd)) bad('table bottom rule sits on the table, not below the gap', r);
  console.log(`110c fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
