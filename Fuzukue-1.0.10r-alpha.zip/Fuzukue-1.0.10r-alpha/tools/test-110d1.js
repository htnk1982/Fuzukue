/* 1.0.10d.1：文書の種類（帯の左端のプルダウン）、新しい資料、選択肢はプルダウン（押すたびに巡るボタンをやめる）、課題と完了・引用の入切、見出し行の網 */
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  // 1 種類：帯の左端に常にある。資料にすると A4 横・60 字、文書に戻すと既定の用紙。取り消しで戻り、プルダウンも追従。中身は変わらない
  await page.evaluate(() => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n[表題]報告の題\n[番号1]背景\n本文です。\n')); FZ.app.render(); });
  let r = await page.evaluate(() => { const k = document.getElementById('kind'); const rk = k.getBoundingClientRect(), rf = document.getElementById('fkeys').getBoundingClientRect(); return { vis: rk.width > 30 && rk.left < rf.left, v: document.getElementById('kindSel').value }; });
  if (!r.vis || r.v !== 'doc') bad('kind pulldown sits at the left of the band', r);
  const b0 = await body(); await page.selectOption('#kindSel', 'slide'); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const f = FZ.app.ed.doc.format; return { kind: f.kind, w: f.widthMm, h: f.heightMm, cols: f.cols, focus: document.activeElement.id }; });
  if (r.kind !== 'slide' || r.w !== 297 || r.h !== 210 || r.cols !== 60 || r.focus !== 'ta' || (await body()) !== b0) bad('kind → slide', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60); r = await page.evaluate(() => [FZ.app.ed.doc.format.kind || 'doc', document.getElementById('kindSel').value]); if (r.join() !== 'doc,doc') bad('undo kind', r);
  await page.selectOption('#kindSel', 'slide'); await page.selectOption('#kindSel', 'doc'); await page.waitForTimeout(60);
  r = await page.evaluate(() => { const f = FZ.app.ed.doc.format; return { kind: f.kind, w: f.widthMm, cols: f.cols }; }); if (r.kind !== 'doc' || r.w !== 210 || r.cols !== 40) bad('kind → doc uses the default paper', r);
  r = await page.evaluate(async () => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n種類: 資料\n---\n本文\n')); FZ.app.render(); await new Promise(r => setTimeout(r, 30)); return document.getElementById('kindSel').value; }); if (r !== (await page.evaluate(() => FZ.app.ed.doc.format.kind === 'slide' ? 'slide' : 'doc'))) bad('pulldown follows the opened document', r);
  // 新しい資料（F2→D）
  r = await page.evaluate(async () => { FZ.app.ed.dirty = false; FZ.app.run('newSlide'); await new Promise(r => setTimeout(r, 50)); return { kind: FZ.app.ed.doc.format.kind, sel: document.getElementById('kindSel').value, title: FZ.app.ed.doc.lines[0].attrs.style }; });
  if (r.kind !== 'slide' || r.sel !== 'slide' || r.title !== 'title') bad('new slide from F2→D', r);
  r = await page.evaluate(() => { FZ.app.run('fileGroup'); return !!document.querySelector('#sub .ch[data-cmd="newSlide"]'); }); if (!r) bad('new slide tile in F2'); await page.keyboard.press('Escape');
  // 2 選択肢はプルダウン：どの欄にも押すたびに巡るボタンが無い
  r = await page.evaluate(async () => { const out = []; FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |\n[番号1]題\n')); FZ.app.render(); FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 });
    for (const f of ['format', 'scheme', 'table', 'toc', 'find', 'slide', 'headFill', 'shadeType', 'scale']) { try { FZ.app.openForm(f); await new Promise(r => setTimeout(r, 20)); const btn = document.querySelectorAll('#sub button.cyc').length; const sel = document.querySelectorAll('#sub select.cyc').length; out.push([f, btn, sel]); document.querySelector('#sub button[data-act="cancel"]') ? document.querySelector('#sub button[data-act="cancel"]').click() : null; } catch (e) { out.push([f, 'ERR ' + e.message]); } } return out; });
  if (r.some(x => x[1] !== 0) || !r.find(x => x[0] === 'format')[2]) bad('forms use pulldowns, no cycling buttons', r);
  // 欄のプルダウンで値を選んで適用（書式の向き）
  await page.evaluate(() => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n本文\n')); FZ.app.render(); FZ.app.openForm('format'); }); await page.selectOption('#sub select[name="landscape"]', '1'); await page.click('#sub button[data-act="apply"]'); await page.waitForTimeout(60);
  r = await page.evaluate(() => { const f = FZ.app.ed.doc.format; return [f.widthMm, f.heightMm]; }); if (!(r[0] > r[1])) bad('choose landscape from the pulldown', r);
  // 見出し行の網：選んで適用
  await page.evaluate(() => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n#表 列 0,10,20 様式 格子 見出し薄\n| a | b |\n| c | d |\n')); FZ.app.render(); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('to:headFill'); });
  r = await page.evaluate(() => document.querySelector('#sub select[name="shade"]').value); if (r !== 'gray') bad('head fill form shows the current shade', r);
  await page.selectOption('#sub select[name="shade"]', 'dark'); await page.keyboard.press('Enter'); await page.waitForTimeout(40); r = await body(); if (!/様式 格子 見出し濃/.test(r)) bad('head fill applied from the pulldown', r);
  // 3 課題 ❏・完了 ☑・引用は入切
  r = await page.evaluate(() => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\nやること\n')); app.render(); const out = []; const k = () => { const l = app.ed.line().attrs.list; return l ? (l.kind || 'item') : '-'; };
    app.run('todo'); out.push(k()); app.run('todo'); out.push(k()); app.run('todo'); app.run('done'); out.push(k()); app.run('done'); out.push(k()); app.run('done'); out.push(k()); app.run('todo'); out.push(k());
    app.run('quote'); out.push(app.ed.line().attrs.quote | 0); app.run('quote'); out.push(app.ed.line().attrs.quote | 0); return out.join(); });
  if (r !== 'todo,-,done,todo,done,-,1,0') bad('todo / done / quote toggle on and off', r);
  r = await page.evaluate(() => { FZ.app.run('structGroup'); return !!document.querySelector('#sub .ch[data-cmd="done"]'); }); if (!r) bad('done tile in F4'); await page.keyboard.press('Escape');
  // 図の F5・F6 は巡回でなく、複製と箱の設定
  r = await page.evaluate(() => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n#箱 1 0,1 8x3 細 無 A\n[図6]\n')); app.render(); app.ed.setCaret({ line: 0, seg: 0, off: 0 }); app.run('figInsert'); return [...document.querySelectorAll('#fkeys .fk')].map(x => x.dataset.cmd).slice(4, 6).join(); });
  if (r !== 'fg:dup,fg:props') bad('figure F5/F6 are duplicate and box settings', r);
  // 4 取説
  r = await page.evaluate(() => { const m = FZ.manualText(); return ['文書の種類', 'プルダウン', '完了の ☑'].filter(w => !m.includes(w)); }); if (r.length) bad('manual mentions kind pulldown and done', r);
  console.log(`110d1 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
