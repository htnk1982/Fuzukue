/* 1.0.10e：ツリー（T1〜T3）— 見え方の切替・節の描き方・深さ・畳み・キーで移動と編集・マウスで選ぶ／動かす／足す／直す・写す／貼る・紙面との行き来・罫と網を連れて動く */
const { chromium } = require('playwright'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-table', 'fz-tree']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
const SRC = '[表題]生成AIの浸透戦略\n[番号1]現状認識\n本文A\n[項目1]UXの壁\n[項目2]プロンプトの呪縛\n[項目1]心理の壁\n[番号1]施策\n[番号2]UX変革\n[項目1]逆提案型UI\n[番号2]価値転換\n#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |\n[番号1]目指す姿\n#囲み ×2\nメモ\n[項目1]x\n本文B\n';
(async () => {
  // 1 中身：ツリーの形、節の範囲、動かすと罫・網（表・囲み）が付いてくる、種類の付け替え
  { const e = new FZ.Editor(); e.onChange = () => { }; e.onCaret = () => { }; e.setDoc(FZ.parse('#fzk 2\n---\n' + SRC)); const tr = FZ.tree.build(e.doc, { body: true });
    const shape = []; const w = (n, d) => { shape.push(d + ':' + n.kind + ':' + n.text.slice(0, 6)); for (const c of n.children) w(c, d + 1); }; w(tr.root, 0);
    const want = ['0:root:文書', '1:title:生成AIの浸', '2:num:現状認識', '3:body:本文A', '3:list:UXの壁', '4:list:プロンプトの', '3:list:心理の壁', '2:num:施策', '3:num:UX変革', '4:list:逆提案型UI', '3:num:価値転換', '4:block:［表］a・b', '2:num:目指す姿', '3:block:［囲み］メモ', '3:body:本文B'];
    if (shape.join('|') !== want.join('|')) bad('tree shape', shape);
    const f = t => FZ.tree.build(e.doc, { body: true }).nodes.find(n => n.text === t);
    e.mutate('', () => FZ.tree.move(e, FZ.tree.build(e.doc, { body: true }), [f('目指す姿')], f('現状認識'), 'before'));
    const s1 = FZ.serialize(e.doc).split('---\n')[1]; if (!/^\[表題\]生成AIの浸透戦略\n\[番号1\]目指す姿\n#囲み ×2\nメモ\n\[項目1\]x\n本文B\n\[番号1\]現状認識/.test(s1) || !s1.includes('#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |')) bad('move carries the box and the table', s1);
    e.undo(); e.mutate('', () => FZ.tree.move(e, FZ.tree.build(e.doc, { body: true }), [f('UXの壁')], f('施策'), 'after'));
    const s2 = FZ.serialize(e.doc).split('---\n')[1]; if (!s2.includes('[番号1]UXの壁\n[項目1]プロンプトの呪縛\n[番号1]目指す姿')) bad('list item dropped beside a heading becomes a heading; its sub items stay items', s2);
    e.undo(); e.mutate('', () => FZ.tree.demote(e, FZ.tree.build(e.doc, { body: true }), f('価値転換')));
    const s3 = FZ.serialize(e.doc).split('---\n')[1]; if (!s3.includes('[項目1]逆提案型UI\n[番号3]価値転換\n#表')) bad('demote makes it the last child of the elder sibling', s3);
    e.undo(); e.mutate('', () => FZ.tree.remove(e, [f('施策')])); const s4 = FZ.serialize(e.doc).split('---\n')[1]; if (/施策|#表|#罫/.test(s4) || !s4.includes('#囲み ×2')) bad('remove a section with its table', s4); }
  // 2 画面
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const S = () => page.evaluate(() => ({ mode: FZ.app.st.mode, sel: (() => { const v = FZ.app.st.tree.view; const k = FZ.app.st.tree.sel; const n = v && v.shown.find(n => (n.obj || 'root') === k); return n ? n.text : null; })(), n: document.querySelectorAll('#tree .tn').length, view: document.getElementById('viewSel').value }));
  const box = text => page.evaluate(t => { const g = [...document.querySelectorAll('#tree .tn')].find(g => g.textContent.includes(t)); if (!g) return null; const r = g.querySelector('rect').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }, text);
  await page.evaluate(src => { FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\n' + src)); FZ.app.render(); FZ.app.ed.setCaret({ line: 8, seg: 0, off: 0 }); }, SRC);
  // 開く：Ctrl+Shift+O、今いる節が選ばれる。右の欄のアウトラインは無い
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); let r = await S();
  if (r.mode !== 'tree' || r.sel !== '逆提案型UI' || r.view !== 'tree' || r.n !== 11) bad('open the tree at the current node', r);
  r = await page.evaluate(() => ({ pages: document.getElementById('pages').style.display, side: !document.getElementById('side').hidden, band: !!document.querySelector('#sub #tvKind') && !!document.querySelector('#sub .ch[data-cmd="tv:after"]') })); if (r.pages !== 'none' || r.side || !r.band) bad('tree replaces the paper, band shows tree tools', r);
  // キー：移る・足す・打つ
  await page.keyboard.press('ArrowLeft'); r = await S(); if (r.sel !== 'UX変革') bad('left goes to the parent', r);
  await page.keyboard.press('ArrowDown'); r = await S(); if (r.sel !== '逆提案型UI') bad('down goes to the next row (indented tree)', r);
  await page.keyboard.press('ArrowDown'); r = await S(); if (r.sel !== '価値転換') bad('down again goes to the next row', r);
  // 字下げの形：子は親より右、上から下へ 1 行ずつ。枝の線がある
  r = await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === 'UX変革'), c = v.shown.find(x => x.text === '逆提案型UI'), s2 = v.shown.find(x => x.text === '価値転換'); const P = q => v.pos.get(q); return { dir: FZ.app.st.tree.dir, inx: P(c).x > P(n).x, down: P(c).y > P(n).y && P(s2).y > P(c).y, same: P(s2).x === P(n).x, paths: document.querySelectorAll('#tree .tl path').length }; });
  if (r.dir !== 'i' || !r.inx || !r.down || !r.same || r.paths < 3) bad('indented tree layout by default', r);
  await page.keyboard.press('Tab'); await page.waitForTimeout(60); await page.keyboard.type('収益化'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  await page.keyboard.press('Enter'); await page.waitForTimeout(60); await page.keyboard.type('継続課金'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  r = await body(); if (!r.includes('[番号2]価値転換\n#表 列 0,10,20 様式 格子\n| a | b |\n| c | d |\n[番号3]収益化\n[番号3]継続課金\n[番号1]目指す姿')) bad('Tab adds a child, Enter a sibling, typed in place', r);
  await page.keyboard.press('Enter'); await page.waitForTimeout(60); await page.keyboard.press('Escape'); await page.waitForTimeout(60); r = await body(); if ((r.match(/\[番号3\]/g) || []).length !== 2) bad('Esc on a new empty node removes it', r);
  // Alt+↑ で上へ、Alt+← で浅く、取り消し
  await page.keyboard.press('Alt+ArrowUp'); await page.waitForTimeout(60); r = await body(); if (!r.includes('[番号3]継続課金\n[番号3]収益化')) bad('Alt+Up moves among siblings', r);
  await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(60); r = await body(); if (!/\[番号2\]継続課金\n\[番号1\]目指す姿/.test(r)) bad('Alt+Left promotes to the parent level', r.slice(-160));
  await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z'); await page.waitForTimeout(60); r = await body(); if (!r.includes('[番号3]収益化\n[番号3]継続課金')) bad('undo tree moves', r);
  // F2 で直す、Delete で消す
  await page.keyboard.press('Control+Enter'); await page.waitForTimeout(40); await page.keyboard.press('Control+a'); await page.keyboard.type('サブスク'); await page.keyboard.press('Enter'); await page.waitForTimeout(40); r = await body(); if (!r.includes('[番号3]サブスク')) bad('Ctrl+Enter edits the node text', r);
  await page.keyboard.press('Delete'); await page.waitForTimeout(40); r = await body(); if (r.includes('サブスク')) bad('Delete removes the node', r);
  // 深さ・畳み
  await page.keyboard.press('1'); await page.waitForTimeout(40); r = await S(); if (r.n !== 4) bad('depth 1 shows the top headings', r);
  r = await page.evaluate(() => document.querySelector('#tree .fold') && document.querySelector('#tree .fold').textContent); if (!/^＋\d+$/.test(r || '')) bad('folded count badge', r);
  await page.keyboard.press('9'); await page.keyboard.press('0'); await page.waitForTimeout(40); r = await S(); if (r.n < 15) bad('depth 0 shows body, tables and boxes', r);
  await page.keyboard.press('9'); await page.waitForTimeout(40);
  // 深さのタイル（一括）：1 段 → 4 節、本文 → 本文まで、全部に戻す
  await page.evaluate(() => FZ.app.run('tvd:1')); await page.waitForTimeout(40); r = await S(); if (r.n !== 4) bad('depth tile 1 shows the top headings', r);
  await page.keyboard.press('F4'); await page.waitForTimeout(40); r = await page.evaluate(() => { const e = document.querySelector('#ms_depth'); return !!e && e.value === '1'; }); if (!r) bad('depth tile (F10) shows its state'); await page.keyboard.press('Escape'); await page.waitForTimeout(40);
  await page.evaluate(() => FZ.app.run('tvd:0')); await page.waitForTimeout(40); r = await S(); if (r.n < 15) bad('depth tile body shows body text', r);
  await page.evaluate(() => FZ.app.run('tvd:9')); await page.waitForTimeout(40);
  // 狭い幅：横にはみ出さない（深い節は折り返す）
  await page.setViewportSize({ width: 760, height: 900 }); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const m = document.getElementById('treePane'); return { sw: m.scrollWidth, cw: m.clientWidth }; }); if (r.sw > r.cw + 2) bad('indented tree fits a narrow window', r);
  await page.setViewportSize({ width: 1280, height: 900 }); await page.waitForTimeout(150);
  // 拡大・縮小：Ctrl+= で大きく（箱も字も）、拡大したままクリックで正しい節を選べる、Ctrl+0 で等倍、帯の縮小
  const w0 = (await box('心理の壁')).h; await page.keyboard.press('Control+Equal'); await page.waitForTimeout(60); await page.keyboard.press('Control+Equal'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ sc: FZ.app.st.tree.scale, view: document.getElementById('stView').textContent })); let bz = await box('心理の壁');
  if (!(r.sc > 1.2) || !(bz.h > w0 * 1.2) || !/ツリー 1\d\d%/.test(r.view)) bad('Ctrl+= zooms the tree', { r, h0: w0, h1: bz.h });
  await page.mouse.click(bz.x + 30, bz.y + bz.h / 2); r = await S(); if (r.sel !== '心理の壁') bad('click selects the right node when zoomed', r);
  r = await page.evaluate(() => { const m = document.getElementById('treePane'); return { sw: m.scrollWidth, cw: m.clientWidth }; }); if (r.sw > r.cw + 2) bad('zoomed indented tree still fits the width', r);
  await page.keyboard.press('F10'); await page.waitForTimeout(30); await page.click('#sub .ch[data-cmd="zoomOut"]'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ sc: FZ.app.st.tree.scale, mode: FZ.app.st.mode })); if (!(r.sc > 1 && r.sc < 1.3) || r.mode !== 'tree') bad('F10 zoom-out tile works in the tree', r); await page.keyboard.press('Escape'); await page.waitForTimeout(30);
  await page.keyboard.press('Control+0'); await page.waitForTimeout(60); r = await page.evaluate(() => FZ.app.st.tree.scale); if (r !== 1) bad('Ctrl+0 resets the tree zoom', r);
  // マウス：クリックで選ぶ、ダブルクリックで直す、ドラッグで動かす（子に落とす）
  let b = await box('心理の壁'); await page.mouse.click(b.x + 20, b.y + b.h / 2); r = await S(); if (r.sel !== '心理の壁') bad('click selects', r);
  await page.mouse.dblclick(b.x + 20, b.y + b.h / 2); await page.waitForTimeout(40); await page.keyboard.press('End'); await page.keyboard.type('（認知）'); await page.keyboard.press('Enter'); await page.waitForTimeout(40);
  r = await body(); if (!r.includes('[項目1]心理の壁（認知）')) bad('double-click edits in place', r);
  await page.waitForTimeout(700); b = await box('心理の壁'); let t = await box('目指す姿');
  await page.mouse.move(b.x + 20, b.y + b.h / 2); await page.mouse.down(); await page.mouse.move(t.x + t.w * 0.5, t.y + t.h / 2, { steps: 6 }); await page.mouse.move(t.x + t.w * 0.9, t.y + t.h / 2, { steps: 3 }); await page.waitForTimeout(30);
  r = await page.evaluate(() => !!document.querySelector('#tree .tdrop')); await page.mouse.up(); await page.waitForTimeout(60);
  const r2 = await body(); if (!r || !/\[番号1\]目指す姿\n#囲み ×2\nメモ\n\[項目1\]x\n本文B\n\[項目1\]心理の壁（認知）/.test(r2)) bad('drag onto the right part of a node drops it as a child', { ind: r, b: r2.slice(-120) });
  // ドラッグで上に落とす（兄弟の前へ）
  b = await box('目指す姿'); t = await box('現状認識'); await page.mouse.move(b.x + 20, b.y + b.h / 2); await page.mouse.down(); await page.mouse.move(t.x + 30, t.y + 3, { steps: 6 }); await page.waitForTimeout(30); await page.mouse.up(); await page.waitForTimeout(60);
  r = await body(); if (!/^\[表題\]生成AIの浸透戦略\n\[番号1\]目指す姿/.test(r)) bad('drag onto the top edge drops it before', r.slice(0, 80));
  await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 寄せると出る ＋ で子を足す
  b = await box('UX変革'); await page.mouse.move(b.x + b.w / 2, b.y + b.h / 2); await page.waitForTimeout(40); r = await page.evaluate(() => document.querySelectorAll('#tree .tadd').length);
  const add = await page.evaluate(() => { const g = document.querySelector('#tree .tadd[data-add="child"] circle'); const rr = g.getBoundingClientRect(); return { x: rr.left + rr.width / 2, y: rr.top + rr.height / 2 }; });
  await page.mouse.move(add.x, add.y); await page.mouse.click(add.x, add.y); await page.waitForTimeout(60); await page.keyboard.type('音声入力'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  const r3 = await body(); if (r !== 2 || !r3.includes('[項目1]逆提案型UI\n[項目1]音声入力')) bad('hover + adds a child', { n: r, b: r3 });
  // 種類が箱に見える。番号・記号の形を帯で変える（同じ段のものすべて）。種類を番号箇条書きに
  r = await page.evaluate(() => document.querySelectorAll('#tree .tn text.tk').length); if (r) bad('no kind labels in the boxes (kind is shown in the band)', r);
  b = await box('現状認識'); await page.mouse.click(b.x + 30, b.y + b.h / 2); await page.waitForTimeout(40);
  r = await page.evaluate(() => ({ v: document.getElementById('tvMark').value, dis: document.getElementById('tvMark').disabled, k: document.getElementById('tvKind').value })); if (r.v !== '1.' || r.dis || r.k !== 'num') bad('marker select shows the level scheme', r);
  await page.selectOption('#tvMark', 'Ⅰ'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ f: FZ.app.ed.doc.format.scheme[0], mk: [...document.querySelectorAll('#tree .tn')].map(g => g.textContent).filter(t => /現状認識|施策|目指す姿/.test(t)) })); if (r.f !== 'Ⅰ' || !r.mk.every(t => /^Ⅰ|^Ⅱ|^Ⅲ/.test(t))) bad('marker change applies to the level and shows in the tree', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(40); r = await page.evaluate(() => FZ.app.ed.doc.format.scheme[0]); if (r !== '1.') bad('undo marker change', r);
  b = await box('UXの壁'); await page.mouse.click(b.x + 30, b.y + b.h / 2); await page.waitForTimeout(40); await page.selectOption('#tvKind', 'nlist'); await page.waitForTimeout(60);
  r = await body(); const r5 = await page.evaluate(() => ({ v: document.getElementById('tvMark').value, k: document.getElementById('tvKind').value, lab: [...document.querySelectorAll('#tree .tn')].find(g => g.textContent.includes('UXの壁')).textContent }));
  if (!/\[番号項目1\]UXの壁/.test(r) || r5.v !== '1）' || r5.k !== 'nlist' || !/^1）/.test(r5.lab)) bad('kind to numbered list', { b: r.slice(0, 120), r5 });
  await page.selectOption('#tvMark', '①'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ l: FZ.app.ed.doc.format.listScheme[0], t: [...document.querySelectorAll('#tree .tn')].find(g => g.textContent.includes('UXの壁')).textContent })); if (r.l !== '①' || !/^①/.test(r.t)) bad('numbered list marker change', r);
  await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z'); await page.waitForTimeout(60); r = await body(); if (!/\[項目1\]UXの壁/.test(r)) bad('undo kind change', r.slice(0, 120));
  // 寄せると出る下の ＋ で弟を足す（下の＋は次の行に重なるが、寄せている節は替わらない）
  b = await box('UX変革'); await page.mouse.move(b.x + b.w / 2, b.y + b.h / 2); await page.waitForTimeout(40);
  const addA = await page.evaluate(() => { const g = document.querySelector('#tree .tadd[data-add="after"] circle'); if (!g) return null; const rr = g.getBoundingClientRect(); return { x: rr.left + rr.width / 2, y: rr.top + rr.height / 2 }; });
  if (addA) { await page.mouse.move(addA.x, addA.y - 6, { steps: 2 }); await page.mouse.move(addA.x, addA.y + 3, { steps: 3 }); await page.waitForTimeout(30); await page.mouse.click(addA.x, addA.y + 3); await page.waitForTimeout(60); await page.keyboard.type('弟の施策'); await page.keyboard.press('Enter'); await page.waitForTimeout(60); }
  r = await body(); if (!addA || !/\[項目1\]音声入力\n\[番号2\]弟の施策\n\[番号2\]価値転換/.test(r)) bad('bottom + adds a younger sibling', { addA, b: r.slice(0, 200) }); await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 囲んで選ぶ → Delete でまとめて消す → 取り消し
  b = await box('UXの壁'); t = await box('心理の壁'); await page.mouse.move(b.x - 10, b.y + b.h / 2); await page.mouse.down(); await page.mouse.move(t.x + t.w + 6, t.y + t.h / 2, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(40);
  r = await page.evaluate(() => FZ.app.st.tree.multi.size); await page.keyboard.press('Delete'); await page.waitForTimeout(40); const r4 = await body();
  if (r < 2 || r4.includes('UXの壁') || r4.includes('心理の壁')) bad('rubber band select and delete', { n: r, b: r4.slice(0, 120) }); await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 写す（Markdown）・貼る（箇条書きを子として）
  b = await box('現状認識'); await page.mouse.click(b.x + 20, b.y + b.h / 2);
  r = await page.evaluate(() => { const dt = new DataTransfer(); document.getElementById('ta').dispatchEvent(new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true })); return dt.getData('text/plain'); });
  if (!/現状認識/.test(r) || !/- UXの壁/.test(r) || !/本文A/.test(r)) bad('copy a node as Markdown', r);
  b = await box('目指す姿'); await page.mouse.click(b.x + 20, b.y + b.h / 2);
  await page.evaluate(() => { const dt = new DataTransfer(); dt.setData('text/plain', '- 社会インフラ化\n  - 不可視化\n- あたりまえ化\n'); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }); await page.waitForTimeout(60);
  r = await body(); if (!/本文B\n\[項目1\]社会インフラ化\n\[項目2\]不可視化\n\[項目1\]あたりまえ化/.test(r)) bad('paste a Markdown list as children', r.slice(-160));
  // 紙面へ：選んだ節の頭にカーソル。プルダウンからも行き来
  b = await box('価値転換'); await page.mouse.click(b.x + 20, b.y + b.h / 2); await page.keyboard.press('Escape'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ mode: FZ.app.st.mode, t: FZ.app.ed.line().segs[0].text, view: document.getElementById('viewSel').value, tree: document.getElementById('tree').style.display })); if (r.mode !== 'text' || r.t !== '価値転換' || r.view !== 'paper' || r.tree !== 'none') bad('Esc returns to the paper at the node', r);
  await page.selectOption('#viewSel', 'tree'); await page.waitForTimeout(60); r = await S(); if (r.mode !== 'tree' || r.sel !== '価値転換') bad('view pulldown opens the tree', r);
  await page.evaluate(() => FZ.app.run('tvs:v')); await page.waitForTimeout(60); r = await page.evaluate(() => { const a = [...document.querySelectorAll('#tree .tn')].map(g => g.querySelector('rect').getBoundingClientRect()); return a[0].top < a[1].top; }); if (!r) bad('top-down layout', r);
  await page.selectOption('#viewSel', 'paper'); await page.waitForTimeout(60); r = await S(); if (r.mode !== 'text') bad('view pulldown back to paper', r);
  // 3 取説・帯
  r = await page.evaluate(() => { const m = FZ.manualText(); return ['ツリー', '弟を足す', '子を足す', '紙面へ'].filter(w => !m.includes(w)); }); if (r.length) bad('manual explains the tree', r);
  r = await page.evaluate(() => { FZ.app.run("structGroup"); return !!document.querySelector("#sub .ch[data-cmd=\"outlinePanel\"]"); }); if (!r) bad("F4 has the tree tile");
  console.log(`110e fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
