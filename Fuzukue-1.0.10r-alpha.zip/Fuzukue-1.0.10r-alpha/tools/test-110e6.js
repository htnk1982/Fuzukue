/* 1.0.10e.7：ツリーの深さ「文」— 段落を「。」ごとの文の節に（括弧の中では切らない）、文を直す・足す・消す・入れ替える・別の段落へドラッグ・独立した段落に */
const { chromium } = require('playwright'); const path = require('path');
require('../app/js/fz-core.js'); require('../app/js/fz-tree.js'); const FZ = globalThis.FZ;
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した！「本当か？」と問う。\n[番号1]課題\n為替が重い。\n';
(async () => {
  const ss = FZ.tree.sentences('売上は伸びた。海外が牽引した！　「本当か？」と問う。残り').map(x => x.text); if (ss.join('|') !== '売上は伸びた。|海外が牽引した！|「本当か？」と問う。|残り') bad('sentence split (brackets)', ss);
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  await page.evaluate(async src => { await FZ.app.loadText('#fzk 2\n---\n' + src, 'x.fzk', null); }, SRC); await page.waitForTimeout(150);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const S = () => page.evaluate(() => ({ sel: (() => { const v = FZ.app.st.tree.view; const k = FZ.app.st.tree.sel; const n = v && v.shown.find(n => (n.key || n.fig || n.obj || 'root') === k); return n ? n.text : null; })(), names: [...document.querySelectorAll('#tree .tn')].map(g => g.textContent) }));
  const box = text => page.evaluate(t => { const g = [...document.querySelectorAll('#tree .tn')].find(g => g.textContent === t || g.textContent.startsWith(t)); if (!g) return null; const r = g.querySelector('rect').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }, text);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80);
  await page.evaluate(() => FZ.app.run('tvd:-1')); await page.waitForTimeout(60); let r = await S();
  if (r.names.some(t => /段落（/.test(t)) || !r.names.includes('売上は伸びた。') || !r.names.includes('「本当か？」と問う。') || !r.names.includes('為替が重い。')) bad('sentence boxes inside the paragraph frame (no label)', r.names);
  r = await page.evaluate(() => document.getElementById('stMode') ? document.getElementById('stMode').textContent : document.querySelector('#status').textContent); if (!/文まで/.test(r)) bad('status shows the sentence depth', r);
  // 入れ替え（Alt+↓）
  let b = await box('売上は伸びた。'); await page.mouse.click(b.x + 20, b.y + 10); await page.keyboard.press('Alt+ArrowDown'); await page.waitForTimeout(60);
  r = await body(); if (!r.includes('海外が牽引した！売上は伸びた。「本当か？」と問う。')) bad('Alt+Down swaps sentences', r); r = await S(); if (r.sel !== '売上は伸びた。') bad('selection follows the moved sentence', r.sel);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 直す（Ctrl+Enter）
  b = await box('海外が牽引した！'); await page.mouse.click(b.x + 20, b.y + 10); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(40); await page.keyboard.press('Control+a'); await page.keyboard.type('海外が大きく伸びた'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  r = await body(); if (!r.includes('売上は伸びた。海外が大きく伸びた。「本当か？」')) bad('edit a sentence (period added)', r);
  // 足す（Enter）→ 打つ → Enter
  await page.keyboard.press('Enter'); await page.waitForTimeout(60); await page.keyboard.type('アジアが中心。'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  r = await body(); if (!r.includes('海外が大きく伸びた。アジアが中心。「本当か？」')) bad('add a sentence after', r);
  await page.keyboard.press('Enter'); await page.waitForTimeout(60); await page.keyboard.press('Escape'); await page.waitForTimeout(60); r = await body(); if (r.includes('新しい文')) bad('Esc cancels a new sentence', r);
  // 消す
  b = await box('アジアが中心。'); await page.mouse.click(b.x + 20, b.y + 10); await page.keyboard.press('Delete'); await page.waitForTimeout(60); r = await body(); if (r.includes('アジア') || !r.includes('海外が大きく伸びた。「本当か？」')) bad('delete a sentence', r);
  // 別の段落へドラッグ（「為替が重い。」の後ろへ）
  b = await box('売上は伸びた。'); const t = await box('為替が重い。'); await page.mouse.move(b.x + 20, b.y + 10); await page.mouse.down(); await page.mouse.move(t.x + 30, t.y + t.h * 0.8, { steps: 6 }); await page.waitForTimeout(30); await page.mouse.up(); await page.waitForTimeout(60);
  r = await body(); if (!r.includes('為替が重い。売上は伸びた。') || r.includes('\n売上は伸びた。海外')) bad('drag a sentence to another paragraph', r);
  // 独立した段落に（Alt+←）
  b = await box('「本当か？」と問う。'); await page.mouse.click(b.x + 20, b.y + 10); await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(60);
  r = await body(); if (!/海外が大きく伸びた。\n「本当か？」と問う。\n/.test(r)) bad('split a sentence into its own paragraph', r);
  console.log(`110e6 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
