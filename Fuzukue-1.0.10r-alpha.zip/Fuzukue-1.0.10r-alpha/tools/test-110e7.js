/* 1.0.10e.8：並べて表示（左にツリー、右に紙面）— 表示のプルダウン、ツリーで選ぶと紙面が追う（カーソル・スクロール・範囲の網）、紙面で動くとツリーが追う、押した側が操作の先、Esc で紙面へ、平文は段落を平らに */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 820 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const src = fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8'); await page.evaluate(async s => { await FZ.app.loadText(s, 'x.fzk', null); }, src); await page.waitForTimeout(200);
  const S = () => page.evaluate(() => ({ view: FZ.app.st.view, mode: FZ.app.st.mode, caret: FZ.app.ed.caret.line, sel: (() => { const v = FZ.app.st.tree.view; const n = v && v.shown.find(n => (n.key || n.fig || n.obj || 'root') === FZ.app.st.tree.sel); return n && n.text; })(), tree: getComputedStyle(document.getElementById('treePane')).display, pages: document.getElementById('pages').style.display, tw: document.getElementById('treePane').offsetWidth, mw: document.getElementById('main').offsetWidth, scroll: document.getElementById('main').scrollTop }));
  await page.selectOption('#viewSel', 'split'); await page.waitForTimeout(150); let r = await S();
  if (r.view !== 'split' || r.tree === 'none' || r.pages === 'none' || !(r.tw > 200 && r.mw > 400)) bad('split shows the tree and the paper', r);
  // ツリーで選ぶ → 紙面が追う
  const bx = await page.evaluate(() => { const g = [...document.querySelectorAll('#tree .tn')].find(g => g.textContent.includes('下期の重点施策')); const q = g.querySelector('rect').getBoundingClientRect(); return { x: q.left + 30, y: q.top + 10 }; });
  await page.mouse.click(bx.x, bx.y); await page.waitForTimeout(150); r = await S();
  const line = await page.evaluate(() => FZ.app.ed.doc.lines.findIndex(l => l.segs[0].text === '下期の重点施策'));
  if (r.mode !== 'tree' || r.caret !== line || !(r.scroll > 0)) bad('tree selection moves the paper caret and scroll', { r, line });
  r = await page.evaluate(() => document.querySelectorAll('#pages .ov rect').length); if (r < 3) bad('selected section is shaded on the paper', r);
  // 紙面を押す → 紙面が操作の先、カーソルを動かすとツリーが追う
  const pg = await page.evaluate(() => { const w = document.querySelectorAll('#pages .pgwrap')[0]; w.scrollIntoView(); const q = w.getBoundingClientRect(); return { x: q.left + q.width * 0.3, y: q.top + q.height * 0.42 }; });
  await page.mouse.click(pg.x, pg.y); await page.waitForTimeout(120); r = await S(); if (r.mode !== 'text' || r.view !== 'split') bad('clicking the paper focuses the paper', r);
  const before = r.sel; await page.keyboard.press('Control+Home'); await page.waitForTimeout(120); r = await S(); if (r.sel === before || !/2026年度|上期の売上/.test(r.sel || '')) bad('paper caret moves the tree selection', { before, after: r.sel });
  // 打った字は紙面に（並べたまま）
  await page.keyboard.press('End'); await page.keyboard.type('（速報）'); await page.waitForTimeout(120); r = await page.evaluate(() => [...document.querySelectorAll('#tree .tn')].some(g => g.textContent.includes('（速報）'))); if (!r) bad('typing on the paper updates the tree', r);
  // Ctrl+Shift+O は並べたまま側を替える、Esc でツリーから紙面へ
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); r = await S(); if (r.mode !== 'tree' || r.view !== 'split') bad('Ctrl+Shift+O switches the focus to the tree', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(80); r = await S(); if (r.mode !== 'text' || r.view !== 'split') bad('Esc goes back to the paper, still side by side', r);
  // 紙面だけ・ツリーだけ
  await page.selectOption('#viewSel', 'paper'); await page.waitForTimeout(80); r = await S(); if (r.view !== 'paper' || r.tree !== 'none') bad('back to paper only', r);
  await page.selectOption('#viewSel', 'tree'); await page.waitForTimeout(80); r = await S(); if (r.view !== 'tree' || r.mode !== 'tree' || r.pages !== 'none') bad('tree only', r);
  // 平文：段落が平らに出る
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n一つ目の段落。\n二つ目の段落。\n三つ目。\n', 'p.fzk', null); }); await page.waitForTimeout(120);
  r = await page.evaluate(() => [...document.querySelectorAll('#tree .tn')].map(g => g.textContent)); if (!(r.includes('一つ目の段落。') && r.includes('三つ目。'))) bad('plain paragraphs shown flat', r);
  console.log(`110e7 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
