/* 1.0.10e.9：段落と文のレベル管理 — 段落は文を収める枠（名札なし）、梯子（文→段落→見出し、段落→前の段落の文、文→箇条書き）、種類で文を取り出す、ばらす（文ごとの段落・箇条書き・親子）・まとめる、頁の境目と改頁 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。国内は横ばい。\n次の段落。\n[番号1]課題\n為替が重い。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const load = async () => { await page.evaluate(async src => { await FZ.app.loadText('#fzk 2\n---\n' + src, 'x.fzk', null); }, SRC); await page.waitForTimeout(100); };
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const box = text => page.evaluate(t => { const g = [...document.querySelectorAll('#tree .tn')].find(g => g.textContent === t || g.textContent.startsWith(t)); if (!g) return null; const r = g.querySelector('rect').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }, text);
  const pick = async t => { await page.waitForTimeout(550); const b = await box(t); if (!b) return false; await page.mouse.click(b.x + 20, b.y + 9); await page.waitForTimeout(30); return true; };
  await load(); await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); await page.evaluate(() => FZ.app.run('tvd:-1')); await page.waitForTimeout(60);
  // 1 枠：文の箱が段落の枠の中に（線でつながない）
  let r = await page.evaluate(() => { const v = FZ.app.st.tree.view; const para = v.shown.find(n => n.para); const s1 = v.shown.find(n => n.text === '売上は伸びた。'); const P = v.pos.get(para), Q = v.pos.get(s1); return { inside: Q.x > P.x && Q.y > P.y && Q.x + Q.w < P.x + P.w + 0.01 && Q.y + Q.h < P.y + P.h + 0.01, frames: document.querySelectorAll('#tree .tn.para').length, sents: document.querySelectorAll('#tree .tn.sent').length }; });
  if (!r.inside || r.frames !== 1 || r.sents !== 3) bad('sentences inside the paragraph frame', r);
  // 2 文 → 箇条書き（Alt+→）：段落をその文の前後で割る
  await pick('海外が牽引した。'); await page.keyboard.press('Alt+ArrowRight'); await page.waitForTimeout(60); r = await body();
  if (!/\n売上は伸びた。\n\[項目1\]海外が牽引した。\n国内は横ばい。\n次の段落。/.test(r)) bad('sentence demoted to a list item (paragraph split)', r); await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 3 文 → 段落（Alt+←）：その場で割る
  await pick('海外が牽引した。'); await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(60); r = await body();
  if (!/\n売上は伸びた。\n海外が牽引した。\n国内は横ばい。\n/.test(r)) bad('sentence promoted to its own paragraph in place', r);
  // 4 段落 → 見出し（Alt+←）：節の子の段
  await pick('海外が牽引した。'); await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(60); r = await body(); if (!/\[番号2\]海外が牽引した。/.test(r)) bad('paragraph promoted to a heading', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 5 段落 → 前の段落の文（Alt+→）
  await pick('海外が牽引した。'); await page.keyboard.press('Alt+ArrowRight'); await page.waitForTimeout(60); r = await body(); if (!/\n売上は伸びた。海外が牽引した。\n国内は横ばい。/.test(r)) bad('paragraph demoted into the previous paragraph', r);
  await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z'); await page.waitForTimeout(40); r = await body(); if (!/\n売上は伸びた。海外が牽引した。国内は横ばい。\n/.test(r)) bad('undo restores the paragraph', r);
  // 6 種類で文を取り出す（番号見出し）
  await pick('国内は横ばい。'); await page.selectOption('#tvKind', 'num'); await page.waitForTimeout(60); r = await body(); if (!/\n売上は伸びた。海外が牽引した。\n\[番号2\]国内は横ばい。\n次の段落。/.test(r)) bad('kind select extracts a sentence as a heading', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 7 ばらす：箇条書き・親子・文ごとの段落
  await pick('売上は伸びた。'); await page.selectOption('#tvRe', 'list'); await page.waitForTimeout(60); r = await body(); if (!/\[項目1\]売上は伸びた。\n\[項目1\]海外が牽引した。\n\[項目1\]国内は横ばい。/.test(r)) bad('explode into list items', r); await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  await pick('売上は伸びた。'); await page.selectOption('#tvRe', 'tree'); await page.waitForTimeout(60); r = await body(); if (!/\[項目1\]売上は伸びた。\n\[項目2\]海外が牽引した。\n\[項目2\]国内は横ばい。/.test(r)) bad('explode into parent and children', r);
  // 8 まとめる：親と子 → 1 つの段落
  await page.evaluate(() => FZ.app.run('tvd:9')); await page.waitForTimeout(40); await pick('・ 売上は伸びた。'); await page.selectOption('#tvRe', 'merge'); await page.waitForTimeout(60); r = await body(); if (!/\n売上は伸びた。海外が牽引した。国内は横ばい。\n次の段落。/.test(r)) bad('merge a node and its children into one paragraph', r);
  // 9 頁の境目と改頁
  r = await page.evaluate(() => [...document.querySelectorAll('#tree .tpg')].map(e => e.textContent)); if (!(r.length === 1 && /^P1/.test(r[0]))) bad('one-page document: only the P1 mark', r); /* 1.0.10p：頁の印は P1 から */
  await pick('2. 課題'); await page.click('#sub .ch[data-cmd="tv:break"]'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ n: document.querySelectorAll('#tree .tpg.forced').length, t: (document.querySelector('#tree .tpg.forced text') || {}).textContent, br: FZ.app.ed.doc.lines.find(l => l.segs[0].text === '課題').attrs.breakBefore })); if (r.n !== 1 || r.t !== 'P2' || !r.br) bad('page break from the tree shows the boundary', r);
  await page.click('#sub .ch[data-cmd="tv:break"]'); await page.waitForTimeout(60); r = await page.evaluate(() => document.querySelectorAll('#tree .tpg').length); if (r !== 1) bad('page break toggled off (only P1 left)', r);
  console.log(`110e8 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
