/* 1.0.10f：資料の表紙（柱なしの最初のページ）・表紙の頁番号・開始番号 */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; const fs = require('fs'); let fail = 0; const ok = (c, m) => { if (!c) { fail++; console.log('NG', m); } else console.log('ok', m); };
const base = fs.readFileSync(__dirname + '/../samples/資料見本.fzk', 'utf8');
const withCover = (extra) => FZ.parse(base.replace('---\n', extra + '---\n[表題]2026年度 上期 営業報告（表紙）\n営業企画部\n'));
const pn = p => p.head.glyphs.filter(g => g.w === 0.5 && g.line === -1 && /\d/.test(g.text) && g.sx === 1).map(g => g.text).join('');
{ const d0 = FZ.parse(base); const L0 = FZ.layout(d0); ok(!L0.cover && L0.pages.every(p => !p.cover), 'no cover by default');
  ok(L0.pages.map(pn).join(',') === L0.pages.map((_, i) => String(i + 1)).join(','), 'default numbering 1..');
  const d = withCover('表紙: あり\n開始番号: 0\n'); ok(d.format.cover && !d.format.coverNum && d.format.pageStart === 0, 'parse cover/start');
  const L = FZ.layout(d); ok(L.pages.length === L0.pages.length + 1, 'cover adds a page');
  ok(L.pages[0].cover && !L.pages.slice(1).some(p => p.cover), 'only first page is cover');
  ok(L.pages[0].head.glyphs.length === 0 && L.pages[0].head.rules.length === 0 && L.pages[0].head.boxes.length === 0, 'cover has no header');
  ok(L.pages[0].titleLine == null && L.coverTitle === 0, 'cover title stays in body');
  ok(L.lineMap[0].segs[0].rows.length && L.lineMap[0].segs[0].rows[0].page === 0 && L.lineMap[0].segs[0].rows[0].y >= 0, 'cover title placed on cover body');
  ok(L.pages[1].titleLine === 2, 'next title lifted to page 2 header');
  ok(L.pages.map(pn).join(',') === ['', '1', '2'].slice(0, L.pages.length).join(','), 'start 0: cover uncounted, body 1..');
  const s = FZ.serialize(d); ok(/表紙: あり/.test(s) && /開始番号: 0/.test(s), 'serialize');
  const d2 = FZ.parse(s); ok(d2.format.cover && d2.format.pageStart === 0, 'round trip');
  d.format.coverNum = true; let L2 = FZ.layout(d); ok(pn(L2.pages[0]) === '0' && L2.pages[0].head.boxes.length === 1 && L2.pages[0].head.rules.length === 0, 'coverNum shows only number');
  ok(/表紙: あり（頁番号も）/.test(FZ.serialize(d)) && FZ.parse(FZ.serialize(d)).format.coverNum, 'coverNum round trip');
  d.format.coverNum = false; d.format.pageStart = 5; L2 = FZ.layout(d); ok(L2.pages.map(pn).slice(1).join(',') === '6,7', 'start 5');
  /* 表題で始まらない表紙：題は引き上げず、最初の表題から柱 */
  const d3 = FZ.parse(base.replace('---\n', '表紙: あり\n---\n営業企画部\n\n')); const L3 = FZ.layout(d3); ok(L3.coverTitle === -1 && L3.pages[0].cover, 'cover without title line');
  /* pptx */
  d.format.pageStart = 0; const px = Buffer.from(FZ.toPptx(d)).toString('latin1');
  ok(/firstSlideNum="0"/.test(px), 'pptx firstSlideNum');
  const s1 = (px.match(/<p:sld [\s\S]*?<\/p:sld>/g) || [])[0] || ''; ok(s1 && !/ph type="title"/.test(s1) && !/機密表示/.test(s1), 'pptx cover slide has no header');
  ok(Buffer.from(s1, 'latin1').toString('utf8').includes('（表紙）'), 'pptx cover title in body');
  const s2x = (px.match(/<p:sld [\s\S]*?<\/p:sld>/g) || [])[1] || ''; ok(/ph type="title"/.test(s2x), 'pptx page 2 has header title');
  ok(!/sldNum/.test(s1), 'pptx cover: no slide number by default');
  d.format.coverNum = true; const px2 = Buffer.from(FZ.toPptx(d)).toString('latin1'); const c2 = (px2.match(/<p:sld [\s\S]*?<\/p:sld>/g) || [])[0]; ok(/sldNum/.test(c2) && !/ph type="title"/.test(c2), 'pptx coverNum');
  /* docx：開始番号 */
  const dx = Buffer.from(FZ.toDocx(d)).toString('utf8'); ok(/<w:pgMar[^>]*\/><w:pgNumType w:start="0"\/>/.test(dx), 'docx pgNumType after pgMar');
  const dx0 = Buffer.from(FZ.toDocx(d0)).toString('utf8'); ok(!/pgNumType/.test(dx0), 'docx default no pgNumType');
  /* 一般文書でも開始番号は {page} に効く */
  const g = FZ.parse('#fzk 2\n柱下: - {page} -\n柱行: 0 1\n開始番号: 3\n---\n本文\n'); ok(g.format.pageStart === 3, 'pageStart in plain doc');
  const Lg = FZ.layout(g); const ft = (Lg.pages[0].hf || []).map(x => x.text).join(''); ok(/- 3 -/.test(ft), 'plain doc footer uses start: ' + ft.slice(-12));
}
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
