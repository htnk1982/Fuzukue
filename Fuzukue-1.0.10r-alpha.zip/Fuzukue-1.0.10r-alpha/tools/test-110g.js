/* 1.0.10g：グラフ（図版の一種）— データモデル・原本・組版・描画・Markdown／TXT・Word／PowerPoint の編集できるグラフ */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-render', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fail = 0; const ok = (c, m, info) => { if (!c) { fail++; console.log('NG', m, info !== undefined ? JSON.stringify(info).slice(0, 300) : ''); } else console.log('ok', m); };
const CH = '#グラフ g1 図 棒 75% 売上の推移\n#データ | 年度 | 2023 | 2024 | 2025 |\n#データ | 国内 | 120 | 135 | 1,500.5 |\n#データ | 海外 | 80 | △5 |  |\n#グラフ設定 単位=億円 凡例=右 値=なし 縦横=75 網=濃,白\n';
const SRC = '#fzk 2\n---\n[表題]報告\n本文。\n' + CH + '次の行\n';
const d = FZ.parse(SRC); const fg = d.lines[1].attrs.figs && d.lines[1].attrs.figs[0];
ok(fg && fg.chart && fg.file === '' && fg.width === 75 && fg.title === '売上の推移', 'parse: chart fig on previous line', fg);
const c = fg.chart;
ok(c.type === 'bar' && c.corner === '年度' && c.cats.join() === '2023,2024,2025' && c.series.length === 2, 'parse: cats/series');
ok(c.series[0].values[2] === 1500.5 && c.series[1].values[1] === -5 && c.series[1].values[2] === null, 'numbers: comma, △ negative, blank null', c.series.map(s => s.values));
ok(c.unit === '億円' && c.legend === 'right' && c.labels === false && Math.abs(c.ratio - 0.75) < 1e-9 && c.series[0].shade === 'dark' && c.series[1].shade === 'none', 'options');
const s1 = FZ.serialize(d); ok(s1.includes(CH.split('\n')[0]) && /#グラフ設定 単位=億円 凡例=右 値=なし 縦横=75 網=濃,白/.test(s1), 'serialize', s1.split('---\n')[1]);
ok(FZ.serialize(FZ.parse(s1)) === s1, 'round trip stable');
ok(d.lines[2].segs[0].text === '次の行' && !d.lines[2].attrs.figs, 'next line untouched');
/* 表 → グラフ（見出しの行・列の判定と向き） */
const g1 = FZ.chartFromGrid([['', '東', '西'], ['売上', '10', '20'], ['利益', '1', '2']]); ok(g1.cats.join() === '東,西' && g1.series.map(s => s.name).join() === '売上,利益', 'grid: rows are series when rows<=cols', g1);
const g2 = FZ.chartFromGrid([['月', '件数'], ['1月', '3'], ['2月', '5'], ['3月', '4']]); ok(g2.cats.join() === '1月,2月,3月' && g2.series.length === 1 && g2.series[0].name === '件数' && g2.corner === '月', 'grid: long table -> columns are series', g2);
ok(FZ.chartable([['a', '1'], ['b', '2']]) && !FZ.chartable([['a', 'b'], ['c', 'd']]), 'chartable');
const tr = FZ.chartTranspose(g1); ok(tr.cats.join() === '売上,利益' && tr.series[0].values.join() === '10,1', 'transpose');
/* 組版：縦横の比で高さ、ページの図版にデータ */
const L = FZ.layout(d); const im = L.pages[0].images[0]; ok(im && im.chart === c, 'layout: page image carries chart');
ok(Math.abs(im.h - Math.round(im.w * L.geo.cw * 0.75 / L.geo.ch)) <= 1, 'layout: height from ratio', [im.w, im.h]);
const svg = FZ.renderPage(L, 0, {}); ok(/class="figimg figchart"/.test(svg) && /<g class="chart"/.test(svg) && !/（画像なし）/.test(svg), 'render: chart group');
ok(/url\(#s_dark_0\)/.test(svg), 'render: series pattern fill');
/* 種類ごとに描ける */
for (const [t] of FZ.CHART_TYPES) { const cc = FZ.normalizeChart({ ...c, type: t, labels: true }); const S = FZ.chartShapes(cc, 300, 180, 10.5); ok(S.some(x => x.hit), 'shapes: ' + t); }
const pie = FZ.normalizeChart({ type: 'pie', cats: ['A', 'B', 'C', 'D'], series: [{ name: 'x', values: [50, 30, 15, 5] }] }); const ps = FZ.chartSvg(pie, 0, 0, 300, 180, { F: { dark: 'url(#a)', none: '#fff', mid: 'url(#m)', hatch: 'url(#h)', dots: 'url(#d)' }, uid: 'u' });
ok(/<clipPath id="u_w0">/.test(ps) && /clip-path="url\(#u_w0\)"/.test(ps), 'pie: pattern wedges are clipped rects (printable)');
const smallPie = FZ.chartShapes(pie, 120, 72, 10.5); ok(smallPie.some(x => x.leg) && smallPie.filter(x => x.t === 'text').some(x => /^A 50%$/.test(x.text)), 'pie: list mode when small');
const hit = FZ.chartHit(FZ.normalizeChart({ ...c, labels: true }), 300, 180, 10.5, ...(() => { const r = FZ.chartShapes(FZ.normalizeChart({ ...c, labels: true }), 300, 180, 10.5).find(x => x.t === 'rect' && x.hit); return [r.x + r.w / 2, r.y + r.h / 2]; })()); ok(hit && hit.s === 0 && hit.j === 0, 'hit test', hit);
/* Markdown：注記＋表、読み込みでグラフに戻る（直前の「図 1　題」は題に） */
const md = FZ.toGfm(d); ok(/<!-- グラフ：棒 単位=億円 凡例=右 値=なし 縦横=75 網=濃,白 -->\n\| 年度 \| 2023 \| 2024 \| 2025 \|\n\| --- \| ---: \| ---: \| ---: \|/.test(md), 'gfm: note + table', md);
const d2 = FZ.fromGfm(md); const f2 = d2.lines.flatMap(l => l.attrs.figs || []); ok(f2.length === 1 && f2[0].chart && f2[0].title === '売上の推移' && f2[0].kind === '図', 'gfm import: chart with title', f2);
const c2 = f2[0].chart; ok(c2.type === 'bar' && c2.unit === '億円' && c2.legend === 'right' && !c2.labels && c2.ratio === 0.75 && c2.series[0].shade === 'dark' && c2.series[1].values[1] === -5, 'gfm import: options and data', c2);
ok(!d2.lines.some(l => /図 1/.test(l.segs.map(s => s.text).join(''))), 'gfm import: caption line absorbed');
ok(d2.lines.some(l => l.segs[0].text === '次の行'), 'gfm import: following text kept');
/* TXT：題とデータ（タブ区切り） */
const tx = FZ.toPlain(d); ok(/図 1　売上の推移\n年度\t2023\t2024\t2025\n国内\t120\t135\t1500.5/.test(tx), 'txt: caption + TSV', tx);
/* Word：編集できるグラフ＋埋め込みの Excel */
const dxf = FZ.toDocx(d, { files: true }); const dn = dxf.map(x => x.name); const txt = n => { const x = dxf.find(y => y.name === n); return x ? (typeof x.data === 'string' ? x.data : Buffer.from(x.data).toString('utf8')) : ''; };
ok(dn.includes('word/charts/chart1.xml') && dn.includes('word/charts/_rels/chart1.xml.rels') && dn.includes('word/embeddings/Microsoft_Excel_Worksheet1.xlsx'), 'docx: chart parts', dn);
ok(/graphicData uri="http:\/\/schemas.openxmlformats.org\/drawingml\/2006\/chart"><c:chart [^>]*r:id="rIdC1"/.test(txt('word/document.xml')), 'docx: inline chart frame');
ok(/Id="rIdC1"[^>]*relationships\/chart" Target="charts\/chart1.xml"/.test(txt('word/_rels/document.xml.rels')) && /Override PartName="\/word\/charts\/chart1.xml"/.test(txt('[Content_Types].xml')) && /Default Extension="xlsx"/.test(txt('[Content_Types].xml')), 'docx: rels and content types');
const cx = txt('word/charts/chart1.xml'); ok(/<c:barChart><c:barDir val="col"\/><c:grouping val="clustered"\/>/.test(cx) && /<c:legendPos val="r"\/>/.test(cx) && !/<c:dLbls>/.test(cx) && /<c:externalData r:id="rId1">/.test(cx), 'docx: chart xml (bar, legend right, no labels, data link)');
ok(/<a:solidFill><a:srgbClr val="000000"\/><\/a:solidFill>/.test(cx) && /<c:v>国内<\/c:v>/.test(cx) && /<c:v>1500.5<\/c:v>/.test(cx), 'docx: series fill and cache');
/* PowerPoint（資料）：スライドのグラフ枠 */
const ds = FZ.parse(SRC.replace('---\n', '用紙: A4 横\n文字数: 60\n行数: 26\n柱行: 2 0\n書式: 資料\n本文幅: 60%\n---\n'));
const pf = FZ.toPptx(ds, { files: true }); const pn = pf.map(x => x.name); const ptx = n => { const x = pf.find(y => y.name === n); return x ? (typeof x.data === 'string' ? x.data : Buffer.from(x.data).toString('utf8')) : ''; };
ok(pn.includes('ppt/charts/chart1.xml') && pn.includes('ppt/embeddings/Microsoft_Excel_Worksheet1.xlsx'), 'pptx: chart parts', pn.filter(n => /chart|embed/.test(n)));
ok(/<p:graphicFrame>[\s\S]*?name="図 1"[\s\S]*?r:id="rIdC1"/.test(ptx('ppt/slides/slide1.xml')) && /Id="rIdC1"[^>]*relationships\/chart" Target="..\/charts\/chart1.xml"/.test(ptx('ppt/slides/_rels/slide1.xml.rels')), 'pptx: graphic frame and slide rel');
ok(/Override PartName="\/ppt\/charts\/chart1.xml"/.test(ptx('[Content_Types].xml')), 'pptx: content type');
/* 円の Office 出力：率の書式・凡例と名前 */
const pxml = FZ.chartXml(pie); ok(/<c:pieChart>/.test(pxml) && /formatCode="0%"/.test(pxml) && /<c:showCatName val="1"\/>/.test(pxml) && /<c:dLblPos val="bestFit"\/>/.test(pxml), 'office pie: percent format, names, best fit');
/* 帯：構成比で書き出す */
const band = FZ.normalizeChart({ type: 'band', cats: ['x'], series: [{ name: 'a', values: [30] }, { name: 'b', values: [70] }] }); ok(/percentStacked/.test(FZ.chartXml(band)) && /<c:v>0.3<\/c:v>/.test(FZ.chartXml(band)), 'office band: percent stacked of shares');
/* 見本（資料見本）はグラフをデータで持つ */
const smp = FZ.parse(require('fs').readFileSync(__dirname + '/../samples/資料見本.fzk', 'utf8')); const sf = smp.lines.flatMap(l => l.attrs.figs || []); ok(sf.filter(x => x.chart).length === 3 && sf.some(x => x.file === 'photo.jpg'), 'sample uses native charts');
/* 編集：図版の追加・変更・取消 */
const ed = new FZ.Editor(); ed.setDoc(FZ.parse('#fzk 2\n---\n一行目\n'));
const id = ed.addFigure({ kind: '図', title: 't', chart: FZ.chartSample() }); ok(ed.figById(id).fg.chart.series.length === 2, 'editor: add chart');
ed.setFig(id, { chart: FZ.normalizeChart({ ...ed.figById(id).fg.chart, type: 'line' }) }); ok(ed.figById(id).fg.chart.type === 'line', 'editor: set chart'); ed.undo(); ok(ed.figById(id).fg.chart.type === 'bar', 'editor: undo');
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
