/* 1.0.10h：段階 3b — ツリーで探す（G3）、紙面の範囲とツリーの複数選択をつなぐ（G2）、節と子から構成図（R3） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。\n[項目1]国内は横ばい\n[項目1]海外は伸びた\n[番号1]課題\n為替が重い。\n[番号2]対策\n[項目1]為替予約\n[項目1]現地生産\n[番号2]海外の人材\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const load = async () => { await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, SRC); await page.waitForTimeout(120); };
  const onText = () => page.evaluate(() => { const e = document.querySelector('#tree .tn.on'); return e ? e.textContent : null; });
  await load();
  /* G3：ツリーで探す */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => FZ.app.run('tvd:1')); await page.waitForTimeout(60);
  await page.keyboard.press('Control+f'); await page.waitForTimeout(80); let r = await page.evaluate(() => ({ f: FZ.app.st.form, m: FZ.app.st.mode })); if (!(r.f === 'tfind' && r.m === 'tree')) bad('Ctrl+F in tree opens tree search (stays in tree)', r);
  await page.keyboard.type('海外'); await page.waitForTimeout(120); r = await page.evaluate(() => ({ n: document.querySelectorAll('#tree .tn.hit').length, info: document.querySelector('.tfinfo').textContent }));
  if (!(r.info === '3 件')) bad('hit count over all nodes', r);
  await page.keyboard.press('Enter'); await page.waitForTimeout(120); r = { t: await onText(), d: await page.evaluate(() => FZ.app.st.tree.depth), info: await page.evaluate(() => document.querySelector('.tfinfo').textContent) };
  if (!(r.t && r.t.includes('海外が牽引') && r.d === 0 && r.info === '1/3 件')) bad('Enter goes to the first hit (body: depth opens to 本文)', r);
  await page.keyboard.press('Enter'); await page.waitForTimeout(100); r = await onText(); if (!(r && r.includes('海外は伸びた'))) bad('Enter goes to the next hit', r);
  await page.keyboard.press('Shift+Enter'); await page.waitForTimeout(100); r = await onText(); if (!(r && r.includes('海外が牽引'))) bad('Shift+Enter goes back', r);
  r = await page.evaluate(() => document.querySelectorAll('#tree .tn.hit').length); if (r < 3) bad('hits marked in the tree', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(80); r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#tree .tn.hit').length, m: FZ.app.st.mode })); if (r.f || r.n || r.m !== 'tree') bad('Esc closes search and clears marks', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(100);
  /* G2：並べる。紙面の範囲 → ツリーに印、ツリーへ移ると複数選択。ツリーの複数選択 → 紙面に網 */
  await page.selectOption('#viewSel', 'split'); await page.waitForTimeout(200); if (await page.evaluate(() => FZ.app.st.mode === 'tree')) { await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(120); } await page.evaluate(() => FZ.app.run('tvd:9')); await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 3, seg: 0, off: 0 }); ed.setCaret({ line: 4, seg: 0, off: 2 }, true); }); await page.waitForTimeout(150);
  await page.evaluate(() => { FZ.app.render(); }); await page.waitForTimeout(100);
  r = await page.evaluate(() => document.querySelectorAll('#tree .tpsel').length); if (r !== 2) bad('paper range marks 2 nodes in the tree', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); r = await page.evaluate(() => ({ m: FZ.app.st.mode, n: FZ.app.st.tree.multi.size, on: document.querySelectorAll('#tree .tn.on').length })); if (!(r.m === 'tree' && r.n === 2 && r.on === 2)) bad('entering the tree selects the range nodes', r);
  await page.waitForTimeout(100); r = await page.evaluate(() => document.querySelectorAll('.pg .ov rect').length); if (r < 2) bad('tree multi-selection shaded on paper', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(100); await page.selectOption('#viewSel', 'paper'); await page.waitForTimeout(150);
  /* R3：構成図 */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 5, seg: 0, off: 0 })); await page.keyboard.press('F7'); await page.keyboard.press('r'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ f: FZ.app.st.form, info: document.querySelector('#sub .info').textContent })); if (!(r.f === 'figtree' && r.info.includes('課題'))) bad('F7→R opens figure-from-structure form for the caret section', r);
  await page.keyboard.press('1'); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const i = d.lines.findIndex(l => l.attrs.figure); if (i < 0) return null; const F = d.lines[i].attrs.figure; return { i, n: F.boxes.length, a: F.arrows.length, texts: F.boxes.map(b => b.text), W: Math.max(...F.boxes.map(b => b.x + b.w)), h: F.h }; });
  if (!(r && r.i === 11 && r.n === 5 && r.a === 4 && r.texts[0] === '課題' && r.texts.includes('為替予約') && r.texts.includes('海外の人材'))) bad('structure figure: section + children + grandchildren after the section', r);
  if (r && r.W > 40) bad('figure fits the column', r);
  r = await page.evaluate(() => { const F = FZ.app.ed.doc.lines.find(l => l.attrs.figure).attrs.figure; const B = id => F.boxes.find(b => b.id === id); return F.arrows.every(a => B(a.from).x < B(a.to).x); }); if (!r) bad('left-to-right: parents left of children');
  await page.keyboard.press('Control+z'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.ed.doc.lines.some(l => l.attrs.figure)); if (r) bad('undo removes the figure');
  /* 上から下へ（ツリーから）、子の無い節は断る */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '対策'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); });
  await page.evaluate(() => FZ.app.run('figTree')); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.st.form); if (r !== 'figtree') bad('figTree form in tree', r);
  await page.keyboard.press('2'); await page.waitForTimeout(150); r = await page.evaluate(() => { const d = FZ.app.ed.doc; const i = d.lines.findIndex(l => l.attrs.figure); if (i < 0) return null; const F = d.lines[i].attrs.figure; const B = id => F.boxes.find(b => b.id === id); return { mode: FZ.app.st.mode, n: F.boxes.length, td: F.arrows.every(a => B(a.from).y < B(a.to).y) }; });
  if (!(r && r.mode === 'tree' && r.n === 3 && r.td)) bad('top-down structure figure from the tree', r);
  await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '海外の人材'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); FZ.app.openForm('figtree'); }); await page.keyboard.press('1'); await page.waitForTimeout(100);
  r = await page.evaluate(() => FZ.app.st.msg); if (!/子.*ありません/.test(r)) bad('node without children refuses', r);
  console.log('110h2 fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
