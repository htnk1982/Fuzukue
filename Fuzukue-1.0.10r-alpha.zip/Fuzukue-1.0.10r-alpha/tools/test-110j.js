/* 1.0.10j：構造のままの PowerPoint（X4）とツリーの見た目の書き出し（X1）— 型・頁割り・部品。画面からの書き出しも */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-render', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-tree', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx', 'fz-pptx2']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, fs = require('fs'), path = require('path'); let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 300) : ''); } else console.log('ok', m); };
const txt = (files, n) => { const x = files.find(y => y.name === n); return x ? (typeof x.data === 'string' ? x.data : Buffer.from(x.data).toString('utf8')) : ''; };
/* X4：資料見本（表題ごと） */
{ const d = FZ.parse(fs.readFileSync(path.join(__dirname, '../samples/資料見本.fzk'), 'utf8')); const F = FZ.toPptxOutline(d, { files: true }); const names = F.map(x => x.name);
  const slides = names.filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n)); ok(slides.length === 3, 'outline: cover + one slide per 表題', slides.length);
  const s1 = txt(F, 'ppt/slides/slide1.xml'), s2 = txt(F, 'ppt/slides/slide2.xml'), s3 = txt(F, 'ppt/slides/slide3.xml');
  ok(/type="ctrTitle"/.test(s1) && s1.includes('2026年度 上期 営業報告') && s1.includes('営業企画部'), 'cover: doc title and author');
  ok(/<p:ph type="title"\/>/.test(s2) && s2.includes('上期の売上は前年比 3% 増、海外が牽引'), 'slide title placeholder');
  ok(/<a:pPr lvl="0"[^>]*>(<a:buNone\/>)?<\/a:pPr><a:r><a:rPr[^>]*b="1"[^>]*>.*?<a:t>概況<\/a:t>/.test(s2) && /<a:pPr lvl="1"[^>]*><\/a:pPr><a:r>.*?<a:t>国内：主力/.test(s2), 'headings level 0 bold, list items level 1');
  ok(/<a:pPr lvl="1" indent="0"><a:buNone\/><\/a:pPr><a:r>.*?<a:t>上期の売上高は/.test(s2), 'body paragraph without bullet at its level');
  ok(/graphicData uri="http:\/\/schemas.openxmlformats.org\/drawingml\/2006\/chart"/.test(s2) && /graphicData uri=".*chart"/.test(s3), 'first figure (chart) on the right');
  ok(/Target="..\/charts\/chart1.xml"/.test(txt(F, 'ppt/slides/_rels/slide2.xml.rels')) && names.includes('ppt/embeddings/Microsoft_Excel_Worksheet1.xlsx'), 'chart parts and rels');
  ok(/slideLayout2.xml/.test(txt(F, 'ppt/slides/_rels/slide2.xml.rels')) && /slideLayout1.xml/.test(txt(F, 'ppt/slides/_rels/slide1.xml.rels')), 'layouts: title / title and content');
  ok(/<p:ph type="body" idx="1"\/>/.test(txt(F, 'ppt/slideMasters/slideMaster1.xml')) && /<a:lvl2pPr/.test(txt(F, 'ppt/slideMasters/slideMaster1.xml')), 'master has body placeholder with levels'); }
/* X4：見本（見出しごと、表は右、題の前の本文は「概要」） */
{ const d = FZ.parse(fs.readFileSync(path.join(__dirname, '../samples/見本.fzk'), 'utf8')); const F = FZ.toPptxOutline(d, { files: true }); const all = F.filter(x => /slides\/slide\d+\.xml$/.test(x.name)).map(x => txt(F, x.name));
  ok(all.length >= 6, 'outline: one slide per top heading', all.length); ok(all.some(s => /<a:t>概要<\/a:t>/.test(s)), 'lead text slide titled 概要');
  ok(all.some(s => /graphicData uri="http:\/\/schemas.openxmlformats.org\/drawingml\/2006\/table"><a:tbl>/.test(s)), 'table as a PowerPoint table');
  const F2 = FZ.toPptxOutline(d, { files: true, level: 2 }); ok(F2.filter(x => /slides\/slide\d+\.xml$/.test(x.name)).length > all.length, 'level 2 makes more slides'); }
/* X1：頁割り（節を途中で切らない） */
{ const nodes = []; for (let k = 0; k < 60; k++) nodes.push({ x: (k % 3) * 28, y: k * 34, w: 300, h: 28 + (k % 5), lines: ['節 ' + k], head: k === 0 }); const edges = [{ pts: [[14, 28], [14, 2000]] }];
  const m = { nodes, edges, W: 400, H: 60 * 34 }; const P = FZ.treePages(m, 595, 842, 36); ok(P.pages.length >= 2, 'tree pages', P.pages.length);
  const uh = 842 - 72; let cut = 0; for (const pg of P.pages) for (const n of nodes) { if (n.y >= pg.y0 - 0.5 && n.y < pg.y1 - 0.5) { if ((n.y + n.h - pg.y0) * P.k > uh + 1) cut++; } } ok(!cut, 'no node crosses a page end', cut);
  ok(nodes.every(n => P.pages.filter(pg => n.y >= pg.y0 - 0.5 && n.y < pg.y1 - 0.5).length === 1), 'each node on exactly one page');
  const svgs = FZ.treePageSvgs(m, 595, 842); ok(svgs.length === P.pages.length && svgs.every(s => /^<svg /.test(s)) && /1\/\d/.test(svgs[0]), 'page SVGs with page numbers');
  const T = FZ.treeToPptx(m, { files: true }); const sl = T.filter(x => /slides\/slide\d+\.xml$/.test(x.name)); ok(sl.length >= 2 && /<p:cxnSp>/.test(txt(T, 'ppt/slides/slide1.xml')) && /prst="roundRect"/.test(txt(T, 'ppt/slides/slide1.xml')), 'tree PowerPoint: boxes and connector lines'); }
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
