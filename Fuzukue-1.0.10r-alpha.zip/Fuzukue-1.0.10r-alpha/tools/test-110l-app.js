/* 1.0.10l：画面 — 節の参照（F7→S）、構成の型（F7→U：カーソルの後ろに・新しい文書で・霞が関の体系） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n[表題]報告\n[番号1]概況\n本文。\n[番号1]課題\n[番号2]為替\n詳しくは\n', 'x.fzk', null); }); await page.waitForTimeout(150);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const lineText = i => page.evaluate(i => FZ.app.ed.lay.lineMap[i].segs[0].rows.map(r => r.glyphs.map(g => g.text).join('')).join(''), i);
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 5, seg: 0, off: 4 })); await page.keyboard.press('F7'); await page.keyboard.press('s'); await page.waitForTimeout(80);
  let r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#sub .mv').length })); if (!(r.f === 'secref' && r.n === 4)) bad('F7→S lists headings', r);
  await page.keyboard.type('為替'); await page.keyboard.press('Enter'); await page.waitForTimeout(100); r = await body(); if (!/\[番号2 節:h1\]為替/.test(r) || !r.includes('詳しくは<図番 §h1>')) bad('anchor and ref inserted', r);
  r = await lineText(5); if (r !== '詳しくは2（1）為替') bad('paper shows label', r);
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 })); await page.keyboard.press('Alt+ArrowDown'); await page.waitForTimeout(100);
  r = await page.evaluate(() => { const i = FZ.app.ed.doc.lines.findIndex(l => FZ.hasRefs(l.segs[0].text)); return FZ.app.ed.lay.lineMap[i].segs[0].rows.map(x => x.glyphs.map(g => g.text).join('')).join(''); }); if (r !== '詳しくは1（1）為替') bad('label follows the moved section', r);
  /* 見出しを消すと「節 ?」 */
  await page.evaluate(() => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.attrs.anchor); ed.mutate('', () => { delete ed.doc.lines[i].attrs.anchor; }); }); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const i = FZ.app.ed.doc.lines.findIndex(l => FZ.hasRefs(l.segs[0].text)); return FZ.app.ed.lay.lineMap[i].segs[0].rows.map(x => x.glyphs.map(g => g.text).join('')).join(''); }); if (r !== '詳しくは節 ?') bad('missing section shows 節 ?', r);
  /* 構成の型：カーソルの後ろに（題のある文書では題の行を除く） */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 })); await page.keyboard.press('F7'); await page.keyboard.press('u'); await page.waitForTimeout(80); r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#sub button[data-act^=t]').length, k: document.querySelectorAll('#sub button.kasumi').length }));
  if (!(r.f === 'skeleton' && r.n === 8 && r.k === 4)) bad('skeleton form with 4 Kasumigaseki types', r);
  await page.keyboard.press('1'); await page.waitForTimeout(120); r = await body(); if (!(/^\[表題\]報告\n\[番号1\]目的\n（何を報告し/.test(r) && (r.match(/\[表題\]/g) || []).length === 1)) bad('report skeleton after caret, no second title', r.slice(0, 160));
  await page.keyboard.press('Control+z'); await page.waitForTimeout(80);
  /* 新しい文書で（霞が関） */
  await page.evaluate(() => { FZ.app.ed.dirty = false; }); await page.keyboard.press('F7'); await page.keyboard.press('u'); await page.waitForTimeout(80); await page.selectOption('#sub select[name="where"]', 'new'); await page.focus('#sub button[data-act="t4"]'); await page.keyboard.press('5'); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ b: FZ.serialize(FZ.app.ed.doc).split('---\n')[1], bu: FZ.normalizeScheme(FZ.app.ed.doc.format.bulletScheme)[0], sym: FZ.normalizeScheme(FZ.app.ed.doc.format.symScheme)[0], n: FZ.normalizeScheme(FZ.app.ed.doc.format.scheme)[1] }));
  if (!(/^\[表題\]〇〇について（案）\n\[番号1\]背景・経緯/.test(r.b) && r.bu === '○' && r.sym === '【】' && r.n === '（1）')) bad('Kasumigaseki one-pager in a new doc with its scheme', r);
  r = await lineText(4); if (!/^【現状】$/.test(r)) bad('sym heading drawn as 【】', r);
  console.log('110l-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
