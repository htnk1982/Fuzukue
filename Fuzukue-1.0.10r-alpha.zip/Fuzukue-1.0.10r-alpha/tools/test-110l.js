/* 1.0.10l：節の参照（S5）と構成の型（S6・霞が関） */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 300) : ''); } else console.log('ok', m); };
const d = FZ.parse('#fzk 2\n---\n[表題]報告\n[番号1 節:h1]概況\n本文 <図番 §h2> と <図番 §h3>、<図番 §zz> を参照。\n[番号1]課題\n[番号2 節:h2]為替\n[番号3 節:h4]円安\n[記号1 節:h3]補足\n[番号1 節:h2]重複\n');
const N = FZ.figureNumbers(d); ok(N.get('§h1').label === '1. 概況' && N.get('§h2').label === '2（1）為替' && N.get('§h4').label === '2（1）① 円安' && N.get('§h3').label === '「補足」', 'labels: number + title, parents in front, others in brackets', [...N.entries()].map(([k, v]) => k + '=' + v.label));
ok(!d.lines[7].attrs.anchor && d.lines[4].attrs.anchor === 'h2', 'duplicate anchor dropped on load (first wins)');
const t = FZ.expandRefsText(d, d.lines[2].segs[0].text); ok(t === '本文 2（1）為替 と 「補足」、節 ? を参照。', 'expanded text (unknown → 節 ?)', t);
const L = FZ.layout(d); ok(L.lineMap[2].segs[0].rows.map(r => r.glyphs.map(g => g.text).join('')).join('').includes('2（1）為替'), 'layout shows label');
const s = FZ.serialize(d); ok(/\[番号2 節:h2\]為替/.test(s) && s.includes('<図番 §h2>'), 'serialize anchors and refs'); ok(FZ.serialize(FZ.parse(s)) === s, 'round trip');
/* 並べ替えに追う */
const ed = new FZ.Editor(); ed.setDoc(FZ.parse(s)); ed.moveSection(3, -1); const N2 = FZ.figureNumbers(ed.doc); ok(N2.get('§h2').label === '1（1）為替' && N2.get('§h1').label === '2. 概況', 'labels follow reorder', [N2.get('§h2').label, N2.get('§h1').label]);
ok(FZ.toGfm(ed.doc).includes('1（1）為替'), 'Markdown gets the text'); { const x = FZ.toDocx(ed.doc, { files: true }).find(f => f.name === 'word/document.xml').data; const tx = (x.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(t => t.replace(/<[^>]+>/g, '')).join('').replace(/\s+/g, ''); ok(tx.includes('1（1）為替'), 'Word gets the text'); }
/* 霞が関の体系 */
const K = FZ.SCHEME_PRESETS.find(p => p.name === '霞が関'); ok(K && K.num[0] === '1.' && K.bullet[0] === '○' && K.sym[0] === '【】', 'Kasumigaseki preset');
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
