/* 1.0.10m：画面 — 保留へ送る（紙面の節・文・範囲、ツリーの節）、保留の島（戻す・消す）、取り消し、帯の数 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。\n[番号1]課題\n為替が重い。\n[番号1]対策\n[項目1]予約\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, SRC); await page.waitForTimeout(150);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const parked = () => page.evaluate(() => (FZ.app.ed.doc.parked || []).map(p => p.label + ':' + p.lines.length));
  /* 節（カーソル）を送る */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 })); await page.keyboard.press('F3'); await page.keyboard.press('p'); await page.waitForTimeout(100);
  let r = await body(); if (/課題|為替/.test(r.split('#保留')[0])) bad('section removed from the document', r); r = await parked(); if (r.join() !== '課題:2') bad('section parked with its body', r);
  /* 文（Ctrl+クリック相当）を送る */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 2, seg: 0, off: 9 }); FZ.app.run('selSent'); FZ.app.run('park'); }); await page.waitForTimeout(100);
  r = await page.evaluate(() => FZ.app.ed.doc.lines[2].segs[0].text); if (r !== '売上は伸びた。') bad('sentence removed', r); r = await parked(); if (r.join() !== '課題:2,海外が牽引した。:1') bad('sentence parked', r);
  /* 保留の島：戻す（カーソルの節の後ろ）・消す */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 })); await page.keyboard.press('F3'); await page.keyboard.press('o'); await page.waitForTimeout(80); r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#island .isl').length })); if (!(r.f === 'parked' && r.n === 2)) bad('island lists 2 (full text at the bottom)', r);
  await page.click('#island button[data-isl="b0"]'); await page.waitForTimeout(100); r = await body(); if (!/\[番号1\]概況\n売上は伸びた。\n\[番号1\]課題\n為替が重い。\n\[番号1\]対策/.test(r)) bad('put back after the caret section', r);
  r = await page.evaluate(() => document.querySelectorAll('#island .isl').length); if (r !== 1) bad('island refreshed', r);
  await page.click('#island button[data-isl="x0"]'); await page.waitForTimeout(80); r = await parked(); if (r.length) bad('removed from island', r);
  await page.keyboard.press('Escape'); await page.keyboard.press('Control+z'); await page.waitForTimeout(80); r = await parked(); if (r.join() !== '海外が牽引した。:1') bad('undo brings it back', r);
  /* 保存の往復 */
  r = await page.evaluate(() => { const s = FZ.serialize(FZ.app.ed.doc); const d = FZ.parse(s); return { has: /#保留 p\d+ 海外が牽引した。/.test(s), back: (d.parked || []).length }; }); if (!(r.has && r.back === 1)) bad('saved in the file', r);
  /* ツリー：選んだ節を送る、帯に数 */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '対策'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); FZ.app.drawSub(); });
  await page.evaluate(() => FZ.app.run('park')); await page.waitForTimeout(120); r = await body(); if (/\[番号1\]対策/.test(r.split('#保留')[0])) bad('tree node parked', r);
  r = await page.evaluate(() => { const e = document.querySelector('#sub .pkn'); return e ? e.textContent : null; }); if (r !== '保留 2') bad('tree band shows island count', r);
  r = await page.evaluate(() => FZ.toGfm(FZ.app.ed.doc)); if (/対策|海外が牽引/.test(r)) bad('parked not in Markdown', r);
  await page.keyboard.press('Control+Shift+O');
  console.log('110m-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
