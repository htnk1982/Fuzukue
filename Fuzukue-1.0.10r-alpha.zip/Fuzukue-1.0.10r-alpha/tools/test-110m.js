/* 1.0.10m：保留の島（S4）— 原本の書き方・往復・参照の字・書き出しに出ない、画面で送る・戻す・消す・取り消し */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 300) : ''); } else console.log('ok', m); };
const SRC = '#fzk 2\n文字数: 30\n---\n[表題]報告\n[番号1]概況\n本文\n#保留 p1 古い案\n[番号1]旧案\n詳しくは<図番 a>。\n[項目1]項目\n#保留ここまで\n#図版 a 図 写真 -\n';
const d = FZ.parse(SRC); ok(d.lines.length === 3 && d.parked && d.parked.length === 1 && d.parked[0].label === '古い案' && d.parked[0].lines.length === 3, 'parsed parked island', d.parked);
ok(FZ.expandRefsText(d, d.parked[0].lines[1].segs[0].text) === '詳しくは図 1。', 'ref chars mapped to the main table');
const s = FZ.serialize(d); ok(/#保留 p1 古い案\n\[番号1\]旧案\n詳しくは<図番 a>。\n\[項目1\]項目\n#保留ここまで/.test(s) && FZ.serialize(FZ.parse(s)) === s, 'serialize and round trip');
ok(!FZ.toGfm(d).includes('旧案') && !FZ.toPlain(d).includes('旧案') && !Buffer.from(FZ.toDocx(d)).toString('latin1').includes('Ê§'), 'not exported (Markdown/text)');
ok(!FZ.layout(d).pages.some(p => p.glyphs.some(g => g.text === '旧')), 'not laid out');
const ed = new FZ.Editor(); ed.setDoc(d); ed.mutate('', () => { ed.doc.parked.push({ id: 'p2', label: 'x', lines: [FZ.newLine()] }); }); ok(ed.doc.parked.length === 2, 'editor change'); ed.undo(); ok(ed.doc.parked.length === 1, 'undo restores parked');
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
