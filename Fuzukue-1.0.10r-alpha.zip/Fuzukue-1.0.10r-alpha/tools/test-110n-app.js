/* 1.0.10n：画面 — Word をドロップ／F2→G で取り込む、F2 の帯、Markdown の書き出しは文机 Markdown */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const b64 = fs.readFileSync(path.join(__dirname, 'sample-docx/structured.docx')).toString('base64');
  await page.evaluate(b64 => { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); const f = new File([u], '事業報告.docx', { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }); const dt = new DataTransfer(); dt.items.add(f); document.getElementById('main').dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true })); }, b64);
  await page.waitForTimeout(800);
  let r = await page.evaluate(() => ({ msg: FZ.app.st.msg, name: FZ.app.ed.doc.fileName, body: FZ.serialize(FZ.app.ed.doc).split('---\n')[1].slice(0, 60), dirty: FZ.app.ed.dirty }));
  if (!(/Word を取り込みました：見出し 3/.test(r.msg) && r.name === '事業報告.fzk' && /2026年度 事業報告\n\[番号1\]概況/.test(r.body) && r.dirty)) bad('drop .docx imports with structure', r);
  await page.keyboard.press('F2'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ tile: !!document.querySelector('#sub .ch[data-cmd="importDocx"]'), rows: new Set([...document.querySelectorAll('#sub .ch')].map(e => Math.round(e.getBoundingClientRect().top))).size }));
  if (!(r.tile && r.rows <= 2)) bad('F2 has Word import, one band', r); await page.keyboard.press('Escape');
  await page.evaluate(() => { window.__dl = []; FZ.files.download = (data, name) => { window.__dl.push({ name, text: typeof data === 'string' ? data : '' }); }; FZ.app.ed.doc.lines[1].attrs.anchor = 'h1'; FZ.app.run('exportMd'); });
  r = await page.evaluate(() => window.__dl[0]); if (!(r && /\.md$/.test(r.name) && r.text.includes('<!-- 節:h1 -->'))) bad('Markdown export is 文机 Markdown', r && r.text.slice(0, 120));
  console.log('110n-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
