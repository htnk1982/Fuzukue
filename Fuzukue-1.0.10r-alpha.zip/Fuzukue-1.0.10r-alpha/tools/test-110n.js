/* 1.0.10n：文机 Markdown（X2）と Word の取り込み（X5） */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-docxin']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, fs = require('fs'), path = require('path'); let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 400) : ''); } else console.log('ok', m); };
(async () => {
  /* X2 */
  const src = '#fzk 2\n---\n[表題]報告\n[番号1 節:h1]概況\n本文。<図番 sales>と<図番 §h2>を参照。\n#図版 sales 図 売上の推移 chart.png 50%\n[番号1 改頁]課題\n[番号2 節:h2]為替\n重い。\n#グラフ g1 図 棒 地域別\n#データ |  | 東 | 西 |\n#データ | 件数 | 3 | 5 |\n';
  const d = FZ.parse(src); const md = FZ.toGfm(d, { fz: true });
  ok(md.includes('<!-- 節:h1 -->\n\n## 1. 概況') && md.includes('[図 1](#図-sales)') && md.includes('[2（1）為替](#節-h2)') && md.includes('<!-- 図版 sales 図 50% -->') && md.includes('<!-- 改頁 -->\n\n## 2. 課題') && md.includes('<!-- グラフ：棒'), '文机 Markdown has anchors, ref links, figure note, page break, chart', md);
  const plain = FZ.toGfm(d); ok(!/<!-- 節|<!-- 図版|\(#節-/.test(plain) && plain.includes('<!-- 改頁 -->'), 'plain GFM stays plain (page break kept)');
  const d2 = FZ.fromGfm(md, FZ.newDoc()); const s2 = FZ.serialize(d2).split('---\n')[1];
  ok(s2.includes('[番号1 節:h1]概況') && s2.includes('本文。<図番 sales>と<図番 §h2>を参照。') && s2.includes('#図版 sales 図 売上の推移 chart.png 50%') && s2.includes('[番号1 改頁]課題') && s2.includes('#グラフ'), 'read back to the same structure', s2);
  ok(FZ.toGfm(d2, { fz: true }) === md, 'Markdown round trip is stable');
  const d3 = FZ.fromGfm('# 題\n\n本文\n\n![図 2　写真](photo.jpg)\n\n次\n', FZ.newDoc()); const f3 = d3.lines.flatMap(l => l.attrs.figs || []); ok(f3.length === 1 && f3[0].file === 'photo.jpg' && f3[0].title === '写真', 'plain image paragraph becomes a figure', f3);
  /* X5：見出しスタイルの Word */
  const r = await FZ.fromDocx(fs.readFileSync(path.join(__dirname, 'sample-docx/structured.docx'))); const b = FZ.serialize(r.doc).split('---\n')[1];
  ok(r.headings && /^\[表題[^\]]*\]2026年度 事業報告\n\[番号1\]概況\n/.test(b), 'Title and Heading 1 (manual numbers removed)', b.slice(0, 80));
  ok(b.includes('売上は<太字>前年比 3% 増</太字>となった。') && b.includes('[項目1]国内は横ばい\n[項目1]海外は増加\n[項目2]アジアが中心'), 'bold runs and bullet levels (style name digit)');
  ok(b.includes('[番号2]為替') && b.includes('[番号項目1]予約を進める\n[番号項目1]現地生産を増やす'), 'Heading 2 and numbered list');
  ok(/\| <太字>項目<\/太字> \| <太字>上期<\/太字> \| <太字>下期<\/太字> \|\n\| 国内 \| 134 \| 140 \|/.test(b), 'table');
  /* X5：見出しスタイルの無い Word（平文の番号から） */
  const p = await FZ.fromDocx(fs.readFileSync(path.join(__dirname, 'sample-docx/plain.docx'))); const pb = FZ.serialize(p.doc).split('---\n')[1];
  ok(!p.headings && p.lifted === 6 && FZ.normalizeScheme(p.doc.format.scheme)[0] === '第1', 'plain numbering lifted with the best-fitting scheme (公用文)', { lifted: p.lifted });
  ok(/^\[番号1\]目的\nこの規程は手続を定める。\n\[番号1\]定義\n\[番号2\]用語の意味は次のとおり。\n\[番号3\]申請者/.test(pb), 'paragraph lines kept separate', pb);
  /* zip の読み：書いた docx を読み戻す */
  const back = await FZ.fromDocx(FZ.toDocx(d)); ok(back.headings && /\[番号1\]概況/.test(FZ.serialize(back.doc)), 'reads 文机 own Word output');
  console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})();
