/* 1.0.10o：画面 — AI からの戻し（X3）：写した範囲を覚える、貼って比べる、取り込む・捨てる・戻す・残りを全部、自動の範囲、ツリーの印、帯 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は<傍点>伸びた</傍点>。\n[番号1]課題\n為替が重い。\n[項目1]円安\n[番号1]対策\n予約する。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window.__clip = t; } }, configurable: true }); await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, SRC); await page.waitForTimeout(150);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const S = () => page.evaluate(() => { const a = FZ.app.st.aiBack; return a ? { n: a.hunks.length, i: a.i, name: a.name, taken: a.taken, skip: a.skip.size, kinds: a.hunks.map(h => h.kind).join(',') } : null; });
  /* 写す：カーソルの節。範囲を覚える */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 4, seg: 0, off: 0 }); FZ.app.run('aiCopySec'); }); await page.waitForTimeout(100);
  let r = await page.evaluate(() => ({ clip: window.__clip, sc: FZ.app.st.aiScope && FZ.app.st.aiScope.idx }));
  if (!(r.clip && r.clip.startsWith('<!-- 表題なし -->') && r.clip.includes('# 2. 課題') && JSON.stringify(r.sc) === '[3,4,5]')) bad('section copied and scope remembered', r);
  /* その間に文書の前が変わっても範囲は付いてくる */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); }); await page.keyboard.press('End'); await page.keyboard.press('Enter'); await page.keyboard.type('追記。'); await page.waitForTimeout(80);
  /* 戻す：欄を開いて貼る → 比べる */
  const md2 = r.clip.replace('為替が重い。', '為替の影響が大きい。').replace('- 円安', '- 円安\n- 金利高');
  await page.evaluate(() => FZ.app.run('aiReturn')); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ f: FZ.app.st.form, ta: !!document.querySelector('#sub textarea[name="md"]'), focus: document.activeElement && document.activeElement.name }));
  if (!(r.f === 'aiback' && r.ta && r.focus === 'md')) bad('form opens with the paste box focused', r);
  await page.fill('#sub textarea[name="md"]', md2); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(150);
  r = await S(); if (!(r && r.n === 2 && r.kinds === 'chg,add' && /写した範囲/.test(r.name))) bad('compared: 2 hunks against the copied range (auto)', r);
  r = await page.evaluate(() => document.querySelector('#sub .aiprev').innerHTML); if (!/<del>が重い<\/del><ins>の影響が大きい<\/ins>/.test(r)) bad('preview keeps okurigana with the word', r);
  r = await page.evaluate(() => ({ prev: document.querySelector('#sub .aiprev') && document.querySelector('#sub .aiprev').innerHTML, info: document.querySelector('#sub .info').textContent, caret: FZ.app.ed.caret.line, focus: document.activeElement && document.activeElement.dataset.act, ov: document.querySelectorAll('.ov rect').length }));
  if (!(/<del>[^<]+<\/del><ins>[^<]+<\/ins>/.test(r.prev) && /1\/2/.test(r.info) && r.caret === 5 && r.focus === 'take' && r.ov > 0)) bad('preview shows the change, caret on it, overlay drawn', r);
  r = await page.evaluate(() => { const s = document.querySelector('#sub'); const b = document.querySelector('#sub button[data-act="take"]'); return { h: s.getBoundingClientRect().height, bh: b.getBoundingClientRect().height }; }); if (r.h > r.bh * 2 + 14) bad('review band fits 2 rows', r);
  await page.screenshot({ path: path.resolve(__dirname, '../../shot-aiback.png'), clip: { x: 0, y: 0, width: 1100, height: 200 } });
  await page.keyboard.press('ArrowDown'); await page.waitForTimeout(60); r = await S(); const c2 = await page.evaluate(() => FZ.app.ed.caret.line); if (!(r.i === 1 && c2 === 6)) bad('ArrowDown moves to the next hunk (caret at the insertion point)', { r, c2 }); await page.keyboard.press('ArrowUp'); await page.waitForTimeout(60);
  /* 取り込む（Enter）→ 次へ。捨てる（Delete） */
  await page.keyboard.press('Enter'); await page.waitForTimeout(120); r = await body();
  if (!(r.includes('[番号1]課題\n為替の影響が大きい。\n[項目1]円安') && r.includes('売上は<傍点>伸びた</傍点>。\n追記。'))) bad('take: text changed in place, rest untouched', r);
  r = await S(); if (!(r.n === 1 && r.taken === 1 && r.kinds === 'add')) bad('one left after take', r);
  await page.keyboard.press('Delete'); await page.waitForTimeout(100); r = await S(); if (!(r.n === 0 && r.skip === 1)) bad('drop: none left', r);
  r = await page.evaluate(() => document.querySelector('#sub').textContent); if (!/違いはありません/.test(r)) bad('form says no differences', r);
  /* 欄の中の Ctrl+Z：取り込みを戻すと、その違いがまた出る（捨てたものは出ない） */
  await page.keyboard.press('Control+z'); await page.waitForTimeout(120); r = await S(); const b2 = await body();
  if (!(r.n === 1 && r.kinds === 'chg' && b2.includes('為替が重い。'))) bad('undo inside the form brings the hunk back', { r, b2 });
  /* 残りを全部 */
  await page.click('#sub button[data-act="back"]'); await page.waitForTimeout(80); r = await page.evaluate(() => document.querySelector('#sub textarea[name="md"]').value.length); if (!r) bad('back keeps the pasted text', r);
  await page.keyboard.press('Control+Enter'); await page.waitForTimeout(120); r = await S(); if (!(r.n === 2)) bad('compare again: 2 (skips reset)', r);
  await page.click('#sub button[data-act="all"]'); await page.waitForTimeout(120); r = await body(); const s2 = await S();
  if (!(r.includes('為替の影響が大きい。\n[項目1]円安\n[項目1]金利高\n[番号1]対策') && s2.n === 0)) bad('take all', { r, s2 });
  r = await page.evaluate(() => { const u = FZ.app.ed.undoStack.length; FZ.app.ed.undo(); return { u, b: FZ.serialize(FZ.app.ed.doc).split('---\n')[1] }; }); if (!r.b.includes('為替が重い。\n[項目1]円安\n[番号1]対策')) bad('take all is one undo step', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ f: FZ.app.st.form, a: FZ.app.st.aiBack })); if (r.f || r.a) bad('Escape closes and forgets the session', r);
  /* 中身の無い貼り付けは比べない（すべて消す塊にしない） */
  await page.evaluate(() => FZ.app.run('aiReturn')); await page.waitForTimeout(60); await page.fill('#sub textarea[name="md"]', '<!-- 表題なし -->\n'); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ a: FZ.app.st.aiBack, m: FZ.app.st.msg })); if (!(!r.a && /中身がありません/.test(r.m))) bad('empty paste is refused', r); await page.keyboard.press('Escape');
  /* 自動の範囲：文書全体の Markdown を貼れば文書全体と比べる */
  await page.evaluate(() => { FZ.app.run('aiCopyDoc'); }); await page.waitForTimeout(80); const whole = await page.evaluate(() => window.__clip);
  await page.evaluate(() => { FZ.app.st.aiScope = { idx: [3, 4, 5], snap: FZ.app.ed.doc.lines.map(l => FZ.lineSig(FZ.app.ed.doc, l)), what: '「課題」の節' }; FZ.app.run('aiReturn'); }); await page.waitForTimeout(60);
  await page.fill('#sub textarea[name="md"]', '```markdown\n' + whole.replace('予約する。', '早めに予約する。') + '```\n'); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(120);
  r = await S(); if (!(r && r.n === 1 && r.name === '文書全体')) bad('auto picks the whole document; code fence unwrapped', r);
  /* ツリー：印が付き、取り込める */
  await page.keyboard.press('Escape'); await page.evaluate(() => { FZ.app.run('outlinePanel'); }); await page.waitForTimeout(150);
  await page.evaluate(() => FZ.app.run('aiReturn')); await page.waitForTimeout(60); r = await page.evaluate(() => ({ mode: FZ.app.st.mode, f: FZ.app.st.form }));
  if (!(r.mode === 'tree' && r.f === 'aiback')) bad('opens in the tree', r);
  await page.fill('#sub textarea[name="md"]', whole.replace('予約する。', '早めに予約する。')); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ badges: document.querySelectorAll('#tree .tdiff').length, cur: document.querySelectorAll('#tree .tdiff.cur').length, sel: FZ.app.st.tree.sel && FZ.app.st.tree.sel.segs && FZ.app.st.tree.sel.segs[0].text }));
  if (!(r.badges >= 1 && r.cur === 1)) bad('tree shows diff badges', r);
  r = await page.evaluate(() => FZ.app.st.aiBack.hunks.length);
  if (r === 1) { await page.keyboard.press('ArrowDown'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ i: FZ.app.st.aiBack.i, mode: FZ.app.st.mode, f: FZ.app.st.form })); if (!(r.i === 0 && r.mode === 'tree' && r.f === 'aiback')) bad('arrow keys stay in the form (tree)', r); }
  await page.keyboard.press('Enter'); await page.waitForTimeout(150); r = await page.evaluate(() => ({ b: FZ.serialize(FZ.app.ed.doc).split('---\n')[1], mode: FZ.app.st.mode, badges: document.querySelectorAll('#tree .tdiff').length }));
  if (!(r.b.includes('早めに予約する。') && r.mode === 'tree' && r.badges === 0)) bad('take in the tree', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(60);
  /* 帯：ファイルの帯に「戻す」、2 行に収まる */
  await page.evaluate(() => { if (FZ.app.st.mode === 'tree') FZ.app.run('outlinePanel'); }); await page.waitForTimeout(80);
  await page.keyboard.press('F2'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ tile: !!document.querySelector('#sub .ch[data-cmd="aiReturn"]'), rows: new Set([...document.querySelectorAll('#sub .ch')].map(e => Math.round(e.getBoundingClientRect().top))).size }));
  if (!(r.tile && r.rows <= 2)) bad('file band has the return tile and fits 2 rows', r);
  await page.keyboard.press('r'); await page.waitForTimeout(60); r = await page.evaluate(() => FZ.app.st.form); if (r !== 'aiback') bad('F2→R opens it', r);
  console.log('110o-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
