/* 1.0.10o：AI からの戻し（X3）— 差分・取り込み・文机 Markdown の往復の忠実さ */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-tree', 'fz-merge']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, fs = require('fs'), path = require('path'); let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 500) : ''); } else console.log('ok', m); };
const sample = n => fs.readFileSync(path.join(__dirname, '../samples', n), 'utf8');
const fmtOf = A => JSON.parse(JSON.stringify(A.format));
const targets = A => ({ anchors: A.lines.map(l => l.attrs.anchor).filter(Boolean), figs: A.lines.flatMap(l => (l.attrs.figs || []).map(f => f.id)) });
function sliceDoc(d, a, b) { const sub = { ...d, lines: d.lines.slice(a, b + 1).map(l => JSON.parse(JSON.stringify(l))), rules: [], fills: [], images: d.images, refs: d.refs };
  for (const r of d.rules) { if (r.axis === 'h' && r.line >= a && r.line <= b + 1) sub.rules.push({ ...r, line: r.line - a }); else if (r.axis === 'v' && r.from >= a && r.to <= b) sub.rules.push({ ...r, from: r.from - a, to: r.to - a }); }
  for (const f of d.fills) if (f.from >= a && f.to <= b) sub.fills.push({ ...f, from: f.from - a, to: f.to - a }); const r = FZ.normalize(sub); r._nums = FZ.figureNumbers(d); return r; }
const range = (a, b) => { const r = []; for (let k = a; k <= b; k++) r.push(k); return r; };
/* 取り込みを最後まで（毎回比べ直す） */
function mergeAll(ed, B, idx) { const sigB = B.lines.map(l => FZ.lineSig(B, l)); let steps = 0;
  for (; steps < 80; steps++) { const sigA = ed.doc.lines.map(l => FZ.lineSig(ed.doc, l)); const H = FZ.diffDocs(ed.doc, idx, B, sigA, sigB); if (!H.length) break; const h = H[0]; const n0 = ed.doc.lines.length;
    ed.mutate('', () => FZ.applyHunk(ed, B, h, { sigA, sigB })); const d = ed.doc.lines.length - n0; const s0 = h.rem.length ? h.rem[0] : h.at, e0 = h.rem.length ? h.rem[h.rem.length - 1] : h.at - 1; const out = new Set(); for (const i of idx) { if (i < s0) out.add(i); else if (i > e0) out.add(i + d); } for (let k = s0; k <= e0 + d; k++) out.add(k); idx = [...out].sort((x, y) => x - y); }
  return { steps, idx, sigB }; }
const content = (doc, idx) => (idx || doc.lines.map((_, i) => i)).map(i => FZ.lineSig(doc, doc.lines[i])).filter(s => s !== '|');

/* 1. 往復しても違いが出ない（文書全体・節ごと） */
for (const name of ['見本.fzk', '資料見本.fzk', '新聞風見本.fzk', '取扱説明書.fzk']) { const A = FZ.parse(sample(name)); const sigA = A.lines.map(l => FZ.lineSig(A, l));
  const B = FZ.fromGfm(FZ.toGfm(A, { fz: true }), { ...FZ.newDoc(), format: fmtOf(A) }); const H = FZ.diffDocs(A, range(0, A.lines.length - 1), B, sigA);
  ok(!H.length, `whole round trip has no differences: ${name}`, H.slice(0, 2).map(h => h.key.slice(0, 120)));
  const tr = FZ.tree.build(A, {}); let bad = []; for (const nd of tr.nodes) { if (!['num', 'sym', 'title', 'list'].includes(nd.kind)) continue;
    const B2 = FZ.fromGfm(FZ.toGfm(sliceDoc(A, nd.line, nd.end), { fz: true }), { ...FZ.newDoc(), format: fmtOf(A) }, { refTargets: targets(A) }); const idx = range(nd.line, nd.end); FZ.alignLevels(A, idx, B2);
    const H2 = FZ.diffDocs(A, idx, B2, sigA); if (H2.length) bad.push(nd.text.slice(0, 16) + ':' + H2[0].key.slice(0, 80)); }
  ok(!bad.length, `section round trips have no differences: ${name}`, bad.slice(0, 3)); }

/* 2. 文机 Markdown の注記：目次・表題・飾り・囲み・表題なし */
{ const A = FZ.parse(sample('取扱説明書.fzk')); const md = FZ.toGfm(A, { fz: true }); ok(/<!-- 目次 \{.*\} -->/.test(md) && md.includes('<!-- 囲み -->'), 'toc and box notes', md.slice(0, 200));
  const B = FZ.fromGfm(md, { ...FZ.newDoc(), format: fmtOf(A) }); ok(B.lines.some(l => l.attrs.toc) && B.rules.length > 0 && FZ.articleMatch(B, B.lines.findIndex(l => l.segs[0].text.startsWith('この説明書の読み方'))), 'toc line and box come back'); }
{ const A = FZ.parse(sample('資料見本.fzk')); const md = FZ.toGfm(A, { fz: true }); ok(md.includes('<!-- 表題 -->\n# '), 'several titles are noted'); const B = FZ.fromGfm(md, { ...FZ.newDoc(), format: fmtOf(A) }); ok(B.lines.filter(l => l.attrs.style === 'title').length === A.lines.filter(l => l.attrs.style === 'title').length, 'all titles come back'); }
{ const A = FZ.parse(sample('新聞風見本.fzk')); const md = FZ.toGfm(A, { fz: true }); ok(/<!-- 飾り \S+ -->\n#/.test(md), 'decorated heading lines are noted'); const B = FZ.fromGfm(md, { ...FZ.newDoc(), format: fmtOf(A) }); ok(B.lines.filter(l => l.attrs.deco).length === A.lines.filter(l => l.attrs.deco && l.segs.some(s => s.text)).length, 'decorated lines come back'); }
{ const A = FZ.parse('#fzk 2\n---\n[番号1]概況\n本文。\n'); const md = FZ.toGfm(A, { fz: true }); ok(md.startsWith('<!-- 表題なし -->') && FZ.fromGfm(md, FZ.newDoc()).lines[0].attrs.style === 'num', 'a doc without a title keeps # as a numbered heading', md);
  ok(!FZ.toGfm(A).includes('表題なし'), 'plain GFM has no note'); }

/* 3. 差分の塊と取り込み：節の参照・図・飾り・傍点は残る */
const src = '#fzk 2\n---\n[表題]報告\n[番号1 節:h1]概況\n売上は<傍点>伸びた</傍点>。<図番 sales>を参照。\n#図版 sales 図 売上の推移 chart.png 50%\n[項目1]国内は横ばい\n[番号1]課題\n為替が重い。<図番 §h1>を見よ。\n[番号1]対策\n予約する。\n';
{ const ed = new FZ.Editor(); ed.setDoc(FZ.parse(src)); const A = ed.doc; const md = FZ.toGfm(A, { fz: true });
  const md2 = md.replace('為替が重い。', '為替の影響が大きい。').replace('- 国内は横ばい', '- 国内は横ばい\n- 海外は増加').replace(/## 3\. 対策\n\n予約する。\n?/, '').replace('売上は*伸びた*。', '売上は*大きく伸びた*。');
  const B = FZ.fromGfm(md2, { ...FZ.newDoc(), format: fmtOf(A) }); const H = FZ.diffDocs(A, range(0, A.lines.length - 1), B);
  ok(H.map(h => h.kind).join(',') === 'chg,add,chg', 'hunks: change, add, change+delete', H.map(h => [h.kind, h.rem, h.b]));
  const r = mergeAll(ed, B, range(0, A.lines.length - 1)); const out = FZ.serialize(ed.doc).split('---\n')[1];
  ok(JSON.stringify(content(ed.doc)) === JSON.stringify(r.sigB.filter(s => s !== '|')), 'after taking all, content equals the returned text', out);
  ok(out.includes('売上は<傍点>大きく伸びた</傍点>。<図番 sales>を参照。') && out.includes('#図版 sales 図 売上の推移 chart.png 50%'), 'marks MD keeps, figure and its reference stay', out);
  ok(out.includes('為替の影響が大きい。<図番 §h1>を見よ。') && out.includes('[項目1]海外は増加') && !out.includes('対策'), 'section ref remapped; item added; section removed', out);
  ok(ed.undoStack.length === r.steps, 'one undo step per hunk', { u: ed.undoStack.length, s: r.steps }); }
/* 4. 節だけ写して戻す：範囲の外は触らない。範囲の外の節への参照も参照のまま */
{ const ed = new FZ.Editor(); ed.setDoc(FZ.parse(src)); const A = ed.doc; const tr = FZ.tree.build(A, {}); const nd = tr.nodes.find(n => n.text === '課題');
  const md = FZ.toGfm(sliceDoc(A, nd.line, nd.end), { fz: true }); ok(md.includes('[1. 概況](#節-h1)'), 'section copy links an outside section', md);
  const B = FZ.fromGfm(md.replace('重い', 'とても重い') + '\n追記した段落。\n', { ...FZ.newDoc(), format: fmtOf(A) }, { refTargets: targets(A) }); const before = FZ.serialize(A).split('[番号1]課題')[0];
  mergeAll(ed, B, range(nd.line, nd.end)); const out = FZ.serialize(ed.doc);
  ok(out.startsWith(before) && out.includes('為替がとても重い。<図番 §h1>を見よ。\n\n追記した段落。\n[番号1]対策\n予約する。'), 'only the section changes; ref kept; the addition lands at the end of the section', out.split('---\n')[1]); }
/* 5. 飾りの行：字だけ直り、飾りと倍角は残る */
{ const ed = new FZ.Editor(); ed.setDoc(FZ.parse(sample('新聞風見本.fzk'))); const A = ed.doc; const md = FZ.toGfm(A, { fz: true }); const t0 = A.lines.find(l => l.attrs.deco && l.segs[0].text.length > 4); const old = t0.segs[0].text;
  const B = FZ.fromGfm(md.replace(old, '速報' + old.slice(2)), { ...FZ.newDoc(), format: fmtOf(A) }); mergeAll(ed, B, range(0, A.lines.length - 1)); const t1 = ed.doc.lines.find(l => l.segs[0].text === '速報' + old.slice(2));
  ok(t1 && t1.attrs.deco === t0.attrs.deco && t1.segs[0].marks[0] === t0.segs[0].marks[0], 'decorated heading: text changes, decoration and size marks stay', t1 && { a: t1.attrs, m: t1.segs[0].marks.slice(0, 3), m0: t0.segs[0].marks.slice(0, 3) }); }
/* 6. 表の枡の字：罫はそのまま */
{ const A0 = FZ.parse(sample('見本.fzk')); const ed = new FZ.Editor(); ed.setDoc(A0); const A = ed.doc; const md = FZ.toGfm(A, { fz: true }); const rules0 = A.rules.length; const m = md.match(/\n\| ([^|\n]+?) \|/); 
  const B = FZ.fromGfm(md.replace(m[0], '\n| ' + m[1] + '改 |'), { ...FZ.newDoc(), format: fmtOf(A) }); const r = mergeAll(ed, B, range(0, A.lines.length - 1));
  ok(r.steps === 1 && ed.doc.rules.length === rules0 && ed.doc.lines.some(l => l.segs.some(s => s.text === m[1] + '改')), 'table cell edit keeps the table rules', { steps: r.steps, rules0, now: ed.doc.rules.length }); }
/* 7. 範囲の付け替え：前に行が増えても、範囲の中への挿入も */
{ const old = ['a', 'b', 'c', 'd', 'e'], now = ['x', 'a', 'b', 'c', 'Q', 'd', 'e']; ok(JSON.stringify(FZ.remapIdx([1, 2, 3], old, now)) === '[2,3,4,5]', 'remap: shift and inside insertion', FZ.remapIdx([1, 2, 3], old, now)); }
/* 8. 箇条書きの段の合わせ */
{ const A = FZ.parse('#fzk 2\n---\n[項目1]親\n[項目2]子\n[項目3]孫\n'); const B = FZ.fromGfm('- 子\n  - 孫\n', FZ.newDoc()); ok(FZ.alignLevels(A, [1, 2], B) === 1 && B.lines[0].attrs.list.level === 1 && !FZ.diffDocs(A, [1, 2], B).length, 'list levels aligned to the scope'); }
console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
