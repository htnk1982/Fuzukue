/* 1.0.10p：段落・項目の中の改行（Shift+Enter＝attrs.join）、ツリー（区切り線を出さない・箇条書きの中の文・改行の行は同じ節） */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-docxin', 'fz-tree', 'fz-merge']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 500) : ''); } else console.log('ok', m); };
(async () => {
  const SRC = '#fzk 2\n---\n[番号1]概況\n売上は伸びた。\n[改行]海外が牽引。円安。\n次の段落。\n[区切り]\n[項目1]国内は横ばい。\n[続き1 改行]価格競争。\n[項目2]首都圏は堅調。\n[番号1]課題\n';
  const d = FZ.parse(SRC); ok(d.lines[2].attrs.join === true && FZ.serialize(d).includes('[改行]海外が牽引。円安。') && FZ.serialize(d).includes('[続き1 改行]価格競争。'), 'join token round trip');
  /* ツリー */
  const t = FZ.tree.build(d, { body: true, sentences: true }); const kinds = t.nodes.map(n => n.kind + ':' + n.text);
  ok(!kinds.some(k => /区切り/.test(k)), 'separator line is not a tree node', kinds);
  const para = t.nodes.find(n => n.text.startsWith('売上は伸びた。')); ok(para && para.end === 2 && para.text === '売上は伸びた。 海外が牽引。円安。' && para.children.filter(c => c.kind === 'sent').length === 3, 'join line belongs to the paragraph node; its sentences too', para && { end: para.end, text: para.text, ch: para.children.map(c => c.text) });
  ok(t.byObj.get(d.lines[2]) === para, 'join line maps to its paragraph node');
  const item = t.nodes.find(n => n.kind === 'list' && n.text.startsWith('国内')); ok(item && item.para && item.children.map(c => c.kind + ':' + c.text).join('|') === 'sent:国内は横ばい。|sent:価格競争。|list:首都圏は堅調。', 'list item: sentences split by default (with its child item kept)', item && item.children.map(c => c.kind + ':' + c.text));
  ok(FZ.tree.childType(item).kind === 'list', 'child type ignores sentence nodes');
  /* Markdown */
  const md = FZ.toGfm(d, { fz: true }); ok(md.includes('売上は伸びた。\\\n海外が牽引。円安。') && md.includes('- 国内は横ばい。\\\n  価格競争。'), 'Markdown: line break with backslash', md);
  const B = FZ.fromGfm(md, FZ.newDoc()); const bs = FZ.serialize(B).split('---\n')[1]; ok(bs.includes('売上は伸びた。\n[改行]海外が牽引。円安。') && bs.includes('[項目1]国内は横ばい。\n[続き1 改行]価格競争。'), 'Markdown read back to join lines', bs);
  ok(!FZ.diffDocs(d, d.lines.map((_, i) => i), B).length, 'no differences after round trip');
  const wd = await FZ.fromDocx(FZ.toDocx(FZ.parse('#fzk 2\n---\n一つ目の段落。\n二つ目の段落。\n'))); ok(!wd.doc.lines.some(l => l.attrs.join), 'Word paragraphs stay separate paragraphs on import');
  /* Word */
  const files = await FZ.unzip(FZ.toDocx(d)); const x = new TextDecoder().decode(await files.get('word/document.xml')()); const plain = x.replace(/<w:br\/>/g, '⏎').replace(/<\/w:p>/g, '¶').replace(/<[^>]+>/g, '');
  ok(plain.includes('売上は伸びた。⏎海外が牽引。円安。¶') && plain.includes('国内は横ばい。⏎価格競争。¶'), 'Word: one paragraph with a line break', plain.slice(0, 200));
  /* 編集 */
  const ed = new FZ.Editor(); ed.setDoc(FZ.parse('#fzk 2\n---\n売上は伸びた。海外が牽引。\n[項目1]国内は横ばい。価格競争。\n'));
  ed.setCaret({ line: 0, seg: 0, off: 7 }); ed.softBreak(); let s = FZ.serialize(ed.doc).split('---\n')[1]; ok(s.startsWith('売上は伸びた。\n[改行]海外が牽引。\n'), 'Shift+Enter in a paragraph', s);
  ed.setCaret({ line: 2, seg: 0, off: 7 }); ed.softBreak(); s = FZ.serialize(ed.doc).split('---\n')[1]; ok(s.includes('[項目1]国内は横ばい。\n[続き1 改行]価格競争。'), 'Shift+Enter in a list item', s);
  ed.setCaret({ line: 3, seg: 0, off: 0 }); ed.enter(); s = FZ.serialize(ed.doc).split('---\n')[1]; ok(s.includes('[項目1]国内は横ばい。\n[項目1]価格競争。'), 'Enter at the start of a join line splits the item', s);
  ed.undo(); ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.backspace(); s = FZ.serialize(ed.doc).split('---\n')[1]; ok(s.startsWith('売上は伸びた。海外が牽引。\n'), 'Backspace at the start of a join line joins back', s);
  ed.setCaret({ line: 1, seg: 0, off: 3 }); ed.softBreak(); ed.setCaret({ line: 2, seg: 0, off: 2 }); ed.enter(); s = FZ.serialize(ed.doc).split('---\n')[1]; ok(s.includes('[項目1]国内は\n[続き1 改行]横ば\n[項目1]い。\n[続き1 改行]価格競争。'), 'Enter in the middle of a join line makes a new item', s);
  const ed2 = new FZ.Editor(); ed2.setDoc(FZ.parse('#fzk 2\n---\n[番号1]見出し\n')); ed2.setCaret({ line: 0, seg: 0, off: 2 }); ed2.softBreak(); ok(!ed2.doc.lines[1].attrs.join && !ed2.doc.lines[1].attrs.style, 'Shift+Enter in a heading is a plain Enter');
  console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})();
