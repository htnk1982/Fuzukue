/* 1.0.10q：画面 — 区画（F6→C）、保留の島の全文（画面の下）、並べるの境目をドラッグ、F8＝表（罫線を手で引く機能はやめた）、F2 のツリー書き出し・構造PPT なし、ツリーの Word は図形 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '[表題]政策の概要\n[番号1]現状と対応\n背景。\n[番号2]現状\n[項目1]利用が伸びない\n[番号2]課題\n[項目1]使い方\n[番号2]対応\n[項目1]研修\n[番号1]今後\n実施する。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); }, SRC); await page.waitForTimeout(100);
  /* 区画 */
  await page.keyboard.press('F6'); await page.keyboard.press('c'); await page.waitForTimeout(80);
  let r = await page.evaluate(() => ({ f: FZ.app.st.form, info: document.querySelector('#sub .info') && document.querySelector('#sub .info').textContent })); if (!(r.f === 'panels' && /現状と対応.*3 個/.test(r.info))) bad('F6→C opens the panel form on the section', r);
  await page.selectOption('#sub select[name="n"]', '3'); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ a: FZ.app.ed.doc.lines[1].attrs.panels, fills: FZ.app.ed.lay.pages[0].fills.filter(f => /^pnl/.test(f.id)).length, svg: document.querySelectorAll('#pages svg').length })); if (!(r.a === 3 && r.fills === 3)) bad('3 columns applied, header bands drawn', r);
  await page.selectOption('#sub select[name="head"]', 'gray'); await page.waitForTimeout(100); r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1].split('\n')[1]); if (r !== '[番号1 区画3 区画見出し網]現状と対応') bad('header style saved', r);
  await page.keyboard.press('Escape'); await page.keyboard.press('Control+z'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.ed.doc.lines[1].attrs.panelHead); if (r) bad('undo the style change', r);
  /* 保留の島：全文が画面の下に */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 9, seg: 0, off: 0 }); FZ.app.run('park'); FZ.app.run('parkList'); }); await page.waitForTimeout(120);
  r = await page.evaluate(() => ({ on: document.body.classList.contains('island'), h: document.getElementById('island').offsetHeight, text: document.getElementById('island').innerText })); if (!(r.on && r.h > 40 && /1\.\s*今後/.test(r.text) && /実施する。/.test(r.text))) bad('island shows the full parked text with numbers', r);
  await page.keyboard.press('1'); await page.waitForTimeout(100); r = await page.evaluate(() => ({ n: (FZ.app.ed.doc.parked || []).length, body: FZ.serialize(FZ.app.ed.doc).includes('[番号1]今後') })); if (!(r.n === 0 && r.body)) bad('number key returns it', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(60); r = await page.evaluate(() => document.body.classList.contains('island')); if (r) bad('island hides with the form');
  /* 並べる：境目をドラッグ */
  await page.evaluate(() => { const s = document.getElementById('viewSel'); s.value = 'split'; s.dispatchEvent(new Event('change')); }); await page.waitForTimeout(200);
  const sp = await page.evaluate(() => { const b = document.getElementById('tsplit').getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top + 200, w: document.getElementById('treePane').offsetWidth }; });
  await page.mouse.move(sp.x, sp.y); await page.mouse.down(); await page.mouse.move(sp.x + 120, sp.y, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(120);
  r = await page.evaluate(() => document.getElementById('treePane').offsetWidth); if (!(Math.abs(r - (sp.w + 120)) <= 3)) bad('drag the split boundary', { before: sp.w, after: r });
  await page.evaluate(() => { const s = document.getElementById('viewSel'); s.value = 'paper'; s.dispatchEvent(new Event('change')); }); await page.waitForTimeout(100);
  /* F8＝表、罫線を引くは無い、F6 に飾り */
  r = await page.evaluate(() => ({ f8: document.querySelector('#fkeys .fk:nth-child(8)').textContent, rule: !!FZ.app.keysOf('ruleMode'), cmds: ['ruleMode', 'rect'].filter(c => FZ.app.keysOf(c) !== '') }));
  await page.keyboard.press('F8'); await page.waitForTimeout(60); const t8 = await page.evaluate(() => [...document.querySelectorAll('#sub .ch')].map(e => e.dataset.cmd)); await page.keyboard.press('Escape');
  await page.keyboard.press('F6'); await page.waitForTimeout(60); const t6 = await page.evaluate(() => [...document.querySelectorAll('#sub .ch')].map(e => e.dataset.cmd)); await page.keyboard.press('Escape');
  if (!(/表/.test(r.f8) && t8.includes('table') && t8.includes('tr:above') && t8.includes('tableGroup') && !t8.includes('ruleMode') && t6.includes('headGroup') && t6.includes('fillMode') && t6.includes('panels'))) bad('F8 is 表; decorations in F6; no rule drawing', { r, t8, t6 });
  await page.keyboard.press('F2'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ outline: !!document.querySelector('#sub .ch[data-cmd="exportOutline"]'), labels: ['exportTreePptx', 'exportTreePdf', 'exportTreeDocx'].map(c => (document.querySelector(`#sub .ch[data-cmd="${c}"] .lb`) || {}).textContent) })); await page.keyboard.press('Escape');
  if (r.outline || r.labels.join() !== 'ﾂﾘｰPPT,ﾂﾘｰPDF,ﾂﾘｰWord') bad('F2: no 構造PPT; tree exports labelled ﾂﾘｰ…', r);
  /* ツリーの Word：画像でなく図形 */
  await page.evaluate(() => { window.__dl = []; FZ.files.download = (data, name) => { window.__dl.push({ name, data: data instanceof Uint8Array ? Array.from(data.slice(0, 4)) : null, len: data.length || data.size }); window.__last = data; }; FZ.app.run('exportTreeDocx'); }); await page.waitForTimeout(1200);
  r = await page.evaluate(async () => { const z = window.__last; if (!z) return null; const files = await FZ.unzip(z); const x = new TextDecoder().decode(await files.get('word/document.xml')()); return { name: window.__dl[0].name, wsp: (x.match(/<wps:wsp>/g) || []).length, media: [...files.keys()].filter(k => /media/.test(k)).length, text: x.includes('政策の概要') }; });
  if (!(r && /（ツリー）\.docx$/.test(r.name) && r.wsp > 5 && r.media === 0 && r.text)) bad('tree Word export uses Word shapes with the text (no pictures)', r);
  /* ツリーの帯に深さ・形（編集しながら切り替える） */
  await page.evaluate(() => { FZ.app.run('outlinePanel'); }); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ d: !!document.getElementById('ms_depth'), f: !!document.getElementById('ms_figs'), s: !!document.getElementById('ms_shape'), tiles: [...document.querySelectorAll('#sub .ch')].map(e => e.dataset.cmd).filter(Boolean), h: document.getElementById('sub').getBoundingClientRect().height }));
  if (!(r.d && r.f && r.s && r.tiles.includes('tv:up') && r.h < 60)) bad('tree band has depth, figures and shape with the structure operations in 2 rows', r);
  r = await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '今後'); return v.pos.get(n).h; }); if (r !== 24) bad('tree boxes are tighter on screen (one line = 24px)', r);
  r = await page.evaluate(() => { const m = FZ.app.treeModel ? FZ.app.treeModel() : null; return m ? m.nodes.find(n => n.lines && n.lines[0] && n.lines[0].includes('今後')).h : 28; }); if (r !== 28) bad('tree export keeps the roomier boxes', r);
  await page.selectOption('#ms_depth', '0'); await page.waitForTimeout(120); r = await page.evaluate(() => ({ depth: FZ.app.st.tree.depth, mode: FZ.app.st.mode })); if (!(r.depth === 0 && r.mode === 'tree')) bad('depth changes from the tree band', r);
  await page.evaluate(() => { FZ.app.run('outlinePanel'); }); await page.waitForTimeout(80);
  /* 排他の選択はプルダウン：ツリーの深さ・図表・形は F4（構造）に、倍率は F10、書体・向きは F9。保留と文選択は F3 */
  await page.evaluate(() => { FZ.app.st.tree.depth = 9; if (FZ.app.st.mode === 'tree') FZ.app.run('tv:paper'); }); await page.waitForTimeout(80);
  await page.keyboard.press('F4'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ ids: [...document.querySelectorAll('#sub select[data-msel]')].map(e => e.id), opts: [...document.querySelectorAll('#ms_depth option, #ms_figs option, #ms_shape option')].map(o => o.textContent), h: document.getElementById('sub').getBoundingClientRect().height, park: !!document.querySelector('#sub .ch[data-cmd="park"]') }));
  if (!(r.ids.join() === 'ms_depth,ms_figs,ms_shape' && r.opts.every(t => t.length <= 3) && r.h < 60 && !r.park)) bad('F4 has the tree pulldowns with 2-3 letter choices, in 2 rows', r);
  await page.keyboard.press('f'); await page.waitForTimeout(150); r = await page.evaluate(() => ({ mode: FZ.app.st.mode, depth: FZ.app.st.tree.depth })); if (!(r.mode === 'tree' && r.depth === 0)) bad('F4→F steps the tree depth (all → body)', r);
  await page.keyboard.press('F4'); await page.waitForTimeout(60); await page.selectOption('#ms_shape', 'h'); await page.waitForTimeout(120); r = await page.evaluate(() => ({ dir: FZ.app.st.tree.dir, armed: FZ.app.st.armed })); if (!(r.dir === 'h' && !r.armed)) bad('shape pulldown in F4', r);
  await page.keyboard.press('F4'); await page.waitForTimeout(60); await page.selectOption('#ms_figs', 'open'); await page.waitForTimeout(120); r = await page.evaluate(() => document.getElementById('ms_figs') ? document.getElementById('ms_figs').value : FZ.app.st.tree.showAll); if (!(r === 'open' || r === true)) bad('figures pulldown opens all', r);
  await page.evaluate(() => { FZ.app.run('tvs:i'); FZ.app.run('tvd:9'); FZ.app.run('tvf:close'); FZ.app.run('tv:paper'); }); await page.waitForTimeout(100);
  await page.keyboard.press('F10'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ ids: [...document.querySelectorAll('#sub select[data-msel]')].map(e => e.id), tree: !!document.querySelector('#sub .ch[data-cmd="outlinePanel"]') })); if (!(r.ids.join() === 'ms_zoom' && !r.tree)) bad('F10 has the zoom pulldown and no tree items', r);
  await page.selectOption('#ms_zoom', '1.25'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.st.zoom); if (r !== 1.25) bad('zoom pulldown', r);
  await page.keyboard.press('F10'); await page.keyboard.press('1'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.st.zoom); if (r !== 1.5) bad('F10→1 steps the zoom', r);
  await page.evaluate(() => { FZ.app.st.zoom = 'width'; FZ.app.render(); });
  await page.keyboard.press('F9'); await page.waitForTimeout(60); await page.selectOption('#ms_font', 'gothic'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.ed.doc.format.font); if (r !== 'gothic') bad('font pulldown', r);
  await page.keyboard.press('F9'); await page.waitForTimeout(60); await page.selectOption('#ms_orient', 'l'); await page.waitForTimeout(80); r = await page.evaluate(() => !!FZ.app.ed.doc.format.landscape); if (!r) bad('orientation pulldown', r);
  await page.evaluate(() => { FZ.app.run('undo'); FZ.app.run('undo'); }); await page.waitForTimeout(60);
  await page.keyboard.press('F3'); await page.waitForTimeout(60); r = await page.evaluate(() => ['park', 'parkList', 'selSent'].every(c => !!document.querySelector(`#sub .ch[data-cmd="${c}"]`)) && document.getElementById('sub').getBoundingClientRect().height < 60); if (!r) bad('F3 has park, the island and sentence select', r);
  await page.keyboard.press('Escape'); await page.keyboard.press('Escape');
  /* 書類と資料の版面は別：種類を切り替えると入れ替わる。既定もそれぞれ */
  r = await page.evaluate(async () => { const A = FZ.app; A.ed.mutate('', () => { A.ed.doc.format.cols = 30; }); A.run('kindSlide'); const s1 = { kind: A.ed.doc.format.kind, cols: A.ed.doc.format.cols };
    A.ed.mutate('', () => { A.ed.doc.format.cols = 50; }); A.run('kindDoc'); const d1 = A.ed.doc.format.cols; A.run('kindSlide'); const s2 = A.ed.doc.format.cols; const txt = FZ.serialize(A.ed.doc); return { s1, d1, s2, saved: /控えの版面: .*"doc":\{[^}]*"cols":30/.test(txt) }; });
  if (!(r.s1.kind === 'slide' && r.s1.cols !== 30 && r.d1 === 30 && r.s2 === 50 && r.saved)) bad('document and slide keep their own page settings', r);
  r = await page.evaluate(() => { const A = FZ.app; A.run('format'); return !!document.querySelector('#sub button[data-act="setDefault"]') && document.querySelector('#sub button[data-act="setDefault"]').textContent; }); if (r !== '資料の既定にする') bad('format form offers the slide default', r);
  await page.click('#sub button[data-act="setDefault"]'); await page.keyboard.press('Escape');
  r = await page.evaluate(() => { const A = FZ.app; const sd = JSON.parse(localStorage.getItem('fz.defaults.slide') || 'null'); A.ed.dirty = false; A.run('newSlide'); const f1 = A.ed.doc.format; const out = { sd: sd && sd.cols, slide: f1.cols }; A.ed.dirty = false; A.run('kindDoc'); out.doc = A.ed.doc.format.cols; localStorage.removeItem('fz.defaults.slide'); return out; });
  if (!(r.sd === 50 && r.slide === 50 && r.doc !== 50)) bad('slide default used for a new slide; document default stays separate', r);
  console.log('110q-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
