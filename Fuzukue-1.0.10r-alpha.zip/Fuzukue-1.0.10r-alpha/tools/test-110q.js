/* 1.0.10q：霞が関型の区画（V3）、均等割付の網、ツリーの Word（図形） */
for (const f of ['fz-core', 'fz-figure', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-docxin', 'fz-pptx', 'fz-pptx2', 'fz-tree', 'fz-render']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fail = 0; const ok = (c, m, i) => { if (!c) { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 500) : ''); } else console.log('ok', m); };
(async () => {
  const SRC = '#fzk 2\n書式: 資料\n用紙: A4 横\n---\n[表題]政策の概要\n[番号1 区画3]現状と対応\n背景の説明。\n[番号2]現状\n[項目1]利用が伸びない\n[項目1]人材が足りない\n[番号2]課題\n[項目1]使い方が分からない\n[番号2]対応\n[項目1]研修を行う\n[項目1]事例を共有する\n\n[番号1]今後\n来年度から実施。\n';
  const d = FZ.parse(SRC); ok(d.lines[1].attrs.panels === 3 && FZ.serialize(d).includes('[番号1 区画3]現状と対応'), 'panels token round trip');
  const L = FZ.layout(d); const R = i => L.lineMap[i].segs[0].rows[0]; const Y = i => L.lineMap[i].rows[0].y;
  ok(Y(3) === Y(6) && Y(6) === Y(8) && R(3).left < R(6).left && R(6).left < R(8).left, 'child sections side by side (same top, left to right)', [Y(3), Y(6), Y(8), R(3).left, R(6).left, R(8).left]);
  ok(R(4).left >= R(3).left - 0.01 && R(4).right <= R(6).left, 'panel content stays inside its panel', [R(4).left, R(4).right, R(6).left]);
  const pg = L.pages[0]; ok(pg.fills.filter(f => /^pnl/.test(f.id) && f.shade === 'dark').length === 3 && pg.vrules.filter(r => /^pnl/.test(r.id)).length === 6, 'header bands and frames');
  const bottom = Math.max(...[4, 5, 7, 9, 10].map(i => { const r = L.lineMap[i].rows; return r[r.length - 1].y + r[r.length - 1].h; }));
  ok(Y(11) === bottom && Y(12) > Y(11), 'trailing blank line comes after the panels; then the next section', [Y(11), bottom, Y(12)]);
  ok(R(2).right > R(6).left && Y(2) < Y(3), 'lead text runs in the body width above the panels', [R(2).right, R(6).left]);
  const md = FZ.toGfm(d, { fz: true }); ok(md.includes('<!-- 区画 3 -->\n\n## 1. 現状と対応') || md.includes('<!-- 区画 3 -->'), 'Markdown note', md.slice(0, 200));
  const B = FZ.fromGfm(md, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(d.format)) }); ok(B.lines.find(l => l.segs[0].text === '現状と対応').attrs.panels === 3, 'Markdown read back');
  const d2 = FZ.parse(SRC.replace('[番号1 区画3]', '[番号1 区画2 区画見出し網]')); const L2 = FZ.layout(d2); ok(L2.pages[0].fills.filter(f => /^pnl/.test(f.id)).every(f => f.shade === 'gray') && L2.lineMap[8].rows[0].y > L2.lineMap[3].rows[0].y, '2 columns wrap to a second row; gray header', [L2.lineMap[3].rows[0].y, L2.lineMap[8].rows[0].y]);
  const d3 = FZ.parse('#fzk 2\n---\n[番号1 区画2]表あり\n[番号2]甲\n#表 列 0,3,6 様式 格子\n| a | b |\n| 1 | 2 |\n[番号2]乙\n本文。\n'); const L3 = FZ.layout(d3); const k1 = d3.lines.findIndex(l => l.segs[0].text === '甲'), k2 = d3.lines.findIndex(l => l.segs[0].text === '乙');
  ok(FZ.inTable(d3, 2) && L3.lineMap[k2].rows[0].y > L3.lineMap[k1].rows[0].y && !L3.pages[0].fills.some(f => /^pnl/.test(f.id)), 'a group with a table is not paneled (flows)', [FZ.inTable(d3, 2), k1, k2]);
  /* 並べ方：横（1 段に全部）・縦（1 列に積む）・縦横（列数で段を重ねる） */
  { const mk = t => FZ.parse('#fzk 2\n---\n[番号1 ' + t + ']親\n[番号2]甲\n本文甲。\n[番号2]乙\n本文乙。\n[番号2]丙\n本文丙。\n'); const at = (L, i) => [L.lineMap[i].rows[0].y, L.lineMap[i].segs[0].rows[0].left];
    const H = FZ.layout(mk('区画横')), V = FZ.layout(mk('区画縦')), G = FZ.layout(mk('区画2'));
    ok(at(H, 1)[0] === at(H, 5)[0] && at(H, 5)[1] > at(H, 3)[1], 'horizontal: all in one row');
    ok(at(V, 1)[1] === at(V, 5)[1] && at(V, 5)[0] > at(V, 3)[0] && at(V, 3)[0] > at(V, 1)[0], 'vertical: stacked full width');
    ok(at(G, 1)[0] === at(G, 3)[0] && at(G, 5)[0] > at(G, 1)[0] && at(G, 5)[1] === at(G, 1)[1], 'grid 2 columns: second row');
    const m1 = FZ.toGfm(mk('区画縦'), { fz: true }); ok(m1.includes('<!-- 区画 縦 -->') && FZ.fromGfm(m1, FZ.newDoc()).lines.find(l => l.segs[0].text === '親').attrs.panels === 'v' && FZ.serialize(mk('区画横')).includes('[番号1 区画横]'), 'arrangement survives fzk and Markdown'); }
  /* つなぎ：横は区画の間に ▶ か →、縦は区画の間の行に ▼ か ↓ */
  { const mk = t => FZ.parse('#fzk 2\n---\n[番号1 ' + t + ']親\n[番号2]甲\n本文甲。\n[番号2]乙\n本文乙。\n[番号2]丙\n本文丙。\n'); const marks = L => L.pages[0].glyphs.filter(g => g.deco).map(g => g.text);
    ok(marks(FZ.layout(mk('区画横 区画三角'))).join() === '▶,▶' && marks(FZ.layout(mk('区画縦 区画矢印'))).join() === '↓,↓' && marks(FZ.layout(mk('区画2'))).length === 0, 'connectors: triangles between columns, arrows between stacked boxes, none by default');
    const m2 = FZ.toGfm(mk('区画横 区画三角'), { fz: true }); ok(m2.includes('<!-- 区画 横 三角 -->') && FZ.fromGfm(m2, FZ.newDoc()).lines.find(l => l.segs[0].text === '親').attrs.panelLink === 'tri', 'connector survives Markdown'); }
  const ed = new FZ.Editor(); ed.setDoc(FZ.parse(SRC)); ed.setCaret({ line: 6, seg: 0, off: 1 }); ed.moveV(1, false); ok(ed.caret.line === 7, 'caret moves down inside the same panel', ed.caret);
  /* 均等割付の網：間も埋める（1 つの矩形） */
  const dj = FZ.parse('#fzk 2\n---\n[均等]<網掛け>網掛けの字</網掛け>\n'); const svg = FZ.renderPage(FZ.layout(dj), 0, { mono: true }); const rs = [...svg.matchAll(/<rect[^>]*fill="url\(#s_text_0\)"[^>]*>/g)];
  ok(rs.length === 1 && +rs[0][0].match(/width="([\d.]+)"/)[1] > 300, 'justified shading is one continuous rect', rs.map(m => m[0]));
  /* ツリーの Word：図形 */
  const model = { nodes: [{ x: 0, y: 0, w: 300, h: 28, lines: ['報告'], head: true }, { x: 30, y: 40, w: 270, h: 28, lines: ['1. 概況'] }, { x: 30, y: 80, w: 270, h: 28, lines: ['2. 課題'] }], edges: [{ pts: [[14, 28], [14, 94]] }, { pts: [[14, 54], [30, 54]] }], W: 304, H: 112 };
  const Ds = FZ.treeDrawings(model, 510, 750); const dd = FZ.newDoc(); dd.lines = Ds.map(D => ({ segs: [FZ.newSeg(0, '')], attrs: { drawing: D } }));
  const files = await FZ.unzip(FZ.toDocx(dd)); const x = new TextDecoder().decode(await files.get('word/document.xml')()); const names = [...files.keys()];
  ok(/<wpg:wgp>/.test(x) && (x.match(/<wps:wsp>/g) || []).length === 5 && x.includes('<w:t xml:space="preserve">1. 概況</w:t>') && !names.some(n => /media\//.test(n)), 'tree Word: native shapes with text, no images', { wsp: (x.match(/<wps:wsp>/g) || []).length, names });
  console.log(fail ? 'FAIL ' + fail : 'ALL OK'); process.exit(fail ? 1 : 0);
})();
