/* 1.0.10r：ツリーの書き出し（PPT・Word・PDF）に、中身を見せている表・グラフ（図表）・流れ図も入る（以前は名前の箱だけで中身が抜けていた） */
const { chromium } = require('playwright'); const path = require('path'); const zlib = require('zlib');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const SRC = '#fzk 2\n---\n[表題]題\n[番号1]背景\n本文の文。\n#表 列 0,10,20,30 様式 格子 見出し薄\n| 項目 | 上期 | 下期 |\n| 国内 | 1 | 2 |\n\n[番号1]今後\n実施する。\n';
/* zip の中のファイル名と中身（deflate／stored） */
function unzip(buf) { const out = {}; let p = 0; while (p + 30 < buf.length && buf.readUInt32LE(p) === 0x04034b50) { const m = buf.readUInt16LE(p + 8), cs = buf.readUInt32LE(p + 18), nl = buf.readUInt16LE(p + 26), xl = buf.readUInt16LE(p + 28); const name = buf.slice(p + 30, p + 30 + nl).toString(); const d = buf.slice(p + 30 + nl + xl, p + 30 + nl + xl + cs); out[name] = m === 8 ? zlib.inflateRawSync(d) : d; p += 30 + nl + xl + cs; } return out; }
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText(s, 'x.fzk', null); FZ.app.ed.setCaret({ line: 6, seg: 0, off: 0 }); FZ.app.run('chart'); }, SRC); await page.waitForTimeout(300);
  await page.keyboard.press('Escape');
  await page.evaluate(() => { FZ.app.run('outlinePanel'); }); await page.waitForTimeout(200);
  /* 名前だけ（図題）のときは中身なし */
  let r = await page.evaluate(() => FZ.app.treeModel().nodes.filter(n => n.fig).length); if (r !== 0) bad('closed figures carry no contents', r);
  await page.evaluate(() => FZ.app.run('tvf:open')); await page.waitForTimeout(300);
  r = await page.evaluate(() => { const m = FZ.app.treeModel(); return { figs: m.nodes.filter(n => n.fig).map(n => n.fig.cells ? 'cells:' + n.fig.cells.list.map(c => c.text).join(',') : 'svg'), svg: FZ.treePageSvgs(m, 595, 842, {}).join('') }; });
  if (!(r.figs.includes('cells:項目,上期,下期,国内,1,2') && r.figs.includes('svg'))) bad('tree model carries the table cells and the chart drawing', r.figs);
  if (!(r.svg.includes('国内') && r.svg.includes('class="pg tfig"'))) bad('tree PDF pages draw the contents');
  const files = await page.evaluate(async () => { const got = []; const orig = FZ.files.download; FZ.files.download = (data, name) => got.push({ name, data }); await FZ.app.run('exportTreePptx'); await new Promise(r => setTimeout(r, 900)); await FZ.app.run('exportTreeDocx'); await new Promise(r => setTimeout(r, 900)); FZ.files.download = orig;
    const out = []; for (const d of got) { const u = new Uint8Array(await (d.data.arrayBuffer ? d.data.arrayBuffer() : new Blob([d.data]).arrayBuffer())); let bin = ''; for (let i = 0; i < u.length; i += 8192) bin += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); out.push({ name: d.name, b64: btoa(bin) }); } return out; });
  const P = files.find(f => f.name.endsWith('.pptx')), D = files.find(f => f.name.endsWith('.docx'));
  if (!P || !D) bad('both files were written', files.map(f => f.name));
  else {
    const zp = unzip(Buffer.from(P.b64, 'base64')); const sl = Object.keys(zp).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n)).map(n => zp[n].toString()).join('');
    if (!(sl.includes('国内') && (sl.match(/name="セル"/g) || []).length === 6)) bad('PowerPoint: the table is 6 editable cell boxes');
    if (!(Object.keys(zp).some(n => /^ppt\/media\/tree\d\.png$/.test(n)) && /r:embed="rIdT1"/.test(sl))) bad('PowerPoint: the chart is a picture', Object.keys(zp).filter(n => n.includes('media')));
    const rel = Object.keys(zp).filter(n => /slide\d+\.xml\.rels$/.test(n)).map(n => zp[n].toString()).join(''); if (!/Id="rIdT1"[^>]*media\/tree1\.png/.test(rel)) bad('PowerPoint: the picture has its relationship');
    const zd = unzip(Buffer.from(D.b64, 'base64')); const doc = zd['word/document.xml'].toString();
    if (!(doc.includes('国内') && (doc.match(/name="セル"/g) || []).length === 6)) bad('Word: the table is 6 editable cell boxes');
    if (!(/<a:blipFill><a:blip r:embed="rIdImg1"\/>/.test(doc) && zd['word/media/image1.png'])) bad('Word: the chart is a picture box');
    if (!/media\/image1\.png/.test(zd['word/_rels/document.xml.rels'].toString())) bad('Word: the picture has its relationship');
  }
  console.log('110r-app fails=' + fails, 'errors:', errors); await browser.close(); process.exit(fails ? 1 : 0);
})();
