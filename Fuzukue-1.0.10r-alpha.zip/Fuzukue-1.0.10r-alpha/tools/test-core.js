for (const f of ['fz-core','fz-figure','fz-styles','fz-entities','fz-md','fz-gfm','fz-export']) require('../app/js/'+f+'.js');
const FZ=globalThis.FZ;
const doc=FZ.parse(FZ.sampleText());
console.log('lines',doc.lines.length,'rules',doc.rules.length,'fills',doc.fills.length);
const lay=FZ.layout(doc);
console.log('pages',lay.pages.length,'glyphs p0',lay.pages[0].glyphs.length,'hrules',lay.pages[0].hrules.length,'vrules',lay.pages[0].vrules.length);
// show first rows
for(const [y,es] of [...lay.pages[0].rowmap.entries()].slice(0,8)) console.log('y',y, es.map(e=>`L${e.line}s${e.seg}k${e.k} [${e.startCol}-${e.endCol}) off${e.startOff}-${e.endOff}`).join(' | '));
const s1=FZ.serialize(doc); const doc2=FZ.parse(s1); const s2=FZ.serialize(doc2);
console.log('roundtrip stable:', s1===s2, s1.length);
if(s1!==s2){const a=s1.split('\n'),b=s2.split('\n');for(let i=0;i<Math.max(a.length,b.length);i++)if(a[i]!==b[i]){console.log('DIFF',i,'\n',a[i],'\n',b[i]);break;}}
console.log(s1.split('\n').slice(0,16).join('\n'));
// markdown
const md='# 題名\n\n本文 **太字** です。\n\n## 見出し\n- 項目1\n  - 子項目\n1. 番号\n\n| A | B |\n|---|---|\n| 1 | 2 |\n';
const d3=FZ.fromMarkdown(md); console.log('md lines',d3.lines.length,'rules',d3.rules.length); console.log(FZ.serialize(d3)); console.log(FZ.toMarkdown(d3));
// posToXY
console.log(FZ.posToXY(lay,{line:2,seg:0,off:10}), FZ.xyToPos(lay,0,3,5));
