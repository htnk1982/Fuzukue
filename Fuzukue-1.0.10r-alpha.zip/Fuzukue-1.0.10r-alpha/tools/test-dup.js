const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 820 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  const lines = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => l.segs.map(s => s.text).join('|')));
  // 同一内容の行（空行）が複数ある文書で、2行目にカーソルを置いて打つ
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); d.lines = [FZ.newLine('一'), FZ.newLine(''), FZ.newLine(''), FZ.newLine(''), FZ.newLine('同じ'), FZ.newLine('同じ')]; FZ.app.ed.setDoc(d); FZ.app.render(); });
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }));
  console.log('caret xy for line1:', await page.evaluate(() => JSON.stringify(FZ.app.ed.xy())), ' line2:', await page.evaluate(() => { FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); return JSON.stringify(FZ.app.ed.xy()); }), ' line4:', await page.evaluate(() => { FZ.app.ed.setCaret({ line: 4, seg: 0, off: 1 }); return JSON.stringify(FZ.app.ed.xy()); }));
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }));
  await page.keyboard.type('abc');
  console.log('typed on line1 ->', await lines());
  // 実キーで Enter 連打 → 行が増えるか、カーソルが追従するか
  await page.keyboard.press('Enter'); await page.keyboard.press('Enter'); await page.keyboard.type('x');
  console.log('after enter enter x ->', await lines(), await page.evaluate(() => JSON.stringify(FZ.app.ed.caret)));
  console.log('errors', errors);
  await browser.close();
})();
