for (const f of ['fz-core','fz-figure','fz-editor','fz-styles','fz-entities','fz-md','fz-gfm','fz-export']) require('../app/js/'+f+'.js');
const FZ=globalThis.FZ; const ed=new FZ.Editor();
const dump=()=>ed.doc.lines.map((l,i)=>i+': '+l.segs.map(s=>`@${s.col}"${s.text}"`).join(' ')+(Object.keys(l.attrs).length?' '+JSON.stringify(l.attrs):'')).join('\n');
ed.insertText('最初の段落です。'); ed.enter(); ed.insertText('二番目'); 
ed.setCaret({line:0,seg:0,off:3}); ed.insertText('挿入'); 
console.log(dump());
ed.setCaret({line:1,seg:0,off:0}); ed.backspace(); console.log('--- join:'); console.log(dump());
ed.undo(); console.log('--- undo:'); console.log(dump());
ed.setCaret({line:1,seg:0,off:3}); ed.insertTable(3,2,[10,16,14],true); console.log('--- table:'); console.log(dump()); console.log(JSON.stringify(ed.doc.rules.map(r=>r.axis==='h'?`h${r.line}:${r.from}-${r.to}`:`v${r.col}:${r.from}-${r.to}`)));
ed.insertText('セル1'); ed.tab(); ed.insertText('セル2の長い文章がここに入ると折り返すはず、折り返す。'); ed.enter(); ed.insertText('新行');
console.log('--- typed in cells + enter:'); console.log(dump()); console.log(JSON.stringify(ed.doc.rules.map(r=>r.axis==='h'?`h${r.line}:${r.from}-${r.to}`:`v${r.col}:${r.from}-${r.to}`)));
const lay=ed.lay; for(const [y,es] of [...lay.pages[0].rowmap.entries()]) console.log('y',y, es.map(e=>`L${e.line}s${e.seg}k${e.k}[${e.left}-${e.right}) ${e.startCol}-${e.endCol}`).join(' | '));
console.log('vrules p0', JSON.stringify(lay.pages[0].vrules.map(v=>[v.col,v.y1,v.y2])), 'hrules', JSON.stringify(lay.pages[0].hrules.map(h=>[h.y,h.from,h.to])));
// move down from line0 into table, then free cursor
ed.setCaret({line:0,seg:0,off:2}); ed.moveV(1); console.log('after down', ed.caret); ed.moveV(1); console.log('after down2', ed.caret);
ed.docEnd(); ed.moveV(1); console.log('end+down', ed.caret); ed.moveV(1); console.log('end+down2', ed.caret); ed.insertText('仮想行に書く'); console.log(dump());
// marks
ed.anchor={line:0,seg:0,off:0}; ed.caret={line:0,seg:0,off:2,vcol:null,vrow:0}; ed.toggleMark(FZ.M.BOLD); console.log('marks0', ed.doc.lines[0].segs[0].marks.join(''));
console.log(FZ.serialize(ed.doc));
// find
console.log('find', ed.find('セル'), ed.sel());
console.log('md:\n'+FZ.toMarkdown(ed.doc));
