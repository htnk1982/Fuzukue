const { chromium } = require('playwright');
const out = '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  let fails = 0; const L = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => (l.attrs.list ? `[${l.attrs.list.kind}${l.attrs.list.level}]` : '') + l.segs.map(s => s.text).join('|')));
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); d.lines = [FZ.newLine('')]; FZ.app.ed.setDoc(d); FZ.app.render(); });
  // 1) 三体系：数字見出し Ⅰ（題）→ 数字見出し 1.（段落レベル、Tab で 2 段目）→ 箇条書き（見出しの本文開始位置）→ 入れ子（親の本文開始位置）、→ は同じ階層、空項目 Enter で戻る
  await page.evaluate(() => { FZ.app.ed.mutate('', () => { const f = FZ.app.ed.doc.format; f.scheme = ['Ⅰ', '1.', '1）', '（1）', '①', 'ア', 'a）', 'ⅰ）']; f.titleLevels = 1; f.bulletScheme = ['■', '・', '‐', '◦', '▪', '▫', '‣', '⁃']; }); });
  await page.keyboard.type('基本方針'); await page.keyboard.press('F4'); await page.keyboard.press('3'); await page.keyboard.press('Enter');
  await page.keyboard.press('F4'); await page.keyboard.press('3'); await page.keyboard.press('Tab'); await page.keyboard.type('現状と課題'); await page.keyboard.press('Enter');
  await page.keyboard.press('F4'); await page.keyboard.press('5'); await page.keyboard.type('項目A'); await page.keyboard.press('Enter'); await page.keyboard.type('項目B');
  await page.keyboard.press('F4'); await page.keyboard.press('t'); await page.keyboard.type('詳細'); await page.keyboard.press('Enter'); await page.keyboard.press('Enter'); await page.keyboard.press('Enter'); // 空項目 Enter ×2 → 上へ戻る
  await page.keyboard.press('F4'); await page.keyboard.press('e'); await page.keyboard.type('結論'); await page.keyboard.press('Enter'); await page.keyboard.press('F4'); await page.keyboard.press('3'); // 数字見出し（直前の数字見出しと同じ 2 段目になる）
  await page.keyboard.type('販売計画');
  console.log(await L());
  const mk = await page.evaluate(() => { const lay = FZ.app.ed.lay; return lay.pages[0].glyphs.filter(g => g.marker).map(g => `${g.line}:${g.text}@${g.col}`); }); console.log('markers', mk.join(' '));
  // 見出し Ⅰ@0、1.@1（本文は 3 から）→ 子 ■@3 → 孫 ・@4、→ は項目と同じ階層（@3）、最後は 2.@1
  const okAlign = mk.some(m => m.startsWith('0:Ⅰ@0')) && mk.some(m => m.startsWith('1:1@1')) && mk.some(m => m.startsWith('2:■@3')) && mk.some(m => m.startsWith('4:・@4')) && mk.some(m => m.startsWith('5:→@3')) && mk.some(m => m.startsWith('6:2@1')); if (!okAlign) { fails++; console.log('FAIL nesting alignment'); }
  // 2) 濃い網掛け＋白文字
  await page.evaluate(() => { const ed = FZ.app.ed; ed.addFill(1, 1, 0, 20, 'dark'); FZ.app.render(); });
  const wh = await page.evaluate(() => document.querySelector('.pgwrap svg .txt text.wh') != null); if (!wh) { fails++; console.log('FAIL white text in dark fill'); }
  // 3) TSV 貼付 → 表
  await page.keyboard.press('Control+End'); await page.keyboard.press('Enter');
  await page.evaluate(() => { const dt = new DataTransfer(); dt.setData('text/plain', '品目\t数量\t備考\nりんご\t12\t長野県産の特選品です\nみかん\t3\t'); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); });
  await page.waitForTimeout(50); const tbl = await page.evaluate(() => ({ rules: FZ.app.ed.doc.rules.filter(r => r.axis === 'v').map(r => r.col), lines: FZ.app.ed.doc.lines.filter(l => l.attrs.cells).map(l => l.segs.map(s => s.col + ':' + s.text).join(' ')) })); console.log('table', JSON.stringify(tbl));
  if (!(tbl.rules.length === 4 && tbl.lines.length === 3)) { fails++; console.log('FAIL tsv table'); }
  // 4) 罫線モードで囲みを描いてセル化する試験は、1.0.10q で罫線を手で引く機能をやめたので外した
  await page.evaluate(() => FZ.app.flush()); await page.waitForTimeout(80);
  await page.screenshot({ path: out + 'feat.png', clip: { x: 0, y: 0, width: 1180, height: 760 } });
  // 既存の表の様式を F4→F6 のフォームから変える（表の中では「表の様式」、外では「表を引く」）
  await page.evaluate(() => { const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 36\n---\n前\n#表 列 0,20,40 様式 格子\n| 品目 | 金額 |\n| りんご | 120 |\n| みかん | -80 |\n後\n'); FZ.app.ed.setDoc(d); FZ.app.render(); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); });
  await page.keyboard.press('F8'); await page.keyboard.press('n'); await page.waitForTimeout(80); /* 1.0.10q：F8（表）→N */
  const tf = await page.evaluate(() => document.getElementById('sub').textContent); if (!/表の様式/.test(tf)) { fails++; console.log('FAIL restyle form', tf.slice(0, 60)); }
  await page.evaluate(() => { const s = document.querySelector('.cyc[data-name="style"]'); s.selectedIndex = (s.selectedIndex + 3) % s.options.length; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.keyboard.press('Enter'); await page.waitForTimeout(100); // 決算表
  const tr = await page.evaluate(() => ({ v: FZ.app.ed.doc.rules.filter(r => r.axis === 'v').map(r => r.kind), fill: FZ.app.ed.doc.fills.map(f => f.shade), tri: FZ.app.ed.doc.lines[3].segs.map(s => s.text).join('|'), al: FZ.app.ed.doc.lines[2].attrs.cellAlign, mode: FZ.app.st.mode }));
  if (!(tr.v.every(k => k === 'none') && tr.fill[0] === 'dark' && /▲80/.test(tr.tri) && tr.al && tr.al[1] === 'right' && tr.mode === 'text')) { fails++; console.log('FAIL restyle applied', tr); }
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 })); await page.keyboard.press('F8'); await page.keyboard.press('n'); await page.waitForTimeout(80);
  const tf2 = await page.evaluate(() => document.getElementById('sub').textContent); if (!/^表列/.test(tf2)) { fails++; console.log('FAIL insert form outside', tf2.slice(0, 40)); } await page.keyboard.press('Escape'); await page.keyboard.press('Escape');
  // レベルと位置は別のボタン：本文の位置を決めて（F8→J）から箇条書きにしても位置は残り、F8→H/J で動き、Tab はレベル（記号）だけを変える。F6→A は本文では何もしない
  await page.evaluate(() => { const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 36\n---\n[番号1]章\n本文の行\n'); FZ.app.ed.setDoc(d); FZ.app.render(); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); });
  const mcol = () => page.evaluate(() => { const r = FZ.app.ed.lay.lineMap[1].segs[0].rows[0]; const g = r.glyphs.filter(x => x.marker && !x.tail); return (g.length ? g.map(x => x.text).join('').trim() : '') + '@' + (g.length ? g[0].col : r.startCol); });
  await page.evaluate(() => FZ.app.run('indent')); await page.waitForTimeout(50); if ((await mcol()) !== '@0' || !/レベルがありません/.test(await page.evaluate(() => FZ.app.st.msg))) { fails++; console.log('FAIL level op on plain', await mcol()); }
  for (let k = 0; k < 3; k++) { await page.keyboard.press('F6'); await page.keyboard.press('j'); } await page.waitForTimeout(50); if ((await mcol()) !== '@3') { fails++; console.log('FAIL pos right on plain', await mcol()); }
  await page.keyboard.press('F4'); await page.keyboard.press('5'); await page.waitForTimeout(50); if ((await mcol()) !== '・@3') { fails++; console.log('FAIL bullet keeps position', await mcol()); }
  await page.keyboard.press('F6'); await page.keyboard.press('h'); await page.waitForTimeout(50); if ((await mcol()) !== '・@2') { fails++; console.log('FAIL pos left on bullet', await mcol()); }
  await page.keyboard.press('Tab'); await page.waitForTimeout(50); if ((await mcol()) !== '‐@2') { fails++; console.log('FAIL Tab changes level only', await mcol()); }
  const stl = await page.evaluate(() => document.getElementById('stStyle').textContent); if (!/位置2固定/.test(stl)) { fails++; console.log('FAIL status shows fixed position', stl); }
  await page.keyboard.press('F6'); await page.keyboard.press('j'); await page.waitForTimeout(50); if ((await mcol()) !== '‐@3') { fails++; console.log('FAIL F6→J', await mcol()); }
  await page.keyboard.press('F6'); await page.keyboard.press('k'); await page.waitForTimeout(50); if ((await mcol()) !== '‐@4') { fails++; console.log('FAIL position auto', await mcol()); }
  console.log(`feat fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
