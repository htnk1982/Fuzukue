/* アプリ側：Markdown 貼付（GFM）→ 引用・コード・リンク・タスクが本文に入り、描画エラーが無いこと。リンクのフォーム・状態行 */
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  let fails = 0;
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); FZ.app.ed.setDoc(d); FZ.app.render(); });
  const md = '## 見出し\n\n本文に[リンク](https://example.com/x)と`code`と~~消し~~。\n\n> 引用\n\n- [ ] やる\n- [x] 済み\n\n```sh\nnpm test\n```\n';
  await page.evaluate((md) => { const dt = new DataTransfer(); dt.setData('text/plain', md); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, md);
  await page.waitForTimeout(60);
  const st = await page.evaluate(() => FZ.app.ed.doc.lines.map(l => JSON.stringify(l.attrs) + '|' + l.segs[0].text + (l.segs[0].links ? ' L=' + l.segs[0].links.map(x => x.url).join(',') : ''))); console.log(st.join('\n'));
  const ok = st.some(x => x.includes('"style":"num","level":1')) && st.some(x => x.includes('L=https://example.com/x')) && st.some(x => x.includes('"quote":1')) && st.some(x => x.includes('"kind":"todo"')) && st.some(x => x.includes('"kind":"done"')) && st.some(x => x.includes('"code":"sh"'));
  if (!ok) { fails++; console.log('FAIL paste mapping'); }
  // 状態行に URL、リンクフォーム
  await page.evaluate(() => { const i = FZ.app.ed.doc.lines.findIndex(l => l.segs[0].links); const l = FZ.app.ed.doc.lines[i].segs[0].links[0]; FZ.app.ed.setCaret({ line: i, seg: 0, off: l.start + 1 }); FZ.app.flush(); });
  const status = await page.evaluate(() => document.getElementById('stStyle').textContent); if (!status.includes('https://example.com/x')) { fails++; console.log('FAIL status url', status); }
  await page.keyboard.press('Control+Shift+L'); await page.waitForTimeout(30); const url = await page.evaluate(() => (document.querySelector('#sub input[name="url"]') || {}).value); if (url !== 'https://example.com/x') { fails++; console.log('FAIL link form', url); }
  await page.fill('#sub input[name="url"]', 'https://example.com/y'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  const url2 = await page.evaluate(() => { const i = FZ.app.ed.doc.lines.findIndex(l => l.segs[0].links); return FZ.app.ed.doc.lines[i].segs[0].links[0].url; }); if (url2 !== 'https://example.com/y') { fails++; console.log('FAIL link set', url2); }
  // リンク文字の途中に入力してもリンク範囲が追従
  await page.keyboard.type('追加'); await page.waitForTimeout(30);
  const lk = await page.evaluate(() => { const i = FZ.app.ed.doc.lines.findIndex(l => l.segs[0].links); const s = FZ.app.ed.doc.lines[i].segs[0]; const l = s.links[0]; return { text: s.text.slice(l.start, l.end), marks: s.marks.slice(l.start, l.end).every(m => m & FZ.M.LINK), outside: !(s.marks[l.end] & FZ.M.LINK) }; }); console.log('link after typing', JSON.stringify(lk));
  if (!(lk.text.includes('追加') && lk.marks && lk.outside)) { fails++; console.log('FAIL link splice'); }
  // 引用・コードの切替、Markdown 書出
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); }); await page.keyboard.press('F6'); await page.keyboard.press('o'); await page.waitForTimeout(20);
  const q = await page.evaluate(() => FZ.app.ed.doc.lines[0].attrs.quote); if (q !== 1) { fails++; console.log('FAIL quote toggle', q); }
  const out = await page.evaluate(() => FZ.toGfm(FZ.app.ed.doc)); console.log(out); if (!(out.includes('> ## （1） 見出し') && out.includes('[リ追加ンク](https://example.com/y)') && out.includes('- [x] 済み') && out.includes('```sh'))) { fails++; console.log('FAIL export'); }
  await page.evaluate(() => FZ.app.flush()); await page.waitForTimeout(60);
  await page.screenshot({ path: '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/gfm-app.png', clip: { x: 0, y: 0, width: 1180, height: 520 } });
  console.log(`gfm-app fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
