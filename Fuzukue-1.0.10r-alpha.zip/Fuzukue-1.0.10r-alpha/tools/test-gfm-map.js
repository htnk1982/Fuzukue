/* GFM ⇄ 文机 の写像：仕様例 672 件を全部通して落ちないこと、代表文書の往復が安定すること */
const fs = require('fs'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-export']) require('../app/js/' + f + '.js'); const FZ = globalThis.FZ;
const ex = JSON.parse(fs.readFileSync(path.join(__dirname, 'gfm-examples.json'), 'utf8'));
let errs = 0, fails = 0;
for (const e of ex) { try { const d = FZ.fromGfm(e.md); const t = FZ.serialize(d); const d2 = FZ.parse(t); const md2 = FZ.toGfm(d2); const d3 = FZ.fromGfm(md2); const md3 = FZ.toGfm(d3); if (md2 !== md3) { fails++; if (fails <= 5) console.log('UNSTABLE:', JSON.stringify(e.md), '\n  md2:', JSON.stringify(md2), '\n  md3:', JSON.stringify(md3)); } FZ.layout(d2); } catch (err) { errs++; if (errs <= 5) console.log('ERR', JSON.stringify(e.md), err.stack.split('\n').slice(0, 2).join(' ')); } }
console.log('spec inputs', ex.length, 'errors', errs, 'unstable round trips', fails);
// 代表文書
const md = fs.readFileSync(path.join(__dirname, 'gfm-sample.md'), 'utf8');
const d = FZ.fromGfm(md); const t = FZ.serialize(d); const t2 = FZ.serialize(FZ.parse(t)); const md2 = FZ.toGfm(FZ.parse(t)); const md3 = FZ.toGfm(FZ.fromGfm(md2));
console.log('fzk stable', t === t2, 'md stable', md2 === md3);
if (md2 !== md3) { const a = md2.split('\n'), b = md3.split('\n'); for (let i = 0; i < Math.max(a.length, b.length); i++) if (a[i] !== b[i]) { console.log('DIFF', i, JSON.stringify(a[i]), JSON.stringify(b[i])); break; } }
// 文机の見本 → GFM → 文机：構造が保たれる
const s = FZ.parse(FZ.sampleText()); const smd = FZ.toGfm(s); const s2 = FZ.fromGfm(smd);
const count = (doc, pred) => doc.lines.filter(pred).length;
console.log('sample→gfm→fzk: headings', count(s, l => /^h\d$/.test(l.attrs.style)), count(s2, l => /^h\d$/.test(l.attrs.style)), 'items', count(s, l => l.attrs.list), count(s2, l => l.attrs.list), 'table rows', count(s, l => l.attrs.cells), count(s2, l => l.attrs.cells), 'figure', count(s, l => l.attrs.figure), count(s2, l => l.attrs.figure));
console.log(`gfm-map fails=${errs + (md2 !== md3 ? 1 : 0) + (t !== t2 ? 1 : 0)}`);
