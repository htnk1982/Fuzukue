/* GFM 仕様例（spec.txt の 672 例）との照合。examples.json は tools/gfm-examples.json */
const fs = require('fs'); const path = require('path');
require('../app/js/fz-entities.js'); require('../app/js/fz-md.js'); const FZ = globalThis.FZ;
const ex = JSON.parse(fs.readFileSync(path.join(__dirname, 'gfm-examples.json'), 'utf8'));
const norm = s => s.replace(/\s+$/g, '').replace(/>\n</g, '><').replace(/\n/g, '');
let pass = 0; const fails = {}; const show = process.argv[2];
for (const e of ex) { const ext = e.ext.split(/\s+/); const opts = { gfmAutolink: ext.includes('autolink'), table: ext.includes('table'), strikethrough: ext.includes('strikethrough') }; let out; try { out = FZ.md.toHtml(FZ.md.parse(e.md, opts), { tagfilter: ext.includes('tagfilter') }); } catch (err) { out = 'ERR ' + err.message + '\n' + (err.stack || '').split('\n')[1]; } if (norm(out) === norm(e.html)) pass++; else { (fails[e.section] = fails[e.section] || []).push({ e, out }); } }
console.log('examples', ex.length, 'pass', pass, 'fail', ex.length - pass);
for (const [s, f] of Object.entries(fails)) { console.log(' ', s, f.length); if (show && (show === 'all' || s.includes(show))) for (const { e, out } of f.slice(0, 6)) console.log('---- md:\n' + e.md + '---- expected:\n' + e.html + '---- got:\n' + out); }
