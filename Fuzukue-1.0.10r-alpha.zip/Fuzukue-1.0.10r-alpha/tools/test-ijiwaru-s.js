/* いじわるテスト報告 S 群の回帰試験（合否あり）：黙って消さない・開ける・壊れない・誤爆しない */
for (const f of ['fz-core', 'fz-figure', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info) : '')); } };
const H = '#fzk 2\n文字数: 40\n行数: 36\n---\n';
const texts = d => d.lines.map(l => l.segs.map(s => s.text).join('|'));
const rt = t => { const d = FZ.parse(t); const s1 = FZ.serialize(d); const s2 = FZ.serialize(FZ.parse(s1)); return { d, s1, stable: s1 === s2 }; };

// S-1 認識できない [ ] は本文
{ const d = FZ.parse(H + '[重要]この件は至急\n[参考]URL\n[]空\n[項目1 謎]項目は残る\n[見出し]見出し');
  ok(texts(d)[0] === '[重要]この件は至急', 'S-1 [重要] kept', texts(d)[0]); ok(texts(d)[1] === '[参考]URL', 'S-1 [参考] kept'); ok(texts(d)[2] === '[]空', 'S-1 [] kept');
  ok(d.lines[3].attrs.list && texts(d)[3] === '項目は残る', 'S-1 partial token', d.lines[3]); ok(d.lines[4].attrs.style === 'num' && d.lines[4].attrs.level === 0, 'S-1 heading', d.lines[4].attrs);
  const r = rt(H + '[重要]x'); ok(r.stable && texts(r.d)[0] === '[重要]x', 'S-1 round trip'); }
// S-2 # 行
{ const d = FZ.parse(H + '# 見出しのつもり\n## 二番目\n### 三\n#### 四\n#コメント？\n#謎 指示\n#fzk 2\n本文');
  const t = texts(d); ok(d.lines[0].attrs.style === 'num' && d.lines[0].attrs.level === 0 && t[0] === '見出しのつもり', 'S-2 # heading', [d.lines[0].attrs, t[0]]);
  ok(d.lines[1].attrs.level === 1 && d.lines[2].attrs.level === 2 && d.lines[3].attrs.level === 3 && [1, 2, 3].every(k => d.lines[k].attrs.style === 'num'), 'S-2 ## ### ####', d.lines.slice(1, 4).map(l => l.attrs));
  ok(t[4] === '#コメント？' && t[5] === '#謎 指示' && t[6] === '#fzk 2', 'S-2 unknown # kept as text', t); ok(d.lines.length === 8, 'S-2 line count', d.lines.length); }
// S-3 URL
{ let d; try { d = FZ.parse(H + '<リンク https://x.jp/%E4>壊れた</リンク> <リンク https://x.jp/%E4%BE%8B%2F?a=1>符号化済み</リンク> <リンク https://x.jp/a%20b%3Cc%3E>空白</リンク>'); } catch (e) { ok(false, 'S-3 throws', e.message); }
  if (d) { const L = d.lines[0].segs[0].links; ok(L[0].url === 'https://x.jp/%E4', 'S-3 keep %E4', L[0]); ok(L[1].url === 'https://x.jp/%E4%BE%8B%2F?a=1', 'S-3 keep encoded', L[1]); ok(L[2].url === 'https://x.jp/a b<c>', 'S-3 decode only ws/<>', L[2]);
    const s1 = FZ.serialize(d); ok(s1.includes('<リンク https://x.jp/%E4%BE%8B%2F?a=1>') && s1.includes('<リンク https://x.jp/a%20b%3Cc%3E>'), 'S-3 serialize', s1.split('\n---\n')[1]); ok(FZ.serialize(FZ.parse(s1)) === s1, 'S-3 stable'); } }
// S-4 制御文字
{ const md = '# 制御\u0001文字\u000B\u0000\u007F ]]> & < >\n\n本文\u001F \uD800 孤立';
  const d = FZ.fromGfm(md); ok(texts(d)[0] === '制御文字\uFFFD ]]> & < >', 'S-4 clean on import (NUL は GFM 仕様で U+FFFD)', texts(d)[0]); ok(!/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/.test(texts(d).join('')), 'S-4 no controls');
  const d2 = FZ.parse(H + 'a\u0001b\u000Bc'); ok(texts(d2)[0] === 'abc', 'S-4 clean on fzk parse', texts(d2)[0]);
  const raw = FZ.newDoc(); raw.lines = [{ segs: [FZ.newSeg(0, 'x\u0001y\u000By')], attrs: {} }]; raw.lines[0].segs[0].marks = [0, 0, 0, 0, 0]; raw.title = 't\u0002';
  const dx = FZ.toDocx(FZ.normalize(raw)); const px = FZ.toPptx(FZ.normalize(raw)); ok(dx.length > 1000 && px.length > 1000, 'S-4 export runs');
  ok(FZ.xmlEsc('a\u0001b\u000Bc\uD800d') === 'abcd', 'S-4 xmlEsc strips'); }
// S-5 Office の Target
{ ok(FZ.uriForOffice('https://x.jp/a b') === 'https://x.jp/a%20b', 'S-5 space'); ok(FZ.uriForOffice('https://x.jp/%E4%BE%8B?a=1&b=2') === 'https://x.jp/%E4%BE%8B?a=1&b=2', 'S-5 keep encoded'); ok(FZ.uriForOffice('https://例え.jp/あ"') === 'https://%E4%BE%8B%E3%81%88.jp/%E3%81%82%22', 'S-5 non-ascii');
  const d = FZ.parse(H + '<リンク https://x.jp/a%20b>空白</リンク>'); const files = FZ.zip ? null : null; const bytes = FZ.toDocx(d); const str = Buffer.from(bytes).toString('latin1'); ok(str.includes('Target="https://x.jp/a%20b"'), 'S-5 docx rels target', str.match(/Target="https[^"]*"/g)); }
// S-6 貼付の判定と改行
{ const mail = '山田様\nお世話になっております。\n下記の件、ご確認ください。\n- 納期：11/5\n以上、よろしくお願いします。\n';
  ok(!FZ.looksLikeMarkdown(mail), 'S-6 mail not markdown'); ok(FZ.looksLikeMarkdown('- a\n- b\n- c'), 'S-6 list is markdown'); ok(FZ.looksLikeMarkdown('## 見出し\n\n本文\n\n- a\n- b'), 'S-6 ai output'); ok(!FZ.looksLikeMarkdown('一行目\n二行目\n三行目'), 'S-6 plain');
  ok(!FZ.looksLikeMarkdown('前 [リンク](https://x.jp) 後\n\n2行目'), 'S-6 inline only → not auto'); ok(FZ.looksLikeMarkdown('| a | b |\n|---|---|\n| 1 | 2 |'), 'S-6 table');
  const d = FZ.fromGfm('# 章\n一行目\n二行目\n\n- 項目\n  続き行', null, { fragment: true, hardBreaks: true }); const t = texts(d);
  ok(d.lines[0].attrs.style === 'num' && !d.lines[0].attrs.align, 'S-6 fragment: no title', d.lines[0].attrs); ok(t[1] === '一行目' && t[2] === '二行目', 'S-6 hard breaks', t); const ci = t.indexOf('続き行'); ok(ci > 0 && d.lines[ci].attrs.list && d.lines[ci].attrs.list.kind === 'cont', 'S-6 list continuation line', d.lines[ci]);
  const d2 = FZ.fromGfm('# 章\n一行目\n二行目'); ok(d2.lines[0].attrs.style === 'title' && texts(d2)[1] === '一行目二行目', 'S-6 file: GFM semantics kept', texts(d2)); }
// S-7 列境界
{ const d = FZ.parse(H + '#表 列 40,0,10 様式 格子\n| a | b |\n| c | d |\n#表 列 abc 様式 格子\n| e | f |\n#表 列 0,50,-3,10 様式 格子\n| g | h |');
  const t = texts(d); ok(t[0] === 'a|b' && t[1] === 'c|d', 'S-7 unsorted bounds keep cells', t); ok(d.lines[0].segs.map(s => s.col).join(',') === '0,10', 'S-7 sorted', d.lines[0].segs.map(s => s.col));
  ok(t[2] === 'e | f' || t[2] === 'e|f', 'S-7 invalid bounds fallback', t[2]); ok(d.lines[3].segs.map(s => s.col).join(',') === '0,10', 'S-7 clamp', d.lines[3].segs.map(s => s.col));
  ok(!d.rules.some(r => r.axis === 'h' && r.from > r.to), 'S-7 no reversed rules');
  const d2 = FZ.parse(H + '#罫 横 50-10 細\n本文\n#罫 縦 99 ×0 細\n#網 10-5 ×2 薄\n#網 0-40 ×0 薄\n本文'); ok(d2.rules.every(r => r.from <= r.to) && d2.rules.length === 1 && d2.fills.length === 1 && d2.fills[0].col === 5 && d2.fills[0].cols === 5, 'S-7 rule/fill sanitize', [d2.rules, d2.fills]); }
// S-8 エスケープ
{ const d = FZ.parse(H + '\\\\x 二重\nC:\\Users\\yuta\\文書\n\\\\<太字>a</太字>\n\\[角]\n\\#井桁\n\\<山\n\\x そのまま\na \\| b\n\\\\\\<山');
  const t = texts(d); ok(t[0] === '\\x 二重', 'S-8 \\\\x', t[0]); ok(t[1] === 'C:\\Users\\yuta\\文書', 'S-8 windows path', t[1]); ok(t[2] === '\\a' && d.lines[2].segs[0].marks[1] & FZ.M.BOLD && !(d.lines[2].segs[0].marks[0] & FZ.M.BOLD), 'S-8 escaped backslash then tag', [t[2], d.lines[2].segs[0].marks]);
  ok(t[3] === '[角]' && t[4] === '#井桁' && t[5] === '<山' && t[6] === '\\x そのまま' && t[7] === 'a | b' && t[8] === '\\<山', 'S-8 escapes', t);
  for (const txt of ['\\x', 'C:\\Users\\a', 'a\\<b', 'a\\\\b', '\\', '\\\\', '[x]y', '#x', '|x', 'a|b', '<太字>', 'x\\', '\\[x]']) { const doc = FZ.newDoc(); doc.lines = [{ segs: [FZ.newSeg(0, txt)], attrs: {} }]; doc.lines[0].segs[0].marks = Array.from(txt, () => 0); const s1 = FZ.serialize(FZ.normalize(doc)); const back = texts(FZ.parse(s1))[0]; ok(back === txt, 'S-8 round trip ' + JSON.stringify(txt), [s1.split('\n---\n')[1], back]); }
  // 表の中の | と、表の直後の | 行
  const doc = FZ.fromGfm('| a \\| b | c |\n|---|---|\n| 1 | 2 |\n\n| で始まる段落'); const s1 = FZ.serialize(doc); const back = FZ.parse(s1); ok(texts(back)[0] === 'a | b|c' && texts(back)[3] === '| で始まる段落' && FZ.serialize(back) === s1, 'S-8 table pipes', [texts(back), s1.split('\n---\n')[1]]); }
// 既存の見本が変わらない
{ for (const f of ['見本.fzk', '新聞風見本.fzk']) { const t = require('fs').readFileSync(__dirname + '/../samples/' + f, 'utf8'); const r = rt(t); ok(r.stable, 'sample stable ' + f); ok(r.s1.replace(/\s+$/, '') === t.replace(/\s+$/, ''), 'sample unchanged ' + f, r.s1.split('\n').filter((l, i) => l !== t.split('\n')[i]).slice(0, 3)); } }
console.log(`ijiwaru-s fails=${fails}`, 'errors:', errors);
