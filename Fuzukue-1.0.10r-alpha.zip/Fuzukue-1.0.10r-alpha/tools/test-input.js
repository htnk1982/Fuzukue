/* 入力の総点検：実キーイベント＋CDPによるIME合成で、モデル・textarea・表示位置の整合を各ステップで検査 */
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 820 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  const cdp = await page.context().newCDPSession(page);
  let fails = 0; const steps = [];
  const check = async (label) => {
    const r = await page.evaluate(() => {
      const ed = FZ.app.ed, st = FZ.app.st, ta = document.getElementById('ta'); const out = { ok: true, msgs: [] };
      const seg = ed.seg(); if (!st.composing && ta.value !== seg.text) { out.ok = false; out.msgs.push(`ta.value≠seg.text  ta="${ta.value}" seg="${seg.text}"`); }
      const s = ed.sel(); if (!st.composing && !s && ta.selectionEnd !== ed.caret.off) { out.ok = false; out.msgs.push(`ta.sel ${ta.selectionEnd} ≠ caret.off ${ed.caret.off}`); }
      const xy = ed.xy(); if (!xy) { out.ok = false; out.msgs.push('xy null'); }
      else if (!(ed.caret.vrow > 0)) { const es = ed.lay.pages[xy.page].rowmap.get(xy.y) || []; if (!es.some(e => e.line === ed.caret.line && e.seg === ed.caret.seg)) { out.ok = false; out.msgs.push(`caret drawn on row of other line: y=${xy.y} caret.line=${ed.caret.line} rows=${es.map(e => e.line)}`); } }
      if (document.activeElement !== ta && !st.dialogOpen) { out.ok = false; out.msgs.push('textarea not focused: ' + (document.activeElement && document.activeElement.id)); }
      out.lines = ed.doc.lines.map(l => l.segs.map(s => s.text).join('|')); out.caret = JSON.stringify(ed.caret); return out;
    });
    if (!r.ok) { fails++; console.log('FAIL', label, r.msgs.join(' ; '), '\n   lines=', JSON.stringify(r.lines), 'caret=', r.caret); }
    steps.push(label); return r;
  };
  const reset = async (lines) => page.evaluate((lines) => { localStorage.clear(); const d = FZ.newDoc(); d.lines = lines.map(t => FZ.newLine(t)); FZ.app.ed.setDoc(d); FZ.app.st.mode = 'text'; FZ.app.render(); document.getElementById('ta').focus(); }, lines);
  const ime = async (text, final) => { for (let i = 1; i <= text.length; i++) { await cdp.send('Input.imeSetComposition', { text: text.slice(0, i), selectionStart: i, selectionEnd: i }); await page.waitForTimeout(5); } if (final !== null) { await cdp.send('Input.imeSetComposition', { text: final, selectionStart: final.length, selectionEnd: final.length }); await cdp.send('Input.insertText', { text: final }); } };
  const L = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => l.segs.map(s => s.text).join('|')));

  // A. ASCII 連打 + Enter/Backspace
  await reset(['']); await page.keyboard.type('abc def'); await check('A1 type'); await page.keyboard.press('Enter'); await check('A2 enter'); await page.keyboard.type('xyz'); await page.keyboard.press('Home'); await page.keyboard.press('Backspace'); await check('A3 join'); 
  let l = await L(); if (l.join('\n') !== 'abc defxyz') { fails++; console.log('FAIL A3 content', l); }
  // B. IME 途中挿入・取消・連続
  await reset(['前半後半']); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 2 }));
  await ime('にほんご', '日本語'); await check('B1 ime insert'); l = await L(); if (l[0] !== '前半日本語後半') { fails++; console.log('FAIL B1', l); }
  await ime('きゃんせる', ''); await check('B2 ime cancel'); l = await L(); if (l[0] !== '前半日本語後半') { fails++; console.log('FAIL B2', l); }
  await ime('れんぞく', '連続'); await ime('にゅうりょく', '入力'); await check('B3 ime twice'); l = await L(); if (l[0] !== '前半日本語連続入力後半') { fails++; console.log('FAIL B3', l); }
  await page.keyboard.press('Control+z'); await check('B4 undo'); l = await L(); if (l[0] !== '前半日本語連続後半') { fails++; console.log('FAIL B4 undo should remove one composition', l); }
  // C. 選択範囲を IME で置換
  await reset(['あいうえお']); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 1 })); await page.keyboard.press('Shift+ArrowRight'); await page.keyboard.press('Shift+ArrowRight'); await check('C0 sel');
  await ime('か', '換'); await check('C1 ime replace sel'); l = await L(); if (l[0] !== 'あ換えお') { fails++; console.log('FAIL C1', l); }
  // C2. 行をまたぐ選択を IME で置換（keydown 229 → prepareTyping）
  await reset(['一行目', '二行目']); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 1 })); await page.keyboard.press('Shift+ArrowDown');
  await cdp.send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Process', code: 'KeyA', windowsVirtualKeyCode: 229 });
  await ime('ぬ', '抜'); await check('C2 ime cross-line'); l = await L(); if (l.join('\n') !== '一抜行目') { fails++; console.log('FAIL C2', l); }
  // D. 上書き + IME
  // E. 空行の連続でクリック・入力
  await reset(['一', '', '', '', '二']); 
  const rowPx = await page.evaluate(() => { const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = r.width / g.W; return { x: r.left + (g.left + 3 * g.cw) * sc, y: (row) => r.top + (g.top + (g.bodyTop + row + 0.5) * g.ch) * sc }; });
  for (const row of [1, 2, 3]) { await page.mouse.click(rowPx.x, await page.evaluate((row) => { const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = r.width / g.W; return r.top + (g.top + (g.bodyTop + row + 0.5) * g.ch) * sc; }, row)); const r = await check('E click row ' + row); const c = JSON.parse(r.caret); if (c.line !== row) { fails++; console.log('FAIL E click row', row, 'caret', r.caret); } }
  await page.keyboard.type('x'); await check('E type after click'); l = await L(); if (l[3] !== '　　　x') { fails++; console.log('FAIL E type', l); }
  // F. 箇条書き：Enter で継続、空項目 Enter で終了、Tab 階層
  await reset(['']); await page.evaluate(() => FZ.app.run('item')); await page.keyboard.type('a'); await page.keyboard.press('Enter'); await page.keyboard.press('Tab'); await page.keyboard.type('b'); await page.keyboard.press('Enter'); await page.keyboard.press('Enter'); await page.keyboard.press('Enter'); await page.keyboard.type('c'); await check('F list');
  const attrs = await page.evaluate(() => FZ.app.ed.doc.lines.map(x => JSON.stringify(x.attrs))); if (!(attrs[0].includes('list') && attrs[1].includes('"level":1') && !attrs[2].includes('list'))) { fails++; console.log('FAIL F attrs', attrs, await L()); }
  // G. 折返し段落の途中で Enter → 前後が分かれる。Delete で再結合
  await reset(['あ'.repeat(45) + 'い'.repeat(10)]); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 45 })); await page.keyboard.press('Enter'); await check('G1 split'); l = await L(); if (!(l.length === 2 && l[1] === 'い'.repeat(10))) { fails++; console.log('FAIL G1', l.map(x => x.length)); }
  await page.keyboard.press('ArrowUp'); await page.keyboard.press('End'); await page.keyboard.press('Delete'); await check('G2 delete-join'); l = await L(); if (l.length !== 1) { fails++; console.log('FAIL G2', l.length); }
  // H. 右端の自由カーソル → 入力で空白詰め、Enter で詰めない
  await reset(['短い']); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 2, vcol: 5 })); await check('H1 void right'); await page.keyboard.type('z'); await check('H2 typed'); l = await L(); if (l[0] !== '短い　　　z') { fails++; console.log('FAIL H2', JSON.stringify(l)); }
  for (let i = 0; i < 4; i++) await page.keyboard.press('ArrowRight'); await page.keyboard.press('Enter'); await check('H3 enter in void'); l = await L(); if (l[0] !== '短い　　　z' || l.length !== 2) { fails++; console.log('FAIL H3', JSON.stringify(l)); }
  // I. 表のセル：Tab 移動、IME、Enter で行追加
  await reset(['']); await page.evaluate(() => FZ.app.ed.insertTable(2, 1, [10, 30], false)); await page.keyboard.type('A'); await page.keyboard.press('Tab'); await ime('せる', 'セル'); await check('I1 table ime'); await page.keyboard.press('Enter'); await page.keyboard.type('B'); await check('I2 table enter'); l = await L(); if (!(l[0] === 'A|セル' && l[1] === '|B')) { fails++; console.log('FAIL I', l); }
  // J. 上下移動の目標桁、PageDown
  await reset(['あいうえおかきくけこ', 'あ', 'あいうえおかきくけこ']); await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 7 })); await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowDown'); const r2 = await check('J goal col'); if (JSON.parse(r2.caret).off !== 7) { fails++; console.log('FAIL J goal col', r2.caret); }
  // K. 高速連打（keydown/keyup 交互）
  await reset(['']); await page.keyboard.type('the quick brown fox 1234567890', { delay: 0 }); await check('K fast'); l = await L(); if (l[0] !== 'the quick brown fox 1234567890') { fails++; console.log('FAIL K', l); }
  // L. 修飾付き入力 → 表示後も位置整合
  await reset(['']); await page.keyboard.press('Control+b'); await page.keyboard.type('Bold'); await page.keyboard.press('Control+b'); await page.keyboard.type('普通'); await check('L marks'); const mk = await page.evaluate(() => FZ.app.ed.doc.lines[0].segs[0].marks.join('')); if (mk !== '111100') { fails++; console.log('FAIL L marks', mk); }
  // M. ダイアログを開閉してもフォーカスが戻る
  await page.keyboard.press('F9'); await page.keyboard.press('f'); await page.waitForTimeout(100); await page.keyboard.press('Escape'); await page.waitForTimeout(100); await page.keyboard.type('x'); await check('M dialog focus'); l = await L(); if (l[0] !== 'Bold普通x') { fails++; console.log('FAIL M', l); }
  // N. 状態行をクリックしてもフォーカス維持
  await page.click('#stPos'); await page.keyboard.type('y'); await check('N status click'); l = await L(); if (l[0] !== 'Bold普通xy') { fails++; console.log('FAIL N', l); }
  // O. 見本の全行でクリック位置→行の一致
  await page.evaluate(() => { FZ.app.ed.setDoc(FZ.parse(FZ.sampleText())); FZ.app.render(); document.getElementById('ta').focus(); });
  const mism = await page.evaluate(() => { const ed = FZ.app.ed; let bad = []; const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = ed.lay.geo; const sc = r.width / g.W; for (const [y, es] of ed.lay.pages[0].rowmap) { for (const e of es) { const col = (e.startCol + e.endCol) / 2; const pos = FZ.xyToPos(ed.lay, 0, y, col); if (!pos || pos.line !== e.line || pos.seg !== e.seg) bad.push({ y, line: e.line, got: pos }); } } return bad; });
  if (mism.length) { fails++; console.log('FAIL O xyToPos', mism.slice(0, 5)); }
  console.log(`steps=${steps.length} fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
