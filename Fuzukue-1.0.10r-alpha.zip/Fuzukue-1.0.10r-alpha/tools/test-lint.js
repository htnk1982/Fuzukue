/* 構造の検査（1.0.10b.9）：壊れ方が静かなものを機械で見張る
 * 1. 読み込み用 Worker の束ね（fz-worker-src.js）が今のソースと同じか（古いと、開いた文書だけ古い解析で読まれる）
 * 2. 行末の // 注釈に、コードが飲み込まれていないか（1 行に詰める書き方の事故：注釈のあとに足した文が実行されない）
 * 3. すべての app/js が構文として正しいか
 * 4. 版の番号が はじめに.md と揃っているか */
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..'); let fails = 0; const bad = (n, i) => { fails++; console.log('FAIL', n, i === undefined ? '' : JSON.stringify(i).slice(0, 400)); };
// 1
{ delete require.cache[require.resolve('./build-worker.js')]; const { out, file } = require('./build-worker.js'); const cur = fs.readFileSync(file, 'utf8'); if (cur !== out) bad('worker bundle is stale: run node tools/build-worker.js'); }
// 2・3：acorn（開発機にあれば）で注釈を取り出し、注釈の中身が「コードとして読める文」なら疑う
let acorn = null; for (const p of ['acorn', '/opt/npm-tools/node_modules/acorn', '/opt/node-tools/node_modules/acorn']) { try { acorn = require(p); break; } catch { } }
const jsFiles = fs.readdirSync(path.join(root, 'app/js')).filter(f => f.endsWith('.js') && f !== 'fz-worker-src.js');
if (!acorn) console.log('SKIP comment/syntax lint (acorn not found)');
else {
  const codeLike = txt => { const t = txt.trim(); if (t.length < 12 || !/[;=(){}]/.test(t) || /[　-鿿＀-￯]/.test(t.replace(/(['"`]).*?\1/g, ''))) return false; // 和文の注釈は対象外（文字列の中の和文は除いて判定）
    try { const ast = acorn.parse(t, { ecmaVersion: 'latest', sourceType: 'script', allowReturnOutsideFunction: true }); const kinds = ast.body.map(n => n.type); const strong = ast.body.some(n => /Declaration|IfStatement|ForStatement|ForOfStatement|WhileStatement|ReturnStatement/.test(n.type) || (n.type === 'ExpressionStatement' && /Call|Assignment|Update/.test(n.expression.type))); return strong && ast.body.length >= 1 && kinds.length; } catch { return false; } };
  const tailCode = txt => { const t = txt.replace(/^[\s\S]*[\u3000-\u9fff\uff00-\uffef]/, ''); return /[;}]/.test(t) && codeLike(t); }; // 尻尾は「;」か「}」のある文だけ（式に見える数式の注釈を拾わない）
  for (const f of jsFiles) { const src = fs.readFileSync(path.join(root, 'app/js', f), 'utf8'); const comments = [];
    try { acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script', onComment: (block, text, start) => { if (!block) comments.push({ text, start }); } }); } catch (e) { bad('syntax ' + f, e.message); continue; }
    for (const c of comments) if (codeLike(c.text) || tailCode(c.text)) { /* 和文の注釈のあとに続いた ASCII の尻尾もコードとして読めるか見る */ const line = src.slice(0, c.start).split('\n').length; bad(`code swallowed by // comment? ${f}:${line}`, c.text.slice(0, 160)); } }
  // 試験の側の正しさ：わざと飲み込ませた例を見つけられるか
  if (codeLike(' 説明：f(x) を呼ぶ ')) bad('lint self-check (ja)'); if (!codeLike(' const x = f(1); g(x);')) bad('lint self-check (code)'); { const t = ' 説明の文 const y = h(2); k(y);'; if (!tailCode(t)) bad('lint self-check (tail)'); if (tailCode(' 点。page = R·(u,v)')) bad('lint self-check (formula)'); }
}
// 4
{ const core = fs.readFileSync(path.join(root, 'app/js/fz-core.js'), 'utf8'); const v = (core.match(/VERSION\s*=\s*'([^']+)'/) || [])[1]; const readme = fs.readFileSync(path.join(root, 'はじめに.md'), 'utf8'); const base = String(v).replace(/-alpha$/, ''); if (!v || !readme.includes(base)) bad('version mismatch fz-core vs はじめに.md', [v]); }
console.log(`lint fails=${fails}`); process.exit(fails ? 1 : 0);
