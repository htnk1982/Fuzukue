/* メニュー（1.0.10b の作り直し）：F キー＝グループ、タイルの 1 文字で実行、フォームは属するグループに戻る、1 段の帯、キーの道筋は表から */
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 800 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + require('path').resolve(__dirname, '../app/index.html') + ''); await page.waitForTimeout(400);
  let fails = 0; const bad = (n, i) => { fails++; console.log('FAIL', n, i === undefined ? '' : JSON.stringify(i)); };
  const subText = () => page.evaluate(() => document.getElementById('sub').textContent.trim());
  const ev = f => page.evaluate(f);
  await ev(() => { localStorage.clear(); FZ.app.ed.setDoc(FZ.newDoc()); FZ.app.ed.insertText('本文'); FZ.app.render(); });
  // F キーの並び（取説・ﾌｧｲﾙ・…・表示）。印刷・保存は F キーに無い
  const caps = await ev(() => [...document.querySelectorAll('#fkeys .fk')].map(d => d.textContent));
  if (caps.join(',') !== 'F1取説,F2ﾌｧｲﾙ,F3編集,F4構造,F5文字,F6配置,F7挿入,F8表,F9書式,F10表示') bad('F-key captions', caps);
  // 倍率フォーム → 適用 → 子メニューは表示のグループ
  await ev(() => FZ.app.openForm('zoom')); await page.waitForTimeout(50); await page.fill('#sub input[name="pct"]', '150'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  const z = await ev(() => FZ.app.st.zoom); if (z !== 1.5) bad('zoom pct', z); if (!(await ev(() => (document.querySelector('#ms_zoom') || {}).value === '1.5')) || (await ev(() => FZ.app.st.group)) !== 'view') bad('view group after zoom form', await subText());
  await ev(() => FZ.app.openForm('zoom')); await page.waitForTimeout(50); await page.click('#sub button[data-act="width"]'); await page.waitForTimeout(50);
  if ((await ev(() => FZ.app.st.zoom)) !== 'width') bad('zoom width');
  // F4 構造 → 構え。F6 配置に切り替わり構え、クリックで実行しても行は残る
  await page.keyboard.press('F4'); await page.waitForTimeout(40); if (!(await ev(() => FZ.app.st.group === 'struct' && FZ.app.st.armed)) || !(await subText()).includes('本文')) bad('F4 arms struct group');
  await page.keyboard.press('F6'); await page.waitForTimeout(50); if (!(await ev(() => FZ.app.st.group === 'line' && FZ.app.st.armed))) bad('F6 arms line group');
  if (!(await ev(() => document.querySelector('#fkeys .fk.on.armed') && document.querySelector('#fkeys .fk.on.armed').textContent === 'F6配置'))) bad('F6 key cap lit and armed');
  await page.click('#sub .ch[data-cmd=alignC]'); await page.waitForTimeout(50);
  if ((await ev(() => FZ.app.ed.line().attrs.align)) !== 'center') bad('alignC by click'); if ((await ev(() => FZ.app.st.group)) !== 'line') bad('group stays after click'); if ((await ev(() => FZ.app.st.armed)) !== false) bad('disarmed after click');
  // 構えたまま 1 文字キー → 実行して構えを解く。構えていなければ文字が入る
  await page.keyboard.press('F6'); await page.keyboard.press('9'); await page.waitForTimeout(40); if ((await ev(() => FZ.app.ed.line().attrs.align)) !== 'right') bad('key 9 → right'); if (await ev(() => FZ.app.st.armed)) bad('disarmed after key');
  await page.keyboard.type('9'); await page.waitForTimeout(40); if (!(await ev(() => FZ.app.ed.line().segs[0].text)).includes('9')) bad('typing 9 inserts when not armed');
  // Esc で構えを解く（行は残る）
  await page.keyboard.press('F5'); await page.keyboard.press('Escape'); await page.waitForTimeout(30); if (!(await ev(() => FZ.app.st.group === 'marks' && !FZ.app.st.armed))) bad('Esc disarms, row stays');
  // F6 → Y で見出し飾り（構えたまま）。項目を実行すると配置に戻る。Esc・「戻る」でも戻る（1.0.10q：見出し飾りは F6、表の様式は F8 表の下）
  await page.keyboard.press('F6'); await page.keyboard.press('y'); await page.waitForTimeout(50);
  if (!(await ev(() => FZ.app.st.group === 'head' && FZ.app.st.armed))) bad('F6→Y head group armed', await ev(() => [FZ.app.st.group, FZ.app.st.armed]));
  if (!(await ev(() => document.querySelector('#fkeys .fk.on') && document.querySelector('#fkeys .fk.on').textContent.startsWith('F6')))) bad('F6 lit in subgroup');
  await page.keyboard.press('1'); await page.waitForTimeout(50); if ((await ev(() => FZ.app.st.group)) !== 'line') bad('back to line after deco', await ev(() => FZ.app.st.group));
  await page.keyboard.press('F6'); await page.keyboard.press('y'); await page.keyboard.press('Escape'); await page.waitForTimeout(30); if ((await ev(() => FZ.app.st.group)) !== 'line') bad('Esc returns to line');
  await page.keyboard.press('F8'); await page.keyboard.press('u'); await page.waitForTimeout(30); await page.click('#sub .ch.back'); await page.waitForTimeout(30); if ((await ev(() => FZ.app.st.group)) !== 'tedit') bad('back tile returns to 表 (F8)');
  // F9 → F 書式 → 適用 → 書式のグループ
  await page.keyboard.press('F9'); await page.keyboard.press('f'); await page.waitForTimeout(80); if ((await ev(() => FZ.app.st.form)) !== 'format') bad('F9→F format form');
  await page.click('#sub button[data-act="apply"]'); await page.waitForTimeout(80); if (!(await subText()).includes('用紙') || (await ev(() => FZ.app.st.group)) !== 'fmt') bad('fmt group after format apply', await subText());
  // F3 → F 検索置換（編集のグループ）
  await page.keyboard.press('F3'); await page.keyboard.press('f'); await page.waitForTimeout(50); if (!['find', 'replace'].includes(await ev(() => FZ.app.st.form))) bad('F3→F find form', await ev(() => FZ.app.st.form)); await page.keyboard.press('Escape');
  // 表から作るキーの道筋（使い方・コマンド一覧・案内の文）
  const keys = await ev(() => ({ bold: FZ.app.keysOf('bold'), save: FZ.app.keysOf('save'), print: FZ.app.keysOf('print'), art: FZ.app.keysOf('hd:article'), hr: FZ.app.keysOf('hr'), rule: FZ.app.keysOf('ruleMode'), scheme: FZ.app.keysOf('scheme') }));
  if (keys.bold !== 'F5→1 / Ctrl+B' || !/F2→S/.test(keys.save) || !/F12/.test(keys.save) || !/Ctrl\+S/.test(keys.save) || keys.print !== 'F2→P / Ctrl+P' || !/F7→K/.test(keys.art) || !/F6→Y→U/.test(keys.art) || keys.hr !== 'F7→L' || keys.rule !== '' || keys.scheme !== 'F9→W') bad('derived key paths', keys);
  // 表の整合：項目のコマンドが全部ある、グループの中でキーが重ならない、主なグループのタイルは全部ピクトグラム付き
  const integ = await ev(() => { const G = FZ.app.GROUPS; const out = []; for (const [n, g] of Object.entries(G)) { const ks = g.items.filter(i => i.cmd).map(i => i.key.toLowerCase()); const dup = ks.filter((k, i) => ks.indexOf(k) !== i); if (dup.length) out.push(n + ' dup ' + dup); for (const it of g.items) if (it.cmd && !FZ.app.keysOf(it.cmd)) out.push(n + ' no cmd ' + it.cmd); }
    for (const n of Object.keys(G)) { FZ.app.st.group = n; FZ.app.drawSub(); const noic = [...document.querySelectorAll('#sub .ch:not(.back)')].filter(t => !t.querySelector('svg.ic, svg.sw')).map(t => t.dataset.cmd); if (noic.length) out.push(n + ' no icon ' + noic); } return out; });
  if (integ.length) bad('menu table integrity', integ);
  // どのグループも 1 段の帯に収まる（1180px・1100px）。帯の高さは 2 段のタイル分
  for (const W of [1180, 1100]) { await page.setViewportSize({ width: W, height: 800 }); await page.waitForTimeout(50);
    for (const g of ['struct', 'marks', 'file', 'edit', 'line', 'insert', 'decor', 'fmt', 'view', 'head', 'table', 'scale', 'fix']) { const r = await ev((g) => { FZ.app.st.group = g; FZ.app.st.armed = true; FZ.app.drawSub(); const d = document.getElementById('dock'); const s = document.getElementById('sub'); return [d.offsetHeight, s.scrollWidth, s.clientWidth]; }, g); if (r[0] > 54 || r[1] > r[2]) bad(`group fits one band @${W}: ` + g, r); } }
  await page.setViewportSize({ width: 1180, height: 800 }); await ev(() => { FZ.app.st.group = 'struct'; FZ.app.st.armed = false; FZ.app.drawSub(); });
  // 取説（F1）：ロゴと、表から作ったキー（節は fz-help.js）
  await page.keyboard.press('F1'); await page.waitForTimeout(300); const help = await ev(() => { const img = document.querySelector('#sideBody .hhead img'); return { side: FZ.app.st.side, logo: !!img && img.naturalWidth > 0, text: document.getElementById('sideBody').textContent }; });
  if (help.side !== 'help' || !help.logo || !help.text.includes('F5→1 / Ctrl+B') || !help.text.includes('メニューの使い方')) bad('help panel with logo and derived keys', { side: help.side, logo: help.logo });
  await page.keyboard.press('F1'); await page.waitForTimeout(50);
  // コマンド一覧：キーの道筋が出る
  await page.keyboard.press('Control+k'); await page.waitForTimeout(80); await page.keyboard.type('囲み記事'); await page.waitForTimeout(80); const pal = await ev(() => document.getElementById('palList').textContent);
  if (!/F7→K/.test(pal)) bad('palette shows derived keys', pal.slice(0, 200)); await page.keyboard.press('Escape');
  // ページ番号が無い
  const pno = await ev(() => document.querySelectorAll('svg.pg .pno').length); if (pno) bad('page number badge present', pno);
  console.log(`menu fails=${fails}`, 'errors:', errors);
  await browser.close(); process.exit(fails ? 1 : 0);
})();
