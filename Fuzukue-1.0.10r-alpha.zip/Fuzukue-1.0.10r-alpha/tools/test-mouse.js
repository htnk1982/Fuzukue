const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 820 } });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); d.lines = ['一行目の文章です。', '二行目の文章です。', '三行目の文章です。'].map(t => FZ.newLine(t)); FZ.app.ed.setDoc(d); FZ.app.render(); });
  const pt = async (row, col) => page.evaluate(([row, col]) => { const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = r.width / g.W; return { x: r.left + (g.left + col * g.cw) * sc, y: r.top + (g.top + (g.bodyTop + row + 0.5) * g.ch) * sc }; }, [row, col]);
  const a = await pt(0, 2), b = await pt(2, 5);
  await page.mouse.move(a.x, a.y); await page.mouse.down(); await page.mouse.move(a.x + 20, a.y, { steps: 3 }); await page.mouse.move(b.x, b.y, { steps: 8 }); await page.mouse.up();
  console.log('sel after drag:', await page.evaluate(() => JSON.stringify(FZ.app.ed.sel())), 'text:', await page.evaluate(() => { const s = FZ.app.ed.sel(); return s ? FZ.app.ed.textOf(s) : null; }));
  await page.screenshot({ path: '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/shot-drag.png', clip: { x: 0, y: 0, width: 1100, height: 300 } });
  // shift-click
  const c = await pt(1, 3); await page.mouse.click(c.x, c.y); await page.keyboard.down('Shift'); await page.mouse.click(b.x, b.y); await page.keyboard.up('Shift');
  console.log('shift-click sel:', await page.evaluate(() => { const s = FZ.app.ed.sel(); return s ? FZ.app.ed.textOf(s) : null; }));
  await browser.close();
})();
