/* 貼付の方針（S-6）：メール本文は整形しない／Ctrl+Alt+V で整形し直す／箇条書きの塊は整形／貼付の # は表題にしない／改行は行として保つ */
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + require('path').resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  let fails = 0; const bad = (n, i) => { fails++; console.log('FAIL', n, JSON.stringify(i)); };
  const reset = () => page.evaluate(() => { localStorage.clear(); FZ.app.ed.setDoc(FZ.newDoc()); FZ.app.render(); });
  const paste = (text) => page.evaluate((md) => { const dt = new DataTransfer(); dt.setData('text/plain', md); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, text);
  const dump = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => ({ a: l.attrs, t: l.segs.map(s => s.text).join('|') })));
  const msg = () => page.evaluate(() => FZ.app.st.msg);
  // 1 メール本文：行がそのまま
  await reset(); await paste('山田様\nお世話になっております。\n- 納期：11/5\n以上、よろしくお願いします。\n'); await page.waitForTimeout(50);
  let d = await dump(); if (!(d[0].t === '山田様' && d[1].t === 'お世話になっております。' && d[2].t === '- 納期：11/5' && d[3].t === '以上、よろしくお願いします。' && !d[2].a.list)) bad('mail paste kept as lines', d);
  const m1 = await msg(); if (!/Ctrl\+Alt\+V/.test(m1)) bad('hint message', m1);
  // 2 Ctrl+Alt+V で整形し直す → 項目になる、改行は行のまま
  await page.keyboard.press('Control+Alt+v'); await page.waitForTimeout(50);
  d = await dump(); if (!(d[0].t === '山田様' && d[1].t === 'お世話になっております。' && d[2].a.list && d[2].t === '納期：11/5' && d[3].t === '以上、よろしくお願いします。')) bad('Ctrl+Alt+V reformat', d);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(30); d = await dump(); if (!(d[2].t === '- 納期：11/5')) bad('undo of reformat', d);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(30); d = await dump(); if (!(d.length === 1 && d[0].t === '')) bad('undo of paste', d);
  // 3 箇条書きの塊は自動整形
  await reset(); await paste('- a\n- b\n- c\n'); await page.waitForTimeout(50); d = await dump(); if (!(d[0].a.list && d[1].a.list && d[2].a.list && d[0].t === 'a')) bad('list auto', d);
  // 4 文書の途中に # 見出し → 表題にならない／段落内の改行は行
  await reset(); await page.evaluate(() => { FZ.app.ed.insertText('既存'); FZ.app.ed.enter(); });
  await paste('# 章の見出し\n一行目\n二行目\n\n- 項目\n'); await page.waitForTimeout(50); d = await dump();
  if (!(d[1].a.style === 'num' && d[1].a.level === 0 && !d[1].a.align && d[2].t === '一行目' && d[3].t === '二行目')) bad('mid-doc heading & hard breaks', d);
  const title = await page.evaluate(() => FZ.app.ed.doc.title); if (title) bad('title untouched', title);
  // 5 Ctrl+Shift+V はそのまま、その後 Ctrl+Alt+V は効く
  await reset(); await page.keyboard.down('Control'); await page.keyboard.down('Shift'); await page.keyboard.press('v'); await page.keyboard.up('Shift'); await page.keyboard.up('Control');
  await paste('## 見出し\n本文\n'); await page.waitForTimeout(50); d = await dump(); if (!(d[0].t === '## 見出し' && !d[0].a.style)) bad('Ctrl+Shift+V plain', d);
  await page.keyboard.press('Control+Alt+v'); await page.waitForTimeout(50); d = await dump(); if (!(d[0].a.style === 'num' && d[0].a.level === 1 && d[0].t === '見出し')) bad('reformat after plain', d);
  // 6 他の編集の後は Ctrl+Alt+V を拒む
  await page.keyboard.type('x'); await page.keyboard.press('Control+Alt+v'); await page.waitForTimeout(50); const m6 = await msg(); if (!/ありません/.test(m6)) bad('refuse stale', m6);
  // 7 制御文字入りの貼付
  await reset(); await paste('a\u0001b\u000Bc'); await page.waitForTimeout(30); d = await dump(); if (d[0].t !== 'abc') bad('control chars removed', d[0].t);
  // 8 和文の番号を起こす（C-3、任意）：切なら行のまま、入なら見出し・箇条書きに
  await reset(); await paste('１．背景\n（１）市場\n・項目\n'); await page.waitForTimeout(50); d = await dump(); if (!(d[0].t === '１．背景' && !d[0].a.style)) bad('jaLift off keeps lines', d);
  await page.evaluate(() => { FZ.app.run('jaLift'); }); const on = await page.evaluate(() => FZ.app.st.jaLift && localStorage.getItem('fz.jaLift') === '1'); if (!on) bad('jaLift persisted'); await reset(); await paste('１．背景\n（１）市場\n・項目\n'); await page.waitForTimeout(50); d = await dump();
  if (!(d[0].a.style === 'num' && d[0].a.level === 0 && d[0].t === '背景' && d[1].a.style === 'num' && d[1].a.level === 1 && d[2].a.list && d[2].t === '項目')) bad('jaLift on lifts markers', d);
  await page.evaluate(() => { FZ.app.run('jaLift'); });
  console.log(`paste fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
