const { chromium } = require('playwright');
const out = '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 820 } });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(500);
  await page.evaluate(() => { localStorage.clear(); FZ.app.ed.setDoc(FZ.parse(FZ.sampleText())); FZ.app.render(); const g = FZ.app.ed.lay.geo; const s = document.createElement('style'); s.textContent = `@page{size:${g.W}pt ${g.H}pt;margin:0}`; document.head.append(s); });
  await page.emulateMedia({ media: 'print' });
  await page.pdf({ path: out + 'sample.pdf', preferCSSPageSize: true, printBackground: true });
  await browser.close();
})();
