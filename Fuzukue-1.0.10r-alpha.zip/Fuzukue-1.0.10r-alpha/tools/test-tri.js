/* 三体系（数字見出し・記号見出し・箇条書き）：番号の数え方・字下げ・原本の語・旧ファイルの読み替え・Markdown の往復・Word */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = [];
const ok = (cond, name, info) => { if (!cond) { fails++; errors.push(name + (info !== undefined ? ' :: ' + JSON.stringify(info) : '')); } };
const H = '#fzk 2\n文字数: 40\n行数: 36\n---\n';
const markers = doc => { const lay = FZ.layout(doc); const out = []; for (const p of lay.pages) { const byLine = new Map(); for (const g of p.glyphs) if (g.marker) { if (!byLine.has(g.line)) byLine.set(g.line, { text: '', col: g.col }); byLine.get(g.line).text += g.text; } for (const [l, m] of byLine) out[l] = m.text.trim() + '@' + m.col; } return out; };
// 1 番号は記号見出しをまたいで続く／仕切り直しの設定／再開／題のレベル
{ const d = FZ.parse(H + '[番号1]背景\n[記号1]現状\n[番号2]市場\n[番号2]競合\n[記号1]対策\n[番号2]増員\n[番号1]課題\n[番号2 再開5]五\n[項目1]a\n[項目2]b\n');
  const m = markers(d); ok(m[0] === '1.@0' && m[2] === '（1）@1' && m[3] === '（2）@1' && m[5] === '（3）@1' && m[6] === '2.@0' && m[7] === '（5）@1', 'numbering continues across sym headings', m);
  ok(m[1].startsWith('■@') && m[4].startsWith('■@'), 'sym heading marker', m);
  const boldOf = (doc, i) => { const lay = FZ.layout(doc); return lay.pages[0].glyphs.filter(g => g.line === i && !g.marker).every(g => g.marks & FZ.M.BOLD); }; // 題の太字は組版が付ける（K-1）
  ok(boldOf(d, 0) && boldOf(d, 2) && !boldOf(FZ.parse(H + '[番号3]x'), 0) && !d.lines[0].segs[0].marks.some(x => x & FZ.M.BOLD), 'title levels bold by layout, paragraph level 3 not, nothing baked', [d.format.titleLevels]);
  d.format.symResetsNum = true; const m2 = markers(d); ok(m2[5] === '（1）@1', 'symResetsNum restarts after sym heading', m2);
  const s1 = FZ.serialize(d); ok(s1.includes('[番号1]背景') && s1.includes('[記号1]現状') && s1.includes('[番号2 再開5]五') && s1.includes('[項目2]b') && s1.includes('番号体系: ') && s1.includes('記号見出し: ') && s1.includes('箇条書き: ') && s1.includes('仕切り直し: あり'), 'fzk tokens', s1.split('\n---\n')[1]);
  ok(FZ.serialize(FZ.parse(s1)) === s1, 'fzk stable'); }
// 2 字下げ：数字見出し n は n マス、記号見出しは直前の数字見出しの本文位置＋レベル、箇条書きは見出しの本文位置＋入れ子
{ const d = FZ.parse(H + '[番号1]A\n[番号2]B\n[記号1]C\n[記号2]D\n[項目1]a\n[項目2]b\n[項目1]c\n[番号1]E\n[項目1]d\n');
  const m = markers(d); ok(m[1] === '（1）@1' && m[2] === '■@4' && m[3] === '◆@5' && m[4] === '・@6' && m[5] === '‐@7' && m[6] === '・@6' && m[8] === '・@2', 'indent rules', m); }
// 3 旧ファイル（単一体系）の読み替え：見た目を保つ
{ const old = '#fzk 2\n階層: 1. （1） ■ ・ ‐ ◦ ▪ ▫\n---\n[見出し]旧見出し\n[項目1]一\n[項目2]二\n[項目3]三\n[項目4]四\n[→4]矢\n';
  const d = FZ.parse(old); const m = markers(d);
  ok(d.lines[0].attrs.style === 'sym' && m[0] === undefined || m[0] === '@0', 'old heading → sym with no mark', [d.lines[0].attrs, m[0]]);
  ok(d.lines[1].attrs.style === 'num' && d.lines[2].attrs.style === 'num' && d.lines[2].attrs.level === 1 && d.lines[3].attrs.list && d.lines[3].attrs.list.level === 0 && d.lines[4].attrs.list.level === 1 && d.lines[5].attrs.list.kind === 'arrow', 'old items split into num/bullets', d.lines.map(l => l.attrs));
  ok(m[1] === '1.@0' && m[2] === '（1）@1' && m[3].startsWith('■@') && m[4].startsWith('・@'), 'old markers preserved', m);
  const old2 = '#fzk 2\n階層: Ⅰ 1. 1） ■ ・ ‐ ◦ ▪\n見出し番号: あり\n---\n[見出し]章\n[見出し2]節\n[項目1]a\n';
  const d2 = FZ.parse(old2); const m2 = markers(d2); ok(d2.lines[0].attrs.style === 'num' && d2.lines[1].attrs.style === 'num' && d2.lines[1].attrs.level === 1 && d2.format.titleLevels === 3 && m2[0] === 'Ⅰ@0' && m2[1] === '1.@1' && m2[2].startsWith('■@'), 'old headingNumbers → num titles', [d2.lines.map(l => l.attrs), m2, d2.format.titleLevels]); }
// 4 Markdown：# は数字見出し（題）、番号付きリストは段落レベル、記号は箇条書き、■ で始まる見出しは記号見出し。書き出しは番号を焼く
{ const d = FZ.fromGfm('# 題\n\n## 背景\n\n### ■ 現状\n\n- a\n  - b\n\n1. 納期\n   1. 子\n2. 品質\n\n## 課題\n\n3. 三から\n');
  const a = d.lines.map(l => l.attrs);
  ok(a[0].style === 'title' && a[1].style === 'num' && a[1].level === 0 && a[2].style === 'sym' && a[2].level === 0, 'md headings', a.slice(0, 3));
  ok(a[3].list && a[3].list.level === 0 && a[4].list.level === 1, 'md bullets', a.slice(3, 5));
  const nums = d.lines.filter(l => l.attrs.list && l.attrs.list.kind === 'num').map(l => [l.attrs.list.level, l.attrs.restart || null]); ok(JSON.stringify(nums) === JSON.stringify([[0, null], [1, null], [0, null], [0, 3]]), 'md ordered → numbered list items with restart (1.0.10a.3)', nums);
  const md = FZ.toGfm(d); ok(md.includes('## 1. 背景') && md.includes('### ■ 現状') && md.includes('\n1. 納期\n   1. 子\n2. 品質') && md.includes('## 2. 課題') && md.includes('\n3. 三から'), 'md export bakes numbers', md);
  const d2 = FZ.fromGfm(md); ok(JSON.stringify(d2.lines.map(l => l.attrs)) === JSON.stringify(a), 'md round trip keeps structure', d2.lines.map(l => l.attrs)); }
// 5 Word：題は Heading、段落レベルは自動番号、記号見出しは独自スタイルに記号を焼く、箇条書きは記号の番号定義
{ const d = FZ.parse(H + '[番号1]背景\n[番号3]納期\n[記号1]現状\n[項目1]a\n'); const bytes = FZ.toDocx(d); const str = Buffer.from(bytes).toString('utf8');
  ok(str.includes('w:val="Heading1"') && str.includes('w:val="FzSym1"') && /<w:ilvl w:val="2"\/><w:numId w:val="1"\/>/.test(str) && /<w:ilvl w:val="0"\/><w:numId w:val="5"\/>/.test(str) && str.includes('abstractNumId="5"'), 'docx structure'); }
// 6 編集：見出しの付け外し・Tab でレベル・箇条書きとの行き来
{ const ed = new FZ.Editor(); ed.setDoc(FZ.newDoc()); ed.insertText('章'); ed.setHeading('num'); const gb = () => ed.lay.pages[0].glyphs.filter(g => g.line === ed.caret.line && !g.marker).every(g => g.marks & FZ.M.BOLD); ok(ed.line().attrs.style === 'num' && ed.line().attrs.level === 0 && gb() && !ed.line().segs[0].marks.some(m => m & FZ.M.BOLD), 'setHeading num bold (layout)', ed.line());
  ed.indent(1); ok(ed.line().attrs.level === 1, 'Tab deepens heading level'); ed.indent(1); ok(ed.line().attrs.level === 2 && !gb(), 'paragraph level drops bold');
  ed.setHeading('sym'); ok(ed.line().attrs.style === 'sym' && ed.line().attrs.level === 0, 'switch to sym'); ed.setList(); ok(ed.line().attrs.list && !ed.line().attrs.style, 'heading → bullet'); ed.setHeading('num'); ok(ed.line().attrs.style === 'num' && !ed.line().attrs.list, 'bullet → heading'); ed.setHeading('num'); ok(!ed.line().attrs.style, 'toggle off'); }
console.log(`tri fails=${fails}`, 'errors:', errors);
