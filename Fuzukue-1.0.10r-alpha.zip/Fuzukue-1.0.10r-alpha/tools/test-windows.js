/* 複数の窓：窓ごとに番号を取り、復旧データを分ける。閉じた窓の未保存の文書は次に開いた窓が引き継ぐ。8 つまで */
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 } }); let fails = 0; const bad = (n, i) => { fails++; console.log('FAIL', n, JSON.stringify(i)); };
  const url = 'file://' + path.resolve(__dirname, '../app/index.html'); const errors = [];
  const open = async () => { const p = await ctx.newPage(); p.on('pageerror', e => errors.push(e.message)); await p.goto(url); await p.waitForTimeout(300); return p; };
  const a = await open(); await a.evaluate(() => { for (let n = 0; n <= 9; n++) { localStorage.removeItem('fz.slot.' + n); localStorage.removeItem('fz.recover.' + n); } localStorage.removeItem('fz.recover'); }); await a.reload(); await a.waitForTimeout(300);
  const b = await open();
  const sa = await a.evaluate(() => FZ.app.st.slot), sb = await b.evaluate(() => FZ.app.st.slot); if (!(sa === 1 && sb === 2)) bad('slots 1 and 2', [sa, sb]);
  await a.evaluate(() => { FZ.app.ed.insertText('窓Aの文'); }); await b.evaluate(() => { FZ.app.ed.insertText('窓Bの文'); }); await a.waitForTimeout(1600); // 復旧の保存（間引きあり）
  await a.evaluate(() => window.dispatchEvent(new Event('beforeunload'))); await b.evaluate(() => window.dispatchEvent(new Event('beforeunload')));
  const keys = await a.evaluate(() => [localStorage.getItem('fz.recover.1'), localStorage.getItem('fz.recover.2')].map(x => x && JSON.parse(x).text.split('---\n')[1].trim()));
  if (!(keys[0] === '窓Aの文' && keys[1] === '窓Bの文')) bad('separate recovery per window', keys);
  const title = await b.evaluate(() => document.title); if (!/文机 2$/.test(title)) bad('title shows window number', title);
  // 窓 B を閉じ、印が消えてから新しい窓を開くと、窓 2 の文書を引き継ぐ
  await b.close(); await a.waitForTimeout(100); const c = await open(); const sc = await c.evaluate(() => FZ.app.st.slot); const tc = await c.evaluate(() => FZ.app.ed.doc.lines[0].segs[0].text); if (!(sc === 2 && tc === '窓Bの文')) bad('new window takes over closed slot', [sc, tc]);
  // 8 つまで
  const more = []; for (let k = 0; k < 6; k++) more.push(await open()); const slots = await Promise.all(more.map(p => p.evaluate(() => FZ.app.st.slot))); if (JSON.stringify(slots) !== '[3,4,5,6,7,8]') bad('slots 3..8', slots);
  const ninth = await open(); const s9 = await ninth.evaluate(() => [FZ.app.st.slot, FZ.app.st.msg]); if (!(s9[0] === 0 && /8 つを超えました/.test(s9[1]))) bad('ninth window has no slot', s9);
  await a.evaluate(() => FZ.app.run('newWindow')); const m = await a.evaluate(() => FZ.app.st.msg); if (!/8 つまで/.test(m)) bad('newWindow refuses at 8', m);
  console.log(`windows fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
