@echo off
rem Fuzukue launcher: runs the app in Microsoft Edge (or Chrome) app mode. No install needed.
setlocal
set "HERE=%~dp0"
set "URL=file:///%HERE:\=/%app/index.html"
set "PROFILE=%LOCALAPPDATA%\Fuzukue\browser-profile"
set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"
if exist "%BROWSER%" goto run
set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if exist "%BROWSER%" goto run
echo Edge / Chrome not found. Opening with the default browser.
start "" "%HERE%app\index.html"
exit /b
:run
start "" "%BROWSER%" --app="%URL%" --user-data-dir="%PROFILE%" --window-size=1180,900 --no-first-run --no-default-browser-check
exit /b
