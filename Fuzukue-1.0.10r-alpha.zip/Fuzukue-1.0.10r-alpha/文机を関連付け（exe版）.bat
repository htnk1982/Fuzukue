@echo off
rem Associate .fzk files with Fuzukue.exe (current user only, no admin rights needed).
rem After this, double-clicking a .fzk file in Explorer opens it in Fuzukue.
rem Run again if you move Fuzukue.exe. To undo:  Fuzukue.exe --unregister
setlocal
set "EXE=%~dp0Fuzukue.exe"
if not exist "%EXE%" (
  echo Fuzukue.exe was not found next to this file.
  echo Build it first with host\build-windows.bat
  pause & exit /b 1
)
"%EXE%" --register
