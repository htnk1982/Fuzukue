/* 文机 アプリ：画面・入力・モード・ファイル・印刷
 * 方針：1画面。ポップアップ／ダイアログは使わない（選択肢だけはプルダウン）。
 *   上部ドック = Fキー行 ＋ 子メニュー行（開いた F グループの項目、またはインライン・フォーム）。下部 = 状態行
 *   右パネル  = 使い方／コマンド一覧（同じ画面内でトグル）。ツリーは紙面に替わる見え方
 *   表示は常に白黒＋網点（印刷イメージ）
 *   フォームの選択肢はプルダウン（select）。押すたびに値が巡るボタンは使わない（今の値と選べる値が一目で分かるように） */
(function (FZ) {
'use strict';
const $ = id => document.getElementById(id);
const M = FZ.M, G = FZ.graphemes;
const PX = 96 / 72;
const ed = new FZ.Editor();
const st = { mode: 'text', sub: null, ruleKind: 'thin', shade: 'gray', rc: { page: 0, y: 0, col: 0 }, ranchor: null, preview: null, zoom: 'width', grid: true, mono: true,
  file: null, composing: false, compStart: 0, lastPasteShift: false, lastPaste: null, jaLift: false, /* 和文の番号・記号を起こす（C-3、任意。貼付と .md/.txt の読み込みに効く） */ msg: '', msgAlert: false, msgTimer: 0,
  group: 'struct', armed: false, form: null, side: null, formFocus: false, fig: null }; // group：子メニュー行に出しているグループ（常に何か出ている）。armed：F キーを押した直後で、1 文字キーが項目の実行に使われる状態
const main = $('main'), pagesEl = $('pages'), ta = $('ta'), sub = $('sub'), sideEl = $('side');
let pageCache = [], wraps = [];
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const half = v => Math.round(v * 2) / 2;
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ================= 描画（フレーム合流・幾何キャッシュ） ================= */
let renderQueued = false, overlayQueued = false, geomDirty = true, pageGeom = [], mainW = 0, mainH = 0;
function mainSize() { if (!mainW) { mainW = main.clientWidth; mainH = main.clientHeight; } return [mainW, mainH]; }
function requestRender() { if (renderQueued) return; renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); }
function requestOverlay() { if (overlayQueued || renderQueued) return; overlayQueued = true; requestAnimationFrame(() => { overlayQueued = false; renderOverlay(); status(); }); }
function flush() { if (renderQueued) { renderQueued = false; render(); } if (overlayQueued) { overlayQueued = false; renderOverlay(); status(); } }
function targetWidthPx() {
  const [mw, mh] = mainSize(); const avail = mw - 28; const W = ed.lay.geo.W, H = ed.lay.geo.H;
  if (st.zoom === 'width') return Math.min(avail, W * PX * 2.4);
  if (st.zoom === 'page') return Math.min(avail, (mh - 30) * W / H); // 高さを画面に合わせる
  return W * PX * Number(st.zoom); // 倍率（1 = 100%）
}
let lastWpx = 0, lastN = 0;
let skipTree = false; // 紙面のスクロールだけのときはツリーを描き直さない
function render() {
  const vw = st.view || 'paper'; document.body.classList.toggle('vtree', vw === 'tree'); document.body.classList.toggle('vsplit', vw === 'split'); document.body.classList.toggle('tfocus', st.mode === 'tree');
  if (vw !== 'paper') { if (!skipTree) renderTree(); } else if (treeEl.style.display !== 'none') { treeEl.style.display = 'none'; treeEl.innerHTML = ''; }
  if (vw === 'tree') { if (pagesEl.style.display !== 'none') pagesEl.style.display = 'none'; status(); syncView(); return; }
  if (pagesEl.style.display === 'none') { pagesEl.style.display = ''; geomDirty = true; }
  const lay = ed.lay, n = lay.pages.length;
  const wpx = Math.max(120, targetWidthPx());
  if (wpx !== lastWpx || n !== lastN) { geomDirty = true; lastWpx = wpx; lastN = n; }
  pagesEl.style.width = wpx + 'px';
  pagesEl.style.setProperty('--pw', lay.geo.W + 'pt'); pagesEl.style.setProperty('--ph', lay.geo.H + 'pt');
  while (wraps.length > n) { wraps.pop().remove(); pageCache.pop(); }
  while (wraps.length < n) { const d = document.createElement('div'); d.className = 'pgwrap'; d.dataset.page = wraps.length; pagesEl.append(d); wraps.push(d); pageCache.push(''); }
  applyFonts(); /* 書体を先に流す（基準の字幅は字をその書体で測って置く） */
  const ph = wpx * lay.geo.H / lay.geo.W;
  const top = main.scrollTop, bottom = top + mainSize()[1]; let firstVis = 0, lastVis = n - 1;
  if (ph && n > 3) { const gap = 12; firstVis = clamp(Math.floor((top - 12) / (ph + gap)) - 1, 0, n - 1); lastVis = clamp(Math.ceil(bottom / (ph + gap)) + 1, 0, n - 1); }
  for (let p = 0; p < n; p++) {
    const w = wraps[p];
    if (p < firstVis || p > lastVis) { if (pageCache[p] !== '') { w.innerHTML = ''; pageCache[p] = ''; } w.style.height = ph + 'px'; continue; }
    w.style.height = '';
    const svg = FZ.renderPage(lay, p, { grid: st.grid ? (st.gridMode || 'dots') : false, font: ed.doc.format.font, mono: true, imageHref, reveal: st.reveal }); if (pageCache[p] !== svg) { w.innerHTML = svg; pageCache[p] = svg; }
  }
  renderOverlay(); status(); drawNotes();
}
function measurePages() { // 1回だけ強制レイアウト。以後はキャッシュ
  const rm = main.getBoundingClientRect(); pageGeom = wraps.map(w => { const r = w.getBoundingClientRect(); return { left: r.left - rm.left + main.scrollLeft, top: r.top - rm.top + main.scrollTop, width: r.width, height: r.height }; }); geomDirty = false;
}
function pagePt(p) { if (geomDirty || !pageGeom[p]) measurePages(); const g = pageGeom[p]; if (!g) return null; return { left: g.left, top: g.top, scale: g.width / ed.lay.geo.W }; }
function selectionRects() {
  const s = ed.sel(); if (!s) return []; const out = [];
  const before = (l, g, l2, g2) => l < l2 || (l === l2 && g < g2);
  ed.lay.pages.forEach((pg, p) => { for (const es of pg.rowmap.values()) for (const e of es) {
    if (before(e.line, e.seg, s.a.line, s.a.seg) || before(s.b.line, s.b.seg, e.line, e.seg)) continue;
    let from = e.startOff, to = e.endOff;
    if (e.line === s.a.line && e.seg === s.a.seg) from = Math.max(from, s.a.off); if (e.line === s.b.line && e.seg === s.b.seg) to = Math.min(to, s.b.off);
    if (to < from) continue; if (to === from && !(e.startOff === e.endOff)) continue;
    const colOf = off => { let best = e.carets[0]; for (const c of e.carets) if (Math.abs(c.off - off) < Math.abs(best.off - off)) best = c; return best.col; };
    const c1 = colOf(from), c2 = colOf(to); out.push({ page: p, y: e.y, h: e.h, col: c1, w: Math.max(0.3, c2 - c1) });
  } });
  return out;
}
function renderOverlay() {
  if (st.mode === 'tree') { renderTreeOverlay(); if (st.view !== 'split') return; }
  const lay = ed.lay; const pp0 = pagePt(0); const ov = { selRects: [], rects: [], lines: [], hits: [], caret: null, composing: st.composing, mono: true, scale: pp0 ? pp0.scale : 1 };
  if (st.mode === 'text') {
    ov.selRects = st.cells ? cellRects() : selectionRects();
    if (drag && drag.kind === 'pedge') { ov.lines.push({ page: drag.page, c1: drag.x, r1: drag.y1, c2: drag.x, r2: drag.y2, w: 2.2 }, { page: drag.page, c1: drag.x - drag.G.GAP, r1: drag.y1, c2: drag.x - drag.G.GAP, r2: drag.y2, w: 2.2 }); }
    if (drag && drag.kind === 'bedge' && drag.rows) ov.lines.push({ page: drag.page, c1: drag.x, r1: drag.rows.y1, c2: drag.x, r2: drag.rows.y2, w: 2.2 });
    if (drag && drag.kind === 'tcol' && drag.rows) ov.lines.push({ page: drag.page, c1: drag.x, r1: drag.rows.y1, c2: drag.x, r2: drag.rows.y2, w: 2.2 });
    if (drag && drag.kind === 'tmove') ov.rects.push({ page: drag.page, col: drag.I.L + drag.dx, y: drag.rows.y1 + drag.dy, w: drag.I.R - drag.I.L, h: drag.rows.y2 - drag.rows.y1, fill: '#000', opacity: 0.06, stroke: '#000', sw: 1.6, solid: true });
    { const tg = !drag && tableGrip(); if (tg) ov.rects.push({ page: tg.page, col: tg.col, y: tg.y, w: tg.w, h: tg.h, fill: '#000', opacity: 0.85, stroke: '#000', sw: 0.6, solid: true }); } /* 表の左上のつまみ（ドラッグで表を動かす） */
    const xy = ed.xy(); if (xy) { let w = 1; const seg = ed.seg(); if (ed.caret.vcol == null && ed.caret.off < seg.text.length) { const g = G(seg.text).find(g => g.start === ed.caret.off); if (g) w = FZ.gWidth(g, seg.marks[g.start] | 0); } ov.caret = { page: xy.page, y: xy.y, h: xy.h, col: xy.col, w }; ov.caretColor = inDarkFill(xy) ? '#fff' : '#111'; }
    if (st.reveal && ov.caret) { const R = ganttCellRect(st.reveal); if (R) { ov.rects.push({ ...R, fill: 'none', opacity: 0, stroke: '#000', sw: 1.4, solid: true }); ov.caret.hidden = true; } } /* 工程表の期間のセル：字の代わりにセルの枠（名前は矢羽根の中に出る） */
    const gh = st.ganttHover; if (gh && !drag) { if (gh.kind === 'bar') for (const [xx, on] of [[gh.x0, gh.which === 'u0'], [gh.x1, gh.which === 'u1']]) ov.rects.push({ page: gh.page, col: xx - 0.14, y: gh.y + gh.h * 0.18, w: 0.28, h: gh.h * 0.64, fill: '#000', opacity: on ? 1 : 0.55, stroke: '#fff', sw: 0.6, solid: true }); else if (gh.kind === 'ms') ov.rects.push({ page: gh.page, col: gh.x - 0.45, y: gh.y + gh.h * 0.08, w: 0.9, h: gh.h * 0.84, fill: 'none', opacity: 0, stroke: '#000', sw: 1, solid: true }); } /* 掴める所：矢羽根の両端のつまみ（近い方を濃く）・◆ の枠 */
  } else if (st.mode === 'fig') {
    const fi = figInfo(); if (fi) { const F = fi.F, X = x => fi.left + x, P = fi.P, Y = fi.Y; ov.handles = []; ov.ports = [];
      if (st.fig.connecting) ov.labels = F.boxes.map(b => ({ page: P(b.y), col: X(b.x), y: Y(b.y), text: String(b.id) }));
      const ids = figIds(); for (const id of ids) { const b = FZ.figureBox(F, id); if (b) ov.rects.push({ page: P(b.y), col: X(b.x) - 0.18, y: Y(b.y) - 0.12, w: b.w + 0.36, h: b.h + 0.24, fill: '#1a56c4', opacity: st.fig.connecting === id ? 0.2 : 0.07, stroke: '#1a56c4', sw: 1.1 }); } // 選択は箱の少し外に破線（箱の線の太さと紛れないように）
      const one = figSel(); if (one && !st.fig.connecting) for (const h of FZ.figureHandles(one)) ov.handles.push({ page: P(one.y), col: X(h.x), y: Y(one.y) + h.y - one.y }); /* 箱は頁をまたがない（図を切るのは箱の間）ので、つまみは箱の頁に */
      for (const id of new Set([st.fig.hover, one && one.id].filter(x => x != null))) { const b = FZ.figureBox(F, id); if (b && !drag) for (const q of FZ.figurePorts(b)) ov.ports.push({ page: P(b.y), col: X(q.x), y: Y(b.y) + q.y - b.y }); }
      if (st.fig.selArrow != null && F.arrows[st.fig.selArrow]) { const a = F.arrows[st.fig.selArrow]; const A = FZ.figureBox(F, a.from), B = FZ.figureBox(F, a.to); if (A && B) for (const sg of FZ.figureRoute(A, B, a.via, a.vp)) ov.lines.push(sg.k === 'h' ? { page: P(sg.y), c1: X(sg.from), r1: Y(sg.y), c2: X(sg.to), r2: Y(sg.y), w: 3 } : { page: P(sg.y1), c1: X(sg.col), r1: Y(sg.y1), c2: X(sg.col), r2: P(sg.y2) === P(sg.y1) ? Y(sg.y2) : Y(sg.y1) + fi.parts.find(p => p.page === P(sg.y1)).f1 - sg.y1, w: 3 }); }
      if (st.fig.link) { const L = st.fig.link; const A = FZ.figureBox(F, L.from); if (A) { const q = FZ.figurePorts(A).find(p => p.id === L.port) || { x: A.x + A.w / 2, y: A.y + A.h / 2 }; ov.lines.push({ page: P(A.y), c1: X(q.x), r1: Y(A.y) + q.y - A.y, c2: X(L.x), r2: Y(A.y) + L.y - A.y, w: 1.6 }); } if (L.to != null) { const T = FZ.figureBox(F, L.to); if (T) ov.rects.push({ page: P(T.y), col: X(T.x), y: Y(T.y), w: T.w, h: T.h, fill: '#c81e1e', opacity: 0.15, stroke: '#c81e1e', solid: true, sw: 2 }); } }
      if (st.fig.band) { const bd = st.fig.band; ov.rects.push({ page: P(Math.min(bd.y1, bd.y2)), col: X(Math.min(bd.x1, bd.x2)), y: Y(Math.min(bd.y1, bd.y2)), w: Math.abs(bd.x2 - bd.x1), h: Math.abs(bd.y2 - bd.y1), fill: 'none', opacity: 0, stroke: '#1a56c4' }); }
      for (const pt of fi.parts) ov.rects.push({ page: pt.page, col: fi.left, y: pt.y0, w: fi.right - fi.left, h: pt.f1 - pt.f0, fill: 'none', opacity: 0, stroke: '#9ab' });
      { const pl = fi.parts[fi.parts.length - 1]; ov.handles.push({ page: pl.page, col: fi.left + (fi.right - fi.left) / 2, y: pl.y0 + pl.f1 - pl.f0, bar: true }); } }
  } else if (st.mode === 'tree') { /* 並べる：ツリーで選んだ節の範囲を紙面に薄く示す */
    const n0 = treeNodeSel(); const list = treeSelected(); for (const n of (list.length ? list : [n0])) { const i = n && n.obj ? ed.doc.lines.indexOf(n.obj) : -1; if (i < 0) continue; const e2 = n.kind === 'sent' || n.kind === 'fig' ? i : Math.max(i, Math.min(n.end, i + 400)); const cols = lay.geo.cols; /* G2：複数選んだ節もすべて */
      for (let k = i; k <= e2; k++) { const lm = lay.lineMap[k]; if (!lm) continue; for (const r of lm.rows) ov.rects.push({ page: r.page, col: -0.9, y: r.y, w: k === i ? 0.4 : 0.25, h: r.h, fill: '#000', opacity: 1, stroke: 'none', sw: 0 }); } } /* 1.0.10u：灰色の塗りをやめ、左の余白に縦の線（節の頭の行は太く） */
  } else {
    const rc = st.rc; ov.lines.push({ page: rc.page, c1: rc.col - .45, r1: rc.y, c2: rc.col + .45, r2: rc.y }, { page: rc.page, c1: rc.col, r1: rc.y - .45, c2: rc.col, r2: rc.y + .45 });
    if (st.ranchor && (st.sub === 'rect' || st.mode === 'fill')) { const a = st.ranchor; ov.rects.push({ page: rc.page, col: Math.min(a.col, rc.col), y: Math.min(a.y, rc.y), w: Math.abs(a.col - rc.col), h: Math.abs(a.y - rc.y), fill: st.mode === 'fill' ? '#555' : 'none', opacity: .25, stroke: '#c81e1e' }); }
    if (st.preview) ov.lines.push(st.preview);
  }
  if (st.form === 'aiback' && st.aiBack && st.aiBack.hunks.length) { const S = st.aiBack, cols = lay.geo.cols; /* AI からの戻し：違う所（今の塊は濃く、足す所は線） */
    S.hunks.forEach((h, k) => { const cur = k === S.i;
      if (h.rem.length) for (const i of h.rem) { const lm = lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) ov.rects.push({ page: r.page, col: -0.6, y: r.y, w: cols + 1.2, h: r.h, fill: '#000', opacity: cur ? 0.13 : 0.05, stroke: cur ? '#000' : 'none', sw: cur ? 0.8 : 0 }); }
      if (h.kind === 'add' || h.kind === 'chg') { const at = h.rem.length ? h.rem[h.rem.length - 1] + 1 : h.at; const lm = lay.lineMap[Math.min(at, ed.doc.lines.length - 1)]; const r = lm && lm.rows[0]; const lmP = at > 0 ? lay.lineMap[at - 1] : null; const rp = lmP && lmP.rows[lmP.rows.length - 1];
        if (h.kind === 'add' && (r || rp)) { const y = r && at < ed.doc.lines.length ? r.y : rp.y + rp.h, pg = r && at < ed.doc.lines.length ? r.page : rp.page; ov.lines.push({ page: pg, c1: -0.6, r1: y, c2: cols + 0.6, r2: y, w: cur ? 3 : 1.5 }); } } }); }
  if (st.form === 'phase' && st.pufuCmp && st.mode === 'text') { const R2 = pufuCmpNow(); if (R2) { ov.tags = ov.tags || []; const map = lay.pufuAt || FZ.pufuLayoutMap(ed.doc, FZ.pufuRegion(lay.geo)); const TWp = FZ.PUFU_GEOM.TW; const ch = [...R2.status.keys()].sort((x, y) => x - y); const cur = st.pufuCmp.i >= 0 ? ch[st.pufuCmp.i] : null; /* 1.0.14e 局面との比較：足した＝太い枠、直した＝薄い網（印刷には出ない） */
      for (const [q, v] of R2.status) { const pf = map.get(q), lm = lay.lineMap[q]; if (!pf || !lm) continue; const x0 = pf.tag != null || pf.tagShade ? pf.bx0 + TWp : pf.bx0;
        for (const r of lm.rows) ov.rects.push(v === 'add' ? { page: r.page, col: pf.bx0 - 0.2, y: r.y + 0.05, w: pf.bx1 - pf.bx0 + 0.4, h: r.h - 0.1, fill: 'none', opacity: 0, stroke: FZ.SHU, sw: q === cur ? 3.2 : 2.2, care: true } : { page: r.page, col: x0, y: r.y, w: pf.bx1 - x0, h: r.h, fill: FZ.SHU, opacity: q === cur ? 0.2 : 0.1, stroke: q === cur ? FZ.SHU : 'none', sw: 1, care: true }); /* 1.0.15a 比べた印は手当て（朱） */
        const r0 = lm.rows[0]; if (r0) ov.tags.push({ page: r0.page, col: -0.6, y: r0.y, text: v === 'add' ? '足した' : '直した', anchor: 'end' }); } } }
  if (st.form === 'fit' && st.mode === 'text') { ov.tags = []; const geo = lay.geo; /* P11：節ごとの紙幅（左の余白に札）と、区画の高さを決める区画（細い枠） */
    for (const x of fitBlocks()) { if (x.sec) { const lm = lay.lineMap[x.line]; if (lm && lm.rows[0]) ov.tags.push({ page: lm.rows[0].page, col: -0.6, y: lm.rows[0].y, text: `${x.n} 行・${Math.round(x.n / geo.rows * 100)}%`, anchor: 'end' }); }
      if (x.kind === '区画' && x.tall != null) { const lm = lay.lineMap[x.tall]; if (lm && lm.rows[0]) ov.tags.push({ page: lm.rows[0].page, col: -0.6, y: lm.rows[0].y + 1, text: '高さを決める区画', anchor: 'end' }); } }
    lay.pages.forEach((pg, p) => { let used = 0; ed.doc.lines.forEach((ln, i) => { const lm = lay.lineMap[i]; if (lm) for (const r of lm.rows) if (r.page === p) used = Math.max(used, r.y + r.h); }); ov.tags.push({ page: p, col: geo.cols + 0.4, y: Math.max(0, geo.rows - 1), text: `この頁 ${Math.round(used / geo.rows * 100)}%`, anchor: 'start' }); }); }
  if (st.form === 'why' && st.mode === 'text') { const L = ed.caret.line, W = lay.lineMap[L] && lay.lineMap[L].why; const R = [[L, L]]; if (W && W.brk && /次の行/.test(W.brk.why) && L + 1 < ed.doc.lines.length) R.push([L + 1, L + 1]); st.tprev = { ranges: R, text: '', why: true }; } else if (st.tprev && st.tprev.why) st.tprev = null; /* P10：理由を見ている行（と一緒に送る次の行） */
  if (st.tprev && st.tprev.ranges && (st.mode === 'text' || st.mode === 'tree')) { const cols = lay.geo.cols; /* P07：対象を細い枠で（ページごとに範囲の上下で 1 つ） */
    for (const [a, b] of st.tprev.ranges.slice(0, 200)) { const box = new Map(); for (let k = a; k <= b; k++) { const lm = lay.lineMap[k]; if (!lm) continue; for (const r of lm.rows) { const q = box.get(r.page) || { y0: r.y, y1: r.y + r.h }; q.y0 = Math.min(q.y0, r.y); q.y1 = Math.max(q.y1, r.y + r.h); box.set(r.page, q); } }
      for (const [pg, q] of box) ov.rects.push({ page: pg, col: -0.35, y: q.y0 - 0.08, w: cols + 0.7, h: q.y1 - q.y0 + 0.16, fill: 'none', opacity: 0, stroke: '#000', sw: 1.1 }); } }
  pufuGhosts(ov); /* 1.0.16h プ譜の薄い手引き */ ov.tags = ov.tags || []; healthMarks(ov); /* 1.0.15b 健康診断の印 */ findMarks(ov); /* 1.0.15d 検索の当たり */ focusDims(ov); /* 1.0.15e 集中の表示 */
  if (st.careHidden) { ov.tags = []; ov.hits = []; ov.rects = ov.rects.filter(r => !r.care); } /* 1.0.15a 手当てを隠す：札・点検の印・比べた印を出さない（紙だけ） */
  wraps.forEach((w, p) => { const g = w.querySelector('.ov'); if (g) g.innerHTML = FZ.renderOverlay(lay, p, ov); });
  if (ov.caret) positionTA(ov.caret);
}
function inDarkFill(xy) { const pg = ed.lay.pages[xy.page]; return pg && pg.fills.some(f => FZ.inkShade(f.shade) && xy.col >= f.col && xy.col < f.col + f.cols && xy.y >= f.y1 && xy.y < f.y2); }
function positionTA(c) {
  const pp = pagePt(c.page); if (!pp) return; const geo = ed.lay.geo; const x = geo.left + c.col * geo.cw, y = geo.top + (geo.bodyTop + c.y) * geo.ch;
  const hpx = Math.max(10, c.h * geo.ch * pp.scale), fontPx = Math.max(8, geo.cw * pp.scale);
  let cellsBefore = 0; const seg = ed.seg(); const off = ed.caret.off; for (const g of G(seg.text)) { if (g.start >= off) break; cellsBefore += FZ.isHalf(g.text.codePointAt(0)) ? 0.5 : 1; }
  const before = cellsBefore * fontPx;
  Object.assign(ta.style, { left: (pp.left + x * pp.scale - before) + 'px', top: (pp.top + y * pp.scale) + 'px', width: (before + 6) + 'px', height: hpx + 'px', fontSize: fontPx + 'px', lineHeight: hpx + 'px' });
}
function scrollToCaret(force) {
  if (st.mode === 'tree' && !force) return;
  const xy = st.mode === 'text' || force ? ed.xy() : st.mode === 'fig' ? (() => { const fi = figInfo(); if (!fi) return null; const b = st.fig.sel != null ? FZ.figureBox(fi.F, st.fig.sel) : null; return b ? { page: fi.P(b.y), y: fi.Y(b.y), h: b.h } : { page: fi.page, y: fi.Y0, h: fi.parts[0].f1 - fi.parts[0].f0 }; })() : { page: st.rc.page, y: st.rc.y, h: 1 }; if (!xy) return; const pp = pagePt(xy.page); if (!pp) return; const geo = ed.lay.geo;
  const top = pp.top + (geo.top + (geo.bodyTop + xy.y) * geo.ch) * pp.scale, bottom = top + xy.h * geo.ch * pp.scale;
  const mh = mainSize()[1]; if (top < main.scrollTop + 24) main.scrollTop = top - 60; else if (bottom > main.scrollTop + mh - 24) main.scrollTop = bottom - mh + 60;
}
/* ================= 本文入力（隠し textarea） ================= */
function syncTA() {
  if (st.composing || st.mode !== 'text') return; const seg = ed.seg();
  if (ta.value !== seg.text) ta.value = seg.text;
  const s = ed.selInSeg(); const a = s ? s.a.off : ed.caret.off, b = s ? s.b.off : ed.caret.off;
  if (ta.selectionStart !== a || ta.selectionEnd !== b) try { ta.setSelectionRange(a, b, 'forward'); } catch { }
}
function focusTA() { if (st.formFocus) return; if (document.activeElement !== ta) ta.focus({ preventScroll: true }); }
ta.addEventListener('input', e => {
  if (st.mode !== 'text') { syncTA(); return; }
  if (ed.line().attrs.figure) { ta.value = ''; msg('図の中は Enter で編集（箱の文字は箱を選んで Enter）', true); return; }
  if (ed.line().attrs.toc) { ta.value = ''; msg('目次の行には文字を入れられません（Enter で範囲の設定、Backspace で目次を消す）', true); return; }
  if (ed.line().attrs.hr) { ta.value = ''; msg('区切り線の行には文字を入れられません（Enter で下に行を足す、Backspace で区切り線を消す）', true); return; }
  if (!st.composing && !e.isComposing) { const v = ta.value, se = ta.selectionEnd; if (autoCellify()) { ta.value = v; try { ta.setSelectionRange(se, se); } catch { } } } // keydown を経ない入力でも箱の中のセル化を適用
  ed.applyDiff(ta.value, ta.selectionEnd, { composing: st.composing || e.isComposing }); if (!st.composing && !e.isComposing) ganttNormalizeCell();
});
ta.addEventListener('compositionstart', () => { st.composing = true; st.compStart = ed.caret.off; ed.breakUndo(); requestOverlay(); });
ta.addEventListener('compositionend', () => {
  st.composing = false; if (st.mode !== 'text') { syncTA(); return; } ed.applyDiff(ta.value, ta.selectionEnd, { composing: false }); ganttNormalizeCell();
  ed.breakUndo(); syncTA(); requestOverlay();
});
ta.addEventListener('drop', e => e.preventDefault());
/* ---------- ファイルのドラッグ＆ドロップ ----------
 * 原本（.fzk／.md／.txt）は開く（今の文書が未保存なら確かめる）。画像は放した位置の行に図表として付ける（資料書式は図表欄）。
 * 窓のどこに落としても、ブラウザがファイルへ移動して文書を失わないように既定の動作を止める。
 * 上書き保存：放した項目からファイルの参照（File System Access）を取れれば同じファイルに保存、取れなければ Ctrl+S で保存先を聞く */
const DROP_DOC = /\.(fzk|md|markdown|txt|json)$/i, DROP_IMG = /\.(png|jpe?g|gif|svg|webp)$/i;
const isFileDrag = dt => !!dt && [...(dt.types || [])].includes('Files');
let dropEl = null, dropTimer = 0;
function dropHint(on, text) { if (!dropEl) { dropEl = document.createElement('div'); dropEl.id = 'dropHint'; document.body.append(dropEl); } if (on) dropEl.innerHTML = `<span>${esc(text)}</span>`; dropEl.classList.toggle('on', !!on); }
window.addEventListener('dragover', e => { if (!isFileDrag(e.dataTransfer)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; clearTimeout(dropTimer); dropTimer = setTimeout(() => dropHint(false), 250);
  if (!dropEl || !dropEl.classList.contains('on')) dropHint(true, '放すと開きます（.fzk／.md／.txt）　画像は放した行に図表として入ります'); });
window.addEventListener('dragleave', e => { if (!e.relatedTarget) dropHint(false); });
window.addEventListener('drop', e => {
  if (!isFileDrag(e.dataTransfer)) return; e.preventDefault(); e.stopPropagation(); clearTimeout(dropTimer); dropHint(false);
  const ents = [...e.dataTransfer.items].filter(it => it.kind === 'file').map(it => ({ file: it.getAsFile(), handle: fsHandle(it) })).filter(x => x.file); // 参照はイベントの中で取る
  dropFiles(ents, e).catch(er => msg('開けませんでした：' + er.message, true));
}, true);
function fsHandle(it) { try { return typeof it.getAsFileSystemHandle === 'function' ? Promise.resolve(it.getAsFileSystemHandle()).catch(() => null) : null; } catch { return null; } }
async function dropFiles(ents, e) {
  const docs = ents.filter(x => DROP_DOC.test(x.file.name)), imgs = ents.filter(x => /^image\//.test(x.file.type) || DROP_IMG.test(x.file.name));
  if (docs.length) { const d = docs[0]; const text = await d.file.text(); const h = d.handle ? await d.handle : null;
    withDiscard(() => { loadText(text, d.file.name, h && h.kind === 'file' ? { handle: h, name: d.file.name } : null); if (docs.length > 1) msg(`${docs.length} 個のうち「${d.file.name}」を開きました（原本は 1 つずつ開きます）`); }); return; }
  if (imgs.length) {
    if (st.form) closeForm(); if (st.mode !== 'text') exitMode();
    const g = e && eventToGrid(e); if (g && g.row >= 0 && g.row < ed.lay.geo.rows) { const pos = FZ.xyToPos(ed.lay, g.page, Math.floor(g.row), half(clamp(g.col, 0, ed.lay.geo.cols))); if (pos) ed.setCaret(pos); } // 放した行に付ける
    if (ed.line().attrs.figure) { msg('流れ図の行には画像を付けられません。別の行に放してください', true); return; }
    let last = null; for (const x of imgs) { try { const r = await readImageBlob(x.file, x.file.name); if (last) { const nm = ed.addImage(last.mime, last.data, last.name); ed.addFigure({ file: nm, kind: '図', title: '' }); } last = r; } catch (er) { msg('画像を読めませんでした：' + x.file.name, true); } }
    if (last) addImageFigure(last); render(); return; }
  { const dx = ents.find(x => /\.docx$/i.test(x.file.name)); if (dx) { importDocxFile(dx.file); return; } } // Word：構造を起こして取り込む（X5）
  { const px = ents.find(x => /\.pptx$/i.test(x.file.name)); if (px) { importPptxFile(px.file); return; } } // PowerPoint：区画で近似して取り込む（1.0.11g）
  const n = ents[0] ? ents[0].file.name : ''; msg(/\.(doc|pptx?|xlsx?|pdf)$/i.test(n) ? `「${n}」は開けません（Word は .docx、PowerPoint は .pptx なら取り込めます。ほかは、生成 AI や Office で Markdown にしてから開いてください）` : `「${n}」は開けない種類のファイルです（.fzk／.md／.txt と画像）`, true);
}
function clipText(raw) { const plain = FZ.expandRefsText(ed.doc, raw); st.clip = plain !== raw ? { plain, raw } : null; return plain; } // 外へは図番を「図 1」の文字に開いて渡す
ta.addEventListener('copy', e => { if (st.mode === 'tree') { e.clipboardData.setData('text/plain', treeCopyText()); e.preventDefault(); msg('選んだ節を子ごと Markdown で写しました'); return; } if (st.cells) { const R = cellRect(); if (R) { e.clipboardData.setData('text/plain', FZ.tbl.cellsText(ed, R)); e.preventDefault(); msg('セルを写しました（タブ区切り）'); return; } } const s = ed.sel(); const t = s ? ed.textOf(s) : ed.line().segs.map(x => x.text).join('\t') + '\n'; e.clipboardData.setData('text/plain', clipText(t)); e.preventDefault(); });
ta.addEventListener('cut', e => { if (st.mode === 'tree') { e.preventDefault(); return; } const s = ed.sel(); if (!s) { e.preventDefault(); return; } e.clipboardData.setData('text/plain', clipText(ed.textOf(s))); e.preventDefault(); ed.mutate('', () => ed.deleteSelection()); });
/* 貼り付けの出どころ（Office は HTML の Generator、スプレッドシートは印）：'excel'｜'sheets'｜'powerpoint'｜'word'｜'' */
function clipSource(html) {
  if (!html) return ''; const g = (html.match(/<meta[^>]*name=["']?Generator["']?[^>]*content=["']?([^"'>]*)/i) || html.match(/<meta[^>]*content=["']?([^"'>]*)["']?[^>]*name=["']?Generator/i) || [])[1] || '';
  if (/Excel/i.test(g) || /urn:schemas-microsoft-com:office:excel/i.test(html)) return 'excel'; if (/google-sheets-html-origin/i.test(html)) return 'sheets';
  if (/PowerPoint/i.test(g) || /urn:schemas-microsoft-com:office:powerpoint/i.test(html)) return 'powerpoint'; if (/Word/i.test(g) || /urn:schemas-microsoft-com:office:word/i.test(html)) return 'word'; return '';
}
/* Excel・スプレッドシートの HTML からセルの書式を読む（完全互換ではなく、文机の白黒の世界に写せるものだけ）：
 * 太字・下線・取消線・揃え（右・中央）・背景色（明るさで 淡／薄網／濃網 の 3 段に。濃網は白抜き）。結合セルは空のセルで埋める。読めなければ null */
function shadeOf(c) {
  c = String(c || '').trim().toLowerCase(); if (!c || /^(none|transparent|auto|inherit|initial|windowtext|window|white)$/.test(c)) return null;
  const NAMED = { black: '000000', gray: '808080', grey: '808080', silver: 'c0c0c0', yellow: 'ffff00', red: 'ff0000', blue: '0000ff', green: '008000', lime: '00ff00', aqua: '00ffff', cyan: '00ffff', navy: '000080', teal: '008080', maroon: '800000', purple: '800080', olive: '808000', fuchsia: 'ff00ff', orange: 'ffa500' };
  let r, g, b, m; c = c.replace(/\s*!important$/, '').split(/\s+/)[0];
  if ((m = c.match(/^#?([0-9a-f]{6})$/))) { r = parseInt(m[1].slice(0, 2), 16); g = parseInt(m[1].slice(2, 4), 16); b = parseInt(m[1].slice(4, 6), 16); }
  else if ((m = c.match(/^#?([0-9a-f]{3})$/))) { r = parseInt(m[1][0] + m[1][0], 16); g = parseInt(m[1][1] + m[1][1], 16); b = parseInt(m[1][2] + m[1][2], 16); }
  else if ((m = c.match(/^rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/))) { r = +m[1]; g = +m[2]; b = +m[3]; }
  else if (NAMED[c]) return shadeOf('#' + NAMED[c]); else return null;
  const L = (0.299 * r + 0.587 * g + 0.114 * b) / 255; return L >= 0.96 ? null : L >= 0.84 ? 'light' : L >= 0.55 ? 'gray' : 'dark';
}
function sheetGrid(html) {
  let dd; try { dd = new DOMParser().parseFromString(html, 'text/html'); } catch { return null; } const table = dd.querySelector('table'); if (!table) return null;
  const css = {}; for (const st of dd.querySelectorAll('style')) for (const m of st.textContent.matchAll(/\.([\w-]+)\s*\{([^}]*)\}/g)) css[m[1]] = (css[m[1]] || '') + ';' + m[2];
  const decl = t => { const o = {}; for (const part of String(t).split(';')) { const k = part.indexOf(':'); if (k > 0) o[part.slice(0, k).trim().toLowerCase()] = part.slice(k + 1).trim().replace(/^['"]|['"]$/g, ''); } return o; };
  const textOf = td => { const c = td.cloneNode(true); c.querySelectorAll('br').forEach(b => b.replaceWith('\u2028')); return c.textContent.replace(/\u00a0/g, ' ').replace(/[ \t\r\n]+/g, ' ').replace(/\s*\u2028\s*/g, ' ').trim(); };
  const rows = []; let any = false;
  table.querySelectorAll('tr').forEach((tr, r) => { const row = rows[r] = rows[r] || []; let c = 0;
    for (const td of tr.children) { if (!/^(TD|TH)$/.test(td.tagName)) continue; while (row[c]) c++;
      const stl = decl((td.className ? String(td.className).split(/\s+/).map(k => css[k] || '').join(';') : '') + ';' + (td.getAttribute('style') || ''));
      const text = textOf(td); const inner = (sel) => { const e = td.querySelector(sel); return !!e && textOf(e) === text && text !== ''; };
      const fw = stl['font-weight'] || ''; const deco = (stl['text-decoration'] || '') + ' ' + (stl['text-line-through'] || '');
      const cell = { text, bold: /^(bold|bolder|[6-9]00)$/.test(fw) || inner('b,strong'), under: /underline/.test(deco) || (!!stl['text-underline-style'] && stl['text-underline-style'] !== 'none') || inner('u'), strike: /line-through|single/.test(deco) || inner('s,strike,del'),
        align: ({ right: 'right', center: 'center', centre: 'center', justify: 'justify' })[(stl['text-align'] || td.getAttribute('align') || '').toLowerCase()] || null, shade: shadeOf(stl['background'] || stl['background-color'] || td.getAttribute('bgcolor')) };
      if (cell.bold || cell.under || cell.strike || cell.align || cell.shade) any = true;
      const cs = Math.max(1, Math.min(50, +td.getAttribute('colspan') || 1)), rs = Math.max(1, Math.min(500, +td.getAttribute('rowspan') || 1));
      for (let dr = 0; dr < rs; dr++) for (let dc = 0; dc < cs; dc++) { const rr = rows[r + dr] = rows[r + dr] || []; rr[c + dc] = dr || dc ? { text: '', shade: cell.shade, cont: true } : cell; }
      c += cs; } });
  const n = Math.max(0, ...rows.map(r => r.length)); if (!rows.length || !n) return null;
  for (const r of rows) for (let k = 0; k < n; k++) if (!r[k]) r[k] = { text: '' };
  while (rows.length && rows[rows.length - 1].every(x => !x.text)) rows.pop(); return rows.length ? { rows, styled: any } : null;
}
/* 書式付きの表を差し込む：Markdown の表で組んでから、セルの太字・下線・取消線・揃え・網を当てる */
function insertSheet(grid) {
  const esc2 = t => t.replace(/\|/g, '｜').replace(/([\\`*_\[\]<>~])/g, '\\$1'); const n = grid.rows[0].length;
  const md = grid.rows.map((r, i) => '| ' + r.map(c => esc2(c.text)).join(' | ') + ' |' + (i === 0 ? '\n|' + Array.from({ length: n }, () => ' --- ').join('|') + '|' : '')).join('\n') + '\n';
  const d = FZ.fromMarkdown(md, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true });
  const tl = []; d.lines.forEach((l, i) => { if (l.attrs.cells) tl.push(i); }); if (tl.length !== grid.rows.length) { insertDoc(d); return; }
  const shaded = grid.rows.some(r => r.some(c => c.shade)); if (shaded) d.fills = d.fills.filter(x => x.from > tl[tl.length - 1] || x.to < tl[0]); // Excel に網があれば、文机の既定の見出しの網の代わりに Excel の網
  tl.forEach((li, r) => { const ln = d.lines[li]; const cells = grid.rows[r]; const segs = ln.segs.slice().sort((a, b) => a.col - b.col); const bounds = FZ.cellsAt(d, li, d.format.cols);
    const al = cells.map(c => c.align || null); if (al.some(Boolean)) ln.attrs.cellAlign = al.map(x => x || 'left');
    segs.forEach((sg, k) => { const c = cells[k]; if (!c) return; const add = (c.bold ? M.BOLD : 0) | (c.under ? M.UNDER : 0) | (c.strike ? M.STRIKE : 0); if (add) sg.marks = sg.marks.map(m => m | add); });
    let k = 0; while (k < cells.length) { const sh = cells[k].shade; if (!sh || !bounds[k]) { k++; continue; } let e = k; while (e + 1 < cells.length && cells[e + 1].shade === sh && bounds[e + 1]) e++; d.fills.push({ id: FZ.uid(), col: bounds[k].left, cols: bounds[e].right - bounds[k].left, from: li, to: li, shade: sh }); k = e + 1; } });
  insertDoc(d);
}
ta.addEventListener('paste', e => {
  if (st.mode === 'tree') { e.preventDefault(); treePaste(e.clipboardData.getData('text/plain') || ''); return; }
  e.preventDefault(); const dt = e.clipboardData; const text = dt.getData('text/plain'); const html = dt.getData('text/html') || ''; const src = clipSource(html);
  const imgItem = [...(dt.items || [])].find(x => x.kind === 'file' && /^image\//.test(x.type)); const shift = st.lastPasteShift;
  if (st.mode !== 'text' || ed.line().attrs.figure || ed.line().attrs.toc || ed.line().attrs.hr) return;
  /* 貼り付けの振り分け：Excel・スプレッドシートのセル（2 つ以上）→ 表。図・画像（Excel のグラフ、PowerPoint の図形・画像、画面の切り取り、ブラウザの画像）→ 図表（挿入の「画像」と同じ）。
     それ以外の文字（Word・ブラウザの文章）は従来どおり。Word の文章には画面の絵も付いてくるが、文字を優先する。Ctrl+Shift+V は文字のまま */
  /* 1.0.15d（B-8）表の中へ貼る：タブ区切り（Excel のセル・文机のセルの写し）はカーソルのセル（選んだセルの左上）からセルへ流し込む。行が足りなければ足す */
  if (!shift && text && FZ.inTable(ed.doc, ed.caret.line)) { const t0 = text.replace(/\r/g, '').replace(/\n+$/, ''); if (/\t/.test(t0) || ((src === 'excel' || src === 'sheets') && /\n/.test(t0))) { const rows = FZ.parseTSV(t0);
      if (rows.length > 1 || (rows[0] && rows[0].length > 1)) { const R = st.cells ? cellRect() : null; st.cells = null; const r = FZ.tbl.pasteInto(ed, rows, R ? { line: R.la, j: R.ca } : null); st.lastPasteShift = false; ed.breakUndo(); requestOverlay();
        if (r) msg(`${r.rows} 行 × ${r.cols} 列をセルへ流し込みました${r.added ? `（行を ${r.added} 足した）` : ''}${r.cut ? `。右にはみ出た ${r.cut} セルは入れていません` : ''}（Ctrl+Z で戻る／Ctrl+Shift+V で字のまま）`, false, 6000); return; } } }
  const sheet = (src === 'excel' || src === 'sheets') && /<table/i.test(html) && text;
  if (sheet && !shift) { const rows = FZ.parseTSV(text); const n = rows.reduce((t, r) => t + r.length, 0);
    if (n >= 2) { const grid = sheetGrid(html); const tsvRows = rows.length; const imgP = imgItem && imgItem.getAsFile() ? readImageBlob(imgItem.getAsFile(), '') : null; if (imgP) imgP.catch(() => { });
      if (grid && grid.rows.length === tsvRows) insertSheet(grid); else insertMarkdown(FZ.tsvToMarkdown(text));
      st.lastPaste = { kind: 'sheet', snap: ed.undoStack[ed.undoStack.length - 1], img: imgP }; st.lastPasteShift = false; ed.breakUndo();
      msg((src === 'excel' ? 'Excel' : 'スプレッドシート') + ' のセルを表として貼り付け' + (grid && grid.styled ? '（太字・揃え・網を写す）' : '') + '：' + (FZ.chartable && FZ.chartable(rows) ? 'Ctrl+G でグラフに／' : '') + (imgP ? 'Ctrl+Alt+V で見た目のまま図に／' : '') + 'Ctrl+Z で取消／Ctrl+Shift+V で文字のまま', false, 8000); return; }
    ed.insertText(text.replace(/\r?\n$/, ''), { key: '' }); st.lastPasteShift = false; ed.breakUndo(); return; } // セル 1 つは文字（末尾の改行は付けない）
  if (imgItem && (!text.trim() || src === 'powerpoint' || ((src === 'excel' || src === 'sheets') && !/<table/i.test(html)))) { const fl = imgItem.getAsFile(); st.lastPasteShift = false;
    if (fl) readImageBlob(fl, '').then(r => { addImageFigure(r); if (src === 'powerpoint' || src === 'excel') msg((src === 'excel' ? 'Excel のグラフ・図' : 'PowerPoint の図形・画像') + 'を図として貼り付け：題を入れて Enter'); }, er => msg('画像を貼り付けられませんでした：' + er.message, true)); return; } // 図・画像 → 図表
  if (!text) return;
  if (st.clip && st.clip.plain === text) { ed.insertText(st.clip.raw, { key: '' }); ed.breakUndo(); return; } // 文机の中でのコピー：図番の字を保ったまま
  if (!st.lastPasteShift && !/\n./.test(text.replace(/\r/g, '').replace(/\n+$/, '')) && /\*\*[^*\n]+\*\*|~~[^~\n]+~~/.test(text) && insertInlineMarkdown(text)) { st.lastPasteShift = false; ed.breakUndo(); msg('太字・取消線を整えて貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); return; } // 1 行の **太字**
  const multi = text.replace(/\r/g, '').split('\n').length >= 2;
  if (!st.lastPasteShift && FZ.looksLikeTSV(text)) { insertMarkdown(FZ.tsvToMarkdown(text)); msg('表として貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else if (!st.lastPasteShift && multi && FZ.looksLikeMarkdown(text)) { insertMarkdown(text); msg('Markdown として整形（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else if (!st.lastPasteShift && multi && st.jaLift && FZ.jaMarkerCount(text) >= 2) { insertMarkdown(text); msg('和文の番号・記号を見出し・箇条書きに起こして貼り付け（Ctrl+Z で取消／Ctrl+Shift+V でそのまま貼付）'); st.lastPaste = null; }
  else { ed.insertText(text, { key: '' }); st.lastPaste = { text, snap: ed.undoStack[ed.undoStack.length - 1] }; if (multi && FZ.markdownSignals(text).inline + FZ.markdownSignals(text).list) msg('そのまま貼り付け（Markdown として整形：Ctrl+Alt+V）'); }
  st.lastPasteShift = false; ed.breakUndo();
});
/* 1 行の Markdown（**太字** ~~取消~~ リンク）を、今の位置に文字として差し込む（行は分けない）。段落 1 つにならなければ false */
function insertInlineMarkdown(text) {
  let d; try { d = FZ.fromMarkdown(text.replace(/\r?\n+$/, ''), { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true }); } catch { return false; }
  const ls = d.lines.filter(l => l.segs.some(s => s.text)); if (ls.length !== 1 || ls[0].segs.length !== 1 || ls[0].attrs.style || ls[0].attrs.list || ls[0].attrs.cells) return false; const sg = ls[0].segs[0];
  ed.mutate('', () => { ed.deleteSelection(); ed.materialize(); const seg = ed.seg(), at = ed.caret.off; ed.spliceSeg(seg, at, at, sg.text, sg.marks.map(m => (m & ~M.LINK) | (ed.typing & ~M.LINK))); if (sg.links) { seg.links = (seg.links || []).concat(sg.links.map(l => ({ ...l, start: l.start + at, end: l.end + at }))); FZ.syncLinks(seg); } ed.caret.off = at + sg.text.length; ed.caret.vcol = null; ed.anchor = null; });
  return true;
}
/* 直前にそのまま貼った文字列を Markdown として整形し直す（取り消してから変換。クリップボードは読まない） */
function pasteAsMarkdown() {
  const lp = st.lastPaste;
  if (lp && lp.kind === 'sheet') { // Excel のセルを表で貼った直後：見た目のまま図に貼り直す（表を取り消してから図）
    if (!lp.snap || ed.undoStack[ed.undoStack.length - 1] !== lp.snap) { msg('直前の貼り付けがありません（表を貼った直後に Ctrl+Alt+V）', true); return; }
    if (!lp.img) { msg('コピー元が図を渡していないので、図にできません', true); return; }
    lp.img.then(r => { if (ed.undoStack[ed.undoStack.length - 1] !== lp.snap) return; ed.mutate('', () => ed.restore(lp.snap)); st.lastPaste = null; addImageFigure(r); msg('Excel のセルを図に貼り直しました（題を入れて Enter／Ctrl+Z で表に戻る）'); }, er => msg('図を読めませんでした：' + er.message, true)); return; } if (!lp || !lp.snap || ed.undoStack[ed.undoStack.length - 1] !== lp.snap) { msg('直前の貼り付けがありません（貼り付けた直後に Ctrl+Alt+V）', true); return; }
  insertMarkdown(lp.text, lp.snap); st.lastPaste = null; ed.breakUndo(); msg('Markdown として整形（Ctrl+Z でそのままの貼付に戻る）');
}
/* Markdown を今の文書に差し込む。貼付なので「# が 1 つなら表題」にはせず、改行は行として保つ（ワープロの作法） */
function insertMarkdown(text, before) { // before：この状態に戻してから差し込む（そのまま貼った直後の整形し直し）
  if (text.length > BIG_TEXT && getWorker()) { parseText(text, 'md', { fragment: true, hardBreaks: true }, JSON.parse(JSON.stringify(ed.doc.format))).then(d => insertDoc(d, before)).catch(e => msg('整形できませんでした：' + e.message, true)); return; }
  insertDoc(FZ.fromMarkdown(text, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true, hardBreaks: true }), before);
}
function insertDoc(d, before) {
  if (st.jaLift) FZ.liftJaMarkers(d);
  ed.mutate('', () => {
    if (before) ed.restore(before);
    ed.deleteSelection(); ed.materialize(); const c = ed.caret; let at = c.line; const cur = ed.line();
    const replace = cur.segs.length === 1 && cur.segs[0].text === '' && !FZ.inTable(ed.doc, at) && !cur.attrs.list && !cur.attrs.style && !cur.attrs.fw; /* 空の箇条書き・見出しの行は残す（フレームワークの空の項目を消さない） */
    if (!replace) at = c.line + 1;
    d.lines.forEach((ln, k) => ed.insertLine(at + k, ln));
    for (const r of d.rules) { if (r.axis === 'h') r.line += at; else { r.from += at; r.to += at; } ed.doc.rules.push(r); }
    for (const f of d.fills) { f.from += at; f.to += at; ed.doc.fills.push(f); }
    if (replace) ed.removeLine(at + d.lines.length);
    ed.dedupeRules(); ed.normalizeSegs();
    const last = at + d.lines.length - 1; const ll = ed.doc.lines[last]; ed.caret = { line: last, seg: ll.segs.length - 1, off: ll.segs[ll.segs.length - 1].text.length, vcol: null, vrow: 0 }; ed.anchor = null;
  });
}
/* ---------- 文書の挿入・分割（専用機の「他文書の結合」「文書分割」） ---------- */
/* 挿入する文書の画像・図表・図番を、今の文書と重ならないように付け替える（同じ名前で中身が違う画像は名前を変える。図表の ID が重なれば変える。図番の字は今の文書の表で振り直す） */
function mergeAssets(d) {
  const imgMap = new Map(); ed.doc.images = ed.doc.images || {};
  for (const [nm, img] of Object.entries(d.images || {})) { const cur = ed.doc.images[nm]; if (!cur) { ed.doc.images[nm] = img; continue; } if (cur.data === img.data) continue; let k = 2, nn; const m = nm.match(/^(.*?)(\.[^.]*)?$/); do { nn = m[1] + '_' + k++ + (m[2] || ''); } while (ed.doc.images[nn]); ed.doc.images[nn] = img; imgMap.set(nm, nn); }
  const ids = new Set(); for (const ln of ed.doc.lines) for (const fg of ln.attrs.figs || []) ids.add(fg.id); const idMap = new Map();
  for (const ln of d.lines) { for (const fg of ln.attrs.figs || []) { if (imgMap.has(fg.file)) fg.file = imgMap.get(fg.file); if (ids.has(fg.id)) { let k = 2; while (ids.has(fg.id + '_' + k)) k++; idMap.set(fg.id, fg.id + '_' + k); fg.id = fg.id + '_' + k; } ids.add(fg.id); }
    for (const sg of ln.segs) { if (sg.links) for (const l of sg.links) if (l.image && imgMap.has(l.url)) l.url = imgMap.get(l.url);
      if (FZ.hasRefs(sg.text)) { let t = ''; for (const ch of sg.text) { const id = FZ.refId(d, ch); t += id != null ? FZ.refChar(ed.doc, idMap.get(id) || id) : ch; } sg.text = t; } } }
}
async function insertFileHere() {
  let r; try { r = await FZ.files.open(); } catch (e) { msg('開けませんでした：' + e.message, true); return; } if (!r) return;
  const isMd = /\.(md|markdown)$/i.test(r.name || ''); let d;
  try { d = /^\uFEFF?#fzk\b/.test(r.text) ? FZ.parse(r.text) : isMd ? FZ.fromMarkdown(r.text, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(ed.doc.format)) }, { fragment: true }) : FZ.parse(r.text); } catch (e) { msg('読めませんでした：' + e.message, true); return; }
  mergeAssets(d); insertDoc(d); render(); msg(`「${r.name}」を挿入しました（${d.lines.length} 行。${K('undo')} で取り消し）`);
}
/* カーソルの行から文末までを別の文書として保存し、保存できたらこの文書から除く（取り消しで戻せる） */
async function splitHere() {
  if (st.mode !== 'text') exitMode(); const L = ed.caret.line, N = ed.doc.lines.length; if (L === 0) { msg('文書の先頭では分けられません（分けたい行にカーソルを置く）', true); return; }
  const e2 = new FZ.Editor(); e2.onChange = () => { }; e2.onCaret = () => { }; e2.setDoc(FZ.parse(FZ.serialize(ed.doc))); for (let k = 0; k < L; k++) e2.removeLine(0);
  const tail = FZ.serialize(e2.doc); const base = baseTitle();
  let r; try { r = await FZ.files.saveAs(tail, base + '_後半.fzk'); } catch (e) { msg('保存できませんでした：' + e.message, true); return; } if (!r) return;
  ed.mutate('split', () => { for (let k = N - 1; k >= L; k--) ed.removeLine(k); if (!ed.doc.lines.length) ed.insertLine(0, FZ.newLine()); const last = ed.doc.lines.length - 1; ed.caret = { line: last, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; });
  render(); msg(`${L + 1} 行目から先を「${r.name}」に保存し、この文書から除きました（この文書は未保存。${K('undo')} で戻せる）`, false, 10000);
}
/* ローマ字をかなに（Rupo の「シフトミス訂正」）：選んだ範囲、無ければカーソルの直前の英字の続き */
function romajiHere() {
  if (st.mode !== 'text') return; let s = ed.selInSeg();
  if (!s) { if (ed.sel()) { msg('1 つのセルか段落の中を選んでください', true); return; } const c = ed.caret, t = ed.seg().text; let a = c.off; while (a > 0 && /[A-Za-z'\-]/.test(t[a - 1])) a--; if (a === c.off) { msg('カーソルの前に英字がありません（範囲を選んでも可）', true); return; } ed.setCaret({ line: c.line, seg: c.seg, off: a }); ed.setCaret({ line: c.line, seg: c.seg, off: c.off }, true); s = ed.selInSeg(); }
  const src = ed.textOf(s); const kana = FZ.romajiToKana(src); if (kana === src) { msg('かなに直せる英字がありません', true); return; }
  ed.insertText(kana, { key: 'romaji' }); flush(); msg(`「${src.slice(0, 20)}」をかなにしました。漢字にするには IME の再変換（変換キー）`);
}
/* 字数（専用機の文書情報表示）：全体と選択範囲。原稿用紙は 400 字詰め（20 字×20 行、段落ごとに行を改め、行頭 1 字下げ）で換算 */
function countInfo() {
  const isSp = ch => /[\s\u3000]/.test(ch); let all = 0, noSp = 0, paras = 0, rows = 0;
  for (const ln of ed.doc.lines) { const t = ln.segs.map(sg => sg.text).join(''); const n = [...t].length; all += n; let k = 0; for (const ch of t) if (!isSp(ch)) k++; noSp += k; if (k) paras++; rows += k ? Math.ceil((n + 1) / 20) : 1; }
  const s = ed.sel(); let sel = null; if (s) { const t = ed.textOf(s); const n = [...t.replace(/\n/g, '')].length; let k = 0; for (const ch of t) if (!isSp(ch)) k++; sel = { n, k }; }
  return { all, noSp, paras, rows, sheets: Math.ceil(rows / 20), pages: ed.lay.pages.length, sel };
}
FZ.countInfo = countInfo;
function prepareTyping() {
  if (st.cells) { st.cells = null; requestOverlay(); }
  autoCellify();
  const s = ed.sel(); const needDel = s && !ed.selInSeg();
  if (needDel || ed.caret.vcol != null || ed.caret.vrow > 0) { ed.pushUndo('type'); if (needDel) ed.deleteSelection(); ed.materialize(); ed.relayout(); ed.onChange('edit'); flush(); syncTA(); }
}
/* 空行に囲み（内側の縦罫線）があるとき、その中で打ち始めたら自動でセルにする（箱の中の文字） */
function autoCellify() {
  const c = ed.caret; const i = c.line; const ln = ed.line(); if (ln.attrs.cells || c.vrow > 0) return false;
  const vr = FZ.vRulesAt(ed.doc, i).filter(r => r.col > 0 && r.col < ed.lay.geo.cols); if (!vr.length) return false;
  if (!ln.segs.every(sg => !sg.text.trim())) return false;
  const xy = ed.xy(); const col = c.vcol != null ? c.vcol : (xy ? xy.col : 0);
  ed.mutate('', () => { ed.cellify(i); const cells = FZ.cellsAt(ed.doc, i); const k = Math.max(0, cells.findIndex(x => col >= x.left && col < x.right)); const l2 = ed.line(); let sidx = l2.segs.findIndex(sg => sg.col === cells[k].left); if (sidx < 0) { l2.segs.push(FZ.newSeg(cells[k].left, '')); l2.segs.sort((a, b) => a.col - b.col); sidx = l2.segs.findIndex(sg => sg.col === cells[k].left); } c.seg = sidx; c.off = 0; c.vcol = null; });
  flush(); syncTA(); return true;
}
/* ================= キー操作 ================= */
ta.addEventListener('keydown', e => { if (!/^F\d+$/.test(e.key) && !['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(e.key) && st.fkPrev) { st.fkPrev = null; updateGuide(); } }, true); /* F キーの 2 度押しの見張り：ほかのキーで解く */
ta.addEventListener('keydown', onKey);
function onKey(e) {
  if (st.mode !== 'text') { modeKey(e); return; }
  if (!st.composing && !e.isComposing && e.keyCode !== 229 && ta.value !== ed.seg().text) syncTA();
  if (e.isComposing || e.keyCode === 229 || e.key === 'Process') { prepareTyping(); return; }
  const k = e.key, ctrl = e.ctrlKey || e.metaKey, shift = e.shiftKey, alt = e.altKey;
  // 開いている子メニュー：1キーで実行して閉じる。合わないキーは閉じて通常処理
  if (st.armed && !ctrl && !alt && k.length === 1) { const it = GROUPS[st.group].items.find(it => it.key && it.key.toLowerCase() === k.toLowerCase()); if (it) { e.preventDefault(); const g0 = st.group; disarm(); runItem(it); if (st.group === g0) afterGroupItem(); if (it.msel) drawSub(); return; } disarm(); }
  if (/^F\d+$/.test(k) && !ctrl && !alt) { if (fkey(k)) e.preventDefault(); return; }
  if (st.cells && !['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(k)) { // セルの範囲を選んでいる：Delete で中身を消す、Esc でやめる、Ctrl+C で写す。ほかのキーは範囲を解いて通常どおり
    if ((k === 'Delete' || k === 'Backspace') && !ctrl) { e.preventDefault(); const R = cellRect(); st.cells = null; if (R) FZ.tbl.clearCells(ed, R); return; }
    if (k === 'Escape') { e.preventDefault(); st.cells = null; requestOverlay(); drawSub(); return; }
    if (ctrl && (k.toLowerCase() === 'c')) return;
    st.cells = null; requestOverlay(); }
  if (k === 'Escape') { e.preventDefault(); escape(); return; }
  if (ctrl && !alt) {
    const lk = k.toLowerCase(); let done = true;
    switch (lk) {
      case 's': run(shift ? 'saveAs' : 'save'); break; case 'o': run(shift ? 'outlinePanel' : 'open'); break; case 'z': shift ? run('redo') : run('undo'); break; case 'y': run('redo'); break;
      case 'f': run('find'); break; case 'h': run('replace'); break; case 'p': run('print'); break; case 'k': run('palette'); break; case 'a': ed.selectAll(); break;
      case 'b': run('bold'); break; case 'u': run('under'); break; case 'e': run('alignC'); break; case 'r': run('alignR'); break; case 'j': run('alignJ'); break;
      case 'l': if (shift) run('link'); else run('alignL'); break; case 'g': run(shift ? 'grid' : 'chart'); break;
      case 'home': ed.docStart(shift); break; case 'end': ed.docEnd(shift); break;
      case '=': case '+': case ';': run('zoomIn'); break; case '-': run('zoomOut'); break; case '0': run(shift ? 'zoomPage' : 'zoomFit'); break;
      case 'v': st.lastPasteShift = shift; done = false; break; case 'c': case 'x': done = false; break;
      case 'enter': run('pageBreak'); break; case 'n': run('new'); break; case 'm': run(shift ? 'posLeft' : 'moveTo'); break; // Ctrl+M：送り先を選んで移す（S3）。位置は F6→J／H、Ctrl+Shift+M は左へ
      case 'arrowup': run('outlineUp'); break; case 'arrowdown': run('outlineDown'); break;
      case 'arrowleft': ed.wordMove(-1, shift); break; case 'arrowright': ed.wordMove(1, shift); break; /* 語ごと（Shift で選ぶ） */
      case 'backspace': case 'delete': { const a0 = ed.line().attrs; if (st.reveal) { if (lk === 'backspace') ganttGuardKey('Backspace') || ed.wordDelete(-1); else ed.wordDelete(1); break; } if (!(a0.hr || a0.toc || a0.figure)) ed.wordDelete(lk === 'backspace' ? -1 : 1); break; } /* 語ごとに消す（区切り線・目次・図の行では何もしない） */
      default: done = false;
    }
    if (done) e.preventDefault(); return;
  }
  if (ctrl && alt && k.toLowerCase() === 'v') { e.preventDefault(); run('pasteMd'); return; }
  if (ctrl && alt && k.toLowerCase() === 'm') { e.preventDefault(); run('noteAdd'); return; }
  if (alt && !ctrl && (k === 'PageDown' || k === 'PageUp')) { e.preventDefault(); noteStep(k === 'PageDown' ? 1 : -1); return; }
  if (alt && shift && (k === 'ArrowLeft' || k === 'ArrowRight')) { run(k === 'ArrowLeft' ? 'posLeft' : 'posRight'); e.preventDefault(); return; } /* Alt+Shift+←→：位置を左右へ（レベルは変えない） */
  if (alt && toolKey(e)) return; /* 1.0.15f 道具（Alt+1〜9） */
  if (alt) { const m2 = { ArrowUp: 'sx:up', ArrowDown: 'sx:down', ArrowLeft: 'sx:out', ArrowRight: 'sx:in' }[k]; if (m2) { run(m2); e.preventDefault(); } return; } // 構造の近道：紙面でもツリーと同じ意味（梯子・並べ替え）
  if (ed.line().attrs.hr && !ctrl) { // 区切り線の行：Enter で下に本文の行、Backspace/Delete で区切り線を消して空行に
    if (k === 'Enter') { e.preventDefault(); const at = ed.caret.line; ed.mutate('', () => { ed.insertLine(at + 1, FZ.newLine()); ed.caret = { line: at + 1, seg: 0, off: 0, vcol: null, vrow: 0 }; }); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); ed.setAttrs({ hr: null }); msg('区切り線を消しました'); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('区切り線の行には文字を入れられません', true); return; }
  }
  if (ed.line().attrs.toc && !ctrl) { // 目次の行：Enter で範囲の設定、Backspace/Delete で目次を消して空行に
    if (k === 'Enter') { e.preventDefault(); openForm('toc'); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); ed.removeToc(ed.caret.line); msg('目次を消しました'); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('目次の行には文字を入れられません（Enter で範囲の設定）', true); return; }
  }
  if (ed.line().attrs.figure && !ctrl) { // 図の行：Enter で図の編集へ。箱が無ければ Backspace/Delete で本文の空行に戻す
    if (k === 'Enter') { e.preventDefault(); enterFigMode(ed.caret.line); return; }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); if (!ed.line().attrs.figure.boxes.length) ed.removeFigure(ed.caret.line); else msg('図を消すには、箱をすべて消してから Backspace', true); return; }
    if (k === 'Tab' || k.length === 1) { e.preventDefault(); if (k.length === 1) msg('図の中は Enter で編集', true); return; }
  }
  if (!ctrl && !alt && !shift && ganttGuardKey(k)) { e.preventDefault(); return; }
  let handled = true;
  switch (k) {
    case 'Enter': if (shift) ed.softBreak(); else ed.enter(); break; case 'Tab': ed.tab(shift); break; /* Shift+Enter：段落・項目の中の改行 */ case 'Backspace': ed.backspace(); break; case 'Delete': ed.del(); break;
    case 'ArrowLeft': ed.moveH(-1, shift); break; case 'ArrowRight': ed.moveH(1, shift); break; case 'ArrowUp': ed.moveV(-1, shift); if (!shift) ed.cellSnap(); break; case 'ArrowDown': ed.moveV(1, shift); if (!shift) ed.cellSnap(); break;
    case 'Home': ed.home(shift); break; case 'End': ed.end(shift); break;
    case 'PageUp': for (let i = 0; i < Math.max(4, ed.lay.geo.rows - 4); i++) ed.moveV(-1, shift); break; case 'PageDown': for (let i = 0; i < Math.max(4, ed.lay.geo.rows - 4); i++) ed.moveV(1, shift); break;
    default: handled = false;
  }
  if (handled) { e.preventDefault(); return; }
  if (k.length === 1) prepareTyping();
}
function escape() { if (st.form) { closeForm(); return; } if (GROUPS[st.group] && GROUPS[st.group].parent) { showGroup(GROUPS[st.group].parent); return; } if (st.armed) { disarm(); return; } if (st.side) { closeSide(); return; } if (ed.sel()) { ed.anchor = null; ed.onCaret(); } }
function fkey(k) {
  const map = FK[st.mode === 'fill' ? 'fill' : st.mode === 'rule' ? 'rule' : st.mode === 'fig' ? 'fig' : 'text']; const item = map.find(x => x[0] === k); /* ツリーも紙面と同じ F キー */ if (!item || !item[2]) { if (FK_HIDDEN[k]) { run(FK_HIDDEN[k]); return true; } return false; }
  const g = GROUP_OF[item[2]]; /* P06：同じ F キーを続けて 2 回で、帯の項目をキーで選ぶ（1 回目は帯の切り替えだけ。押した後の字は本文に入る） */
  if (g && st.fkPrev === k && st.group === g && !st.form && (st.mode === 'text' || st.mode === 'tree')) { st.fkPrev = null; bandEnter(); return true; }
  run(item[2]); st.fkPrev = g && (st.mode === 'text' || st.mode === 'tree') ? k : null; updateGuide(); return true;
}
/* ---------- 罫線・網掛けモードのキー ---------- */
function modeKey(e) {
  if (st.mode === 'tree') { treeKeyDown(e); return; }
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey;
  if (e.isComposing || e.keyCode === 229) { e.preventDefault(); return; }
  if (st.mode === 'fig') { figKey(e); return; }
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  e.preventDefault();
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.ranchor) { st.ranchor = null; requestOverlay(); return; } exitMode(); return; }
  if (ctrl && k.toLowerCase() === 'z') { shift ? ed.redo() : ed.undo(); return; } if (ctrl && k.toLowerCase() === 'y') { ed.redo(); return; }
  if (ctrl && k.toLowerCase() === 's') { run('save'); return; } if (ctrl && k.toLowerCase() === 'k') { run('palette'); return; }
  const dir = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' }[k];
  if (dir) { if (st.mode === 'fill' || st.sub === 'rect') { if (!st.ranchor) st.ranchor = { ...st.rc }; ruleMove(dir); } else ruleStep(dir, !shift); return; }
  if (st.mode === 'fill' && !ctrl && k.length === 1) { const id = Object.keys(SWATCH_KEY).find(x => SWATCH_KEY[x] === k.toUpperCase()); if (id) { run('s:' + id); return; } } // 見本の 1 文字で文様を選ぶ
  if (k === 'Enter') { if (st.mode === 'fill') applyFill(); else if (st.sub === 'rect') applyRect(); else { st.ranchor = { ...st.rc }; st.sub = 'rect'; drawSub(); drawFkeys(); status(); } return; }
  if (k === 'Home') { st.rc.col = 0; requestOverlay(); return; } if (k === 'End') { st.rc.col = ed.lay.geo.cols; requestOverlay(); return; }
  if (k === 'PageDown') { if (st.rc.page < ed.lay.pages.length - 1) { st.rc.page++; st.rc.y = 0; st.ranchor = null; requestOverlay(); scrollToCaret(); } return; }
  if (k === 'PageUp') { if (st.rc.page > 0) { st.rc.page--; st.rc.y = 0; st.ranchor = null; requestOverlay(); scrollToCaret(); } return; }
  if (k === 'Backspace' || k === 'Delete') { st.sub = st.sub === 'erase' ? null : 'erase'; drawSub(); drawFkeys(); status(); return; }
}
/* ================= 罫線モード ================= */
function enterFillMode() { if (st.mode === 'tree') exitTree(); if (st.mode === 'fig') { st.fig = null; st.mode = 'text'; } if (st.mode === 'text') { const xy = ed.xy(); st.rc = xy ? { page: xy.page, y: Math.max(0, xy.y), col: Math.max(0, Math.floor(xy.col)) } : { page: 0, y: 0, col: 0 }; } st.mode = 'fill'; st.sub = null; st.ranchor = null; st.preview = null; ed.anchor = null; st.group = null; st.form = null; render(); drawFkeys(); drawSub(); focusTA(); }
function exitMode() { if (st.mode === 'tree') { if (st.treeCmd) return; /* コマンドの中から呼ばれたとき（st.treeCmd）はツリーのまま */ exitTree(); return; } if (st.mode === 'fig') { exitFigMode(); return; } st.mode = 'text'; st.sub = null; st.ranchor = null; st.preview = null; const rc = st.rc; const pos = FZ.xyToPos(ed.lay, rc.page, Math.min(rc.y, Math.max(0, ed.lay.geo.rows - 1)), rc.col); if (pos) ed.setCaret(pos); render(); drawFkeys(); drawSub(); syncTA(); focusTA(); }
function ruleMove(dir) { const rc = st.rc, geo = ed.lay.geo; const maxY = geo.rows; if (dir === 'left') rc.col = Math.max(0, rc.col - 1); if (dir === 'right') rc.col = Math.min(geo.cols, rc.col + 1); if (dir === 'up') rc.y = Math.max(0, rc.y - 1); if (dir === 'down') rc.y = Math.min(maxY, rc.y + 1); requestOverlay(); scrollToCaret(); }
function ensureRows(page, y) { const e = ed.lay.endPos; if (page !== e.page || y < e.y) return; const need = y - e.y + 1; for (let k = 0; k < need; k++) ed.insertLine(ed.doc.lines.length, FZ.newLine()); ed.relayout(); }
function hSeg(page, y, from, to, erase, dir) { ed.mutate('rule', () => { let line = ed.hAnchorAt(page, y); if (line == null) { ensureRows(page, y - 1); line = ed.hAnchorAt(page, y); } if (line == null) { msg('折返し行の途中には横線を引けません', true); return; } if (erase) ed.eraseH(line, from, to); else { const id = ed.addHRule(line, from, to, st.ruleKind, dir); } }); }
function vSeg(page, y, col, erase, dir) { ed.mutate('rule', () => { let line = ed.vAnchorAt(page, y); if (line == null) { ensureRows(page, y); line = ed.vAnchorAt(page, y); } if (line == null) return; if (erase) ed.eraseV(line, line, col); else { const id = ed.addVRule(line, line, col, st.ruleKind, dir); } }); }
function ruleStep(dir, draw) {
  const rc = st.rc, geo = ed.lay.geo, erase = st.sub === 'erase'; const maxY = geo.rows;
  if (dir === 'right') { if (rc.col >= geo.cols) return; if (draw) hSeg(rc.page, rc.y, rc.col, rc.col + 1, erase, 'r'); rc.col++; }
  if (dir === 'left') { if (rc.col <= 0) return; if (draw) hSeg(rc.page, rc.y, rc.col - 1, rc.col, erase, 'l'); rc.col--; }
  if (dir === 'down') { if (rc.y >= maxY) return; if (draw) vSeg(rc.page, rc.y, rc.col, erase, 'd'); rc.y++; }
  if (dir === 'up') { if (rc.y <= 0) return; if (draw) vSeg(rc.page, rc.y - 1, rc.col, erase, 'u'); rc.y--; }
  requestOverlay(); scrollToCaret();
}
function rectCoords() { const a = st.ranchor || st.rc, b = st.rc; return { page: b.page, y1: Math.min(a.y, b.y), y2: Math.max(a.y, b.y), c1: Math.min(a.col, b.col), c2: Math.max(a.col, b.col) }; }
function applyRect() {
  const r = rectCoords(); if (r.y2 <= r.y1 || r.c2 <= r.c1) { st.ranchor = null; requestOverlay(); return; }
  ed.mutate('', () => { ensureRows(r.page, r.y2 - 1); const la = ed.hAnchorAt(r.page, r.y1), lb = ed.hAnchorAt(r.page, r.y2); const vf = ed.vAnchorAt(r.page, r.y1), vt = ed.vAnchorAt(r.page, r.y2 - 1);
    if (la == null || lb == null || vf == null || vt == null) { msg('この範囲には囲みを引けません（折返し行の途中）', true); return; }
    if (st.sub === 'erase') { ed.eraseH(la, r.c1, r.c2); ed.eraseH(lb, r.c1, r.c2); ed.eraseV(vf, vt, r.c1); ed.eraseV(vf, vt, r.c2); } else { ed.addHRule(la, r.c1, r.c2, st.ruleKind); ed.addHRule(lb, r.c1, r.c2, st.ruleKind); ed.addVRule(vf, vt, r.c1, st.ruleKind); ed.addVRule(vf, vt, r.c2, st.ruleKind); } });
  st.ranchor = null; st.sub = null; drawSub(); drawFkeys();
}
function applyFill() {
  const r = rectCoords(); if (r.y2 <= r.y1 || r.c2 <= r.c1) { st.ranchor = null; requestOverlay(); return; }
  ed.mutate('', () => { ensureRows(r.page, r.y2 - 1); const vf = ed.vAnchorAt(r.page, r.y1), vt = ed.vAnchorAt(r.page, r.y2 - 1); if (vf == null || vt == null) return; ed.addFill(vf, vt, r.c1, r.c2 - r.c1, st.shade); });
  st.ranchor = null; drawSub();
}
/* ================= 図モード（フローチャート） =================
 * 紙面の上で直接いじる：クリックで選ぶ（Shift で足す）、ドラッグで動かす、四隅・辺のつまみで大きさ、箱の辺の点から別の箱へドラッグで矢印、
 * 空いた所をダブルクリックで箱を足す、箱・矢印をダブルクリックでその場で文字、空いた所をドラッグで囲んで選ぶ、図の下端のつまみで高さ。
 * キー（Tab・矢印・N・C・Delete…）とコマンドも残す */
function figInfo(line = st.fig ? st.fig.line : ed.caret.line) {
  const ln = ed.doc.lines[line]; if (!ln || !ln.attrs.figure) return null; const lm = ed.lay.lineMap[line]; if (!lm || !lm.rows[0]) return null;
  const r = lm.rows[0], row = lm.segs[0].rows[0]; const F = ln.attrs.figure; const parts = lm.figParts && lm.figParts.length ? lm.figParts : [{ page: r.page, y0: r.y, f0: 0, f1: F.h }];
  /* 1.0.14f 頁に分けた図：図の行 y → 頁（P）と頁の中の行（Y）。図の外（上・下）は最初・最後の頁に */
  const partOf = y => parts.find(p => y >= p.f0 && y < p.f1) || (y < parts[0].f0 ? parts[0] : parts[parts.length - 1]);
  return { line, F, page: r.page, Y0: r.y, left: row.left, right: row.right, parts, P: y => partOf(y).page, Y: y => { const p = partOf(y); return p.y0 + y - p.f0; } };
}
function figRowAt(g) { const p = ed.lay.pages[g.page]; if (!p) return null; const es = p.rowmap.get(Math.floor(g.row)); const e = es && es.find(x => x.fig); return e ? e.line : null; }
function enterFigMode(line, sel) {
  const ln = ed.doc.lines[line]; if (!ln || !ln.attrs.figure) return; if (st.form) closeForm(); if (st.armed) disarm(); st.cells = null;
  ed.anchor = null; ed.setCaret({ line, seg: 0, off: 0 }); st.mode = 'fig'; st.sub = null; st.ranchor = null; st.preview = null;
  const F = ln.attrs.figure; st.fig = { line, sel: sel !== undefined ? sel : (F.boxes[0] ? F.boxes[0].id : null), multi: new Set(), selArrow: null, connecting: false, hover: null, band: null, link: null };
  render(); drawFkeys(); drawSub(); focusTA();
}
function exitFigMode() { closeInline(true); st.mode = 'text'; const line = st.fig ? st.fig.line : ed.caret.line; st.fig = null; st.sub = null; pagesEl.style.cursor = ''; if (ed.doc.lines[line]) ed.setCaret({ line, seg: 0, off: 0 }); render(); drawFkeys(); drawSub(); syncTA(); focusTA(); }
/* 選択：1 つなら sel、2 つ以上なら multi（sel はその最後＝つまみを出す箱ではない） */
function figIds() { if (!st.fig) return []; if (st.fig.multi && st.fig.multi.size) return [...st.fig.multi]; return st.fig.sel != null ? [st.fig.sel] : []; }
function figSetSel(ids) { const arr = [...new Set(ids)]; st.fig.selArrow = null; st.fig.multi = new Set(arr.length >= 2 ? arr : []); st.fig.sel = arr.length ? arr[arr.length - 1] : null; }
function figSelect(id, add) { const cur = new Set(figIds()); if (add) { if (cur.has(id)) cur.delete(id); else cur.add(id); } else { cur.clear(); if (id != null) cur.add(id); } figSetSel([...cur]); }
function figSel() { const fi = figInfo(); const ids = figIds(); if (!fi || ids.length !== 1) return null; return FZ.figureBox(fi.F, ids[0]) || null; }
function figPrim() { const fi = figInfo(); const ids = figIds(); return fi && ids.length ? FZ.figureBox(fi.F, ids[ids.length - 1]) || null : null; }
function figRefresh() { requestOverlay(); drawSub(); status(); }
function figCycle(dir) { // Tab：箱 → 矢印 の順に選択を巡る
  const fi = figInfo(); if (!fi) return; const F = fi.F; const items = [...F.boxes.map(b => ({ box: b.id })), ...F.arrows.map((a, k) => ({ arrow: k }))]; if (!items.length) return;
  let k = items.findIndex(it => (st.fig.sel != null && it.box === st.fig.sel) || (st.fig.selArrow != null && it.arrow === st.fig.selArrow)); k = (k + dir + items.length) % items.length; if (k < 0) k = 0;
  const it = items[k]; figSetSel(it.box != null ? [it.box] : []); st.fig.selArrow = it.arrow ?? null; figRefresh(); scrollToCaret();
}
function figMove(dx, dy, resize) {
  const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) { if (fi && fi.F.boxes.length) { figSetSel([fi.F.boxes[0].id]); figRefresh(); } return; }
  const W = fi.right - fi.left;
  ed.figOp(fi.line, F => { const bs = ids.map(id => FZ.figureBox(F, id)).filter(Boolean);
    if (resize) { const bb = bs[bs.length - 1]; bb.w = clamp(bb.w + dx, 2, W - bb.x); bb.h = clamp(bb.h + dy, 1, F.h - bb.y); return; }
    const ddx = clamp(dx, -Math.min(...bs.map(b => b.x)), W - Math.max(...bs.map(b => b.x + b.w))), ddy = clamp(dy, -Math.min(...bs.map(b => b.y)), F.h - Math.max(...bs.map(b => b.y + b.h)));
    for (const b of bs) { b.x += ddx; b.y += ddy; } }, resize ? 'figsize' : 'figmove');
  figRefresh();
}
/* 箱を足す：at（図の座標）があればそこを中心に、無ければ選んだ箱の隣。足したらその場で文字を打てる */
function figAddBox(at) {
  const fi = figInfo(); if (!fi) return; const W = fi.right - fi.left; const sel = figSel(); let newId = 0;
  ed.figOp(fi.line, F => { newId = F.boxes.reduce((m, b) => Math.max(m, b.id), 0) + 1; let spot; if (at) { spot = { x: clamp(half(at.x - 4), 0, Math.max(0, W - 8)), y: Math.max(0, Math.round(at.y - 1.5)) }; } else spot = FZ.figureFreeSpot(F, W, sel, 8, 3);
    const b = { id: newId, x: spot.x, y: spot.y, w: 8, h: 3, text: '', kind: 'thin', shade: null, bold: false }; if (spot.y + 3 > F.h) F.h = spot.y + 3; F.boxes.push(b); });
  figSetSel([newId]); figRefresh(); flush(); openInline('box', newId);
}
function figDelete() {
  const fi = figInfo(); if (!fi) return;
  if (st.fig.selArrow != null) { const k = st.fig.selArrow; ed.figOp(fi.line, F => { F.arrows.splice(k, 1); }); st.fig.selArrow = null; figRefresh(); return; }
  const ids = figIds(); if (!ids.length) return; const order = fi.F.boxes.map(x => x.id); const k = order.indexOf(ids[0]);
  ed.figOp(fi.line, F => { F.boxes = F.boxes.filter(x => !ids.includes(x.id)); F.arrows = F.arrows.filter(a => !ids.includes(a.from) && !ids.includes(a.to)); });
  const left = fi.F.boxes; figSetSel(left.length ? [left[clamp(k, 0, left.length - 1)].id] : []); figRefresh();
  if (!left.length) msg('箱がありません。Esc で本文へ戻り Backspace で図を消せます');
}
function figConnectStart() { const b = figPrim(); if (!b) { msg('まず箱を選んでください（箱の辺の点から別の箱へドラッグしてもつなげます）', true); return; } st.fig.connecting = b.id; st.fig.selArrow = null; figRefresh(); }
function figConnect(from, to) {
  const fi = figInfo(); if (!fi || from == null || to == null || to === from) { figRefresh(); return; }
  let idx = -1; ed.figOp(fi.line, F => { const k = F.arrows.findIndex(a => a.from === from && a.to === to); if (k >= 0) { idx = k; return; } F.arrows.push({ from, to, label: '', kind: 'thin' }); idx = F.arrows.length - 1; });
  figSetSel([]); st.fig.selArrow = idx; figRefresh(); msg('矢印でつなぎました（ダブルクリックでラベル、Delete で消す）');
}
function figConnectTo(targetId) { const from = st.fig.connecting; st.fig.connecting = false; figConnect(from, targetId); }
function figCycleProp(prop, vals) { const fi = figInfo(); const p = figPrim(); if (!fi || !p) return; const k = vals.indexOf(p[prop]); figSetProp(prop, vals[(k + 1) % vals.length]); }
function figSetProp(prop, val) { const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) { msg('箱を選んでください', true); return; } ed.figOp(fi.line, F => { for (const id of ids) { const b = FZ.figureBox(F, id); if (b) b[prop] = val; } }); figRefresh(); }
function figHeight(d) { const fi = figInfo(); if (!fi) return; ed.figOp(fi.line, F => { const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); F.h = clamp(F.h + d, minH, 200); }); figRefresh(); }
function figAlign(mode) { const fi = figInfo(); const ids = figIds(); if (!fi || ids.length < (mode[0] === 'd' ? 3 : 2)) { msg(mode[0] === 'd' ? '等間隔には箱を 3 つ以上選んでください（Shift+クリックか囲むドラッグ）' : '揃えるには箱を 2 つ以上選んでください（Shift+クリックか囲むドラッグ）', true); return; } ed.figOp(fi.line, F => FZ.figureAlign(F, ids, mode)); figRefresh(); }
function figDuplicate() { const fi = figInfo(); const ids = figIds(); if (!fi || !ids.length) return; let out = []; ed.figOp(fi.line, F => { out = FZ.figureDuplicate(F, ids, fi.right - fi.left); }); figSetSel(out); figRefresh(); }
function figKey(e) {
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey;
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  if (ctrl && k.toLowerCase() === 'z') { e.preventDefault(); shift ? ed.redo() : ed.undo(); figRefresh(); return; } if (ctrl && k.toLowerCase() === 'y') { e.preventDefault(); ed.redo(); figRefresh(); return; }
  if (ctrl && k.toLowerCase() === 's') { e.preventDefault(); run('save'); return; } if (ctrl && k.toLowerCase() === 'k') { e.preventDefault(); run('palette'); return; }
  if (ctrl && k.toLowerCase() === 'a') { e.preventDefault(); const fi = figInfo(); if (fi) { figSetSel(fi.F.boxes.map(b => b.id)); figRefresh(); } return; }
  if (ctrl && k.toLowerCase() === 'd') { e.preventDefault(); figDuplicate(); return; }
  if (ctrl) return;
  e.preventDefault();
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.fig.connecting) { st.fig.connecting = false; figRefresh(); return; } exitFigMode(); return; }
  if (k === 'Tab') { figCycle(shift ? -1 : 1); return; }
  const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
  if (d) { if (st.fig.connecting) { figCycle(d[0] + d[1] < 0 ? -1 : 1); return; } figMove(d[0], d[1], shift); return; }
  if (k === 'Enter') { if (st.fig.connecting) { figConnectTo(st.fig.sel); return; } if (st.fig.selArrow != null) { openInline('arrow', st.fig.selArrow); return; } const b = figPrim(); if (b) openInline('box', b.id); else figAddBox(); return; }
  if (k === 'Delete' || k === 'Backspace') { figDelete(); return; }
  const lk = k.toLowerCase();
  if (lk === 'n') figAddBox(); else if (lk === 'c') figConnectStart(); else if (lk === 't') { const b = figPrim(); if (b) openInline('box', b.id); } else if (lk === 'p') { if (figSel()) openForm('box'); } else if (lk === 'd') figDuplicate();
  else if (lk === 'k') figCycleProp('kind', ['thin', 'thick', 'double', 'dotted']); else if (lk === 's') figCycleProp('shade', [null, 'gray', 'deep', 'dark', 'hatch', 'dots']); else if (lk === 'b') figCycleProp('bold', [false, true]); else if (lk === 'l') openForm('lanes'); else if (k === '+' || k === ';' || k === '=') figHeight(1); else if (k === '-') figHeight(-1);
  else if (/^[1-9]$/.test(k)) { const fi = figInfo(); const b = fi && fi.F.boxes.find(x => x.id === +k); if (b) { if (st.fig.connecting) figConnectTo(b.id); else { figSetSel([b.id]); figRefresh(); } } }
}
/* ---------- その場の文字入力（箱の文字・矢印のラベル） ---------- */
let inl = null; // { el, kind: 'box'|'arrow', id, line }
function openInline(kind, id) {
  closeInline(true); const fi = figInfo(); if (!fi) return; const F = fi.F; const geo = ed.lay.geo;
  let x1, y1, w, h, text, fy = 0;
  if (kind === 'box') { const b = FZ.figureBox(F, id); if (!b) return; x1 = fi.left + b.x; fy = b.y; y1 = fi.Y(b.y); w = b.w; h = b.h; text = b.text; }
  else { const a = F.arrows[id]; const m = FZ.figureArrowMid(F, id); if (!a || !m) return; w = Math.max(8, FZ.textWidth(a.label) + 2); h = 1; x1 = fi.left + (m.horiz ? m.x - w / 2 : m.x + 0.5); fy = m.horiz ? Math.max(0, Math.floor(m.y) - 1) : Math.floor(m.y); y1 = fi.Y(fy); text = a.label; }
  const pp = pagePt(fi.P(fy)); if (!pp) return;
  const s = pp.scale, el = document.createElement('textarea'); el.className = 'inl' + (kind === 'arrow' ? ' one' : ''); el.value = text; el.spellcheck = false; el.setAttribute('aria-label', kind === 'box' ? '箱の文字' : '矢印のラベル');
  const lines = Math.max(1, String(text).split('\n').length), padTop = kind === 'box' ? Math.max(2, Math.floor(Math.max(0, h - lines) / 2) * geo.ch * s) : 2; // 箱の文字は上下の中ほどから
  Object.assign(el.style, { left: (pp.left + (geo.left + x1 * geo.cw) * s) + 'px', top: (pp.top + (geo.top + (geo.bodyTop + y1) * geo.ch) * s) + 'px', width: Math.max(48, w * geo.cw * s) + 'px', height: Math.max(20, h * geo.ch * s) + 'px', fontSize: Math.max(11, geo.fs * s * 0.9) + 'px', lineHeight: Math.max(13, geo.ch * s) + 'px', paddingTop: padTop + 'px' });
  main.append(el); st.formFocus = true; inl = { el, kind, id, line: fi.line };
  el.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.isComposing || ev.keyCode === 229) return; if (ev.key === 'Escape') { ev.preventDefault(); closeInline(false); } else if ((ev.key === 'Enter' && !ev.shiftKey && !ev.altKey) || ev.key === 'Tab') { ev.preventDefault(); closeInline(true); } });
  el.addEventListener('blur', () => { if (inl && inl.el === el) closeInline(true); });
  el.focus(); el.select(); msg(kind === 'box' ? '箱の文字：Enter で決定、Shift+Enter で改行、Esc で取消' : '矢印のラベル：Enter で決定、Esc で取消', false, 0);
}
function closeInline(commit) {
  if (!inl) return; const { el, kind, id, line } = inl; inl = null; st.formFocus = false; const v = el.value; el.remove(); msg('');
  const ln = ed.doc.lines[line]; const cur = ln && ln.attrs.figure; const old = cur ? (kind === 'box' ? (FZ.figureBox(cur, id) || {}).text : (cur.arrows[id] || {}).label) : null;
  if (commit && cur && old != null && v !== old) ed.figOp(line, F => { if (kind === 'box') { const b = FZ.figureBox(F, id); if (!b) return; b.text = v; const iw = Math.max(0.5, b.w - 1); const need = v.split('\n').reduce((t, s) => t + Math.max(1, Math.ceil(FZ.textWidth(s) / iw - 1e-6)), 0); if (need > b.h) { b.h = need; if (b.y + b.h > F.h) F.h = b.y + b.h; } } else { const a = F.arrows[id]; if (a) a.label = v.replace(/\n/g, ' '); } });
  if (st.mode === 'fig') figRefresh(); focusTA();
}
/* ---------- マウス（図） ---------- */
function figLocal(g) { const fi = figInfo(); if (!fi) return null; const pt = fi.parts.find(p => p.page === g.page) || fi.parts[0]; return { fi, x: g.col - fi.left, y: g.row - pt.y0 + pt.f0 }; } /* 1.0.14f 頁に分けた図：指した頁の分の図の行 */
const HANDLE_CURSOR = { nw: 'nwse-resize', se: 'nwse-resize', ne: 'nesw-resize', sw: 'nesw-resize', n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize' };
/* 図の座標 loc で何をつかむか：{ t: 'handle'|'port'|'height'|'box'|'arrow'|'empty', … } */
function figWhat(fi, loc) {
  const F = fi.F, W = fi.right - fi.left; const one = figSel();
  if (one && !st.fig.connecting) { const h = FZ.figureHandles(one).find(h => Math.abs(h.x - loc.x) <= 0.5 && Math.abs(h.y - loc.y) <= 0.36); if (h) return { t: 'handle', box: one, hid: h.id }; }
  for (const id of new Set([st.fig.hover, one && one.id].filter(x => x != null))) { const b = FZ.figureBox(F, id); if (!b) continue; const p = FZ.figurePorts(b).find(p => Math.abs(p.x - loc.x) <= 0.6 && Math.abs(p.y - loc.y) <= 0.42); if (p) return { t: 'port', box: b, port: p.id }; }
  const hit = FZ.figureHit(F, loc.x, loc.y); if (hit) return { t: 'box', box: hit };
  if (Math.abs(loc.y - F.h) <= 0.4 && Math.abs(loc.x - W / 2) <= 1.6) return { t: 'height' }; // 図の下端の真ん中のつまみ
  const ak = FZ.figureArrowHit(F, loc.x, loc.y); if (ak >= 0) return { t: 'arrow', k: ak };
  return { t: 'empty' };
}
function figHoverBox(F, loc) { for (let k = F.boxes.length - 1; k >= 0; k--) { const b = F.boxes[k]; if (loc.x >= b.x - 1 && loc.x <= b.x + b.w + 1 && loc.y >= b.y - 0.7 && loc.y <= b.y + b.h + 0.7) return b.id; } return null; }
function figPointerDown(e, g, clicks = 1) {
  const loc = figLocal(g); if (!loc) return; const { fi } = loc; const F = fi.F; const cap = () => pagesEl.setPointerCapture(e.pointerId);
  const w = figWhat(fi, loc);
  if (st.fig.connecting) { const hit = FZ.figureHit(F, loc.x, loc.y); if (hit) figConnectTo(hit.id); else { st.fig.connecting = false; figRefresh(); } focusTA(); return; }
  if (w.t === 'handle') { ed.pushUndo(''); drag = { kind: 'figsize', id: e.pointerId, box: w.box.id, hid: w.hid, sx: loc.x, sy: loc.y, o: { ...w.box }, moved: false }; cap(); return; }
  if (w.t === 'port') { st.fig.link = { from: w.box.id, port: w.port, x: loc.x, y: loc.y, to: null }; drag = { kind: 'figlink', id: e.pointerId }; cap(); figRefresh(); return; }
  if (w.t === 'height') { ed.pushUndo(''); drag = { kind: 'figh', id: e.pointerId, sy: loc.y, oh: F.h, moved: false }; cap(); return; }
  if (w.t === 'box') { const hit = w.box;
    if (e.shiftKey) { figSelect(hit.id, true); figRefresh(); focusTA(); return; }
    if (!figIds().includes(hit.id)) figSelect(hit.id, false); figRefresh();
    if (clicks >= 2) { openInline('box', hit.id); return; }
    ed.pushUndo(''); const ids = figIds(); drag = { kind: 'figmove', id: e.pointerId, clicked: hit.id, orig: ids.map(i => { const b = FZ.figureBox(F, i); return { id: i, x: b.x, y: b.y, w: b.w, h: b.h }; }), sx: loc.x, sy: loc.y, moved: false }; cap(); focusTA(); return; }
  if (w.t === 'arrow') { figSetSel([]); st.fig.selArrow = w.k; figRefresh(); if (clicks >= 2) { openInline('arrow', w.k); return; } focusTA(); return; }
  if (clicks >= 2) { figAddBox({ x: loc.x, y: loc.y }); return; }
  if (!e.shiftKey) figSetSel([]);
  st.fig.band = { x1: loc.x, y1: loc.y, x2: loc.x, y2: loc.y, base: figIds() }; drag = { kind: 'figband', id: e.pointerId }; cap(); figRefresh(); focusTA();
}
function figDragMove(g) {
  const loc = figLocal(g); if (!loc || !drag) return; const { fi } = loc; const F = fi.F; const W = fi.right - fi.left;
  if (drag.kind === 'figmove') { const o = drag.orig; let dx = half(loc.x - drag.sx), dy = Math.round(loc.y - drag.sy);
    dx = clamp(dx, -Math.min(...o.map(b => b.x)), W - Math.max(...o.map(b => b.x + b.w))); dy = clamp(dy, -Math.min(...o.map(b => b.y)), F.h - Math.max(...o.map(b => b.y + b.h)));
    let ch = false; for (const ob of o) { const b = FZ.figureBox(F, ob.id); if (!b) continue; if (b.x !== ob.x + dx || b.y !== ob.y + dy) { b.x = ob.x + dx; b.y = ob.y + dy; ch = true; } }
    if (ch) { drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figsize') { const b = FZ.figureBox(F, drag.box); if (!b) return; const r = FZ.figureResize(drag.o, drag.hid, loc.x - drag.sx, loc.y - drag.sy, W, F.h); if (r.x !== b.x || r.y !== b.y || r.w !== b.w || r.h !== b.h) { Object.assign(b, r); drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figh') { const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); const h = clamp(Math.round(drag.oh + loc.y - drag.sy), minH, 200); if (h !== F.h) { F.h = h; drag.moved = true; ed.relayout(); ed.dirty = true; render(); } return; }
  if (drag.kind === 'figlink') { const L = st.fig.link; L.x = loc.x; L.y = loc.y; const hit = FZ.figureHit(F, loc.x, loc.y); L.to = hit && hit.id !== L.from ? hit.id : null; requestOverlay(); return; }
  if (drag.kind === 'figband') { const bd = st.fig.band; bd.x2 = loc.x; bd.y2 = loc.y; const x1 = Math.min(bd.x1, bd.x2), x2 = Math.max(bd.x1, bd.x2), y1 = Math.min(bd.y1, bd.y2), y2 = Math.max(bd.y1, bd.y2);
    const inside = F.boxes.filter(b => b.x < x2 && b.x + b.w > x1 && b.y < y2 && b.y + b.h > y1).map(b => b.id); figSetSel([...bd.base, ...inside]); figRefresh(); }
}
function figDragEnd(d) {
  if (d.kind === 'figmove' || d.kind === 'figsize' || d.kind === 'figh') { if (d.moved) ed.onChange('edit'); else { ed.undoStack.pop(); if (d.kind === 'figmove' && d.orig.length > 1) figSetSel([d.clicked]); } } // 選んだ中の箱を動かさずにクリック：その箱だけを選ぶ
  else if (d.kind === 'figlink') { const L = st.fig.link; st.fig.link = null; if (L && L.to != null) figConnect(L.from, L.to); }
  else if (d.kind === 'figband') st.fig.band = null;
  figRefresh(); if (!inl) focusTA();
}
function figHover(g) {
  const loc = figLocal(g); if (!loc) return ''; const { fi } = loc; const F = fi.F; const hv = figHoverBox(F, loc); if (hv !== st.fig.hover) { st.fig.hover = hv; requestOverlay(); }
  if (Math.floor(g.row) !== fi.Y(Math.floor(loc.y)) || loc.y < -0.5 || loc.y > F.h + 0.5) return '';
  const w = figWhat(fi, loc); return w.t === 'handle' ? HANDLE_CURSOR[w.hid] : w.t === 'port' ? 'crosshair' : w.t === 'box' ? 'move' : w.t === 'height' ? 'ns-resize' : w.t === 'arrow' ? 'pointer' : 'default';
}
/* ================= ツリー（構造を直接いじる見え方） =================
 * 本文の領域を切り替えて、文書の構造を左から右（または上から下）に広がる節として描く。データは文書そのもので、操作はすべて文書の編集（取り消しも共通）。
 * キー：矢印で移動、Enter 弟・Shift+Enter 兄・Tab 子、Alt+矢印で動かす・浅く深く、F2 文字、Delete 消す、Space 畳む、1〜9 深さ・0 本文まで、Esc 紙面へ。
 * マウス：クリックで選ぶ（Shift で足す）、ダブルクリックで文字、ドラッグで動かす（節の上・下・右に落とす）、空いた所を囲んで選ぶ、寄せると出る ＋ で足す */
const treeEl = $('tree'), tpane = $('treePane');
st.view = 'paper'; // 見え方：paper（紙面）・tree（ツリー）・split（並べる）。st.mode が 'tree' なら、操作の先はツリー
st.tree = { show: new Set(), scale: (() => { try { const v = +localStorage.getItem('fz.treeScale'); return v >= 0.5 && v <= 3 ? v : 1; } catch (e) { return 1; } })(), sel: null, multi: new Set(), depth: 9, dir: 'i', folds: new WeakSet(), hover: null, drop: null, band: null, view: null, edit: null };
const TREE_FS = 13, TREE_LH = 18, TREE_PX = 8, TREE_IND = 30;
function treeBuild(forceBody) { const title = ed.doc.title || (st.file && st.file.name ? st.file.name.replace(/\.[^.]+$/, '') : '') || '文書'; const nums = ed.lay.figNums; const tr = FZ.tree.build(ed.doc, { body: forceBody || st.tree.depth <= 0, sentences: st.tree.depth === -1, figs: true, title, figLabel: fg => { const nn = nums && nums.get(fg.id); return (nn ? nn.label : fg.kind) + (fg.title ? '　' + fg.title : '') + (fg.chart ? '' : fg.file ? '' : '（画像なし）'); } }); const r = tr.root; tr.top = (r.children.length === 1 && r.children[0].kind === 'title') ? r.children[0] : r; if (!forceBody && st.tree.depth > 0 && !tr.nodes.some(n => n.kind !== 'body' && n.kind !== 'block' && n !== tr.top)) { const t2 = treeBuild(true); t2.flat = true; return t2; } return tr; } /* 見出しも箇条書きも無い平文：段落を平らに並べて見せる（構造はここから作る） */
const treeKey = n => n.key || n.fig || n.obj || 'root';
const treeDesc = n => { let k = 0; const walk = x => { for (const c of x.children || []) { k++; walk(c); } }; walk(n); return k; }; /* 1.0.15e 子孫の数 */
/* 1.0.15e（C-4）畳んだ節と深さ（しおり）を文書ごとに覚える（保存先のある文書だけ。行の字の頭で照らす） */
const treeMemKey = () => st.file && (st.file.path || st.file.name) ? 'fz.tmem.' + (st.file.path || st.file.name) : null;
function treeMemSave() { const k = treeMemKey(); if (!k) return; try { const L = ed.doc.lines, f = []; for (let i = 0; i < L.length && f.length < 500; i++) if (st.tree.folds.has(L[i])) f.push({ i, t: L[i].segs.map(s => s.text).join('').slice(0, 16) }); lsW(k, { depth: st.tree.depth, f }); } catch { } }
function treeMemLoad() { if (st.tree.memFor === ed.docId) return; st.tree.memFor = ed.docId; const k = treeMemKey(); if (!k) return; const m = lsJ(k, null); if (!m) return; if (typeof m.depth === 'number' && m.depth >= -1 && m.depth <= 9) st.tree.depth = m.depth; const L = ed.doc.lines; const tx = l => l.segs.map(s => s.text).join('').slice(0, 16);
  for (const x of m.f || []) { let ln = L[x.i]; if (!ln || tx(ln) !== x.t) ln = x.t ? L.find(l => tx(l) === x.t) : null; if (ln) st.tree.folds.add(ln); } }
/* 図表の節（図版・表・流れ図）：名前だけを出し、「表示」で中身を紙面と同じ描画で見せる（窓の幅と紙面での大きさの小さい方） */
const treeShowable = n => n && (n.kind === 'fig' || (n.kind === 'block' && (n.block === 'table' || n.block === 'figure')));
const treeShowKey = n => n.kind === 'fig' ? 'f:' + n.fig.id : 'b:' + n.line;
/* 紙面の上の範囲（pt）：{ page, x, y, w, h } */
function treeFigRect(n) { const L = ed.lay, geo = L.geo, cw = geo.cw, ch = geo.ch; const X = c => geo.left + c * cw, Y = r => geo.top + (geo.bodyTop + r) * ch;
  if (n.kind === 'fig') { for (let p = 0; p < L.pages.length; p++) { const pg = L.pages[p]; for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) if (im.id === n.fig.id) return { page: p, x: X(im.col), y: Y(im.y), w: im.w * cw, h: im.h * ch }; } return null; } /* 画像はちょうどで切る（隣の行の罫や表がはみ出して見えていた） */
  const lm = L.lineMap[n.line]; if (!lm || !lm.rows[0]) return null; const p = lm.rows[0].page; let y1 = Infinity, y2 = -Infinity; for (let i = n.line; i <= n.end; i++) { const m = L.lineMap[i]; if (!m) continue; for (const r of m.rows) if (r.page === p) { y1 = Math.min(y1, r.y); y2 = Math.max(y2, r.y + r.h); } } if (!(y2 > y1)) return null;
  let l, r; if (n.block === 'table') { const I = FZ.tbl.info(ed, n.line); if (!I) return null; l = I.L; r = I.R; } else { const row = lm.segs[0] && lm.segs[0].rows[0]; if (!row) return null; l = row.left; r = row.right; }
  return { page: p, x: X(l) - 0.75, y: Y(y1) - 0.75, w: (r - l) * cw + 1.5, h: (y2 - y1) * ch + 1.5 }; } /* 罫の太さの半分だけ外へ（2pt 取ると上下の図がはみ出した） */
/* 紙面のページの描画をそのまま切り抜いて埋める（文様の id は付け替え：隠れた紙面の定義を指さない） */
function treeFigSvg(rc, x, y, w, h, k, cache) { let svg = cache.get(rc.page); if (svg == null) { svg = FZ.renderPage(ed.lay, rc.page, { grid: false, font: ed.doc.format.font, mono: true, imageHref }); cache.set(rc.page, svg); }
  const fsz = (svg.match(/font-size="([\d.]+)"/) || [])[1] || '10'; const body = svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '').replace(new RegExp('(s_[a-z0-9]+_|gdot)' + rc.page + '(?=["\\)])', 'g'), '$1t' + k);
  return `<svg class="pg tfig" x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${rc.x} ${rc.y} ${rc.w} ${rc.h}" preserveAspectRatio="xMinYMin meet" font-size="${fsz}">${body}</svg>`; }
/* 1.0.14a ツリーでも、プ譜の項目は役の名前を印の代わりに出す（考える時に役が見える） */
let pufuRoles = { gen: -1, id: -1, map: new Map() };
function pufuRoleOfLine(line) { if (pufuRoles.gen !== ed.gen || pufuRoles.id !== ed.docId || pufuRoles.doc !== ed.doc) { const m = new Map(); for (const B of FZ.pufuBlocks(ed.doc)) for (const [q, it] of B.map) if (it.kind === 'node' || it.kind === 'frame' || it.kind === 'res') m.set(q, FZ.pufuTagOf(B, it)); pufuRoles = { gen: ed.gen, id: ed.docId, doc: ed.doc, map: m }; } return pufuRoles.map.get(line) || ''; }
function treeMarker(n) { if (n.root || n.kind === 'title' || n.kind === 'body' || n.kind === 'block') return ''; { const pr = FZ.pufuBlocks ? pufuRoleOfLine(n.line) : ''; if (pr) return '【' + pr + '】'; } const lm = ed.lay.lineMap[n.line]; const row = lm && lm.segs[0] && lm.segs[0].rows[0]; if (!row) return ''; return row.glyphs.filter(g => g.marker).map(g => g.text).join('').trim(); }
function treeWrap(text, cols, maxLines) { const out = []; let cur = '', w = 0; for (const g of FZ.graphemes(text)) { const gw = FZ.textWidth(g.text); if (w + gw > cols + 1e-6) { out.push(cur); cur = ''; w = 0; if (out.length >= maxLines) break; } cur += g.text; w += gw; } if (out.length < maxLines) out.push(cur); else if (out.join('').length + cur.length < text.length || cur) { const last = out[maxLines - 1]; out[maxLines - 1] = last.slice(0, Math.max(0, last.length - 1)) + '…'; } return out.slice(0, maxLines).map(s => s || ''); }
/* 折り返しのぶら下げ：2 行目からは hang 字下げ（番号・記号の後ろの字に面を合わせる） */
function treeWrapH(text, cols, maxLines, hang) { if (!hang) return treeWrap(text, cols, maxLines); const out = []; let cur = '', w = 0, lim = cols; for (const g of FZ.graphemes(text)) { const gw = FZ.textWidth(g.text); if (w + gw > lim + 1e-6) { out.push(cur); cur = ''; w = 0; lim = Math.max(2, cols - hang); if (out.length >= maxLines) break; } cur += g.text; w += gw; } if (out.length < maxLines) out.push(cur); else { const last = out[maxLines - 1]; out[maxLines - 1] = last.slice(0, Math.max(0, last.length - 1)) + '…'; } return out.slice(0, maxLines).map(x => x || ''); }
/* 番号・記号と字の間：全角 1 字の記号（・‐◦ など）は詰める（2 行目の 1 字下げと面が合う）、ほかは半角の空き */
const treeMkSep = mk => mk && !(FZ.textWidth(mk) === 1 && /[^\x00-\x7F]/.test(mk)) ? ' ' : '';
function treeCount(n) { let c = 0; for (const k of n.children) c += 1 + treeCount(k); return c; }
/* 描く子：畳んだ節は描かない。深さ d（1〜9）より深い節は描かない（0＝本文まで全部） */
function treeVisKids(n, top) { if (st.tree.folds.has(treeKey(n))) return []; const d = st.tree.depth; return n.children.filter(c => d <= 0 || c.depth - top.depth <= d); } // 0＝本文まで、−1＝文まで（どちらも全部）
function renderTree() {
  treeEl.style.display = 'block';
  const tr = treeBuild(); const top = tr.top; const vis = n => treeVisKids(n, top); const isBox = n => !!n.para && vis(n).some(c => c.kind === 'sent'); const layVis = n => isBox(n) ? vis(n).filter(c => c.kind !== 'sent') : vis(n); /* 段落は文を収める枠：文は枠の中に縦に積む（木の行にしない） */
  const info = new Map(); // 節 → { lines, w, h, mk }
  const M = 20, IND = TREE_IND, dirI = st.tree.dir === 'i'; const PY = st.tree.exportW ? 5 : 3; // 箱の上下の余白：画面は詰めて行を多く見せる（書き出しは従来の 5）
  const shown = []; const walk = n => { shown.push(n); for (const c of vis(n)) walk(c); }; walk(top);
  const textOf = n => { const mk = treeMarker(n); const sp = treeMkSep(mk); const gh = !n.text && n.line != null ? pufuGhostMap().get(n.line) : ''; return { mk, hang: mk ? FZ.textWidth(mk + sp) : 0, text: (mk ? mk + sp : '') + (n.text || (gh ? '（' + gh + '）' : n.root ? '' : '（空）')) }; };
  /* 字下げ：箱は画面の右端まで伸ばす（右の余白は子を足す ＋ の分だけ）。収まらない文は箱の中で折り返す */
  const layK = targetWidthPx() / ed.lay.geo.W; const figCache = new Map(); let figK = 0; // 紙面での 1pt の画素
  const SC = st.tree.scale; const availW = st.tree.exportW ? st.tree.exportW : Math.max(240, (tpane.clientWidth - 16 - (tpane.scrollHeight > tpane.clientHeight ? 0 : 17)) / SC - M - 30); // 縦のスクロールバーが後から出ても横にはみ出さない。倍率の分だけ狭く組んで拡大する
  const sizeOf = (n, d) => { let x = info.get(n); if (x) return x; const body = n.kind === 'body' || n.kind === 'block'; const { mk, text, hang } = textOf(n);
    if (isBox(n)) { const PB = PY + 1; const w = dirI ? Math.max(8 * TREE_FS + TREE_PX * 2, availW - (d | 0) * IND) : 22 * TREE_FS + TREE_PX * 2 + PB * 2; const iw = w - PB * 2; const cols = Math.max(4, Math.floor((iw - TREE_PX * 2) / TREE_FS)); let y = PB; const inner = [];
      for (const c of vis(n).filter(c2 => c2.kind === 'sent')) { const lines = treeWrap(c.text || '（空）', cols, 4); const h = lines.length * TREE_LH + PY * 2; inner.push({ c, rx: PB, ry: y, w: iw, h, lines }); y += h + 2; }
      x = { lines: [], mk: '', w, h: y - 2 + PB, inner, box: true }; info.set(n, x); return x; }
    const showable = treeShowable(n), open = showable && st.tree.show.has(treeShowKey(n)); const rc = open ? treeFigRect(n) : null;
    if (dirI) { const w = Math.max(6 * TREE_FS + TREE_PX * 2, availW - (d | 0) * IND); const fold = n.children.length && !vis(n).length; const cols = Math.max(4, Math.floor((w - TREE_PX * 2) / TREE_FS) - (fold ? 3 : 0) - (showable ? 4 : 0)); // 畳んだ数（＋n）・「表示」は箱の右端の中に。種類は箱に書かない（考える邪魔。帯の「種類」で見る・変える）
      const lines = treeWrapH(text, cols, body ? 2 : 3, hang); const fig = rc ? (() => { const fw = Math.max(40, Math.min(w - TREE_PX * 2, rc.w * layK / SC)); return { rc, w: fw, h: rc.h * fw / rc.w }; })() : null; /* 図表：紙面で見える大きさ（ツリーの倍率で割る）と箱の幅の小さい方 */
      x = { lines, mk, hang, w, h: lines.length * TREE_LH + PY * 2 + (fig ? fig.h + PY + 3 : 0), fig, showable, open }; info.set(n, x); return x; }
    const cols = body ? 20 : showable ? 16 : 13; const lines = treeWrap(text, cols, 2); let w0 = cols * TREE_FS + TREE_PX * 2; const fig = rc ? (() => { const fw = Math.max(40, Math.min(480, rc.w * layK)); return { rc, w: fw, h: rc.h * fw / rc.w }; })() : null; if (fig) w0 = Math.max(w0, fig.w + TREE_PX * 2);
    x = { lines, mk, w: w0, h: lines.length * TREE_LH + PY * 2 + (fig ? fig.h + PY + 3 : 0), fig, showable, open }; info.set(n, x); return x; };
  const L = FZ.tree.layout(top, { dir: st.tree.dir, visible: layVis, size: sizeOf, gapDepth: 40, gapSib: dirI ? (st.tree.exportW ? 6 : 0) : 8, indent: IND, tight: true }); /* 1.0.11b：画面の字下げは枠を隙間なく積む */ /* 同じ親の続く兄弟は辺で接する（線を減らす） */
  for (const n of shown) { const s0 = info.get(n); if (!s0 || !s0.box) continue; const p = L.pos.get(n); for (const it of s0.inner) { L.pos.set(it.c, { x: p.x + it.rx, y: p.y + it.ry, w: it.w, h: it.h, depth: p.depth + 1 }); info.set(it.c, { lines: it.lines, mk: '', w: it.w, h: it.h, inBox: true }); } } /* 枠の中の文の位置 */
  // 選択を今の木に合わせる（消えた節なら親へ）
  const byKey = new Map(shown.map(n => [treeKey(n), n])); if (!st.tree.sel || !byKey.has(st.tree.sel)) { let p = st.tree.sel && tr.byObj.get(st.tree.sel); if (!p && st.tree.selLine != null) { const same = tr.nodes.filter(n => n.text === st.tree.selText).sort((a, b) => Math.abs(a.line - st.tree.selLine) - Math.abs(b.line - st.tree.selLine)); p = same[0] || FZ.tree.nodeAt(tr, Math.min(st.tree.selLine, ed.doc.lines.length - 1)); } while (p && !byKey.has(treeKey(p))) p = p.parent; st.tree.sel = treeKey(p || top); } // 取り消しで行が作り直されても、同じ行の節を選んだまま
  { const n = byKey.get(st.tree.sel); st.tree.selLine = n.line; st.tree.selText = n.text; }
  if (st.tree.pendSel) { const [a0, b0] = st.tree.pendSel; st.tree.pendSel = null; const ns = shown.filter(n => !n.root && n !== top && n.line != null && n.line >= a0 && n.line <= b0 && !(n.parent && n.parent.line != null && n.parent.line >= a0 && n.parent !== top && !n.parent.root)); if (ns.length > 1) { st.tree.multi = new Set(ns.map(treeKey)); st.tree.sel = treeKey(ns[0]); } }
  for (const k of [...st.tree.multi]) if (!byKey.has(k)) st.tree.multi.delete(k);
  const P = n => L.pos.get(n); const o = []; const edges = []; /* 線の点（書き出し用。画面の座標から余白 M を引いたもの） */
  /* 線：子を出していない兄弟が続く所（辺で接した塊）は 1 本の枝でつなぐ（兄弟ごとに枝を引かない） */
  const touch = (a, b) => { const p = P(a), q = P(b); return st.tree.dir === 'v' ? Math.abs(q.x - (p.x + p.w)) < 0.5 : Math.abs(q.y - (p.y + p.h)) < 0.5; }; /* 辺で接している兄弟 */
  const runsOf = kids => { const runs = []; let cur = null; for (const c of kids) { if (cur && touch(cur.items[cur.items.length - 1], c)) cur.items.push(c); else { cur = { items: [c] }; runs.push(cur); } } return runs; };
  for (const n of shown) { const kids = layVis(n); if (!kids.length) continue; const p = P(n); const runs = runsOf(kids);
    if (dirI) { const lx = M + p.x + 14; let d = '', last = 0; for (const r of runs) { const q = P(r.items[0]); last = M + q.y + q.h / 2; d += `M${lx} ${last}H${M + q.x}`; edges.push({ pts: [[lx - M, last - M], [q.x, last - M]] }); } o.push(`<path d="M${lx} ${M + p.y + p.h}V${last}${d}"/>`); edges.push({ pts: [[lx - M, p.y + p.h], [lx - M, last - M]] }); continue; } // 親の下から縦の線、塊へ横の枝
    for (const r of runs) { const a = P(r.items[0]), z = P(r.items[r.items.length - 1]);
      if (st.tree.dir === 'h') { const x1 = M + p.x + p.w, py = M + p.y + p.h / 2, x2 = M + a.x, top = M + a.y, bot = M + z.y + z.h; const y2 = py >= top + 2 && py <= bot - 2 ? py : r.items.length > 1 ? (top + bot) / 2 : M + a.y + a.h / 2; if (Math.abs(y2 - py) < 0.5) { o.push(`<path d="M${x1} ${py}H${x2}"/>`); edges.push({ pts: [[x1 - M, py - M], [x2 - M, py - M]] }); } else { const mx = x1 + 18; o.push(`<path d="M${x1} ${py}H${mx}V${y2}H${x2}"/>`); edges.push({ pts: [[x1 - M, py - M], [mx - M, py - M], [mx - M, y2 - M], [x2 - M, y2 - M]] }); } }
      else { const y1 = M + p.y + p.h, px = M + p.x + p.w / 2, y2 = M + a.y, lft = M + a.x, rgt = M + z.x + z.w; const x2 = px >= lft + 2 && px <= rgt - 2 ? px : r.items.length > 1 ? (lft + rgt) / 2 : M + a.x + a.w / 2; if (Math.abs(x2 - px) < 0.5) { o.push(`<path d="M${px} ${y1}V${y2}"/>`); edges.push({ pts: [[px - M, y1 - M], [px - M, y2 - M]] }); } else { const my = y1 + 18; o.push(`<path d="M${px} ${y1}V${my}H${x2}V${y2}"/>`); edges.push({ pts: [[px - M, y1 - M], [px - M, my - M], [x2 - M, my - M], [x2 - M, y2 - M]] }); } } } }
  /* 頁の境目（字下げ）：その節から新しい頁になる所に線と頁番号。改頁を決めた所は実線と「改頁」 */
  let lastPg = null; const pageOfN = n => { if (!n.obj || n.root) return null; const lm = ed.lay.lineMap[n.line]; return lm && lm.rows[0] ? lm.rows[0].page : null; };
  const WW = dirI ? M + L.W + 28 : 0; const pageMark = (n, x, y) => { if (!dirI || n.kind === 'sent' || n.root) return ''; const pg = pageOfN(n); if (pg == null) return ''; const prev = lastPg; lastPg = pg; if (prev != null && pg <= prev) return ''; const forced = !!(n.obj && n.obj.attrs.breakBefore);
    /* 頁の境目：細い破線と、左端に四角で囲んだ P1・P2…（最初の頁から） */ const yy = y - 3.5; const lab = 'P' + (pg + 1); const bw = lab.length * 5.6 + 4; return `<g class="tpg${forced ? ' forced' : ''}"><path d="M${bw + 3} ${yy}H${st.tree.exportW ? WW - 8 : bw + 22}"/><rect x="1.5" y="${yy - 5.5}" width="${bw}" height="11" rx="1"/><text x="${1.5 + bw / 2}" y="${yy + 3.3}" text-anchor="middle">${lab}</text><title>${pg + 1} 頁${forced ? '（ここから改頁）' : ''}</title></g>`; };
  const hitKeys = st.tree.find && st.tree.find.trim() ? new Set(treeFindHits().map(treeKey)) : null; /* ツリーで探す：当たった節 */
  const warns = st.form === 'scheck' ? (() => { const m = new Map(); for (const it of structIssues()) { const a = m.get(it.obj) || []; a.push(CHECK_NAMES[it.kind] + '：' + it.msg); m.set(it.obj, a); } return m; })() : null; /* 構造の点検：印を付ける節 */
  const aiMarks = st.form === 'aiback' && st.aiBack && st.aiBack.hunks.length ? (() => { const m = new Map(), S = st.aiBack, vis2 = new Set(shown); /* AI からの戻し：違う所の節に印（畳んだ・深さで隠れた行は見えている親に） */
    const nodeAt = i => { for (let k = i; k >= 0; k--) { let n = tr.byObj.get(ed.doc.lines[k]); if (!n) continue; while (n && !vis2.has(n)) n = n.parent; return n && n.obj ? n.obj : null; } return null; };
    S.hunks.forEach((h, k) => { const put = (o2, kind) => { if (!o2) return; const e = m.get(o2); if (!e) m.set(o2, { kind, cur: k === S.i }); else { if (e.kind !== kind) e.kind = 'chg'; if (k === S.i) e.cur = true; } }; if (h.rem.length) new Set(h.rem.map(nodeAt)).forEach(o2 => put(o2, h.kind)); else put(nodeAt(Math.max(0, h.at - 1)), 'add'); }); return m; })() : null;
  const nodesSvg = shown.map((n, i) => { const p = P(n), s = info.get(n); const key = treeKey(n); const on = key === st.tree.sel || st.tree.multi.has(key); const body = n.kind === 'body' || n.kind === 'block' || n.kind === 'sent'; const head = n.root || n.kind === 'title';
    const x = M + p.x, y = M + p.y; const hidden = n.children.length && !vis(n).length ? treeCount(n) : 0;
    const flat = dirI && !st.tree.exportW; /* 1.0.10u：画面の字下げは箱をやめて字と枝だけ（枠は選んだ節だけ）。見出しは太字。「表示」と＋n は字のすぐ後ろ */
    const tw = flat ? Math.max(0, ...s.lines.map((ln, k) => FZ.textWidth(ln) + (k ? s.hang || 0 : 0))) * TREE_FS : 0; const sx0 = x + TREE_PX + tw + 8; const bold = head || (flat && (n.kind === 'num' || n.kind === 'sym'));
    const fw = flat ? (s.box ? Math.min(p.w, Math.max(...s.inner.map(it => Math.max(0, ...it.lines.map(ln => FZ.textWidth(ln))) * TREE_FS + TREE_PX * 2 + (it.rx * 2)), 60)) : n.kind === 'sent' ? p.w : Math.min(p.w, Math.max(tw + TREE_PX * 2 + (s.showable ? 48 : 0) + (hidden ? 34 : 0), s.fig ? s.fig.w + TREE_PX * 2 : 0))) : p.w; if (flat && s.box) for (const it of s.inner) { it.fw = fw - it.rx * 2; const pc = P(it.c); if (pc) pc.fw = it.fw; } /* 段落の枠は中の文のいちばん長いものに合わせる */
    const sepL = flat && s.box ? s.inner.slice(1).map(it => `<path class="tsep" d="M${x + it.rx} ${y + it.ry - 1}H${x + fw - it.rx}"/>`).join('') : ''; /* 文と文の境目は破線 */
    const t = sepL + s.lines.map((ln, k) => `<text x="${x + TREE_PX + (k ? (s.hang || 0) * TREE_FS : 0)}" y="${y + PY + TREE_LH * k + 13}"${bold ? ' font-weight="700"' : ''}>${esc(ln)}</text>`).join('')
      + (s.showable ? `<g class="tshow" data-show="${i}"><rect x="${flat ? sx0 : x + p.w - 44 - (hidden && dirI ? 30 : 0)}" y="${y + 4}" width="38" height="18" rx="2"/><text x="${flat ? sx0 + 19 : x + p.w - 25 - (hidden && dirI ? 30 : 0)}" y="${y + 17}" text-anchor="middle">${s.open ? '閉じる' : '表示'}</text></g>` : '')
      + (s.fig ? `<rect class="tfigbg" x="${x + TREE_PX}" y="${y + s.lines.length * TREE_LH + PY + 3}" width="${s.fig.w}" height="${s.fig.h}"/>` + treeFigSvg(s.fig.rc, x + TREE_PX, y + s.lines.length * TREE_LH + PY + 3, s.fig.w, s.fig.h, figK++, figCache) : '')
      + (s.open && !s.fig ? `<text class="tk" x="${x + TREE_PX}" y="${y + s.lines.length * TREE_LH + PY + 9}">（紙面にまだ組まれていません）</text>` : '');
    const nn = (() => { if (n.root || n.line == null) return 0; const own = n.obj && n.obj.attrs && n.obj.attrs.notes ? n.obj.attrs.notes.length : 0; if (vis(n).length || n.end == null) return own; let c = 0; for (let q = n.line; q <= Math.min(n.end, ed.doc.lines.length - 1); q++) { const ns = ed.doc.lines[q].attrs.notes; if (ns) c += ns.length; } return c; })(); /* 見えている節と、隠れている子孫の付箋の数 */ const noteB = nn ? `<g class="tnote"><title>付箋 ${nn}</title><rect x="${flat ? sx0 + (s.showable ? 44 : 0) + (hidden ? 34 : 0) : x + p.w - 24}" y="${y + 4}" width="18" height="14" rx="1"/><text x="${(flat ? sx0 + (s.showable ? 44 : 0) + (hidden ? 34 : 0) : x + p.w - 24) + 9}" y="${y + 15}" text-anchor="middle">付</text></g>` : ''; /* 付箋の付いた節 */
    const badge = hidden ? (dirI ? (flat ? `<text class="fold" data-fold="${i}" x="${sx0 + (s.showable ? 44 : 0)}" y="${y + Math.min(p.h / 2, TREE_LH / 2 + PY) + 4}">＋${hidden}</text>` : `<text class="fold" data-fold="${i}" x="${x + p.w - 6}" y="${y + p.h / 2 + 4}" text-anchor="end">＋${hidden}</text>`) : st.tree.dir !== 'v' ? `<text class="fold" data-fold="${i}" x="${x + p.w + 5}" y="${y + p.h / 2 + 4}">＋${hidden}</text>` : `<text class="fold" data-fold="${i}" x="${x + p.w / 2}" y="${y + p.h + 14}" text-anchor="middle">＋${hidden}</text>`) : '';
    const wn = warns && n.kind !== 'sent' && n.obj ? warns.get(n.obj) : null; let warnB = wn ? `<g class="twarn"><title>${esc(wn.join('\n'))}</title><circle cx="${x + p.w - 9}" cy="${y + 9}" r="7"/><text x="${x + p.w - 9}" y="${y + 13}" text-anchor="middle">!</text></g>` : '';
    const am = aiMarks && n.kind !== 'sent' && n.obj ? aiMarks.get(n.obj) : null; if (am) warnB += `<g class="tdiff${am.cur ? ' cur' : ''}"><title>AI からの戻し：${AI_KIND[am.kind]}${am.kind === 'add' ? '（この後ろに）' : ''}</title><rect x="${x + p.w - 17}" y="${y + 2}" width="15" height="14" rx="2"/><text x="${x + p.w - 9.5}" y="${y + 13}" text-anchor="middle">${am.kind === 'add' ? '＋' : am.kind === 'del' ? '－' : '直'}</text></g>`;
    return `${pageMark(n, x, y)}<g class="tn${on ? ' on' : ''}${wn ? ' warn' : ''}${am ? ' diff' : ''}${hitKeys && hitKeys.has(key) ? ' hit' : ''}${body ? ' body' : ''}${head ? ' head' : ''}${n.kind === 'fig' ? ' figN' : ''}${s.box ? ' para' : ''}${n.kind === 'sent' ? ' sent' : ''}" data-i="${i}"><rect x="${x}" y="${y}" width="${p.w}" height="${p.h}" rx="1.5"/>${flat ? `<rect class="tf" x="${x}" y="${y}" width="${n.kind === 'sent' && p.fw ? p.fw : fw}" height="${p.h}"/>` : ''}${t}${noteB}</g>${badge}${warnB}`; }).join('');
  const W = dirI ? M + L.W + 28 : L.W + M * 2 + 60, H = L.H + M * 2 + 40; // 字下げは窓の幅ちょうど（右端に子を足す ＋ の分）
  treeEl.innerHTML = `<svg${dirI && !st.tree.exportW ? ' class="ti"' : ''} width="${Math.ceil(W * SC)}" height="${Math.ceil(H * SC)}" viewBox="0 0 ${W} ${H}"><g class="tl">${o.join('')}</g>${nodesSvg}<g class="tov"></g></svg>`;
  st.tree.view = { tr, top, shown, pos: L.pos, M, info, edges, LW: L.W, LH: L.H };
  renderTreeOverlay(); if (st.view === 'split' && st.mode === 'tree') treeFollowPaper();
}
/* 並べるとき：ツリーで選んだ節 → 紙面のカーソルとその場所（紙面だけ動かす） */
let followLine = -1, followTimer = 0;
function treeFollowPaper(force) { if (st.view !== 'split') return; const n = treeNodeSel(); if (!n || !n.obj) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0 || (i === followLine && !force)) return; followLine = i;
  ed.caret = { line: i, seg: 0, off: n.kind === 'sent' ? n.sStart : 0, vcol: null, vrow: 0 }; ed.anchor = null; scrollToCaret(true); requestOverlay(); }
/* 並べるとき：紙面のカーソル → ツリーの節（ツリーだけ動かす） */
function treeFollowCaret(now) { if (st.view !== 'split' || st.mode === 'tree') return; if (followTimer) cancelAnimationFrame(followTimer); const go = () => { followTimer = 0; const v = st.tree.view; if (!v) return; let n = FZ.tree.nodeAt(v.tr, ed.caret.line); const shown = new Set(v.shown); while (n && !shown.has(n)) n = n.parent; if (!n) n = v.top; const k = treeKey(n); followLine = ed.caret.line; if (k === st.tree.sel) { renderTreeOverlay(); return; } st.tree.sel = k; renderTree(); treeScrollToSel(); }; if (now) go(); else followTimer = requestAnimationFrame(go); }
function treeNodeSel() { const v = st.tree.view; if (!v) return null; return v.shown.find(n => treeKey(n) === st.tree.sel) || v.top; }
function treeSelected() { const v = st.tree.view; if (!v) return []; const keys = new Set([...st.tree.multi, st.tree.sel]); return v.shown.filter(n => keys.has(treeKey(n))); }
function renderTreeOverlay() {
  const g = treeEl.querySelector('.tov'); const v = st.tree.view; if (!g || !v) return; const M = v.M; const o = [];
  const hv = st.tree.hover != null ? v.shown[st.tree.hover] : null;
  if (hv && !st.tree.drop && !st.tree.band && !st.tree.edit) { const p = v.pos.get(hv); const x = M + p.x, y = M + p.y; const btn = (cx, cy, act, tip) => `<g class="tadd" data-add="${act}"><title>${tip}</title><circle cx="${cx}" cy="${cy}" r="8"/><path d="M${cx - 4} ${cy}h8M${cx} ${cy - 4}v8"/></g>`;
    if (hv.kind !== 'body' && hv.kind !== 'block' && FZ.tree.childType(hv)) o.push(st.tree.dir !== 'v' ? btn(x + p.w + 12, y + p.h / 2, 'child', '子を足す（Tab）') : btn(x + p.w / 2, y + p.h + 12, 'child', '子を足す（Tab）'));
    if (!hv.root && hv !== v.top) o.push(st.tree.dir !== 'v' ? btn(x + p.w / 2, y + p.h + (st.tree.dir === 'i' ? 3 : 10), 'after', '弟を足す（Enter）') : btn(x + p.w + 10, y + p.h / 2, 'after', '弟を足す（Enter）')); }
  const d = st.tree.drop; if (d) { const p = v.pos.get(d.node); const x = M + p.x, y = M + p.y; if (d.rel === 'child') o.push(`<rect class="tdrop" x="${x - 3}" y="${y - 3}" width="${p.w + 6}" height="${p.h + 6}" rx="4"/>`); else if (st.tree.dir !== 'v') { const g2 = st.tree.dir === 'i' ? 2 : 5; const yy = d.rel === 'before' ? y - g2 : y + p.h + g2; o.push(`<path class="tdropl" d="M${x - 6} ${yy}H${x + p.w + 6}"/>`); } else { const xx = d.rel === 'before' ? x - 5 : x + p.w + 5; o.push(`<path class="tdropl" d="M${xx} ${y - 6}V${y + p.h + 6}"/>`); } }
  if (st.view === 'split' && st.mode !== 'tree') { const sl = ed.sel(); if (sl && sl.a.line !== sl.b.line) for (const n of v.shown) { if (n.root || n === v.top || n.line == null || n.line < sl.a.line || n.line > sl.b.line) continue; const p = v.pos.get(n); if (p) o.push(`<rect class="tpsel" x="${M + p.x - 2}" y="${M + p.y - 2}" width="${p.w + 4}" height="${p.h + 4}" rx="4"/>`); } } /* 並べる（G2）：紙面で選んだ範囲の節に印 */
  const b = st.tree.band; if (b) o.push(`<rect class="tband" x="${Math.min(b.x1, b.x2)}" y="${Math.min(b.y1, b.y2)}" width="${Math.abs(b.x2 - b.x1)}" height="${Math.abs(b.y2 - b.y1)}"/>`);
  g.innerHTML = o.join('');
}
function treeScrollToSel() { const v = st.tree.view; const n = treeNodeSel(); if (!v || !n) return; const p = v.pos.get(n); const svg = treeEl.querySelector('svg'); if (!p || !svg) return; const mr = tpane.getBoundingClientRect(), sr = svg.getBoundingClientRect(); const SC = st.tree.scale; const x = sr.left - mr.left + tpane.scrollLeft + (v.M + p.x) * SC, y = sr.top - mr.top + tpane.scrollTop + (v.M + p.y) * SC, pw = p.w * SC, ph = p.h * SC; const [mw, mh] = [tpane.clientWidth, tpane.clientHeight];
  if (y < tpane.scrollTop + 10) tpane.scrollTop = y - 40; else if (y + ph > tpane.scrollTop + mh - 10) tpane.scrollTop = y + ph - mh + 40; if (x < tpane.scrollLeft + 10) tpane.scrollLeft = x - 40; else if (x + pw > tpane.scrollLeft + mw - 10) tpane.scrollLeft = x + Math.min(pw, mw - 80) - mw + 40; }
function enterTree() {
  if (st.mode === 'tree') return; if (st.mode !== 'text') exitMode(); if (st.form) closeForm(); if (st.armed) disarm(); st.cells = null; const fromPaper = !st.view || st.view === 'paper'; if (fromPaper) st.view = 'tree';
  const psel = ed.sel(); st.tree.pendSel = psel && psel.a.line !== psel.b.line ? [psel.a.line, psel.b.line] : null; /* G2：紙面で範囲を選んでいたら、その節をツリーで選ぶ */
  st.mode = 'tree'; st.group = null; st.armed = false; st.tree.multi.clear(); st.tree.hover = null; st.tree.drop = null; st.tree.band = null; treeMemLoad();
  const tr = treeBuild(); let n = FZ.tree.nodeAt(tr, ed.caret.line); const top = tr.top; while (n && n !== top && st.tree.depth > 0 && n.depth - top.depth > st.tree.depth) n = n.parent; st.tree.sel = treeKey(n || top);
  const bk = st.tree.back; st.tree.back = null; if (bk) { const hit = bk.fig ? tr.figs.find(f => f.fig.id === bk.fig) : tr.byObj.get(bk.obj); if (hit) st.tree.sel = treeKey(hit); } // 行って帰る：図表の節に戻る
  if (fromPaper) { tpane.scrollTop = 0; tpane.scrollLeft = 0; } render(); drawFkeys(); drawSub(); treeScrollToSel(); focusTA();
}
function exitTree(toNode = true) {
  if (st.mode !== 'tree') return; closeTreeEdit(true); treeMemSave(); const n = treeNodeSel(); st.mode = 'text'; st.group = null; st.armed = false; if (st.view === 'tree') { st.view = 'paper'; treeEl.style.display = 'none'; treeEl.innerHTML = ''; } pagesEl.style.display = ''; geomDirty = true; pagesEl.style.cursor = ''; // 並べるときはツリーを残して紙面に移るだけ
  if (toNode && n && !n.root && n.obj) { const i = ed.doc.lines.indexOf(n.obj); if (i >= 0) ed.setCaret({ line: i, seg: 0, off: 0 }); }
  render(); drawFkeys(); drawSub(); scrollToCaret(); syncTA(); focusTA();
}
/* 行って帰る：図表の中身を紙面のその場で直す（Ctrl+Shift+O で同じ節に戻る） */
function treeOpenObject(n) { st.tree.back = n.kind === 'fig' ? { fig: n.fig.id } : { obj: n.obj }; exitTree(false);
  if (n.kind === 'fig') { const x = ed.figById(n.fig.id); if (x) ed.setCaret({ line: x.line, seg: 0, off: 0 }); st.figSel = n.fig.id; openForm(n.fig.chart ? 'chart' : 'fig'); msg('図表の設定（Ctrl+Shift+O でツリーに戻る）', false, 5000); return; }
  const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return;
  if (n.block === 'figure') { enterFigMode(i); msg('図を直しています（Esc で本文、Ctrl+Shift+O でツリーに戻る）', false, 5000); return; }
  ed.setCaret({ line: i, seg: 0, off: 0 }); scrollToCaret(); msg('表を直しています（Ctrl+Shift+O でツリーに戻る）', false, 5000); }
function toggleTree() { if (st.mode === 'tree') exitTree(); else enterTree(); } // 並べるときは、ツリーと紙面の間で移る
/* 見え方：紙面・ツリー・並べる（左にツリー、右に紙面） */
function setView(v) { if (v === st.view) return; if (v === 'paper') { if (st.mode === 'tree') exitTree(); st.view = 'paper'; render(); } else if (v === 'tree') { if (st.mode === 'tree') { st.view = 'tree'; render(); } else { st.view = 'paper'; enterTree(); } } else { const wasTree = st.mode === 'tree'; st.view = 'split'; if (!wasTree) { render(); treeFollowCaret(true); } else { render(); treeFollowPaper(true); } } geomDirty = true; syncView(); drawSub(); drawFkeys(); focusTA(); }
function treeRefresh() { if (st.structProxy) return; render(); drawSub(); status(); treeScrollToSel(); } // 紙面から構造の操作を使っている間（withCaretNode）は描き直しを後へ
/* ツリーの操作 → 文書の編集。終わったら選び直す */
function treeDo(fn, selectObj) { let r; ed.mutate('', () => { r = fn(); }); if (r && r.obj !== undefined) st.tree.sel = r.obj; else if (selectObj) st.tree.sel = selectObj; treeRefresh(); return r; }
/* 文の後ろ（前）に文を足す：仮の文を入れてその場で打つ（空のまま Esc で消える） */
function sentEnd(t) { return /[。．！？!?][」』）)】〉》”’]*$/.test(t) ? t : t + '。'; }
function treeAddSent(n, rel) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (!x) return; const at = rel === 'before' ? x.start : x.end; const ph = '新しい文。'; const prev = { key: treeKey(n), line: n.line, text: n.text };
  ed.mutate('', () => ed.spliceSeg(seg, at, at, ph, FZ.marksFor(ph, (seg.marks[x.start] | 0) & ~FZ.M.LINK))); st.tree.sel = FZ.tree.sentKey(n.obj, rel === 'before' ? n.si : n.si + 1); st.tree.multi.clear(); treeRefresh(); openTreeEdit(true); if (st.tree.edit) st.tree.edit.prev = prev; }
/* 文を動かす：段落の中で前・後ろの文と入れ替える */
function treeMoveSent(n, dir) { const seg = n.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); const j = n.si + dir; if (j < 0 || j >= ss.length) { msg('段落の端です（別の段落へはドラッグで）', true); return; } if (seg.links && seg.links.length) { msg('リンクを含む段落の文は並べ替えられません', true); return; }
  const A = ss[Math.min(n.si, j)], B = ss[Math.max(n.si, j)]; const piece = (x, last) => { let t = seg.text.slice(x.start, x.end), m = seg.marks.slice(x.start, x.end); if (!last) { const core = t.replace(/[ 　]+$/, ''); if (!/[。．！？!?][」』）)】〉》”’]*$/.test(core)) { t = core + '。'; m = m.slice(0, core.length).concat([m[core.length - 1] | 0]); } } return { t, m }; };
  const b = piece(B, false), a = piece(A, B.end >= seg.text.length); ed.mutate('', () => ed.spliceSeg(seg, A.start, B.end, b.t + a.t, b.m.concat(a.m))); st.tree.sel = FZ.tree.sentKey(n.obj, j); treeRefresh(); }
/* 文を別の段落の文の前・後ろへ（または段落の末尾へ） */
function treeDropSent(n, drop) { const sSeg = n.obj.segs[0]; const x = FZ.tree.sentences(sSeg.text)[n.si]; if (!x) return false; const t = drop.node; if (sSeg.links && sSeg.links.length) { msg('リンクを含む段落の文は動かせません', true); return false; }
  let piece = null, tObj = t.obj, tSi = t.kind === 'sent' ? t.si : null; const sameLine = tObj === n.obj;
  ed.mutate('', () => { const core = sSeg.text.slice(x.start, x.end); const tt = sentEnd(core.replace(/[ 　]+$/, '')); piece = { t: tt, m: FZ.marksFor(tt, (sSeg.marks[x.start] | 0) & ~FZ.M.LINK) }; for (let q = 0; q < Math.min(tt.length, core.length); q++) piece.m[q] = sSeg.marks[x.start + q] | 0;
    ed.spliceSeg(sSeg, x.start, x.end, '', []); const seg = tObj.segs[0]; let at;
    if (tSi == null) at = seg.text.length; else { let k = tSi; if (sameLine && tSi > n.si) k--; const ss = FZ.tree.sentences(seg.text); const y = ss[k]; at = !y ? seg.text.length : drop.rel === 'before' ? y.start : y.end; }
    if (at === seg.text.length && seg.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(seg.text)) { ed.spliceSeg(seg, at, at, '。', [seg.marks[at - 1] | 0]); at++; }
    ed.spliceSeg(seg, at, at, piece.t, piece.m);
    if (!sSeg.text.trim() && n.obj !== tObj) { const i = ed.doc.lines.indexOf(n.obj); if (i >= 0) FZ.tree.removeRange(ed, i, i); } });
  const ss2 = FZ.tree.sentences(tObj.segs[0].text); const k2 = ss2.findIndex(y => y.text.startsWith(piece.t.slice(0, Math.min(8, piece.t.length)))); st.tree.sel = FZ.tree.sentKey(tObj, Math.max(0, k2)); treeRefresh(); return true; }
/* 文を独立した段落に（浅く）：段落の後ろに新しい段落として */
function treeSplitSent(n) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (!x) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; let nl = null;
  ed.mutate('', () => { const t = seg.text.slice(x.start, x.end).replace(/[ 　]+$/, ''), m = seg.marks.slice(x.start, x.start + t.length); ed.spliceSeg(seg, x.start, x.end, '', []); nl = FZ.newLine(''); nl.attrs = { ...n.obj.attrs }; delete nl.attrs.figs; nl.segs[0].text = t; nl.segs[0].marks = m; FZ.tree.insertAt(ed, i + 1, nl); if (!seg.text.trim()) FZ.tree.removeRange(ed, i, i); });
  st.tree.sel = nl; treeRefresh(); msg('文を独立した段落にしました（Ctrl+Z で戻す）'); }
/* 文を種類（段落・見出し・箇条書き）の行に取り出す：段落をその文の前後で割る（前と後ろは段落のまま） */
function treeSentToKind(n, kind0) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; const i = ed.doc.lines.indexOf(n.obj); if (!x || i < 0) return; if (seg.links && seg.links.length) { msg('リンクを含む段落は割れません', true); return; }
  const sec = n.parent && n.parent.parent; const kind = kind0 === 'nlist' ? 'list' : kind0; const lvl = kind === 'num' ? (sec && sec.kind === 'num' ? Math.min(7, sec.level + 1) : 0) : kind === 'sym' ? (sec && sec.kind === 'sym' ? Math.min(7, sec.level + 1) : 0) : kind === 'list' ? (sec && sec.kind === 'list' ? Math.min(7, sec.level + 1) : 0) : 0;
  const attrsK = kind === 'title' ? { style: 'title' } : kind === 'num' || kind === 'sym' ? { style: kind, level: lvl } : kind === 'list' ? { list: kind0 === 'nlist' ? { level: lvl, kind: 'num' } : { level: lvl } } : {};
  let mid = null; ed.mutate('', () => { const end = x.start + x.text.length; const piece = (a, b) => ({ t: seg.text.slice(a, b).replace(/^[ 　]+|[ 　]+$/g, ''), m: seg.marks.slice(a, b) }); const B = piece(0, x.start), C = piece(x.start, end), A = piece(x.end, seg.text.length);
    const base = { ...n.obj.attrs }; const figs = base.figs; delete base.figs; const mk = (pc, at) => { const ln = FZ.newLine(''); ln.attrs = at; ln.segs[0].text = pc.t; ln.segs[0].marks = pc.m.slice(0, pc.t.length); while (ln.segs[0].marks.length < pc.t.length) ln.segs[0].marks.push(0); return ln; };
    const out = []; if (B.t) out.push(mk(B, { ...base })); mid = mk(C, kind === 'body' ? { ...base } : attrsK); out.push(mid); if (A.t) out.push(mk(A, { ...base })); if (figs) out[out.length - 1].attrs.figs = figs;
    const L0 = ed.doc.lines[i]; L0.segs = out[0].segs; L0.attrs = out[0].attrs; if (out[0] === mid) mid = L0; for (let k = 1; k < out.length; k++) FZ.tree.insertAt(ed, i + k, out[k]); });
  st.tree.sel = mid; treeRefresh(); msg('文を取り出しました（Ctrl+Z で戻す）'); }
/* 段落 → 見出し（いる節の子の段）。段落 → 前の段落の文 */
function treeParaUp(n) { const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; const t = FZ.tree.childType(n.parent) || { kind: 'list', level: 0 }; ed.mutate('', () => FZ.tree.retype(ed, i, i, t)); st.tree.sel = n.obj; treeRefresh(); msg('段落を' + ({ num: '番号見出し', sym: '記号見出し', list: '箇条書き', title: '表題' }[t.kind] || '見出し') + 'にしました（後ろの本文はその子に。Ctrl+Z で戻す）'); }
function treeParaDown(n) { const sib = n.parent.children.filter(c => c.kind !== 'fig'); const k = sib.indexOf(n); const pv = sib[k - 1]; if (!pv || pv.kind !== 'body' || !pv.obj || pv.obj.segs.length !== 1) { msg('前が段落でないので文にできません', true); return; }
  const i = ed.doc.lines.indexOf(n.obj); const ps = pv.obj.segs[0], s0 = n.obj.segs[0]; if ((ps.links && ps.links.length) || (s0.links && s0.links.length)) { msg('リンクを含む段落はつなげません', true); return; }
  ed.mutate('', () => { if (ps.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(ps.text)) ed.spliceSeg(ps, ps.text.length, ps.text.length, '。', [ps.marks[ps.text.length - 1] | 0]); ed.spliceSeg(ps, ps.text.length, ps.text.length, s0.text, s0.marks.slice()); if (n.obj.attrs.figs) pv.obj.attrs.figs = (pv.obj.attrs.figs || []).concat(n.obj.attrs.figs); FZ.tree.removeRange(ed, i, i); });
  st.tree.sel = pv.obj; treeRefresh(); msg('前の段落の文にしました（Ctrl+Z で戻す）'); }
/* ばらす（段落 → 文ごとの段落／箇条書き／親子）・まとめる（続く段落・箇条書き、または節と子 → 1 つの段落） */
function treeRegroup(how) { const n0 = treeNodeSel(); if (!n0) return;
  if (how === 'merge') { let list = treeSelected().filter(n => (n.kind === 'body' || n.kind === 'list' || n.kind === 'num' || n.kind === 'sym') && n.obj && n.obj.segs.length === 1).sort((p, q) => p.line - q.line); let range = null;
    if (list.length === 1) { const n = list[0]; if (n.end > n.line) range = [n.line, n.end]; else { msg('まとめる節を Shift+クリックで 2 つ以上選ぶか、子のある節を選んでください', true); return; } }
    if (!list.length) return; const objs = range ? ed.doc.lines.slice(range[0], range[1] + 1).filter(l => l.segs.length === 1 && !l.attrs.figure && !l.attrs.toc && !l.attrs.hr && !FZ.inTable(ed.doc, ed.doc.lines.indexOf(l))) : list.map(n => n.obj);
    if (objs.length < 2) { msg('まとめるものがありません', true); return; } const first = objs[0];
    ed.mutate('', () => { const seg = first.segs[0]; for (const o of objs.slice(1)) { const s1 = o.segs[0]; if (!s1.text.trim()) continue; if (seg.text && !/[。．！？!?][」』）)】〉》”’]*[ 　]*$/.test(seg.text)) ed.spliceSeg(seg, seg.text.length, seg.text.length, '。', [seg.marks[seg.text.length - 1] | 0]); ed.spliceSeg(seg, seg.text.length, seg.text.length, s1.text, s1.marks.slice()); if (o.attrs.figs) first.attrs.figs = (first.attrs.figs || []).concat(o.attrs.figs); }
      for (const o of objs.slice(1).reverse()) { const i = ed.doc.lines.indexOf(o); if (i >= 0) FZ.tree.removeRange(ed, i, i); } const keep = first.attrs.figs; first.attrs = keep ? { figs: keep } : {}; });
    st.tree.multi.clear(); st.tree.sel = first; treeRefresh(); msg(objs.length + ' 個を 1 つの段落にまとめました（Ctrl+Z で戻す）'); return; }
  const node = n0.kind === 'sent' ? n0.parent : n0; if (node.kind !== 'body' || !node.obj || node.obj.segs.length !== 1) { msg('段落（本文）を選んでください', true); return; }
  const seg = node.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); if (ss.length < 2) { msg('文が 1 つの段落はばらせません', true); return; } if (seg.links && seg.links.length) { msg('リンクを含む段落はばらせません', true); return; }
  const i = ed.doc.lines.indexOf(node.obj); const sec = node.parent; const lv0 = sec && sec.kind === 'list' ? Math.min(7, sec.level + 1) : 0;
  ed.mutate('', () => { const base = { ...node.obj.attrs }; const figs = base.figs; delete base.figs; const lines = ss.map((x, k) => { const t = x.text.replace(/^[ 　]+/, ''); const a = x.start + (x.text.length - t.length); const ln = FZ.newLine(''); ln.segs[0].text = t; ln.segs[0].marks = seg.marks.slice(a, a + t.length);
      ln.attrs = how === 'para' ? { ...base } : how === 'list' ? { list: { level: lv0 } } : { list: { level: k === 0 ? lv0 : Math.min(7, lv0 + 1) } }; return ln; });
    if (figs) lines[lines.length - 1].attrs.figs = figs; const L0 = ed.doc.lines[i]; L0.segs = lines[0].segs; L0.attrs = lines[0].attrs; for (let k = 1; k < lines.length; k++) FZ.tree.insertAt(ed, i + k, lines[k]); });
  st.tree.sel = node.obj; treeRefresh(); msg({ para: '文ごとの段落に', list: '箇条書きに', tree: '親子（最初の文が親）に' }[how] + 'ばらしました（Ctrl+Z で戻す）'); }
function treeToggleBreak() { const n = treeNodeSel(); if (!n || !n.obj || n.root) return; const i = ed.doc.lines.indexOf(n.obj); if (i < 0) return; ed.mutate('', () => { const a = ed.doc.lines[i].attrs; if (a.breakBefore) delete a.breakBefore; else a.breakBefore = true; }); treeRefresh(); msg(n.obj.attrs.breakBefore ? 'この節から新しい頁にします（ツリーに「改頁」の線）' : '改頁を外しました'); }
function treeAdd(rel, at) {
  const n = at || treeNodeSel(); if (!n) return; if (n.kind === 'sent') { if (rel === 'child') { msg('文には子を足せません', true); return; } treeAddSent(n, rel); return; } if (rel !== 'child' && (n.root || n === st.tree.view.top)) rel = 'child';
  if (rel === 'child' && (n.kind === 'body' || n.kind === 'block' || !FZ.tree.childType(n))) { msg('この節には子を足せません（本文・表・図）', true); return; }
  let ln = null; ed.mutate('', () => { ln = FZ.tree.add(ed, n, rel); }); if (!ln) return; if (rel === 'child') st.tree.folds.delete(treeKey(n));
  const prev = { key: treeKey(n), line: n.line, text: n.text }; st.tree.sel = ln; st.tree.multi.clear(); treeRefresh(); openTreeEdit(true); if (st.tree.edit) st.tree.edit.prev = prev;
}
function treeDelete() { const v0 = st.tree.view; const list = treeSelected().filter(n => !n.root && n !== (v0 && v0.top)); if (!list.length && treeNodeSel() === (v0 && v0.top)) { msg('いちばん上の節（表題）は消せません。紙面で直します', true); return; } if (!list.length) return; const v = st.tree.view; const first = list[0]; const sib = first.parent ? first.parent.children : []; const k = sib.indexOf(first); const next = sib[k + 1] || sib[k - 1] || first.parent; const figs = list.filter(n => n.kind === 'fig'), sents = list.filter(n => n.kind === 'sent' && !list.includes(n.parent)), rest = list.filter(n => n.kind !== 'fig' && n.kind !== 'sent'); const descN = rest.filter(n => !rest.some(m => m !== n && FZ.tree.isAncestor(m, n))).reduce((t, n) => t + treeDesc(n), 0);
  ed.mutate('', () => { for (const n of sents.slice().sort((p, q) => p.line - q.line || q.si - p.si)) { const seg = n.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[n.si]; if (x) ed.spliceSeg(seg, x.start, x.end, '', []); } /* 文は段落の中から消す */ for (const n of figs) { const x = ed.figById(n.fig.id); if (!x) continue; const at = ed.doc.lines[x.line].attrs; at.figs.splice(x.k, 1); if (!at.figs.length) delete at.figs; } FZ.tree.remove(ed, rest); }); /* 図表は図版だけを消す（付いている行は残す） */ st.tree.multi.clear(); st.tree.sel = next ? treeKey(next) : null; treeRefresh(); msg(`${list.length} 個の節を消しました（${descN ? `子孫 ${descN} 個も。` : ''}Ctrl+Z で戻る）`); }
function treeMoveSel(fn) { const v0 = st.tree.view; const all = treeSelected().filter(n => !n.root && n !== (v0 && v0.top)); const list = all.filter(n => n.kind !== 'fig'); if (!list.length) { if (all.length) msg('図表は付いている行と一緒に動きます（その行の節を動かす。並べ替えは F7 挿入の「図表設定」）', true); return; } const n = treeNodeSel(); const key = treeKey(n); let ok = false; ed.mutate('', () => { ok = fn(list, n); }); if (!ok) { ed.undoStack.pop(); msg('そちらへは動かせません', true); } st.tree.sel = key; treeRefresh(); }
function treeNav(dirKey) {
  const v = st.tree.view; const n = treeNodeSel(); if (!v || !n) return; const h = st.tree.dir === 'h'; const along = st.tree.dir === 'i' ? { up: 'row-', down: 'row+', left: 'parent', right: 'child' } : h ? { up: 'prev', down: 'next', left: 'parent', right: 'child' } : { left: 'prev', right: 'next', up: 'parent', down: 'child' }; const a = along[dirKey];
  let t = null; const vis = c => treeVisKids(c, v.top);
  if (a === 'row-' || a === 'row+') { const k = v.shown.indexOf(n); t = v.shown[k + (a === 'row+' ? 1 : -1)] || null; } // 字下げ：上下は見えている次・前の行
  else if (a === 'parent') t = n === v.top ? null : n.parent; else if (a === 'child') { if (st.tree.folds.has(treeKey(n))) { st.tree.folds.delete(treeKey(n)); render(); } t = vis(n)[0] || null; }
  else { const p = v.pos.get(n); const same = v.shown.filter(c => c !== n && v.pos.get(c).depth === p.depth); const key = c => h ? v.pos.get(c).y : v.pos.get(c).x; const k0 = key(n); const cand = same.filter(c => a === 'next' ? key(c) > k0 : key(c) < k0).sort((x, y) => a === 'next' ? key(x) - key(y) : key(y) - key(x)); t = cand[0] || null; }
  if (t) { st.tree.sel = treeKey(t); st.tree.multi.clear(); renderTreeOverlay(); render(); drawSub(); status(); treeScrollToSel(); }
}
function treeKeyDown(e) {
  const k = e.key, shift = e.shiftKey, ctrl = e.ctrlKey || e.metaKey, alt = e.altKey;
  if (e.isComposing || e.keyCode === 229) { e.preventDefault(); return; }
  if (st.armed && !ctrl && !alt && k.length === 1) { const it = (GROUPS[st.group] || { items: [] }).items.find(it => it.key && it.key.toLowerCase() === k.toLowerCase()); if (it) { e.preventDefault(); const g0 = st.group; disarm(); runItem(it); if (st.mode === 'tree' && st.group === g0) afterGroupItem(); if (it.msel) drawSub(); return; } disarm(); } // F キーで開いたグループ：1 文字で実行（紙面と同じ）
  if (/^F\d+$/.test(k)) { if (fkey(k)) e.preventDefault(); return; }
  if (ctrl && !alt) { const lk = k.toLowerCase();
    if (lk === 'enter') { e.preventDefault(); openTreeEdit(false); return; }
    const TXT = { b: 'bold', u: 'under', e: 'alignC', r: 'alignR', j: 'alignJ', l: shift ? 'link' : 'alignL', f: 'find', h: 'replace', p: 'print', n: 'new', m: 'moveTo', g: 'chart' }; if (TXT[lk]) { e.preventDefault(); run(TXT[lk]); return; } // 紙面と同じ近道：選んだ節に効く
    if (lk === 'z') { e.preventDefault(); shift ? ed.redo() : ed.undo(); treeRefresh(); return; } if (lk === 'y') { e.preventDefault(); ed.redo(); treeRefresh(); return; }
    if (lk === 's') { e.preventDefault(); run(shift ? 'saveAs' : 'save'); return; } if (lk === 'k') { e.preventDefault(); run('palette'); return; } if (lk === 'o' && shift) { e.preventDefault(); exitTree(); return; }
    if (lk === 'c' || lk === 'x' || lk === 'v') return; // 写す・貼るは copy／paste の出来事で
    const mv = { arrowup: 'up', arrowdown: 'down', arrowleft: 'out', arrowright: 'in' }[lk]; if (mv) { e.preventDefault(); run('tv:' + mv); return; }
    if (lk === '=' || lk === '+' || lk === ';') { e.preventDefault(); treeZoom(1); return; } if (lk === '-') { e.preventDefault(); treeZoom(-1); return; } if (lk === '0') { e.preventDefault(); treeZoom(0); return; }
    return; }
  e.preventDefault();
  if (alt) { const mv = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'out', ArrowRight: 'in' }[k]; if (mv) run('tv:' + mv); return; }
  if (k === 'Escape') { if (st.form) { closeForm(); return; } if (st.group) { treeCloseGroup(); return; } if (st.tree.multi.size) { st.tree.multi.clear(); render(); return; } exitTree(); return; }
  const nav = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' }[k]; if (nav) { treeNav(nav); return; }
  if (k === 'Enter') { treeAdd(shift ? 'before' : 'after'); return; }
  if (k === 'Tab') { if (shift) run('tv:out'); else treeAdd('child'); return; }
  if (k === 'Delete' || k === 'Backspace') { treeDelete(); return; }
  if (k === ' ') { run('tv:fold'); return; }
  if (k === 'Home') { st.tree.sel = treeKey(st.tree.view.top); render(); treeScrollToSel(); return; }
  if (k === '+' || k === ';' || k === '=') { treeZoom(1); return; } if (k === '-') { treeZoom(-1); return; }
  if (/^[0-9]$/.test(k)) { treeSetDepth(+k); return; }
}
function treeSetDepth(d) { const n = treeNodeSel(); st.tree.depth = d; st.tree.folds = new WeakSet(); if (n) st.tree.sel = treeKey(n); render(); drawSub(); status(); treeScrollToSel(); treeMemSave(); }
/* その場で文字を直す（新しく足した節は、空のまま決めるか Esc で取り消すと消える） */
function openTreeEdit(isNew) {
  closeTreeEdit(true); const v = st.tree.view; const n = treeNodeSel(); if (!v || !n || n.root) { if (n && n.root) msg('根（文書の名前）は直せません。表題の行を足すと根になります', true); return; }
  if (n.kind !== 'fig' && (!n.obj || n.obj.segs.length !== 1 || n.kind === 'block')) { msg('表・図・囲みの中身は紙面で直します（Esc で紙面へ）', true); return; }
  const p = v.pos.get(n); const svg = treeEl.querySelector('svg'); const mr = tpane.getBoundingClientRect(), sr = svg.getBoundingClientRect(); const mk = (v.info.get(n) || {}).mk || '';
  const el = document.createElement('textarea'); el.className = 'inl tinl'; const rawT = n.kind === 'fig' ? n.fig.title : n.kind === 'sent' ? n.raw : n.obj.segs[0].text; const refs = [...rawT].filter(ch => FZ.isRefChar(ch)); el.value = rawT.replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕'); // 図番の字は〔図〕で見せ、決めるときに戻す el.spellcheck = false; el.setAttribute('aria-label', '節の文字');
  /* 箱そのものに書く：番号・記号の後ろから、箱と同じ字・同じ行送りで、箱の中に重ねる（浮いた別の箱を出さない）。長くなれば下へ伸びる */
  const SC = st.tree.scale; const ff = getComputedStyle(svg).fontFamily; const cv = openTreeEdit.cv || (openTreeEdit.cv = document.createElement('canvas').getContext('2d')); const head = n.kind === 'title'; cv.font = `${head ? '700 ' : ''}${TREE_FS}px ${ff}`; const mkW = mk ? cv.measureText(mk + treeMkSep(mk)).width : 0;
  const bx = sr.left - mr.left + tpane.scrollLeft, by = sr.top - mr.top + tpane.scrollTop; const PYs = 3; const minH = Math.max(TREE_LH + 2, p.h - 2) * SC;
  Object.assign(el.style, { left: bx + (v.M + p.x + TREE_PX - 2 + mkW) * SC + 'px', top: by + (v.M + p.y + 1) * SC + 'px', width: Math.max(60, p.w - TREE_PX - mkW - 2) * SC + 'px', height: minH + 'px', fontSize: TREE_FS * SC + 'px', lineHeight: TREE_LH * SC + 'px', textAlign: 'left', padding: `${(PYs - 1) * SC}px ${2 * SC}px 0`, fontFamily: ff, fontWeight: head ? '700' : '400' });
  el.rows = 1; const grow = () => { el.style.height = minH + 'px'; if (el.scrollHeight > el.clientHeight + 1) el.style.height = el.scrollHeight + 'px'; }; el.addEventListener('input', grow);
  tpane.append(el); grow(); st.formFocus = true; st.tree.edit = { el, obj: n.obj, isNew, mk, fig: n.kind === 'fig' ? n.fig : null, sent: n.kind === 'sent' ? n.si : null, refs }; renderTreeOverlay();
  el.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.isComposing || ev.keyCode === 229) return; if (ev.key === 'Escape') { ev.preventDefault(); closeTreeEdit(false); } else if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); closeTreeEdit(true); } else if (ev.key === 'Tab') { ev.preventDefault(); closeTreeEdit(true); treeAdd(ev.shiftKey ? 'before' : 'child'); } });
  el.addEventListener('blur', () => { if (st.tree.edit && st.tree.edit.el === el) closeTreeEdit(true); });
  el.focus(); if (isNew) el.select(); else el.setSelectionRange(el.value.length, el.value.length);
  msg((mk ? mk + ' ' : '') + '文字を打って Enter（Tab で決めて子を足す、Esc で取消）', false, 0);
}
function closeTreeEdit(commit) {
  const E = st.tree.edit; if (!E) return; st.tree.edit = null; st.formFocus = false; let rk = 0; const v = E.el.value.replace(/\n/g, '').replace(/〔図〕/g, m => (E.refs && rk < E.refs.length) ? E.refs[rk++] : m); E.el.remove(); msg('');
  if (E.fig) { if (commit && v !== E.fig.title) ed.setFig(E.fig.id, { title: v }); if (st.mode === 'tree') { render(); drawSub(); status(); } focusTA(); return; } // 図表の題
  const i = ed.doc.lines.indexOf(E.obj); if (i < 0) { focusTA(); return; }
  if (E.isNew && (!commit || !v.trim())) { ed.undo(); if (E.prev) { st.tree.sel = E.prev.key; st.tree.selLine = E.prev.line; st.tree.selText = E.prev.text; } render(); drawSub(); status(); focusTA(); return; } // 足したばかりの節を取り消す（選びは元の節へ）
  if (E.sent != null) { const seg = E.obj.segs[0]; const x = FZ.tree.sentences(seg.text)[E.sent]; if (commit && x && v.trim() && v !== x.text) { const t = sentEnd(v.trim()); const m0 = seg.marks[x.start] | 0; ed.mutate(E.isNew ? 'tnew' : '', () => ed.spliceSeg(seg, x.start, x.start + x.text.length, t, FZ.marksFor(t, m0 & ~FZ.M.LINK))); } }
  else if (commit && v !== E.obj.segs[0].text) { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(E.obj); if (n) { ed.mutate(E.isNew ? 'tnew' : '', () => FZ.tree.setText(ed, n, v)); } }
  if (st.mode === 'tree') { render(); drawSub(); status(); } focusTA();
}
/* 写す：選んだ節を子ごと Markdown に（AI へそのまま渡せる）。貼る：Markdown の箇条書き・見出しを選んだ節の子として */
/* ================= 構造・ツリーで書き出す（X1・X4） ================= */
/* ツリーの見た目の型：今のツリー（深さ・畳み・形）の箱と線。ツリーを出していなければ、その場で組む */
function treeModel() { const visible = st.view === 'tree' || st.view === 'split'; const sel = st.tree.sel; st.tree.exportW = 720; let v; try { renderTree(); v = st.tree.view; } finally { st.tree.exportW = 0; } /* 書き出しは決まった幅で組む（画面の幅に左右されない） */
  if (visible) { st.tree.sel = sel; renderTree(); } else { treeEl.style.display = 'none'; treeEl.innerHTML = ''; st.tree.view = null; }
  if (!v || !v.edges) return null; const cache = new Map(); let fk = 0;
  const nodes = v.shown.map(n => { const p = v.pos.get(n), s = v.info.get(n) || { lines: [] }; if (!p) return null; const o = { x: p.x, y: p.y, w: p.w, h: p.h, lines: s.lines || [], head: !!(n.root || n.kind === 'title'), body: n.kind === 'body' || n.kind === 'block', sent: n.kind === 'sent', para: !!s.box, inBox: !!s.inBox };
    if (s.fig) o.fig = treeFigModel(n, s, cache, fk++); return o; }).filter(Boolean); /* 中身を見せている図表・表・流れ図も書き出す（以前は名前の箱だけで、中身が抜けていた） */
  const W = Math.max(...nodes.map(n => n.x + n.w)) + 4, H = Math.max(...nodes.map(n => n.y + n.h)) + 4; return { nodes, edges: v.edges, W, H }; }
/* 書き出し用の図表の中身：箱の中の位置（書き出しの余白は 5）、紙面と同じ描画の SVG、表ならセルの箱、画像なら元の画像 */
function treeFigModel(n, s, cache, k) { const rc = s.fig.rc, w = s.fig.w, h = s.fig.h; const f = { x: TREE_PX, y: (s.lines || []).length * TREE_LH + 8, w, h, svg: treeFigSvg(rc, 0, 0, w, h, 900 + k, cache) };
  if (n.kind === 'block' && n.block === 'table') f.cells = treeTableCells(n, rc, w / rc.w);
  else if (n.kind === 'fig' && n.fig && n.fig.file && !n.fig.chart) { const img = ed.doc.images && ed.doc.images[n.fig.file]; if (img && /^image\/(png|jpeg|gif)$/.test(img.mime)) f.image = { mime: img.mime, data: img.data }; }
  return f; }
/* 表のセル：紙面の組版の位置を、ツリーの箱の中の位置に縮めて（Word・PowerPoint では字を直せる箱にする） */
function treeTableCells(n, rc, sc) { const L = ed.lay, geo = L.geo, cw = geo.cw, ch = geo.ch; const X = c => geo.left + c * cw, Y = r => geo.top + (geo.bodyTop + r) * ch; const I = FZ.tbl.info(ed, n.line); if (!I) return null; const out = [];
  for (let i = n.line; i <= n.end; i++) { const m = L.lineMap[i], ln = ed.doc.lines[i]; if (!m || !ln || !ln.attrs.cells) continue; const rows = m.rows.filter(r => r.page === rc.page); if (!rows.length) continue; const y1 = Math.min(...rows.map(r => r.y)), y2 = Math.max(...rows.map(r => r.y + r.h));
    for (const c of FZ.cellsAt(ed.doc, i, ed.doc.format.cols)) { if (c.left < I.L - 1e-6 || c.right > I.R + 1e-6) continue; const text = ln.segs.filter(g => g.col >= c.left - 1e-6 && g.col < c.right - 1e-6).map(g => g.text).join('').trim();
      out.push({ x: (X(c.left) - rc.x) * sc, y: (Y(y1) - rc.y) * sc, w: (c.right - c.left) * cw * sc, h: (y2 - y1) * ch * sc, text, head: i === n.line }); } }
  return out.length ? { list: out, fs: cw * sc * 0.82 } : null; }
/* 図表の中身の SVG を PNG に（PowerPoint・Word の絵に。字の書体は紙面の CSS を写して入れる） */
async function treeFigPng(f) { const rs = getComputedStyle(document.documentElement); const vars = { '--mincho': rs.getPropertyValue('--mincho'), '--gothic': rs.getPropertyValue('--gothic') }; let css = '';
  for (const sh of document.styleSheets) { let rules; try { rules = sh.cssRules; } catch { continue; } for (const r of rules) if (r.selectorText && /svg\.pg/.test(r.selectorText)) css += r.cssText.replace(/var\((--[a-z]+)\)/g, (m0, v) => vars[v] || 'serif') + '\n'; }
  const S = 3, W = Math.max(1, Math.round(f.w * S)), H = Math.max(1, Math.round(f.h * S)); const src = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${f.w} ${f.h}"><style>${css}</style><rect width="100%" height="100%" fill="#fff"/>${f.svg}</svg>`;
  const url = URL.createObjectURL(new Blob([src], { type: 'image/svg+xml' })); try { const img = new Image(); await new Promise((ok, ng) => { img.onload = ok; img.onerror = () => ng(new Error('図表の絵を作れませんでした')); img.src = url; }); const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(img, 0, 0, W, H); return c.toDataURL('image/png').split(',')[1]; } finally { URL.revokeObjectURL(url); } }
const TREE_FAMILY = () => { const o = FZ.officeFont(ed.doc.format.fontGothic || 'BIZ UDGothic'); return `'${o.ea}','BIZ UDGothic','Yu Gothic','Meiryo',sans-serif`; };
async function exportTree(kind) { const m = treeModel(); if (!m || !m.nodes.length) { msg('ツリーが空です', true); return; } const name = baseTitle() + '（ツリー）';
  const prep = async () => { for (const n of m.nodes) { const f = n.fig; if (!f || f.cells) continue; if (f.image) f.pic = { mime: f.image.mime, data: f.image.data }; else { try { f.pic = { mime: 'image/png', data: await treeFigPng(f) }; } catch (e) { f.pic = null; } } } }; /* 表はセルの箱、画像は元の画像、グラフ・流れ図は紙面と同じ描画の絵 */
  if (kind === 'pptx') return exportVia('ツリー図（PowerPoint）', name + '.pptx', async () => { await prep(); return FZ.zipAsync(FZ.treeToPptx(m, { files: true, font: ed.doc.format.fontGothic, title: name })); });
  const pw = 595.3, ph = 841.9;
  if (kind === 'pdf') { try { await busy('ツリーを書き出し中…'); printTreePages(FZ.treePageSvgs(m, pw, ph, { family: TREE_FAMILY() })); } catch (e) { msg('ツリーの書き出しに失敗：' + e.message, true); } return; }
  if (kind === 'docx') { let pages = 0; return exportVia('ツリー図（Word）', name + '.docx', async () => { await prep(); /* Word：頁ごとに箱と線の図形のまとまり（Word で動かせる・字を直せる。画像にしない） */ const d = FZ.newDoc(); d.format = { ...d.format, ...JSON.parse(JSON.stringify(ed.doc.format)), kind: 'doc', paper: 'A4', widthMm: 210, heightMm: 297, landscape: false, margins: { top: 15, right: 15, bottom: 15, left: 15 }, headerRows: 0, footerRows: 0, header: '', footer: '' }; d.images = {};
      m.nodes.forEach((n, i) => { if (n.fig && n.fig.pic) { n.fig.picKey = 'tree-fig-' + i; d.images[n.fig.picKey] = n.fig.pic; } }); const Ds = FZ.treeDrawings(m, (210 - 30) * 72 / 25.4, (297 - 30) * 72 / 25.4 - 4); pages = Ds.length; d.lines = Ds.map(D => ({ segs: [FZ.newSeg(0, '')], attrs: { drawing: D } }));
      return { data: await FZ.zipAsync(FZ.toDocx(d, { files: true })), note: `（${Ds.length} 頁。箱と線は Word の図形で、字も直せる）` }; }); } }
function printTreePages(svgs) { let box = $('treePrint'); if (box) box.remove(); box = document.createElement('div'); box.id = 'treePrint'; box.innerHTML = svgs.join(''); document.body.append(box); document.body.classList.add('ptree');
  let s = $('treePrintStyle'); if (!s) { s = document.createElement('style'); s.id = 'treePrintStyle'; document.head.append(s); } s.textContent = '@page { size: A4 portrait; margin: 0 } #treePrint { display: none } @media print { body.ptree > *:not(#treePrint) { display: none !important } body.ptree #treePrint { display: block } #treePrint > svg { display: block; width: 210mm; height: 297mm; page-break-after: always; break-after: page } }';
  const done = () => { document.body.classList.remove('ptree'); box.remove(); window.removeEventListener('afterprint', done); }; window.addEventListener('afterprint', done); msg('ツリーを印刷します（PDF にするなら印刷先で「PDF に保存」）', false, 6000); setTimeout(() => { try { window.print(); } catch (e) { done(); } }, 50); }
/* Word の取り込み（X5） */
function pickDocx() { const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document'; inp.onchange = () => { const f = inp.files[0]; if (f) importDocxFile(f); }; inp.click(); }
function pickPptx() { const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation'; inp.onchange = () => { const f = inp.files[0]; if (f) importPptxFile(f); }; inp.click(); }
/* 1.0.11g PowerPoint の取り込み：スライド→資料の頁、図形の段と列→区画、表・画像・グラフ・ノート（付箋） */
async function importPptxFile(file) { try { await busy('PowerPoint を取り込み中…'); const buf = await file.arrayBuffer(); const name = file.name.replace(/\.pptx$/i, ''); const r = await FZ.fromPptx(buf, { title: name, format: slideFormat(JSON.parse(JSON.stringify(defaultFormat()))) });
    withDiscard(() => { st.file = null; st.savedAt = 0; ed.setDoc(r.doc); setFileName(name + '.fzk'); ed.dirty = true; clearRecovery(); scheduleRecovery(); st.mode = 'text'; drawFkeys(); drawSub(); render(); main.scrollTop = 0; focusTA(); const t = r.stats;
      const ti = ed.doc.lines.map((l, i) => l.attrs.style === 'title' ? i : -1).filter(i => i >= 0); const by = new Map(); for (const c of r.conv || []) { const L = c.si >= 0 ? ti[c.si] : undefined; if (!by.has(c.what)) by.set(c.what, []); if (L != null && !by.get(c.what).includes(L)) by.get(c.what).push(L); }
      setConvLog({ title: 'PowerPoint の取り込み', file: file.name, time: Date.now(), items: [...by.entries()].map(([what, lines]) => ({ what, lines })) }); const nc = by.size;
      msg(`PowerPoint を取り込みました：スライド ${t.slides}・区画 ${t.panels}・表 ${t.tables}・画像 ${t.images}・グラフ ${t.charts}・ノート ${t.notes}（付箋に）。見た目ではなく構造の近似です${nc ? `（推定・入らない所 ${nc} 種：${K('convLog')}）` : ''}。.fzk として保存してください`, false, 10000); }, '取り込む'); }
  catch (e) { msg('PowerPoint を取り込めませんでした：' + e.message, true); } }
async function importDocxFile(file) { try { await busy('Word を取り込み中…'); const buf = await file.arrayBuffer(); const r = await FZ.fromDocx(buf, { ...FZ.newDoc(), format: JSON.parse(JSON.stringify(defaultFormat())) }); if (!r.doc.title) r.doc.title = file.name.replace(/\.docx$/i, '');
    withDiscard(() => { st.file = null; st.savedAt = 0; ed.setDoc(r.doc); setFileName(file.name.replace(/\.docx$/i, '.fzk')); ed.dirty = true; clearRecovery(); scheduleRecovery(); st.mode = 'text'; drawFkeys(); drawSub(); render(); main.scrollTop = 0; focusTA();
      const t = FZ.tree.build(ed.doc, {}); const nh = t.nodes.filter(n => n.kind === 'num' || n.kind === 'sym').length; const by = new Map(); for (const c of r.conv || []) { const L = c.near ? ed.doc.lines.findIndex(l => l.segs.map(sg => sg.text).join('').includes(c.near)) : -1; if (!by.has(c.what)) by.set(c.what, []); if (L >= 0 && !by.get(c.what).includes(L)) by.get(c.what).push(L); }
      if (r.lifted) by.set('見出しは平文の番号から起こした（Word の見出しスタイルが無い）', []); setConvLog({ title: 'Word の取り込み', file: file.name, time: Date.now(), items: [...by.entries()].map(([what, lines]) => ({ what, lines })) }); const nc = by.size;
      msg(`Word を取り込みました：見出し ${nh}${r.headings ? '' : r.lifted ? `（平文の番号から ${r.lifted} 行起こした）` : '（見出しが見つかりませんでした）'}・画像 ${r.images}${nc ? `（入らない・推定 ${nc} 種：${K('convLog')}）` : ''}。.fzk として保存してください`, false, 9000); }, '取り込む'); }
  catch (e) { msg('Word を取り込めませんでした：' + e.message, true); } }
/* ================= 構造の操作を紙面でも（G1・G4） =================
 * 紙面のカーソルの所（文を選んでいればその文、行を範囲で選んでいればその行の節）をツリーの節と見なし、ツリーと同じ操作を当てる。
 * 文書・選択・メニューは 1 つ：ツリーの操作の関数をそのまま使い、終わったらカーソルを結果の節（文なら文を選び直す）へ */
function sentSelOk() { const q = st.sentSel; const s = ed.sel(); if (!q || !s) return false; const ln = ed.doc.lines[s.a.line]; if (ln !== q.obj || s.a.line !== s.b.line || ln.segs.length !== 1) return false; return s.a.off === q.a && s.b.off === q.b; }
function selectSentence(pos) { if (st.mode === 'tree') { msg('ツリーでは文の深さ（F10 → Y）で文を選べます'); return false; } if (st.mode !== 'text') exitMode(); if (pos) ed.setCaret(pos);
  const L = ed.caret.line, ln = ed.doc.lines[L]; if (!ln || ln.segs.length !== 1 || !ln.segs[0].text.trim() || ln.attrs.cells || ln.attrs.figure || ln.attrs.toc) { msg('文を選べるのは本文・見出し・箇条書きの行です', true); return false; }
  const ss = FZ.tree.sentences(ln.segs[0].text); if (!ss.length) return false; const off = ed.caret.off; let k = ss.findIndex(x => off >= x.start && off < x.end); if (k < 0) k = off >= ss[ss.length - 1].start ? ss.length - 1 : 0;
  const x = ss[k]; const b = x.start + x.text.length; ed.anchor = { line: L, seg: 0, off: x.start }; ed.caret = { line: L, seg: 0, off: b, vcol: null, vrow: 0 }; ed.onCaret(); st.sentSel = { obj: ln, si: k, a: x.start, b, n: ss.length };
  requestOverlay(); status(); msg(ss.length > 1 ? `${k + 1} 文目（${ss.length} 文の段落）を選びました：Alt+← 段落に・Alt+→ 箇条書きに・Alt+↑↓ 並べ替え・${K('structGroup')} の種類で取り出す` : '1 文だけの段落です（段落として上げ下げ・並べ替え）', false, 7000); return true; }
/* 紙面のカーソル（選んだ文）の節：構造の操作と対象の見せ方（P07）が同じ答えを使う */
function caretNode(opts = {}) { const ss = !opts.noSent && sentSelOk() ? st.sentSel : null; const tr = FZ.tree.build(ed.doc, { body: true, sentences: true, figs: false, title: ed.doc.title || '文書' }); const r = tr.root; tr.top = (r.children.length === 1 && r.children[0].kind === 'title') ? r.children[0] : r;
  const line = ed.doc.lines[ed.caret.line]; let node = ss ? tr.sents.find(n => n.obj === line && n.si === ss.si) : null; if (!node) node = tr.byObj.get(line); return { tr, node, line, ss }; }
function withCaretNode(fn, opts = {}) {
  if (st.mode === 'fig' || st.mode === 'rule' || st.mode === 'fill') exitMode();
  const { tr, node, line, ss } = caretNode(opts); const r = tr.root;
  if (!node) { msg('ここには構造の操作が効きません（表の中・空行・図など）', true); return false; }
  const multi = new Set(); const sel = ed.sel(); if (!ss && sel && sel.a.line !== sel.b.line) for (let k = sel.a.line; k <= sel.b.line; k++) { const n = tr.byObj.get(ed.doc.lines[k]); if (n) multi.add(treeKey(n)); }
  const save = { view: st.tree.view, multi: st.tree.multi }; const caret0 = { ...ed.caret }, obj0 = line, u0 = ed.undoStack.length;
  st.tree.view = { tr, shown: [r, ...tr.nodes, ...tr.sents], top: tr.top, proxy: true }; st.tree.sel = treeKey(node); st.tree.multi = multi; st.structProxy = true;
  try { fn(node); } finally { st.structProxy = false; }
  const key = st.tree.sel; st.tree.view = null; st.tree.multi = save.multi;
  if (ed.undoStack.length !== u0 || opts.always) { let done = false;
    if (key && typeof key === 'object' && key.sent !== undefined) { const t2 = FZ.tree.build(ed.doc, { body: true, sentences: true }); const n2 = t2.sents.find(n => n.key === key); /* 文の名札は { sent: k }（行と番号で決まる） */ if (n2) { const L = ed.doc.lines.indexOf(n2.obj); const b = n2.sStart + n2.raw.length; ed.anchor = { line: L, seg: 0, off: n2.sStart }; ed.caret = { line: L, seg: 0, off: b, vcol: null, vrow: 0 }; st.sentSel = { obj: n2.obj, si: n2.si, a: n2.sStart, b, n: n2.parent.children.length }; done = true; } }
    if (!done) { const obj = key && typeof key === 'object' && key.sent === undefined ? key : obj0; let L = ed.doc.lines.indexOf(obj); if (L < 0) L = Math.min(caret0.line, ed.doc.lines.length - 1); const ln = ed.doc.lines[L]; const same = obj === obj0; const sg = same ? Math.min(caret0.seg, ln.segs.length - 1) : 0; ed.anchor = null; ed.caret = { line: L, seg: sg, off: same ? Math.min(caret0.off, ln.segs[sg].text.length) : 0, vcol: null, vrow: 0 }; st.sentSel = null; }
    ed.onCaret(); }
  render(); drawSub(); status(); requestOverlay(); return true; }
/* 構造の操作（ツリーの選んだ節／紙面のカーソルの節に同じ意味で効く） */
function structOp(op, arg) {
  const T = () => { const n = treeNodeSel(); if (!n) return; const para = n.kind === 'body' && n.obj && n.obj.segs.length === 1;
    if (op === 'out') { if (n.kind === 'sent') return treeSentToKind(n, 'body'); if (para) return treeParaUp(n); return treeMoveSel((list, x) => (FZ.tree.levelExcess(x) > 0 && FZ.tree.levelShift(ed, x, -1)) || FZ.tree.promote(ed, st.tree.view.tr, x) || FZ.tree.levelShift(ed, x, -1)); } /* 段を飛ばして深くしてあれば、まず段を戻す */
    if (op === 'in') { if (n.kind === 'sent') return treeSentToKind(n, 'list'); if (para) return treeParaDown(n); return treeMoveSel((list, x) => FZ.tree.demote(ed, st.tree.view.tr, x) || FZ.tree.levelShift(ed, x, 1)); } /* 入れる兄が無ければ段だけ深く（Markdown の見出しのように） */
    if (op === 'up' || op === 'down') { const d = op === 'up' ? -1 : 1; if (n.kind === 'sent') return treeMoveSent(n, d); return treeMoveSel((list, x) => FZ.tree.shift(ed, st.tree.view.tr, x, d)); }
    if (op === 're') return treeRegroup(arg); };
  if (st.mode === 'tree') { T(); return; }
  if (st.mode !== 'text') exitMode();
  if ((op === 'up' || op === 'down') && !sentSelOk()) { run(op === 'up' ? 'outlineUp' : 'outlineDown'); return; } // 行・節の並べ替えは紙面の節の移動（範囲の選択にも効く）
  withCaretNode(T, { noSent: op === 're' }); }
/* 種類のコマンド：ツリーでは選んだ節（子の段も揃える）、紙面で文を選んでいればその文を段落から取り出す。それ以外は紙面の行の種類（従来どおり） */
function kindGuard(k) { if (st.mode === 'tree') { treeSetKind(k); return true; } if (st.mode === 'text' && sentSelOk() && st.sentSel.n > 1) { withCaretNode(n => { if (n.kind === 'sent') treeSentToKind(n, k); }); return true; } return false; }
/* AI に渡す：Markdown をクリップボードへ（ファイルにしない） */
async function copyText(t) { try { await navigator.clipboard.writeText(t); return true; } catch { /* file:// などで使えない時は下の方法 */ }
  try { const x = document.createElement('textarea'); x.value = t; x.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0'; document.body.append(x); x.select(); const r = document.execCommand('copy'); x.remove(); focusTA(); return r; } catch { return false; } }
/* カーソルの行を含む節（箇条書きの中なら、それを含む見出しの節）：{ line, end, text } | null */
function sectionAt(L) { const tr = FZ.tree.build(ed.doc, {}); let best = null; for (const n of tr.nodes) if (n.line <= L && n.end >= L && (n.kind === 'num' || n.kind === 'sym' || n.kind === 'title' || n.kind === 'list') && (!best || n.depth > best.depth)) best = n;
  if (best && best.kind === 'list') { let p = best; while (p.parent && p.parent.kind === 'list') p = p.parent; best = p.parent && !p.parent.root ? p.parent : p; } return best; }
/* AI に写す範囲（P18：帯にも同じ答えを見せる）：文書全体／ツリーで選んだ節／紙面で選んだ複数行／カーソルの節 */
function aiScope(whole) { if (whole) return { whole: true, what: '文書全体' };
  if (st.mode === 'tree') { const n = treeNodeSel(); return n && !n.root ? { tree: true, what: '「' + String(n.text).slice(0, 16) + '」の節', range: nodeRange(n) } : { tree: true, what: '文書全体' }; }
  const s = ed.sel(); if (s && s.a.line !== s.b.line) return { what: '選んだ範囲', range: [s.a.line, s.b.line] };
  const best = sectionAt(ed.caret.line); return best ? { what: '「' + String(best.text).slice(0, 16) + '」の節', range: [best.line, best.end] } : { whole: true, what: '文書全体（見出しがありません）' }; }
async function aiCopy(whole) { const sc = aiScope(whole); let md, idx = null; const what = sc.what;
  { const pz = !whole && sc.range ? FZ.pufuAt(ed.doc, sc.range[0]) : null; if (pz && pz.B.head === sc.range[0]) { const B = pz.B; md = FZ.pufuToMd(ed.doc, B); rememberScope(rangeIdx(B.head, B.end - 1), what.replace(/（.*$/, '')); const ok = await copyText(md); msg(ok ? `プ譜を役の名前付きで写しました（${md.length.toLocaleString()} 字）。直してもらった答えは ${K('aiReturn')} で比べて取り込む` : '写せませんでした', !ok, 8000); return ok; } } /* 1.0.14d プ譜の節：役の名前付きの形（AI が役を読み違えない・戻すときに行ごとに比べられる） */
  if (sc.tree) { md = treeCopyText(); idx = treeCopyIdx(); }
  else if (sc.range) { md = FZ.toGfm(sliceDoc(sc.range[0], sc.range[1]), { fz: true }); idx = rangeIdx(sc.range[0], sc.range[1]); }
  else md = FZ.toGfm(ed.doc, { fz: true });
  if (!sc.tree) { try { const off = sc.range ? sc.range[0] : 0; const rec = FZ.convAudit(sc.range ? sliceDoc(sc.range[0], sc.range[1]) : ed.doc, 'md'); for (const it of rec.items) it.lines = it.lines.map(i => i + off); rec.title = 'AI に写した Markdown（' + what.replace(/（.*$/, '') + '）'; setConvLog(rec); } catch (e) { /* 記録が作れなくても写す */ } }
  rememberScope(idx, what.replace(/（.*$/, ''));
  const ok = await copyText(md); msg(ok ? `${what}を Markdown で写しました（${md.length.toLocaleString()} 字）：AI の入力欄に貼り付けてください` : `写せませんでした（${K('exportMd')} で Markdown ファイルに）`, !ok, 7000); return ok; }
function sliceDoc(a, b) { const d = ed.doc; const sub = { ...d, lines: d.lines.slice(a, b + 1).map(l => JSON.parse(JSON.stringify(l))), rules: [], fills: [], images: d.images, refs: d.refs, _nums: FZ.figureNumbers(d) };
  { const ordOf = lines => { const c = [], out = []; for (const ln of lines) { const at = ln.attrs; if (at.style === 'title') c.length = 0; if (at.style !== 'num') { out.push(0); continue; } const lv = Math.min(7, at.level | 0); if (at.restart) c[lv] = (typeof at.restart === 'number' ? at.restart : 1) - 1; c.length = lv + 1; c[lv] = (c[lv] || 0) + 1; out.push(c[lv]); } return out; };
    const full = ordOf(d.lines.slice(0, b + 1)), c = []; sub.lines.forEach((ln, k) => { const at = ln.attrs; if (at.style === 'title') c.length = 0; if (at.style !== 'num') return; const lv = Math.min(7, at.level | 0); if (at.restart) c[lv] = (typeof at.restart === 'number' ? at.restart : 1) - 1; c.length = lv + 1; let v = (c[lv] || 0) + 1; const want = full[a + k]; if (v !== want) { at.restart = want > 1 ? want : true; v = want; } c[lv] = v; }); } /* 節だけ写しても見出しの番号は文書のまま（2 番目の節は「2.」） */
  for (const r of d.rules) { if (r.axis === 'h' && r.line >= a && r.line <= b + 1) sub.rules.push({ ...r, line: r.line - a }); else if (r.axis === 'v' && r.from >= a && r.to <= b) sub.rules.push({ ...r, from: r.from - a, to: r.to - a }); }
  for (const f of d.fills) if (f.from >= a && f.to <= b) sub.fills.push({ ...f, from: f.from - a, to: f.to - a }); const r = FZ.normalize(sub); r._nums = sub._nums; return r; } /* 範囲の外の節・図への参照も文書全体の番号で */
function treeCopyNodes() { const sel = treeSelected(); const ns = (sel.length ? sel : [treeNodeSel()]).filter(Boolean).sort((p, q) => p.line - q.line); return ns.filter(n => !ns.some(m => m !== n && FZ.tree.isAncestor(m, n))); }
function treeCopyIdx() { const ns = treeCopyNodes(); if (!ns.length || ns.some(n => n.root)) return null; const set = new Set(); for (const n of ns) { const a = ed.doc.lines.indexOf(n.obj); if (a < 0) continue; const b = n.kind === 'sent' ? a : a + (n.end - n.line); for (let k = a; k <= b; k++) set.add(k); } return set.size ? [...set].sort((x, y) => x - y) : null; }
function treeCopyText() { const sel = treeSelected(); if (sel.length && sel.every(n => n.kind === 'sent')) return sel.map(n => n.text).join(''); const ns = (sel.length ? sel : [treeNodeSel()]).filter(Boolean).sort((p, q) => p.line - q.line); const parts = []; for (const n of ns) { if (ns.some(m => m !== n && FZ.tree.isAncestor(m, n))) continue; parts.push(n.root ? FZ.toGfm(ed.doc, { fz: true }) : FZ.toGfm(sliceDoc(n.line, n.end), { fz: true })); } return parts.join('\n'); }
function treePaste(text) {
  const n = treeNodeSel(); if (!n || !text.trim()) return; if (n.kind === 'body' || n.kind === 'block') { msg('本文・表・図の節には貼れません。見出しか項目を選んでください', true); return; }
  let sub; try { const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(ed.doc.format)); sub = FZ.fromGfm(text, base); } catch (e) { msg('貼れませんでした：' + e.message, true); return; }
  const lines = sub.lines.filter((l, k, arr) => !(k === arr.length - 1 && !l.segs.some(s => s.text))); if (!lines.length) return; let firstObj = null;
  ed.mutate('', () => { const at = n.root ? ed.doc.lines.length : n.end + 1; lines.forEach((l, k) => FZ.tree.insertAt(ed, at + k, l)); for (const r of sub.rules) { if (r.axis === 'h') ed.doc.rules.push({ ...r, id: FZ.uid(), line: r.line + at }); else ed.doc.rules.push({ ...r, id: FZ.uid(), from: r.from + at, to: r.to + at }); } for (const f of sub.fills) ed.doc.fills.push({ ...f, id: FZ.uid(), from: f.from + at, to: f.to + at });
    const lvs = lines.map(l => ed.outlineLevel(l.attrs)); const min = Math.min(...lvs.filter(x => x < 99)); firstObj = lines[0];
    const t = (min >= 17 && n.kind !== 'list') ? { kind: 'list', level: 0 } : (FZ.tree.childType(n) || { kind: 'list', level: 0 }); // 箇条書きは見出しの下でも箇条書きのまま
    if (min < 99) for (let k = 0; k < lines.length; k++) { if (lvs[k] !== min) continue; let e2 = k; while (e2 + 1 < lines.length && !(lvs[e2 + 1] <= min)) e2++; const a0 = ed.doc.lines.indexOf(lines[k]); FZ.tree.retype(ed, a0, a0 + (e2 - k), t); } });
  st.tree.folds.delete(treeKey(n)); st.tree.sel = firstObj; treeRefresh(); msg(`${lines.length} 行を「${(n.text || '').slice(0, 12)}」の子として貼りました（Ctrl+Z で戻す）`);
}
/* マウス */
function treePt(e) { const svg = treeEl.querySelector('svg'); if (!svg) return null; const r = svg.getBoundingClientRect(); const SC = st.tree.scale; return { x: (e.clientX - r.left) / SC, y: (e.clientY - r.top) / SC }; }
function treeHit(pt, pad = 0) { const v = st.tree.view; if (!v) return -1; for (let i = v.shown.length - 1; i >= 0; i--) { const p = v.pos.get(v.shown[i]); const x = v.M + p.x, y = v.M + p.y; if (pt.x >= x - pad && pt.x <= x + p.w + pad && pt.y >= y - pad && pt.y <= y + p.h + pad) return i; } return -1; }
function treeDropAt(pt, movers) {
  const v = st.tree.view; const h = st.tree.dir !== 'v'; const gap = st.tree.dir === 'i' ? 2 : 6; const i = treeHit(pt, gap); if (i < 0) return null; const t = v.shown[i]; if (movers.length && movers[0].kind === 'sent') { const m0 = movers[0]; if (t === m0) return null; if (t.kind === 'sent') { const p = v.pos.get(t); return { node: t, rel: (pt.y - (v.M + p.y)) / p.h < 0.5 ? 'before' : 'after' }; } if (t.kind === 'body' && t.obj && t.obj.segs.length === 1) return { node: t, rel: 'child' }; return null; } movers = movers.filter(m => m.kind !== 'fig'); if (!movers.length || t.kind === 'fig' || movers.some(m => m === t || FZ.tree.isAncestor(m, t))) return null;
  const p = v.pos.get(t); const x = v.M + p.x, y = v.M + p.y; const along = h ? (pt.y - y) / p.h : (pt.x - x) / p.w; const across = h ? (pt.x - x) / p.w : (pt.y - y) / p.h;
  const canChild = t.kind !== 'body' && t.kind !== 'block' && FZ.tree.childType(t); const isTop = t === v.top || t.root;
  let rel = across > 0.66 && canChild ? 'child' : along < 0.3 ? 'before' : along > 0.7 ? 'after' : (canChild ? 'child' : along < 0.5 ? 'before' : 'after'); if (isTop) rel = canChild ? 'child' : null; if (!rel) return null; return { node: t, rel };
}
let tdrag = null;
treeEl.addEventListener('pointerdown', e => {
  if (e.button !== 0) return; if (st.mode !== 'tree' && st.view === 'split') enterTree(); /* 並べる：ツリーを押すとツリーへ */ const pt = treePt(e); if (!pt) return; e.preventDefault(); if (st.tree.edit) closeTreeEdit(true); if (st.form) closeForm(); if (st.armed) disarm(); const clicks = clickCount(e); const v = st.tree.view;
  const shw = e.target.closest('[data-show]'); if (shw) { const n = v.shown[+shw.dataset.show]; if (n) { const k = treeShowKey(n); if (st.tree.show.has(k)) st.tree.show.delete(k); else st.tree.show.add(k); st.tree.showAll = false; st.tree.sel = treeKey(n); render(); drawSub(); status(); treeScrollToSel(); } focusTA(); return; } // 図表の中身を見せる・閉じる
  const add = e.target.closest('[data-add]'); if (add && st.tree.hover != null) { const n = v.shown[st.tree.hover]; st.tree.sel = treeKey(n); treeAdd(add.dataset.add, n); return; }
  const fold = e.target.closest('[data-fold]'); if (fold) { const n = v.shown[+fold.dataset.fold]; st.tree.folds.delete(treeKey(n)); if (st.tree.depth > 0 && n.depth - v.top.depth >= st.tree.depth) { st.tree.depth = Math.min(9, n.depth - v.top.depth + 1); } render(); drawSub(); focusTA(); return; }
  const i = treeHit(pt);
  if (i >= 0) { const n = v.shown[i]; const key = treeKey(n);
    if (e.shiftKey) { if (st.tree.multi.has(key)) st.tree.multi.delete(key); else { st.tree.multi.add(key); if (st.tree.sel) st.tree.multi.add(st.tree.sel); } st.tree.sel = key; render(); drawSub(); status(); focusTA(); return; }
    if (!st.tree.multi.has(key)) st.tree.multi.clear(); st.tree.sel = key; render(); drawSub(); status();
    if (clicks >= 2) { const p = v.pos.get(n), inf = v.info.get(n); const inBody = inf && inf.fig && pt.y > v.M + p.y + inf.lines.length * TREE_LH + 4; if (treeShowable(n) && (n.kind !== 'fig' || inBody)) { treeOpenObject(n); return; } openTreeEdit(false); return; } // 図表の中身・表・流れ図：紙面のその場で直す
    if (n.kind === 'fig') { focusTA(); return; } // 図表はドラッグで動かさない（付いている行と動く）
    tdrag = { id: e.pointerId, kind: 'node', sx: pt.x, sy: pt.y, moved: false }; treeEl.setPointerCapture(e.pointerId); focusTA(); return; }
  if (!e.shiftKey) st.tree.multi.clear(); st.tree.band = { x1: pt.x, y1: pt.y, x2: pt.x, y2: pt.y, base: new Set(st.tree.multi) }; tdrag = { id: e.pointerId, kind: 'band' }; treeEl.setPointerCapture(e.pointerId); render(); focusTA();
});
treeEl.addEventListener('pointermove', e => {
  const pt = treePt(e); if (!pt) return; const v = st.tree.view; if (!v) return;
  if (!tdrag || tdrag.id !== e.pointerId) { if (e.buttons) return;
    if (e.target.closest('[data-add]')) { treeEl.style.cursor = 'pointer'; return; } // ＋の上：寄せている節を替えない（下の＋は次の行に重なる）
    let i = null; if (st.tree.hover != null && v.shown[st.tree.hover]) { const p = v.pos.get(v.shown[st.tree.hover]); if (p && pt.x >= v.M + p.x - 4 && pt.x <= v.M + p.x + p.w + 24 && pt.y >= v.M + p.y - 4 && pt.y <= v.M + p.y + p.h + 13) i = st.tree.hover; } // 今の節と＋の届く所にいる間は今の節のまま
    if (i == null) { const h2 = treeHit(pt, 6); i = h2 >= 0 ? h2 : null; }
    if (i !== st.tree.hover) { st.tree.hover = i; renderTreeOverlay(); } treeEl.style.cursor = e.target.closest('[data-fold]') ? 'pointer' : treeHit(pt) >= 0 ? 'grab' : ''; return; }
  if (tdrag.kind === 'node') { if (!tdrag.moved && Math.hypot(pt.x - tdrag.sx, pt.y - tdrag.sy) < 6) return; tdrag.moved = true; treeEl.style.cursor = 'grabbing'; st.tree.drop = treeDropAt(pt, treeSelected()); renderTreeOverlay(); return; }
  if (tdrag.kind === 'band') { const b = st.tree.band; b.x2 = pt.x; b.y2 = pt.y; const x1 = Math.min(b.x1, b.x2), x2 = Math.max(b.x1, b.x2), y1 = Math.min(b.y1, b.y2), y2 = Math.max(b.y1, b.y2); const keys = new Set(b.base);
    for (const n of v.shown) { const p = v.pos.get(n); const nx = v.M + p.x, ny = v.M + p.y; if (nx < x2 && nx + p.w > x1 && ny < y2 && ny + p.h > y1) keys.add(treeKey(n)); } st.tree.multi = keys; if (keys.size) st.tree.sel = [...keys][keys.size - 1]; render(); }
});
treeEl.addEventListener('pointerup', e => {
  if (!tdrag || tdrag.id !== e.pointerId) return; const d = tdrag; tdrag = null; treeEl.style.cursor = '';
  if (d.kind === 'node' && d.moved) { const drop = st.tree.drop; st.tree.drop = null; if (drop) { const sel0 = treeNodeSel(); if (sel0 && sel0.kind === 'sent') { treeDropSent(sel0, drop); focusTA(); return; } const list = treeSelected().filter(n => !n.root && n.kind !== 'fig' && n.kind !== 'sent'); const key = st.tree.sel; let ok = false; ed.mutate('', () => { ok = FZ.tree.move(ed, st.tree.view.tr, list, drop.node, drop.rel); }); if (!ok) { ed.undoStack.pop(); msg('そこへは動かせません', true); } else { if (drop.rel === 'child') st.tree.folds.delete(treeKey(drop.node)); msg(`${list.length} 個の節を動かしました（Ctrl+Z で戻す）`); } st.tree.sel = key; treeRefresh(); } else renderTreeOverlay(); }
  if (d.kind === 'band') { st.tree.band = null; render(); drawSub(); status(); }
  focusTA();
});
treeEl.addEventListener('pointerleave', () => { if (!tdrag && st.tree.hover != null) { st.tree.hover = null; renderTreeOverlay(); } });
treeEl.addEventListener('contextmenu', e => { e.preventDefault(); const pt = treePt(e); const i = pt ? treeHit(pt) : -1; if (i >= 0) { const n = st.tree.view.shown[i]; if (!st.tree.multi.has(treeKey(n))) { st.tree.multi.clear(); st.tree.sel = treeKey(n); } render(); drawSub(); status(); } msg('上の帯で、選んだ節を足す・動かす・種類を変えられます'); focusTA(); });
/* ================= 表：列の境のドラッグ・セルの範囲 ================= */
/* 位置 g が表の列の境（縦罫）の近くなら { I, k, line } */
function tableEdgeAt(g) {
  const p = ed.lay.pages[g.page]; if (!p) return null; const es = p.rowmap.get(Math.floor(g.row)); const e = es && es.find(x => x.cell); if (!e) return null;
  const I = FZ.tbl.info(ed, e.line); if (!I) return null; let k = -1, bd = 0.32; I.B.forEach((c, q) => { const dd = Math.abs(g.col - c); if (dd < bd) { bd = dd; k = q; } }); return k < 0 ? null : { I, k, line: e.line };
}
/* 表の行の y の範囲（そのページ） */
/* 1.0.12a 表のつまみ：カーソルのある表の左上（表の左の外、1 行目の高さ） */
function tableGrip() { if (st.mode !== 'text' || inl) return null; const xy = ed.xy(); if (!xy) return null; let I = FZ.tbl.info(ed), box = false; if (!I) { const A = boxAtCaret(); if (!A) return null; I = { a: A.a, b: A.b, L: A.L, R: A.R, A }; box = true; } /* 1.0.12c 囲みにも同じつまみ */
  const rows = tableRowsOn(I, xy.page); if (!rows) return null; const h = Math.min(0.9, rows.y2 - rows.y1); return { I, box, page: xy.page, rows, col: I.L - 1.15, y: rows.y1 + 0.05, w: 0.85, h: h - 0.1 }; }
/* 1.0.12c 区画の境（隣り合う区画の間の縦罫）：つかんで列の幅の比を変える */
function panelEdgeAt(g) { const p = ed.lay.pages[g.page]; const PG = ed.lay.panelGroups; if (!p || !PG) return null; for (const v of p.vrules) { if (!v.deco || g.row < v.y1 || g.row > v.y2 || Math.abs(g.col - v.col) > 0.35) continue; const m = /^pnl(\d+):\d+:v/.exec(v.id || ''); if (!m) continue; const gl = +m[1], G = PG.get(gl); if (!G || G.n < 2) continue;
    for (let c = 1; c < G.n; c++) if (Math.abs(G.edges[c] - v.col) < 1e-6 || Math.abs(G.edges[c] - G.GAP - v.col) < 1e-6) return { g: gl, c, G, y1: v.y1, y2: v.y2, page: g.page }; } return null; }
function panelRatioSet(gl, G, c, x) { const e = G.edges.slice(); e[c] = x; const w = e.slice(1).map((v, j) => Math.round((v - e[j]) * 2) / 2); const at = ed.doc.lines[gl] && ed.doc.lines[gl].attrs; if (!at) return false; ed.mutate('', () => { if (w.every(v => Math.abs(v - w[0]) < 0.6)) delete at.panelRatio; else at.panelRatio = w; }); return true; }
function boxAtCaret() { return FZ.articleAround && !FZ.inTable(ed.doc, ed.caret.line) ? FZ.articleAround(ed.doc, ed.caret.line) : null; }
/* 1.0.12c 囲みの左右の罫：つかんで幅を変える */
function boxEdgeAt(g) { const p = ed.lay.pages[g.page]; if (!p || !FZ.articleAround) return null; const es = p.rowmap.get(Math.floor(g.row)); const e = es && es.find(x => !x.cell && x.line >= 0); if (!e) return null; const A = FZ.articleAround(ed.doc, e.line); if (!A) return null; const dl = Math.abs(g.col - A.L), dr = Math.abs(g.col - A.R); if (Math.min(dl, dr) > 0.32) return null; return { A, side: dl <= dr ? 'L' : 'R', line: e.line }; }
function tableGripAt(g) { const t = tableGrip(); return t && g.page === t.page && g.col >= t.col - 0.15 && g.col <= t.col + t.w + 0.15 && g.row >= t.y - 0.15 && g.row <= t.y + t.h + 0.15 ? t : null; }
function tableRowsOn(I, page) { let y1 = Infinity, y2 = -Infinity; for (let i = I.a; i <= I.b; i++) { const lm = ed.lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) if (r.page === page) { y1 = Math.min(y1, r.y); y2 = Math.max(y2, r.y + r.h); } } return y1 <= y2 ? { y1, y2 } : null; }
/* カーソル位置のセル { line, col }（表の外なら null） */
function cellOfPos(p) { if (!p || !FZ.inTable(ed.doc, p.line)) return null; const I = FZ.tbl.info(ed, p.line); if (!I) return null; const s = ed.doc.lines[p.line].segs[p.seg]; if (!s) return null; let j = I.B.findIndex(c => Math.abs(c - s.col) < 1e-6); if (j < 0) j = I.B.filter(c => c <= s.col).length - 1; return { line: p.line, col: clamp(j, 0, I.n - 1), a: I.a }; }
/* 表の操作の対象：選んだセルの範囲、無ければカーソルのセル */
function cellRect() { if (st.cells) { const R = FZ.tbl.rectOf(ed, st.cells.a, st.cells.b); if (R) return R; } const c = cellOfPos(ed.caret); return c ? FZ.tbl.rectOf(ed, c, c) : null; }
function cellRects() {
  const R = st.cells && FZ.tbl.rectOf(ed, st.cells.a, st.cells.b); if (!R) return []; const out = []; const B = R.I.B;
  for (let i = R.la; i <= R.lb; i++) { const lm = ed.lay.lineMap[i]; if (!lm) continue; for (const r of lm.rows) out.push({ page: r.page, y: r.y, h: r.h, col: B[R.ca], w: B[R.cb + 1] - B[R.ca] }); }
  return out;
}
/* ================= マウス ================= */
let drag = null;
function eventToGrid(e) { // ポインタキャプチャ中でも座標から対象ページを求める
  if (!wraps.length) return null; const rm = main.getBoundingClientRect(); const yAbs = e.clientY - rm.top + main.scrollTop, xAbs = e.clientX - rm.left + main.scrollLeft;
  if (geomDirty) measurePages(); let p = 0; for (let i = 0; i < pageGeom.length; i++) { const g = pageGeom[i]; if (yAbs >= g.top - 6) p = i; if (yAbs < g.top + g.height + 6) break; }
  const g = pageGeom[p]; if (!g) return null; const scale = g.width / ed.lay.geo.W; const geo = ed.lay.geo;
  const xpt = (xAbs - g.left) / scale, ypt = (yAbs - g.top) / scale; return { page: p, col: (xpt - geo.left) / geo.cw, row: (ypt - geo.top) / geo.ch - geo.bodyTop };
}
/* 本文のクリック位置 → 論理位置（柱・ページの外・文末より後ろも） */
function posFromGrid(g) {
  const geo = ed.lay.geo; const y = Math.floor(g.row); const col = half(clamp(g.col, 0, geo.cols)); const hy = ed.lay.headY;
  if (y < 0 && hy != null && g.row >= hy && g.row < hy + geo.headerRows && ed.lay.pages[g.page] && ed.lay.pages[g.page].rowmap.has(hy)) return FZ.xyToPos(ed.lay, g.page, hy, col); // 柱の表題
  if (y < 0) return { line: 0, seg: 0, off: 0 };
  if (y >= geo.rows) return 'end';
  const pos = FZ.xyToPos(ed.lay, g.page, y, col); if (pos) return pos;
  const end = ed.lay.endPos; if (g.page === end.page && y >= end.y && (!geo.cols2 || (end.x0 || 0) === (col >= geo.colX2 - 0.5 ? geo.colX2 : 0))) { const ll = ed.doc.lines.length - 1; const ln = ed.doc.lines[ll]; return { line: ll, seg: ln.segs.length - 1, off: ln.segs[ln.segs.length - 1].text.length, vrow: y - end.y + 1, vcol: col }; }
  const f = ed.findRow(g.page, y, -1, col) || ed.findRow(g.page, y, 1, col); return f ? FZ.xyToPos(ed.lay, f.page, f.y, col) : null;
}
function setCaretFromGrid(g, extend) { const pos = posFromGrid(g); if (pos === 'end') ed.docEnd(extend); else if (pos) ed.setCaret(pos, extend); }
/* 押した回数（ダブル・トリプルクリック）。pointerdown の detail は Chromium では 0 なので自分で数える */
let lastDown = { t: -1e9, x: 0, y: 0, n: 0 };
function clickCount(e) { const now = e.timeStamp || performance.now(); const near = Math.abs(e.clientX - lastDown.x) < 5 && Math.abs(e.clientY - lastDown.y) < 5; const n = now - lastDown.t < 450 && near ? lastDown.n + 1 : 1; lastDown = { t: now, x: e.clientX, y: e.clientY, n }; return n; }
pagesEl.addEventListener('pointerdown', e => {
  if (st.mode === 'tree' && st.view === 'split') exitTree(false); // 並べる：紙面を押すと紙面へ
  if (e.button !== 0) return; const g = eventToGrid(e); if (!g) return; e.preventDefault(); const clicks = clickCount(e);
  if (st.mode === 'text' && !e.shiftKey && !e.ctrlKey && clicks === 1 && ganttPointerDown(e, g)) return; /* 工程表の矢羽根の端・本体・◆ をつかむ */
  if (inl) closeInline(true);
  if (st.form) closeForm(); if (st.armed) disarm();
  const geo = ed.lay.geo;
  if (st.mode === 'fig') { // 図の外をクリック：本文に戻ってそこにカーソル（別の図ならその図へ）
    const fi = figInfo(); const fpt = fi && fi.parts.find(p => p.page === g.page); const inFig = fpt && g.col >= fi.left - 1.2 && g.col <= fi.right + 1.2 && ((g.row >= fpt.y0 - 0.6 && g.row < fpt.y0 + fpt.f1 - fpt.f0) || figWhat(fi, { x: g.col - fi.left, y: g.row - fpt.y0 + fpt.f0 }).t === 'height');
    if (inFig) { figPointerDown(e, g, clicks); return; } exitFigMode();
  }
  if (st.mode === 'text' && !st.composing && figRowAt(g) != null) { enterFigMode(figRowAt(g), null); figPointerDown(e, g, clicks); return; }
  if (st.mode === 'text') {
    if (st.composing) return;
    const tg = !e.shiftKey && tableGripAt(g); if (tg) { drag = { kind: 'tmove', id: e.pointerId, I: tg.I, box: tg.box, page: tg.page, rows: tg.rows, sx: g.col, sy: g.row, dx: 0, dy: 0 }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); return; } /* 1.0.12a 表の左上のつまみ：表を動かす */
    const te = !e.shiftKey && tableEdgeAt(g); if (te && clicks === 2) { const j = Math.max(0, Math.min(te.I.n - 1, te.k - 1)); if (FZ.tbl.fit(ed, te.I, j, j, tableW())) msg('列の幅を字に合わせました（' + K('undo') + ' で戻す）'); drag = null; render(); return; } /* 列の線のダブルクリック：左の列を字に合わせる */
    const pe = !te && !e.shiftKey && panelEdgeAt(g); if (pe) { drag = { kind: 'pedge', id: e.pointerId, ...pe, x: pe.G.edges[pe.c] }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); return; } /* 1.0.12c 区画の境 */
    const be = !te && !e.shiftKey && boxEdgeAt(g); if (be) { drag = { kind: 'bedge', id: e.pointerId, A: be.A, side: be.side, x: be.side === 'L' ? be.A.L : be.A.R, page: g.page, rows: tableRowsOn({ a: be.A.a, b: be.A.b }, g.page) }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); return; } /* 1.0.12c 囲みの左右の罫をつかむ */
    if (te) { const rows = tableRowsOn(te.I, g.page); st.cells = null; drag = { kind: 'tcol', id: e.pointerId, I: te.I, k: te.k, x: te.I.B[te.k], page: g.page, rows }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); return; }
    const fh = !e.shiftKey && figHit(g); if (fh) { st.figSel = fh.id; openForm(fh.chart ? 'chart' : 'fig'); return; } // 図版をクリック：図表の設定
    const prevCell = e.shiftKey ? (st.cells ? st.cells.a : cellOfPos(ed.caret)) : null;
    st.cells = null; setCaretFromGrid(g, e.shiftKey);
    if (prevCell) { const c2 = cellOfPos(ed.caret); if (c2 && c2.a === prevCell.a && (c2.line !== prevCell.line || c2.col !== prevCell.col)) { st.cells = { a: prevCell, b: c2 }; ed.anchor = null; ed.onCaret(); } } // Shift+クリック：表の中ならセルの範囲
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey) { const lk = FZ.linkAt(ed.seg(), ed.caret.off) || FZ.linkAt(ed.seg(), ed.caret.off - 1); if (lk) { openUrl(lk.url); return; } if (selectSentence()) { focusTA(); return; } } // Ctrl+クリック：リンクは開く、それ以外は文を選ぶ
    drag = { kind: 'sel', id: e.pointerId, cell: st.cells ? st.cells.a : cellOfPos(ed.caret) }; pagesEl.setPointerCapture(e.pointerId); focusTA(); syncTA();
    if (clicks === 2) ed.selectWord(); if (clicks >= 3) ed.selectLine();
  } else {
    const rc = { page: g.page, y: clamp(Math.round(g.row), 0, geo.rows), col: clamp(Math.round(g.col), 0, geo.cols) }; st.rc = rc; st.ranchor = { ...rc }; drag = { kind: 'rule', id: e.pointerId }; pagesEl.setPointerCapture(e.pointerId); requestOverlay(); focusTA();
  }
});
pagesEl.addEventListener('pointermove', e => {
  if (!drag || drag.id !== e.pointerId) { if (e.buttons) return; const g = eventToGrid(e); if (!g) return; let cur = ''; if (st.mode === 'fig' && st.fig) cur = figHover(g); else if (st.mode === 'text' && !inl) cur = tableGripAt(g) ? 'move' : tableEdgeAt(g) || boxEdgeAt(g) || panelEdgeAt(g) ? 'col-resize' : ''; if (pagesEl.style.cursor !== cur) pagesEl.style.cursor = cur; return; }
  const g = eventToGrid(e); if (!g) return; const geo = ed.lay.geo;
  if (drag.kind.startsWith('fig')) { figDragMove(g); return; }
  if (drag.kind === 'tmove') { const W = tableW(); const dx = clamp(half(g.col - drag.sx), -drag.I.L, W - drag.I.R), dy = Math.round(g.row - drag.sy); if (dx !== drag.dx || dy !== drag.dy) { drag.dx = dx; drag.dy = dy; requestOverlay(); } return; }
  if (drag.kind === 'pedge') { const G = drag.G, c = drag.c; const x = clamp(half(g.col), G.edges[c - 1] + 6, G.edges[c + 1] - 6); if (x !== drag.x) { drag.x = x; requestOverlay(); } return; }
  if (drag.kind === 'bedge') { const W = tableW(); const x = drag.side === 'L' ? clamp(half(g.col), 0, drag.A.R - 6) : clamp(half(g.col), drag.A.L + 6, W); if (x !== drag.x) { drag.x = x; requestOverlay(); } return; }
  if (drag.kind === 'tcol') { const [lo, hi] = FZ.tbl.boundaryRange(ed, drag.I, drag.k); const x = clamp(half(g.col), lo, hi); if (x !== drag.x) { drag.x = x; requestOverlay(); } return; }
  if (drag.kind === 'sel') { if (st.composing) return; const y = clamp(Math.floor(g.row), 0, geo.rows - 1); const col = half(clamp(g.col, 0, geo.cols)); const f = ed.findRow(g.page, y, -1) || ed.findRow(g.page, y, 1); if (!f) return; const pos = FZ.xyToPos(ed.lay, f.page, f.y, col); if (!pos) return;
    const c2 = drag.cell ? cellOfPos(pos) : null; // 表の中で別のセルへ：セルの範囲を選ぶ
    if (c2 && c2.a === drag.cell.a && (c2.line !== drag.cell.line || c2.col !== drag.cell.col)) { st.cells = { a: drag.cell, b: c2 }; ed.anchor = null; ed.setCaret({ ...pos, vcol: null }); return; }
    if (st.cells && c2 && c2.line === drag.cell.line && c2.col === drag.cell.col) { st.cells = null; requestOverlay(); }
    ed.setCaret({ ...pos, vcol: null }, true); }
  else { const rc = { page: st.ranchor.page, y: clamp(Math.round(g.row), 0, geo.rows), col: clamp(Math.round(g.col), 0, geo.cols) }; st.rc = rc; const a = st.ranchor; if (st.mode === 'rule' && st.sub !== 'rect') { const horiz = Math.abs(rc.col - a.col) >= Math.abs(rc.y - a.y); st.preview = horiz ? { page: rc.page, c1: Math.min(a.col, rc.col), r1: a.y, c2: Math.max(a.col, rc.col), r2: a.y } : { page: rc.page, c1: a.col, r1: Math.min(a.y, rc.y), c2: a.col, r2: Math.max(a.y, rc.y) }; } requestOverlay(); }
});
pagesEl.addEventListener('pointerup', e => {
  if (!drag || drag.id !== e.pointerId) return; const d = drag; drag = null;
  if (d.kind.startsWith('fig')) { figDragEnd(d); return; }
  if (d.kind === 'pedge') { if (d.x !== d.G.edges[d.c] && panelRatioSet(d.g, d.G, d.c, d.x)) msg('区画の幅を変えました（' + K('undo') + ' で戻す。区画の欄で比を入れても変えられる）'); render(); focusTA(); return; }
  if (d.kind === 'bedge') { const ok = FZ.boxSet(ed, d.A, d.side === 'L' ? d.x : d.A.L, d.side === 'R' ? d.x : d.A.R); if (ok) msg('囲みの幅を変えました（' + K('undo') + ' で戻す）'); render(); focusTA(); return; }
  if (d.kind === 'tmove' && d.box) { const n0 = ed.undoStack.length; let moved = false; const A = d.I.A; if (d.dx) moved = FZ.boxSet(ed, A, A.L + d.dx, A.R + d.dx) || moved; if (d.dy) { const A2 = FZ.articleAround(ed.doc, A.a) || A; moved = FZ.tbl.shiftV(ed, { a: A2.a, b: A2.b }, d.dy) || moved; } if (ed.undoStack.length > n0 + 1) ed.undoStack.length = n0 + 1; if (moved) msg('囲みを動かしました（' + K('undo') + ' で戻す）'); else if (d.dy < 0) msg('上に詰める空行がありません', true); render(); focusTA(); return; }
  if (d.kind === 'tmove') { const n0 = ed.undoStack.length; let moved = false; if (d.dx) moved = FZ.tbl.shift(ed, d.I, d.dx, tableW()) || moved; if (d.dy) { const I2 = FZ.tbl.info(ed, d.I.a + 0) || d.I; moved = FZ.tbl.shiftV(ed, I2, d.dy) || moved; } if (ed.undoStack.length > n0 + 1) ed.undoStack.length = n0 + 1; if (moved) msg('表を動かしました（' + K('undo') + ' で戻す）'); else if (d.dy < 0) msg('上に詰める空行がありません', true); render(); focusTA(); return; }
  if (d.kind === 'tcol') { if (d.x !== d.I.B[d.k]) { FZ.tbl.moveBoundary(ed, d.I, d.k, d.x); msg('列の幅を変えました（Ctrl+Z で戻す）'); } requestOverlay(); focusTA(); return; }
  if (d.kind === 'rule') { const a = st.ranchor, b = st.rc; st.preview = null;
    if (st.mode === 'fill') { if (a.y !== b.y || a.col !== b.col) applyFill(); else { st.ranchor = null; requestOverlay(); } return; }
    if (st.sub === 'rect') { if (a.y !== b.y || a.col !== b.col) applyRect(); else { st.ranchor = null; requestOverlay(); } return; }
    const horiz = Math.abs(b.col - a.col) >= Math.abs(b.y - a.y); const erase = st.sub === 'erase';
    if (horiz && b.col !== a.col) hSeg(a.page, a.y, Math.min(a.col, b.col), Math.max(a.col, b.col), erase, b.col > a.col ? 'r' : 'l');
    else if (!horiz && b.y !== a.y) { const y1 = Math.min(a.y, b.y), y2 = Math.max(a.y, b.y); ed.mutate('', () => { ensureRows(a.page, y2 - 1); const vf = ed.vAnchorAt(a.page, y1), vt = ed.vAnchorAt(a.page, y2 - 1); if (vf == null || vt == null) return; if (erase) ed.eraseV(vf, vt, a.col); else ed.addVRule(vf, vt, a.col, st.ruleKind, b.y > a.y ? 'd' : 'u'); }); }
    st.ranchor = null; requestRender(); }
  else { if (st.cells) { drawSub(); status(); } focusTA(); }
});
pagesEl.addEventListener('pointerleave', () => { if (!drag && st.fig && st.fig.hover != null) { st.fig.hover = null; requestOverlay(); } });
/* 右クリック：帯をその場の操作に切り替える（ポップアップは出さない）。表＝表の編集、選んだ字＝文字、図＝図の帯、ほか＝段落 */
pagesEl.addEventListener('contextmenu', e => {
  e.preventDefault(); const g = eventToGrid(e); if (!g) return; if (inl) closeInline(true); if (st.form) closeForm();
  const fl = figRowAt(g);
  if (st.mode === 'fig' || (st.mode === 'text' && fl != null)) {
    if (st.mode !== 'fig') { if (fl == null) return; enterFigMode(fl, null); } const loc = figLocal(g); if (!loc) return; const w = figWhat(loc.fi, loc);
    if (w.t === 'box' && !figIds().includes(w.box.id)) figSelect(w.box.id, false); else if (w.t === 'arrow') { figSetSel([]); st.fig.selArrow = w.k; }
    figRefresh(); msg('上の帯で、選んだ箱の線・網・揃えを変えられます'); return;
  }
  if (st.mode !== 'text' || st.composing) return;
  const inSel = ed.sel() && selectionRects().some(r => r.page === g.page && g.row >= r.y && g.row < r.y + r.h && g.col >= r.col - 0.3 && g.col <= r.col + r.w + 0.3);
  const inCells = st.cells && cellRects().some(r => r.page === g.page && g.row >= r.y && g.row < r.y + r.h && g.col >= r.col && g.col <= r.col + r.w);
  if (!inSel && !inCells) { st.cells = null; setCaretFromGrid(g, false); }
  const grp = FZ.inTable(ed.doc, ed.caret.line) ? 'tedit' : ed.sel() && !sentSelOk() ? 'marks' : 'struct'; /* 右クリック：表の中は表の編集、文字を選んでいれば文字、それ以外は構造 */
  st.group = grp; st.armed = false; drawSub(); drawFkeys(); requestOverlay(); focusTA();
});
main.addEventListener('pointerdown', e => { if (e.target === main || e.target === pagesEl) { if (st.form) closeForm(); if (st.armed) disarm(); focusTA(); } });
main.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); if (st.view === 'tree') treeZoom(e.deltaY < 0 ? 1 : -1); else pageZoomStep(e.deltaY < 0 ? 1 : -1); } }, { passive: false });
tpane.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); treeZoom(e.deltaY < 0 ? 1 : -1); } }, { passive: false });
/* ================= コマンド ================= */
const CMDS = [];
const cmd = (id, label, group, keys, fn, kw = '') => CMDS.push({ id, label, group, keys, fn, kw });
cmd('editGroup', '編集メニュー（元に戻す・検索置換・整える）', '編集', '', () => toggleGroup('edit'));
cmd('insertGroup', '挿入メニュー（画像・図表・図・表・区切り線・囲み記事・目次）', '挿入', '', () => toggleGroup('insert'));
cmd('tableMenu', '表のメニュー（作る・行と列・セルの網と揃え・様式）', '表', '', () => toggleGroup('tedit'));
cmd('fmtGroup', '書式メニュー（用紙・文字数・体系・資料の柱・書体）', '書式', '', () => toggleGroup('fmt'));
cmd('viewGroup', '表示メニュー（倍率・グリッド・ツリー・コマンド一覧）', '表示', '', () => toggleGroup('view'));
cmd('slideHead', '資料の柱と欄…（本文欄の幅・仕切り・柱の題・機密表示・作成日・作成者・頁番号・表紙・表紙の型・開始番号）', '書式', '', () => { if (ed.doc.format.kind !== 'slide') { msg('資料書式の文書で使えます（新しい資料は ' + K('new') + ' → S、今の文書を資料にするには ' + K('format') + ' の「書式の種類」）', true); return; } openForm('slide'); }, '資料 柱 ヘッダ 機密 作成者 頁番号');
cmd('help', 'ガイド（やりたいこと別の操作と近道）', '説明', '', () => toggleSide('help'), '取説 ヘルプ 使い方');
cmd('manual', '取扱説明書を文書で開く（全機能を詳しく。別の窓）', '説明', '', () => openManual(), '取説 説明書 解説書 マニュアル');
cmd('history', '版の履歴…（開いたとき・保存のたびの原本。選ぶとその版と今の版の違いを見て、戻すかを決める）', 'ファイル', '', () => toggleSide('hist'), '復元 元に戻す 版 履歴 バックアップ');
cmd('insertFile', '文書を挿入…（.fzk・.md・.txt を今の行に）', '挿入', '', () => insertFileHere(), '結合 読み込み 差し込む');
cmd('splitDoc', 'ここから先を別の文書に…（カーソルの行から文末までを別名で保存し、この文書から除く）', 'ファイル', '', () => splitHere(), '分割 切り出す');
cmd('count', '字数を数える…（選択範囲・空白を除く・原稿用紙換算）', '編集', '', () => openForm('count'), '文字数 カウント 原稿用紙');
cmd('romaji', 'ローマ字をかなに（選んだ範囲か、カーソルの前の英字。漢字は IME の再変換で）', '編集', '', () => romajiHere(), 'シフトミス 打ち間違い 英字 かな');
cmd('fileGroup', 'ファイルメニュー（新規・開く・保存・印刷・書き出し）', 'ファイル', '', () => toggleGroup('file'));
cmd('new', '新しい文書', 'ファイル', 'Ctrl+N', newDoc);
cmd('newSlide', '新しい資料（プレゼン。A4 横・1 行目は柱の表題）', 'ファイル', '', () => withDiscard(() => slideDoc()), 'プレゼン スライド 資料');
cmd('kindDoc', 'この文書を「文書」にする（Word 型の紙面。上の「種類」でも）', '書式', '', () => setKind('doc'), '種類 文書 ワード');
cmd('kindSlide', 'この文書を「資料」にする（プレゼン型。A4 横・柱に表題。上の「種類」でも）', '書式', '', () => setKind('slide'), '種類 資料 プレゼン スライド');
/* 文書の種類（上の帯の左端のプルダウン）：文書 ⇄ 資料。中身はそのまま、用紙・字数・柱だけを替える（取り消しで戻る） */
function docFormatFrom(cur) { let base = defaultFormat(); if (base.kind === 'slide') base = FZ.newDoc().format; const f = JSON.parse(JSON.stringify(cur)); delete f.pageAlt; for (const k of ['paper', 'widthMm', 'heightMm', 'landscape', 'cols', 'rows', 'headerRows', 'footerRows', 'hfGap', 'margins', 'header', 'footer']) if (base[k] !== undefined) f[k] = JSON.parse(JSON.stringify(base[k])); f.kind = 'doc'; return f; }
const pickPage = f => { const o = {}; for (const k of FZ.PAGE_KEYS) if (f[k] !== undefined) o[k] = JSON.parse(JSON.stringify(f[k])); return o; };
function setKind(k) {
  const cur = ed.doc.format; const ck = cur.kind === 'slide' ? 'slide' : 'doc'; if (ck === k) { syncKind(); return; } if (st.mode !== 'text') exitMode(); if (st.form) closeForm();
  let restored = false; ed.mutate('', () => { const alt = { ...(cur.pageAlt || {}) }; alt[ck] = pickPage(cur); /* 今の種類の版面を控え、もう一方の控えがあれば戻す */
    const f = k === 'slide' ? slideFormat(cur) : docFormatFrom(cur); if (alt[k]) { Object.assign(f, JSON.parse(JSON.stringify(alt[k]))); restored = true; } f.pageAlt = alt; ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); });
  syncKind(); msg(k === 'slide' ? `資料にしました（${restored ? 'この文書の資料の版面' : '資料の既定の版面'}・1 行目の表題は柱へ。柱の中身は ${K('slideHead')}、戻すには Ctrl+Z か「種類」で文書）` : `文書にしました（${restored ? 'この文書の文書の版面' : '文書の既定の版面'}。戻すには Ctrl+Z）`);
}
/* 見え方（紙面／ツリー）：帯の左端の 2 段目のプルダウン */
function syncView() { const el = $('viewSel'); if (!el) return; const v = st.view || 'paper'; if (el.value !== v) el.value = v; }
$('viewSel').addEventListener('change', e => { setView(e.target.value); });
function syncKind() { const el = $('kindSel'); if (!el) return; const k = ed.doc.format.kind === 'slide' ? 'slide' : 'doc'; if (el.value !== k) el.value = k; }
$('kindSel').addEventListener('change', e => { setKind(e.target.value); focusTA(); });
$('kind').addEventListener('pointerdown', e => { if (st.armed) disarm(); if (st.form) closeForm(); });
cmd('open', 'ファイルを開く…', 'ファイル', 'Ctrl+O', openFile);
cmd('save', '保存', 'ファイル', 'Ctrl+S', () => saveFile(false));
cmd('saveAs', '名前を付けて保存…', 'ファイル', 'Ctrl+Shift+S', () => saveFile(true));
cmd('pasteMd', '直前の貼り付けを別の形に（文字 → Markdown として整形、Excel のセルの表 → 見た目のまま図）', '編集', 'Ctrl+Alt+V', pasteAsMarkdown, 'markdown 貼付 paste');
cmd('newWindow', '新しい窓を開く（最大 8 つ。別の文書を同時に開ける）', 'ファイル', '', newWindow, '窓 ウィンドウ 複数 同時');
cmd('jaLift', '貼付・.md/.txt の読み込みで、行頭の「１．」「（１）」「①」「■」「・」などを見出し・箇条書きに起こす（切替）', '編集', '', () => { st.jaLift = !st.jaLift; try { localStorage.setItem('fz.jaLift', st.jaLift ? '1' : '0'); } catch { } msg('和文の番号・記号を起こす：' + (st.jaLift ? '入（貼付と .md/.txt の読み込みに効く）' : '切')); drawSub(); }, '和文 番号 起こす 貼付 変換');
cmd('tplSave', 'テンプレートとして保存…', 'ファイル', '', () => openForm('tplname'), '雛形');
cmd('settingsOut', '設定を書き出す（既定の書式・体系・テンプレート・断片・表記の決まり）', 'ファイル', '', exportSettings);
cmd('settingsIn', '設定を読み込む…', 'ファイル', '', importSettings);
/* 変換の記録（P18）：行は行そのもの（objs）で覚え、後で文書を直しても位置を見失わない */
function setConvLog(rec) { if (!rec) return; for (const it of rec.items) it.objs = it.lines.map(i => ed.doc.lines[i]).filter(Boolean); st.convLog = rec; if (st.side === 'conv') drawSide(); }
cmd('convLog', '変換の記録…（書き出し・取り込み・AI に写した時に、近似になった所・入らなかった所を位置つきで）', 'ファイル', '', () => toggleSide('conv'), '変換 近似 記録 書き出し 取り込み 互換 落ちる');
/* P18：書き出しは保存先を決めてから作り、書き終わってから「書き出しました」。やめた・書けなかったもそのとおりに出す。近似・入らない所は「変換の記録」に（位置つき） */
async function exportVia(label0, name, produce, audit) { let note = ''; const label = label0 + (/[A-Za-z]$/.test(label0) ? ' ' : ''); /* 英字の後は空けて「Word に」 */
  try { const r = await FZ.files.exportFile(name, async () => { await busy(label + 'に書き出し中…'); const out = await produce(); if (out && out.note) note = out.note; return out && out.data !== undefined ? out.data : out; });
    if (r.cancelled) { msg(`${label0}の書き出しをやめました（何も書いていません）`); return r; }
    const rec = audit ? audit() : null; if (rec) { rec.file = r.name; setConvLog(rec); }
    const n = rec ? rec.items.length : 0; msg(`${label}に書き出しました：${r.name}${r.how === 'download' ? '（ダウンロードに渡しました。保存先と完了はブラウザに任せています）' : ''}${note}${n ? `。近似・入らない所 ${n} 種（${K('convLog')}）` : ''}`, false, 10000); return r; }
  catch (e) { msg(`${label}に書き出せませんでした：${e.message}（何も書いていないか、途中で止まりました）`, true, 0); return { error: e }; } }
/* E-4：HTML（紙面のまま。頁は SVG のベクター、網もベクターの柄のまま、画像は刷りと同じ網点。字は検索・読み上げ用にも持つ）。印刷すると用紙の大きさで 1 頁ずつ */
async function htmlDoc() { finishLayout(); try { await prepareImages(); } catch { } const lay = ed.lay, g = lay.geo, n = lay.pages.length;
  const toData = url => fetch(url).then(r => r.blob()).then(b => new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); }));
  const DATA = new Map(); for (const [name, r] of IMGC) for (const [k, e] of r.ht) if (e && e.url) { try { DATA.set(name + '|' + k, await toData(e.url)); } catch { } }
  const href = (name, img, w, h) => DATA.get(name + '|' + htKey(w, h)) || `data:${img.mime};base64,${img.data}`;
  const pageText = Array.from({ length: n }, () => []); ed.doc.lines.forEach((ln, i) => { const lm = lay.lineMap[i]; const pg = lm && lm.rows[0] ? lm.rows[0].page : -1; const t = FZ.expandRefsText(ed.doc, ln.segs.map(sg => sg.text).join(' ')).replace(/\s+/g, ' ').trim(); if (pg >= 0 && t) pageText[pg].push(t); });
  const heads = []; ed.doc.lines.forEach((ln, i) => { const a = ln.attrs; if (!(a.style === 'title' || a.style === 'num' || a.style === 'sym')) return; const lm = lay.lineMap[i]; if (!lm || !lm.rows[0]) return; const lv = a.style === 'title' ? 0 : (a.level | 0) + 1; if (lv > 3) return; const mk = ((lm.segs && lm.segs[0] && lm.segs[0].rows[0] && lm.segs[0].rows[0].glyphs) || []).filter(gl => gl.marker).map(gl => gl.text).join('').trim(); heads.push({ lv, page: lm.rows[0].page, text: (mk ? mk + ' ' : '') + ln.segs.map(sg => sg.text).join(' ').trim() }); }); /* 番号は組版の付けた字（marker） */
  const e = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); const title = ed.doc.title || baseTitle();
  const pages = []; for (let p = 0; p < n; p++) pages.push(`<section class="page" id="p${p + 1}" aria-label="${p + 1} 頁">${FZ.renderPage(lay, p, { grid: false, font: ed.doc.format.font, mono: true, imageHref: href })}<div class="sr">${pageText[p].map(t => `<p>${e(t)}</p>`).join('')}</div></section>`);
  return `<!doctype html>\n<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="generator" content="文机 ${FZ.VERSION}"><title>${e(title)}</title>
<style>:root{--pw:${g.W}pt;--ph:${g.H}pt}body{margin:0;background:#e9e9e9;color:#111;font-family:"BIZ UDGothic","Yu Gothic",sans-serif}
nav.toc{max-width:var(--pw);margin:16px auto 0;padding:10px 14px;background:#fff;border:1px solid #111;font-size:14px;line-height:1.6}nav.toc b{display:block;margin-bottom:4px}nav.toc a{color:#111}nav.toc ul{margin:0;padding:0;list-style:none}nav.toc .l2{margin-left:1.2em}nav.toc .l3{margin-left:2.4em}
main{padding:8px 16px 32px}.page{position:relative;width:var(--pw);max-width:100%;aspect-ratio:${g.W}/${g.H};margin:16px auto;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.35)}.page>svg{display:block;width:100%;height:100%}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
@page{size:${g.W}pt ${g.H}pt;margin:0}@media print{body{background:none}nav.toc{display:none}main{padding:0}.page{margin:0;box-shadow:none;break-after:page;max-width:none;width:${g.W}pt;height:${g.H}pt}}</style></head>
<body><nav class="toc" aria-label="目次"><b>${e(title)}</b>${heads.length ? '<ul>' + heads.map(h => `<li class="l${h.lv}"><a href="#p${h.page + 1}">${e(h.text)}</a></li>`).join('') + '</ul>' : ''}<span>${n} 頁。印刷すると用紙の大きさで 1 頁ずつ</span></nav>
<main>${pages.join('\n')}</main></body></html>\n`; }
cmd('exportHtml', 'HTML で書き出す（紙面のまま。頁は SVG、網もベクター。社内の掲示・Web に。印刷もできる）', 'ファイル', '', () => exportVia('HTML', baseTitle() + '.html', () => htmlDoc(), () => ({ title: 'HTML への書き出し', target: 'html', time: Date.now(), items: [] })), 'html web ウェブ 掲示 公開');
cmd('exportPdf', 'PDF にする（紙面のまま。印刷の窓で「PDF に保存」を選ぶ）', 'ファイル', '', () => { msg('印刷の窓が開きます。プリンターで「PDF に保存」を選ぶと PDF になります', false, 8000); return st.view === 'tree' ? exportTree('pdf') : doPrint(); }, 'pdf 提出 印刷');
const convNote = d => d && d._converted ? `（SVG・WebP の画像 ${d._converted} 枚を PNG にして入れた）` : '';
cmd('exportMd', 'Markdown で書き出す（文机 Markdown：節の名札・参照・図版・改頁を注記で持つ GFM。読み込むと戻る）', 'ファイル', '', () => exportVia('Markdown', baseTitle() + '.md', () => FZ.toGfm(ed.doc, { fz: true }), () => FZ.convAudit(ed.doc, 'md')), 'md');
cmd('exportDocx', 'Word（.docx）で書き出す（見出しスタイル・自動番号・表・図形・画像。資料は紙面のまま。ツリーだけを見ている時はツリーの姿で）', 'ファイル', '', async () => { if (st.view === 'tree') return exportTree('docx'); const slide = ed.doc.format.kind === 'slide'; return exportVia(slide ? 'Word（紙面のまま）' : 'Word', baseTitle() + '.docx', async () => { const d = await officeDoc(ed.doc); return { data: await FZ.zipAsync(FZ.toDocx(d, { files: true })), note: convNote(d) }; }, () => FZ.convAudit(ed.doc, slide ? 'docxSlide' : 'docx')); }, 'word docx ワード');
cmd('exportDocxFlow', 'Word（.docx）で書き出す・構成（資料を、紙面の形でなく見出しと本文の流れで。Word で書き直す時に）', 'ファイル', '', () => exportVia('Word（構成）', baseTitle() + '.docx', async () => { const d = await officeDoc(ed.doc); return { data: await FZ.zipAsync(FZ.toDocx(d, { files: true, flow: true })), note: convNote(d) }; }, () => FZ.convAudit(ed.doc, ed.doc.format.kind === 'slide' ? 'docxFlow' : 'docx')), 'word docx ワード 構成 流れ');
cmd('importPptx', 'PowerPoint を取り込む…（.pptx。スライド→資料の頁、横に並んだ図形→区画、表・画像・グラフ、ノート→付箋。見た目でなく構造の近似）', 'ファイル', '', () => pickPptx(), 'PowerPoint pptx 取り込み インポート 変換 スライド 区画');
cmd('importDocx', 'Word を取り込む…（.docx。見出しスタイル→見出し、箇条書き・段落番号→箇条書き、表・太字・リンク・画像。見出しスタイルが無ければ平文の番号から節を起こす）', 'ファイル', '', () => pickDocx(), 'Word docx 取り込み インポート 変換 見出し');
cmd('exportTreePptx', 'ツリーの見た目で PowerPoint（箱と線を図形で。節の途中で頁を切らない）', 'ファイル', '', () => exportTree('pptx'), 'ツリー 図 PowerPoint');
cmd('exportTreePdf', 'ツリーの見た目で印刷・PDF（A4 縦。節の途中で頁を切らない）', 'ファイル', '', () => exportTree('pdf'), 'ツリー 図 PDF 印刷');
cmd('exportTreeDocx', 'ツリーの見た目で Word（頁ごとの図）', 'ファイル', '', () => exportTree('docx'), 'ツリー 図 Word');
cmd('exportPptx', 'PowerPoint（.pptx）で書き出す（1 ページ＝1 スライド、表・図形・画像。ツリーだけを見ている時はツリーの姿で）', 'ファイル', '', async () => { if (st.view === 'tree') return exportTree('pptx'); return exportVia('PowerPoint', baseTitle() + '.pptx', async () => { const d = await officeDoc(ed.doc); return { data: await FZ.zipAsync(FZ.toPptx(d, { files: true })), note: convNote(d) }; }, () => FZ.convAudit(ed.doc, 'pptx')); }, 'powerpoint pptx パワポ スライド');
/* Word・PowerPoint に渡す文書：Office がそのまま開けない画像（SVG・WebP など）を PNG にする（画面の側で描いて写す）。
 * SVG は線画なので長辺 2000px で描き直してにじませない。変換は覚えておき、同じ画像は描き直さない。描けなかった画像は元のまま（書き出し側の注記になる） */
const PNGC = new Map(); const OFFICE_MIME = /^image\/(png|jpeg|gif)$/;
function toPng(img) {
  const key = img.mime + ':' + img.data.length + ':' + img.data.slice(0, 64) + img.data.slice(-64); if (PNGC.has(key)) return PNGC.get(key);
  const p = (async () => { const url = URL.createObjectURL(b64ToBlob(img)); try { const im = new Image(); im.src = url; await im.decode(); const sz = FZ.imageSize(img);
      const vector = /svg/.test(img.mime); let w = im.naturalWidth || sz.w || 800, h = im.naturalHeight || sz.h || 600; if (vector) { const r = (sz.h || h) / (sz.w || w); w = 2000; h = Math.max(1, Math.round(2000 * r)); if (h > 2000) { w = Math.max(1, Math.round(w * 2000 / h)); h = 2000; } }
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').drawImage(im, 0, 0, w, h);
      const blob = await new Promise(res => cv.toBlob(res, 'image/png')); if (!blob) throw new Error('PNG にできません');
      const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).replace(/^data:[^,]*,/, '')); fr.onerror = () => rej(fr.error); fr.readAsDataURL(blob); });
      return vector ? { mime: 'image/png', data, svg: img.data } : { mime: 'image/png', data }; } finally { URL.revokeObjectURL(url); } })(); /* 1.0.15c SVG は元の線画も持たせる（Word・PowerPoint は svgBlip で線画、古い Office は PNG） */
  PNGC.set(key, p); p.catch(() => PNGC.delete(key)); return p;
}
async function officeDoc(doc) {
  const imgs = doc.images || {}; const names = Object.keys(imgs).filter(n => imgs[n] && imgs[n].data && !OFFICE_MIME.test(imgs[n].mime)); if (!names.length) return doc;
  const images = { ...imgs }; let n = 0; await Promise.all(names.map(async nm => { try { images[nm] = await toPng(imgs[nm]); n++; } catch { } }));
  const out = { ...doc, images }; Object.defineProperty(out, 'fileName', { value: doc.fileName || '', enumerable: false }); Object.defineProperty(out, '_converted', { value: n, enumerable: false }); return out;
}
cmd('exportTxt', 'プレーンTXT で書き出す（字だけ。飾り・罫・網・画像は入らない）', 'ファイル', '', () => exportVia('テキスト', baseTitle() + '.txt', () => FZ.toPlain(ed.doc), () => FZ.convAudit(ed.doc, 'txt')));
cmd('print', '印刷／PDF（ツリーだけを見ている時はツリーの姿で）', 'ファイル', 'Ctrl+P', () => st.view === 'tree' ? exportTree('pdf') : doPrint(), 'pdf'); /* 1.0.10u：書き出しの入口は 1 つ。見ている姿（紙面／ツリー）で出す */
cmd('format', '書式（用紙・文字数・行数・余白・書体・番号体系）', '書式', '', () => toggleForm('format'));
cmd('fillMode', '網掛け（範囲を選んで地に網）', '配置', '', enterFillMode);
cmd('noteAdd', '付箋を付ける（選んだ字に。選んでいなければ行に。Word のコメントと同じ）', '編集', 'Ctrl+Alt+M', () => noteAdd(), 'コメント 注釈 メモ 指摘 レビュー');
cmd('noteNext', '次の付箋へ', '編集', 'Alt+PgDn', () => noteStep(1), 'コメント');
cmd('notePrev', '前の付箋へ', '編集', 'Alt+PgUp', () => noteStep(-1), 'コメント');
cmd('noteList', '付箋の一覧（右の欄。未解決だけにも）', '編集', '', () => toggleSide('notes'), 'コメント 一覧');
cmd('noteClearDone', '解決した付箋をまとめて消す（取消できる）', '編集', '', () => noteClearDone(), 'コメント 解決済み 削除 片づけ');
cmd('careShow', '手当て（付箋・点検の印・比べた印など、刷られない印。朱）を見せる・隠す。隠すと紙だけ＝刷り上がりと同じ', '表示', '', () => careToggle(), '三層 手当て 注釈 刷り上がり 紙だけ 付箋 隠す');
cmd('convPreview', '写しの見通し（Word・PowerPoint・Markdown・テキストに書き出すと変わる所を、書き出す前に位置つきで）', '表示', '', () => convPreview(), '写し 縮退 互換 書き出し 前に 確かめる 変換');
cmd('health', '文書の健康診断（規模・構造・参照と番号・付箋・表記・構成の型を 1 つの欄に。行を選ぶとその所へ、直せるものは直す・無視する）', '構造', '', () => toggleSide('health'), '点検 診断 校閲 表記 揺れ 公用文 ら抜き 参照切れ 品質 チェック');
cmd('review', '読み手の問い（診断の欄で：何と比べて？・誰がいつ？・で、結論は？など 13 の規則。通信なし）', '構造', '', () => reviewOpen(), '読み手の問い 下読み レビュー 審査 突っ込み 校閲 報告 評価 会議資料 上司 提出前 基準 診断');
cmd('healthNext', '健康診断の次の所へ', '構造', '', () => healthStep(1), '点検 次');
cmd('healthPrev', '健康診断の前の所へ', '構造', '', () => healthStep(-1), '点検 前');
cmd('selfCheck', '往復の自己診断（この文書を 原本・Markdown・Word で書いて読み戻し、変わる所・消える所を位置つきで右の欄に）', 'ファイル', '', () => selfCheck(), '往復 自己診断 互換 壊れない 確かめる 書き出し 読み戻し');
async function selfCheck() { const doc = ed.doc; const items = []; const tx = l => l.segs.map(s => s.text).join(''); msg('往復を試しています…', false, 3000);
  { const s1 = FZ.serialize(doc), d1 = FZ.parse(s1), s2 = FZ.serialize(d1); const diff = []; if (s1 !== s2 || d1.lines.length !== doc.lines.length) doc.lines.forEach((l, i) => { const m = d1.lines[i]; if (!m || FZ.lineSig(doc, l) !== FZ.lineSig(d1, m)) diff.push(i); });
    items.push({ what: !diff.length && s1 === s2 ? '原本（.fzk）：書いて読み戻すと同じ' : `原本（.fzk）：書いて読み戻すと違う行 ${diff.length || '（行は同じで書き方が違う）'}`, lines: diff }); }
  try { const A = FZ.convAudit(doc, 'md'); items.push({ what: A.items.length ? `Markdown：読み戻すと変わる所 ${A.items.length} 種類（下に）` : 'Markdown：読み戻すと同じ', lines: [] }); for (const it of A.items) items.push({ what: 'Markdown：' + it.what, lines: it.lines }); } catch (e) { items.push({ what: 'Markdown：往復できませんでした（' + e.message + '）', lines: [] }); }
  try { const od = await officeDoc(doc); const buf = FZ.zip(FZ.toDocx(od, { files: true, flow: true })); const R = await FZ.fromDocx(buf); const norm = t => String(t).replace(/[\s　*_\\]/g, ''); const got = norm(R.doc.lines.map(tx).join('')); const miss = [];
    doc.lines.forEach((l, i) => { if (l.attrs.figure || l.attrs.toc) return; const t = norm(FZ.expandRefsText(doc, tx(l))); if (t.length >= 4 && !got.includes(t.slice(0, 30))) miss.push(i); });
    items.push({ what: miss.length ? `Word：書いて読み戻すと字が見つからない行 ${miss.length}` : 'Word：書いて読み戻すと、どの行の字も残る', lines: miss }); } catch (e) { items.push({ what: 'Word：往復できませんでした（' + e.message + '）', lines: [] }); }
  setConvLog({ title: '往復の自己診断', target: 'self', items, time: Date.now() }); if (st.side !== 'conv') toggleSide('conv'); else drawSide(); const bad = items.filter(x => x.lines.length || /違う|変わる|見つからない|できません/.test(x.what)).length; msg(bad ? `往復で変わる所 ${bad} 件を右の欄に出しました` : '原本・Markdown・Word のどれも、往復で変わりません', false, 7000); }
cmd('histPick', '版の履歴から節ごとに選んで戻す（選んだ版と今の版の違いを 1 つずつ見て、戻す・捨てる）', 'ファイル', '', () => histPick(st.histSel), '復元 版 履歴 部分 節 戻す');
cmd('noteShow', '付箋のつまみと下線を見せる・隠す', '表示', '', () => { st.notesHidden = !st.notesHidden; drawNotes(); msg(st.notesHidden ? '付箋を隠しました' : '付箋を見せます'); }, 'コメント');
cmd('gantt', '工程表…（ガントチャート。表の行がテーマ・担当、列が期間。期間のセルに字を書けば矢羽根、→ で延ばす、◆ マイルストーン）／工程表の中なら設定を変える…', '挿入', '', () => toggleForm('gantt'), 'ガント スケジュール 工程 日程 矢羽根 マイルストーン');
cmd('table', '表を入れる…（列数・行数・列幅）／表の中なら様式を変える…', '挿入', '', () => toggleForm('table'));
cmd('marks', '文字メニュー（太字・下線などの修飾、倍角、リンク）', '文字', '', () => toggleGroup('marks'));
cmd('structGroup', '構造メニュー（種類・段の上げ下げ・並べ替え・組替・文・改頁・番号の形。紙面でもツリーでも同じ）', '構造', '', () => toggleGroup('struct'));
for (const [k, l, key] of [['out', '上げる（梯子：文→段落→見出し。見出し・箇条書きは浅く）', 'Alt+←'], ['in', '下げる（梯子：段落→前の段落の文、文→箇条書き。見出し・箇条書きは深く）', 'Alt+→'], ['up', '上へ（兄弟の中で。子と本文ごと。文は段落の中で）', 'Alt+↑'], ['down', '下へ（兄弟の中で）', 'Alt+↓']]) cmd('sx:' + k, '構造：' + l, '構造', key, () => structOp(k), '梯子 レベル 上げ下げ 格上げ 格下げ 並べ替え');
for (const [k, l] of [['para', '段落を文ごとの段落にばらす'], ['list', '段落を箇条書きにばらす（1 文 1 項目）'], ['tree', '段落を親子にばらす（最初の文が親、残りが子の項目）'], ['merge', '選んだ行・節（または節と子）を 1 つの段落にまとめる']]) cmd('sx:re:' + k, '組替：' + l, '構造', '', () => structOp('re', k), 'ばらす まとめる 文 段落 箇条書き 親子 組替');
cmd('moveTo', '送り先を選んで移す…（見出しの一覧から移し先を選ぶ。子と本文ごと。長い文書でドラッグしない）', '構造', 'Ctrl+M', () => { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); openForm('moveTo'); }, '移動 移す 送る 見出し 節');
cmd('checkStruct', '構造の点検…（子が 1 つ・中身なし・長い文・文末の不統一・段の飛び を節に印で）', '構造', '', () => { toggleForm('scheck'); if (st.view === 'tree' || st.view === 'split') render(); }, '点検 チェック 校正 文末 長い文');
cmd('sentOpt', '文の分け方…（「．」も文末に、箇条書きの中の文も分ける）', '書式', '', () => openForm('sentopt'), '文 分け方 句点 ピリオド');
cmd('park', '保留へ送る（選んだ節・文・範囲を文書の外の「保留の島」へ。書き出しには出ない。いつでも戻せる）', '構造', '', () => parkSel(), '保留 退避 パーキング 島 一時 置き場');
cmd('parkList', '保留の島…（退避した節・文を見る・戻す・消す）', '構造', '', () => openForm('parked'), '保留 退避 島 戻す');
cmd('sx:mark', '番号・記号の形…（カーソル・選んだ節の段のものすべて。全体は体系…）', '構造', '', () => openForm('marker'), '番号 記号 形 体系');
cmd('selSent', '文を選ぶ（カーソルのある文。紙面では Ctrl+クリックでも。選んだ文に上げる・下げる・種類・上へ下へが効く）', '構造', '', () => selectSentence(), '文 選択 センテンス');
cmd('aiCopySec', 'この節を Markdown で写す（AI に貼り付ける用。紙面＝カーソルの節か選んだ範囲、ツリー＝選んだ節と子）', 'ファイル', '', () => aiCopy(false), 'AI Markdown コピー 写す ChatGPT Claude 貼り付け');
cmd('askAI', 'AI に頼む…（下読み・校正・議事録に起こす・要点に絞る。部品棚から依頼を組み立てて写す。答えは「AI から戻す」に貼る）', 'ファイル', '', () => toggleSide('request'), 'AI 依頼 頼む プロンプト 下読み 校正 議事録 要点 要約 ChatGPT Copilot 部品棚 基準');
cmd('rqNotesClear', '下読みの付箋をすべて消す（作成者「下読み」の付箋だけ。人の付箋は残す）', '編集', '', () => rqNotesClear(), '付箋 下読み 消す AI 指摘');
cmd('rqStopNext', '下読みの「止」へ（未解決の止の付箋を順に）', '編集', '', () => rqStopNext(), '止 下読み 付箋 次');
cmd('rqMatch', '本番の朱と照らし合わせる（提出先が入れた朱＝Word のコメントなどと、下読みの指摘を突き合わせ、当たりを数える）', 'ファイル', '', () => rqMatch(), '的中 当たり 朱 コメント 下読み 記録 基準 提出先');
cmd('askSend', 'AI に頼む（送り先のとおり：手元の AI なら送って答えを受け取る、チャットなら写す）', 'ファイル', '', () => rqDest() === 'local' ? rqSend() : rqCopy(), 'AI 依頼 送る 手元 ローカル LLM Unsloth');
cmd('askCopy', 'AI への依頼を写す（「AI に頼む」の欄の選び方で）', 'ファイル', '', () => rqCopy(), 'AI 依頼 写す プロンプト');
cmd('aiCopyDoc', '文書全体を Markdown で写す（AI に貼り付ける用）', 'ファイル', '', () => aiCopy(true), 'AI Markdown コピー 全体 写す');
cmd('panels', '区画…（見出しの子の節を横に並べた枠に。霞が関型の 1 枚もの）', '配置', '', () => openPanels(), '区画 霞が関 ポンチ絵 枠 横に並べる 列 パネル');
cmd('aiReturn', 'AI から戻す…（AI が直した Markdown を貼ると、違う所を 1 つずつ見て取り込む・捨てる。飾り・罫は今のまま）', 'ファイル', '', () => aiReturn(), 'AI 戻す 取り込む 差分 比べる 貼り付け Markdown ChatGPT Claude');
/* 1.0.11a：ツリーの形は字下げだけ（横広げ・縦広げのコマンドはやめた） */
cmd('find', '検索・置換（ツリーでは節を探す：当たった節に印、Enter で次へ）', '編集', 'Ctrl+F', () => toggleForm(st.mode === 'tree' ? 'tfind' : 'replace'));
cmd('replace', '置換', '編集', 'Ctrl+H', () => toggleForm('replace'));
cmd('lineGroup', '配置メニュー（揃え・位置・改ページ）', '配置', '', () => toggleGroup('line'));
cmd('palette', 'コマンド一覧', '表示', 'Ctrl+K', () => toggleSide('palette'));
cmd('framework', 'フレームワーク…（考える型を枠として入れ、画面の下に枠ごとの書き方を出す）', '挿入', '', () => openFwPick(), 'フレームワーク テンプレート 型 SWOT 3C PDCA 文例 雛形 ビジネス');
cmd('fwGuide', 'フレームワークの解説を出す／隠す', '表示', '', () => { st.fwGuideOff = !st.fwGuideOff; updateFwGuide(); msg(st.fwGuideOff ? 'フレームワークの解説を隠しました' : 'フレームワークの解説を出します（枠の中にカーソルがある間）'); }, 'フレームワーク 解説 書き方');
cmd('undo', '元に戻す', '編集', 'Ctrl+Z', () => { ed.undo(); });
cmd('redo', 'やり直す', '編集', 'Ctrl+Y', () => { ed.redo(); });
cmd('selectAll', 'すべて選択', '編集', 'Ctrl+A', () => ed.selectAll());
cmd('bold', 'ゴシック太字', '文字', 'Ctrl+B', () => ed.toggleMark(M.BOLD));
cmd('under', '下線', '文字', 'Ctrl+U', () => ed.toggleMark(M.UNDER));
cmd('dot', '傍点', '文字', '', () => ed.toggleMark(M.DOT));
cmd('shade', '網掛け文字', '文字', '', () => ed.toggleMark(M.SHADE));
cmd('codeSpan', '文中のコード（Markdown の ` と往復。淡い網・ゴシック）', '文字', '', () => ed.toggleMark(M.CODE), 'code コード 等幅');
cmd('outline', '白抜き', '文字', '', () => ed.toggleMark(M.OUTLINE));
cmd('strike', '取消線', '文字', '', () => ed.toggleMark(M.STRIKE));
cmd('under2', '二重下線', '文字', '', () => ed.toggleMark(M.UNDER2));
cmd('wave', '波線の下線', '文字', '', () => ed.toggleMark(M.WAVE));
cmd('strike2', '二重取消線', '文字', '', () => ed.toggleMark(M.STRIKE2));
cmd('shadeType', '網の文様…（字の網掛けを斜線・格子・濃さなどに）', '文字', '', () => openForm('shadeType'), '網掛け 文様 パターン 斜線 格子');
cmd('shadow', '影文字（白抜きと組むと新聞の影付き白抜き）', '文字', '', () => ed.toggleMark(M.SHADOW), '影 シャドウ 白抜き 見出し');
cmd('scale', 'm×n 倍角…（横・縦 1〜9 倍）', '文字', '', () => openForm('scale'), '倍角 拡大 大きい字 掲示');
cmd('wide', '横倍角', '文字', '', () => ed.toggleMark(M.WIDE));
cmd('tall', '縦倍角', '文字', '', () => ed.toggleMark(M.TALL));
cmd('quad', '四倍角', '文字', '', () => { const s = ed.sel(); if (s) { const all = ed.allMarked(s, M.WIDE) && ed.allMarked(s, M.TALL); ed.mutate('', () => ed.forEachMark(s, m => all ? (m & ~(M.WIDE | M.TALL)) : (m | M.WIDE | M.TALL))); ed.typing = all ? (ed.typing & ~(M.WIDE | M.TALL)) : (ed.typing | M.WIDE | M.TALL); } else { const on = (ed.typing & M.WIDE) && (ed.typing & M.TALL); ed.typing = on ? (ed.typing & ~(M.WIDE | M.TALL)) : (ed.typing | M.WIDE | M.TALL); ed.onCaret(); } });
cmd('clearMarks', '修飾をすべて解除', '文字', '', () => ed.setMarks(0));
cmd('alignL', '左揃え', '配置', 'Ctrl+L', () => ed.setAttrs({ align: null }));
cmd('alignC', '中央揃え', '配置', 'Ctrl+E', () => ed.toggleAttr('align', 'center'));
cmd('alignR', '右揃え', '配置', 'Ctrl+R', () => ed.toggleAttr('align', 'right'));
cmd('alignJ', '均等割付', '配置', 'Ctrl+J', () => ed.toggleAttr('align', 'justify'));
cmd('styleBody', '本文（見出し・箇条書き・発言録を外す。位置は保つ）', '構造', '', () => kindGuard('body') || ed.setAttrs({ style: null, level: null, list: null, speakerCols: null }));
cmd('styleTitle', '表題', '構造', '', () => kindGuard('title') || ed.setAttrs({ style: 'title' }));
cmd('styleNum', '数字見出し（レベル別の番号。Tab で深く）', '構造', '', () => kindGuard('num') || ed.setHeading('num'), '見出し 番号 章');
cmd('styleSym', '記号見出し（レベル別の記号。Tab で深く）', '構造', '', () => kindGuard('sym') || ed.setHeading('sym'), '見出し ■');
cmd('styleSpeech', '発言録（発言者：本文）', '配置', '', () => { const cur = ed.line().attrs; if (cur.style === 'speech') ed.setAttrs({ style: null, speakerCols: null }); else openForm('speech'); }, '台本 議事録');
cmd('item', '箇条書き（レベル別の記号。Tab で深く）切替', '構造', '', () => kindGuard('list') || ed.setList(), '項目 bullet');
cmd('scheme', '見出しと箇条書きの体系…（三体系：番号と記号、見出しの前後の空き、本文の位置）', '書式', '', () => toggleForm('scheme'), 'レベル 箇条書き 番号 記号');
cmd('arrow', '→ 結論・展開の行頭記号', '構造', '', () => ed.setList('arrow'));
cmd('numItem', '番号付き箇条書き（1） 2） 3）…。続く項目を自動で数える。Tab で深く（a） b）…）、Markdown の 1. 2. と往復）切替', '構造', '', () => kindGuard('nlist') || ed.setList('num'), '番号 番号付き リスト ordered 連番');
cmd('todo', '❏ 課題（アクション）の行頭記号 入切', '構造', '', () => ed.setList('todo'), 'todo task チェック 課題');
cmd('done', '☑ 完了 入切（❏ の行を完了に、☑ を ❏ に戻す）', '構造', '', () => ed.setList('done'), 'done 完了 チェック');
cmd('quote', '引用（左に線、2 マス字下げ）入切', '配置', '', () => ed.cycleQuote(), 'blockquote');
cmd('code', 'コード（淡い地。Markdown のコードブロック）切替', '配置', '', () => ed.toggleCode(), 'code pre');
cmd('link', 'リンク…（選択範囲に URL を付ける／外す）', '文字', 'Ctrl+Shift+L', () => openForm('link'), 'url ハイパーリンク');
cmd('childItem', '子項目を作る（1階層下）', '構造', '', () => ed.childItem());
for (const h of FZ.HEADINGS) cmd('hd:' + h.id, '見出し飾り：' + h.label + '（' + h.desc + '）', '見出し飾り', '', () => FZ.applyHeading(ed, h.id), '新聞 見出し');
for (const t of FZ.TABLES) cmd('tb:' + t.id, '表スタイル：' + t.label + '（' + t.desc + '）', '表の様式', '', () => { if (!FZ.applyTable(ed, t.id)) msg('表の中にカーソルを置いてください', true); }, '新聞 表組');
for (const o of FZ.TABLE_OPS) cmd('to:' + o.id, o.id === 'headFill' ? '表：見出し行の網…（淡網・薄網・濃網・濃灰・墨・斜線・なしから選ぶ）' : '表：' + o.label + '（' + o.desc + '）', '表の様式', '', () => { if (o.id === 'headFill') { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return; } openForm('headFill'); return; } if (!FZ.applyTableOp(ed, o.id)) { msg('表の中にカーソルを置いてください', true); return; } if (o.id === 'repeat') { const rg = FZ.tableRange(ed); msg(rg && ed.doc.lines[rg[0]].attrs.noRepeat ? 'この表は見出し行を繰り返しません' : 'ページをまたぐと、次のページの頭に見出し行を繰り返します'); } }, o.id === 'repeat' ? '表組 見出し行 繰り返し タイトル行 ヘッダ行 ページ' : '表組');
cmd('headGroup', '見出し飾り…（新聞の見出し表現）', '配置', '', () => toggleGroup('head'));
cmd('hr', '区切り線を入れる（行の真ん中に線を引く行。Markdown の ---。手で引いた罫とは別）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); ed.insertHr(); }, '区切り線 水平線 hr ---');
cmd('toc', '目次を入れる／範囲を変える（見出しを抜き出して頁番号を自動で付ける）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); openForm('toc'); }, '目次 もくじ 見出し一覧 索引');
cmd('figOpen', '画像を入れる…（図表として今の行に付ける。資料書式では右の図表欄に積む。貼り付け・ドラッグ＆ドロップでも入る）', '挿入', 'Ctrl+V（画像）', () => { if (st.mode !== 'text') exitMode(); pickImage().then(r => { if (r) addImageFigure(r); }); }, '画像 図 写真 グラフ ピクチャ 挿入 png jpeg');
cmd('figEdit', '図表…（題・図／表・幅・順番・差し替え・削除）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); const L = ed.figList(); if (!L.length) { msg('図表がありません（' + K('figOpen') + ' で画像を入れる、または画像を貼り付け）', true); return; } const here = L.filter(x => x.line <= ed.caret.line); const fx = here.length ? here[here.length - 1] : L[0]; st.figSel = fx.fg.id; openForm(fx.fg.chart ? 'chart' : 'fig'); }, '図表 画像 図番号 題 キャプション');
cmd('chart', 'グラフ…（表の中なら表のデータで作る。Excel のセルを表として貼った後もここで。今の行にグラフがあれば直す）', '挿入', 'Ctrl+G', () => chartCmd(), 'グラフ 棒 横棒 折れ線 円 帯 積み上げ チャート 表から Excel');
cmd('figTree', '構成図を作る…（カーソル・選んだ節と子の見出し・箇条書きを、箱と矢印の図に自動で並べる）', '挿入', '', () => openForm('figtree'), '構成図 組織図 ツリー 図 自動 流れ図 マインドマップ');
cmd('secRef', '節の参照を入れる…（本文に「2. 構成」のような見出しの番号と題。並べ替えても番号が追う）', '挿入', '', () => { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); openForm('secref'); }, '参照 相互参照 節 見出し 章');
cmd('skeleton', '構成の型…（報告書・企画書・議事録・霞が関の説明資料・論点整理・事業概要・答申 の骨組みを流し込む）', '構造', '', () => { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); openForm('skeleton'); }, '型 テンプレート 骨組み 霞が関 報告書 企画書 議事録');
cmd('figRef', '図番を入れる（本文に「図 1」。図表の順番が変わっても番号が追従）', '挿入', '', () => { if (st.mode !== 'text') exitMode(); if (!ed.figList().length) { msg('図表がありません', true); return; } openForm('figref'); }, '図番 参照 相互参照 図 表');
cmd('dateToday', '作成日を今日の日付にする（資料の柱。書式の「資料の柱…」で「自動」にすると毎日今日の日付になる）', '書式', '', () => { const f = ed.doc.format; const t = FZ.todayJa(); if (!f.dateAuto && f.date === t) { msg('作成日はすでに今日です（' + t + '）'); return; } ed.mutate('', () => { f.date = t; f.dateAuto = false; }); msg('作成日を今日にしました：' + t); }, '日付 今日 作成日 更新 本日');
cmd('mdStars', '文中に残った **…** を太字にする（生成 AI の Markdown を取り込んで ** が文字のまま残ったとき。選択範囲、無ければ文書全体。対にならない ** は消す）', '編集', '', () => { const n = ed.cleanMdStars(); msg(n ? `** を ${n} か所直しました（Ctrl+Z で戻す）` : '文中に ** はありません'); }, '** アスタリスク 太字 markdown 記号 整える');
cmd('newSlide', '新しい資料（A4 横、本文欄＋図表欄、柱に題・機密表示・日付・頁番号。新規 → S）', 'ファイル', '', () => withDiscard(slideDoc), '資料 プレゼン スライド パワポ 横');
cmd('figInsert', '図（フローチャート）を入れる／編集する', '挿入', '', () => { if (st.mode === 'fig') return; const ln = ed.line(); if (ln.attrs.figure) { enterFigMode(ed.caret.line); return; } if (st.mode !== 'text') exitMode(); const at = ed.insertFigure(10); enterFigMode(at); msg('図：N 箱を足す／C 矢印でつなぐ／Tab 選ぶ／矢印キーで動かす／L レーン／Esc で本文へ'); }, 'フローチャート 流れ図 箱 矢印 スイムレーン');
cmd('fg:add', '図：箱を足す（空いた所をダブルクリックでも）', '図', 'N', () => { if (st.mode === 'fig') figAddBox(); });
cmd('fg:text', '図：箱の文字をその場で打つ（箱をダブルクリックでも）', '図', 'Enter / T', () => { if (st.mode !== 'fig') return; if (st.fig.selArrow != null) { openInline('arrow', st.fig.selArrow); return; } const b = figPrim(); if (b) openInline('box', b.id); else msg('箱を選んでください', true); });
cmd('fg:props', '図：箱の設定…（文字・幅・高さ・線・網）', '図', 'P', () => { if (st.mode === 'fig' && figSel()) openForm('box'); });
cmd('fg:connect', '図：矢印でつなぐ（箱の辺の点から別の箱へドラッグでも）', '図', 'C', () => { if (st.mode === 'fig') figConnectStart(); });
cmd('fg:dup', '図：選んだ箱を複製', '図', 'D / Ctrl+D', () => { if (st.mode === 'fig') figDuplicate(); });
cmd('fg:all', '図：箱をすべて選ぶ', '図', 'Ctrl+A', () => { const fi = st.mode === 'fig' && figInfo(); if (fi) { figSetSel(fi.F.boxes.map(b => b.id)); figRefresh(); } });
cmd('fg:delete', '図：選んだ箱／矢印を消す', '図', 'Delete', () => { if (st.mode === 'fig') figDelete(); });
cmd('fg:kind', '図：箱の線種（細→太→二重→点線）', '図', 'K', () => { if (st.mode === 'fig') figCycleProp('kind', ['thin', 'thick', 'double', 'dotted']); });
cmd('fg:shade', '図：箱の網（なし→薄→濃網→墨→斜線→点）', '図', 'S', () => { if (st.mode === 'fig') figCycleProp('shade', [null, 'gray', 'deep', 'dark', 'hatch', 'dots']); });
for (const [k, l] of [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']]) cmd('fg:k:' + k, '図：箱の線を' + l + 'に', '図', '', () => { if (st.mode === 'fig') figSetProp('kind', k); });
for (const [id, l] of [['none', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['dots', '点']]) cmd('fg:s:' + id, '図：箱の網を' + l + 'に', '図', '', () => { if (st.mode === 'fig') figSetProp('shade', id === 'none' ? null : id); });
for (const [m, l] of [['left', '左を揃える'], ['center', '左右の中央を揃える'], ['right', '右を揃える'], ['top', '上を揃える'], ['middle', '上下の中央を揃える'], ['bottom', '下を揃える'], ['dh', '横に等間隔'], ['dv', '縦に等間隔']]) cmd('fg:al:' + m, '図：選んだ箱の' + l, '図', '', () => { if (st.mode === 'fig') figAlign(m); });
cmd('fg:bold', '図：箱の文字を太字', '図', 'B', () => { if (st.mode === 'fig') figCycleProp('bold', [false, true]); });
cmd('fg:lanes', '図：スイムレーン…（縦／横、名前）', '図', 'L', () => { if (st.mode === 'fig') openForm('lanes'); });
cmd('fg:taller', '図の高さ＋1（図の下端のつまみをドラッグでも）', '図', '+', () => { if (st.mode === 'fig') figHeight(1); });
cmd('fg:shorter', '図の高さ−1', '図', '-', () => { if (st.mode === 'fig') figHeight(-1); });
cmd('fg:compact', '図を詰めて組み直す（箱を字の大きさに、間を詰める。並びは自動に戻る）', '図', '', () => figCompact()); /* 1.0.14f */
function figCompact() { const fi = figInfo(); if (!fi) { msg('図の行にカーソルを置いてください'); return; } const W = fi.right - fi.left; let G = null; try { G = FZ.figureFromMermaid(FZ.figureToMermaid(fi.F, W).join('\n'), W); } catch (e) { G = null; }
  if (!G || !G.boxes.length) { msg('この図は組み直せません'); return; } const before = fi.F.h;
  ed.figOp(fi.line, F => { for (const k of Object.keys(F)) delete F[k]; Object.assign(F, JSON.parse(JSON.stringify(G))); });
  if (st.mode === 'fig' && st.fig) { st.fig.sel = null; st.fig.multi = new Set(); st.fig.selArrow = null; figRefresh(); } render(); msg(`図を詰めて組み直しました（高さ ${before} 行 → ${G.h} 行。元に戻すは Ctrl+Z）`, false, 6000); }
cmd('tableGroup', '表スタイル…（新聞・統計表の表組）', '表', '', () => toggleGroup('table'));
/* 表の編集（行・列・セル）。右クリックで帯に出る。セルの操作は選んだ範囲（ドラッグ・Shift+クリック）か、カーソルのセル */
function tblDo(fn) { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return false; } const r = fn(); if (r === 'narrow') msg('列が狭くて足せません（列の境の罫をドラッグして広げてから）', true); return r; }
function cellsDo(fn) { const R = cellRect(); if (!R) { msg('表の中にカーソルを置いてください', true); return; } fn(R); requestOverlay(); }
/* 1.0.12a 結合・解除・列の幅・表の位置 */
function tableW() { const g = ed.lay.geo; return g.side ? g.cols : g.bodyCols || g.cols; } /* 資料（図表欄あり）では表は全幅まで（本文欄より広い表は全幅に組む） */
function colRange() { const R = cellRect(); if (!R) return null; return R.ca < R.cb ? R : { ...R, ca: 0, cb: R.I.n - 1, all: true }; }
cmd('tmerge', '表：セルを結合（選んだセルを 1 つに。字は左上のセルへまとめる）', '表', '', () => cellsDo(R0 => { if (R0.ca === R0.cb && R0.la === R0.lb) { msg('結合するセルを 2 つ以上選んでください（Shift＋矢印かドラッグ）', true); return; } const R = FZ.tbl.spanOf(ed, R0); FZ.tbl.merge(ed, R); st.cells = null; render(); msg('セルを結合しました（' + K('undo') + ' で戻す）'); }), 'セル 結合 マージ 連結');
cmd('tsplit', '表：結合を解除（範囲の中の境に罫を引き直す）', '表', '', () => cellsDo(R0 => { const R = FZ.tbl.spanOf(ed, R0); if (!FZ.tbl.hasMerge(ed, R)) { msg('選んだ範囲に結合したセルはありません', true); return; } FZ.tbl.unmerge(ed, R); render(); msg('結合を解除しました'); }), 'セル 結合 解除 分割');
cmd('tcw:eq', '表：列の幅をそろえる（選んだ列を同じ幅に。選ばなければ全部の列）', '表', '', () => { const R = colRange(); if (!R) { msg('表の中にカーソルを置いてください', true); return; } if (R.I.n < 2) return; msg(FZ.tbl.equalize(ed, R.I, R.ca, R.cb) ? `列の幅をそろえました（${R.all ? '全部の列' : (R.cb - R.ca + 1) + ' 列'}）` : '列の幅はそろっています'); render(); }, '列 幅 均等 そろえる');
cmd('tcw:fit', '表：列の幅を字に合わせる（選んだ列を中身の字数に。選ばなければ全部の列）', '表', '', () => { const R = colRange(); if (!R) { msg('表の中にカーソルを置いてください', true); return; } msg(FZ.tbl.fit(ed, R.I, R.ca, R.cb, tableW()) ? `列の幅を字に合わせました（${R.all ? '全部の列' : (R.cb - R.ca + 1) + ' 列'}）` : '列の幅は字に合っています'); render(); }, '列 幅 自動 最小 字数 合わせる');
cmd('panelWide', '区画：この区画を全幅に（段を 1 つ使う）／戻す', '配置', '', () => { let i = ed.caret.line; const L = ed.doc.lines; const PG = ed.lay.panelGroups; let g = -1; for (const [gl, G] of PG || []) if (i >= G.lines[0] && i <= G.lines[1]) g = gl; if (g < 0) { msg('区画の中にカーソルを置いてください', true); return; } /* カーソルのある区画の頭：区画の親の子の深さの行まで上る */ const lv = a => a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : (a.list && a.list.kind !== 'cont') ? 17 + (a.list.level | 0) : 99; let cl = 99; for (let q = g + 1; q <= PG.get(g).lines[1]; q++) cl = Math.min(cl, lv(L[q].attrs)); while (i > g + 1 && lv(L[i].attrs) !== cl) i--; const at = L[i].attrs; ed.mutate('', () => { if (at.panelWide) delete at.panelWide; else at.panelWide = true; }); render(); msg(at.panelWide ? 'この区画を全幅にしました（段を 1 つ使う）' : '区画を列に戻しました'); }, '区画 全幅 横長 段');
cmd('bx:full', '囲み：版面の幅いっぱいに戻す', '配置', '', () => { const A = boxAtCaret(); if (!A) { msg('囲みの中にカーソルを置いてください', true); return; } msg(FZ.boxSet(ed, A, 0, ed.lay.geo.bodyCols || ed.lay.geo.cols) ? '囲みを版面の幅いっぱいにしました' : '囲みは版面の幅いっぱいです'); render(); }, '囲み 幅 全幅 戻す');
for (const [id, l, dx, dy] of [['l', '左へ（半字）', -0.5, 0], ['r', '右へ（半字）', 0.5, 0], ['u', '上へ（上の空行を詰める）', 0, -1], ['d', '下へ（上に空行を足す）', 0, 1]]) cmd('tmv:' + id, '表・囲み：' + l, '表', '', () => { const I = FZ.tbl.info(ed); const A = I ? null : boxAtCaret(); if (!I && !A) { msg('表か囲みの中にカーソルを置いてください', true); return; } const ok = A ? (dx ? (A.L + dx >= 0 && A.R + dx <= tableW() && FZ.boxSet(ed, A, A.L + dx, A.R + dx)) : FZ.tbl.shiftV(ed, { a: A.a, b: A.b }, dy)) : dx ? FZ.tbl.shift(ed, I, dx, tableW()) : FZ.tbl.shiftV(ed, I, dy); if (!ok) msg(dx ? '版面の端です' : '上に詰める空行がありません', true); render(); }, '表 囲み 位置 移動 ずらす'); /* 1.0.12c 囲みも */
cmd('teditGroup', '表の編集…（行・列の挿入と削除、セルの網・揃え・消去。表の中で右クリックでも）', '表', '', () => { if (!FZ.tableRange(ed)) { msg('表の中にカーソルを置いてください', true); return; } toggleGroup('tedit'); });
cmd('tr:above', '表：上に行を挿入', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertRow(ed, false); }));
cmd('tr:below', '表：下に行を挿入', '表', '', () => tblDo(() => { st.cells = null; if (ed.line().attrs.sumRow) { msg('合計の行の上に足しました'); return FZ.tbl.insertRow(ed, false); } return FZ.tbl.insertRow(ed, true); }));
/* 1.0.15d（B-8）表の計算 */
cmd('drawer', '引き出し（右の欄のタブ：記号・断片・文庫・量）', '表示', '', () => openDrawer(), 'ひきだし 引出');
cmd('symbols', '記号の引出…（分類・別名で探す・最近使った記号。押すとカーソルの所に）', '挿入', '', () => openDrawer('sym'), 'きごう 文字パレット まる こめ やじるし かっこ 特殊文字');
cmd('snippets', '断片箱…（公用文の定型句・自分の言い回しを入れる。選んだ字を断片に）', '挿入', '', () => openDrawer('snip'), 'だんぺん 定型文 定型句 言い回し');
cmd('library', '文庫…（最近の文書・お気に入りを開く。文書をまたいで探す）', 'ファイル', '', () => openDrawer('lib'), 'ぶんこ 最近 お気に入り 横断検索 書庫');
cmd('docMeter', '文書の量…（引き出しの「量」：字数・頁・この節の字数・目標の字数・健康診断のまとめ）', '表示', '', () => openDrawer('ruler'), 'りょう 統計 字数 目標 物差し');
cmd('tools', '道具箱…（操作の並びを道具にして Alt+1〜9 で使う。記録する・コマンドを名前で足す・近道を決める）', '表示', '', () => openDrawer('tools'), 'どうぐ マクロ キーの割り当て 記録 近道');
cmd('recToggle', '道具の記録を始める／止める', '表示', '', () => { if (st.rec) recStop(); else recStart(); }, 'マクロ 記録');
cmd('practice', 'はじめの一枚（10 分で 1 枚の文書を書き上げる練習。手順は付箋に）', 'ファイル', '', () => practiceStart(), 'れんしゅう 練習 入門 チュートリアル');
cmd('focusMode', '集中の表示（カーソルの節のほかを薄く。刷りには出ない）', '表示', '', () => { st.focus = !st.focus; lsW('fz.focus', st.focus); requestOverlay(); drawFkeys(); msg(st.focus ? '集中の表示：カーソルの節のほかを薄くしました（もう一度で戻す）' : '集中の表示をやめました'); }, 'しゅうちゅう フォーカス');
cmd('pageMap', '頁の地図（紙面の右端の細い帯：頁・付箋・改頁・章・いま見ている所。押すとそこへ）', '表示', '', () => { st.pageMap = !st.pageMap; lsW('fz.pageMap', st.pageMap); pageMapKey = ''; drawPageMap(); drawFkeys(); }, 'ちず スクロール ミニマップ');
cmd('srcPane', '原本の面（カーソルの節の原本を右の欄で読み書き。打ち止めると紙面へ）', '表示', '', () => { if (st.mode === 'tree') exitMode(); toggleSide('src'); }, 'げんぽん ソース fzk テキスト');
cmd('compareDoc', 'ほかの文書と比べる…（違いを 1 つずつ見て取り込む・捨てる。今の文書は取り込むまで変わらない）', 'ファイル', '', async () => { try { const r = await FZ.files.open(); if (!r) return; await compareText(r.text, r.name); } catch (e) { msg('開けませんでした：' + e.message, true); } }, 'ひかく 対校 差分 diff');
cmd('tblSum', '表：合計の行（数の列を足した行を表の下に。表を直すたびに計算し直す。もう一度で外す）', '表', '', () => tblDo(() => { st.cells = null; const r = FZ.tbl.toggleSum(ed);
  if (r === 'none') msg('足せる数の列がありません（見出しの行のほかが、どれも数の列）', true); else if (r === 'add') msg('合計の行を足しました：表を直すたびに計算し直します（Ctrl+Z で戻る／もう一度で外す）'); else if (r === 'del') msg('合計の行を外しました（字は残り、もう計算し直しません）'); requestOverlay(); return r; }), '計算 足し算 総計 sum');
cmd('tblNumRight', '表：数の列を右揃え（見出しの行のほか。もう一度で左に戻す）', '表', '', () => tblDo(() => { st.cells = null; const r = FZ.tbl.numRight(ed); if (!r) msg('数の列がありません', true); else msg(r > 0 ? `数の列 ${r} 本を右揃えにしました（Ctrl+Z で戻る）` : `数の列 ${-r} 本を左揃えに戻しました`); return r; }), '数値 桁 右寄せ');
cmd('tr:del', '表：この行を削除', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteRow(ed); }));
cmd('tc:left', '表：左に列を挿入（今の列を半分に分ける）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertCol(ed, false); }));
cmd('tc:right', '表：右に列を挿入（今の列を半分に分ける）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.insertCol(ed, true); }));
cmd('tc:del', '表：この列を削除（幅は隣の列へ）', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteCol(ed); }));
cmd('tdel', '表を削除', '表', '', () => tblDo(() => { st.cells = null; return FZ.tbl.deleteTable(ed); }));
for (const [id, l] of [['light', '淡網'], ['gray', '薄網'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['none', 'なし']]) cmd('tcs:' + id, '表：セルの網を' + l + 'に', '表', '', () => cellsDo(R => FZ.tbl.fillCells(ed, R, id)));
for (const [al, l] of [['left', '左'], ['center', '中央'], ['right', '右']]) cmd('tca:' + al, '表：セルを' + l + '揃えに', '表', '', () => cellsDo(R => FZ.tbl.alignCells(ed, R, al)));
cmd('tcb', '表：セルの字を太字（切替）', '表', '', () => cellsDo(R => FZ.tbl.boldCells(ed, R)));
cmd('tcx', '表：セルの中身を消す（範囲を選んで Delete でも）', '表', '', () => cellsDo(R => { st.cells = null; FZ.tbl.clearCells(ed, R); }));
cmd('indent', 'レベルを深く（見出し・箇条書き。位置は変えない）', '構造', 'Tab', () => { if (!ed.indent(1)) msg('本文の行にはレベルがありません。位置を動かすのは ' + K('posRight') + '（右へ）／' + K('posLeft') + '（左へ）', true); });
cmd('outdent', 'レベルを浅く（見出し・箇条書き。位置は変えない）', '構造', 'Shift+Tab', () => { if (!ed.indent(-1)) msg('本文の行にはレベルがありません。位置を動かすのは ' + K('posLeft') + '（左へ）／' + K('posRight') + '（右へ）、Ctrl+Shift+M', true); });
/* 位置（見た目）：行頭の桁をレベルと独立に動かす。見出し・箇条書きは位置が固定され、レベルを変えても動かない（K で自動に戻す） */
cmd('posRight', '位置を右へ 1 桁（レベルは変えない）', '配置', 'Alt+Shift+→', () => { if (!ed.posShift(1)) msg('この行は位置を動かせません（表・図・目次・中央／右揃えの行）', true); }, '字下げ インデント 位置');
cmd('posLeft', '位置を左へ 1 桁（レベルは変えない）', '配置', 'Alt+Shift+← / Ctrl+Shift+M', () => { if (!ed.posShift(-1)) msg('この行は位置を動かせません（表・図・目次・中央／右揃えの行）', true); }, '字下げ インデント 位置');
cmd('posAuto', '位置を自動に戻す（見出し・箇条書きはレベルから決まる桁、本文は左端）', '配置', '', () => { if (!ed.posReset()) msg('位置は自動のままです'); }, '字下げ解除 インデント 位置');
cmd('restart', '番号を 1 から数え直す', '構造', '', () => ed.toggleAttr('restart', true));
cmd('pageBreak', 'ここから改頁（この行・節から新しい頁。もう一度で外す）', '構造', 'Ctrl+Enter', () => ed.toggleAttr('breakBefore', true));
cmd('keepLine', '段落をページで分割しない（繰り越す）', '配置', '', () => ed.toggleAttr('keep', 'line'));
/* 次と同頁：点灯は実際に効いているか。題（表題・記号見出し・題のレベル）は既定で効いていて、押すと「送らない」になる（K-12） */
const keepNextOn = a => a.keep === 'next' || (a.keep !== 'free' && ed.isTitleLike(a));
cmd('keepNext', '次の段落と同じページに置く（題の行では「送らない」の切替）', '配置', '', () => { const a = ed.line().attrs; if (ed.isTitleLike(a)) ed.setAttrs({ keep: a.keep === 'free' ? null : 'free' }); else ed.toggleAttr('keep', 'next'); msg(keepNextOn(ed.line().attrs) ? '次と同頁：効いています' : '次と同頁：外しました'); });
cmd('outlineUp', '節を上へ移動', 'アウトライン', 'Alt+↑', () => ed.moveSection(ed.caret.line, -1));
cmd('outlineDown', '節を下へ移動', 'アウトライン', 'Alt+↓', () => ed.moveSection(ed.caret.line, 1));
cmd('outlinePanel', 'ツリー（文書の構造を左から右へ広げて見る・並べ替える）切替', '表示', 'Ctrl+Shift+O', () => toggleTree(), 'アウトライン マインドマップ 構成 ツリー');
const tvSel = () => (st.mode === 'tree' ? treeSelected().filter(n => !n.root) : []);
cmd('tv:after', 'ツリー：弟を足す（同じ種類・レベル）', 'ツリー', 'Enter', () => { if (st.mode === 'tree') treeAdd('after'); });
cmd('tv:before', 'ツリー：兄を足す', 'ツリー', 'Shift+Enter', () => { if (st.mode === 'tree') treeAdd('before'); });
cmd('tv:child', 'ツリー：子を足す（節に寄せると出る ＋ でも）', 'ツリー', 'Tab', () => { if (st.mode === 'tree') treeAdd('child'); });
cmd('tv:del', 'ツリー：選んだ節を消す（子と本文ごと）', 'ツリー', 'Delete', () => { if (st.mode === 'tree') treeDelete(); });
cmd('tv:up', 'ツリー：兄弟の中で上へ（子と本文ごと。文は段落の中で）', 'ツリー', 'Alt+↑ / Ctrl+↑', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeMoveSent(treeNodeSel(), -1); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.shift(ed, st.tree.view.tr, n, -1)); });
cmd('tv:down', 'ツリー：兄弟の中で下へ', 'ツリー', 'Alt+↓ / Ctrl+↓', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeMoveSent(treeNodeSel(), 1); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.shift(ed, st.tree.view.tr, n, 1)); });
cmd('tv:out', 'ツリー：浅く（親の弟に。文は独立した段落に）', 'ツリー', 'Alt+← / Shift+Tab', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeSentToKind(treeNodeSel(), 'body'); return; } if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'body' && treeNodeSel().obj && treeNodeSel().obj.segs.length === 1) { treeParaUp(treeNodeSel()); return; } if (st.mode === 'tree') treeMoveSel((list, n) => (FZ.tree.levelExcess(n) > 0 && FZ.tree.levelShift(ed, n, -1)) || FZ.tree.promote(ed, st.tree.view.tr, n) || FZ.tree.levelShift(ed, n, -1)); });
cmd('tv:in', 'ツリー：深く（兄の末の子に）', 'ツリー', 'Alt+→ / Ctrl+→', () => { if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'sent') { treeSentToKind(treeNodeSel(), 'list'); return; } if (st.mode === 'tree' && treeNodeSel() && treeNodeSel().kind === 'body' && treeNodeSel().obj && treeNodeSel().obj.segs.length === 1) { treeParaDown(treeNodeSel()); return; } if (st.mode === 'tree') treeMoveSel((list, n) => FZ.tree.demote(ed, st.tree.view.tr, n) || FZ.tree.levelShift(ed, n, 1)); }); /* 入れる兄が無ければ段だけ深く */
cmd('tv:edit', 'ツリー：節の文字・図表の題を直す（ダブルクリックでも）', 'ツリー', 'Ctrl+Enter', () => { if (st.mode === 'tree') openTreeEdit(false); });
cmd('tv:fold', 'ツリー：畳む・開く', 'ツリー', 'Space', () => { if (st.mode !== 'tree') return; const n = treeNodeSel(); if (!n || !n.children.length) return; const k = treeKey(n); if (st.tree.folds.has(k)) st.tree.folds.delete(k); else st.tree.folds.add(k); render(); drawSub(); });
cmd('tv:paper', 'ツリーから紙面へ（選んだ節の頭に）', 'ツリー', 'Esc', () => exitTree());
for (const [k, l] of [['para', '段落を文ごとの段落にばらす'], ['list', '段落を箇条書きにばらす（1 文 1 項目）'], ['tree', '段落を親子にばらす（最初の文が親、残りが子の項目）'], ['merge', '選んだ節（または節と子）を 1 つの段落にまとめる']]) cmd('tvr:' + k, 'ツリー：' + l, 'ツリー', '', () => { if (st.mode !== 'tree') return; treeRegroup(k); }, 'ばらす まとめる 文 段落 箇条書き 親子');
cmd('tv:break', 'ツリー：この節から改頁（もう一度で外す）', 'ツリー', '', () => { if (st.mode === 'tree') treeToggleBreak(); }, '改頁 改ページ 頁 境目');
cmd('tvf:open', 'ツリー：図表をすべて表示（中身を見せる）', 'ツリー', '', () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) enterTree(); const tr = treeBuild(); for (const n of tr.figs) st.tree.show.add(treeShowKey(n)); for (const n of tr.nodes) if (treeShowable(n)) st.tree.show.add(treeShowKey(n)); st.tree.showAll = true; render(); drawSub(); treeScrollToSel(); }, '図表 表示 開く 一括');
cmd('tvf:toggle', 'ツリー：図表の中身を見せる・隠す', 'ツリー', '', () => run(st.tree.showAll ? 'tvf:close' : 'tvf:open'));
cmd('tvf:close', 'ツリー：図表をすべて閉じる（名前だけ）', 'ツリー', '', () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) return; st.tree.show.clear(); st.tree.showAll = false; render(); drawSub(); treeScrollToSel(); }, '図表 閉じる 一括');
for (const [d, l] of [[1, '1 段（いちばん上の見出し）まで'], [2, '2 段まで'], [3, '3 段まで'], [4, '4 段まで'], [9, 'すべての見出し・項目'], [0, '本文・表・囲みまで'], [-1, '文まで（段落を「。」ごとの文に分けて、並べ替え・直す）']]) cmd('tvd:' + d, 'ツリーの深さ：' + l + 'を一括で表示（畳みも解く）', 'ツリー', String(d), () => { if (st.mode !== 'tree' && (!st.view || st.view === 'paper')) enterTree(); treeSetDepth(d); }, 'ツリー 深さ レベル 階層 畳む 開く');
for (const [k, l] of [['num', '番号見出し'], ['sym', '記号見出し'], ['nlist', '番号箇条書き'], ['list', '記号箇条書き'], ['body', '本文'], ['title', '表題']]) cmd('tvk:' + k, 'ツリー：選んだ節を' + l + 'に', 'ツリー', '', () => treeSetKind(k));
/* 種類を変える：表題・番号見出し（num）・記号見出し（sym）・番号箇条書き（nlist）・記号箇条書き（list）・本文 */
function treeSetKind(kind0) { if (st.mode !== 'tree') return; const s0 = treeNodeSel(); if (s0 && s0.kind === 'sent') { treeSentToKind(s0, kind0); return; } /* 文の種類を変える：段落を割って取り出す */ const list = tvSel().filter(n => n.kind !== 'block' && n.kind !== 'fig'); if (!list.length) return; const key = st.tree.sel; const kind = kind0 === 'nlist' ? 'list' : kind0;
  ed.mutate('', () => { for (const n of list.sort((p, q) => q.line - p.line)) { const i = ed.doc.lines.indexOf(n.obj); if (i < 0) continue; const tr = FZ.tree.build(ed.doc, { body: true }); const nn = tr.byObj.get(n.obj); const lvl = kind === 'list' || kind === 'num' || kind === 'sym' ? (n.kind === kind ? n.level : nn && nn.parent && nn.parent.kind === kind ? Math.min(7, nn.parent.level + 1) : 0) : 0; FZ.tree.retype(ed, i, nn ? nn.end : i, { kind, level: lvl });
    const a = ed.doc.lines[i].attrs; if (kind === 'list' && a.list) { if (kind0 === 'nlist') a.list = { ...a.list, kind: 'num' }; else if (a.list.kind === 'num') { const l2 = { ...a.list }; delete l2.kind; a.list = l2; } } } });
  st.tree.sel = key; treeRefresh(); }
/* 節の種類の名前（箱の右端に出す）と、帯の「種類」の値 */
function treeKindOf(n) { if (!n || n.root) return ''; if (n.kind === 'list') return n.obj && n.obj.attrs.list && n.obj.attrs.list.kind === 'num' ? 'nlist' : 'list'; return n.kind; }
function treeKindLabel(n) { const k = treeKindOf(n); const lv = (n.level | 0) + 1; if (k === 'block') return /^［([^］]+)］/.test(n.text) ? n.text.match(/^［([^］]+)］/)[1] : '塊'; const lk = n.obj && n.obj.attrs.list && n.obj.attrs.list.kind;
  return { title: '表題', num: '番号見出し' + lv, sym: '記号見出し' + lv, nlist: '番号箇条書き' + lv, list: (lk === 'arrow' ? '矢印' : lk === 'todo' || lk === 'done' ? '課題' : '記号箇条書き') + lv, body: '本文' }[k] || ''; }
/* 番号・記号の形（体系）：選んだ節の種類とレベルの段。同じ種類・同じ段のものすべてに効く */
const TREE_SCH = { num: ['scheme', null, '番号見出し'], sym: ['symScheme', 'DEFAULT_SYM', '記号見出し'], nlist: ['listScheme', 'DEFAULT_LIST', '番号箇条書き'], list: ['bulletScheme', 'DEFAULT_BULLET', '記号箇条書き'] };
function treeMarkerChoices(k) { if (k === 'num' || k === 'nlist') return FZ.NUMBER_KEYS.slice(); const set = [...(k === 'list' ? FZ.DEFAULT_BULLET : FZ.DEFAULT_SYM), ...FZ.SYMBOL_PRESETS]; return [...new Set(set), FZ.NONE_TOKEN]; }
function treeMarkerNow(n) { const k = treeKindOf(n); const d = TREE_SCH[k]; if (!d) return null; const arr = FZ.normalizeScheme(ed.doc.format[d[0]], d[1] ? FZ[d[1]] : FZ.DEFAULT_SCHEME); return { k, lv: clamp(n.level | 0, 0, 7), tok: arr[clamp(n.level | 0, 0, 7)], arr, field: d[0], name: d[2] }; }
function treeSetMarker(tok) { const n = treeNodeSel(); const m = n && treeMarkerNow(n); if (!m || !tok || tok === m.tok) return; const key = st.tree.sel;
  ed.mutate('', () => { const arr = m.arr.slice(); arr[m.lv] = tok; ed.doc.format = { ...ed.doc.format, [m.field]: FZ.normalizeScheme(arr, m.field === 'scheme' ? FZ.DEFAULT_SCHEME : FZ[TREE_SCH[m.k][1]]) }; });
  st.tree.sel = key; treeRefresh(); msg(`${m.name}${m.lv + 1} の形を「${tok}」にしました（同じ段のものすべて。Ctrl+Z で戻す。全体は ${K('scheme')}）`); }
cmd('zoomIn', '拡大', '表示', 'Ctrl++', () => zoomStep(1));
cmd('zoomOut', '縮小', '表示', 'Ctrl+-', () => zoomStep(-1));
cmd('zoomFit', '幅に合わせる（ツリーでは等倍）', '表示', 'Ctrl+0', () => { if (st.mode === 'tree') { treeZoom(0); return; } st.zoom = 'width'; render(); });
cmd('zoomPage', '高さに合わせる（ページ全体）', '表示', 'Ctrl+Shift+0', () => { if (st.mode === 'tree') { treeZoom(0); return; } st.zoom = 'page'; render(); });
cmd('zoomPct', '表示倍率（％）…', '表示', '', () => openForm('zoom'), 'ズーム');
cmd('grid', '方眼の表示切替（字の目・版面・両方は F10「方眼▾」で）', '表示', 'Ctrl+Shift+G', () => { st.grid = !st.grid; if (st.grid && !st.gridMode) st.gridMode = 'dots'; pageCache = pageCache.map(() => ''); render(); });
cmd('landscape', '用紙の縦横を入れ替える', '書式', '', () => { ed.mutate('', () => { const f = ed.doc.format; [f.widthMm, f.heightMm] = [f.heightMm, f.widthMm]; f.landscape = f.widthMm > f.heightMm; }); });
cmd('fontMincho', '本文を明朝で組む', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'mincho'; }));
cmd('fontGothic', '本文をゴシックで組む', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'gothic'; }));
cmd('fontSystem', '本文書体：システム書体', '書式', '', () => ed.mutate('', () => { ed.doc.format.font = 'system'; }));
cmd('exitMode', '本文へ戻る', '網掛け（範囲）', 'Esc', exitMode);
/* 網掛けモードの文様：F1〜F5 は従来の 5 つ、ほかは帯の見本の 1 文字（SWATCH_KEY） */
const SWATCH_KEY = { light: '1', gray: '2', mid: '3', deep: '4', dark: '5', hatch: '6', hatch2: '7', horz: '8', vert: '9', grid: '0', check: 'Q', dots: 'W', wide: 'E', ink: 'R' };
const FILL_FK = { gray: 'F1', dark: 'F2', hatch: 'F3', dots: 'F4', none: 'F5' };
for (const sh of FZ.SHADES.filter(x => x.id !== 'text').concat([{ id: 'none', label: '網掛けを消す' }])) cmd('s:' + sh.id, '網掛け：' + sh.label, '網掛け（範囲）', '（網掛け）' + [FILL_FK[sh.id], SWATCH_KEY[sh.id]].filter(Boolean).join(' / '), () => { st.shade = sh.id; if (st.mode !== 'fill') enterFillMode(); drawFkeys(); drawSub(); status(); }, '文様 パターン');
/* 見本の小さな絵（帯・欄で文様を選ぶとき） */
function swatch(id, size = 14) { const sh = FZ.SHADE_BY[id]; if (!sh) return `<svg class="sw" width="${size}" height="${size}" viewBox="0 0 14 14"><rect x=".5" y=".5" width="13" height="13" fill="#fff" stroke="#000"/><path d="M3 3l8 8M11 3l-8 8" stroke="#000"/></svg>`;
  const pid = 'swp_' + id; return `<svg class="sw" width="${size}" height="${size}" viewBox="0 0 14 14"><defs>${FZ.patternDefFor(sh, pid)}</defs><rect x=".5" y=".5" width="13" height="13" fill="url(#${pid})" stroke="#000"/></svg>`; }
function run(id) { const c = CMDS.find(c => c.id === id); if (!c) return; if (st.rec && !st.toolPlaying && !st.runDepth && !REC_SKIP.has(id) && id !== 'tools' && id !== 'recToggle') recPush({ cmd: id }); st.runDepth = (st.runDepth || 0) + 1; try { return runInner(c); } finally { st.runDepth--; } }
function runInner(c) { if (st.mode !== 'tree') return c.fn(); treeBeforeCmd(c); if (st.mode !== 'tree') return c.fn(); st.treeCmd = true; try { return c.fn(); } finally { st.treeCmd = false; } } /* 戻り値はコマンドのもの（書き出しは Promise） */
/* ツリーでコマンドを使う：対象は選んだ節の行（カーソルをその行に。文字のコマンドは行の文字全体を選ぶ）。紙面でしかできないものは、その節の所で紙面に移ってから */
const TREE_OWN = /^(tv|tvd|tvk|tvf|tvs|sx)[:]|^(moveTo|checkStruct|sentOpt|park|zoom|outlinePanel|viewGroup|fileGroup|editGroup|marks|structGroup|exportTree|selSent|aiCopy|aiReturn|panels|lineGroup|insertGroup|decorGroup|fmtGroup|help|palette|undo|redo|save|saveAs|open|new|kindDoc|kindSlide|grid)/;
const TREE_PAPER = new Set(['fillMode', 'tableMenu', 'figInsert', 'replace', 'findNext', 'findPrev', 'link', 'headGroup', 'tableGroup', 'teditGroup', 'speech']); /* 印刷はツリーのまま（ツリーだけを見ている時はツリーの姿で刷る。1.0.10u） */
function treeBeforeCmd(c) {
  if (TREE_OWN.test(c.id)) return; const n = treeNodeSel(); const i = n && n.obj ? ed.doc.lines.indexOf(n.obj) : -1;
  if (i >= 0) { const ln = ed.doc.lines[i]; const ls = ln.segs.length - 1; ed.caret = { line: i, seg: ls, off: ln.segs[ls].text.length, vcol: null, vrow: 0 }; ed.anchor = c.group === '文字' && (ln.segs.length > 1 || ln.segs[0].text) ? { line: i, seg: 0, off: 0 } : null; }
  if (TREE_PAPER.has(c.id) || c.group === '網掛け（範囲）') { exitTree(); if (i >= 0) ed.setCaret({ line: i, seg: 0, off: 0 }); msg('紙面で続けます（Ctrl+Shift+O でツリーに戻る）', false, 5000); } }
function baseTitle() { return (ed.doc.title || (st.file && st.file.name.replace(/\.[^.]+$/, '')) || '文書').replace(/[\\/:*?"<>|]/g, '_'); }
/* ---------- メニュー：F キー（キートップ）と子メニュー（ピクトグラムのタイル） ----------
 * 分類の原則：文字（字の見た目）→ 段落（行の種類）→ 配置（行の置き場所）→ 挿入（ものを入れる）→ 罫線・飾り（線と飾り）→ 書式（文書全体の決まり）→ 表示（画面だけ）。
 * F キー 1 つ＝グループ 1 つ。押すとそのグループのタイルが右に並ぶ。タイルはクリックで実行（1.0.10u で項目の文字キー〔構え〕はやめた）。
 * 印刷・保存はファイルの中（Ctrl+P／Ctrl+S。旧来の F12 も保存として効く）。キーの一覧（使い方・コマンド一覧）はこの表から作る */
const FK = {
  text: [['F1', 'ガイド', 'help'], ['F2', 'ファイル', 'fileGroup'], ['F3', '編集', 'editGroup'], ['F4', '構造', 'structGroup'], ['F5', '文字', 'marks'], ['F6', '配置', 'lineGroup'], ['F7', '挿入', 'insertGroup'], ['F8', '表', 'tableMenu'], ['F9', '書式', 'fmtGroup'], ['F10', '表示', 'viewGroup']],
  fig: [['F1', '箱', 'fg:add'], ['F2', '文字', 'fg:text'], ['F3', '矢印', 'fg:connect'], ['F4', '削除', 'fg:delete'], ['F5', '複製', 'fg:dup'], ['F6', '箱の\n設定…', 'fg:props'], ['F7', 'レーン…', 'fg:lanes'], ['F8', '高さ＋', 'fg:taller'], ['F9', '高さ−', 'fg:shorter'], ['F10', 'ガイド', 'help'], ['Esc', '本文へ', 'exitMode']],
  tree: [['F1', 'ガイド', 'help'], ['F2', '文字', 'tv:edit'], ['F3', '弟', 'tv:after'], ['F4', '子', 'tv:child'], ['F5', '上へ', 'tv:up'], ['F6', '下へ', 'tv:down'], ['F7', '浅く', 'tv:out'], ['F8', '深く', 'tv:in'], ['F9', '畳む', 'tv:fold'], ['F10', 'ガイド', 'help'], ['Esc', '紙面へ', 'tv:paper']],
  fill: [['F1', '薄', 's:gray'], ['F2', '濃', 's:dark'], ['F3', '斜線', 's:hatch'], ['F4', '点', 's:dots'], ['F5', '消す', 's:none'], ['F6', '', ''], ['F7', '', ''], ['F8', '', ''], ['F9', '', ''], ['F10', 'ガイド', 'help'], ['Esc', '本文へ', 'exitMode']],
};
const FK_HIDDEN = { F12: 'save' }; // 表には出さない（保存の本線は Ctrl+S）
const GROUP_OF = { fileGroup: 'file', editGroup: 'edit', structGroup: 'struct', marks: 'marks', lineGroup: 'line', insertGroup: 'insert', tableMenu: 'tedit', fmtGroup: 'fmt', viewGroup: 'view' };
const SUBGROUP_OF = { headGroup: 'head', tableGroup: 'table', teditGroup: 'tedit', pufuGroup: 'pufu', pufuAiGroup: 'pufuAi' };
/* フォームを開いたら、そのフォームの属するグループを子メニューに出す（閉じた後に関連の項目が並ぶ） */
const FORM_GROUP = { headFill: 'table', shadeType: 'marks', scale: 'marks', count: 'edit', format: 'fmt', scheme: 'fmt', slide: 'fmt', find: 'edit', replace: 'edit', table: 'insert', toc: 'insert', fig: 'insert', chart: 'insert', figtree: 'insert', tfind: 'edit', moveTo: 'struct', scheck: 'edit', sentopt: 'fmt', secref: 'insert', skeleton: 'insert', parked: 'struct', figref: 'insert', link: 'marks', speech: 'line', marker: 'fmt', newdoc: 'file', tplname: 'file', aiback: 'file', panels: 'line', zoom: 'view' };
function drawFkeys() {
  const mode = st.mode === 'fill' ? 'fill' : st.mode === 'rule' ? 'rule' : st.mode === 'fig' ? 'fig' : 'text'; const map = FK[mode]; /* ツリーも紙面と同じ F キー */
  const onMap = { ['k:' + st.ruleKind]: st.mode === 'rule', ['s:' + st.shade]: st.mode === 'fill', erase: st.sub === 'erase', rect: st.sub === 'rect' && st.mode === 'rule', table: st.form === 'table' && mode === 'rule', help: st.side === 'help', palette: st.side === 'palette' && mode !== 'text' };
  if (mode === 'text') { const g = GROUPS[st.group]; const sg = g && g.parent ? g.parent : st.group; for (const [id, gn] of Object.entries(GROUP_OF)) if (gn === sg) onMap[id] = true; }
  $('fkeys').classList.toggle('wesc', map.some(x => x[0] === 'Esc')); /* 1.0.15g 2 段の F キー：Esc は左に 2 段ぬき */
  $('fkeys').innerHTML = map.map(([k, l, id]) => { const on = !!onMap[id]; const armed = on && st.armed && !!GROUP_OF[id]; const c = cmdById(id);
    const pane = id === 'help' || id === 'palette'; // 右の欄の開閉は点灯（黒地）ではなく下の太線で示す。黒地は今のグループだけ
    return `<div class="fk${on ? (pane ? ' pon' : ' on') : ''}${armed ? ' armed' : ''}${!id ? ' dim' : ''}${k === 'Esc' ? ' esc' : ''}" data-cmd="${id}" role="button" aria-label="${esc(k + ' ' + (l || '').replace(/\n/g, ''))}"${c ? ` title="${esc(c.label + '（同じ F キーを続けて 2 回で、帯の項目をキーで選ぶ）')}"` : ''}><span class="k">${k}</span><span class="l">${l ? (l.includes('\n') ? esc(l).replace('\n', '<br>') : [...l].length >= 3 ? nar(l, 12.5, [...l].length >= 4 ? 0.7 : 0.8) : esc(l)) : '&nbsp;'}</span></div>`; }).join('');
}
$('fkeys').addEventListener('pointerdown', e => { const d = e.target.closest('.fk'); if (!d || !d.dataset.cmd) return; e.preventDefault(); run(d.dataset.cmd); });
/* ---------- 子メニュー（グループ／フォーム／ヒント） ---------- */
const A = () => ed.line().attrs, L = () => ed.line().attrs.list;
function isOn(bit) { if (bit === M.BOLD && ed.isTitleLike(ed.line().attrs)) return !ed.line().attrs.thin; const s = ed.sel(); return s ? ed.allMarked(s, bit) : !!(ed.typing & bit); } // 題の行の太字は行の見た目（細字でなければ点灯）
/* 項目：{ cl: 塊の名前 } で塊を切る。key＝旧・構えの 1 文字（いまは試験の読み替え tools/fkey-shim.js だけが使う）、short＝タイルの名前（無ければ label）、icon＝ピクトグラム（無ければ cmd の名前） */
/* 排他の選択はプルダウン：状態を選んで置いておくもの（倍率・ツリーの深さ・図表・形・書体・向き）。範囲にかける操作（揃え・種類・網）はボタンのまま。
   メニューの項目 { key, msel: 名前 }。cmds＝道筋（F キーと「名前▾」）を載せるコマンド */
const pct = v => Math.round(v * 100) + '%';
const MSEL = {
  zoom: { label: '倍率', cmds: ['zoomFit', 'zoomPage', 'zoomPct'], tip: () => st.mode === 'tree' ? 'ツリーの倍率（Ctrl+ホイール・＋／−でも）' : '紙面の倍率（Ctrl+ホイール・Ctrl+＋／−でも）',
    opts: () => { if (st.mode === 'tree') return TREE_SCALES.map(v => [v, v === 1 ? '等倍' : pct(v)]); const o = [['width', '幅に合わせる'], ['page', 'ページ全体'], ...[0.5, 0.75, 1, 1.25, 1.5, 2].map(v => [v, pct(v)])]; if (typeof st.zoom === 'number' && !o.some(x => x[0] === st.zoom)) o.push([st.zoom, pct(st.zoom)]); o.push(['pct', '指定…', 1]); return o; },
    val: () => st.mode === 'tree' ? st.tree.scale : st.zoom,
    set: v => { if (st.mode === 'tree') { st.tree.scale = +v; try { localStorage.setItem('fz.treeScale', String(st.tree.scale)); } catch (e) { /* 覚えられなくても動く */ } render(); return; } if (v === 'pct') { run('zoomPct'); return; } st.zoom = v === 'width' || v === 'page' ? v : +v; render(); } },
  depth: { label: '深さ', cmds: Object.keys({ 'tvd:1': 1, 'tvd:2': 1, 'tvd:3': 1, 'tvd:9': 1, 'tvd:0': 1, 'tvd:-1': 1 }), tip: () => 'ツリーの深さ（文書全体を一度に開く・畳む）：1〜3 段・全段（すべての見出し・項目）・本文まで・文まで', bare: 1, opts: () => [[1, '1段'], [2, '2段'], [3, '3段'], [9, '全段'], [0, '本文'], [-1, '文']], val: () => st.tree.depth, set: v => run('tvd:' + v) },
  figs: { label: '図表', cmds: ['tvf:open', 'tvf:close'], bare: 1, tip: () => 'ツリーの図表：図題＝題だけ／図中身＝中身も見せる（1 つずつは図表の節の「表示」で）', opts: () => { const o = [['close', '図題'], ['open', '図中身']]; if (!st.tree.showAll && st.tree.show.size) o.unshift(['', '図一部', 1]); return o; }, val: () => st.tree.showAll ? 'open' : st.tree.show.size ? '' : 'close', set: v => { if (v) run('tvf:' + v); } },
  font: { label: '書体', cmds: ['fontMincho', 'fontGothic'], tip: () => '本文の書体（文書全体）', opts: () => [['mincho', '明朝'], ['gothic', 'ゴシック']], val: () => ed.doc.format.font === 'gothic' ? 'gothic' : 'mincho', set: v => run(v === 'gothic' ? 'fontGothic' : 'fontMincho') },
  narrow: { label: '字幅', cmds: [], tip: () => '長体：字の幅を 90%・75%・50% に（選んだ字、選ばなければこの後に打つ字。横倍角と重なれば倍角が優先）', opts: () => [['0', '100%'], ['1', '90%'], ['2', '75%'], ['3', '50%']],
    val: () => { const s0 = ed.sel(); let mk = ed.typing | 0; if (s0) { let v = null; ed.forEachMark(s0, m => { if (v == null) v = m; return m; }, true); mk = v | 0; } return String((mk & FZ.M.NAR) >>> 28); },
    set: v => { const k = +v | 0; ed.mapMarks(m => (m & ~FZ.M.NAR) | (k << 28)); render(); msg(k ? '長体 ' + ['', '90', '75', '50'][k] + '%' : '字幅を元に'); } },
  gridMode: { label: '方眼', cmds: ['grid'], tip: () => '方眼（画面だけ・印刷に出ない）：字の目＝マスの角の点、版面＝版面の枠・柱の欄・字と行の目盛・余白の mm、両方', opts: () => [['off', 'なし'], ['dots', '字の目'], ['frame', '版面'], ['all', '両方']], val: () => st.grid ? (st.gridMode || 'dots') : 'off',
    set: v => { if (v === 'off') st.grid = false; else { st.grid = true; st.gridMode = v; } try { localStorage.setItem('fz.gridMode', st.grid ? st.gridMode : 'off'); } catch { } pageCache = pageCache.map(() => ''); render(); } },
  printLayer: { label: '刷る', cmds: [], tip: () => '刷るもの（印刷・PDF）：紙だけ（本文の字・罫・網）／手当ても（付箋の番号を朱で余白に、中身を最後の頁に。レビュー用の刷り）', opts: () => [['paper', '紙だけ'], ['care', '手当ても']], val: () => printLayer, set: v => { printLayer = v === 'care' ? 'care' : 'paper'; try { localStorage.setItem('fz.printLayer', printLayer); } catch { } drawSub(); msg(printLayer === 'care' ? '刷るとき付箋も刷り込みます（番号を余白に朱で、中身を最後の頁に）' : '刷るのは紙だけ（手当ては刷りません）'); } },
  pufuForm: { label: '形', cmds: ['pufuFormAuto', 'pufuFormTree', 'pufuFormCols'], tip: () => `プ譜の紙面の形（いまは${pufuFormIs() === 'cols' ? '列の図' : '字下げ'}）：自動＝横長の紙面・広い版面なら列の図`, opts: () => [['auto', '自動'], ['tree', '字下げ'], ['cols', '列の図']], val: () => pufuFormOf(), set: v => pufuForm(v) },
  orient: { label: '向き', cmds: ['landscape'], tip: () => '用紙の向き（縦長・横長）', opts: () => [['p', '縦長'], ['l', '横長']], val: () => ed.doc.format.landscape ? 'l' : 'p', set: v => { if ((v === 'l') !== !!ed.doc.format.landscape) run('landscape'); } } };
function mselHtml(it, noKey) { const M = MSEL[it.msel]; const o = M.opts(); const cur = String(M.val()); const kk = '';
  const list = o.some(x => String(x[0]) === cur) ? o : [[cur, '—'], ...o];
  return `<label class="ms" title="${esc(M.tip() + (kk ? `　［${kk}］で次へ` : ''))}">${M.bare ? '' : `<span class="ml">${esc(M.label)}</span>`}<select id="ms_${it.msel}" data-msel="${it.msel}">${list.map(([v, l]) => `<option value="${esc(String(v))}"${String(v) === cur ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>${kk ? `<span class="k${[...kk].length > 1 ? ' w' : ''}"><b>${esc(kk)}</b></span>` : ''}</label>`; }
/* 段のボタン：L1・L2・L3・L全・本文・単文（どれも 2 字）を 2 段×3 列に詰める（ツリーの深さ） */
const SEGD = { depth: { tip: 'ツリーの段数（文書全体を一度に開く・畳む）', opts: [[1, 'L1', '1 段（いちばん上の見出し）まで'], [2, 'L2', '2 段まで'], [3, 'L3', '3 段まで'], [9, 'L全', 'すべての見出し・項目'], [0, '本文', '本文・表・囲みまで'], [-1, '単文', '文まで（段落を文ごとに）']], val: () => st.tree.depth, cmd: v => 'tvd:' + v } };
function segdHtml(it) { const D = SEGD[it.segd]; const cur = String(D.val()); return `<span class="segd" title="${esc(D.tip)}">${D.opts.map(([v, l, tip]) => `<span class="ch mini${String(v) === cur ? ' on' : ''}" data-cmd="${D.cmd(v)}" title="${esc(tip)}"><span class="lb">${esc(l)}</span></span>`).join('')}</span>`; }
function clusterHtml(c, noKey) { if (c.items.some(i => i.segd)) return `<div class="cl">${c.label ? `<span class="cll" title="${esc(c.label)}">${esc(c.label)}</span>` : ''}<div class="cg">${c.items.map(i => i.segd ? segdHtml(i) : i.msel ? mselHtml(i, noKey) : tile(i)).join('')}</div></div>`;
  const t = c.items.filter(i => !i.msel), m = c.items.filter(i => i.msel); const lab = c.label ? `<span class="cll" title="${esc(c.label)}">${esc(c.label)}</span>` : ''; /* グループの名前：横書きで左上に小さく */
  if (t.length && m.length && t.length % 2) return `<div class="cl">${lab}<div class="cg mix">${c.items.map(i => i.msel ? mselHtml(i, noKey) : tile(i)).join('')}</div></div>`; // タイルが奇数なら空いた段にプルダウンを詰める
  return `<div class="cl">${lab}${t.length ? `<div class="cg${c.cols ? ' rows' : ''}"${c.cols ? ` style="grid-template-columns:repeat(${c.cols},auto)"` : ''}>${t.map(tile).join('')}</div>` : ''}${m.length ? `<div class="sg">${m.map(i => mselHtml(i, noKey)).join('')}</div>` : ''}</div>`; }
/* 構えのキー・クリックで項目を実行：プルダウンは次の値へ（「指定…」「一部だけ」は飛ばす） */
function runItem(it) { if (!it.msel) { run(it.cmd); return; } const M = MSEL[it.msel]; const o = M.opts().filter(x => !x[2]); const i = o.findIndex(x => String(x[0]) === String(M.val())); const nx = o[(i + 1) % o.length]; M.set(String(nx[0])); msg(M.label + '：' + nx[1]); }
const GROUPS = {
  file: { title: 'ファイル', items: [{ cl: '文書' }, { key: 'N', label: '新規…', short: '新規', cmd: 'new', icon: 'new' }, { key: 'I', label: 'はじめの一枚（10 分で 1 枚を書き上げる練習）', short: '一枚', cmd: 'practice', icon: 'skeleton' }, { key: 'D', label: '新しい資料', short: '資料', cmd: 'newSlide', icon: 'slideNew' }, { key: 'O', label: '開く…', short: '開く', cmd: 'open', icon: 'open' }, { key: 'L', label: '文庫…（最近の文書・お気に入り・文書をまたいで探す）', short: '文庫', cmd: 'library', icon: 'drawer', on: () => st.side === 'drawer' && st.drawerTab === 'lib' }, { key: 'E', label: 'ほかの文書と比べる…（違いを 1 つずつ取り込む・捨てる）', short: '比べる', cmd: 'compareDoc', icon: 'compare' }, { key: 'S', label: '保存', cmd: 'save', icon: 'save' }, { key: 'A', label: '名前を付けて保存…', short: '別名保存', cmd: 'saveAs', icon: 'saveAs' }, { key: 'P', label: '印刷・PDF', short: '印刷', cmd: 'print', icon: 'print' },
    { cl: '人に渡す' }, { label: 'HTML（紙面のまま。社内の掲示・Web に。印刷もできる）', short: 'HTML', cmd: 'exportHtml', icon: 'html' }, { label: 'PDF（紙面のまま。正式な提出に）', short: 'PDF', cmd: 'exportPdf', icon: 'pdf' }, { key: '1', label: 'Word（資料は紙面のまま）', short: 'Word', cmd: 'exportDocx', icon: 'word' }, { label: 'Word（構成：見出しと本文の流れ。資料を Word で書き直す時に）', short: 'Word構成', cmd: 'exportDocxFlow', icon: 'word' }, { key: '2', label: 'PowerPoint', short: 'PPT', cmd: 'exportPptx', icon: 'pptx' }, { key: '4', label: 'テキスト', short: 'TXT', cmd: 'exportTxt', icon: 'txt' },
    { cl: 'AI' }, { key: 'Q', label: 'AI に頼む…（下読み・校正・議事録・要点。部品棚から依頼を組み立てて写す）', short: '頼む', cmd: 'askAI', icon: 'ask', on: () => st.side === 'request' }, { key: 'C', label: 'この節を Markdown で写す（貼り付け用）', short: '節を写す', cmd: 'aiCopySec', icon: 'aiSec' }, { key: 'V', label: '文書全体を Markdown で写す（貼り付け用）', short: '全体写す', cmd: 'aiCopyDoc', icon: 'aiDoc' }, { key: 'R', label: 'AI から戻す…（直してもらった Markdown を貼って、違う所を 1 つずつ取り込む）', short: '差分取込', cmd: 'aiReturn', icon: 'aiBack', on: () => st.form === 'aiback' }, { key: '3', label: 'Markdown ファイルに書き出す', short: 'MD', cmd: 'exportMd', icon: 'md' },
    { cl: 'ほか' }, { key: 'G', label: 'Word を取り込む…（.docx の見出し・箇条書き・表から構造を起こす）', short: 'Word取込', cmd: 'importDocx', icon: 'word' }, { key: 'J', label: 'PowerPoint を取り込む…（.pptx のスライドを資料の頁に。横に並んだ図形は区画）', short: 'PPT取込', cmd: 'importPptx', icon: 'pptx' }, { key: 'W', label: '新しい窓', short: '新窓', cmd: 'newWindow', icon: 'newWin' }, { key: 'H', label: '版の履歴…', short: '履歴', cmd: 'history', icon: 'history', on: () => st.side === 'hist' }, { label: '変換の記録…（書き出し・取り込みで近似になった所・入らなかった所）', short: '変換記録', cmd: 'convLog', icon: 'check', on: () => st.side === 'conv' }, { key: 'B', label: 'ここから先を別の文書に…', short: '分割', cmd: 'splitDoc', icon: 'split' }, { key: 'T', label: 'テンプレート保存…', short: '雛形', cmd: 'tplSave', icon: 'tpl' } ] },
  edit: { title: '編集', items: [{ cl: '戻す' }, { key: 'Z', label: '元に戻す', short: '戻す', cmd: 'undo', icon: 'undo' }, { key: 'Y', label: 'やり直す', short: 'やり直し', cmd: 'redo', icon: 'redo' },
    { cl: '探す' }, { key: 'F', label: '検索・置換…', short: '検索', cmd: 'find', icon: 'find', on: () => st.form === 'find' || st.form === 'replace' }, { key: 'A', label: 'すべて選択', short: '全選択', cmd: 'selectAll', icon: 'selAll' }, { key: 'Q', label: '文を選ぶ（Ctrl+クリックでも）', short: '文選択', cmd: 'selSent', icon: 'sentSel' },
    { cl: '整える' }, { key: 'V', label: '貼り直し（MD 整形・Excel は図に）', short: '貼り直し', cmd: 'pasteMd', icon: 'pasteMd' }, { key: 'C', label: '字数を数える…', short: '字数', cmd: 'count', icon: 'count', on: () => st.form === 'count' }, { key: 'K', label: '構造の点検…（子が 1 つ・中身なし・長い文・文末の不統一・段の飛び）', short: '点検', cmd: 'checkStruct', icon: 'check', on: () => st.form === 'scheck' }, { key: 'D', label: '文書の健康診断（規模・構造・参照切れ・付箋・表記の決まり・構成の型。行を選ぶとその所へ、直す・無視する）', short: '診断', cmd: 'health', icon: 'health', on: () => st.side === 'health' },
    { cl: '付箋' }, { label: '付箋を付ける（Ctrl+Alt+M）', short: '付ける', cmd: 'noteAdd', icon: 'noteAdd' }, { label: '付箋の一覧', short: '一覧', cmd: 'noteList', icon: 'noteList', on: () => st.side === 'notes' },
    { cl: '救済' }, { key: 'R', label: 'ローマ字をかなに', short: 'かな化', cmd: 'romaji', icon: 'romaji' }, { key: 'B', label: '** を太字に', short: '**太字', cmd: 'mdStars', icon: 'stars' }, { key: 'J', label: '和文の番号を起こす（「1.」「（1）」などを見出し・箇条書きに）', short: '番号化', cmd: 'jaLift', icon: 'jaLift', on: () => st.jaLift },
    { cl: '保留' }, { key: 'P', label: '保留へ送る（文書の外へ退避。書き出しに出ない）', short: '保留', cmd: 'park', icon: 'park' }, { key: 'O', label: '保留の島…（退避した節・文を戻す）', short: '保留島', cmd: 'parkList', icon: 'parkList', on: () => st.form === 'parked' }] },
  struct: { title: '構造', items: [{ cl: '種類' }, { key: '1', label: '本文', cmd: 'styleBody', icon: 'body', on: () => !A().style && !A().list }, { key: '2', label: '表題', cmd: 'styleTitle', icon: 'title', on: () => A().style === 'title' }, { key: '3', label: '番号見出し', short: '番号見出', cmd: 'styleNum', icon: 'numHead', on: () => A().style === 'num' }, { key: '4', label: '記号見出し', short: '記号見出', cmd: 'styleSym', icon: 'symHead', on: () => A().style === 'sym' }, { key: '5', label: '箇条書き', short: '箇条', cmd: 'item', icon: 'bullet', on: () => !!L() && !['num', 'arrow', 'todo', 'done'].includes(L().kind) }, { key: 'N', label: '番号付き箇条書き', short: '番号箇条', cmd: 'numItem', icon: 'numItem', on: () => L() && L().kind === 'num' }, { key: 'E', label: '結論', cmd: 'arrow', icon: 'arrow', on: () => L() && L().kind === 'arrow' }, { key: 'R', label: '課題', cmd: 'todo', icon: 'todo', on: () => L() && (L().kind === 'todo' || L().kind === 'done') }, { key: 'D', label: '完了', cmd: 'done', icon: 'done', on: () => L() && L().kind === 'done' },
    { cl: '段', cols: 2 }, { key: 'S', label: '上げる（Alt+←。文→段落→見出し、見出し・箇条書きは浅く）', short: '上げ', cmd: 'sx:out', icon: 'sxOut' }, { key: 'A', label: '下げる（Alt+→。段落→前の段落の文、文→箇条書き、見出し・箇条書きは深く）', short: '下げ', cmd: 'sx:in', icon: 'sxIn' }, { key: 'I', label: '上へ（Alt+↑。子と本文ごと。文は段落の中で）', short: '上へ', cmd: 'sx:up', icon: 'tUp' }, { key: 'K', label: '下へ（Alt+↓）', short: '下へ', cmd: 'sx:down', icon: 'tDown' }, { key: 'J', label: '番号再開', short: '再開', cmd: 'restart', icon: 'restart', on: () => !!A().restart }, { key: 'V', label: '送り先を選んで移す…（Ctrl+M）', short: '移す', cmd: 'moveTo', icon: 'moveTo', on: () => st.form === 'moveTo' },
    { cl: '文の組替' }, { key: 'G', label: '段落を文ごとの段落にばらす', short: '文→段落', cmd: 'sx:re:para', icon: 'reSplit' }, { key: 'L', label: '段落を箇条書きにばらす（1 文 1 項目）', short: '文→箇条', cmd: 'sx:re:list', icon: 'reList' }, { key: 'H', label: '段落を親子にばらす（最初の文が親）', short: '文→親子', cmd: 'sx:re:tree', icon: 'reTree' }, { key: 'M', label: 'まとめる（選んだ行・節と子を 1 つの段落に）', short: '1段落に', cmd: 'sx:re:merge', icon: 'reMerge' }, { label: '構成を試す…（本文はそのまま、節の順番と親子だけの試案。元の案と行き来して採る・捨てる）', short: '構成試案', cmd: 'trial', icon: 'reTree', on: () => !!st.trial },
    { cl: 'ﾂﾘｰ' }, { segd: 'depth' }, { label: '図表の中身を見せる（ツリーで、表・グラフ・図を縮小して見せる）', short: '図中身', cmd: 'tvf:toggle', icon: 'chart', on: () => !!st.tree.showAll }] }, // 表示（F10）のツリーの項目もここに：構造を直しながら深さ・図表・形を切り替える
  marks: { title: '文字', items: [{ cl: '修飾' }, { key: '1', label: '太字', cmd: 'bold', on: () => isOn(M.BOLD) }, { key: '2', label: '下線', cmd: 'under', on: () => isOn(M.UNDER) }, { key: '3', label: '傍点', cmd: 'dot', on: () => isOn(M.DOT) }, { key: '4', label: '網掛け', short: '網掛', cmd: 'shade', on: () => isOn(M.SHADE) }, { key: '5', label: '白抜き', short: '白抜', cmd: 'outline', on: () => isOn(M.OUTLINE) }, { key: '6', label: '取消線', short: '取消', cmd: 'strike', on: () => isOn(M.STRIKE) },
    { cl: '倍角', cols: 2 }, { key: '7', label: '横倍角', short: '横倍', cmd: 'wide', on: () => isOn(M.WIDE) }, { key: '8', label: '縦倍角', short: '縦倍', cmd: 'tall', on: () => isOn(M.TALL) }, { key: '9', label: '四倍角', short: '四倍', cmd: 'quad', on: () => isOn(M.WIDE) && isOn(M.TALL) }, { key: 'K', label: 'm×n 倍角…', short: 'm×n', cmd: 'scale', on: () => st.form === 'scale' }, { key: 'W', msel: 'narrow' }, { key: 'H', label: '影文字', short: '影', cmd: 'shadow', on: () => isOn(M.SHADOW) },
    { cl: '線' }, { key: 'A', label: '二重下線', short: '二重下', cmd: 'under2', on: () => isOn(M.UNDER2) }, { key: 'S', label: '波線', cmd: 'wave', on: () => isOn(M.WAVE) }, { key: 'D', label: '二重取消線', short: '二重消', cmd: 'strike2', on: () => isOn(M.STRIKE2) }, { key: 'F', label: 'コード', short: 'コード', cmd: 'codeSpan', on: () => isOn(M.CODE) }, { key: 'G', label: '網の文様…', short: '文様', cmd: 'shadeType', on: () => st.form === 'shadeType' },
    { cl: 'ほか' }, { key: 'L', label: 'リンク…', short: 'リンク', cmd: 'link', on: () => !!FZ.linkAt(ed.seg(), ed.caret.off) }, { key: 'N', label: '図番…', short: '図番', cmd: 'figRef' }, { key: '0', label: '解除', cmd: 'clearMarks' }] },
  line: { title: '配置', items: [{ cl: '揃え', cols: 3 }, { key: '7', label: '左揃え', short: '左', cmd: 'alignL', on: () => !A().align || A().align === 'left' }, { key: '8', label: '中央揃え', short: '中央', cmd: 'alignC', on: () => A().align === 'center' }, { key: '9', label: '右揃え', short: '右', cmd: 'alignR', on: () => A().align === 'right' }, { key: '0', label: '均等割付', short: '均等', cmd: 'alignJ', on: () => A().align === 'justify' },
    { cl: '位置', cols: 2 }, { key: 'H', label: '左へ', cmd: 'posLeft' }, { key: 'J', label: '右へ', cmd: 'posRight' }, { key: 'K', label: '自動', cmd: 'posAuto', on: () => A().indent != null && !!FZ.nodeKind(A()) },
    { cl: '形' }, { key: 'O', label: '引用', cmd: 'quote', icon: 'quote', on: () => !!A().quote }, { key: 'P', label: 'コード', short: 'コード', cmd: 'code', icon: 'codeBlock', on: () => !!A().code }, { key: '6', label: '発言録', short: '発言録', cmd: 'styleSpeech', icon: 'speech', on: () => A().style === 'speech' }, { key: 'C', label: '区画…（見出しの子の節を枠に入れて並べる：横・縦・縦横 m×n。霞が関型の 1 枚もの）', short: '区画', cmd: 'panels', icon: 'panels', on: () => st.form === 'panels' },
    { cl: '送り' }, { key: 'F', label: '分割禁止（この行を頁で割らない）', short: '分割禁止', cmd: 'keepLine', on: () => A().keep === 'line' }, { key: 'G', label: '次と同頁', short: '次と同頁', cmd: 'keepNext', on: () => keepNextOn(A()) }, { key: 'B', label: 'ここから改頁', short: '改頁', cmd: 'pageBreak', icon: 'pageBreak', on: () => !!A().breakBefore }, { label: '配置の理由…（この行の位置・太字・番号・次頁へ移った理由）', short: '理由', cmd: 'whyPlace', icon: 'help', on: () => st.form === 'why' },
    { cl: '飾り' }, { key: 'Y', label: '見出し飾り…（新聞の見出し表現）', short: '見出飾り', cmd: 'headGroup', icon: 'headDeco', on: () => !!A().deco }, { key: 'M', label: '網掛け（範囲を選んで地に網）', short: '網掛', cmd: 'fillMode', icon: 'fill' }] },
  insert: { title: '挿入', items: [{ cl: '図表' }, { key: 'P', label: '画像…', short: '画像', cmd: 'figOpen', icon: 'image' }, { key: 'C', label: 'グラフ…', short: 'グラフ', cmd: 'chart', icon: 'chart' }, { key: 'T', label: '表…', short: '表', cmd: 'table', icon: 'table', on: () => !!A().cells }, { label: '工程表…（ガントチャート）', short: '工程表', cmd: 'gantt', icon: 'gantt', on: () => st.form === 'gantt' }, { key: 'I', label: '図（流れ図）', short: '流れ図', cmd: 'figInsert', icon: 'flow', on: () => !!A().figure }, { key: 'R', label: '構成図を作る…（節と子から）', short: '構成図', cmd: 'figTree', icon: 'tShapeH', on: () => st.form === 'figtree' }, { key: 'G', label: '図表の設定…', short: '図表設定', cmd: 'figEdit', icon: 'figEdit', on: () => !!A().figs },
    { cl: '参照' }, { key: 'N', label: '図番…', short: '図番', cmd: 'figRef', icon: 'figRef' }, { key: 'S', label: '節の参照…（見出しの番号と題。並べ替えても追う）', short: '節の参照', cmd: 'secRef', icon: 'secRef' }, { key: 'D', label: '文書を挿入…', short: '文書', cmd: 'insertFile', icon: 'insertFile' }, { key: 'U', label: '構成の型…（報告書・企画書・霞が関の資料などの骨組み）', short: '構成の型', cmd: 'skeleton', icon: 'skeleton' }, { key: 'B', label: 'フレームワーク…（SWOT・3C・PDCA など考える型。紙面に枠、画面の下に書き方）', short: 'フレーム', cmd: 'framework', icon: 'grid', on: () => !$('fwpick').hidden }, { key: 'F', label: 'プ譜…（ゴールから逆算する道筋。右から左へ枝分かれ）', short: 'プ譜', cmd: 'pufuGroup', icon: 'pufu' },
    { cl: '区切り' }, { key: 'L', label: '区切り線', short: '区切線', cmd: 'hr', icon: 'hr', on: () => !!A().hr }, { key: 'Y', label: '記事の区切り', short: '記事', cmd: 'hd:sep', icon: 'sepDia' }, { key: 'K', label: '囲み記事', short: '囲み', cmd: 'hd:article', icon: 'article' }, { key: 'J', label: '囲み（題なし）', short: '枠', cmd: 'hd:articleN', icon: 'articleN' }, { key: 'M', label: '目次…', short: '目次', cmd: 'toc', icon: 'toc', on: () => !!A().toc },
    { cl: '字' }, { key: 'O', label: '記号の引出…（分類・別名で探す・最近）', short: '記号', cmd: 'symbols', icon: 'symbols', on: () => st.side === 'drawer' && st.drawerTab === 'sym' }, { key: 'W', label: '断片箱…（定型句・自分の言い回し）', short: '断片', cmd: 'snippets', icon: 'snippet', on: () => st.side === 'drawer' && st.drawerTab === 'snip' }] },
  fmt: { title: '書式', items: [{ cl: '用紙' }, { key: 'F', label: '用紙・文字数…', short: '用紙', cmd: 'format', icon: 'page', on: () => st.form === 'format' }, { label: '版面の物差し…（版面の縁をドラッグで余白、字数・行数・版面の型。紙面に仮に出す）', short: '物差し', cmd: 'ruler', icon: 'grid', on: () => st.form === 'ruler' }, { label: '紙幅の使い道…（目標の頁数・最小の字。はみ出す原因と試す案）', short: '紙幅', cmd: 'fitCheck', icon: 'count', on: () => st.form === 'fit' }, { key: 'M', msel: 'font' }, { key: 'R', msel: 'orient' },
    { cl: '体系' }, { key: 'W', label: '見出し・箇条の体系と空き…', short: '体系', cmd: 'scheme', icon: 'scheme', on: () => st.form === 'scheme' }, { key: 'S', label: '文の分け方…（「．」も文末に・箇条書きの中の文も）', short: '文分け', cmd: 'sentOpt', icon: 'sentSel', on: () => st.form === 'sentopt' }, { key: 'N', label: '番号・記号の形…（カーソルの段のものすべて）', short: '番号形', cmd: 'sx:mark', icon: 'scheme', on: () => st.form === 'marker' },
    { cl: '資料' }, { key: 'H', label: '資料の柱と表紙…', short: '柱・表紙', cmd: 'slideHead', icon: 'slideHead', on: () => st.form === 'slide' }, { key: 'D', label: '作成日を今日に', short: '作成日', cmd: 'dateToday', icon: 'date' }, { cl: '設定' }, { key: 'X', label: '設定を書き出す', short: '書出', cmd: 'settingsOut', icon: 'cfgOut' }, { key: 'I', label: '設定を読み込む…', short: '読込', cmd: 'settingsIn', icon: 'cfgIn' }] },
  view: { title: '表示', items: [{ cl: '倍率', cols: 2 }, { key: '1', msel: 'zoom' }, { key: '2', label: '拡大', cmd: 'zoomIn', icon: 'zoomIn' }, { key: '3', label: '縮小', cmd: 'zoomOut', icon: 'zoomOut' }, { key: 'G', msel: 'gridMode' },
    { cl: '説明' }, { key: 'H', label: 'ガイド（右の欄：やりたいこと別の操作と近道）', short: 'ガイド', cmd: 'help', icon: 'help', on: () => st.side === 'help' }, { key: 'M', label: '取扱説明書（全機能を詳しく。文書で開く）', short: '取説', cmd: 'manual', icon: 'manual' }, { key: 'K', label: 'フレームワークの解説を出す／隠す（枠の中にカーソルがあるとき、画面の下に）', short: '枠解説', cmd: 'fwGuide', icon: 'help', on: () => !st.fwGuideOff },
    { cl: '机' }, { key: 'D', label: '引き出し（記号・断片・文庫・量）', short: '引き出し', cmd: 'drawer', icon: 'drawer', on: () => st.side === 'drawer' }, { key: 'U', label: '文書の量（字数・頁・この節・目標・診断のまとめ）', short: '量', cmd: 'docMeter', icon: 'count', on: () => st.side === 'drawer' && st.drawerTab === 'ruler' }, { key: 'F', label: '集中の表示（カーソルの節のほかを薄く）', short: '集中', cmd: 'focusMode', icon: 'focus', on: () => !!st.focus }, { key: 'B', label: '頁の地図（右端の細い帯）', short: '地図', cmd: 'pageMap', icon: 'pageMap', on: () => !!st.pageMap }, { key: 'S', label: '原本の面（カーソルの節の原本を読み書き）', short: '原本', cmd: 'srcPane', icon: 'md', on: () => st.side === 'src' }, { key: 'T', label: '道具箱（操作の並びを Alt+1〜9 で）', short: '道具', cmd: 'tools', icon: 'tools', on: () => st.side === 'drawer' && st.drawerTab === 'tools' },
    { cl: '層' }, { key: 'L', label: '手当て（付箋・点検の印・比べた印。朱）を見せる／隠す。隠すと紙だけ＝刷り上がり', short: '手当て', cmd: 'careShow', icon: 'care', on: () => !st.careHidden }, { key: 'P', msel: 'printLayer' }, { key: 'V', label: '写しの見通し（書き出す前に、Word・PowerPoint・Markdown・テキストで変わる所）', short: '見通し', cmd: 'convPreview', icon: 'convLog', on: () => st.side === 'conv' && !!(st.convLog && st.convLog.target === 'preview') }] },
  pufu: { title: 'プ譜', parent: 'insert', items: [{ cl: '足す（役で）', cols: 3 }, { key: '1', label: '勝利条件を足す（獲得目標の下。いまの勝利条件の後に）', short: '勝利条件', cmd: 'pfAdd:win', icon: 'pfWin' }, { key: '2', label: '取組を足す（勝利条件の下に、中間目的を 1 つ入れて）', short: '取組', cmd: 'pfAdd:frame', icon: 'pufuFrame' }, { key: '3', label: '中間目的を足す（いまの中間目的の後。取組・勝利条件を選んでいればその中の最後に）', short: '中間目的', cmd: 'pfAdd:mid', icon: 'pfMid' }, { key: '4', label: '施策を足す（いまの施策の後。中間目的を選んでいればその下の最後に）', short: '施策', cmd: 'pfAdd:act', icon: 'pfAct' }, { key: '5', label: '段取りを足す（施策の下）', short: '段取り', cmd: 'pfAdd:step', icon: 'pfStep' }, { key: '6', label: '成果物を書く（中間目的の箱の中に。あればそこへ）', short: '成果物', cmd: 'pfAdd:out', icon: 'pfOut' }, { key: 'E', label: '気づきを書く（箱の中の吹き出し）', short: '気づき', cmd: 'pufuInsight', icon: 'pufuNote' }, { key: 'R', label: '資源と制約（廟算八要素）を足す', short: '資源', cmd: 'pufuRes', icon: 'pufuRes' },
    { cl: '組み替える', cols: 2 }, { key: 'I', label: '上へ（同じ役の中で。子ごと。Alt+↑）', short: '上へ', cmd: 'pf:up', icon: 'tUp' }, { key: 'K', label: '下へ（同じ役の中で。子ごと。Alt+↓）', short: '下へ', cmd: 'pf:down', icon: 'tDown' }, { key: 'O', label: '上の役へ（施策→中間目的など。子ごと一段浅く。Alt+←）', short: '上の役へ', cmd: 'pf:out', icon: 'outdent' }, { key: 'L', label: '下の役へ（中間目的→施策など。子ごと一段深く。Alt+→）', short: '下の役へ', cmd: 'pf:in', icon: 'indent' }, { key: 'W', label: '取組でまとめる／外す（選んだ中間目的を取組で包む。取組の上なら外す）', short: 'まとめる', cmd: 'pufuFrame', icon: 'pufuFrame' }, { key: 'X', label: 'この項目を消す（子ごと。Ctrl+Z で戻る）', short: '消す', cmd: 'pf:del', icon: 'figDel' },
    { cl: '作る', cols: 2 }, { key: 'N', label: 'プ譜を入れる（型）', short: '入れる', cmd: 'pufuNew', icon: 'pufu' }, { key: 'M', label: 'この節をプ譜にする／戻す', short: 'プ譜に', cmd: 'pufuMark', icon: 'pufuMark', on: () => !!(FZ.pufuAt && FZ.pufuAt(ed.doc, ed.caret.line)) }, { key: 'T', label: '役の名前…（紙面・書き出しで見せる名前を変える。構造はそのまま）', short: '役の名前', cmd: 'pufuNames', icon: 'figText', on: () => st.form === 'pnames' }, { key: 'F', msel: 'pufuForm' },
    { cl: '見る' }, { key: 'C', label: '診断（右の欄。プ譜の項目：中間目的は状態か・数・施策の担当と期日・取組の名前・〔推測〕）', short: '診断', cmd: 'pufuCheck', icon: 'health', on: () => st.side === 'health' }, { key: 'S', label: '局面を記録（今のプ譜を原本に残す）', short: '記録', cmd: 'pufuPhaseSave', icon: 'pufuPhase' }, { key: 'D', label: '局面と比べる…', short: '比べる', cmd: 'pufuPhaseCmp', icon: 'pufuCmp', on: () => st.form === 'phase' },
    { cl: 'AI' }, { key: 'A', label: 'AI と（下書き・下読みを頼む・次の局面・取り込む・戻す）', short: 'AI…', cmd: 'pufuAiGroup', icon: 'aiSec' }] },
  pufuAi: { title: 'プ譜の AI', parent: 'pufu', items: [{ cl: 'AI に頼む' }, { key: 'P', label: '下書きを AI に…（議事録・発言録・個人の文章などから）', short: '下書き', cmd: 'pufuPrompt', icon: 'aiSec', on: () => st.form === 'pdraft' }, { key: 'K', label: '下読みを頼む（このプ譜を AI に読ませて直しをもらう。指示文を写す）', short: '下読み', cmd: 'pufuReview', icon: 'aiSec' }, { key: 'J', label: '次の局面を頼む…（新しい情報とこのプ譜を指示文に）', short: '次の局面', cmd: 'pufuNext', icon: 'aiSec', on: () => st.form === 'pnext' },
      { cl: '受け取る' }, { key: 'I', label: 'AI の答えを新しいプ譜として取り込む…', short: '取り込む', cmd: 'pufuImport', icon: 'aiBack', on: () => st.form === 'pimport' }, { key: 'B', label: 'AI の答えを今のプ譜と比べて取り込む（AI から戻す）', short: '戻す', cmd: 'aiReturn', icon: 'aiBack' }] },
  head: { title: '見出し飾り', parent: 'line', items: [{ cl: '飾り' }, ...FZ.HEADINGS.map(h => ({ key: h.key, label: h.label, short: h.id === 'sep' ? '区切り' : h.short, cmd: 'hd:' + h.id }))] },
  table: { title: '表の様式', parent: 'tedit', items: [{ cl: '様式' }, ...FZ.TABLES.map(t => ({ key: t.key, label: t.label, short: t.short, cmd: 'tb:' + t.id })), { cl: '操作' }, ...FZ.TABLE_OPS.map(o => ({ key: o.key, label: o.label, short: o.short, cmd: 'to:' + o.id, on: o.id === 'repeat' ? () => { const rg = FZ.tableRange(ed); return !!rg && !ed.doc.lines[rg[0]].attrs.noRepeat; } : undefined }))] },
  tedit: { title: '表', items: [{ cl: '表', cols: 1 }, { key: 'N', label: '表を作る…（列数・行数・列幅）', short: '表作成', cmd: 'table', icon: 'table', on: () => st.form === 'table' }, { key: 'U', label: '表の様式…（格子・新聞・統計表）', short: '様式', cmd: 'tableGroup', icon: 'tableStyle' }, { key: 'X', label: '表を削除', short: '表削除', cmd: 'tdel', icon: 'tableDel' }, { cl: '行', cols: 1 }, { key: 'R', label: '上に行を挿入', short: '上に行', cmd: 'tr:above', icon: 'rowAbove' }, { key: 'F', label: '下に行を挿入', short: '下に行', cmd: 'tr:below', icon: 'rowBelow' }, { key: 'V', label: '行を削除', short: '行削除', cmd: 'tr:del', icon: 'rowDel' },
    { cl: '列', cols: 1 }, { key: 'T', label: '左に列を挿入', short: '左に列', cmd: 'tc:left', icon: 'colLeft' }, { key: 'G', label: '右に列を挿入', short: '右に列', cmd: 'tc:right', icon: 'colRight' }, { key: 'B', label: '列を削除', short: '列削除', cmd: 'tc:del', icon: 'colDel' },
    { cl: '結合', cols: 1 }, { key: 'M', label: 'セルを結合（選んだセルを 1 つに）', short: '結合', cmd: 'tmerge', icon: 'cellMerge' }, { key: 'S', label: '結合を解除（セルに分ける）', short: '解除', cmd: 'tsplit', icon: 'cellSplit' },
    { cl: '列の幅', cols: 1 }, { key: 'E', label: '列の幅をそろえる（選んだ列を同じ幅に。選ばなければ全部）', short: '揃える', cmd: 'tcw:eq', icon: 'colEqual' }, { key: 'W', label: '列の幅を字に合わせる（選んだ列を中身の字数に。選ばなければ全部。列の線をダブルクリックでも）', short: '字合せ', cmd: 'tcw:fit', icon: 'colFit' },
    { cl: '位置', cols: 2 }, { key: 'H', label: '表・囲みを左へ（半字）', short: '左へ', cmd: 'tmv:l', icon: 'moveL' }, { key: 'L', label: '表・囲みを右へ（半字）', short: '右へ', cmd: 'tmv:r', icon: 'moveR' }, { key: 'I', label: '表・囲みを上へ（上の空行を詰める）', short: '上へ', cmd: 'tmv:u', icon: 'moveU' }, { key: 'J', label: '表・囲みを下へ（上に空行）', short: '下へ', cmd: 'tmv:d', icon: 'moveD' }, { key: 'O', label: '囲みを版面の幅いっぱいに戻す', short: '囲全幅', cmd: 'bx:full', icon: 'article' },
    { cl: 'セルの網' }, { key: '5', label: '淡網', cmd: 'tcs:light', sw: 'light' }, { key: '1', label: '薄網', cmd: 'tcs:gray', sw: 'gray' }, { key: '2', label: '濃網', cmd: 'tcs:deep', sw: 'deep' }, { key: '3', label: '墨（白抜き）', short: '墨', cmd: 'tcs:dark', sw: 'dark' }, { key: '4', label: '斜線', cmd: 'tcs:hatch', sw: 'hatch' }, { key: '0', label: '網を消す', short: 'なし', cmd: 'tcs:none', sw: 'none' },
    { cl: 'セル・計算', cols: 3 }, { key: '7', label: '左揃え', short: '左', cmd: 'tca:left', icon: 'alignL' }, { key: '8', label: '中央揃え', short: '中央', cmd: 'tca:center', icon: 'alignC' }, { key: '9', label: '右揃え', short: '右', cmd: 'tca:right', icon: 'alignR' }, { key: 'K', label: '太字', cmd: 'tcb', icon: 'bold' }, { key: 'D', label: '中身を消す', short: '消去', cmd: 'tcx', icon: 'clearCell' }, { key: 'Y', label: '合計の行（数の列を足す。表を直すたびに計算し直す。もう一度で外す）', short: '合計', cmd: 'tblSum', icon: 'tblSum', on: () => { const I = FZ.tbl.info(ed); return !!(I && FZ.tbl.sumRowOf(ed.doc, I) >= 0); } }, { key: 'Z', label: '数の列を右揃え（もう一度で左に戻す）', short: '数→右', cmd: 'tblNumRight', icon: 'numRight' } ] },
};
/* ツリーの帯（ツリーのときに出る。キーはツリーのキー） */
const TREE_BAND = { title: 'ツリー', items: [{ cl: '足す', cols: 2 }, { key: '⏎', label: '弟を足す（Enter）', short: '弟', cmd: 'tv:after', icon: 'tSib' }, { key: 'Tab', label: '子を足す（Tab）', short: '子', cmd: 'tv:child', icon: 'tChild' },
  { cl: '動かす', cols: 2 }, { label: '上へ（Alt+↑）', short: '上へ', cmd: 'tv:up', icon: 'tUp' }, { label: '下へ（Alt+↓）', short: '下へ', cmd: 'tv:down', icon: 'tDown' }, { label: '浅く（Alt+←）', short: '浅く', cmd: 'tv:out', icon: 'outdent' }, { label: '深く（Alt+→）', short: '深く', cmd: 'tv:in', icon: 'indent' },
  { cl: '節' }, { key: 'C+⏎', label: '文字を直す', short: '直す', cmd: 'tv:edit', icon: 'figText' }, { key: 'Del', label: '消す', cmd: 'tv:del', icon: 'figDel' }, { label: 'ここから改頁', short: '改頁', cmd: 'tv:break', icon: 'pageBreak', on: () => { const n = treeNodeSel(); return !!(n && n.obj && n.obj.attrs.breakBefore); } }, // 紙面へは Esc か「表示」のプルダウン
  { label: '畳む・開く（Space。選んだ節だけ）', short: '畳む', cmd: 'tv:fold', icon: 'tFold' }, { cl: '戻る' }, { label: '紙面へ（Esc。ツリーを閉じて紙面で書く）', short: '紙面へ', cmd: 'tv:paper', icon: 'back' }] }; // R6：帯は構造の操作だけ。深さ・図表の開閉・形・倍率は F10（表示） // 拡大・縮小は F10（表示）・Ctrl+ホイール・Ctrl+＋／−・＋／− // 文字（F2）・紙面へ（Esc）は F キーの行にある
/* 図の帯（図を編集しているときに出る。メニューのグループではない。キーは図のキー） */
const FIG_BAND = { title: '図', items: [{ cl: '足す' }, { key: 'N', label: '箱を足す', short: '箱', cmd: 'fg:add', icon: 'figAdd' }, { key: 'C', label: '矢印でつなぐ', short: 'つなぐ', cmd: 'fg:connect', icon: 'figConnect', on: () => !!(st.fig && st.fig.connecting) }, { key: 'D', label: '複製', cmd: 'fg:dup', icon: 'figDup' },
    { cl: '文字' }, { key: 'T', label: '文字を打つ', short: '文字', cmd: 'fg:text', icon: 'figText' }, { key: 'B', label: '太字', cmd: 'fg:bold', icon: 'bold', on: () => !!(figPrim() && figPrim().bold) },
    { cl: '線', cols: 2 }, ...[['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']].map(([k, l]) => ({ label: l, cmd: 'fg:k:' + k, icon: 'ln_' + k, on: () => !!(figPrim() && figPrim().kind === k) })),
    { cl: '網' }, ...[['none', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨'], ['hatch', '斜線'], ['dots', '点']].map(([id, l]) => ({ label: l, cmd: 'fg:s:' + id, sw: id, on: () => !!(figPrim() && (figPrim().shade || 'none') === id) })),
    { cl: '整える' }, { key: 'K', label: '詰めて組み直す', short: '詰める', cmd: 'fg:compact', icon: 'figCompact' },
    { cl: '揃え', cols: 3 }, ...[['left', '左', '左'], ['center', '中央', '中'], ['right', '右', '右'], ['top', '上', '上'], ['middle', '中段', '中段'], ['bottom', '下', '下'], ['dh', '横等間隔', '横等'], ['dv', '縦等間隔', '縦等']].map(([m, l, sh]) => ({ label: l, short: sh, cmd: 'fg:al:' + m, icon: 'al_' + m }))] }; // 消す・レーン・図の高さ・本文へ は F キーの行にある
/* コマンドのキー：メニューの道筋（F キーと項目の名前。例 F5「太字」）をこの表から引く。ほかの近道（Ctrl など）は cmd() の keys */
const CMDI = new Map(); function cmdById(id) { if (!id) return null; if (CMDI.size !== CMDS.length) { CMDI.clear(); for (const c of CMDS) CMDI.set(c.id, c); } return CMDI.get(id) || null; }
let PATHS = null;
function menuPaths() {
  if (PATHS) return PATHS; PATHS = new Map(); const add = (id, p) => { if (!PATHS.has(id)) PATHS.set(id, []); if (!PATHS.get(id).includes(p)) PATHS.get(id).push(p); };
  for (const [k, , id] of FK.text) { if (!id) continue; add(id, k); const gn = GROUP_OF[id]; if (!gn) continue;
    const walk = (g, pre, depth) => { for (const it of GROUPS[g].items) { if (it.msel) { for (const id of MSEL[it.msel].cmds) add(id, pre + '「' + MSEL[it.msel].label + '▾」'); continue; } if (!it.cmd) continue; const p = pre + '「' + String(it.short || it.label).replace(/（.*$/, '') + '」'; /* 1.0.10u：道筋は F キーと項目の名前（項目の文字キーはやめた） */ add(it.cmd, p); const sg = SUBGROUP_OF[it.cmd]; if (sg && depth < 2 && sg !== g) walk(sg, p, depth + 1); } };
    walk(gn, k, 0); }
  for (const [k, id] of Object.entries(FK_HIDDEN)) add(id, k);
  return PATHS;
}
function keysOf(c) { return [...(menuPaths().get(c.id) || []), c.keys].filter(Boolean).join(' / '); }
function K(id) { const p = menuPaths().get(id); if (p && p.length) return p[0]; const c = cmdById(id); return c ? c.keys : ''; } // 案内の文に出すキー
/* F キー：そのグループを子メニューに出す（項目はクリック。押した後の字は本文に入る）。子メニューは閉じない */
function toggleGroup(name) { if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); if (st.form) closeForm(); if (name !== 'pufu' && name !== 'pufuAi') st.pufuAuto = false; st.group = name; st.armed = false; /* 1.0.10u：F キーはグループの切り替えだけ（項目の文字キー・構えはやめた） */ drawSub(); drawFkeys(); focusTA(); }
function showGroup(name) { st.group = name; st.armed = false; drawSub(); drawFkeys(); }
function disarm() { if (!st.armed) return; st.armed = false; drawSub(); drawFkeys(); }
function afterGroupItem() { /* 1.0.16h 帯は替えない：子の帯（プ譜・見出し飾り・表の様式など）で 1 つ選んでも、その帯のまま続けて使える。戻るのは「戻る」か F キーで */ }
/* ツリー：開いたグループを閉じて、ツリーの帯（構造の操作）に戻る */
function treeCloseGroup() { st.group = null; st.armed = false; drawSub(); drawFkeys(); focusTA(); } // 見出し飾り・表の様式は罫線・飾りの下の階層なので、実行したら罫線・飾りに戻る
function closeGroup() { disarm(); }
function tile(it) { const on = !!(it.on && it.on()); const c = cmdById(it.cmd); const sk = c && c.keys && !/^（/.test(c.keys) ? c.keys : ''; const dg = FZ.degradeTip ? FZ.degradeTip(it.cmd) : ''; const tip = (c ? c.label : it.label) + (sk ? `　［${sk}］` : '') + (dg ? '\n写し　' + dg : ''); /* 近道があれば説明に出す（帯には出さない）。1.0.15a 写しで変わるもの（C-12） */
  return `<span class="ch${on ? ' on' : ''}${it.sw ? ' sw' : ''}" data-cmd="${it.cmd}" role="button" tabindex="-1" aria-pressed="${on}" title="${esc(tip)}">${it.sw ? swatch(it.sw) : FZ.icon(it.icon || it.cmd)}<span class="lb">${nar(it.short || it.label)}</span></span>`; }
/* 長体の字：大きめの字を横に詰めて組む（帯の項目名・F キーの名前）。幅は canvas で測って箱に与える（transform は幅を変えないため） */
const NAR_X = 0.84, _narW = new Map(); let _narCv = null;
function nar(t, px = 13, sx = NAR_X) { t = String(t); const key = px + '|' + t; let w = _narW.get(key); if (w == null) { try { _narCv = _narCv || document.createElement('canvas').getContext('2d'); _narCv.font = `${px}px ${getComputedStyle(document.body).fontFamily}`; w = _narCv.measureText(t).width; } catch (e) { w = t.length * px; } _narW.set(key, w); }
  return `<span class="nr" style="width:${Math.ceil(w * sx) + 1}px"><i style="transform:scaleX(${sx})">${esc(t)}</i></span>`; }
function clusters(items) { const out = []; let cur = null; for (const it of items) { if (it.cl !== undefined) { cur = { label: it.cl, items: [], cols: it.cols || 0 }; out.push(cur); } else { if (!cur) { cur = { label: '', items: [] }; out.push(cur); } cur.items.push(it); } } return out; }
function drawSub() { drawSubBody(); updateGuide(); drawIsland(); fitFkeys(); }
/* 1.0.15g：F キーは 2 段が基本（幅が約 150px 減り、帯が F キーの横に収まる窓が広がる）。帯がどのみち F キーの下へ回るほど狭い窓では 1 段に戻す
   （そのときは 1 段の方が帯の高さが低い）。決めるのは窓の幅と Esc の有無だけ（帯を替えても F キーの並びは動かない） */
let fkFitKey = '';
function fitFkeys(force) { const fk = $('fkeys'), sub = $('sub'); if (!fk || !sub) return; const key = innerWidth + ':' + fk.classList.contains('wesc'); if (!force && key === fkFitKey) return; fkFitKey = key;
  fk.classList.add('two'); if (sub.getBoundingClientRect().top >= fk.getBoundingClientRect().bottom - 2) fk.classList.remove('two'); }
window.addEventListener('resize', () => fitFkeys());
function drawSubBody() {
  if (!st.armed || st.form || (st.mode !== 'text' && st.mode !== 'tree')) document.body.classList.remove('armed');
  if (st.form) { drawForm(); return; }
  sub.classList.remove('form', 'hint'); st.formFocus = false;
  if (st.mode === 'rule') { sub.classList.add('hint'); sub.innerHTML = `<span class="ttl">罫線</span><span class="hintl"><b>矢印キー</b> 線を引く　<b>Shift+矢印</b> 移動　<b>Enter</b> 囲みの始点／確定　<b>Backspace</b> 消去切替　<b>ドラッグ</b> でも引ける　<b>Esc</b> 本文へ</span>`; return; }
  if (st.mode === 'tree' && !st.group) { const n = treeNodeSel(); const m = treeSelected().length; const kindOpt = n && !n.root && n.kind !== 'block' ? treeKindOf(n) : ''; const mk = n && treeMarkerNow(n);
    const sel = (id, vals, cur, tip) => `<select id="${id}" class="cyc" title="${esc(tip)}">${vals.map(([v, l]) => `<option value="${v}"${String(v) === String(cur) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    const mkVals = mk ? (() => { const ch = treeMarkerChoices(mk.k); if (!ch.includes(mk.tok)) ch.unshift(mk.tok); return ch.map(t => [t, t === FZ.NONE_TOKEN ? 'なし（記号なし）' : t]); })() : [['', '—']];
    sub.innerHTML = `<div class="cl tsels"><label>種類 ${sel('tvKind', [['', '—'], ['title', '表題'], ['num', '番号見出し'], ['sym', '記号見出し'], ['nlist', '番号箇条書き'], ['list', '記号箇条書き'], ['body', '本文']], kindOpt, '選んだ節の種類（段は木の位置で決まる）。文を選んで変えると、段落を割って取り出す')}</label><label title="${mk ? esc(mk.name) + ' ' + (mk.lv + 1) + '（この段のものすべて）の番号・記号の形' : '番号見出し・記号見出し・箇条書きを選ぶと変えられる'}">番号 ${sel('tvMark', mkVals, mk ? mk.tok : '', mk ? `${mk.name}${mk.lv + 1}（この段のものすべて）の番号・記号の形。全体は ${K('scheme')}` : '')}</label><label>組替 ${sel('tvRe', [['', '—'], ['para', '文ごとの段落に'], ['list', '箇条書きに'], ['tree', '親子に'], ['merge', 'まとめる']], '', '段落をばらす（文ごとの段落／箇条書き／最初の文を親にした親子）、選んだ節（または節と子）を 1 つの段落にまとめる')}</label></div>` + clusterHtml({ label: '表示', items: [{ segd: 'depth' }, { label: '図表の中身を見せる（表・グラフ・図を縮小して見せる）', short: '図中身', cmd: 'tvf:toggle', icon: 'chart', on: () => !!st.tree.showAll }] }, true) + (n && n.line != null && pufuCtx(n.line) ? clusterHtml({ label: 'プ譜：' + (pufuRoleOfLine(n.line) || '題'), cols: 3, items: GROUPS.pufu.items.filter(it => it.cmd && /^pfAdd:|^pf:del$|^pufuFrame$/.test(it.cmd)) }, true) : '') + clusters(n && n.line != null && pufuCtx(n.line) ? TREE_BAND.items.map(it => it.cmd === 'tv:out' ? { ...it, label: '上の役へ（施策→中間目的など。子ごと一段浅く。Alt+←）', short: '上の役へ' } : it.cmd === 'tv:in' ? { ...it, label: '下の役へ（中間目的→施策など。子ごと一段深く。Alt+→）', short: '下の役へ' } : it) : TREE_BAND.items).map(c => clusterHtml(c)).join('') + `<span class="cl note">${m > 1 ? `${m} 個を<br>選択中` : ''}${(ed.doc.parked || []).length ? `<span class="ch pkn" data-cmd="parkList" title="保留の島を開く">保留 ${ed.doc.parked.length}</span>` : ''}</span>`;
    $('tvKind').onchange = ev => { if (ev.target.value) treeSetKind(ev.target.value); focusTA(); }; $('tvMark').disabled = !mk; $('tvMark').onchange = ev => { treeSetMarker(ev.target.value); focusTA(); }; $('tvRe').onchange = ev => { const v = ev.target.value; if (v) treeRegroup(v); focusTA(); }; fitClusterNames(); return; } /* ツリーの帯に表示（深さ・図表・形）も：編集しながら切り替える */
  if (st.mode === 'fig') { const n = figIds().length; sub.innerHTML = clusters(FIG_BAND.items).map(c => clusterHtml(c)).join('') + `<span class="cl note">${st.fig.connecting ? '<b class="alert">矢印の先の<br>箱をクリック</b>' : n > 1 ? `${n} 個を<br>選択中` : st.fig.selArrow != null ? '矢印を<br>選択中' : ''}</span>`; fitClusterNames(); return; }
  if (st.mode === 'fill') { sub.classList.add('hint'); sub.innerHTML = `<span class="ttl">網掛け</span><span class="hintl"><b>矢印</b> 範囲 <b>Enter</b> 掛ける <b>Esc</b> 本文へ</span><span class="sws">${FZ.SHADES.filter(x => x.id !== 'text').map(sh => `<span class="ch sw${st.shade === sh.id ? ' on' : ''}" data-cmd="s:${sh.id}" title="${esc(sh.label)}">${swatch(sh.id)}<span class="lb">${esc(sh.name)}</span><span class="k">${SWATCH_KEY[sh.id]}</span></span>`).join('')}<span class="ch sw${st.shade === 'none' ? ' on' : ''}" data-cmd="s:none" title="網掛けを消す">${swatch('none')}<span class="lb">消す</span><span class="k">F5</span></span></span>`; return; }
  const g = GROUPS[st.group] || GROUPS.struct; sub.classList.toggle('armed', st.armed);
  const back = g.parent ? `<span class="ch back" data-back="1" role="button" tabindex="-1" title="${esc(GROUPS[g.parent].title)}に戻る［Esc］">${FZ.icon('back')}<span class="lb">戻る</span><span class="k">Esc</span></span>` : '';
  const note = (st.group === 'table' || st.group === 'tedit') && !FZ.tableRange(ed) ? '<span class="tnote" title="行・列・セルの操作は、表の中にカーソルを置いてから">表の中で使う</span>' : '';
  document.body.classList.toggle('armed', !!st.armed); // 構え：帯の左端を太線に、項目のキーを黒地に、状態行の案内を反転に、カーソルを薄く（打った字が本文に入らない状態）
  sub.innerHTML = back + clusters(g.items).map(c => clusterHtml(c)).join('') + note;
  fitClusterNames();
  if (st.bandKb) { const T = bandTiles(); const el = T.find(x => (x.dataset.cmd || x.dataset.msel || x.dataset.back) === st.bandCmd) || T[0]; if (el) { st.formFocus = true; el.tabIndex = -1; el.focus({ preventScroll: true }); } else bandLeave(); } /* 描き直しても印を保つ */
}
/* 塊の名前の縦書き：伸ばし棒・ダッシュは縦の形に */
const VFORM = { 'ー': '｜', '－': '｜', '—': '｜', '〜': '≀', '…': '︙' }; const vlabel = t => [...t].map(ch => esc(VFORM[ch] || ch)).join('<br>');
/* 塊の名前（縦書き）は、帯が 1 段に収まる時だけ出す（収まらなければ隠してタイルを優先） */
function fitClusterNames() { sub.classList.remove('tight'); const cls = [...sub.querySelectorAll(':scope > .cl')]; if (cls.length < 2) return; const t0 = cls[0].getBoundingClientRect().top; if (cls.some(c => Math.abs(c.getBoundingClientRect().top - t0) > 4)) sub.classList.add('tight'); }
/* 子メニューの項目をクリック：実行して構えを解く（キーで押したときと同じ）。別のメニューやフォームを開く項目はそちらに移る */
sub.addEventListener('pointerdown', e => { st.fkPrev = null; if (e.target.closest('input,button,label,select')) return; e.preventDefault(); if (st.bandKb) bandLeave(false); const c = e.target.closest('.ch'); if (!c) return; if (c.dataset.back) { const g = GROUPS[st.group]; if (g && g.parent) showGroup(g.parent); focusTA(); return; } const g = st.group; run(c.dataset.cmd); if ((st.mode === 'text' || (st.mode === 'tree' && g)) && !st.form) { if (st.group === g) { disarm(); afterGroupItem(); drawSub(); } else drawSub(); focusTA(); } if (st.tprevCmd) targetPreview(st.form ? null : st.tprevCmd); }); /* 実行したあとの対象を見せ直す（節を動かしたら動いた先） */
$('status').addEventListener('pointerdown', e => { e.preventDefault(); });
/* ---------- P06：帯をキーで操作する ----------
   同じ F キーを続けて 2 回押すと、帯の項目にキーの印（白黒の太い枠）が乗る。←→ で前後、↑↓ で上下の段、Home・End、Enter・Space で実行、Esc・Tab で本文へ。
   実行したら本文の編集位置に戻る（欄やもっと深い帯を開く項目はそちらへ）。字のキー・Ctrl の近道は本文に戻してそのまま効かせる（本文の Tab・変換・図の矢印とはぶつからない） */
function bandTiles() { return [...sub.querySelectorAll('.ch[data-cmd], .ch[data-back], select[data-msel]')].filter(el => el.getClientRects().length); }
function bandEnter(cmd) { const T = bandTiles(); if (!T.length) return false; st.bandKb = true; sub.classList.add('kb'); bandFocus((cmd && T.find(x => x.dataset.cmd === cmd)) || T.find(x => x.classList.contains('on')) || T[0]); return true; }
function bandFocus(el) { if (!el) return; if (el.tagName !== 'SELECT') el.tabIndex = -1; st.formFocus = true; el.focus({ preventScroll: true }); st.bandCmd = el.dataset.cmd || el.dataset.msel || el.dataset.back || null; targetPreview(el.dataset.cmd || null); updateGuide(); }
function bandLeave(toBody = true) { if (!st.bandKb) return; st.bandKb = false; st.bandCmd = null; st.formFocus = false; sub.classList.remove('kb'); targetPreview(null); updateGuide(); if (toBody) focusTA(); }
function bandNear(T, cur, dir) { const r0 = cur.getBoundingClientRect(), cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2; let best = null, bs = Infinity;
  for (const el of T) { if (el === cur) continue; const r = el.getBoundingClientRect(), y = r.top + r.height / 2, dy = (y - cy) * dir; if (dy < 4) continue; const sc = Math.round(dy / 6) * 1000 + Math.abs(r.left + r.width / 2 - cx); if (sc < bs) { bs = sc; best = el; } } return best || cur; }
function bandActivate(el) { if (!el) return; if (el.dataset.back) { const g = GROUPS[st.group]; if (g && g.parent) { showGroup(g.parent); bandEnter(); } return; }
  const cmd = el.dataset.cmd, g = st.group; bandLeave(false); run(cmd);
  if ((st.mode === 'text' || (st.mode === 'tree' && g)) && !st.form) { if (st.group !== g && GROUPS[st.group] && GROUPS[st.group].parent === g) { drawSub(); bandEnter(); return; } /* もっと深い帯（見出し飾り・表の様式）：そのままキーで選ぶ */
    if (st.group === g) { disarm(); afterGroupItem(); } drawSub(); focusTA(); } else if (!st.form) focusTA(); }
sub.addEventListener('keydown', e => { if (st.form || !st.bandKb) return; const k = e.key, cur = document.activeElement; const T = bandTiles(); const i = T.indexOf(cur);
  if (imeKey(e)) { bandLeave(); return; } /* 変換が始まった：本文へ */
  if (k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); bandFocus(T[((i < 0 ? 0 : i) + (k === 'ArrowRight' ? 1 : -1) + T.length) % T.length]); return; }
  if (k === 'ArrowUp' || k === 'ArrowDown') { if (cur && cur.tagName === 'SELECT') return; e.preventDefault(); bandFocus(cur && i >= 0 ? bandNear(T, cur, k === 'ArrowDown' ? 1 : -1) : T[0]); return; }
  if (k === 'Home' || k === 'End') { e.preventDefault(); bandFocus(k === 'Home' ? T[0] : T[T.length - 1]); return; }
  if (k === 'Enter' || k === ' ') { if (cur && cur.tagName === 'SELECT') { if (k === 'Enter') { e.preventDefault(); bandLeave(); } return; } e.preventDefault(); bandActivate(cur); return; }
  if (k === 'Escape' || k === 'Tab') { e.preventDefault(); bandLeave(); return; }
  if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(k)) return;
  if (/^F\d+$/.test(k)) { e.preventDefault(); bandLeave(); if (!e.ctrlKey && !e.altKey) fkey(k); return; }
  bandLeave(); onKey(e); }); /* 字・近道：本文に戻して、本文のキーとして扱う */
sub.addEventListener('focusout', e => { if (!st.bandKb || st.form) return; if (e.relatedTarget && sub.contains(e.relatedTarget)) return; setTimeout(() => { if (st.bandKb && !sub.contains(document.activeElement)) bandLeave(false); }, 0); });
/* ---------- P07：操作の対象を先に見せる ----------
   帯の項目にマウスを乗せる・キーで印を乗せると、紙面の対象を細い枠で囲み、案内の行に「対象：…」を出す。確認の小窓は出さない（取消は 1 回の Ctrl+Z）。
   対象の解決は実際のコマンドと同じ関数（構造の上下＝ed.sectionRange、上げ下げ＝caretNode、種類＝ed.selectedLines・kindGuard の条件、番号の形＝FORMS.marker.node と treeMarkerNow） */
function rangeDesc(a, b, skipHead) { const L = ed.doc.lines; let items = 0, paras = 0, tables = 0, figs = 0, inT = false;
  for (let k = a + (skipHead ? 1 : 0); k <= b && k < L.length; k++) { const at = L[k].attrs; figs += (at.figs || []).length; if (at.cells) { if (!inT) tables++; inT = true; continue; } inT = false; if (at.list || FZ.isHeading(at)) items++; else if (L[k].segs.some(sg => sg.text.trim())) paras++; }
  return [items && `${items} 項目`, paras && `段落 ${paras}`, tables && `表 ${tables} 点`, figs && `図表 ${figs} 点`].filter(Boolean).join('・'); }
const lineText = (i, n = 14) => { const t = (ed.doc.lines[i] ? ed.doc.lines[i].segs.map(sg => sg.text).join(' ') : '').replace(/\s+/g, ' ').trim(); return [...t].length > n ? [...t].slice(0, n).join('') + '…' : t; };
const qline = i => { const t = lineText(i); return t ? '「' + t + '」' : '（空行）'; };
function nodeRange(n) { const i = n && n.obj ? ed.doc.lines.indexOf(n.obj) : -1; if (i < 0) return null; return [i, n.kind === 'sent' ? i : i + Math.max(0, (n.end | 0) - (n.line | 0))]; }
function nodeTargetText(n, R) { if (n.kind === 'sent') return `選んだ文「${String(n.text || '').slice(0, 14)}」`; const sub = rangeDesc(R[0], R[1], true); return R[1] > R[0] ? `${qline(R[0])}の節と配下 ${sub || '（中身なし）'}` : `${qline(R[0])}の行`; }
function moveTarget(op) { const verb = { up: '上へ', down: '下へ', out: '上げる', in: '下げる' }[op];
  if (st.mode === 'tree') { const list = treeSelected(); const ns = list.length ? list : [treeNodeSel()].filter(Boolean); const R = ns.map(nodeRange).filter(Boolean); if (!R.length) return null; return { ranges: R, text: `${verb}：${ns.length > 1 ? `選んだ ${ns.length} 節` : nodeTargetText(ns[0], R[0])}` }; }
  if (st.mode !== 'text') return null;
  if ((op === 'up' || op === 'down') && !sentSelOk()) { const R = ed.sectionRange(ed.caret.line); return { ranges: [R], text: `${verb}：${R[1] > R[0] ? `${qline(R[0])}の節と配下 ${rangeDesc(R[0], R[1], true) || '（中身なし）'}` : `${qline(R[0])}の行`}` }; } /* outlineUp・outlineDown（ed.moveSection）と同じ範囲 */
  const { node } = caretNode(); if (!node) return null; const R = nodeRange(node); if (!R) return null; return { ranges: [R], text: `${verb}：${nodeTargetText(node, R)}` }; }
const KIND_NAME = { body: '本文', title: '表題', num: '番号見出し', sym: '記号見出し', list: '箇条書き', nlist: '番号箇条書き' };
function kindTarget(k) { const nm = KIND_NAME[k];
  if (st.mode === 'tree') { const n = treeNodeSel(); const R = n && nodeRange(n); if (!R) return null; return { ranges: [R], text: `種類を${nm}へ：${nodeTargetText(n, R)}（子の段も揃える）` }; }
  if (st.mode !== 'text') return null;
  if (sentSelOk() && st.sentSel.n > 1) { const L = ed.caret.line; return { ranges: [[L, L]], text: `選んだ文を段落から取り出して${nm}に` }; } /* kindGuard と同じ条件 */
  const [a, b] = ed.selectedLines(); const L = ed.doc.lines.slice(a, b + 1); const cur = ed.line().attrs;
  const same = (k === 'num' || k === 'sym') && cur.style === k; const fixed = L.some(l => l.attrs.indent != null && FZ.nodeKind(l.attrs));
  const notes = [same ? `${nm}なので外して本文に` : '', fixed ? '個別の位置指定は保持' : '', k === 'body' && L.some(l => l.attrs.style || l.attrs.list) ? '番号・記号は外れ、位置は保つ' : ''].filter(Boolean);
  return { ranges: [[a, b]], text: `種類を${same ? '本文' : nm}へ変更（${b > a ? `選んだ ${b - a + 1} 行` : `${qline(a)}の行`}）${notes.length ? '。' + notes.join('・') : ''}` }; }
function markerTarget() { const n = FORMS.marker.node(); const m = n && treeMarkerNow(n); if (!m) return { ranges: [], text: '番号・記号の形：番号見出し・記号見出し・箇条書きの行で使う' };
  const tr = FZ.tree.build(ed.doc, { body: true }); const R = []; for (const x of tr.nodes) if (treeKindOf(x) === m.k && (x.level | 0) === m.lv) { const i = ed.doc.lines.indexOf(x.obj); if (i >= 0) R.push([i, i]); }
  return { ranges: R, text: `${m.name}${m.lv + 1} の番号・記号（いま「${m.tok === FZ.NONE_TOKEN ? 'なし' : m.tok}」）：文書全体 ${R.length} 箇所` }; }
const TARGETS = { 'sx:up': () => moveTarget('up'), 'sx:down': () => moveTarget('down'), 'sx:out': () => moveTarget('out'), 'sx:in': () => moveTarget('in'), outlineUp: () => moveTarget('up'), outlineDown: () => moveTarget('down'),
  styleBody: () => kindTarget('body'), styleTitle: () => kindTarget('title'), styleNum: () => kindTarget('num'), styleSym: () => kindTarget('sym'), item: () => kindTarget('list'), numItem: () => kindTarget('nlist'),
  'sx:mark': () => markerTarget(),
  /* P18：書き出しは目的と対象を先に */
  exportDocx: () => ({ text: st.view === 'tree' ? 'ツリー図を Word に：ツリーの見た目のまま（頁ごとの図。箱と線は Word の図形）' : ed.doc.format.kind === 'slide' ? `紙面を保つ Word：資料 ${pagesN()} 頁を、PowerPoint と同じ紙面のまま Word の頁に図形で置く（段落の流れは無い。Word で書き直すなら「Word構成」）` : `Word：文書全体 ${pagesN()} 頁を見出しスタイル・自動番号・表・図で` }),
  exportDocxFlow: () => ({ text: ed.doc.format.kind === 'slide' ? `構成を Word に：資料 ${pagesN()} 頁を見出しと本文の流れで（区画の並び・図表欄の位置は捨てる）` : `Word（構成）：この文書はふつうの Word と同じ（${pagesN()} 頁）` }),
  exportPptx: () => ({ text: st.view === 'tree' ? 'ツリー図を PowerPoint に（箱と線は図形。節の途中で頁を切らない）' : `PowerPoint：1 頁＝1 スライド、${pagesN()} 枚（番号・記号は字として入る）` }),
  exportHtml: () => ({ text: `HTML：文書全体 ${pagesN()} 頁を紙面のまま（頁は SVG のベクター、目次つき。社内の掲示・Web にそのまま。印刷もできる）` }),
  exportPdf: () => ({ text: `PDF：文書全体 ${pagesN()} 頁を紙面のまま（印刷の窓で「PDF に保存」）。正式な提出に` }),
  exportTxt: () => ({ text: `テキスト：文書全体 ${ed.doc.lines.length} 行の字だけ（飾り・罫・網・画像は入らない）` }),
  exportMd: () => ({ text: 'Markdown ファイル：文書全体（文机の注記つき。読み込むと戻る）' }),
  aiCopySec: () => { const sc = aiScope(false); return { ranges: sc.range ? [sc.range] : [], text: `AI に写す範囲：${sc.what}（Markdown でクリップボードへ）` }; },
  aiCopyDoc: () => ({ ranges: [], text: 'AI に写す範囲：文書全体（Markdown でクリップボードへ）' }),
  fitCheck: () => ({ ranges: [], text: `紙幅の使い道：いま ${pagesN()} 頁${ed.doc.format.targetPages ? `・目標 ${ed.doc.format.targetPages} 頁` : ''}（何が紙幅を使っているか・はみ出す原因・試す案）` }) };
const pagesN = () => (ed.lay && ed.lay.pages ? ed.lay.pages.length : '?');
FZ.targetOf = cmd => { const f = TARGETS[cmd]; try { return f ? f() : null; } catch (e) { return null; } };
function targetPreview(cmd) { const t = cmd ? FZ.targetOf(cmd) : null; const had = !!st.tprev; st.tprev = t; st.tprevCmd = t ? cmd : null; if (t || had) { requestOverlay(); updateGuide(); } }
sub.addEventListener('pointerover', e => { if (st.form || st.bandKb) return; const c = e.target.closest && e.target.closest('.ch[data-cmd]'); const cmd = c ? c.dataset.cmd : null; if (cmd !== st.tprevCmd) targetPreview(cmd); });
sub.addEventListener('pointerleave', () => { if (!st.bandKb && st.tprev) targetPreview(null); });
/* ---------- インライン・フォーム ---------- */
const FORMS = {};
const TREE_FORMS = new Set(['count', 'format', 'scheme', 'slide', 'table', 'toc', 'fig', 'figref', 'newdoc', 'tplname', 'chart', 'tfind', 'marker', 'figtree', 'moveTo', 'scheck', 'sentopt', 'secref', 'skeleton', 'parked', 'aiback', 'panels']); // ツリーのまま帯で開く欄
function openForm(name) { if (st.bandKb) { st.bandKb = false; st.bandCmd = null; sub.classList.remove('kb'); targetPreview(null); } if (st.formSession && st.formSession.name !== name) formSessionEnd(false); if (!st.formSession) formSessionStart(name); const figForm = st.mode === 'fig' && (name === 'box' || name === 'arrow' || name === 'lanes'); if (st.mode !== 'text' && name !== 'table' && !figForm && !(st.mode === 'tree' && TREE_FORMS.has(name))) exitMode(); st.armed = false; st.form = name; if (st.mode === 'text' && FORM_GROUP[name]) st.group = FORM_GROUP[name]; if (st.mode === 'tree') st.group = null; drawSub(); drawFkeys(); }
function toggleForm(name) { if (st.form === name) closeForm(); else openForm(name); }
function closeForm() { if (!st.form) return; const was = st.form; if (was === 'phase') { st.pufuCmp = null; requestOverlay(); } if (st.formSession) formSessionEnd(false); if (was === 'ruler' && st.rulerGrid) { st.grid = st.rulerGrid.grid; st.gridMode = st.rulerGrid.mode; st.rulerGrid = null; pageCache = pageCache.map(() => ''); requestRender(); } if (was === 'fit') { st.fitView = false; requestOverlay(); } /* 物差しの方眼は閉じたら元に */ if (was === 'parked') { st.form = null; drawIsland(); } if (was === 'tfind' && st.tree.find) st.tree.find = ''; st.form = null; if ((was === 'tfind' || was === 'scheck' || was === 'aiback') && (st.view === 'tree' || st.view === 'split')) render(); if (was === 'aiback') { st.aiBack = null; requestOverlay(); } st.formFocus = false; if (st.mode === 'tree') render(); drawSub(); drawFkeys(); focusTA(); }
/* 選択肢：プルダウン（vals = [[値, 表示], …]、cur = 今の値） */
const cycOpts = (vals, cur) => { let i = vals.findIndex(v => v[0] === cur); if (i < 0) i = 0; return vals.map((v, k) => `<option value="${esc(v[0])}"${k === i ? ' selected' : ''}>${esc(v[1])}</option>`).join(''); };
function cyc(name, vals, cur) { return `<select class="cyc" name="${name}" data-name="${name}">${cycOpts(vals, cur)}</select>`; }
function cycVal(name) { const b = sub.querySelector(`select.cyc[data-name="${name}"]`); return b ? b.value : null; }
function inp(name, val, cls = '', type = 'text', extra = '') { return `<input name="${name}" class="${cls}" type="${type}" value="${esc(val)}" ${extra}>`; }
function fval(name) { const el = sub.querySelector(`[name="${name}"]`); return el ? el.value : ''; } // input と select の両方
function drawForm() {
  sub.classList.add('form'); const F = FORMS[st.form]; sub.innerHTML = F.html();
  sub.querySelectorAll('input').forEach(i => i.addEventListener('input', () => { if (F.change) F.change(i.name); }));
  sub.querySelectorAll('select').forEach(i => i.addEventListener('change', () => { if (F.change) F.change(i.name); }));
  st.formFocus = true; const first = sub.querySelector(F.focus || 'input') || sub.querySelector('button'); if (first) { first.focus(); if (first.select) first.select(); }
  if (F.change) F.change();
}
/* P03：かな漢字の変換中のキー（Enter で確定・矢印で候補・Esc で取消）は IME のもの。帯の欄・コマンドの検索・型の選び場では、変換中のキーで操作を走らせない */
const imeKey = e => !!(e && (e.isComposing || e.keyCode === 229 || e.key === 'Process'));
FZ.imeKey = imeKey;
sub.addEventListener('keydown', e => { if (!st.form || imeKey(e)) return; const F = FORMS[st.form]; if (e.key === 'Escape') { e.preventDefault(); if (F.preview) cancelForm(); else closeForm(); return; }
  if (e.key === 'Enter' && e.target.tagName !== 'BUTTON' && !(e.target.tagName === 'TEXTAREA' && !(e.ctrlKey || e.metaKey))) { e.preventDefault(); if (F.enter) F.enter(e); } if (F.key) F.key(e); });
sub.addEventListener('change', e => { const s0 = e.target.closest && e.target.closest('select[data-msel]'); if (!s0) return; const g = st.group; MSEL[s0.dataset.msel].set(s0.value); if (st.form) return; if (st.mode === 'text' || st.mode === 'tree') { if (g && st.group === g) { disarm(); afterGroupItem(); } } drawSub(); drawFkeys(); focusTA(); });
sub.addEventListener('click', e => { const b = e.target.closest('button[data-act]'); if (!b || !st.form) return; const F = FORMS[st.form]; if (F.act) F.act(b.dataset.act, e); });
sub.addEventListener('change', e => { if (st.form && FORMS[st.form] && FORMS[st.form].commit) FORMS[st.form].commit(e); }); /* 欄の中の確定（セルを離れた等） */
sub.addEventListener('paste', e => { if (st.form && FORMS[st.form] && FORMS[st.form].paste) FORMS[st.form].paste(e); });
/* 書式 */
FORMS.format = {
  /* 1.0.10u：項目を 6 つの塊（用紙・版面・余白・書体・組み・柱）に分け、3 行の格子に並べる。種類と資料の柱は入口を 1 つに（左上の種類・F9 の柱・表紙） */
  html() { const f = ed.doc.format; const B = (t, inner, cls = '') => `<div class="fb${cls ? ' ' + cls : ''}"><span class="fbt">${t}</span>${inner}</div>`;
    return `<div class="fgrid"><div class="frow">${B('用紙', `${cyc('paper', [['A4', 'A4'], ['A5', 'A5'], ['B5', 'B5'], ['B4', 'B4'], ['A3', 'A3'], ['Letter', 'Letter'], ['custom', '自由']], FZ.PAPERS[f.paper] ? f.paper : 'custom')}${cyc('landscape', [['0', '縦'], ['1', '横']], f.widthMm > f.heightMm ? '1' : '0')}<label>幅${inp('widthMm', f.widthMm, 'n', 'number', 'step="0.1"')}</label><label>高${inp('heightMm', f.heightMm, 'n', 'number', 'step="0.1"')}</label><span class="u">mm</span>`)}${B('版面', `<label>文字数${inp('cols', f.cols, 'n', 'number', 'min="4" max="200"')}</label><label>行数${inp('rows', f.rows, 'n', 'number', 'min="2" max="300"')}</label><span class="info" id="fmtInfo"></span>`)}</div>
    <div class="frow">${B('余白', `<label>上${inp('top', f.margins.top, 'n', 'number', 'step="0.5"')}</label><label>下${inp('bottom', f.margins.bottom, 'n', 'number', 'step="0.5"')}</label><label>左${inp('left', f.margins.left, 'n', 'number', 'step="0.5"')}</label><label>右${inp('right', f.margins.right, 'n', 'number', 'step="0.5"')}</label>`)}${B('組み', `<label>ぶら下げ${cyc('hang', [['1', 'する'], ['0', 'しない']], f.hang ? '1' : '0')}</label><button type="button" data-act="scheme">体系と空き…</button>`)}<div class="fb fend"><button type="button" data-act="setDefault" title="${f.kind === 'slide' ? 'この版面（用紙・文字数・行数・余白・柱）を新しい資料の既定にする（文書の既定とは別）' : 'この書式を新しい文書の既定にする（資料の既定とは別）'}">${f.kind === 'slide' ? '資料の既定に' : '文書の既定に'}</button><button type="button" data-act="loadDefault" title="${f.kind === 'slide' ? '資料の既定の版面を当てる' : '文書の既定の書式を当てる'}">既定を当てる</button></div></div>
    <div class="frow">${B('書体', `<label>本文${cyc('font', [['mincho', '明朝'], ['gothic', 'ゴシック']], f.font === 'gothic' ? 'gothic' : 'mincho')}</label><label>明朝${fontPicker('fontMincho', f.fontMincho || 'BIZ UDMincho')}</label><label>ゴシック${fontPicker('fontGothic', f.fontGothic || 'BIZ UDGothic')}</label><button type="button" data-act="fonts" title="この PC に入っている書体をすべて読む（初回はブラウザが許可を求めます）">全書体を読む</button>`)}${B('基準の字幅', `<label title="全角の字（漢字・かな・全角の記号）を元の書体の何％の幅で描くか。100％ は元のまま。字はマスの中ほどに置く">全角${inp('zenW', Math.round(FZ.glyphPct(f.zenW) * 100), 'n', 'number', 'min="30" max="200" step="5"')}%</label><label title="半角の字（英数字・半角記号）を元の書体の何％の幅で描くか。プロポーショナルな書体の英数字を半マスに収める。それでもはみ出す字（W・M など）はさらに縮める">半角${inp('hanW', Math.round(FZ.glyphPct(f.hanW) * 100), 'n', 'number', 'min="30" max="200" step="5"')}%</label><button type="button" data-act="fit" title="選んだ明朝・ゴシックの字をこの PC で測って、全角・半角の字がマスに収まる％を入れる">測る</button>`)}</div>
    <div class="frow">${B('書体の組', `${cyc('fprof', fontProfVals(), String(fontProfMatch(f)))}<label>名前${inp('fpname', '', 'm', 'text', 'placeholder="今の書体と字幅に名前を付けて保存"')}</label><button type="button" data-act="fpsave">保存</button><button type="button" data-act="fpdel">削除</button>`)}</div>
    <div class="frow">${B('柱', `<label title="差し込み：{file} ファイル名（保存し直すとその名前に）／{page} 頁番号／{pages} 総頁数">ヘッダ${inp('header', f.header, 'w')}</label><label>${inp('headerRows', f.headerRows, 'n', 'number', 'min="0" max="8"')}行</label><label title="差し込み：{page} 頁番号／{pages} 総頁数／{file} ファイル名">フッタ${inp('footer', f.footer, 'w')}</label><label>${inp('footerRows', f.footerRows, 'n', 'number', 'min="0" max="8"')}行</label><label title="{page} の最初の番号（0 から）">開始${inp('pageStart', f.pageStart, 'n', 'number', 'min="0" max="9999"')}</label>`)}<div class="fb fend"><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button></div></div></div>`; },
  read() { const f = JSON.parse(JSON.stringify(ed.doc.format)); const n = k => +fval(k); /* 書体は選択欄（name=fontMincho／fontGothic）の値 */ f.paper = cycVal('paper'); f.widthMm = n('widthMm'); f.heightMm = n('heightMm'); f.landscape = cycVal('landscape') === '1'; f.cols = n('cols'); f.rows = n('rows'); f.margins = { top: n('top'), right: n('right'), bottom: n('bottom'), left: n('left') }; f.header = fval('header'); f.footer = fval('footer'); { const v = fval('pageStart'); if (v != null) f.pageStart = String(v).trim() === '' ? 1 : +v; } f.headerRows = n('headerRows'); f.footerRows = n('footerRows'); f.font = cycVal('font'); f.fontMincho = fval('fontMincho').trim() || 'BIZ UDMincho'; f.fontGothic = fval('fontGothic').trim() || 'BIZ UDGothic'; for (const k of ['zenW', 'hanW']) { const v = FZ.glyphPct(fval(k)); if (v === 1) delete f[k]; else f[k] = Math.round(v * 100); } f.hang = cycVal('hang') === '1'; return f; }, /* 種類は左上の「種類」だけで変える（入口ひとつ） */
  change(name) {
    const set = (k, v) => { const el = sub.querySelector(`[name="${k}"]`); if (el) el.value = v; };
    if (name === 'paper' && FZ.PAPERS[cycVal('paper')]) { let [w, h] = FZ.PAPERS[cycVal('paper')]; if (cycVal('landscape') === '1') [w, h] = [h, w]; set('widthMm', w); set('heightMm', h); }
    if (name === 'kind' && cycVal('kind') === 'slide') { const s = slideFormat(this.read()); for (const k of ['widthMm', 'heightMm', 'cols', 'rows', 'headerRows', 'footerRows']) set(k, s[k]); setCyc('paper', [['A4', 'A4'], ['A5', 'A5'], ['B5', 'B5'], ['B4', 'B4'], ['A3', 'A3'], ['Letter', 'Letter'], ['custom', '自由']], 'A4'); setCyc('landscape', [['0', '縦'], ['1', '横']], '1'); } // 資料にしたら A4 横・60×26・柱 2 行を提案（適用前に直せる）
    if (name === 'fprof') { const v = cycVal('fprof'); if (v !== '-') { const pr = fontProfiles()[+v]; fillFontProf(pr); const nm = sub.querySelector('[name="fpname"]'); if (nm) nm.value = pr.builtin ? '' : pr.name; } }
    else if (['fontMincho', 'fontGothic', 'zenW', 'hanW'].includes(name)) setCyc('fprof', fontProfVals(), String(fontProfMatch(this.read())));
    if (name === 'landscape') { const w = +fval('widthMm'), h = +fval('heightMm'); set('widthMm', cycVal('landscape') === '1' ? Math.max(w, h) : Math.min(w, h)); set('heightMm', cycVal('landscape') === '1' ? Math.min(w, h) : Math.max(w, h)); }
    try { const f = this.read(); const g = FZ.geometry(f); const bad = !(g.areaW > 0 && g.areaH > 0) || !(f.cols >= 4) || !(f.rows >= 2); const el = $('fmtInfo'); el.className = 'info' + (bad ? ' alert' : ''); el.textContent = bad ? '余白・文字数・行数が不正' : `${(g.cw / FZ.PT).toFixed(1)}×${(g.ch / FZ.PT).toFixed(1)}mm ${g.fs.toFixed(1)}pt`; el.title = '1 マスの大きさと字の大きさ'; } catch { }
  },
  enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'scheme') { closeForm(); openForm('scheme'); return; } if (a === 'slide') { const f = this.read(); closeForm(); if (f.kind !== ed.doc.format.kind) ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); openForm('slide'); return; } if (a === 'setDefault') { const f = this.read(); if (f.kind === 'slide') { try { localStorage.setItem(SLIDE_DEFAULTS_KEY, JSON.stringify(pickPage(f))); } catch { } msg('この版面を資料の既定にしました（新しい資料・資料にする時に使う。文書の既定は別）'); } else { const d = { ...f }; delete d.pageAlt; saveDefaults(d); msg('この書式を文書の既定にしました（新しい文書・文書にする時に使う。資料の既定は別）'); } return; }
      if (a === 'loadDefault') { closeForm(); const slide = ed.doc.format.kind === 'slide'; ed.mutate('', () => { const cur = ed.doc.format; const f = slide ? slideFormat(cur) : JSON.parse(JSON.stringify(defaultFormat())); if (!slide) f.kind = 'doc'; if (cur.pageAlt) f.pageAlt = cur.pageAlt; ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); msg(slide ? '資料の既定の版面を当てました' : '文書の既定の書式を当てました'); return; } if (a === 'fit') { const r = measureFit(fval('fontMincho'), fval('fontGothic')); setVal('zenW', r.zen); setVal('hanW', r.han); setCyc('fprof', fontProfVals(), String(fontProfMatch(this.read()))); msg(`測りました：全角 ${r.zen}%・半角 ${r.han}%（${r.note}）`, !!r.miss); return; }
      if (a === 'fpsave') { const name = fval('fpname').trim(); if (!name) { msg('書体の組の名前を入れてください', true); sub.querySelector('[name="fpname"]').focus(); return; } if (FONT_PROFILES.some(p => p.name === name)) { msg('内蔵の組と同じ名前は使えません', true); return; } const f = this.read(); const us = userFontProfiles().filter(p => p.name !== name); us.push({ name, mincho: f.fontMincho, gothic: f.fontGothic, zen: Math.round(FZ.glyphPct(f.zenW) * 100), han: Math.round(FZ.glyphPct(f.hanW) * 100) }); saveUserFontProfiles(us); setCyc('fprof', fontProfVals(), String(fontProfiles().findIndex(p => p.name === name))); msg('書体の組を保存：' + name + '（この PC のブラウザに。設定の書き出しにも入る）'); return; }
      if (a === 'fpdel') { const v = cycVal('fprof'); const ps = fontProfiles(); if (v === '-' || ps[+v].builtin) { msg('内蔵の組は削除できません（自分で保存した組のみ）', true); return; } const name = ps[+v].name; saveUserFontProfiles(userFontProfiles().filter(p => p.name !== name)); setCyc('fprof', fontProfVals(), '-'); const nm = sub.querySelector('[name="fpname"]'); if (nm) nm.value = ''; msg('書体の組を削除：' + name); return; }
      if (a === 'fonts') { loadFontList(true).then(() => { for (const k of ['fontMincho', 'fontGothic']) { const el = sub.querySelector(`select[name="${k}"]`); if (el) { const v = el.value; el.innerHTML = fontOptions(v); el.value = v; } } msg(st.fontList && st.fontList.length ? `書体 ${st.fontList.length} 件を一覧に読みました` : '書体の一覧を読めませんでした', !(st.fontList && st.fontList.length)); }); return; } const f = this.read(); const g = FZ.geometry(f); if (!(g.areaW > 0 && g.areaH > 0)) { msg('余白が用紙より大きい', true); return; } closeForm(); ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.normalizeSegs(); }); msg('書式を適用'); },
};
/* 階層体系：8 階層それぞれに番号書式／記号／なし。プリセット（内蔵＋自分で保存） */
const SCHEME_KEY = 'fz.schemes';
function userSchemes() { try { const a = JSON.parse(localStorage.getItem(SCHEME_KEY) || '[]'); return Array.isArray(a) ? a.filter(p => p && p.name && (Array.isArray(p.num) || Array.isArray(p.levels))).map(p => ({ name: String(p.name), num: FZ.normalizeScheme(p.num || p.levels), title: p.title == null ? 2 : clamp(p.title | 0, 0, 8), sym: FZ.normalizeScheme(p.sym, FZ.DEFAULT_SYM), bullet: FZ.normalizeScheme(p.bullet, FZ.DEFAULT_BULLET) })) : []; } catch { return []; } }
function saveUserSchemes(a) { try { localStorage.setItem(SCHEME_KEY, JSON.stringify(a)); } catch { } }
function setCyc(name, vals, cur) { const b = sub.querySelector(`select.cyc[data-name="${name}"]`); if (!b) return; b.innerHTML = cycOpts(vals, cur); }
const SCHEME_PAL = () => [...FZ.NUMBER_KEYS, ...FZ.SYMBOL_PRESETS, ...FZ.WRAP_PAIRS, FZ.NONE_TOKEN];
FORMS.scheme = {
  presets() { return [...FZ.SCHEME_PRESETS.map(p => ({ ...p, builtin: true })), ...userSchemes()]; },
  presetVals(ps) { return [...ps.map((p, i) => [String(i), p.name + (p.builtin ? '' : '＊')]), ['-', '（自由）']]; },
  sameAs(p, f) { return p.num.join(' ') === f.scheme.join(' ') && (p.title | 0) === (f.titleLevels | 0) && p.sym.join(' ') === FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM).join(' ') && p.bullet.join(' ') === FZ.normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET).join(' '); },
  html() {
    const f = ed.doc.format, ps = this.presets(), cur = ps.findIndex(p => this.sameAs(p, f));
    const pal = k => `<button type="button" class="pal" data-act="pal" data-tok="${esc(k)}">${esc(k)}</button>`;
    const row = (ttl, key, toks) => `<span style="flex-basis:100%;height:0"></span><span class="cat" style="min-width:5.5em">${ttl}</span>` + toks.map((t, i) => `<label class="lvl">${i + 1}${inp(key + i, t, 'lv', 'text', `data-i="${i}" spellcheck="false" autocomplete="off"`)}</label>`).join('');
    return `<span class="ttl">三体系</span><label>プリセット ${cyc('preset', this.presetVals(ps), cur >= 0 ? String(cur) : '-')}</label>` +
      `<label>題のレベル数 ${cyc('title', Array.from({ length: 9 }, (_, i) => [String(i), String(i)]), String(f.titleLevels | 0))}</label>` +
      `<label>記号見出しで番号を ${cyc('reset', [['0', '続ける'], ['1', '仕切り直す']], f.symResetsNum ? '1' : '0')}</label>` +
      `<label title="本文・箇条書きから見出しに戻るとき（と、深い節から浅い節に戻るとき）に 1 行空ける。見出しから下りるときは空けない。区切り線：大きな節の前の空きの真ん中に線">戻り空き ${cyc('rgap', [['0', 'なし'], ['1', 'あり'], ['rule', 'あり＋区切り線']], f.returnGap === 'rule' ? 'rule' : f.returnGap ? '1' : '0')}</label>` +
      `<label title="本文・箇条書きの後に来る題（題レベルの数字見出し・記号見出し・表題）の前に 1 行空ける">題の前空き ${cyc('tgap', [['0', 'なし'], ['1', 'あり']], f.titleGap ? '1' : '0')}</label>` +
      `<label title="表題（文書の題）と、そのすぐ後の本文・見出しの間に 1 行空ける。表題が続くとき・すでに空行があるときは空けない">表題の後空き ${cyc('taft', [['0', 'なし'], ['1', 'あり']], f.titleAfter ? '1' : '0')}</label>` +
      `<label title="表のすぐ前が本文・見出しなどの中身なら、表の前に 1 行空ける（空行があるとき・ページの頭は空けない）">表の前空き ${cyc('tgap2', [['0', 'なし'], ['1', 'あり']], f.tableGap ? '1' : '0')}</label>` +
      `<label title="本文の段落（見出しでも箇条書きでもない段落）の行頭。見出しの頭＋1字＝見出しの番号・記号の桁から 1 字下げ（既定）、見出しの頭＝番号・記号の桁、見出しの文字＝番号の後ろの文字の桁、左端＝見出しに関係なく左端。位置を決めた行（配置の「左へ・右へ」）は従わない">本文の位置 ${cyc('bfol', [['0', '左端'], ['mark', '見出しの頭'], ['step', '見出しの頭＋1字'], ['1', '見出しの文字']], f.bodyFollow === 'mark' || f.bodyFollow === 'step' ? f.bodyFollow : f.bodyFollow ? '1' : '0')}</label>` +
      row('数字見出し', 'n', f.scheme) + row('記号見出し', 's', FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM)) + row('箇条書き', 'b', FZ.normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET)) + row('番号付き箇条書き', 'l', FZ.normalizeScheme(f.listScheme, FZ.DEFAULT_LIST)) +
      `<span style="flex-basis:100%;height:0"></span><span class="pal-row">` + FZ.NUMBER_KEYS.map(pal).join('') + `<span class="sep"></span>` + FZ.SYMBOL_PRESETS.map(pal).join('') + `<span class="sep"></span>` + FZ.WRAP_PAIRS.map(pal).join('') + pal(FZ.NONE_TOKEN) + `</span>` +
      `<span style="flex-basis:100%;height:0"></span><span class="info" id="schInfo"></span><span class="sp"></span>` +
      `<label>名前 ${inp('name', cur >= 0 && !ps[cur].builtin ? ps[cur].name : '', 'm', 'text', 'placeholder="自分の体系として保存"')}</label><button type="button" data-act="save">保存</button><button type="button" data-act="del">削除</button><button type="button" data-act="setDefault" title="この三体系を新しい文書の既定にする">既定にする</button>` +
      `<button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`;
  },
  focus: 'input.lv',
  read() { const g = k => Array.from({ length: 8 }, (_, i) => fval(k + i)); return { num: FZ.normalizeScheme(g('n')), title: clamp(+cycVal('title') | 0, 0, 8), sym: FZ.normalizeScheme(g('s'), FZ.DEFAULT_SYM), bullet: FZ.normalizeScheme(g('b'), FZ.DEFAULT_BULLET), list: FZ.normalizeScheme(g('l'), FZ.DEFAULT_LIST), reset: cycVal('reset') === '1', rgap: cycVal('rgap') === 'rule' ? 'rule' : cycVal('rgap') === '1', tgap: cycVal('tgap') === '1', taft: cycVal('taft') === '1', tblg: cycVal('tgap2') === '1', bfol: cycVal('bfol') === 'mark' || cycVal('bfol') === 'step' ? cycVal('bfol') : cycVal('bfol') === '1' }; },
  fill(p) { const set = (k, toks) => toks.forEach((t, i) => { const el = sub.querySelector(`[name="${k}${i}"]`); if (el) el.value = t; }); set('n', p.num); set('s', p.sym); set('b', p.bullet); setCyc('title', Array.from({ length: 9 }, (_, i) => [String(i), String(i)]), String(p.title | 0)); },
  change(name) {
    if (name === 'preset') { const v = cycVal('preset'); if (v !== '-') { const p = this.presets()[+v]; this.fill(p); const nm = sub.querySelector('[name="name"]'); if (nm) nm.value = p.builtin ? '' : p.name; } }
    else if (name && /^[nsb]\d$/.test(name) || name === 'title') { const ps = this.presets(), r = this.read(), k = ps.findIndex(p => p.num.join(' ') === r.num.join(' ') && (p.title | 0) === r.title && p.sym.join(' ') === r.sym.join(' ') && p.bullet.join(' ') === r.bullet.join(' ')); setCyc('preset', this.presetVals(ps), k >= 0 ? String(k) : '-'); }
    const r = this.read(); const ex = (toks, idx, anc) => { const s = FZ.schemeSample(toks, idx, anc); return s || '（印なし）'; };
    const el = $('schInfo'); if (el) el.textContent = `数字：${[0, 1, 2, 3].map(i => ex(r.num, i, Array(i).fill(1))).join('　')}（題は ${r.title} 段まで）　記号：${[0, 1, 2].map(i => ex(r.sym, i)).join('　')}　箇条：${[0, 1, 2].map(i => ex(r.bullet, i)).join('　')}`;
  },
  key(e) {
    const t = e.target; if (!t.classList || !t.classList.contains('lv')) return;
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); const pal = SCHEME_PAL(); let k = pal.indexOf(FZ.normalizeToken(t.value)); k = k < 0 ? (e.key === 'ArrowDown' ? 0 : pal.length - 1) : (k + (e.key === 'ArrowDown' ? 1 : pal.length - 1)) % pal.length; t.value = pal[k]; t.select(); this.change(t.name); }
  },
  enter() { this.act('apply'); },
  act(a, e) {
    if (a === 'cancel') { closeForm(); return; }
    if (a === 'pal') { const tok = e.target.closest('[data-tok]').dataset.tok; const slots = [...sub.querySelectorAll('input.lv')]; let k = slots.indexOf(st.schemeSlot); if (k < 0) k = 0; slots[k].value = tok; this.change(slots[k].name); const nx = slots[Math.min(slots.length - 1, k + 1)]; st.schemeSlot = nx; nx.focus(); nx.select(); return; }
    if (a === 'save') { const name = fval('name').trim(); if (!name) { msg('保存する体系の名前を入れてください', true); sub.querySelector('[name="name"]').focus(); return; } if (FZ.SCHEME_PRESETS.some(p => p.name === name)) { msg('内蔵の体系と同じ名前は使えません', true); return; } const r = this.read(); const us = userSchemes().filter(p => p.name !== name); us.push({ name, num: r.num, title: r.title, sym: r.sym, bullet: r.bullet }); saveUserSchemes(us); const ps = this.presets(); setCyc('preset', this.presetVals(ps), String(ps.findIndex(p => p.name === name))); msg('体系を保存：' + name); return; }
    if (a === 'del') { const v = cycVal('preset'); const ps = this.presets(); if (v === '-' || ps[+v].builtin) { msg('内蔵の体系は削除できません（自分で保存した体系のみ）', true); return; } const name = ps[+v].name; saveUserSchemes(userSchemes().filter(p => p.name !== name)); const ps2 = this.presets(); setCyc('preset', this.presetVals(ps2), '-'); const nm = sub.querySelector('[name="name"]'); if (nm) nm.value = ''; msg('体系を削除：' + name); return; }
    if (a === 'setDefault') { const r = this.read(); const d = defaultFormat(); d.scheme = r.num; d.titleLevels = r.title; d.symScheme = r.sym; d.bulletScheme = r.bullet; d.listScheme = r.list; d.symResetsNum = r.reset; d.returnGap = r.rgap; d.titleGap = r.tgap; d.titleAfter = r.taft; d.tableGap = r.tblg; d.bodyFollow = r.bfol; saveDefaults(d); msg('この三体系を既定にしました（新規文書に使う）'); return; }
    if (a === 'apply') { const r = this.read(); closeForm(); ed.mutate('', () => { const f = ed.doc.format; f.scheme = r.num; f.titleLevels = r.title; f.symScheme = r.sym; f.bulletScheme = r.bullet; f.listScheme = r.list; f.symResetsNum = r.reset; f.returnGap = r.rgap; f.titleGap = r.tgap; f.titleAfter = r.taft; f.tableGap = r.tblg; f.bodyFollow = r.bfol; ed.normalizeSegs(); }); msg('三体系を適用'); }
  },
};
sub.addEventListener('focusin', e => { if (e.target.classList && e.target.classList.contains('lv')) st.schemeSlot = e.target; });
/* 目次：載せる見出しの範囲（数字見出しのレベル from〜to、記号見出しは 1〜to）。今の行が目次ならその設定を変える、そうでなければ入れる */
FORMS.toc = {
  html() {
    const a = ed.line().attrs; const T = a.toc ? FZ.tocRange(a.toc, ed.doc.format) : { num: [0, Math.max(0, (ed.doc.format.titleLevels | 0) - 1)], sym: null };
    const lv = Array.from({ length: 8 }, (_, i) => [String(i + 1), String(i + 1)]);
    return `<span class="ttl">目次</span><span class="info">${a.toc ? '範囲を変える' : 'この行に目次を入れる（見出しを抜き出し、頁番号は自動）'}</span>` +
      `<label>数字見出し ${cyc('nfrom', [['0', '載せない'], ...lv], T.num ? String(T.num[0] + 1) : '0')} 〜 ${cyc('nto', lv, T.num ? String(T.num[1] + 1) : '2')}</label>` +
      `<label>記号見出し ${cyc('sym', [['0', '載せない'], ...lv.map(([k]) => [k, k + ' まで'])], T.sym ? String(T.sym[1] + 1) : '0')}</label>` +
      `<button type="button" class="pri" data-act="ok">${a.toc ? '変更' : '入れる'} Enter</button>${a.toc ? '<button type="button" data-act="remove">目次を消す</button>' : ''}<button type="button" data-act="cancel">取消 Esc</button>`;
  },
  read() { const nf = +cycVal('nfrom'), nt = +cycVal('nto'), sy = +cycVal('sym'); return { num: nf > 0 ? [nf - 1, Math.max(nf, nt) - 1] : null, sym: sy > 0 ? [0, sy - 1] : null }; },
  enter() { this.act('ok'); },
  act(a) {
    if (a === 'cancel') { closeForm(); return; }
    if (a === 'remove') { closeForm(); ed.removeToc(ed.caret.line); msg('目次を消しました'); return; }
    if (a === 'ok') { const t = this.read(); if (!t.num && !t.sym) { msg('数字見出しか記号見出しのどちらかは載せてください', true); return; } closeForm(); if (ed.line().attrs.toc) { ed.setToc(ed.caret.line, t); msg('目次の範囲を変えました'); } else { ed.insertToc(t); msg('目次を入れました（見出しを増やすと自動で増え、頁番号も付け直します）'); } focusTA(); }
  },
};
/* 表 */
/* 表：カーソルが表の中なら「この表の様式を変える」、外なら「表を引く」 */
function tableAtCaret() { if (st.mode === 'text') return FZ.tableRange(ed); const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, Math.max(0, ed.lay.geo.rows - 1)), st.rc.col); return pos ? FZ.tableRange(ed, pos.line) : null; }
/* 工程表：表のまま。新しく作る（開始・単位・期間数・見出しの段・左の列・行数）／工程表の中なら設定（左の列の数・見出しの段・基準の位置）を変える */
const GANTT_UNITS = [['m', '月'], ['q', '四半期'], ['h', '半期'], ['y', '年度']];
function ganttPeriods(y0, m0, unit, n) { const out = [], groups = []; const fyOf = (y, m) => m >= 4 ? y : y - 1; /* 年度は 4 月始まり */
  for (let k = 0; k < n; k++) { let lab, grp;
    if (unit === 'm') { const t = (m0 - 1) + k, y = y0 + Math.floor(t / 12), m = t % 12 + 1; lab = m + '月'; grp = (m0 === 4 ? fyOf(y, m) + '年度' : y + '年'); }
    else if (unit === 'q') { const q0 = Math.floor(((m0 - 4 + 12) % 12) / 3); const t = q0 + k, fy = fyOf(y0, m0) + Math.floor(t / 4); lab = (t % 4 + 1) + 'Q'; grp = fy + '年度'; }
    else if (unit === 'h') { const h0 = ((m0 - 4 + 12) % 12) >= 6 ? 1 : 0; const t = h0 + k, fy = fyOf(y0, m0) + Math.floor(t / 2); lab = t % 2 ? '下期' : '上期'; grp = fy + '年度'; }
    else { const fy = fyOf(y0, m0) + k; lab = fy + '年度'; grp = ''; }
    out.push(lab); if (!groups.length || groups[groups.length - 1].name !== grp) groups.push({ name: grp, n: 1 }); else groups[groups.length - 1].n++; }
  return { labels: out, groups }; }
FORMS.gantt = {
  html() { const T = ganttTable(ed.caret.line); const now = new Date(); const fy = now.getMonth() + 1 >= 4 ? now.getFullYear() : now.getFullYear() - 1;
    if (T) { const G = T.G; const n = Math.max(0, FZ.tableCells(ed.doc, T.ts + (G.heads || 1) - 1 >= T.ts ? T.ts + (G.heads || 1) - 1 : T.ts, ed.lay.geo.bodyCols).length - (G.labels | 0));
      return `<span class="ttl">工程表</span><span class="lbl">項目欄 ${G.labels | 0} 欄</span><button type="button" data-act="lab+" title="項目欄を 1 つ足す（いちばん広い項目欄を割る）">＋</button><button type="button" data-act="lab-" title="最後の項目欄を消す（字は消える）">−</button><label>年度の段 ${cyc('band', [['1', 'あり'], ['0', 'なし']], (G.heads || 1) >= 2 ? '1' : '0')}</label><label>基準の線 ${cyc('base', [['', 'なし'], ...Array.from({ length: n }, (_, k) => [String(k + 1), (k + 1) + ' 列目']), ['now', '今日']], G.base != null ? String(Math.floor(G.base)) : '')}</label><label>位置 ${cyc('bfrac', [['0', '始め'], ['0.25', '1/4'], ['0.5', '中'], ['0.75', '3/4']], G.base != null ? String(Math.round((G.base - Math.floor(G.base)) * 4) / 4) : '0.5')}</label><button type="button" class="pri" data-act="set">適用 Enter</button><button type="button" data-act="off" title="工程表をやめてふつうの表に（字はそのまま）">ふつうの表に</button><button type="button" data-act="cancel">取消 Esc</button><span class="hintl">空いた所を横に引くと矢羽根・名前は打つ・◆ で始めるとマイルストーン・端と本体と ◆ はドラッグ（1/4 刻み）</span>`; }
    return `<span class="ttl">工程表</span><label>開始 ${inp('y0', fy, 'n', 'number', 'min="1990" max="2100"')}年 ${inp('m0', 4, 'n', 'number', 'min="1" max="12"')}月</label><label>単位 ${cyc('unit', GANTT_UNITS, 'm')}</label><label>期間 ${inp('n', 12, 'n', 'number', 'min="1" max="60"')}</label><label title="左の項目欄の名前を「・」で区切って並べる（1〜6 欄。例：テーマ・担当・状況）">項目欄 ${inp('labels', 'テーマ・担当', 'w8', 'text')}</label><label>年度の段 ${cyc('band', [['1', 'あり'], ['0', 'なし']], '1')}</label><label>行 ${inp('rows', 5, 'n', 'number', 'min="1" max="100"')}</label><button type="button" class="pri" data-act="make">工程表を作る Enter</button><button type="button" data-act="cancel">取消 Esc</button><span class="hintl">表のまま作る。期間のセルの空いた所を横に引くと矢羽根（名前はそのまま打つ）</span>`; },
  focus: 'input[name="y0"]', enter() { this.act(ganttTable(ed.caret.line) ? 'set' : 'make'); },
  act(a) { if (a === 'cancel') { closeForm(); return; }
    let T = ganttTable(ed.caret.line);
    if (a === 'off' && T) { closeForm(); ed.mutate('', () => { delete ed.doc.lines[T.ts].attrs.gantt; }); msg('ふつうの表にしました（セルの字はそのまま）'); return; }
    if ((a === 'lab+' || a === 'lab-') && T) { const n0 = ed.undoStack.length; const r = ganttLabelStep(T, a === 'lab+' ? 1 : -1); if (ed.undoStack.length > n0 + 1) ed.undoStack.length = n0 + 1; if (r === true) { msg(a === 'lab+' ? '項目欄を足しました（見出しの「項目」を書き換える）' : '最後の項目欄を消しました（Ctrl+Z で戻る）'); const T2 = ganttTable(T.ts); if (T2) { ed.setCaret({ line: T2.ts + (T2.G.heads || 1), seg: 0, off: 0 }); drawForm(); } } else msg(r === 'min' ? '項目欄は 1 つより減らせません' : r === 'max' ? '項目欄は 6 つまで' : '項目欄が狭くて割れません（列の境をドラッグして広げてから）', true); return; }
    if (a === 'set' && T) { const labels = T.G.labels | 0; const wantBand = cycVal('band') === '1', hasBand = (T.G.heads || 1) >= 2;
      const n0 = ed.undoStack.length; let bandMsg = ''; const bv = cycVal('base'), bf = +cycVal('bfrac') || 0;
      if (wantBand !== hasBand) { const ok = ganttBandToggle(T, wantBand, labels); bandMsg = ok ? (wantBand ? '年度の段を足しました（年度の字から右の空のセルまでが 1 つの帯）' : '年度の段を外しました') : '年度の段を作れませんでした（見出しの期間が読めません）'; if (ok) T = ganttTable(T.ts); }
      const heads = T.G.heads || 1; let base = null;
      if (bv === 'now') { base = ganttTodayBase(T, labels, heads); if (base == null) msg('見出しの期間から今日の位置が読めません（列を選んでください）', true); }
      else if (bv) base = +bv + bf;
      closeForm(); ed.mutate('', () => { ed.doc.lines[T.ts].attrs.gantt = { labels, heads, ...(base != null ? { base } : {}) }; }); if (ed.undoStack.length > n0 + 1) ed.undoStack.length = n0 + 1; /* 行の挿入・字の移し・設定を 1 回の取消に */ msg(bandMsg || '工程表の設定を変えました', /作れません/.test(bandMsg)); return; }
    if (a !== 'make') return;
    const y0 = clamp(+fval('y0') | 0, 1990, 2100), m0 = clamp(+fval('m0') | 0, 1, 12), unit = cycVal('unit') || 'm', n = clamp(+fval('n') | 0, 1, 60), heads = cycVal('band') === '1' && unit !== 'y' ? 2 : 1, names = ganttLabelNames(fval('labels')), labels = names.length, rows = clamp(+fval('rows') | 0, 1, 100);
    const W = ed.lay.geo.bodyCols; const want = names.map((nm, k) => k === 0 ? Math.max(4, Math.round(W * (labels === 1 ? 0.2 : 0.16)), Math.ceil(FZ.textWidth(nm)) + 1) : Math.max(3, Math.round(W * 0.08), Math.ceil(FZ.textWidth(nm)) + 1)); /* 項目欄の幅：1 欄目は広く、ほかは名前が入る幅 */
    const lw = want.slice(); let L = lw.reduce((t, v) => t + v, 0);
    let pw = Math.floor((W - L) * 2 / n) / 2; if (pw < 1.5) { pw = 1.5; L = W - pw * n; const tot = want.reduce((t, v) => t + v, 0); let acc = 0; lw.splice(0, lw.length, ...want.map((v, k) => { const x = k === want.length - 1 ? L - acc : Math.max(2, Math.floor(L * v / tot)); acc += x; return x; })); } if (pw < 1 || lw.some(x => x < 2)) { msg('期間・項目欄が多すぎて紙の幅に入りません（期間か項目欄を減らすか、単位を大きく）', true); return; }
    const bounds = [0]; for (const w of lw) bounds.push(bounds[bounds.length - 1] + w); for (let k = 0; k < n; k++) bounds.push(+(L + pw * (k + 1)).toFixed(1));
    const P = ganttPeriods(y0, m0, unit, n); if (unit === 'm' && pw < 2) P.labels = P.labels.map(l => l.replace(/月$/, '')); /* 期間のセルが 2 字に満たなければ「10月」を「10」に（折り返さない） */ const tag = `[工程表 工程列${labels}${heads > 1 ? ' 工程見出し' + heads : ''}]`; const out = ['#表 列 ' + bounds.join(',') + ' 様式 格子 見出し薄'];
    /* 年度の段あり：1 段目に年度の帯（年度の始まりのセルに「2026年度」、続きは空）と左の列の見出し、2 段目に期間の短い名前（4月・1Q・上期）。
       なし：1 段だけ、左上のセルに年度（期間が 2 年度にまたがれば「2026〜2027年度」） */ const gn = P.groups.map(g => g.name).filter(Boolean); const corner = gn.length ? (gn.length > 1 ? gn[0].replace(/年度?$/, '') + '〜' + gn[gn.length - 1] : gn[0]) : 'テーマ';
    const esc1 = t => t.replace(/\|/g, '\\|'); if (heads === 2) { const band = []; for (const g of P.groups) { band.push(g.name || ' '); for (let q = 1; q < g.n; q++) band.push(' '); } out.push(tag + '| ' + names.map(esc1).join(' | ') + ' | ' + band.join(' | ') + ' |'); out.push('| ' + names.map(() => ' ').join(' | ') + ' | ' + P.labels.join(' | ') + ' |'); }
    else out.push(tag + '| ' + [corner, ...names.slice(1)].map(esc1).join(' | ') + ' | ' + P.labels.join(' | ') + ' |');
    const empty = () => Array.from({ length: n }, () => ' ');
    for (let r = 0; r < rows; r++) { const c = empty(); const lab = names.map(() => ' '); if (r === 0) { c[0] = '◆開始'; lab[0] = '全体'; } if (r === 1 && n >= 2) { c[0] = '計画'; c[1] = '→'; lab[0] = '（例）計画'; } out.push('| ' + lab.join(' | ') + ' | ' + c.join(' | ') + ' |'); }
    const d = FZ.parse('#fzk 2\n文字数: ' + ed.doc.format.cols + '\n---\n' + out.join('\n') + '\n'); if (heads === 2) { const t0 = d.lines.findIndex(l => l.attrs.gantt); const hf = d.fills.find(x => x.from === t0 && x.to === t0); if (t0 >= 0 && hf) d.fills.push({ ...hf, id: FZ.uid(), from: t0 + 1, to: t0 + 1 }); } /* 2 段目の見出しも網 */
    closeForm(); insertDoc(d); msg('工程表を作りました：期間のセルの空いた所を横に引くと矢羽根（放して名前を打つ）。◆ で始めるとマイルストーン');
  } };
/* 項目欄の名前：「・」「、」「,」「/」で区切る（1〜6 欄、空なら「テーマ」） */
function ganttLabelNames(v) { const a = String(v || '').split(/[・、,，\/／\s]+/).map(x => x.trim()).filter(Boolean).slice(0, 6); return a.length ? a : ['テーマ']; }
/* 工程表の項目欄を 1 つ足す・減らす（左の項目欄の中で：足すときは項目欄のいちばん広い欄を割る、減らすときは最後の欄を前の欄に寄せる） */
function ganttLabelStep(T, dir) { const d = ed.doc, W = ed.lay.geo.bodyCols, G = T.G, lab = G.labels | 0; const cells = FZ.tableCells(d, T.ts, W); if (dir < 0 && lab <= 1) return 'min'; if (dir > 0 && lab >= 6) return 'max';
  const target = dir > 0 ? cells.slice(0, Math.max(1, lab)).reduce((b, c, k, a) => (c.right - c.left > a[b].right - a[b].left ? k : b), 0) : lab - 1; const c = cells[target]; if (dir > 0 && c.right - c.left < 4) return 'narrow';
  const L = d.lines[T.ts]; const si = L.segs.findIndex(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); ed.setCaret({ line: T.ts, seg: Math.max(0, si), off: 0 });
  const ok = dir > 0 ? FZ.tbl.insertCol(ed, true) : FZ.tbl.deleteCol(ed); if (ok !== true) return ok || 'fail';
  ed.mutate('', () => { const top = d.lines[T.ts]; top.attrs.gantt = { ...top.attrs.gantt, labels: lab + dir }; if (dir > 0) { const c2 = FZ.tableCells(d, T.ts, W)[target + 1]; const sg = c2 && top.segs.find(x => x.col >= c2.left - 1e-6 && x.col < c2.right - 1e-6); if (sg && !sg.text.trim()) { sg.text = '項目'; sg.marks = FZ.marksFor('項目', 0); } } });
  return true; }
/* 年度の段を足す・外す（表の 1 段目に帯の行。足すときは見出しの期間の並びと左上の年度から年度の変わり目を読む） */
function ganttBandToggle(T, on, labels) { const d = ed.doc, W = ed.lay.geo.bodyCols, ts = T.ts; const lab = labels | 0;
  const cellText = (i, c) => { const sg = d.lines[i].segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); return sg ? sg.text.trim() : ''; };
  const setCell = (i, c, text) => { const L = d.lines[i]; let sg = L.segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); if (!sg) { sg = FZ.newSeg(c.left, ''); L.segs.push(sg); L.segs.sort((a, b) => a.col - b.col); } sg.text = text; sg.marks = FZ.marksFor(text, 0); };
  if (on) { const cells = FZ.tableCells(d, ts, W); const per = cells.slice(lab), lc = cells.slice(0, lab); if (!per.length) return false;
    const corner = lc.map(c => cellText(ts, c)).join(' '); const ym = corner.match(/(\d{4})/); const now = new Date(); let fy = ym ? +ym[1] : (now.getMonth() + 1 >= 4 ? now.getFullYear() : now.getFullYear() - 1); const cal = /\d{4}年(?!度)/.test(corner);
    const marks = []; per.forEach((c, k) => { const t = cellText(ts, c); let mm, turn = false; if ((mm = t.match(/^(\d{1,2})月?$/))) turn = k > 0 && +mm[1] === (cal ? 1 : 4); else if (/^1Q$/.test(t)) turn = k > 0; else if (t === '上期') turn = k > 0; else if (/^\d{4}年度?$/.test(t)) return; if (turn) fy++; marks.push(k === 0 || turn ? fy + (cal ? '年' : '年度') : ''); });
    if (marks.length !== per.length) return false;
    ed.setCaret({ line: ts, seg: 0, off: 0 }); if (!FZ.tbl.insertRow(ed, false)) return false;
    ed.mutate('', () => { const top = d.lines[ts], old = d.lines[ts + 1]; top.attrs.gantt = { ...old.attrs.gantt, heads: (old.attrs.gantt.heads || 1) + 1 }; delete old.attrs.gantt;
      const c2 = FZ.tableCells(d, ts, W); c2.slice(lab).forEach((c, k) => setCell(ts, c, marks[k] || ''));
      c2.slice(0, lab).forEach((c, k) => { let t = cellText(ts + 1, c); if (k === 0 && /\d{4}/.test(t)) t = 'テーマ'; setCell(ts, c, t); setCell(ts + 1, c, ''); });
      const hf = d.fills.find(x => x.from === ts && x.to === ts); if (hf && !d.fills.some(x => x.from === ts + 1 && x.to === ts + 1 && x.col === hf.col)) d.fills.push({ ...hf, id: FZ.uid(), from: ts + 1, to: ts + 1 }); });
    return true; }
  /* 外す：左の列の見出しを 2 段目へ、左上には年度（帯の最初と最後） */
  const cells = FZ.tableCells(d, ts, W); const yrs = cells.slice(lab).map(c => cellText(ts, c)).filter(Boolean);
  ed.mutate('', () => { const c2 = FZ.tableCells(d, ts + 1, W); cells.slice(0, lab).forEach((c, k) => { const t = cellText(ts, c); const tgt = c2[k]; if (tgt && !cellText(ts + 1, tgt)) setCell(ts + 1, tgt, k === 0 && yrs.length ? (yrs.length > 1 ? yrs[0].replace(/年度?$/, '') + '〜' + yrs[yrs.length - 1] : yrs[0]) : t); });
    const g = d.lines[ts].attrs.gantt; d.lines[ts + 1].attrs.gantt = { ...g, heads: Math.max(1, (g.heads || 1) - 1) }; delete d.lines[ts].attrs.gantt;
    d.fills = d.fills.filter(x => !(x.from === ts + 1 && x.to === ts + 1)); });
  ed.setCaret({ line: ts, seg: 0, off: 0 }); return FZ.tbl.deleteRow(ed); }
/* 今日の位置（見出しの最後の段の「4月」「1Q」「上期」「2026年度」と、上の段の年度・年から読む） */
function ganttTodayBase(T, labels, heads) { const d = ed.doc, now = new Date(), y = now.getFullYear(), m = now.getMonth() + 1, day = now.getDate(); const hl = d.lines[T.ts + heads - 1]; if (!hl) return null; const cells = FZ.tableCells(d, T.ts + heads - 1, ed.lay.geo.bodyCols).slice(labels);
  const txt = c => { const sg = hl.segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6); return sg ? sg.text.trim() : ''; }; const fy = m >= 4 ? y : y - 1;
  const yearAt = []; if (heads >= 2) { const bl = d.lines[T.ts]; let cur = null; for (const c of cells) { const sg = bl.segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6); const t = sg ? sg.text.trim() : ''; const mm = t.match(/^(\d{4})(年度|年)$/); if (mm) cur = { y: +mm[1], fiscal: mm[2] === '年度' }; yearAt.push(cur); } } /* 年度の段：その列の年度（年） */
  const yearOk = k => { const Y = yearAt[k]; return !Y || (Y.fiscal ? Y.y === fy : Y.y === y); };
  for (let k = 0; k < cells.length; k++) { const t = txt(cells[k]); let mm; /* 年度の段が無く同じ月が 2 度あれば最初の列（年をまたぐ長い工程表は列を選ぶ） */
    if ((mm = t.match(/^(\d{1,2})月?$/))) { if (+mm[1] === m && yearOk(k)) return k + 1 + (day - 0.5) / 31; }
    else if ((mm = t.match(/^([1-4])Q$/))) { const q = Math.floor(((m - 4 + 12) % 12) / 3) + 1; if (+mm[1] === q && yearOk(k)) return k + 1 + (((m - 4 + 12) % 3) + (day - 0.5) / 31) / 3; }
    else if (t === '上期' || t === '下期') { const h = ((m - 4 + 12) % 12) >= 6 ? '下期' : '上期'; if (t === h && yearOk(k)) return k + 1 + ((((m - 4 + 12) % 12) % 6) + (day - 0.5) / 31) / 6; }
    else if ((mm = t.match(/^(\d{4})年度$/))) { if (+mm[1] === fy) return k + 1 + ((((m - 4 + 12) % 12)) + (day - 0.5) / 31) / 12; } }
  return null; }
FORMS.table = {
  html() { const rg = tableAtCaret(); if (rg) return `<span class="ttl">表の様式</span><span class="info">${rg[1] - rg[0] + 1} 行の表（${rg[0] + 1}〜${rg[1] + 1} 行目）の罫線・網・揃えを様式に合わせて引き直す</span><label>様式 ${cyc('style', FZ.TABLES.map(t => [t.id, t.label]), 'grid')}</label><span class="info" id="tblInfo">${esc(FZ.TABLES[0].desc)}</span><button type="button" class="pri" data-act="restyle">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`;
    return `<span class="ttl">表</span><label>列 ${inp('cols', 3, '', 'number', 'min="1" max="40"')}</label><label>行 ${inp('rows', 3, '', 'number', 'min="1" max="200"')}</label><label>列幅（マス、カンマ区切り。空なら均等） ${inp('widths', '', 'm')}</label><label>線種 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']], st.ruleKind)}</label><label>先頭行 ${cyc('header', [['1', '網掛け'], ['0', 'なし']], '1')}</label><label>様式 ${cyc('style', FZ.TABLES.map(t => [t.id, t.label]), 'grid')}</label><span class="info" id="tblInfo"></span><button type="button" class="pri" data-act="apply">表を引く Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  vals() { const cols = clamp(+fval('cols') | 0, 1, 40), rows = clamp(+fval('rows') | 0, 1, 200); const total = ed.lay.geo.cols; let widths = fval('widths').split(/[,、\s]+/).filter(Boolean).map(Number).filter(n => n > 0); if (widths.length !== cols) { const w = Math.floor(total / cols); widths = Array.from({ length: cols }, (_, i) => i === cols - 1 ? total - w * (cols - 1) : w); } return { cols, rows, widths, kind: cycVal('kind'), header: cycVal('header') === '1', style: cycVal('style') || 'grid' }; },
  change() { if (tableAtCaret()) { const t = FZ.TABLES.find(x => x.id === cycVal('style')); const el = $('tblInfo'); if (el && t) el.textContent = t.desc; return; } const t = this.vals(); const sum = t.widths.reduce((a, b) => a + b, 0); const ok = sum <= ed.lay.geo.cols; const el = $('tblInfo'); el.className = 'info' + (ok ? '' : ' alert'); el.textContent = ok ? `${t.cols}列×${t.rows}行、列幅 ${t.widths.join('・')}（計${sum}）` : `列幅の合計 ${sum} が 1行 ${ed.lay.geo.cols} 字を超過`; },
  enter() { this.act(tableAtCaret() ? 'restyle' : 'apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; }
    if (a === 'restyle') { const id = cycVal('style'); const rg = tableAtCaret(); closeForm(); if (!rg) return; if (st.mode !== 'text') { const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, ed.lay.geo.rows - 1), st.rc.col); st.mode = 'text'; st.sub = null; if (pos) ed.setCaret(pos); drawFkeys(); drawSub(); } if (FZ.applyTable(ed, id)) msg('表の様式を「' + (FZ.TABLES.find(t => t.id === id) || {}).label + '」にしました（Ctrl+Z で戻る）'); focusTA(); return; }
    const t = this.vals(); if (t.widths.reduce((x, y) => x + y, 0) > ed.lay.geo.cols) return; closeForm(); if (st.mode !== 'text') { const pos = FZ.xyToPos(ed.lay, st.rc.page, Math.min(st.rc.y, ed.lay.geo.rows - 1), st.rc.col); st.mode = 'text'; st.sub = null; if (pos) ed.setCaret(pos); drawFkeys(); drawSub(); } ed.insertTable(t.cols, t.rows, t.widths, t.header, t.kind); if (t.style && t.style !== 'grid') FZ.applyTable(ed, t.style); focusTA(); },
};
/* 検索・置換。1.0.15d（B-13）：正規表現（$1・$& で置き換え）・当たった所を紙面に朱の枠・一覧（右の欄：飛ぶ・1 つずつ置換・置換の見通し）・すべて太字 */
const findState = { n: '', r: '', ic: false, re: false };
function findRe() { const n = findState.n; if (!n) return null; try { return new RegExp(findState.re ? n : n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gu' + (findState.ic ? 'i' : '')); } catch (e) { return { error: e.message }; } }
let findCache = null;
function findMatches(max = 5000) { const key = [ed.gen, ed.docId, findState.n, findState.ic, findState.re].join('\u0001'); if (findCache && findCache.key === key) return findCache.list;
  const re = findRe(); let list; if (!re || re.error) list = re; else { list = []; const L = ed.doc.lines;
    outer: for (let i = 0; i < L.length; i++) for (let k = 0; k < L[i].segs.length; k++) { const t = L[i].segs[k].text; if (!t) continue; re.lastIndex = 0; let m; while ((m = re.exec(t))) { if (!m[0].length) { re.lastIndex++; continue; } list.push({ line: i, seg: k, a: m.index, b: m.index + m[0].length, m }); if (list.length >= max) break outer; } } }
  findCache = { key, list }; return list; }
function replOf(m) { const r = findState.r; if (!findState.re) return r; return r.replace(/\$(\$|&|\d{1,2}|<[^>]+>)/g, (t, k) => k === '$' ? '$' : k === '&' ? m[0] : k[0] === '<' ? ((m.groups || {})[k.slice(1, -1)] ?? '') : (m[+k] ?? '')); }
const posCmp = (p, q) => p.line - q.line || p.seg - q.seg || p.off - q.off;
function findGo(dir) { const list = findMatches(); if (!Array.isArray(list)) { msg(list && list.error ? '正規表現の誤り：' + list.error : '探す字を入れてください', true); return false; } if (!list.length) { msg('見つかりません', true); return false; }
  const s = ed.sel(); const from = s ? (dir > 0 ? s.b : s.a) : ed.caret; let hit;
  if (dir > 0) hit = list.find(x => posCmp({ line: x.line, seg: x.seg, off: x.a }, from) >= 0 && !(s && x.line === s.a.line && x.seg === s.a.seg && x.a === s.a.off && x.b === s.b.off)) || list[0];
  else { for (let k = list.length - 1; k >= 0; k--) { const x = list[k]; if (posCmp({ line: x.line, seg: x.seg, off: x.b }, from) <= 0 && !(s && x.line === s.a.line && x.seg === s.a.seg && x.a === s.a.off)) { hit = x; break; } } hit = hit || list[list.length - 1]; }
  healthGo(hit); st.findSel = list.indexOf(hit); if (st.side === 'find') drawSide(); return true; }
function findAtSel() { const s = ed.sel(); if (!s || s.a.line !== s.b.line || s.a.seg !== s.b.seg) return null; const list = findMatches(); return Array.isArray(list) ? list.find(x => x.line === s.a.line && x.seg === s.a.seg && x.a === s.a.off && x.b === s.b.off) || null : null; }
function findReplaceOne(x) { if (!x) return false; const seg = ed.doc.lines[x.line].segs[x.seg]; const rep = replOf(x.m); ed.mutate('', () => { ed.spliceSeg(seg, x.a, x.b, rep, FZ.marksFor(rep, (seg.marks[x.a] | 0) & ~FZ.M.LINK)); ed.anchor = null; ed.caret = { line: x.line, seg: x.seg, off: x.a + rep.length, vcol: null, vrow: 0 }; }); return true; }
function findReplaceAll() { const list = findMatches(1e6); if (!Array.isArray(list) || !list.length) return 0; ed.mutate('', () => { for (let k = list.length - 1; k >= 0; k--) { const x = list[k]; const seg = ed.doc.lines[x.line].segs[x.seg]; const rep = replOf(x.m); ed.spliceSeg(seg, x.a, x.b, rep, FZ.marksFor(rep, (seg.marks[x.a] | 0) & ~FZ.M.LINK)); } ed.anchor = null; }); return list.length; }
function findBoldAll() { const list = findMatches(1e6); if (!Array.isArray(list) || !list.length) return 0; const B = FZ.M.BOLD; let all = true; for (const x of list) { const mk = ed.doc.lines[x.line].segs[x.seg].marks; for (let q = x.a; q < x.b; q++) if (!((mk[q] | 0) & B)) all = false; }
  ed.mutate('', () => { for (const x of list) { const mk = ed.doc.lines[x.line].segs[x.seg].marks; for (let q = x.a; q < x.b; q++) mk[q] = all ? (mk[q] & ~B) : ((mk[q] | 0) | B); } }); return all ? -list.length : list.length; }
/* 紙面の印：検索の欄か一覧を開いている間、当たった所（500 まで）に朱の細い枠 */
function hitRange(ov, line, seg, a, b) { const lm = ed.lay.lineMap[line]; if (!lm) return; const sl = lm.segs[seg || 0]; if (!sl) return; for (const row of sl.rows) { let x0 = Infinity, x1 = -Infinity; for (const g of row.glyphs) { if (g.off < a || g.off >= b || g.marker) continue; x0 = Math.min(x0, g.col); x1 = Math.max(x1, g.col + g.w); } if (x1 > x0) ov.hits.push({ page: row.page, col: x0 - 0.05, y: row.y + 0.05, w: x1 - x0 + 0.1, h: row.h - 0.1 }); } }
function findMarks(ov) { if (!(st.form === 'find' || st.form === 'replace' || st.side === 'find') || st.mode !== 'text' || !findState.n) return; const list = findMatches(); if (!Array.isArray(list)) return; ov.hits = ov.hits || []; for (const x of list.slice(0, 500)) hitRange(ov, x.line, x.seg, x.a, x.b); }
/* 一覧（右の欄） */
function findHtml() { const list = findMatches(); const repl = st.form === 'replace' || st.findRepl;
  if (!findState.n) return '<div class="side-empty">検索の欄（Ctrl+F）に探す字を入れると、当たった所がここに並びます。</div>';
  if (!Array.isArray(list)) return `<div class="side-empty alert">正規表現の誤り：${esc(list.error || '')}</div>`;
  const ctx = x => { const t = ed.doc.lines[x.line].segs[x.seg].text; const pre = t.slice(Math.max(0, x.a - 10), x.a), post = t.slice(x.b, x.b + 10); return `${x.a > 10 ? '…' : ''}${esc(pre)}<b class="fdh">${esc(t.slice(x.a, x.b))}</b>${esc(post)}${x.b + 10 < t.length ? '…' : ''}`; };
  const pageOf = L => { const lm = ed.lay.lineMap[L]; return lm && lm.rows[0] ? (lm.rows[0].page + 1) + ' 頁' : ''; };
  const head = `<div class="hvhead"><b>${list.length >= 5000 ? '5000 件以上' : list.length + ' 件'}</b>　「${esc(findState.n)}」${findState.re ? '（正規表現）' : ''}${repl ? `　→「${esc(findState.r)}」` : ''}<br><span class="d">行を選ぶとその所へ。紙面の朱の枠が当たった所</span></div>`
    + `<div class="hvact">${repl ? '<button type="button" data-fdact="all" class="pri">すべて置換</button>' : ''}<button type="button" data-fdact="bold" title="当たった所をすべて太字に（もう太字なら外す。Ctrl+Z で戻る）">すべて太字</button><button type="button" data-act="manualSec" data-sec="検索・置換" title="取扱説明書の「検索・置換」を開く">説明</button></div>`;
  return head + (list.length ? list.slice(0, 300).map((x, k) => `<div class="li fd${st.findSel === k ? ' cur' : ''}" data-fd="${k}"><span class="t">${ctx(x)}<br><span class="d">${pageOf(x.line)}${repl ? `　→「${esc(replOf(x.m))}」` : ''}</span></span>${repl ? `<button type="button" data-fdr="${k}" title="この所だけ置換">置換</button>` : ''}</div>`).join('') + (list.length > 300 ? `<div class="side-empty">ほか ${list.length - 300} 件（紙面の枠は 500 件まで）</div>` : '') : '<div class="side-empty">見つかりません。</div>'); }
function findClick(e) { const t = e.target; const list = findMatches(); if (!Array.isArray(list)) return false;
  const fa = t.closest('[data-fdact]'); if (fa) { if (fa.dataset.fdact === 'all') { const n = findReplaceAll(); msg(n + ' 件を置換（1 回の Ctrl+Z で戻る）'); } else { const n = findBoldAll(); msg(n > 0 ? `${n} か所を太字に（Ctrl+Z で戻る）` : `${-n} か所の太字を外しました`); } render(); drawSide(); refreshFindInfo(); return true; }
  const fr = t.closest('[data-fdr]'); if (fr) { const x = list[+fr.dataset.fdr]; if (x && findReplaceOne(x)) { st.findSel = null; render(); drawSide(); refreshFindInfo(); } return true; }
  const it = t.closest('[data-fd]'); if (it) { const x = list[+it.dataset.fd]; if (x) { st.findSel = +it.dataset.fd; healthGo(x); drawSide(); } return true; }
  return false; }
function refreshFindInfo() { const el = $('findInfo'); if (!el) return; if (!findState.n) { el.textContent = ''; return; } const list = findMatches(); el.textContent = Array.isArray(list) ? (list.length >= 5000 ? '5000 件以上' : list.length + ' 件') : '正規表現の誤り'; el.classList.toggle('alert', !Array.isArray(list)); }
FORMS.find = {
  html() { const repl = st.form === 'replace'; const s = ed.sel(); if (s && ed.selInSeg()) { findState.n = ed.textOf(s); findState.re = false; } return `<span class="ttl">${repl ? '置換' : '検索'}</span><label>検索 ${inp('n', findState.n, 'w')}</label>${repl ? `<label title="正規表現のときは $1・$& で当たった字を使える">置換 ${inp('r', findState.r, 'w')}</label>` : ''}<label>大小 ${cyc('ic', [['0', '区別'], ['1', '同一視']], findState.ic ? '1' : '0')}</label><label title="正規表現：\\d+（数字の並び）・(令和|平成)\\d+年・^第 など。セルの中・行の中で探す">字 ${cyc('re', [['0', 'そのまま'], ['1', '正規表現']], findState.re ? '1' : '0')}</label><button type="button" data-act="prev">↑ Shift+Enter</button><button type="button" class="pri" data-act="next">↓ Enter</button>${repl ? `<button type="button" data-act="one">置換</button><button type="button" data-act="all">すべて置換</button>` : ''}<button type="button" data-act="list" title="当たった所を右の欄に並べる（飛ぶ・1 つずつ置換・置換の見通し・すべて太字）">一覧</button><span class="info" id="findInfo"></span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'input[name="n"]',
  change() { findState.n = fval('n'); findState.r = fval('r'); findState.ic = cycVal('ic') === '1'; findState.re = cycVal('re') === '1'; st.findRepl = st.form === 'replace'; st.findSel = null; refreshFindInfo(); requestOverlay(); if (st.side === 'find') { clearTimeout(st.findT); st.findT = setTimeout(() => { if (st.side === 'find') drawSide(); }, 150); } },
  enter(e) { this.act(e.shiftKey ? 'prev' : (e.target.name === 'r' ? 'one' : 'next')); },
  act(a) { if (a === 'cancel') { closeForm(); return; } this.change(); if (!findState.n) return;
    if (a === 'list') { if (st.side !== 'find') toggleSide('find'); else drawSide(); return; }
    if (a === 'next' || a === 'prev') { if (findGo(a === 'prev' ? -1 : 1)) { requestRender(); } }
    if (a === 'one') { const x = findAtSel(); if (x) { findReplaceOne(x); findCache = null; } findGo(1); requestRender(); refreshFindInfo(); if (st.side === 'find') drawSide(); }
    if (a === 'all') { const n = findReplaceAll(); msg(n + ' 件を置換（1 回の Ctrl+Z で戻る）'); render(); refreshFindInfo(); if (st.side === 'find') drawSide(); }
  },
};
FORMS.replace = FORMS.find;
/* 発言者欄の幅 */
FORMS.speech = { html() { return `<span class="ttl">発言録</span><label>発言者欄の幅（マス） ${inp('n', ed.line().attrs.speakerCols || 6, '', 'number', 'min="1" max="30"')}</label><span class="hintl">「発言者：本文」の形で打つと、本文の開始位置と折返しが揃います</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; }, enter() { this.act('apply'); }, act(a) { if (a === 'apply') { const n = clamp(+fval('n') | 0, 1, 30); closeForm(); ed.setAttrs({ style: 'speech', speakerCols: n }); } else closeForm(); } };
/* 表の見出し行の網：選んで適用（押すたびに巡る切替はやめた） */
FORMS.headFill = {
  html() { const rg = FZ.tableRange(ed); let cur = 'none'; if (rg) { const B = FZ.tableBounds(ed.doc, rg[0]); const L = B[0], R = B[B.length - 1]; const f = ed.doc.fills.find(x => x.from === rg[0] && x.to === rg[0] && x.col <= L && x.col + x.cols >= R); if (f) cur = f.shade; }
    return `<span class="ttl">見出し行の網</span><label>網 ${cyc('shade', [['light', '淡網'], ['gray', '薄網'], ['deep', '濃網'], ['ink', '濃灰（白抜き）'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['none', 'なし']], cur)}</label><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'select', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const sh = cycVal('shade'); const rg = FZ.tableRange(ed); closeForm(); if (!rg) return; const B = FZ.tableBounds(ed.doc, rg[0]); const L = B[0], R = B[B.length - 1]; ed.mutate('', () => { ed.removeFillRect(rg[0], rg[0], L, R - L); if (sh !== 'none') ed.doc.fills.push({ id: FZ.uid(), from: rg[0], to: rg[0], col: L, cols: R - L, shade: sh }); }); },
};
/* 図：箱の文字と体裁 */
FORMS.box = {
  html() { const b = figSel() || { text: '', w: 8, h: 3, kind: 'thin', shade: null, bold: false }; return `<span class="ttl">箱</span><label>文字 ${inp('text', b.text, 'w')}</label><label>幅 ${inp('w', b.w, '', 'number', 'min="2" max="200"')}</label><label>高 ${inp('h', b.h, '', 'number', 'min="1" max="200"')}</label><label>線 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['double', '二重'], ['dotted', '点線']], b.kind)}</label><label>網 ${cyc('shade', [['', 'なし'], ['gray', '薄'], ['deep', '濃網'], ['dark', '墨（白抜き）'], ['hatch', '斜線'], ['dots', '点']], b.shade || '')}</label><label>太字 ${cyc('bold', [['0', 'なし'], ['1', '太字']], b.bold ? '1' : '0')}</label><span class="hintl">文字は箱の幅で折り返し、上下左右の中央に置かれます</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="text"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); const b = figSel(); if (!fi || !b) { closeForm(); return; } const text = fval('text'), w = clamp(+fval('w') | 0, 2, 200), h = clamp(+fval('h') | 0, 1, 200), kind = cycVal('kind'), shade = cycVal('shade') || null, bold = cycVal('bold') === '1'; closeForm();
    ed.figOp(fi.line, F => { const bb = FZ.figureBox(F, b.id); if (!bb) return; const W = fi.right - fi.left; bb.text = text; bb.w = Math.min(w, W - bb.x); bb.h = h; bb.kind = kind; bb.shade = shade; bb.bold = bold; if (bb.y + bb.h > F.h) F.h = bb.y + bb.h; }); figRefresh(); },
};
/* 図：矢印のラベル・線種 */
FORMS.arrow = {
  html() { const fi = figInfo(); const a = fi && st.fig.selArrow != null ? fi.F.arrows[st.fig.selArrow] : { label: '', kind: 'thin' }; return `<span class="ttl">矢印</span><label>ラベル ${inp('label', a.label, 'm')}</label><label>線 ${cyc('kind', [['thin', '細'], ['thick', '太'], ['dotted', '点線']], a.kind)}</label><button type="button" data-act="flip">向きを逆に</button><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="label"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); const k = st.fig ? st.fig.selArrow : null; if (!fi || k == null) { closeForm(); return; } const label = fval('label'), kind = cycVal('kind'); if (a !== 'flip') closeForm(); ed.figOp(fi.line, F => { const ar = F.arrows[k]; if (!ar) return; ar.label = label; ar.kind = kind; if (a === 'flip') { const t = ar.from; ar.from = ar.to; ar.to = t; } }); figRefresh(); },
};
/* 図：スイムレーン */
FORMS.lanes = {
  html() { const fi = figInfo(); const L = fi && fi.F.lanes; return `<span class="ttl">スイムレーン</span><label>方向 ${cyc('dir', [['', 'なし'], ['v', '縦（列に分ける）'], ['h', '横（行に分ける）']], L ? L.dir : '')}</label><label>名前（｜で区切る） ${inp('titles', L ? L.items.map(it => it.title).join('｜') : '営業｜開発｜品質', 'w')}</label><label>図の高さ ${inp('h', fi ? fi.F.h : 10, '', 'number', 'min="1" max="200"')}</label><span class="hintl">縦レーンは上に名前の帯、横レーンは左に名前（縦書き）。箱は矢印キーやドラッグでレーンへ</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="titles"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const fi = figInfo(); if (!fi) { closeForm(); return; } const dir = cycVal('dir'), titles = fval('titles').split(/[|｜]/).map(t => t.trim()).filter((t, k, arr) => t || arr.length === 1), h = clamp(+fval('h') | 0, 1, 200); closeForm();
    ed.figOp(fi.line, F => { F.lanes = dir && titles.length ? { dir, items: titles.map(t => ({ title: t, size: 0 })) } : null; const minH = F.boxes.reduce((m, b) => Math.max(m, b.y + b.h), 1); F.h = Math.max(h, minH); }); figRefresh(); },
};
/* リンク */
FORMS.zoom = { html: () => `<span class="ttl">表示倍率</span><label>％ <input name="pct" type="number" min="25" max="400" step="5" value="${st.zoom === 'width' || st.zoom === 'page' ? Math.round(targetWidthPx() / (ed.lay.geo.W * PX) * 100) : Math.round(Number(st.zoom) * 100)}"></label><button type="button" data-act="width">幅に合わせる</button><button type="button" data-act="page">高さに合わせる</button><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`,
  focus: 'input[name="pct"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'width' || a === 'page') { st.zoom = a; closeForm(); render(); return; } const v = clamp(+fval('pct') || 100, 25, 400); st.zoom = v / 100; closeForm(); render(); } };
FORMS.link = {
  html() { const seg = ed.seg(); const cur = FZ.linkAt(seg, ed.caret.off) || FZ.linkAt(seg, ed.caret.off - 1); return `<span class="ttl">リンク</span><label>URL ${inp('url', cur ? cur.url : '', 'w', 'text', 'placeholder="https://… （空にして適用すると外す）"')}</label><span class="hintl">選択範囲に付けます（選択が無ければカーソルの語）。本文では点線の下線、Ctrl+クリックで開く。Markdown では [文字](URL)</span><button type="button" class="pri" data-act="apply">適用 Enter</button>${cur ? '<button type="button" data-act="open">開く</button>' : ''}<button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="url"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const url = fval('url').trim(); if (a === 'open') { if (url) openUrl(url); return; } closeForm(); if (!ed.setLink(url)) msg('リンクを付ける文字を選んでください', true); else msg(url ? 'リンクを付けました' : 'リンクを外しました'); },
};
/* 確認（未保存） */
let askCb = null, askVerb = '続行';
/* 字の網の文様：選んだ字（選択が無ければこの後に打つ字）に網を掛け、文様を選ぶ */
FORMS.shadeType = { html() { return `<span class="ttl">網の文様</span>${FZ.SHADES.map((sh, k) => `<button type="button" class="swb" data-act="sh:${sh.id}" title="${esc(sh.label)}">${swatch(sh.id)} ${esc(sh.name)}<span class="kk">${'1234567890QWER'[k] || ''}</span></button>`).join('')}<button type="button" data-act="off">外す</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { const k = e.key.toUpperCase(); const i = '1234567890QWER'.indexOf(k); if (i >= 0 && k.length === 1 && FZ.SHADES[i]) { e.preventDefault(); e.stopPropagation(); this.act('sh:' + FZ.SHADES[i].id); } },
  act(a) { closeForm(); if (a === 'cancel') return; if (a === 'off') { ed.mapMarks(m => m & ~(M.SHADE | M.SHT)); render(); return; } const id = a.slice(3); ed.mapMarks(m => FZ.withShadeType(m, id)); render(); msg('網の文様：' + FZ.SHADE_BY[id].label); } };
/* m×n 倍角：横 m・縦 n（1〜9）。2 倍までは横倍角・縦倍角・四倍角と同じ */
FORMS.scale = { html() { const mk = ed.sel() ? (() => { let v = null; ed.forEachMark(ed.sel(), m => { if (v == null) v = m; return m; }, true); return v | 0; })() : ed.typing | 0; return `<span class="ttl">m×n 倍角</span><label>横 ${inp('sw', FZ.scaleW(mk), '', 'number', 'min="1" max="9"')}</label><label>縦 ${inp('sh', FZ.scaleH(mk), '', 'number', 'min="1" max="9"')}</label>${[[2, 2], [3, 3], [4, 4], [3, 2], [2, 3], [6, 6]].map(([a, b]) => `<button type="button" data-act="p:${a}x${b}">${a}×${b}</button>`).join('')}<button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="p:1x1">元の大きさ</button><button type="button" data-act="cancel">取消 Esc</button><span class="info">横×縦マス。大きな字の行は縦の倍率ぶんの高さになる</span>`; }, focus: 'input',
  act(a) { if (a === 'cancel') { closeForm(); return; } let w, h; if (a.startsWith('p:')) [w, h] = a.slice(2).split('x').map(Number); else { w = +fval('sw'); h = +fval('sh'); } closeForm(); ed.mapMarks(m => FZ.withScale(m, w, h)); render(); msg(`${w}×${h} 倍角`); } };
FORMS.count = { html() { const c = countInfo(); const f = n => n.toLocaleString(); return `<span class="ttl">字数</span><span class="info">全体 <b>${f(c.all)}</b> 字（空白を除く ${f(c.noSp)} 字）　段落 ${f(c.paras)}　${f(c.pages)} 頁　原稿用紙（400 字詰め）換算 <b>${f(c.sheets)}</b> 枚（${f(c.rows)} 行）</span>${c.sel ? `<span class="info">選択 <b>${f(c.sel.n)}</b> 字（空白を除く ${f(c.sel.k)} 字）</span>` : ''}<button type="button" data-act="cancel">閉じる Esc</button>`; }, focus: 'button', act() { closeForm(); } };
FORMS.ask = { html() { return `<span class="ask">未保存の変更があります。${askVerb === '閉じる' ? '保存してから閉じますか？' : ''}</span><button type="button" class="pri" data-act="save">S 保存して${askVerb}</button><button type="button" data-act="discard">D 保存せずに${askVerb}</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button', key(e) { const k = e.key.toLowerCase(); if (k === 's' || k === 'd') { e.preventDefault(); e.stopPropagation(); this.act(k === 's' ? 'save' : 'discard'); } }, async act(a) { const cb = askCb; askCb = null; closeForm(); if (a === 'cancel') return; if (a === 'save') { const ok = await saveFile(false); if (!ok) return; if (ed.dirty) { askCb = cb; openForm('ask'); msg('保存しているあいだに入力がありました。その入力は未保存です', true, 8000); return; } } if (cb) cb(); } }; /* 保存中に打った字を、閉じる・開くで捨てない */
/* 外での書き換え：開いた（保存した）あとに別のアプリや別の窓が同じファイルを書き換えていたら、上書きの前に聞く */
let conflictInfo = null;
FORMS.conflict = { html() { const nm = st.file ? st.file.name : ''; const o = conflictInfo || {}; const when = o.mtime ? new Date(o.mtime).toLocaleString() : ''; return `<span class="ask">「${esc(nm)}」は${o.gone ? '見つかりません（消された・移された）' : '文机の外で書き換えられています' + (when ? '（' + when + '）' : '')}。</span><button type="button" class="pri" data-act="as">A 別名で保存</button><button type="button" data-act="over">O ${o.gone ? 'もとの場所に保存' : '上書きする'}</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button', key(e) { const k = e.key.toLowerCase(); if (k === 'a' || k === 'o') { e.preventDefault(); e.stopPropagation(); this.act(k === 'a' ? 'as' : 'over'); } }, async act(a) { closeForm(); if (a === 'cancel') return; if (a === 'over') { const ext = await readCurrentFile(st.file); if (ext != null) await histPush(st.file, ext, '外で書き換えた版'); } await saveFile(a === 'as', true); } }; // 上書きする前に、外で書き換えた版を履歴に残す
async function readCurrentFile(f) { try { if (f.handle && typeof f.handle.getFile === 'function') return await (await f.handle.getFile()).text(); if (f.path && typeof globalThis.fzReadFile === 'function') return await globalThis.fzReadFile(f.path); } catch { } return null; }
async function stampFile(f = st.file) { if (!f || !(f.handle || f.path)) return; const t = await FZ.files.info(f); if (t.mtime > 0) { f.mtime = t.mtime; if (t.size != null) f.size = t.size; } } /* 更新日時と大きさ（外での書き換えを見つける手がかり） */
/* 今のファイル名（柱の {file}）。原本にも取消の履歴にも入れない（列挙しない） */
function setFileName(n) { const v = n || ''; if (ed.doc.fileName === v) return; Object.defineProperty(ed.doc, 'fileName', { value: v, enumerable: false, writable: true, configurable: true }); if (/\{file\}/.test((ed.doc.format.header || '') + (ed.doc.format.footer || ''))) ed.relayout(); } // 柱に {file} があるときだけ組み直す
function openUrl(u) { const ok = FZ.safeUrl(u); if (!ok) { msg('この種類のリンクは開きません（http・https・mailto・file だけ）：' + String(u).slice(0, 40), true); return; } window.open(ok, '_blank', 'noopener'); }
function withDiscard(fn, verb = '続行') { if (!ed.dirty) { fn(); return; } askCb = fn; askVerb = verb; if (st.mode !== 'text') exitMode(); openForm('ask'); }
/* exe 版：窓の［×］・Alt+F4 → ホストが閉じる前にここへ問い合わせる。未保存の変更があれば「保存して閉じる／保存せずに閉じる／取消」を出し、決まってから閉じる。
 * ブラウザ版（.bat）は閉じる前の確認をブラウザの標準の問い合わせ（離れる／キャンセル）で出す（beforeunload。保存の選択肢は出せないが、復旧用の退避は残る） */
window.fzRequestClose = () => {
  try { if (typeof window.fzCloseAck === 'function') window.fzCloseAck(); } catch { } // 画面が応答していることをホストに知らせる
  const closeNow = () => { ed.dirty = false; clearRecovery(); try { window.fzCloseNow(); } catch { } };
  if (st.composing) { msg('変換を確定してから閉じてください', true); return; }
  withDiscard(closeNow, '閉じる'); if (st.form === 'ask') { const b = sub.querySelector('button[data-act="save"]'); if (b) b.focus(); }
};
/* ---------- 保存の版の履歴（専用機の「置き換え文書復元」）：開いたとき・保存のたびの原本を、ファイルごとに直近 10 版まで IndexedDB に残す ---------- */
/* P02：ファイルの見分けは、exe 版は置き場所（パス）、ブラウザ版はファイルの参照（handle）そのもの（isSameEntry で同じファイルか確かめる）。
   名前で見分けると、別のフォルダの同じ名前のファイルの版が混ざる。名前を付けた版（「提出前」など）は数の上限で消さない。全体でも上限（ファイル 100・120MB） */
const HIST_MAX = 10, HIST_NAMED = 10, HIST_BYTES = 20e6, HIST_TOTAL = 120e6, HIST_FILES = 100;
const histIds = new WeakMap(); let histSeq = 0;
function histKeyOf(f) { if (!f) return Promise.resolve(null); if (f.path) return Promise.resolve('hist:' + f.path); const h = f.handle; if (!h) return Promise.resolve(null); if (histIds.has(h)) return histIds.get(h);
  const p = (async () => { if (typeof h.isSameEntry === 'function') { try { const reg = (await RDB.get('hist:ids')) || [];
        for (const e of reg) { try { if (e.h && await h.isSameEntry(e.h)) return 'hist:id:' + e.id; } catch { } }
        const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6); reg.push({ id, h, name: h.name }); await RDB.put('hist:ids', reg); return 'hist:id:' + id; } catch { } }
    return 'hist:s:' + WIN_ID + ':' + (++histSeq); })(); /* 参照を残せない環境：この窓を開いている間だけ（名前では混ぜない） */
  histIds.set(h, p); return p; }
const hasHist = f => !!(f && (f.path || f.handle));
async function histPrune(k, bytes) { try { const ix = (await RDB.get('hist:index')) || {}; ix[k] = { t: Date.now(), bytes }; const ks = Object.keys(ix).sort((x, y) => ix[x].t - ix[y].t); let total = ks.reduce((t, x) => t + (ix[x].bytes || 0), 0); const drop = [];
    while (ks.length > 1 && (ks.length > HIST_FILES || total > HIST_TOTAL)) { const x = ks.shift(); if (x === k) { ks.push(x); continue; } total -= ix[x].bytes || 0; delete ix[x]; drop.push(x); }
    for (const x of drop) await RDB.del(x); await RDB.put('hist:index', ix);
    if (drop.some(x => x.startsWith('hist:id:'))) { const reg = (await RDB.get('hist:ids')) || []; await RDB.put('hist:ids', reg.filter(e => !drop.includes('hist:id:' + e.id))); } } catch { } }
async function histPush(f, text, kind) { if (!text) return; const k = await histKeyOf(f); if (!k) return; try { const arr = (await RDB.get(k)) || []; if (arr[0] && arr[0].text === text) return; arr.unshift({ time: Date.now(), kind, text });
    const keep = []; let bytes = 0, plain = 0, named = 0; for (const v of arr) { const nm = !!v.label; if (nm ? named >= HIST_NAMED : plain >= HIST_MAX) continue; if (keep.length && bytes + v.text.length * 2 > HIST_BYTES) continue; bytes += v.text.length * 2; nm ? named++ : plain++; keep.push(v); }
    await RDB.put(k, keep); histPrune(k, bytes); } catch { } }
async function histList(f = st.file) { const k = await histKeyOf(f); if (!k) return []; try { return (await RDB.get(k)) || []; } catch { return []; } }
FZ.histList = histList;
/* 版を見る（今の文書は変えない）：今の版と比べて、違う節を並べる。「この版を戻す」で戻す（戻す前の今の版は履歴に残す） */
function histDiff(text) { let V; try { V = FZ.parse(text); } catch { return null; } const A = ed.doc; const H = FZ.diffDocs(A, A.lines.map((_, i) => i), V, null, null, { exact: true });
  const secName = (doc, tr, L) => { let best = null; for (const n of tr.nodes) if (n.line <= L && n.end >= L && /^(num|sym|title)$/.test(n.kind) && (!best || n.depth > best.depth)) best = n; return best ? String(best.text).replace(/\s+/g, ' ').slice(0, 24) : '（最初の見出しの前）'; };
  const trA = FZ.tree.build(A, {}), trV = FZ.tree.build(V, {}); const by = new Map(); const cats = { body: 0, struct: 0, link: 0, emph: 0 };
  for (const h of H) { const nm = h.rem.length ? secName(A, trA, h.rem[0]) : h.b[1] > h.b[0] ? secName(V, trV, h.b[0]) : secName(A, trA, Math.max(0, h.at - 1)); const e = by.get(nm) || { add: 0, del: 0, chg: 0 }; e[h.kind]++; by.set(nm, e); for (const c of h.cats || []) cats[c] = (cats[c] || 0) + 1; }
  return { n: H.length, secs: [...by.entries()], cats, chars: text.length }; }
async function histView(i) { st.histSel = i; if (st.side !== 'hist') toggleSide('hist'); else drawSide(); }
async function histRestore(i, confirmed) { const f = st.file; const arr = await histList(f); const v = arr[i]; if (!v) return false; if (!confirmed) { histView(i); return false; }
  let d; try { d = await parseText(v.text, 'fzk', {}); } catch (e) { msg('この版は読めませんでした：' + e.message, true); return false; }
  const now = FZ.serialize(ed.doc); await histPush(f, now, '戻す前の版'); /* 今の版（未保存の変更も）を先に残す */
  ed.setDoc(d); setFileName(f ? f.name : ''); st.file = f; ed.dirty = true; scheduleRecovery(); st.histSel = null; drawSide(); render();
  msg(`${histTime(v.time)} の版に戻しました。戻す前の版は履歴の 1 番目に残しています（未保存。保存すると上書き）`, false, 10000); return true; }
async function histName(i, label) { const k = await histKeyOf(st.file); if (!k) return; try { const arr = (await RDB.get(k)) || []; if (!arr[i]) return; const t = String(label || '').trim().slice(0, 20); if (t) arr[i].label = t; else delete arr[i].label; await RDB.put(k, arr); } catch { } drawSide(); }
const histTime = t => { const d = new Date(t); return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`; };
/* 1.0.15a 三層（UI/UX 提案 A-1）：紙＝刷られるもの（本文の字・罫・網）、手当て＝刷られないが机に残るもの（付箋・点検の印・比べた印・札。朱）、写し＝意味を写した別の姿（Word・PowerPoint・Markdown・印刷・PDF） */
function careToggle(on) { st.careHidden = on == null ? !st.careHidden : !on; document.body.classList.toggle('care-off', !!st.careHidden); requestOverlay(); drawNotes(); drawSub(); msg(st.careHidden ? '手当てを隠しました：いま見えているのは紙だけ（刷り上がりと同じ）' : '手当て（付箋・点検の印・比べた印）を見せています。手当ては刷られません（刷るときは「刷る」で選ぶ）'); }
let printLayer = 'paper'; try { printLayer = localStorage.getItem('fz.printLayer') === 'care' ? 'care' : 'paper'; } catch { }
/* 1.0.15a 写しの見通し（UI/UX 提案 C-12）：書き出す前に、形ごとに変わる所を位置つきで「変換の記録」の欄に */
function convPreview() { if (!FZ.convAudit) return; const slide = ed.doc.format.kind === 'slide'; const items = [];
  for (const [t, nm] of [[slide ? 'docxSlide' : 'docx', 'Word'], ['pptx', 'PowerPoint'], ['md', 'Markdown'], ['txt', 'テキスト']]) { let A; try { A = FZ.convAudit(ed.doc, t); } catch (e) { continue; } for (const it of A.items) items.push({ what: nm + '：' + it.what, lines: it.lines }); }
  setConvLog({ title: '写しの見通し（書き出す前）', target: 'preview', items, time: Date.now() }); if (st.side !== 'conv') toggleSide('conv'); else drawSide();
  msg(items.length ? `写しで変わる所 ${items.length} 種類を右の欄に出しました（行を選ぶとその位置へ）。印刷・PDF は紙面のまま` : 'どの写しでも、そのまま写ります', false, 7000); }
/* 1.0.15a 版から節ごとに戻す（UI/UX 提案 B-12）：選んだ版を「答え」にして、AI からの戻しと同じ欄で違いを 1 つずつ戻す・捨てる。Ctrl+Z で戻せる */
async function histPick(i) { const arr = await histList(); const v = i != null ? arr[i] : null; if (!v) { msg('版の履歴で版を選んでから', true); return; } return histPickText(v.text, `版 ${i + 1}（${histTime(v.time)}）`); }
async function histPickText(text, name) { let d; try { d = await parseText(text, 'fzk', {}); } catch (e) { msg('この版は読めませんでした：' + e.message, true); return false; } return histPickDoc(d, name, '版から戻す'); }
/* 1.0.15e（C-11）ほかの文書と比べる：ファイル・文庫の文書と今の文書の違いを、版から戻すのと同じ欄で 1 つずつ取り込む・捨てる */
async function compareText(text, name) { const isMd = /\.(md|markdown|txt)$/i.test(name || ''); let d; try { d = await parseText(text, isMd ? 'md' : 'fzk', {}, isMd ? JSON.parse(JSON.stringify(ed.doc.format)) : null); } catch (e) { msg('読めませんでした：' + e.message, true); return false; } return histPickDoc(d, `「${name}」`, '文書と比べる'); }
function histPickDoc(d, name, title) {
  if (st.mode !== 'text' && st.mode !== 'tree') exitMode(); const sigA = docSigs(); const sigB = d.lines.map(l => FZ.lineSig(d, l));
  st.aiBack = { B: d, sigB, idx: ed.doc.lines.map((_, k) => k), snap: sigA, skip: new Set(), i: 0, hunks: [], name, auto: false, taken: 0, md: '', base: null, showSelf: false, selfN: 0, title, hist: true };
  openForm('aiback'); aiSync(); aiShow(); drawSub(); const n = st.aiBack ? st.aiBack.hunks.length : 0; msg(n ? `${name}との違い ${n} か所：${title === '版から戻す' ? '戻す' : '取り込む'}所だけ「取り込む」（Enter）、残す所は「捨てる」（Delete）` : (title === '版から戻す' ? 'この版と今の版の中身は同じです' : `${name}と今の文書の中身は同じです`), false, 8000); return true; }
/* ================= 1.0.16b AI に頼む（下読み・校正・議事録に起こす・要点に絞る） =================
   右の欄「AI に頼む」（side 'request'）：頼む仕事・深さ・範囲・文書の種類・読み手・場面・上限を選び、部品棚（利用者が足した Markdown。RDB に写しを持つ）から依頼を組み立てて写す。
   入る部品と字数は写す前に欄に出る。部品の中の人名は「伏せる名前」で置き換える。答えは「AI から戻す」に貼る：区切りを読み、稿は差分で取り込み、判定・指摘は右の欄に。議事録・要点は新しい文書で開く */
const rqOpt = (() => { const d = { type: 'review', reader: '上位者', scene: 'auto', depth: 'std', scope: 'sec', budget: 40000, namesOnly: false, draft: 'min' }; try { return { ...d, ...JSON.parse(localStorage.getItem('fz.ask') || '{}') }; } catch { return d; } })();
const rqSave = () => { try { localStorage.setItem('fz.ask', JSON.stringify(rqOpt)); } catch { } };
/* 1.0.16e 送り先：チャットに貼る（クリップボード）か、手元の AI（OpenAI 互換の窓口：Unsloth・LM Studio・Ollama・llama-server）。頼む仕事ごとに覚える。答えの受け取りはどちらも同じ */
const RQ_DEST0 = { review: 'clip', proof: 'local', minutes: 'local', gist: 'local' }; rqOpt.dests = { ...RQ_DEST0, ...(rqOpt.dests || {}) };
const rqDest = () => rqOpt.dests[rqOpt.type] || 'clip';
const rqLocal = (() => { const d = { url: 'http://localhost:8888/v1', key: '', model: '', budget: 12000, models: [] }; try { return { ...d, ...JSON.parse(localStorage.getItem('fz.local') || '{}') }; } catch { return d; } })();
const rqLocalSave = () => { try { localStorage.setItem('fz.local', JSON.stringify(rqLocal)); } catch { } };
let rqRun = null; /* 手元の AI に送っている間 { ctrl, n, t0 } */
const rqBase = () => String(rqLocal.url || '').trim().replace(/\/+$/, '').replace(/\/chat\/completions$/, '');
const rqHeaders = () => ({ 'Content-Type': 'application/json', ...(rqLocal.key ? { Authorization: 'Bearer ' + rqLocal.key } : {}) });
const rqNetErr = r => r && r.status === 401 ? '鍵が違う（Unsloth なら Settings → API で作った sk-unsloth-… を入れる）' : r && r.status === 404 ? '窓口が見つからない（URL の末尾は /v1。ポートも確かめる）' : r ? `手元の AI が ${r.status} を返した` : 'つながらない（手元の AI を起動したか、URL とポート、CORS を確かめる）';
async function rqModels() { let r = null; try { r = await fetch(rqBase() + '/models', { headers: rqHeaders() }); if (!r.ok) throw new Error('http'); const j = await r.json(); rqLocal.models = (j.data || []).map(m => m.id).filter(Boolean); if (!rqLocal.models.includes(rqLocal.model)) rqLocal.model = rqLocal.models[0] || ''; rqLocalSave();
    msg(rqLocal.models.length ? `手元の AI につながりました（モデル ${rqLocal.models.length} 個）` : 'つながったが、読み込んだモデルが無い（手元の AI でモデルを読み込んでから）', !rqLocal.models.length, 7000); } catch (e) { msg('手元の AI に' + rqNetErr(r && !r.ok ? r : null), true, 9000); } if (st.side === 'request') drawSide(); return rqLocal.model; }
async function rqSend() { if (rqRun) { msg('手元の AI が書いています（止めるなら欄の「中止」）', true); return; } if (!rqLocal.model && !(await rqModels())) return;
  const { b, sc } = await rqBuildNow(true); if (b.over) { msg(`依頼が手元の上限（${b.budget.toLocaleString()} 字）を超えている：範囲を狭めるか、上限を上げる（モデル側の文脈長も）`, true, 9000); return; } rememberScope(sc.idx, sc.what.replace(/（.*$/, ''));
  const ctrl = new AbortController(); rqRun = { ctrl, n: 0, t0: Date.now() }; if (st.side === 'request') drawSide(); msg(`手元の AI に送りました（${b.total.toLocaleString()} 字）。読んでいます…`, false, 0); let out = '', r = null;
  try { r = await fetch(rqBase() + '/chat/completions', { method: 'POST', headers: rqHeaders(), signal: ctrl.signal, body: JSON.stringify({ model: rqLocal.model, messages: [{ role: 'user', content: b.text }], stream: true, temperature: 0.2 }) }); if (!r.ok) throw new Error('http');
    if (!/event-stream/.test(r.headers.get('content-type') || '') || !r.body) { const j = await r.json(); out = (j.choices && j.choices[0] && (j.choices[0].message || {}).content) || ''; }
    else { const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '', last = 0; for (;;) { const { value, done } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); let k; while ((k = buf.indexOf('\n')) >= 0) { const ln = buf.slice(0, k).trim(); buf = buf.slice(k + 1); if (!ln.startsWith('data:')) continue; const d = ln.slice(5).trim(); if (d === '[DONE]') continue; try { const j = JSON.parse(d); const c = j.choices && j.choices[0] && j.choices[0].delta; if (c && typeof c.content === 'string') out += c.content; } catch { } }
      rqRun.n = out.length; if (Date.now() - last > 400) { last = Date.now(); msg(`手元の AI が書いています… ${out.length.toLocaleString()} 字（${Math.round((Date.now() - rqRun.t0) / 1000)} 秒）`, false, 0); } } } }
  catch (e) { const ab = e && e.name === 'AbortError'; rqRun = null; if (st.side === 'request') drawSide(); msg(ab ? '手元の AI への依頼を中止しました' : '手元の AI に' + rqNetErr(r && !r.ok ? r : null) + '。「代わりに写す」でチャットに貼れる', !ab, 9000); return; }
  const sec = Math.round((Date.now() - rqRun.t0) / 1000); rqRun = null; out = FZ.askStrip(out); if (st.side === 'request') drawSide(); if (!out.trim()) { msg('手元の AI の答えが空でした（文脈長が足りない・モデルの不調）', true, 9000); return; } st.rqLastAnswer = out; rqReceive(out, sec); }
/* 答えの受け取り（手元の AI）：区切りを読み、付箋・判定・稿の差分へ。区切りが無ければ全体を稿として比べる */
function rqReceive(text, sec) { const P = FZ.askParse(text); let md = text; if (P.ok) { const r = rqTake(P); if (r === null || !r) return; md = r; } st.aiBack = null; if (st.form !== 'aiback') openForm('aiback');
  if (aiCompare(md, 'auto')) { drawSub(); const S = st.aiBack, A = st.rqAnswer; msg(`手元の AI の答え（${sec || 0} 秒）：${P.ok ? '' : '区切りが無いので全体を稿として比べる。'}${A && A.made ? `指摘は付箋 ${A.made} 枚。` : ''}${S.hunks.length ? `稿との違い ${S.hunks.length} 件：Enter で取り込む、Delete で捨てる` : '稿との違いはありません'}`, !!(A && A.level === '止'), 9000); st.rqAnswer = null; } else if (st.form === 'aiback') closeForm(); }
let rqMasks = (() => { try { const v = JSON.parse(localStorage.getItem('fz.askMask') || '[]'); return Array.isArray(v) ? v.filter(x => x && x.from) : []; } catch { return []; } })();
const rqMaskSave = () => { try { localStorage.setItem('fz.askMask', JSON.stringify(rqMasks)); } catch { } };
let rqShelf = null; const rqParsed = new Map(); /* 棚の目録 [{ id, name, kind, kindSet, use, chars, title, t }]。中身は RDB 'ask:part:<id>' */
async function shelfLoad() { if (rqShelf) return rqShelf; try { rqShelf = (await RDB.get('ask:shelf')) || []; } catch { rqShelf = []; } return rqShelf; }
async function shelfSave() { try { await RDB.put('ask:shelf', rqShelf); } catch (e) { msg('部品棚を覚えられませんでした：' + e.message, true); } }
async function partGet(p) { let P = rqParsed.get(p.id); if (!P) { let text = null; try { text = await RDB.get('ask:part:' + p.id); } catch { } if (text == null) return null; P = FZ.parsePart(p.name, text, p.kind); rqParsed.set(p.id, P); } P.kind = p.kind; return P; }
async function shelfAdd(files) { await shelfLoad(); let n = 0;
  for (const f of files) { const text = String(f.text || ''); if (!text.trim()) continue; const old = rqShelf.find(p => p.name === f.name); const id = old ? old.id : Date.now().toString(36) + Math.random().toString(36).slice(2, 6); const P = FZ.parsePart(f.name, text, old && old.kindSet ? old.kind : null);
    try { await RDB.put('ask:part:' + id, text); } catch (e) { msg('部品を覚えられませんでした：' + e.message, true); continue; } rqParsed.set(id, P);
    const rec = { id, name: f.name, kind: P.kind, kindSet: !!(old && old.kindSet), use: old ? old.use !== false : true, chars: text.length, title: P.title, t: Date.now() }; if (old) Object.assign(old, rec); else rqShelf.push(rec); n++; }
  /* 伏せる名前の候補：基準・型に 3 回以上出る姓。いちばん多い姓は「上位者」、ほかは「〇〇」 */ const texts = []; for (const p of rqShelf) if (p.kind === '基準' || p.kind === '型') { const P = await partGet(p); if (P) texts.push(P.sections.map(x => x.h + '\n' + x.body).join('\n')); }
  let nm = 0; FZ.askNameCands(texts).forEach((c, k) => { if (!rqMasks.some(m => m.from === c.name)) { rqMasks.push({ from: c.name, to: k === 0 && !rqMasks.some(m => m.to === '上位者') ? '上位者' : '〇〇', person: true }); nm++; } }); if (nm) rqMaskSave();
  await shelfSave(); return { n, nm }; }
function rqScope() { const sc = aiScope(rqOpt.scope === 'whole'); let md, idx = null; if (sc.tree) { md = treeCopyText(); idx = treeCopyIdx(); } else if (sc.range) { md = FZ.toGfm(sliceDoc(sc.range[0], sc.range[1]), { fz: true }); idx = rangeIdx(sc.range[0], sc.range[1]); } else md = FZ.toGfm(ed.doc, { fz: true }); return { md, idx, what: sc.what }; }
async function rqBuildNow(local = rqDest() === 'local') { await shelfLoad(); const parts = []; for (const p of rqShelf) { if (p.use === false) continue; const P = await partGet(p); if (P) parts.push(P); }
  const sc = rqScope(); const kind = docKind(ed.doc); const scene = rqOpt.scene === 'auto' ? FZ.askSceneGuess(sc.md) : rqOpt.scene;
  const mach = (FZ.reviewIssues ? FZ.reviewIssues(ed.doc, { std: stdNow(), kind }) : []).filter(x => !sc.idx || sc.idx.includes(x.line)).map(x => `〔${x.name}〕「${String(x.text).slice(0, 30)}」${x.q || ''}`);
  const b = FZ.askBuild({ type: rqOpt.type, reader: rqOpt.reader, kind, scene, depth: rqOpt.depth, doc: sc.md, docName: sc.what, shelf: parts, masks: rqMasks, machine: mach, std: stdNow(), budget: local ? rqLocal.budget : rqOpt.budget, namesOnly: !local && rqOpt.namesOnly, compact: local });
  return { b, sc, scene }; }
async function rqCopy() { const { b, sc } = await rqBuildNow(); rememberScope(sc.idx, sc.what.replace(/（.*$/, '')); st.rqLast = { type: rqOpt.type, what: sc.what, time: Date.now() }; const ok = await copyText(b.text);
  msg(ok ? `依頼を写しました（${b.total.toLocaleString()} 字${b.over ? '。上限を超えている' : ''}）：AI に貼り、答えを全部写して「答えを貼る」（${K('aiReturn')}）へ` : '写せませんでした', !ok || b.over, 9000); return ok; }
async function rqHtml() { const { b, scene } = await rqBuildNow(); const A = FZ.ASK, kd = docKind(ed.doc); const sel = (k, list, cur) => `<select data-ask="${k}">${list.map(([v, n]) => `<option value="${esc(String(v))}"${String(v) === String(cur) ? ' selected' : ''}>${esc(n)}</option>`).join('')}</select>`;
  const head = `<div class="askf"><label>頼む仕事 ${sel('type', A.TYPES.map(t => [t.id, t.name]), rqOpt.type)}</label>${rqOpt.type === 'review' ? `<label>深さ ${sel('depth', A.DEPTHS.map(d => [d[0], d[1]]), rqOpt.depth)}</label>` : ''}<br><label>送り先 ${sel('dest', [['clip', 'チャットに貼る'], ['local', '手元の AI']], rqDest())}</label><label>範囲 ${sel('scope', [['sec', 'この節・選んだ所'], ['whole', '文書全体']], rqOpt.scope)}</label><br><label>上限 ${rqDest() === 'local' ? `<select data-local="budget">${[[8000, '8 千字'], [12000, '1.2 万字'], [20000, '2 万字'], [40000, '4 万字']].map(([v, n]) => `<option value="${v}"${v === rqLocal.budget ? ' selected' : ''}>${n}</option>`).join('')}</select>` : sel('budget', A.BUDGETS, rqOpt.budget)}</label><br><label>文書の種類 ${sel('kind', [['', '（選ぶ）'], ...FZ.REVIEW_KINDS.map(k => [k, k])], kd)}</label>${rqOpt.type !== 'proof' ? `<label>読み手 ${sel('reader', A.READERS.map(r => [r[0], r[0]]), rqOpt.reader)}</label>` : ''}<br><label>場面 ${sel('scene', A.SCENES.map(s => [s.id, s.id === 'auto' ? `自動（${(A.SCENES.find(x => x.id === scene) || {}).name || 'なし'}）` : s.name]), rqOpt.scene)}</label>${rqOpt.type === 'review' ? `<label>取り込む稿 ${sel('draft', [['min', '最小修正稿'], ['rec', '推奨修正稿']], rqOpt.draft)}</label>` : ''}</div>`;
  const rows = b.items.map(it => `<div class="li askit${it.cut ? ' cut' : ''}"><span class="t">${it.cut ? '×' : '○'} ${esc(it.label)}</span><span class="d">${it.chars.toLocaleString()} 字</span></div>`).join('');
  const sum = `<div class="asksum${b.over ? ' over' : ''}">合計 <b>${b.total.toLocaleString()}</b> 字 ／ 上限 ${b.budget.toLocaleString()} 字${b.over ? '<br>上限を超えている：棚の部品を外すか、「部品は名前だけ」に' : ''}</div>`;
  const loc = rqDest() === 'local'; const L = rqLocal; const locBox = loc ? `<div class="rqloc">窓口 <input class="sb-input" data-local="url" value="${esc(L.url)}" size="22" spellcheck="false"> 鍵 <input class="sb-input" type="password" data-local="key" value="${esc(L.key)}" size="10" placeholder="無ければ空"><button type="button" data-aact="connect" title="窓口につないでモデルの一覧を読む">つなぐ</button><br>モデル <select data-local="model">${(L.models.length ? L.models : [L.model || '（つないで選ぶ）']).map(m => `<option${m === L.model ? ' selected' : ''}>${esc(m)}</option>`).join('')}</select></div>` : '';
  const acts = loc ? locBox + `<div class="hvact">${rqRun ? `<button type="button" class="pri" data-aact="abort">中止</button><span class="d">書いています…</span>` : `<button type="button" class="pri" data-aact="send">手元の AI に頼む</button><button type="button" data-aact="copy" title="同じ依頼をチャット用に写す">代わりに写す</button>`}</div>` : `<div class="hvact"><button type="button" class="pri" data-aact="copy">依頼を写す</button><button type="button" data-aact="paste" title="AI の答えを全部写して貼る（区切りを読んで取り込む）">答えを貼る…</button></div><label class="askchk"><input type="checkbox" data-askchk="namesOnly"${rqOpt.namesOnly ? ' checked' : ''}> 部品は名前だけ（ChatGPT のプロジェクトに置いてある）</label>`;
  const kinds = p => `<select data-pkind="${p.id}">${A.KINDS.map(k => `<option${k === p.kind ? ' selected' : ''}>${k}</option>`).join('')}</select>`;
  const shelf = `<div class="hsec">部品棚</div>` + (rqShelf.length ? rqShelf.map(p => `<div class="li askp"><label class="t"><input type="checkbox" data-puse="${p.id}"${p.use !== false ? ' checked' : ''}> ${esc(p.name)}</label><span class="d">${kinds(p)} ${p.chars.toLocaleString()} 字<button type="button" data-pdel="${p.id}" title="棚から外す">×</button></span></div>`).join('') : '<div class="side-empty">部品棚は空です。内蔵の核と手順だけで頼めます。手持ちの指示文・審査の基準・文体・知識の Markdown を足すと、依頼に入ります。</div>')
    + `<div class="hvact"><button type="button" data-aact="addFiles">ファイルを足す…</button>${'showDirectoryPicker' in window ? '<button type="button" data-aact="addDir">フォルダから…</button>' : ''}</div>`;
  const mask = `<div class="hsec">伏せる名前</div><div class="huser">${rqMasks.map((m, k) => `<span class="hu">${esc(m.from)}${m.person ? '（姓名・敬称ごと）' : ''}→${esc(m.to)}<button type="button" data-mdel="${k}" title="外す">×</button></span>`).join('')}<br><input class="sb-input" id="amFrom" placeholder="姓" size="6"> → <input class="sb-input" id="amTo" placeholder="上位者" size="6"><button type="button" data-aact="maskAdd">足す</button><div class="d">部品の中の名前だけを置き換える（文書そのものは置き換えない）</div></div>`;
  return rqVerdictHtml() + head + `<div class="hsec">依頼に入るもの</div>` + rows + sum + acts + (await rqMatchHtml()) + shelf + mask + `<div class="hvact"><button type="button" data-act="manualSec" data-sec="AI に頼む" title="取扱説明書の「AI に頼む」を開く">説明</button></div>`; }
function rqVerdictHtml() { const V = st.rqVerdict; const nN = rqNotes().length; if (!V || V.doc !== ed.doc) return nN ? `<div class="rqv"><span class="d">下読みの付箋 ${nN} 枚</span><button type="button" data-aact="notesClear">すべて消す</button></div>` : ''; const P = V.P;
  const g = P.gates.filter(x => !x.pass); const fz = f => `${f.sev ? '〔' + esc(f.sev) + '〕' : ''}${f.quote ? '「' + esc(f.quote.slice(0, 20)) + '」' : ''}${esc(f.ask || f.problem || '')}`;
  return `<div class="rqv"><div class="rqj${P.level === '止' ? ' stop' : ''}">判定：${esc(P.verdict || '（判定なし）')}</div>${P.one ? `<div class="d">${esc(P.one)}</div>` : ''}<div class="d">指摘 ${P.findings.length} 件：付箋 ${V.made} 枚${V.lost.length ? `・場所の分からない ${V.lost.length} 件` : ''}</div>`
    + V.lost.map(f => `<div class="li rql"><span class="t">${fz(f)}</span></div>`).join('')
    + (P.needs.length ? `<div class="hsec">要確認</div>` + P.needs.map(t => `<div class="li rql"><span class="t">${esc(t)}</span></div>`).join('') : '')
    + (P.gates.length ? `<div class="hsec">ゲート（不合格 ${g.length} / ${P.gates.length}）</div>` + g.map(x => `<div class="li rql stop"><span class="t">${esc(x.id)}：${esc(x.why)}</span></div>`).join('') : '')
    + `<div class="hvact">${P.draft ? '<button type="button" data-aact="cmpMin">最小稿と比べる</button>' : ''}${P.draft2 ? '<button type="button" data-aact="cmpRec">推奨稿と比べる</button>' : ''}${nN ? `<button type="button" data-aact="notesClear">下読みの付箋を消す（${nN}）</button>` : ''}<button type="button" data-aact="vClose" title="判定の表示を閉じる">閉じる</button></div></div>`; }
/* ---------- 1.0.16d 基準の記録：下読みの予測と本番の朱（提出先の Word のコメントなど）を照らし合わせ、当たりを数える。外れた朱は基準の記録（棚の「基準の記録.md」）に足し、次の依頼の実例にする ---------- */
const rqDocKey = () => String((st.file && st.file.name) || ed.doc.title || '無題').replace(/\.[^.]+$/, '');
const rqNorm = s => String(s || '').normalize('NFKC').replace(/[\s　「」『』]/g, '');
async function rqPredSave(P) { const items = P.findings.filter(f => f.quote || f.ask).map(f => { const at = rqLocate(f.quote); return { quote: f.quote || '', ask: f.ask || '', problem: f.problem || '', sev: f.sev || '', line: at ? lineText(at.line, 400) : '' }; }); if (!items.length) return;
  let L = []; try { L = (await RDB.get('rq:pred')) || []; } catch { } const key = rqDocKey(); const last = L[L.length - 1]; const rec = { doc: key, title: ed.doc.title || '', time: Date.now(), items }; if (last && last.doc === key && JSON.stringify(last.items) === JSON.stringify(items)) return; L.push(rec); while (L.length > 30) L.shift(); try { await RDB.put('rq:pred', L); } catch { } }
async function rqLog() { try { return (await RDB.get('rq:log')) || []; } catch { return []; } }
async function rqMatch() { const me = noteAuthor(); const act = notesInOrder().filter(x => x.n.author !== RQ_AUTHOR && x.n.author !== me); if (!act.length) { msg('提出先の朱（Word のコメントなど）がありません。朱の入った Word を取り込んでから（作成者が自分・下読みの付箋は数えない）', true); return null; }
  let L = []; try { L = (await RDB.get('rq:pred')) || []; } catch { } const key = rqDocKey(); const pred = [...L].reverse().find(r => r.doc === key) || L[L.length - 1]; if (!pred) { msg('下読みの記録がありません（AI に頼む → 答えを貼る、で残る）', true); return null; }
  const used = new Set(); const res = act.map(x => { const lt = rqNorm(lineText(x.i, 400)), q = rqNorm(x.n.quote); const k = pred.items.findIndex(p => { const pq = rqNorm(p.quote), pl = rqNorm(p.line); return (pq.length >= 4 && (lt.includes(pq) || (q.length >= 4 && (q.includes(pq) || pq.includes(q))))) || (q.length >= 4 && pl.includes(q)) || (pl.length >= 8 && pl === lt); }); if (k >= 0) used.add(k); const h = k >= 0 ? pred.items[k] : null;
    return { line: x.i, who: x.n.author, text: String(x.n.text || '').replace(/\s+/g, ' ').trim(), quote: x.n.quote || '', at: lineText(x.i, 60), hit: h ? (h.ask || h.problem || h.quote) : null }; });
  const nHit = res.filter(r => r.hit).length; const rec = { time: Date.now(), doc: key, pred: pred.items.length, predHit: used.size, actual: res.length, hit: nHit };
  const LOG = await rqLog(); const last = LOG[LOG.length - 1]; if (last && last.doc === key && Date.now() - last.time < 3600e3) LOG.pop(); LOG.push(rec); while (LOG.length > 200) LOG.shift(); try { await RDB.put('rq:log', LOG); } catch { }
  st.rqMatch = { res, rec, pred, doc: ed.doc }; if (st.side !== 'request') toggleSide('request'); else drawSide();
  msg(`本番の朱 ${res.length} 件のうち、下読みが当てたのは ${nHit} 件（${Math.round(nHit / res.length * 100)}%）。下読みの指摘 ${pred.items.length} 件のうち当たり ${used.size} 件`, false, 9000); return rec; }
async function rqRecordMissed() { const M = st.rqMatch; if (!M) return; const miss = M.res.filter(r => !r.hit); if (!miss.length) { msg('外れた朱はありません'); return; } await shelfLoad(); const name = '基準の記録.md'; const old = rqShelf.find(p => p.name === name); let text = old ? await RDB.get('ask:part:' + old.id).catch(() => null) : null;
  if (!text) text = '---\n種類: 基準\n名前: 基準の記録\n---\n## 記録（文机が追記。本番の朱で、下読みが当てられなかったもの）\n'; const day = noteNow().slice(0, 10);
  text = text.replace(/\s*$/, '\n') + miss.map(r => `- 「${(r.quote || r.at).replace(/\s+/g, ' ').slice(0, 60)}」：${r.text.slice(0, 200)}（${day}・${M.rec.doc}）`).join('\n') + '\n'; await shelfAdd([{ name, text }]); const p = rqShelf.find(x => x.name === name); if (p) { p.kind = '基準'; p.kindSet = true; await shelfSave(); }
  if (st.side === 'request') drawSide(); msg(`外れた朱 ${miss.length} 件を、部品棚の「基準の記録」に足しました（次の下読みの依頼に実例として入る。名前は伏せて送る）`, false, 8000); }
async function rqMatchHtml() { const LOG = await rqLog(); const tot = LOG.reduce((a, r) => ({ h: a.h + r.hit, n: a.n + r.actual, p: a.p + (r.predHit || 0), q: a.q + r.pred }), { h: 0, n: 0, p: 0, q: 0 });
  const stat = LOG.length ? `<div class="d">これまで ${LOG.length} 回：本番の朱 ${tot.n} 件のうち当てた ${tot.h} 件（${Math.round(tot.h / Math.max(1, tot.n) * 100)}%）・下読みの指摘 ${tot.q} 件のうち当たり ${tot.p} 件</div>` : '';
  const M = st.rqMatch && st.rqMatch.doc === ed.doc ? st.rqMatch : null; if (!M) return `<div class="hsec">本番の朱</div><div class="hvact"><button type="button" data-aact="match" title="提出先が入れた朱（Word のコメントなど）と、下読みの指摘を照らし合わせる">本番の朱と照らし合わせる</button></div>${stat}`;
  const r = M.rec; const miss = M.res.filter(x => !x.hit).length;
  return `<div class="hsec">本番の朱</div><div class="rqv"><div class="rqj">当てた ${r.hit} / ${r.actual} 件（${Math.round(r.hit / r.actual * 100)}%）</div><div class="d">下読み（${esc(M.pred.title || M.pred.doc)}・${esc(histTime(M.pred.time))}）の指摘 ${r.pred} 件のうち当たり ${r.predHit} 件</div>`
    + M.res.map(x => `<div class="li rql${x.hit ? '' : ' stop'}" data-cvl="${x.line}"><span class="t">${x.hit ? '○' : '×'} ${esc(x.who)}：${esc(x.text.slice(0, 40))}${x.hit ? `<br><span class="d">予測：${esc(String(x.hit).slice(0, 30))}</span>` : ''}</span></div>`).join('')
    + `<div class="hvact">${miss ? `<button type="button" data-aact="recMiss">外れた朱を基準の記録に足す（${miss}）</button>` : ''}<button type="button" data-aact="match">照らし直す</button><button type="button" data-aact="mClose">閉じる</button></div>${stat}</div>`; }
function rqWire() { const B = $('sideBody');
  B.querySelectorAll('[data-local]').forEach(el => el.addEventListener('change', () => { const k = el.dataset.local, v = el.value; rqLocal[k] = k === 'budget' ? +v : String(v).trim(); rqLocalSave(); if (k !== 'url' && k !== 'key') drawSide(); }));
  B.querySelectorAll('[data-ask]').forEach(el => el.addEventListener('change', () => { const k = el.dataset.ask, v = el.value; if (k === 'kind') { ed.mutate('', () => { if (v) ed.doc.kind = v; else delete ed.doc.kind; }); healthCache = null; } else if (k === 'dest') rqOpt.dests[rqOpt.type] = v; else rqOpt[k] = k === 'budget' ? +v : v; rqSave(); drawSide(); }));
  B.querySelectorAll('[data-askchk]').forEach(el => el.addEventListener('change', () => { rqOpt[el.dataset.askchk] = el.checked; rqSave(); drawSide(); }));
  B.querySelectorAll('[data-puse]').forEach(el => el.addEventListener('change', async () => { const p = rqShelf.find(x => x.id === el.dataset.puse); if (p) { p.use = el.checked; await shelfSave(); drawSide(); } }));
  B.querySelectorAll('[data-pkind]').forEach(el => el.addEventListener('change', async () => { const p = rqShelf.find(x => x.id === el.dataset.pkind); if (p) { p.kind = el.value; p.kindSet = true; await shelfSave(); drawSide(); } })); }
async function rqClick(e) { const t = e.target; const a = t.closest('[data-aact]');
  if (a) { const k = a.dataset.aact; if (k === 'match') { rqMatch(); return true; } if (k === 'recMiss') { rqRecordMissed(); return true; } if (k === 'mClose') { st.rqMatch = null; drawSide(); return true; } if (k === 'notesClear') { rqNotesClear(); return true; } if (k === 'vClose') { st.rqVerdict = null; drawSide(); return true; } if ((k === 'cmpMin' || k === 'cmpRec') && st.rqVerdict) { const md = k === 'cmpMin' ? st.rqVerdict.P.draft : st.rqVerdict.P.draft2; if (st.form !== 'aiback') { st.aiBack = null; openForm('aiback'); } if (aiCompare(md, 'auto')) { drawSub(); const S = st.aiBack; msg(S.hunks.length ? `${k === 'cmpMin' ? '最小' : '推奨'}修正稿との違い ${S.hunks.length} 件：Enter で取り込む、Delete で捨てる` : '違いはありません'); } return true; } if (k === 'connect') { rqModels(); return true; } if (k === 'send') { rqSend(); return true; } if (k === 'abort') { if (rqRun) rqRun.ctrl.abort(); return true; } if (k === 'copy') rqCopy(); else if (k === 'paste') { if (st.form !== 'aiback') run('aiReturn'); } else if (k === 'addFiles') rqPickFiles(); else if (k === 'addDir') rqPickDir();
    else if (k === 'maskAdd') { const f = (($('amFrom') || {}).value || '').trim(), to = (($('amTo') || {}).value || '').trim(); if (!f) { msg('伏せる姓を入れてください', true); return true; } rqMasks.push({ from: f, to: to || '上位者', person: true }); rqMaskSave(); drawSide(); } return true; }
  const d = t.closest('[data-pdel]'); if (d) { const id = d.dataset.pdel; rqShelf = rqShelf.filter(p => p.id !== id); rqParsed.delete(id); try { await RDB.del('ask:part:' + id); } catch { } await shelfSave(); drawSide(); return true; }
  const m = t.closest('[data-mdel]'); if (m) { rqMasks.splice(+m.dataset.mdel, 1); rqMaskSave(); drawSide(); return true; }
  const cv = t.closest('[data-cvl]'); if (cv) { const i = +cv.dataset.cvl; if (i >= 0 && i < ed.doc.lines.length) { ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); requestRender(); } return true; } return false; }
async function rqAddList(list) { if (!list.length) { msg('Markdown（.md・.txt）がありません', true); return; } await busy('部品棚に足しています…'); const r = await shelfAdd(list); if (st.side === 'request') drawSide(); msg(`部品棚に ${r.n} 件を足しました（種類は推したもの。欄で変えられる）${r.nm ? `。伏せる名前を ${r.nm} 件足しました` : ''}`, false, 8000); }
function rqPickFiles() { const inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true; inp.accept = '.md,.markdown,.txt,text/markdown,text/plain'; inp.onchange = async () => { const fs = [...inp.files]; if (!fs.length) return; rqAddList(await Promise.all(fs.map(async f => ({ name: f.name, text: await f.text() })))); }; inp.click(); }
async function rqPickDir() { try { const h = await window.showDirectoryPicker(); const list = []; for await (const [n, f] of h.entries()) if (f.kind === 'file' && /\.(md|markdown|txt)$/i.test(n)) list.push({ name: n, text: await (await f.getFile()).text() }); rqAddList(list); } catch (e) { if (e.name !== 'AbortError') msg('読めませんでした：' + e.message, true); } }
/* 答え（区切りつき）を受け取る：議事録・要点は新しい文書で開く（null を返す）。下読み・校正は判定・指摘を右の欄に置き、取り込む稿の Markdown を返す */
/* 1.0.16c 引用の場所：空白・全角半角の違いを無視して本文から探す。見つからなければ前の方だけ（24・16・10 字）で。{ line, seg, a, b } | null */
function rqLocate(q) { const raw = String(q || '').replace(/^[「『"“]|[」』"”]$/g, '').replace(/[…．.]+$/, ''); const N = []; for (const c of raw) { const n = c.normalize('NFKC'); if (!/\s/.test(n)) N.push(n); } const key0 = N.join(''); if ([...key0].length < 4) return null;
  const idx = []; ed.doc.lines.forEach((ln, i) => ln.segs.forEach((g, s) => { let t = '', map = []; for (let p = 0; p < g.text.length; p++) { const n = g.text[p].normalize('NFKC'); if (/\s/.test(n)) continue; for (const c of n) { t += c; map.push(p); } } idx.push({ i, s, t, map }); }));
  for (const len of [key0.length, 24, 16, 10]) { if (len > key0.length) continue; const key = key0.slice(0, len); for (const x of idx) { const k = x.t.indexOf(key); if (k >= 0) return { line: x.i, seg: x.s, a: x.map[k], b: x.map[k + key.length - 1] + 1 }; } } return null; }
const RQ_AUTHOR = '下読み'; /* AI の下読みの付箋の作成者。人の付箋と分け、まとめて消せる */
const rqNoteText = f => [`〔${f.sev || '直'}〕${f.ask ? f.ask : f.problem}`, f.ask && f.problem ? '問題：' + f.problem : '', f.fix ? '直し方：' + f.fix : '', f.need ? '要確認：' + f.need : ''].filter(Boolean).join('\n');
function rqNotes() { return (ed.doc.notes || []).filter(n => n.author === RQ_AUTHOR); }
function rqNotesClear() { const ids = new Set(rqNotes().map(n => n.id)); if (!ids.size) { msg('下読みの付箋はありません'); return; } ed.mutate('', () => { ed.doc.notes = ed.doc.notes.filter(n => !ids.has(n.id)); for (const ln of ed.doc.lines) if (ln.attrs.notes) { const a = ln.attrs.notes.filter(id => !ids.has(id)); if (a.length) ln.attrs.notes = a; else delete ln.attrs.notes; } }); render(); if (st.side) drawSide(); msg(`下読みの付箋 ${ids.size} 枚を消しました（人の付箋は残す。Ctrl+Z で戻す）`); }
const rqStops = () => rqNotes().filter(n => !n.done && /^〔止〕/.test(n.text || ''));
function rqStopNext() { const S = new Set(rqStops().map(n => n.id)); if (!S.size) { msg('未解決の「止」はありません'); return; } const L = notesInOrder().filter(x => S.has(x.n.id)); const cur = ed.caret.line; const x = L.find(y => y.i > cur) || L[0]; ed.anchor = null; ed.caret = { line: x.i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); requestRender(); msg(`止 ${L.indexOf(x) + 1}/${L.length}：${(x.n.text || '').split('\n')[0].replace(/^〔止〕/, '')}`, true, 7000); }
/* 答え（区切りつき）を受け取る：議事録・要点は新しい文書で開く（null を返す）。下読み・校正は、引用が本文にある指摘を付箋（作成者「下読み」）にし、判定・場所の分からない指摘・要確認・ゲートを「AI に頼む」の欄に置いて、取り込む稿の Markdown を返す */
function rqTake(P) {
  if (P.minutes || P.gist) { const md = P.minutes || P.gist, nm = P.minutes ? '議事録' : '要点'; withDiscard(async () => { closeForm(); await loadText(md, nm + '.md', null); if (P.minutes) { ed.doc.kind = '議事録'; healthCache = null; } if (P.needs.length) { setConvLog({ title: `AI の${nm}：要確認`, target: 'ai', items: P.needs.map(t => ({ what: '要確認：' + t, lines: [] })), time: Date.now() }); } msg(`${nm}を新しい文書で開きました${P.needs.length ? `（要確認 ${P.needs.length} 件は右の欄「変換の記録」）` : ''}。保存するまでファイルにはならない`, false, 8000); }, '開く'); return null; }
  const placed = [], lost = []; const have = new Set(rqNotes().map(n => n.quote + '|' + n.text));
  for (const f of P.findings) { const at = f.quote ? rqLocate(f.quote) : null; if (at) placed.push({ f, at }); else lost.push(f); }
  let made = 0; if (placed.length) ed.mutate('', () => { const ids = new Set((ed.doc.notes || []).map(n => n.id)); for (const { f, at } of placed) { const text = rqNoteText(f), quote = ed.doc.lines[at.line].segs[at.seg].text.slice(at.a, at.b); if (have.has(quote + '|' + text)) continue; let k = 1; while (ids.has('n' + k)) k++; const id = 'n' + k; ids.add(id);
    (ed.doc.notes = ed.doc.notes || []).push({ id, author: RQ_AUTHOR, date: noteNow(), done: f.sev === '好', quote: quote.slice(0, 400), text, replies: [] }); const a = ed.doc.lines[at.line].attrs; a.notes = [...(a.notes || []), id]; made++; } });
  st.rqVerdict = { P, lost, made, doc: ed.doc, time: Date.now() }; if (P.findings.length) rqPredSave(P); /* 1.0.16d 突っ込みの予測を記録（本番の朱と照らし合わせる） */
  const md = rqOpt.draft === 'rec' && P.draft2 ? P.draft2 : P.draft; st.rqAnswer = { level: P.level, n: P.findings.length, made, lost: lost.length, hasDraft: !!md };
  if (st.side !== 'request') toggleSide('request'); else drawSide(); render();
  if (!md) { msg(`稿がありません。指摘 ${P.findings.length} 件（付箋 ${made} 枚・場所の分からない ${lost.length} 件）`, P.level === '止', 8000); return ''; } return md; }
/* ================= 1.0.15b 文書の健康診断（UI/UX 提案 A-5・B-7・B-10・C-7・E-6） =================
   1 つの欄に：規模（頁・字・文の長さ・見出し・図表）、構造（構造の点検）、参照と番号（参照切れ・名札の重なり）、付箋（未解決）、表記（FZ.proofIssues の決まり）、構成の型（必須の節・順序・書きかけ）。
   行を開くと所の一覧。所を選ぶとそこへ（字の範囲を選ぶ）。表記は「直す」「この種類をすべて直す」（1 回の Ctrl+Z で戻る）・「無視」（文書に覚える）。欄を開いている間、紙面に朱の印（手当て） */
const proofSets = (() => { try { const v = JSON.parse(localStorage.getItem('fz.proofSets') || 'null'); if (Array.isArray(v)) return new Set(v); } catch { } return new Set(['common', 'num', 'user']); })();
const proofUser = (() => { try { const v = JSON.parse(localStorage.getItem('fz.proofUser') || '[]'); return Array.isArray(v) ? v.filter(x => x && x.from) : []; } catch { return []; } })();
const saveProof = () => { try { localStorage.setItem('fz.proofSets', JSON.stringify([...proofSets])); localStorage.setItem('fz.proofUser', JSON.stringify(proofUser)); } catch { } };
/* 1.0.16a 下読み（機械）：健康診断の「下読み」。入り切りと基準（一文の上限・箇条書き既定・空語・誤読を招く語）はこの窓口に覚える。基準は基準ファイル（部品棚の Markdown）から読める */
let reviewOn = (() => { try { return localStorage.getItem('fz.review') === '1'; } catch { return false; } })();
let stdUser = (() => { try { const v = JSON.parse(localStorage.getItem('fz.std') || 'null'); return v && typeof v === 'object' && v.name ? v : null; } catch { return null; } })();
const saveReview = () => { try { localStorage.setItem('fz.review', reviewOn ? '1' : '0'); if (stdUser) localStorage.setItem('fz.std', JSON.stringify(stdUser)); else localStorage.removeItem('fz.std'); } catch { } };
const stdNow = () => stdUser ? { ...FZ.STD_DEFAULT, ...stdUser } : FZ.STD_DEFAULT;
const KIND_OF_KATA = { report: '報告', plan: '企画・要件', minutes: '議事録', prep: '会議資料', kasumi1: '会議資料', kasumi2: '会議資料', kasumi3: '企画・要件', kasumi4: '報告' };
const docKind = doc => doc.kind || KIND_OF_KATA[doc.kata] || '';
function reviewOpen() { if (!reviewOn) { reviewOn = true; saveReview(); healthCache = null; } st.healthOpen = null; if (st.side !== 'health') toggleSide('health'); else drawSide(); requestOverlay(); const rv = healthGet().rows.filter(r => r.sec === '読み手の問い'); const nz = rv.filter(r => !r.info).reduce((t, r) => t + r.n, 0), ns = rv.filter(r => r.info).reduce((t, r) => t + r.n, 0); msg(nz || ns ? `読み手の問い：直す所 ${nz}・整える所 ${ns}（診断の欄。行を開いて所を選ぶ）` : '読み手の問い：気になる所はありません' + (docKind(ed.doc) ? '' : '（文書の種類を選ぶと見る所が増える）'), false, 7000); }
async function stdLoad() { let r; try { r = await FZ.files.open(); } catch (e) { msg('読めませんでした：' + e.message, true); return; } if (!r) return; const s = FZ.parseStd(r.text); if (!s) { msg('基準ファイルではありません（頭の「---」の間に「種類: 基準」「一文の上限: 60」などが要る。雛形を書き出して直す）', true); return; }
  stdUser = { name: s.name, maxSent: s.maxSent, bullets: s.bullets, empty: s.empty, misread: s.misread, kinds: s.kinds, file: r.name }; saveReview(); healthCache = null; if (st.side === 'health') drawSide(); requestOverlay(); msg(`基準「${s.name}」を読みました（一文 ${s.maxSent} 字・空語 ${s.empty.length}・誤読を招く語 ${s.misread.length}）`); }
/* 1.0.16h 右の欄はマウスでも閉じる（見出しの「閉じる ×」） */
{ const b = $('sideClose'); if (b) b.addEventListener('click', () => { closeSide(); focusTA(); }); }
function healthWire() { const B = $('sideBody'); const k = B.querySelector('[data-hkind]'); if (k) k.addEventListener('change', () => { const v = k.value; ed.mutate('', () => { if (v) ed.doc.kind = v; else delete ed.doc.kind; }); healthCache = null; drawSide(); requestOverlay(); msg(v ? `文書の種類を「${v}」に（原本に覚える。Ctrl+Z で戻す）` : '文書の種類を外しました'); }); }
const KATA_GUIDE = /^[（(][^）)]*[）)]$/;
function kataIssues(doc) { const t = SKELETONS.find(x => x.id === doc.kata); if (!t) return null; const req = []; const src = FZ.parse('#fzk 2\n---\n' + t.body); src.lines.forEach((ln, k) => { const a = ln.attrs; if ((a.style === 'num' || a.style === 'sym') && (a.level | 0) === 0) { const nx = src.lines[k + 1]; const g = nx && !nx.attrs.style && !nx.attrs.list ? nx.segs[0].text : ''; req.push({ name: ln.segs[0].text.replace(/（[^）]*）/g, '').trim(), guide: KATA_GUIDE.test(g) ? g : '' }); } });
  const heads = []; doc.lines.forEach((ln, i) => { const a = ln.attrs; if ((a.style === 'num' || a.style === 'sym') && (a.level | 0) === 0) heads.push({ i, text: ln.segs.map(s => s.text).join('') }); });
  const norm = s => s.replace(/[\s　（）()・、]/g, ''); const found = req.map(r => { const h = heads.find(h => norm(h.text).includes(norm(r.name)) || norm(r.name).includes(norm(h.text)) && norm(h.text).length >= 2); return { ...r, at: h ? h.i : -1 }; });
  const missing = found.filter(r => r.at < 0), order = []; let last = -1; for (const r of found) { if (r.at < 0) continue; if (r.at < last) order.push(r); last = Math.max(last, r.at); }
  const guides = new Set(t.body.split('\n').map(x => x.replace(/^\[[^\]]*\]/, '').trim()).filter(x => KATA_GUIDE.test(x) || /〇〇/.test(x))); const left = []; doc.lines.forEach((ln, i) => { const tx = ln.segs.map(s => s.text).join('').trim(); if (tx && (guides.has(tx) || /〇〇/.test(tx))) left.push(i); });
  return { name: t.name, req: found, missing, order, left }; }
function healthReport() { const doc = ed.doc, lay = ed.lay; const R = []; const add = (sec, key, label, items, o = {}) => R.push({ sec, key, label, items, n: items.length, ...o });
  const tx = ln => ln.segs.map(s => s.text).join('');
  /* 規模 */ const chars = doc.lines.reduce((t, ln) => t + [...tx(ln).replace(/[\s　]/g, '')].length, 0); const sents = []; const tr = FZ.tree.build(doc, { body: true });
  for (const n of tr.nodes) { if ((n.kind !== 'body' && n.kind !== 'list') || !n.obj || n.obj.segs.length !== 1) continue; for (const x of FZ.tree.sentences(n.obj.segs[0].text)) sents.push({ line: doc.lines.indexOf(n.obj), len: [...x.text].length, a: x.start, b: x.start + x.text.length }); }
  const avg = sents.length ? Math.round(sents.reduce((t, x) => t + x.len, 0) / sents.length) : 0; const mx = sents.reduce((m, x) => x.len > (m ? m.len : 0) ? x : m, null); const nHead = doc.lines.filter(l => l.attrs.style === 'num' || l.attrs.style === 'sym').length; const nums = FZ.figureNumbers(doc); const nFig = [...nums.values()].filter(v => !v.section).length;
  const scale = { pages: lay ? (lay.bodyPages || lay.pages.length) : 0, chars, sents: sents.length, avg, max: mx ? mx.len : 0, maxAt: mx, heads: nHead, figs: nFig };
  /* 1.0.16a 読み手の問い（1.0.16h：機械の下読みを改名。下読みは AI の仕事の名前） */ if (reviewOn && FZ.reviewIssues) { const P = FZ.reviewIssues(doc, { std: stdNow(), kind: docKind(doc) }); const by = new Map(); for (const x of P) { if (!by.has(x.rule)) by.set(x.rule, []); by.get(x.rule).push(x); } for (const [id, L] of by) add('読み手の問い', 'v_' + id, `${L[0].sev}｜${L[0].name}`, L.map(x => ({ line: x.line, seg: x.seg, a: x.a, b: x.b, msg: x.msg, fix: x.fix, issue: x })), { fixable: L.some(x => x.fix != null), info: L[0].sev === '整' }); }
  /* 1.0.16h プ譜（旧「プ譜の点検」） */ if (FZ.pufuLint && FZ.pufuBlocks(doc).length) { const P = FZ.pufuLint(doc); const w = P.filter(x => x.level === 'warn'), n = P.filter(x => x.level !== 'warn'); const it = x => ({ line: x.line, seg: 0, msg: x.msg }); if (w.length) add('プ譜', 'pf_warn', '直す', w.map(it)); if (n.length) add('プ譜', 'pf_info', '確かめる', n.map(it), { info: true }); }
  /* 構造 */ const SI = structIssues(); for (const k of Object.keys(CHECK_NAMES)) { if (reviewOn && k === 'long') continue; /* 下読みの「長い文」（基準の上限）が受け持つ */ const it = SI.filter(x => x.kind === k).map(x => ({ line: doc.lines.indexOf(x.obj), a: x.a, b: x.b, msg: x.msg })); if (it.length) add('構造', 's_' + k, CHECK_NAMES[k], it); }
  /* 参照と番号（B-7） */ { const broken = [], dup = []; doc.lines.forEach((ln, i) => ln.segs.forEach((sg, s) => { for (let q = 0; q < sg.text.length; q++) { const cp = sg.text.codePointAt(q); if (cp >= 0xF0000 && cp <= 0xFFFFD) { const id = FZ.refId(doc, String.fromCodePoint(cp)); if (!id || !nums.has(id)) broken.push({ line: i, seg: s, a: q, b: q + 2, msg: `参照先が無い（${id ? (id.startsWith('§') ? '節の名札 ' + id.slice(1) : '図表 ' + id) : '不明'}）` }); q++; } } }));
    const seen = new Map(); doc.lines.forEach((ln, i) => { const a = ln.attrs.anchor; if (!a) return; if (seen.has(a)) dup.push({ line: i, msg: `節の名札「${a}」が ${seen.get(a) + 1} 行目と重なっている（参照はその最初の節へ）` }); else seen.set(a, i); });
    const noTitle = []; for (const [, v] of nums) if (!v.section && !String(v.title || '').trim()) noTitle.push({ line: v.line, msg: `${v.label} に題が無い` });
    if (broken.length) add('参照と番号', 'r_broken', '参照切れ', broken); if (dup.length) add('参照と番号', 'r_dup', '節の名札の重なり', dup); if (noTitle.length) add('参照と番号', 'r_notitle', '題の無い図表', noTitle, { info: true }); }
  /* 1.0.15d 合計の行：上の行の合計と違う（原本を外で直した・AI が書いた）。表を直すか「合計」を押し直すと計算し直す */ if (doc.lines.some(l => l.attrs.sumRow)) { const cl = { ...doc, lines: doc.lines.map(l => ({ attrs: { ...l.attrs, cellAlign: l.attrs.cellAlign && l.attrs.cellAlign.slice() }, segs: l.segs.map(g => ({ ...g, marks: g.marks.slice() })) })) }; FZ.tbl.sumSync(cl, null); const bad = []; cl.lines.forEach((l, i) => { if (l.attrs.sumRow && l.segs.some((g, k) => g.text !== (doc.lines[i].segs[k] || {}).text)) bad.push({ line: i, msg: '合計の行の数が、上の行の合計と違う（表を直すと計算し直す）' }); }); if (bad.length) add('構造', 's_sum', '合計の行の食い違い', bad); }
  /* 1.0.15e（B-6）組版の点検：頁の下の大きな空き（送った理由つき。自分で決めた改頁は除く）・段落の最後の 1 行だけが次の頁・最初の 1 行だけが頁の最後 */
  if (lay && lay.pages && lay.pages.length > 1 && lay.geo) { const rows = lay.geo.rows, NP = lay.pages.length; const used = new Array(NP).fill(0), first = new Array(NP).fill(-1);
    doc.lines.forEach((ln, i) => { const lm = lay.lineMap[i]; if (!lm) return; for (const r of lm.rows) { if (r.page >= NP) continue; used[r.page] = Math.max(used[r.page], r.y + r.h); if (first[r.page] < 0) first[r.page] = i; } });
    const gaps = [], wid = [], orp = [];
    for (let p = 0; p + 1 < NP; p++) { const free = rows - used[p], i = first[p + 1]; if (i < 0 || free < Math.max(5, rows * 0.3)) continue; const W = lay.lineMap[i] && lay.lineMap[i].why; if (W && W.brk && W.brk.own === 'breakBefore') continue; if (doc.lines[i].attrs.style === 'title') continue; gaps.push({ line: i, msg: `${p + 1} 頁の下が ${Math.round(free)} 行空いている${W && W.brk ? '（' + W.brk.why + '）' : ''}` }); }
    doc.lines.forEach((ln, i) => { const lm = lay.lineMap[i]; if (!lm || lm.rows.length < 3 || FZ.inTable(doc, i) || ln.attrs.figure || ln.attrs.toc) return; const ps = lm.rows.map(r => r.page); const p0 = ps[0], p1 = ps[ps.length - 1]; if (p0 === p1) return;
      if (ps.filter(p => p === p1).length === 1) wid.push({ line: i, msg: `段落の最後の 1 行だけが ${p1 + 1} 頁に（前で削るか、改頁の位置を変える）` }); if (ps.filter(p => p === p0).length === 1) orp.push({ line: i, msg: `段落の最初の 1 行だけが ${p0 + 1} 頁の最後に` }); });
    if (gaps.length) add('組版', 't_gap', '頁の下の大きな空き', gaps, { info: true }); if (wid.length) add('組版', 't_widow', '最後の 1 行だけが次の頁', wid, { info: true }); if (orp.length) add('組版', 't_orphan', '最初の 1 行だけが頁の最後', orp, { info: true }); }
  /* 付箋 */ { const open = notesInOrder().filter(x => !x.n.done).map(x => ({ line: x.i, msg: `付箋 ${x.k + 1}：${(x.n.text || '').replace(/\s+/g, ' ').slice(0, 30)}` })); if (open.length) add('付箋', 'n_open', '未解決の付箋', open, { info: true }); }
  /* 表記（B-10） */ if (FZ.proofIssues) { const P = FZ.proofIssues(doc, { sets: [...proofSets], user: proofUser }); const by = new Map(); for (const x of P) { if (!by.has(x.id)) by.set(x.id, []); by.get(x.id).push(x); } for (const [id, L] of by) add('表記', 'p_' + id, L[0].name, L.map(x => ({ line: x.line, seg: x.seg, a: x.a, b: x.b, msg: x.msg, fix: x.fix, issue: x })), { fixable: L.some(x => x.fix != null), info: L[0].set === 'kobun' && false }); }
  /* 構成の型（E-6） */ const K = doc.kata ? kataIssues(doc) : null; if (K) { if (K.missing.length) add('構成の型', 'k_missing', '型の節が無い', K.missing.map(r => ({ line: -1, msg: `「${r.name}」の節が無い${r.guide ? '　' + r.guide : ''}` }))); if (K.order.length) add('構成の型', 'k_order', '型と節の順が違う', K.order.map(r => ({ line: r.at, msg: `「${r.name}」が型の順より前にある` }))); if (K.left.length) add('構成の型', 'k_left', '書きかけ（型の手引きが残っている）', K.left.map(i => ({ line: i, msg: '「（ ）」の手引きや「〇〇」を書き換える' }))); }
  return { scale, rows: R, kata: K }; }
let healthCache = null;
function healthGet() { const sig = ed.doc.lines.length + ':' + (ed.lay && ed.lay.globalSig) + ':' + ed.undoStack.length + ':' + [...proofSets].join() + ':' + proofUser.length + ':' + (ed.doc.proofIgnore || []).length + ':' + (ed.doc.notes || []).length + ':' + ed.redoStack.length + ':' + reviewOn + ':' + (ed.doc.kind || '') + ':' + (stdUser ? stdUser.name + stdUser.maxSent + stdUser.bullets + (stdUser.empty || []).join() + (stdUser.misread || []).join() : ''); if (!healthCache || healthCache.sig !== sig || healthCache.doc !== ed.doc) healthCache = { sig, doc: ed.doc, R: healthReport() }; return healthCache.R; }
function healthItems() { const H = healthGet(); const out = []; for (const r of H.rows) { if (st.healthOpen && st.healthOpen !== r.key) continue; for (const it of r.items) if (it.line >= 0) out.push({ ...it, key: r.key }); } return out; }
function healthGo(it) { if (!it || it.line < 0) return; const L = it.line; if (st.mode === 'tree' || st.mode === 'fig') exitMode(); if (it.a != null) { ed.anchor = { line: L, seg: it.seg || 0, off: it.a }; ed.caret = { line: L, seg: it.seg || 0, off: Math.min(it.b, ed.doc.lines[L].segs[it.seg || 0].text.length), vcol: null, vrow: 0 }; } else { ed.anchor = null; ed.caret = { line: L, seg: 0, off: 0, vcol: null, vrow: 0 }; } ed.onCaret(); scrollToCaret(true); requestOverlay(); }
function healthStep(d) { const L = healthItems(); if (!L.length) { msg('気になる所はありません'); return; } st.healthIdx = st.healthIdx == null ? (d > 0 ? 0 : L.length - 1) : (st.healthIdx + d + L.length) % L.length; const it = L[st.healthIdx]; healthGo(it); msg(`${st.healthIdx + 1}/${L.length}：${it.msg}`, false, 6000); }
function healthFix(list) { const n0 = list.filter(x => x.fix != null).length; if (!n0) return; let n = 0; ed.mutate('', () => { n = FZ.proofApply(ed.doc, list.map(x => x.issue || x)); }); healthCache = null; render(); if (st.side === 'health') drawSide(); msg(`${n} か所を直しました（1 回の Ctrl+Z で戻る）`); }
function healthIgnore(it) { const x = it.issue; if (!x) return; ed.mutate('', () => { const a = ed.doc.proofIgnore = ed.doc.proofIgnore || []; const k = x.id + '|' + x.text; if (!a.includes(k)) a.push(k); }); healthCache = null; if (st.side === 'health') drawSide(); requestOverlay(); msg(`「${x.text}」を、この決まりでは無視します（文書に覚える。Ctrl+Z で戻す）`); }
function healthHtml() { const H = healthGet(), S = H.scale; const hasErr = H.rows.filter(r => !r.info).reduce((t, r) => t + r.n, 0);
  const sc = `<div class="hvhead"><b>${S.pages}</b> 頁・<b>${S.chars.toLocaleString()}</b> 字・文 ${S.sents}（平均 <b>${S.avg}</b> 字・最長 ${S.max} 字）・見出し ${S.heads}・図表 ${S.figs}<br><span class="d">${hasErr ? `直す・確かめる所 ${hasErr} 件。行を開いて所を選ぶとその位置へ（紙面には朱の印）` : '気になる所はありません'}</span></div>`;
  const sets = `<div class="hset">${FZ.PROOF_SETS.map(([k, nm]) => `<label><input type="checkbox" data-hset="${k}"${proofSets.has(k) ? ' checked' : ''}> ${nm}</label>`).join('')}<label title="読み手が必ず問うこと（何と比べて？・誰がいつ？・で、結論は？…）を、打つそばから拾う（通信なし）"><input type="checkbox" data-hrev${reviewOn ? ' checked' : ''}> 読み手の問い</label></div>`;
  const SD = stdNow(), kd = docKind(ed.doc); const rbar = reviewOn ? `<div class="hrev">文書の種類 <select data-hkind><option value="">（選ぶ）</option>${FZ.REVIEW_KINDS.map(k => `<option${k === kd ? ' selected' : ''}>${k}</option>`).join('')}</select>${!ed.doc.kind && kd ? '<span class="d">（構成の型から）</span>' : ''}<br>基準：<b>${esc(SD.name)}</b><span class="d">（一文 ${SD.maxSent} 字${SD.bullets ? '・箇条書き既定' : ''}・空語 ${SD.empty.length}・誤読を招く語 ${SD.misread.length}）</span><br><button type="button" data-hact="stdLoad" title="部品棚の基準ファイル（Markdown）を読む">基準を読む…</button><button type="button" data-hact="stdTpl" title="基準ファイルの雛形を書き出す（部品棚に置いて直す）">雛形を書き出す</button>${stdUser ? '<button type="button" data-hact="stdReset" title="読んだ基準を外して既定に戻す">既定に戻す</button>' : ''}${kd ? '' : '<div class="d">文書の種類を選ぶと、報告・評価・会議資料向けの点検（表の読み方・結論の位置・活動で終わる文・期限）も入る</div>'}</div>` : '';
  const user = proofSets.has('user') ? `<div class="huser">${proofUser.map((u, k) => `<span class="hu">${esc(u.from)}→${esc(u.to)}<button type="button" data-hdel="${k}" title="この決まりを消す">×</button></span>`).join('')}<input class="sb-input" id="huFrom" placeholder="誤" size="6"> → <input class="sb-input" id="huTo" placeholder="正" size="6"><button type="button" data-hact="uadd">決まりを足す</button></div>` : '';
  let sec = ''; const rows = H.rows.map(r => { const head = r.sec !== sec ? `<div class="hsec">${esc(r.sec)}</div>` : ''; sec = r.sec; const open = st.healthOpen === r.key;
    const items = open ? r.items.slice(0, 60).map((it, k) => `<div class="li hit${st.healthSel === r.key + ':' + k ? ' cur' : ''}" data-hit="${r.key}:${k}"><span class="t">${it.line >= 0 ? esc(lineText(it.line, 18) || '（空行）') : '—'}<br><span class="d">${esc(it.msg)}${it.fix != null ? `　→「${esc(it.fix)}」` : ''}</span></span>${it.fix != null ? `<button type="button" data-hfix="${r.key}:${k}">直す</button>` : ''}${it.issue ? `<button type="button" data-hign="${r.key}:${k}" title="この字はこの決まりで見ない（文書に覚える）">無視</button>` : ''}</div>`).join('') + (r.items.length > 60 ? `<div class="side-empty">ほか ${r.items.length - 60} か所</div>` : '') + (r.fixable ? `<div class="hvact"><button type="button" class="pri" data-hfixall="${r.key}">この種類をすべて直す（${r.items.filter(x => x.fix != null).length}）</button></div>` : '') : '';
    return head + `<div class="li hrow${open ? ' on' : ''}${r.info ? ' info' : ''}" data-hrow="${r.key}"><span class="t"><b class="hn">${r.n}</b>　${esc(r.label)}</span><span class="d">${open ? '▲' : '▼'}</span></div>` + items; }).join('');
  return sc + sets + rbar + user + (rows || '<div class="side-empty">直す所・確かめる所はありません。</div>') + `<div class="hvact"><button type="button" data-hact="prev" title="前の所">↑ 前</button><button type="button" data-hact="next" title="次の所">次 ↓</button><button type="button" data-act="manualSec" data-sec="文書の健康診断" title="取扱説明書の「文書の健康診断」を開く">説明</button></div>`; }
function healthClick(e) { const t = e.target; const H = healthGet(); const find = v => { const [key, k] = String(v).split(':'); const r = H.rows.find(x => x.key === key); return r ? { r, it: r.items[+k] } : null; };
  const cb = t.closest('[data-hset]'); if (cb) { const k = cb.dataset.hset; if (cb.checked) proofSets.add(k); else proofSets.delete(k); saveProof(); healthCache = null; drawSide(); requestOverlay(); return true; }
  const rv = t.closest('[data-hrev]'); if (rv) { reviewOn = rv.checked; saveReview(); healthCache = null; drawSide(); requestOverlay(); if (reviewOn) reviewOpen(); return true; }
  const del = t.closest('[data-hdel]'); if (del) { proofUser.splice(+del.dataset.hdel, 1); saveProof(); healthCache = null; drawSide(); return true; }
  const ha = t.closest('[data-hact]'); if (ha) { const a = ha.dataset.hact; if (a === 'uadd') { const f = ($('huFrom') || {}).value || '', to = ($('huTo') || {}).value || ''; if (!f.trim()) { msg('「誤」の字を入れてください', true); return true; } proofUser.push({ from: f.trim(), to: to.trim() }); proofSets.add('user'); saveProof(); healthCache = null; drawSide(); msg(`決まりを足しました：${f.trim()} → ${to.trim()}`); } else if (a === 'next' || a === 'prev') healthStep(a === 'next' ? 1 : -1); else if (a === 'stdLoad') stdLoad(); else if (a === 'stdTpl') exportVia('基準の雛形', '基準.md', () => FZ.stdTemplate()); else if (a === 'stdReset') { stdUser = null; saveReview(); healthCache = null; drawSide(); requestOverlay(); msg('基準を既定に戻しました'); } return ['uadd', 'next', 'prev', 'stdLoad', 'stdTpl', 'stdReset'].includes(a); }
  const fx = t.closest('[data-hfix]'); if (fx) { const f = find(fx.dataset.hfix); if (f) healthFix([f.it]); return true; }
  const fa = t.closest('[data-hfixall]'); if (fa) { const r = H.rows.find(x => x.key === fa.dataset.hfixall); if (r) healthFix(r.items); return true; }
  const ig = t.closest('[data-hign]'); if (ig) { const f = find(ig.dataset.hign); if (f) healthIgnore(f.it); return true; }
  const it = t.closest('[data-hit]'); if (it) { const f = find(it.dataset.hit); if (f) { st.healthSel = it.dataset.hit; healthGo(f.it); drawSide(); } return true; }
  const row = t.closest('[data-hrow]'); if (row) { st.healthOpen = st.healthOpen === row.dataset.hrow ? null : row.dataset.hrow; st.healthIdx = null; drawSide(); requestOverlay(); return true; }
  return false; }
/* 紙面の朱の印（C-7）：欄を開いている間、開いた行の所（無ければ全部、300 まで）に細い朱の枠 */
function healthMarks(ov) { if (st.side !== 'health' || st.careHidden) return; const lay = ed.lay; let n = 0; for (const it of healthItems()) { if (n++ > 300) break; const lm = lay.lineMap[it.line]; if (!lm) continue;
    if (it.a != null) { const sl = lm.segs[it.seg || 0]; if (!sl) continue; for (const row of sl.rows) { let x0 = Infinity, x1 = -Infinity; for (const g of row.glyphs) { if (g.off < it.a || g.off >= it.b || g.marker) continue; x0 = Math.min(x0, g.col); x1 = Math.max(x1, g.col + g.w); } if (x1 > x0) ov.hits.push({ page: row.page, col: x0 - 0.05, y: row.y + 0.05, w: x1 - x0 + 0.1, h: row.h - 0.1 }); } }
    else { const r0 = lm.rows[0]; if (r0) ov.tags.push({ page: r0.page, col: -0.6, y: r0.y, text: '！', anchor: 'end' }); } } }
/* ---------- 1.0.15d（A-3・C-15）引き出し欄：記号・断片・文庫・量（右の欄のタブ。提案の「物差し」は、版面の物差しと紛れるので「量」） ---------- */
const lsJ = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, lsW = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { } };
const DRAWER_TABS = [['sym', '記号'], ['snip', '断片'], ['lib', '文庫'], ['ruler', '量'], ['tools', '道具']];
function openDrawer(tab) { const t = tab || st.drawerTab || lsJ('fz.drawerTab', 'sym'); if (st.side === 'drawer' && (!tab || tab === st.drawerTab)) { closeSide(); return; } st.drawerTab = t; lsW('fz.drawerTab', t); if (st.side === 'drawer') drawSide(); else toggleSide('drawer'); }
const symNorm = s => String(s || '').normalize('NFKC').toLowerCase().replace(/[ァ-ヶ]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x60)).replace(/\s+/g, ' ').trim();
function textReady() { if (st.mode === 'tree') { msg('紙面で入れます（Esc で紙面へ）', true); return false; } if (st.mode !== 'text') exitMode(); const a = ed.line().attrs; if (a.figure || a.toc || a.hr) { msg('この行には字を入れられません（図・目次・区切り線）', true); return false; } return true; }
/* 欄（帯の下の入力）に字を打っている最中なら、そこへ入れる */
function insertIntoField(t) { const ae = document.activeElement; if (!ae || ae === ta || !/^(INPUT|TEXTAREA)$/.test(ae.tagName) || ae.closest('#side') || /^(checkbox|radio|number|range)$/.test(ae.type)) return false; try { ae.setRangeText(t, ae.selectionStart, ae.selectionEnd, 'end'); ae.dispatchEvent(new Event('input', { bubbles: true })); return true; } catch { return false; } }
function symListHtml() { const q = symNorm(st.symQ || ''); const raw = (st.symQ || '').trim();
  const cats = FZ.SYMBOLS.map(([cat, ca, list]) => { const hit = !q ? list : list.filter(([ch, al]) => ch === raw || symNorm(al + ' ' + ca + ' ' + cat).includes(q)); return hit.length ? `<div class="sycat">${esc(cat)}</div><div class="sygrid">${hit.map(([ch, al]) => `<button type="button" data-sym="${esc(ch)}" title="${esc(ch + '　' + al.split(' ').filter(x => !/^[a-z]+$/.test(x)).slice(0, 3).join('・'))}">${esc(ch)}</button>`).join('')}</div>` : ''; }).join('');
  const rec = lsJ('fz.symRecent', []); return (rec.length && !q ? `<div class="sycat">最近</div><div class="sygrid">${rec.map(ch => `<button type="button" data-sym="${esc(ch)}">${esc(ch)}</button>`).join('')}</div>` : '') + (cats || '<div class="side-empty">見つかりません（「まる」「こめ」「やじるし」「かっこ」「まるいち」など）。</div>'); }
function symHtml() { return `<input class="sb-input" id="symQ" placeholder="探す（まる・こめ・やじるし・かっこ・まる1…）" value="${esc(st.symQ || '')}"><div id="symList">${symListHtml()}</div><div class="hvact"><button type="button" data-dact="scheme" title="見出しと箇条書きの記号（三体系）を変える">見出し・箇条書きの記号…</button></div><div class="side-empty hint">押すとカーソルの所に入る（続けて押せる）。帯の欄に打っている最中なら欄に入る。①・㈱・㍻ などは古い環境で化けることがある</div>`; }
function insertSym(ch) { if (!insertIntoField(ch)) { if (!textReady()) return; ed.insertText(ch, { key: '' }); ed.breakUndo(); render(); recPush({ text: ch }); }
  const r = lsJ('fz.symRecent', []).filter(x => x !== ch); r.unshift(ch); lsW('fz.symRecent', r.slice(0, 24)); }
/* 断片箱：自分の断片（この PC のこの窓口に覚える。設定の書き出しにも入る）と、公用文の定型句 */
function snipItems() { const mine = lsJ('fz.snippets', []).map((x, k) => ({ t: String(x.t || x), k })); return lsJ('fz.snipPreset', true) ? mine.concat(FZ.SNIPPETS.map((t, k) => ({ t, p: k }))) : mine; }
function snipListHtml() { const q = symNorm(st.snipQ || ''); const L = snipItems().filter(x => !q || symNorm(x.t).includes(q));
  return L.length ? L.map(x => `<div class="li sn${x.p != null ? ' pre' : ''}" data-snip="${x.p != null ? 'p' + x.p : 'm' + x.k}" title="${esc(x.t)}"><span class="t">${esc(x.t.length > 70 ? x.t.slice(0, 70) + '…' : x.t).replace(/\n/g, '<br>')}</span>${x.p == null ? `<button type="button" data-sndel="${x.k}" title="この断片を消す">×</button>` : ''}</div>`).join('') : '<div class="side-empty">断片がありません。字を選んで「選んだ字を断片に」。</div>'; }
function snipHtml() { return `<input class="sb-input" id="snipQ" placeholder="断片を探す" value="${esc(st.snipQ || '')}"><div class="hvact"><button type="button" data-dact="snipAdd" title="選んだ字（選んでいなければカーソルの行）を断片に">選んだ字を断片に</button><label class="chk"><input type="checkbox" data-snippre${lsJ('fz.snipPreset', true) ? ' checked' : ''}> 公用文の定型句</label></div><div id="snipList">${snipListHtml()}</div><div class="side-empty hint">押すとカーソルの所に入る。〔　〕は選んだ形で入るので、そのまま打てば置き換わる。複数行の断片は Markdown として組む</div>`; }
function insertSnippet(t) { if (insertIntoField(t.replace(/\n+/g, ' '))) return; if (!textReady()) return; t = String(t).replace(/\r/g, '').replace(/\n+$/, ''); if (!/\n/.test(t)) recPush({ text: t });
  if (/\n/.test(t)) { insertMarkdown(t); ed.breakUndo(); render(); msg('断片を入れました（Ctrl+Z で戻る）'); return; }
  if (/\*\*[^*]+\*\*/.test(t) && insertInlineMarkdown(t)) { ed.breakUndo(); render(); return; }
  ed.insertText(t, { key: '' }); ed.breakUndo(); const p = t.indexOf('〔'), q = t.indexOf('〕', p);
  if (p >= 0 && q > p) { const c = ed.caret; const st0 = c.off - t.length; if (st0 >= 0 && ed.seg().text.slice(st0, c.off) === t) { ed.anchor = { line: c.line, seg: c.seg, off: st0 + p }; ed.caret = { line: c.line, seg: c.seg, off: st0 + q + 1, vcol: null, vrow: 0 }; ed.onCaret(); msg('〔　〕を選びました：打てば置き換わる（次の〔 は Ctrl+F で「〔」）'); } }
  render(); }
function snipAdd() { const s = st.mode === 'text' ? ed.sel() : null; const t = (s ? ed.textOf(s) : ed.line().segs.map(x => x.text).join('　')).replace(/\s+$/, ''); if (!t.trim()) { msg('断片にする字を選んでください', true); return; }
  const mine = lsJ('fz.snippets', []).filter(x => String(x.t || x) !== t); mine.unshift({ t }); lsW('fz.snippets', mine.slice(0, 300)); drawSide(); msg('断片に入れました（引き出し → 断片）'); }
/* 文庫：開いた・保存した文書（保存先のあるものだけ）。お気に入りは上に。文書をまたいで探せる */
const LIB_KEY = 'lib:recent';
async function libList() { try { const L = await RDB.get(LIB_KEY); return Array.isArray(L) ? L : []; } catch { return []; } }
async function libSame(x, ref) { if (ref.path) return x.path === ref.path; if (ref.handle && x.handle && typeof x.handle.isSameEntry === 'function') { try { return await x.handle.isSameEntry(ref.handle); } catch { return false; } } return false; }
async function libTouch(ref, name) { if (!ref || !(ref.handle || ref.path)) return; try { const L = await libList(); let old = null; for (let i = 0; i < L.length; i++) if (await libSame(L[i], ref)) { old = L.splice(i, 1)[0]; break; }
    L.unshift({ name: name || ref.name || (old && old.name) || '文書', path: ref.path || null, handle: ref.handle || null, time: Date.now(), fav: !!(old && old.fav) });
    const favs = L.filter(x => x.fav), rest = L.filter(x => !x.fav).slice(0, 30); await RDB.put(LIB_KEY, L.filter(x => x.fav || rest.includes(x)).slice(0, 30 + favs.length)); if (st.side === 'drawer' && st.drawerTab === 'lib') drawSide(); } catch { } }
async function libRead(x, ask) { try { if (x.handle) { let p = 'granted'; if (typeof x.handle.queryPermission === 'function') { p = await x.handle.queryPermission({ mode: 'readwrite' }); if (p !== 'granted' && ask && typeof x.handle.requestPermission === 'function') p = await x.handle.requestPermission({ mode: 'readwrite' }); } if (p !== 'granted') return null; }
    return await FZ.files.read({ handle: x.handle, path: x.path }); } catch { return null; } }
async function libOpen(i, jump) { const L = await libList(); const x = L[i]; if (!x) return; const text = await libRead(x, true); if (text == null) { msg(`「${x.name}」を開けません（動かした・消した、または読む許しがない。ファイル → 開く で開き直してください）`, true); return; }
  withDiscard(async () => { await loadText(text, x.name, { handle: x.handle || undefined, path: x.path || undefined, name: x.name }); if (jump) setTimeout(() => libJump(jump), 0); }); }
function libJump(j) { const L = ed.doc.lines; let i = Math.min(j.line, L.length - 1); const q = j.q.toLowerCase(); const find = k => { const sg = L[k] && L[k].segs.findIndex(s => s.text.toLowerCase().includes(q)); return sg >= 0 ? sg : -1; };
  if (find(i) < 0) { i = L.findIndex((l, k) => find(k) >= 0); if (i < 0) return; } const sg = find(i); const off = L[i].segs[sg].text.toLowerCase().indexOf(q); healthGo({ line: i, seg: sg, a: off, b: off + q.length }); }
async function libFind() { const q = (($('libQ') || {}).value || '').trim(); st.libQ = q; if (!q) { st.libHits = null; drawSide(); return; } const L = await libList(); const hits = []; let skip = 0, n = 0; const ql = q.toLowerCase(); msg('文庫の文書を探しています…', false, 0);
  for (let i = 0; i < L.length && hits.length < 300; i++) { const text = await libRead(L[i], i === 0); if (text == null) { skip++; continue; } n++; let lines; try { lines = /\.(md|markdown|txt)$/i.test(L[i].name) ? text.split('\n') : FZ.parse(text).lines.map(l => l.segs.map(s => s.text).join(' ')); } catch { lines = text.split('\n'); }
    lines.forEach((t, k) => { if (hits.length < 300 && t.toLowerCase().includes(ql)) hits.push({ i, name: L[i].name, line: k, t }); }); }
  st.libHits = { q, hits, skip, n }; msg(`${n} 本の文書で ${hits.length} か所${skip ? `（${skip} 本は読めなかった：許しがない・動かした）` : ''}`); drawSide(); }
function libHitsHtml() { const H = st.libHits; if (!H) return ''; const ctx = t => { const k = t.toLowerCase().indexOf(H.q.toLowerCase()); const a = Math.max(0, k - 10); return (a ? '…' : '') + esc(t.slice(a, k)) + `<b class="fdh">${esc(t.slice(k, k + H.q.length))}</b>` + esc(t.slice(k + H.q.length, k + H.q.length + 14)); };
  return `<div class="side-empty">「${esc(H.q)}」：${H.n} 本で ${H.hits.length} か所${H.skip ? `（${H.skip} 本は読めない）` : ''}</div>` + H.hits.slice(0, 120).map((h, k) => `<div class="li lbh" data-libhit="${k}"><span class="t">${ctx(h.t)}<br><span class="d">${esc(h.name)}</span></span></div>`).join(''); }
async function libHtml() { const L = await libList(); const row = (x, i) => `<div class="li lb" data-lib="${i}"><span class="t">${x.fav ? '★ ' : ''}${esc(x.name)}<br><span class="d">${esc(histTime(x.time))}${x.path ? '　' + esc(String(x.path).replace(/[\\/][^\\/]*$/, '')) : ''}</span></span><button type="button" data-libcmp="${i}" title="今の文書と比べる（違いを 1 つずつ取り込む・捨てる）">比</button><button type="button" data-libfav="${i}" title="${x.fav ? 'お気に入りから外す' : 'お気に入りにする（一覧の上に残る）'}">${x.fav ? '★' : '☆'}</button><button type="button" data-libdel="${i}" title="一覧から外す（ファイルは消さない）">×</button></div>`;
  const fav = L.map((x, i) => [x, i]).filter(([x]) => x.fav), rest = L.map((x, i) => [x, i]).filter(([x]) => !x.fav);
  return `<div class="hvact"><input class="sb-input" id="libQ" placeholder="文庫の文書をまとめて探す" value="${esc(st.libQ || '')}"><button type="button" data-dact="libFind">探す</button></div><div id="libHits">${libHitsHtml()}</div>`
    + (L.length ? (fav.length ? '<div class="sycat">お気に入り</div>' + fav.map(([x, i]) => row(x, i)).join('') : '') + (rest.length ? '<div class="sycat">最近</div>' + rest.map(([x, i]) => row(x, i)).join('') : '')
      : '<div class="side-empty">開いた・保存した文書がここに並びます（保存先のある文書だけ）。</div>') + '<div class="side-empty hint">ブラウザで使うときは、開き直すたびに読む許しを聞かれることがある（exe 版は聞かない）</div>'; }
/* 量：字数・頁・構成・付箋・健康診断のまとめ。目標の字数を決めると残りが出る（文書の名前ごとに覚える） */
function curSection() { const items = ed.outline(); const cur = ed.caret.line; let best = null; for (const it of items) { if (it.kind === 'list') continue; const [a, b] = ed.sectionRange(it.line); if (cur >= a && cur <= b) best = { it, a, b }; } return best; }
const charsIn = (a, b) => { let n = 0; for (let i = a; i <= b; i++) for (const s of ed.doc.lines[i].segs) for (const ch of s.text) if (!/[\s　]/.test(ch)) n++; return n; };
function rulerHtml() { const d = ed.doc, lay = ed.lay; const ch = ed.charCount(), pages = lay.pages.length; const heads = d.lines.filter(l => l.attrs.style === 'num' || l.attrs.style === 'sym').length;
  let tables = 0; d.lines.forEach((l, i) => { if (FZ.inTable(d, i) && !(i > 0 && FZ.inTable(d, i - 1))) tables++; }); const figs = d.lines.reduce((t, l) => t + (l.attrs.figs || []).length + (l.attrs.figure ? 1 : 0), 0);
  const notes = d.notes || [], open = notes.filter(n => !n.done).length; const sec = curSection(); const s = ed.sel(); let sc = 0; if (s) for (const c of ed.textOf(s)) if (!/[\s　]/.test(c)) sc++;
  const gkey = 'fz.goal.' + ((st.file && st.file.name) || d.title || '無題'); const goal = lsJ(gkey, 0) | 0;
  const H = healthGet(); const fixes = H.rows.filter(r => r.n && !r.info); const nfix = fixes.reduce((t, r) => t + r.n, 0);
  const tr = (k, v) => `<tr><th>${k}</th><td>${v}</td></tr>`;
  return `<table class="ruler">${tr('字数', `${ch.toLocaleString()} 字<span class="d">（400 字詰め 約 ${Math.max(1, Math.ceil(ch / 400))} 枚）</span>`)}${tr('頁', `${pages} 頁${ed.layoutDone ? '' : '＋'}<span class="d">（1 頁 平均 ${pages ? Math.round(ch / pages).toLocaleString() : 0} 字）</span>`)}`
    + (sec ? tr('この節', `${charsIn(sec.a, sec.b).toLocaleString()} 字<span class="d">（${esc(sec.it.text.slice(0, 16))}）</span>`) : '') + (s ? tr('選んだ所', sc.toLocaleString() + ' 字') : '')
    + tr('構成', `見出し ${heads}・表 ${tables}・図表 ${figs}`) + tr('付箋', notes.length ? `未解決 ${open} ／ ${notes.length}` : 'なし')
    + tr('目標', `<input class="sb-input num" id="goalIn" type="number" min="0" step="100" value="${goal || ''}" placeholder="字数"> 字${goal ? `<span class="d">　${ch <= goal ? '残り ' + (goal - ch).toLocaleString() + ' 字' : '<b class="alert">' + (ch - goal).toLocaleString() + ' 字超え</b>'}</span><div class="gbar"><i style="width:${Math.min(100, Math.round(ch / goal * 100))}%"></i></div>` : ''}`) + '</table>'
    + `<div class="sycat">健康診断${nfix ? `：直す・確かめる所 ${nfix}` : '：直す所なし'}</div>` + fixes.slice(0, 6).map(r => `<div class="li"><span class="t">${esc(r.label)}</span><span class="d">${r.n}</span></div>`).join('')
    + `<div class="hvact"><button type="button" data-dact="health">健康診断を開く</button><button type="button" data-dact="count">字数を数える…</button></div>`; }
async function drawerHtml() { const t = st.drawerTab || 'sym'; const tabs = `<div class="dtabs" role="tablist">${DRAWER_TABS.map(([k, l]) => `<button type="button" role="tab" data-dtab="${k}" class="${k === t ? 'on' : ''}" aria-selected="${k === t}">${l}</button>`).join('')}</div>`;
  return tabs + (t === 'sym' ? symHtml() : t === 'snip' ? snipHtml() : t === 'lib' ? await libHtml() : t === 'tools' ? toolsHtml() : rulerHtml()); }
function drawerWire() { if (st.drawerTab === 'tools') toolsWire(); const q = $('symQ'); if (q) q.addEventListener('input', () => { st.symQ = q.value; const el = $('symList'); if (el) el.innerHTML = symListHtml(); });
  const sq = $('snipQ'); if (sq) sq.addEventListener('input', () => { st.snipQ = sq.value; const el = $('snipList'); if (el) el.innerHTML = snipListHtml(); });
  const lq = $('libQ'); if (lq) lq.addEventListener('keydown', e => { if (e.key === 'Enter' && !imeKey(e)) { e.preventDefault(); libFind(); } });
  const g = $('goalIn'); if (g) g.addEventListener('change', () => { const gkey = 'fz.goal.' + ((st.file && st.file.name) || ed.doc.title || '無題'); lsW(gkey, Math.max(0, +g.value | 0)); drawSide(); });
  const sp = $('sideBody').querySelector('[data-snippre]'); if (sp) sp.addEventListener('change', () => { lsW('fz.snipPreset', sp.checked); const el = $('snipList'); if (el) el.innerHTML = snipListHtml(); }); }
async function drawerClick(e) { const t = e.target;
  const tb = t.closest('[data-dtab]'); if (tb) { st.drawerTab = tb.dataset.dtab; lsW('fz.drawerTab', st.drawerTab); drawSide(); return true; }
  if (st.drawerTab === 'tools' && await toolsClick(t)) return true;
  const sy = t.closest('[data-sym]'); if (sy) { insertSym(sy.dataset.sym); return true; }
  const da = t.closest('[data-dact]'); if (da) { const a = da.dataset.dact; if (a === 'scheme') run('scheme'); else if (a === 'snipAdd') snipAdd(); else if (a === 'libFind') libFind(); else if (a === 'health') { toggleSide('health'); } else if (a === 'count') run('count'); return true; }
  const sd = t.closest('[data-sndel]'); if (sd) { const mine = lsJ('fz.snippets', []); mine.splice(+sd.dataset.sndel, 1); lsW('fz.snippets', mine); drawSide(); return true; }
  const sn = t.closest('[data-snip]'); if (sn) { const v = sn.dataset.snip; const txt = v[0] === 'p' ? FZ.SNIPPETS[+v.slice(1)] : String((lsJ('fz.snippets', [])[+v.slice(1)] || {}).t || ''); if (txt) insertSnippet(txt); return true; }
  const lc = t.closest('[data-libcmp]'); if (lc) { const L = await libList(); const x = L[+lc.dataset.libcmp]; if (x) { const text = await libRead(x, true); if (text == null) msg(`「${x.name}」を読めません`, true); else compareText(text, x.name); } return true; }
  const lf = t.closest('[data-libfav]'); if (lf) { const L = await libList(); const x = L[+lf.dataset.libfav]; if (x) { x.fav = !x.fav; await RDB.put(LIB_KEY, L).catch(() => { }); } drawSide(); return true; }
  const ld = t.closest('[data-libdel]'); if (ld) { const L = await libList(); L.splice(+ld.dataset.libdel, 1); await RDB.put(LIB_KEY, L).catch(() => { }); st.libHits = null; drawSide(); return true; }
  const lh = t.closest('[data-libhit]'); if (lh) { const h = st.libHits && st.libHits.hits[+lh.dataset.libhit]; if (h) libOpen(h.i, { line: h.line, q: st.libHits.q }); return true; }
  const lb = t.closest('[data-lib]'); if (lb) { libOpen(+lb.dataset.lib); return true; }
  return false; }
/* ---------- 1.0.15d（C-6）状態行の「次の一手」：今いる所で効く操作を 2〜3 個。押せば実行（字に近道を添える） ---------- */
let nextNumKey = '', nextNumVal = null;
function pufuNextOf(X) { const it = X && X.it; if (!it) return ['pfAdd:win', 'pufuCheck', 'pufuPhaseSave']; if (X.res) return ['pufuCheck', 'pufuPhaseSave', 'pufuInsight']; if (it.kind === 'frame') return ['pfAdd:mid', 'pfAdd:frame', 'pufuCheck']; const d = it.depth; return d === 0 ? ['pfAdd:win', 'pufuCheck', 'pufuRes'] : d === 1 ? ['pfAdd:mid', 'pfAdd:frame', 'pfAdd:win'] : d === 2 ? ['pfAdd:act', 'pfAdd:out', 'pfAdd:mid'] : d === 3 ? ['pfAdd:act', 'pfAdd:step', 'pufuInsight'] : ['pfAdd:step', 'pfAdd:act', 'pufuInsight']; } /* 1.0.16g 役ごとの次の一手 */
function nextCmds() { if (st.form || st.bandKb || st.armed) return []; if (st.mode === 'tree') { const n = treeNodeSel(); const X = n && n.line != null && !n.root ? pufuCtx(n.line) : null; return X ? pufuNextOf(X).filter(id => /^pfAdd:/.test(id)).concat(['tv:edit']).slice(0, 3) : ['tv:child', 'tv:after', 'tv:edit']; } if (st.mode === 'fig') return ['fg:add', 'fg:connect', 'fg:compact']; if (st.mode !== 'text') return [];
  const a = ed.line().attrs, L = ed.caret.line; if (st.cells) return ['tmerge', 'tca:right', 'tcb']; if (ed.sel()) return ['bold', 'noteAdd', 'find'];
  if (a.cells && FZ.inTable(ed.doc, L)) { const I = FZ.tbl.info(ed); if (!I) return ['tableGroup', 'tr:below']; if (a.sumRow) return ['tblSum', 'tr:above', 'tblNumRight'];
    const k = ed.gen + ':' + I.a + ':' + I.b; if (k !== nextNumKey) { nextNumKey = k; const P = FZ.tbl.numCols(ed.doc, I.a, I.b, I.B); nextNumVal = { sum: P.cols.some(c => !c.mixed && !c.rate) && FZ.tbl.sumRowOf(ed.doc, I) < 0, any: P.cols.length > 0 }; }
    return ['tableGroup', 'tr:below', nextNumVal.sum ? 'tblSum' : nextNumVal.any ? 'tblNumRight' : 'tc:right']; }
  if (a.figure) return ['fg:compact', 'figInsert']; if (a.figs) return ['figEdit', 'figRef']; if (a.toc) return ['toc'];
  if (a.notes && a.notes.length) return ['noteNext', 'noteList'];
  if (pufuCtxCached()) return pufuNextOf(pufuCtx());
  if (a.style === 'num' || a.style === 'sym') return ['aiCopySec', 'outlineUp', 'outlineDown'];
  if (a.list) return ['childItem', 'arrow', 'todo'];
  return ['health', 'drawer']; }
let BAND_SHORT = null;
function shortOf(c) { if (!BAND_SHORT) { BAND_SHORT = new Map(); for (const g of Object.values(GROUPS)) for (const it of g.items || []) if (it.cmd && !BAND_SHORT.has(it.cmd)) BAND_SHORT.set(it.cmd, String(it.short || it.label).replace(/（.*$/, '').replace(/…$/, '')); }
  return BAND_SHORT.get(c.id) || c.label.replace(/^[^：]{1,4}：/, '').replace(/（.*$/, '').replace(/…$/, '').slice(0, 8); }
function updateNext() { const el = $('stNext'); if (!el) return; const nStop = st.form || st.mode !== 'text' ? 0 : rqStops().length; /* 1.0.16c 未解決の「止」 */ const ids = [...(nStop ? ['rqStopNext'] : []), ...nextCmds()].map(cmdById).filter(Boolean).slice(0, 3); const key = ids.map(c => c.id).join(',') + ':' + nStop; if (el.dataset.k === key) return; el.dataset.k = key;
  el.innerHTML = ids.map(c => { const k = keysOf(c); return `<button type="button" data-next="${c.id}"${c.id === 'rqStopNext' ? ' class="stop"' : ''} title="${esc(c.label + (k ? '　［' + k + '］' : ''))}">${esc(c.id === 'rqStopNext' ? '止 ' + nStop : /^pfAdd:/.test(c.id) ? '＋' + shortOf(c) : shortOf(c))}</button>`; }).join(''); el.hidden = !ids.length; }
$('stNext').addEventListener('pointerdown', e => e.preventDefault());
$('stNext').addEventListener('click', e => { const b = e.target.closest('[data-next]'); if (!b) return; run(b.dataset.next); requestRender(); });
/* ---------- 1.0.15d（C-8）ガイドの「いまいる場所」と、取扱説明書の節へ飛ぶ ---------- */
function hereTopic() { if (st.form === 'find' || st.form === 'replace') return ['検索・置換', 'write', '検索・置換']; if (st.mode === 'tree') return ['ツリー', 'tree', 'ツリー']; if (st.mode === 'fig') return ['流れ図', 'insert', '流れ図'];
  const a = ed.line().attrs, L = ed.caret.line;
  if (st.cells || (a.cells && FZ.inTable(ed.doc, L))) { let a0 = L; while (a0 > 0 && FZ.inTable(ed.doc, a0 - 1)) a0--; if (ed.doc.lines[a0].attrs.gantt) return ['工程表', 'table', '工程表（ガントチャート）']; return a.sumRow ? ['表の合計の行', 'table', '表の計算'] : ['表', 'table', '表']; }
  if (a.figure) return ['流れ図', 'insert', '流れ図']; if (a.figs) return ['図表', 'insert', '図表の設定']; if (a.toc) return ['目次', 'insert', '目次'];
  if (FZ.pufuAt && FZ.pufuAt(ed.doc, L)) return ['プ譜', 'pufu', 'プ譜']; if (a.fw) return ['フレームワーク', 'insert', 'フレームワーク']; if (a.style === 'speech') return ['発言録', 'line', '発言録'];
  if (a.style === 'num' || a.style === 'sym' || a.list || a.style === 'title') return ['見出し・箇条書き', 'para', '構造で書く']; if (a.notes && a.notes.length) return ['付箋', 'write', '付箋'];
  if (ed.sel()) return ['字の飾り', 'marks', '字の飾り']; return ['書く・直す', 'write', '書く・直す']; }
function hereHtml() { const [label, hid, sec] = hereTopic(); return `<div class="here" id="helpHere" data-k="${esc(label)}"><b>いまいる場所</b>　${esc(label)}<br><button type="button" data-go="h-${hid}">この欄の節へ</button><button type="button" data-act="manualSec" data-sec="${esc(sec)}" title="取扱説明書（文書）を開いて、その節へ">取扱説明書の「${esc(sec)}」</button></div>`; }
function updateHere() { if (st.side !== 'help') return; const el = $('helpHere'); if (!el) return; const [label] = hereTopic(); if (el.dataset.k !== label) el.outerHTML = hereHtml(); }
function manualJump(sec, n = 0) { const L = ed.doc.lines; const isHead = l => l.attrs.style === 'num' || l.attrs.style === 'sym'; const tx = l => l.segs.map(s => s.text).join('').trim();
  let i = L.findIndex(l => isHead(l) && tx(l) === sec); if (i < 0) i = L.findIndex(l => isHead(l) && tx(l).includes(sec)); if (i < 0) return;
  const lm = ed.lay.lineMap[i]; if (!(lm && lm.rows && lm.rows[0])) { if (n < 120) setTimeout(() => manualJump(sec, n + 1), 50); return; } ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); requestRender(); msg(`取扱説明書の「${sec}」`); }
/* ---------- 1.0.15e（C-5）集中の表示と頁の地図 ----------
   集中：カーソルの節（いちばん深い見出しの節）のほかを白い薄紙で覆う（紙面の上の覆い。刷りには出ない・手当てとも別）。
   頁の地図：紙面の右端に細い帯。頁ごとの区切り・付箋（朱）・健康診断の所（朱の点）・改頁の指定（墨）・いま見ている所（枠）。押すとその所へ */
st.focus = lsJ('fz.focus', false); st.pageMap = lsJ('fz.pageMap', true);
function focusRange() { if (!st.focus || st.mode !== 'text') return null; const s = curSection(); if (s) return [s.a, s.b]; return null; }
function focusDims(ov) { const R = focusRange(); if (!R) return; const lay = ed.lay; const [a, b] = R; const lmA = lay.lineMap[a], lmB = lay.lineMap[b]; if (!lmA || !lmB || !lmA.rows[0] || !lmB.rows.length) return;
  const r0 = lmA.rows[0], rl = lmB.rows[lmB.rows.length - 1]; const p0 = r0.page, p1 = rl.page; ov.dims = [];
  for (let p = 0; p < lay.pages.length; p++) { if (p < p0 || p > p1) { ov.dims.push({ page: p, y1: null, y2: null }); continue; } if (p === p0) ov.dims.push({ page: p, y1: null, y2: r0.y }); if (p === p1) ov.dims.push({ page: p, y1: rl.y + rl.h, y2: null }); } }
const pageMapEl = (() => { const el = document.createElement('div'); el.id = 'pageMap'; el.setAttribute('aria-label', '頁の地図'); document.body.appendChild(el); return el; })();
let pageMapKey = '';
function drawPageMap() { const el = pageMapEl; const lay = ed.lay; const N = lay && lay.pages ? lay.pages.length : 0; const on = st.pageMap && st.mode !== 'tree' && N >= 2 && !document.body.classList.contains('printing');
  el.hidden = !on; if (!on) return; const r = main.getBoundingClientRect(); const sbw = main.offsetWidth - main.clientWidth; el.style.top = r.top + 'px'; el.style.height = r.height + 'px'; el.style.left = (r.right - sbw - 12) + 'px';
  const rows = lay.geo.rows; const pos = (page, y) => ((page + Math.max(0, Math.min(rows, y)) / rows) / N * 100).toFixed(3) + '%';
  const key = [ed.gen, ed.docId, N, st.careHidden, st.side, (ed.doc.notes || []).length].join(':');
  if (key !== pageMapKey) { if (pageMapKey && N > 60 && !drawPageMap.now) { clearTimeout(drawPageMap.t); drawPageMap.t = setTimeout(() => { drawPageMap.now = true; try { drawPageMap(); } finally { drawPageMap.now = false; } }, 400); } else { pageMapKey = key; const marks = []; /* 大きな文書は打つたびに作り直さない（止めて 0.4 秒後） */
    for (let p = 1; p < N; p++) marks.push(`<i class="pm-pg" style="top:${pos(p, 0)}"></i>`);
    ed.doc.lines.forEach((ln, i) => { const lm = lay.lineMap[i]; const r0 = lm && lm.rows && lm.rows[0]; if (!r0) return;
      if (ln.attrs.breakBefore) marks.push(`<i class="pm-br" style="top:${pos(r0.page, r0.y)}" title="ここから改頁"></i>`);
      if (!st.careHidden && ln.attrs.notes && ln.attrs.notes.length) { const open = ln.attrs.notes.some(id => { const n = (ed.doc.notes || []).find(x => x.id === id); return n && !n.done; }); if (open) marks.push(`<i class="pm-note" data-pml="${i}" style="top:${pos(r0.page, r0.y)}" title="付箋"></i>`); }
      if (ln.attrs.style === 'num' && (ln.attrs.level | 0) === 0) marks.push(`<i class="pm-h" data-pml="${i}" style="top:${pos(r0.page, r0.y)}" title="${esc(ln.segs.map(s => s.text).join('').slice(0, 30))}"></i>`); });
    if (!st.careHidden && st.side === 'health') { let n = 0; for (const it of healthItems()) { if (n++ > 300 || it.line < 0) continue; const lm = lay.lineMap[it.line]; const r0 = lm && lm.rows && lm.rows[0]; if (r0) marks.push(`<i class="pm-hit" style="top:${pos(r0.page, r0.y)}"></i>`); } }
    el.innerHTML = marks.join('') + '<b class="pm-view"></b>'; } }
  const v = el.querySelector('.pm-view'); if (v && main.scrollHeight > 0) { v.style.top = (main.scrollTop / main.scrollHeight * 100).toFixed(3) + '%'; v.style.height = Math.max(1, main.clientHeight / main.scrollHeight * 100).toFixed(3) + '%'; } }
pageMapEl.addEventListener('pointerdown', e => { e.preventDefault(); const t = e.target.closest('[data-pml]'); if (t) { const i = +t.dataset.pml; if (st.mode !== 'text') exitMode(); ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); requestRender(); focusTA(); return; }
  const r = pageMapEl.getBoundingClientRect(); const f = Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)); main.scrollTop = f * main.scrollHeight - main.clientHeight / 2; focusTA(); });
window.addEventListener('resize', () => drawPageMap());
/* ---------- 1.0.15e（C-3）原本の面：カーソルの節の原本（.fzk の行）を右の欄で読み書きする ----------
   紙面 → 原本：カーソルが別の節へ移る・紙面で直すと、欄の原本を書き直す（欄で打っている最中は書き直さない）。
   原本 → 紙面：打ち止めて 0.7 秒（か Ctrl+Enter・「紙面へ」）で読み直し、節を置き換える。紙面へ移すごとに 1 回の Ctrl+Z で戻る。
   読めない原本は欄に誤りを出し、紙面は変えない。範囲は表を割らない。画像の中身（#添付）は欄に出さない（図版の名前はそのまま） */
let srcState = null; /* { a, b, head, text, gen, err } */
function srcRange() { const L = ed.doc.lines.length; const s = curSection(); let a, b; if (s) { a = s.a; b = s.b; } else if (L <= 400) { a = 0; b = L - 1; } else { a = Math.max(0, ed.caret.line - 40); b = Math.min(L - 1, ed.caret.line + 40); }
  while (a > 0 && FZ.inTable(ed.doc, a) && FZ.inTable(ed.doc, a - 1)) a--; while (b < L - 1 && FZ.inTable(ed.doc, b) && FZ.inTable(ed.doc, b + 1)) b++; return [a, b]; }
/* 原本の面の切り出し：sliceDoc と同じだが、見出しの番号を文書に合わせる「再開」は付けない（読み戻すと文書に再開が入ってしまう） */
function srcSlice(a, b) { const d = ed.doc; const sub = { ...d, lines: d.lines.slice(a, b + 1).map(l => JSON.parse(JSON.stringify(l))), rules: [], fills: [], images: {}, refs: d.refs };
  for (const r of d.rules) { if (r.axis === 'h' && r.line >= a && r.line <= b + 1) sub.rules.push({ ...r, line: r.line - a }); else if (r.axis === 'v' && r.from >= a && r.to <= b) sub.rules.push({ ...r, from: r.from - a, to: r.to - a }); }
  for (const f of d.fills) if (f.from >= a && f.to <= b) sub.fills.push({ ...f, from: f.from - a, to: f.to - a }); return FZ.normalize(sub); }
function srcText(a, b) { const sub = srcSlice(a, b); const t = FZ.serialize(sub); const k = t.indexOf('\n---\n'); return { head: t.slice(0, k + 5), body: t.slice(k + 5).replace(/\n$/, '') }; }
function srcLoad(force) { const ta2 = $('srcTa'); if (!ta2) return; if (!force && document.activeElement === ta2 && srcState && srcState.dirty) return; const [a, b] = srcRange();
  if (!force && srcState && srcState.a === a && srcState.b === b && srcState.gen === ed.gen) return; const T = srcText(a, b); srcState = { a, b, head: T.head, text: T.body, gen: ed.gen, err: null, dirty: false }; ta2.value = T.body; srcPaint(); srcInfo(); }
function srcInfo() { const el = $('srcInfo'); if (!el || !srcState) return; const s = curSection(); el.innerHTML = `${srcState.err ? `<b class="alert">読めない：${esc(srcState.err)}</b>` : `行 ${srcState.a + 1}〜${srcState.b + 1}${s ? `　節「${esc(s.it.text.slice(0, 14))}」` : ''}`}`; }
/* 色分け：指示の行（#罫・#表・#図 …）は灰の斜体、行の頭の [種類] は太字、<飾り> は朱、\ の逃がしは薄く */
function srcPaint() { const pre = $('srcPre'), ta2 = $('srcTa'); if (!pre || !ta2) return; pre.innerHTML = ta2.value.split('\n').map(l => { if (/^#/.test(l)) return `<i class="sd">${esc(l)}</i>`; let h = esc(l); h = h.replace(/^(\[[^\]]*\])/, '<b class="sa">$1</b>').replace(/(&lt;\/?[^&\s][^&]*?&gt;)/g, '<span class="sm">$1</span>'); return h; }).join('\n') + '\n'; pre.scrollTop = ta2.scrollTop; }
function srcApply() { const ta2 = $('srcTa'); if (!ta2 || !srcState) return false; const body = ta2.value; let sub; try { sub = FZ.parse(srcState.head + body + '\n'); } catch (e) { srcState.err = e.message; srcInfo(); return false; }
  if (!sub.lines.length) sub.lines = [FZ.newLine()]; const { a, b } = srcState; const d = ed.doc; const n0 = b - a + 1, n1 = sub.lines.length, dl = n1 - n0;
  ed.mutate('src', () => { const inSlice = r => (r.axis === 'h' && r.line >= a && r.line <= b + 1) || (r.axis === 'v' && r.from >= a && r.to <= b);
    d.rules = d.rules.filter(r => !inSlice(r)); d.fills = d.fills.filter(f => !(f.from >= a && f.to <= b));
    for (const r of d.rules) { if (r.axis === 'h') { if (r.line > b + 1) r.line += dl; } else if (r.from > b) { r.from += dl; r.to += dl; } else if (r.to > b) r.to += dl; }
    for (const f of d.fills) { if (f.from > b) { f.from += dl; f.to += dl; } else if (f.to > b) f.to += dl; }
    d.lines.splice(a, n0, ...sub.lines); for (const r of sub.rules) { const q = { ...r, id: r.id || FZ.uid() }; if (q.axis === 'h') q.line += a; else { q.from += a; q.to += a; } d.rules.push(q); } for (const f of sub.fills) d.fills.push({ ...f, id: f.id || FZ.uid(), from: f.from + a, to: f.to + a });
    if (sub.notes && sub.notes.length) { const ids = new Set(sub.notes.map(n => n.id)); d.notes = (d.notes || []).filter(n => !ids.has(n.id)).concat(sub.notes); }
    const c = ed.caret; if (c.line > b) c.line += dl; else if (c.line >= a) c.line = Math.min(c.line, a + n1 - 1); ed.anchor = null; });
  srcState.b = a + n1 - 1; srcState.gen = ed.gen; srcState.err = null; srcState.dirty = false; srcInfo(); render(); return true; }
let srcTimer = 0;
function srcWire() { const ta2 = $('srcTa'); if (!ta2) return; ta2.addEventListener('input', () => { if (!srcState) return; srcState.dirty = true; srcPaint(); clearTimeout(srcTimer); srcTimer = setTimeout(() => { if (srcState && srcState.dirty && !ta2.dataset.ime) srcApply(); }, 700); });
  ta2.addEventListener('compositionstart', () => { ta2.dataset.ime = '1'; }); ta2.addEventListener('compositionend', () => { delete ta2.dataset.ime; ta2.dispatchEvent(new Event('input')); });
  ta2.addEventListener('scroll', () => { const pre = $('srcPre'); if (pre) pre.scrollTop = ta2.scrollTop; });
  ta2.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); clearTimeout(srcTimer); srcApply(); } else if (e.key === 'Escape') { e.preventDefault(); clearTimeout(srcTimer); if (srcState && srcState.dirty) srcApply(); focusTA(); } e.stopPropagation(); });
  ta2.addEventListener('blur', () => { clearTimeout(srcTimer); if (srcState && srcState.dirty) srcApply(); }); }
function srcHtml() { return `<div class="hvhead"><span id="srcInfo"></span><br><span class="d">打ち止めると紙面へ（Ctrl+Enter でもすぐ）。Esc で紙面へ戻る。取消は紙面の Ctrl+Z</span></div><div class="srcbox"><pre id="srcPre" aria-hidden="true"></pre><textarea id="srcTa" spellcheck="false" wrap="soft" aria-label="原本"></textarea></div><div class="hvact"><button type="button" data-srcact="apply" class="pri">紙面へ</button><button type="button" data-srcact="reload" title="紙面から読み直す（欄で直した分は捨てる）">読み直す</button><button type="button" data-act="manualSec" data-sec="原本の形式" title="取扱説明書の「原本の形式」">書き方</button></div>`; }
/* ---------- 1.0.15f（A-6）道具箱：操作をまとめた「道具」を作って、Alt+1〜9 か押して使う ----------
   道具＝コマンドと字の並び（{ cmd } ｜ { text }）。作り方は 2 つ：「記録」（押したコマンド・引き出しから入れた記号と断片を順に覚える）と「足す」（コマンドを名前で選んで足す）。
   1 つのコマンドだけの道具に Alt+数字を割り当てれば、そのコマンドの近道になる（キーの割り当て）。欄の開くコマンドは、欄を開いたところで止まる。
   この PC（この窓口）に覚え、設定の書き出しに入る */
const toolsGet = () => lsJ('fz.tools', []).filter(t => t && Array.isArray(t.steps)), toolsPut = L => lsW('fz.tools', L);
function stepLabel(s) { if (s.text != null) return '「' + (s.text.length > 12 ? s.text.slice(0, 12) + '…' : s.text) + '」を入れる'; const c = cmdById(s.cmd); return c ? shortOf(c) + (c.group ? '（' + c.group + '）' : '') : s.cmd; }
function toolRun(t) { if (!t || !t.steps.length) return; if (st.rec) { msg('記録の最中は道具を使えません（記録を止めてから）', true); return; } st.toolPlaying = true; let n = 0;
  try { for (const s of t.steps) { if (s.text != null) { if (!textReady()) break; ed.insertText(s.text, { key: '' }); ed.breakUndo(); } else { if (!cmdById(s.cmd)) continue; run(s.cmd); } n++; if (st.form) break; /* 欄が開いた：そこで止める */ } }
  finally { st.toolPlaying = false; } render(); msg(`道具「${t.name}」：${n} / ${t.steps.length} 手${n < t.steps.length ? '（欄が開いたので、そこで止めた）' : ''}`); }
function toolKey(e) { if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || !/^[1-9]$/.test(e.key)) return false; const t = toolsGet().find(x => String(x.key) === e.key); if (!t) return false; e.preventDefault(); toolRun(t); return true; }
function recStart() { st.rec = []; msg('記録を始めました：コマンドを押す・引き出しから記号や断片を入れると、順に覚えます（打った字は覚えない）。止めるには 道具 → 記録を止める', false, 8000); if (st.side === 'drawer') drawSide(); updateGuide(); }
function recStop() { const steps = st.rec || []; st.rec = null; if (!steps.length) { msg('記録した操作がありません'); if (st.side === 'drawer') drawSide(); return; } const L = toolsGet(); L.push({ name: '道具 ' + (L.length + 1), key: '', steps }); toolsPut(L); st.toolOpen = L.length - 1; msg(`${steps.length} 手を道具にしました：名前と Alt+数字を決めてください`); if (st.side === 'drawer') drawSide(); }
function recPush(step) { if (!st.rec || st.toolPlaying) return; const last = st.rec[st.rec.length - 1]; if (step.text != null && last && last.text != null && !step.cmd) { last.text += step.text; return; } st.rec.push(step); if (st.side === 'drawer' && st.drawerTab === 'tools') { const el = $('recN'); if (el) el.textContent = st.rec.length; } }
const REC_SKIP = new Set(['drawer', 'symbols', 'snippets', 'library', 'docMeter', 'palette', 'help', 'undo', 'redo', 'save', 'saveAs', 'open', 'new', 'print']);
function toolsHtml() { const L = toolsGet(); const used = new Set(L.map(t => String(t.key)).filter(Boolean));
  const keySel = (t, i) => `<select data-tkey="${i}" title="この道具の近道">${['', ...'123456789'].map(k => `<option value="${k}"${String(t.key) === k ? ' selected' : ''}${k && used.has(k) && String(t.key) !== k ? ' disabled' : ''}>${k ? 'Alt+' + k : '近道なし'}</option>`).join('')}</select>`;
  const rec = st.rec ? `<div class="hvact rec"><b>記録中</b>（<span id="recN">${st.rec.length}</span> 手）<button type="button" class="pri" data-tact="recStop">記録を止める</button></div>` : `<div class="hvact"><button type="button" data-tact="recStart" title="押したコマンドと、引き出しから入れた記号・断片を順に覚える">記録を始める</button><button type="button" data-tact="new" title="空の道具を作って、コマンドを名前で選んで足す">空の道具</button></div>`;
  const list = L.map((t, i) => { const open = st.toolOpen === i; return `<div class="li tl${open ? ' on' : ''}" data-topen="${i}"><span class="t"><b>${esc(t.name)}</b>${t.key ? `　<span class="d">Alt+${esc(t.key)}</span>` : ''}<br><span class="d">${esc(t.steps.map(stepLabel).join(' → ').slice(0, 80))}</span></span><button type="button" data-trun="${i}" title="使う">▶</button></div>`
    + (open ? `<div class="tled"><div class="hvact"><input class="sb-input" data-tname="${i}" value="${esc(t.name)}" maxlength="20">${keySel(t, i)}</div>${t.steps.map((s, k) => `<div class="li tst"><span class="t">${k + 1}　${esc(stepLabel(s))}</span><button type="button" data-tup="${i}:${k}" title="上へ">↑</button><button type="button" data-tdel="${i}:${k}" title="この手を外す">×</button></div>`).join('')}
      <div class="hvact"><input class="sb-input" data-tq="${i}" placeholder="足すコマンドを名前で（例：太字・合計・中央）" list="toolCmds"><button type="button" data-tadd="${i}">足す</button></div><div class="hvact"><button type="button" data-tdrop="${i}">この道具を消す</button></div></div>` : ''); }).join('');
  const dl = `<datalist id="toolCmds">${CMDS.filter(c => !REC_SKIP.has(c.id) && !/^(fg|tv):/.test(c.id)).map(c => `<option value="${esc(c.label.replace(/（.*$/, ''))}">`).join('')}</datalist>`;
  return rec + (L.length ? list : '<div class="side-empty">道具はまだありません。「記録を始める」で、よくする操作の並びを覚えさせる。1 つのコマンドだけの道具に Alt+数字を付ければ、そのコマンドの近道になる。</div>') + dl + '<div class="side-empty hint">欄の開くコマンドは、欄を開いたところで止まる。打った字は記録しない（字は「空の道具」で足すか、断片に）。道具はこの PC に覚え、設定の書き出しに入る</div>'; }
async function toolsClick(t) { const L = toolsGet(); const ix = v => String(v).split(':').map(Number);
  const a = t.closest('[data-tact]'); if (a) { const v = a.dataset.tact; if (v === 'recStart') recStart(); else if (v === 'recStop') recStop(); else if (v === 'new') { L.push({ name: '道具 ' + (L.length + 1), key: '', steps: [] }); toolsPut(L); st.toolOpen = L.length - 1; drawSide(); } return true; }
  const r = t.closest('[data-trun]'); if (r) { toolRun(L[+r.dataset.trun]); return true; }
  const up = t.closest('[data-tup]'); if (up) { const [i, k] = ix(up.dataset.tup); if (k > 0) { const S = L[i].steps; [S[k - 1], S[k]] = [S[k], S[k - 1]]; toolsPut(L); drawSide(); } return true; }
  const dl = t.closest('[data-tdel]'); if (dl) { const [i, k] = ix(dl.dataset.tdel); L[i].steps.splice(k, 1); toolsPut(L); drawSide(); return true; }
  const ad = t.closest('[data-tadd]'); if (ad) { const i = +ad.dataset.tadd; const inp = $('sideBody').querySelector(`[data-tq="${i}"]`); const q = ((inp && inp.value) || '').trim(); if (!q) return true; const c = CMDS.find(c => c.label.replace(/（.*$/, '') === q) || CMDS.find(c => !REC_SKIP.has(c.id) && (c.label + ' ' + (c.kw || '')).includes(q));
    if (c) { L[i].steps.push({ cmd: c.id }); msg(`「${shortOf(c)}」を足しました`); } else { L[i].steps.push({ text: q }); msg('コマンドが見つからないので、字として足しました（入れる字）'); } toolsPut(L); drawSide(); return true; }
  const dr = t.closest('[data-tdrop]'); if (dr) { L.splice(+dr.dataset.tdrop, 1); toolsPut(L); st.toolOpen = null; drawSide(); return true; }
  const op = t.closest('[data-topen]'); if (op && !t.closest('input,select,button')) { const i = +op.dataset.topen; st.toolOpen = st.toolOpen === i ? null : i; drawSide(); return true; }
  return false; }
function toolsWire() { const B = $('sideBody'); B.querySelectorAll('[data-tname]').forEach(el => el.addEventListener('change', () => { const L = toolsGet(); const i = +el.dataset.tname; if (L[i]) { L[i].name = el.value.trim() || L[i].name; toolsPut(L); } }));
  B.querySelectorAll('[data-tkey]').forEach(el => el.addEventListener('change', () => { const L = toolsGet(); const i = +el.dataset.tkey; if (L[i]) { L[i].key = el.value; toolsPut(L); drawSide(); msg(el.value ? `Alt+${el.value} で「${L[i].name}」` : '近道を外しました'); } }));
  B.querySelectorAll('[data-tq]').forEach(el => el.addEventListener('keydown', e => { if (e.key === 'Enter' && !imeKey(e)) { e.preventDefault(); const b = B.querySelector(`[data-tadd="${el.dataset.tq}"]`); if (b) b.click(); } })); }
/* ---------- 1.0.15f（C-13）はじめの一枚：10 分で 1 枚の文書を書き上げる練習。手順は付箋に（上から順に） ---------- */
function practiceDoc() { const src = ['#fzk 2', '---', '[表題]〇〇の検討状況について（報告）', '[右]令和〇年〇月〇日', '[右]〇〇課', '[番号1]背景', '（なぜ検討しているかを 2〜3 行で）', '[番号1]現状', '[項目1]（分かっていることを 3 つまで）', '[項目1]（　）', '[項目1]（　）',
    '[番号1]費用', '#表 列 0,14,24,34 様式 格子 見出し淡', '| 項目 | 予算 | 見込み |', '| （人件費） | 0 | 0 |', '| （物件費） | 0 | 0 |', '[番号1]今後の対応', '[項目1]（いつまでに、何をするか）', '[右]以上', ''].join('\n');
  const d = FZ.parse(src); const now = new Date().toISOString().slice(0, 16).replace('T', ' '); const notes = []; let k = 0;
  const put = (match, text) => { const i = d.lines.findIndex(l => l.segs.map(x => x.text).join('').includes(match)); if (i < 0) return; const id = 'p' + (++k); notes.push({ id, author: '文机', date: now, done: false, quote: '', text, replies: [] }); (d.lines[i].attrs.notes = d.lines[i].attrs.notes || []).push(id); };
  put('〇〇の検討状況', `10 分で 1 枚を書き上げる練習です。付箋（右の余白の番号）を上から順に。\n① 題名：「〇〇」を選んで打ち直す。日付・課の行は右揃え（${K('alignR')}）。`);
  put('なぜ検討して', `② 見出しと本文：見出しは ${K('styleNum')} で番号が付く。Tab で深く・Shift+Tab で浅く。（ ）の手引きを消して、自分の文に。決まり文句は ${K('snippets')}。`);
  put('分かっていること', '③ 箇条書き：Enter で次の項目、Tab で子の項目。要らない項目は行ごと消す（行頭で Backspace）。');
  put('人件費', `④ 表：数を入れたら ${K('tblSum')} で合計の行。表を直すたびに計算し直す。${K('tblNumRight')} で数の列を右揃えに。`);
  put('いつまでに', `⑤ 仕上げ：${K('health')} で健康診断（直す所を直す）。Ctrl+P で刷る（付箋は刷られない）。終わったら ${K('noteList')} → 解決済みを消す。\n次からは ${K('skeleton')} で、報告書・企画書などの骨組みから始められる。`);
  d.notes = notes; return d; }
function practiceStart() { withDiscard(async () => { await loadText(FZ.serialize(practiceDoc()), 'はじめの一枚.fzk', null); ed.dirty = true; status(); msg('はじめの一枚：付箋の手順を上から順に（右の余白の番号を押すと読める）', false, 10000); }); }
/* ================= 右パネル ================= */
function toggleSide(name) { if (st.side === name) { closeSide(); return; } st.side = name; sideEl.hidden = false; sideEl.classList.toggle('wide', name === 'help' || name === 'src'); drawSide(); drawFkeys(); geomDirty = true; requestRender(); }
function closeSide() { st.side = null; st.histSel = null; sideEl.hidden = true; st.formFocus = false; drawFkeys(); geomDirty = true; requestRender(); focusTA(); }
async function drawSide() {
  const body = $('sideBody'); const titles = { help: 'ガイド', palette: 'コマンド一覧', hist: '版の履歴', notes: '付箋', conv: '変換の記録', health: '文書の健康診断', find: '検索の一覧', drawer: '引き出し', src: '原本の面', request: 'AI に頼む' }; $('sideTitle').textContent = titles[st.side] || '';
  if (st.side === 'health') { body.innerHTML = healthHtml(); healthWire(); return; }
  if (st.side === 'request') { const h = await rqHtml(); if (st.side !== 'request') return; body.innerHTML = h; rqWire(); return; } /* 1.0.16b */
  if (st.side === 'find') { body.innerHTML = findHtml(); return; }
  if (st.side === 'src') { body.innerHTML = srcHtml(); srcWire(); srcState = null; srcLoad(true); return; }
  if (st.side === 'drawer') { const h = await drawerHtml(); if (st.side !== 'drawer') return; body.innerHTML = h; drawerWire(); return; }
  if (st.side === 'conv') { const C = st.convLog; if (!C) { body.innerHTML = '<div class="side-empty">まだ記録がありません。書き出す・取り込む・AI に写すと、近似になった所・入らなかった所がここに出ます。</div>'; return; }
    const pageOf = L => { const lm = ed.lay.lineMap[L]; return lm && lm.rows[0] ? (lm.rows[0].page + 1) + ' 頁' : ''; };
    body.innerHTML = `<div class="hvhead"><b>${esc(C.title)}</b>${C.file ? '　' + esc(C.file) : ''}<br><span class="d">${esc(histTime(C.time))}。行を選ぶとその位置へ。ここに無いものはそのまま写っています</span></div>`
      + (C.items.length ? C.items.map((it, k) => { const L = (it.objs || []).map(o => ed.doc.lines.indexOf(o)).filter(i => i >= 0);
        return `<div class="cvw"><b>${esc(it.what)}</b>${it.lines.length ? `（${it.lines.length} か所）` : '（文書全体）'}</div>` + L.slice(0, 30).map(i => `<div class="li cv" data-cvl="${i}"><span class="t">${esc(lineText(i, 22) || '（空行）')}<span class="d">　${pageOf(i)}</span></span></div>`).join('') + (L.length > 30 ? `<div class="side-empty">ほか ${L.length - 30} か所</div>` : ''); }).join('')
        : '<div class="side-empty">近似になる所・入らない所はありませんでした。</div>'); return; }
  if (st.side === 'hist') { if (!hasHist(st.file)) { body.innerHTML = '<div class="side-empty">保存先のある文書だけ、版を残します。いったん保存すると、それから先の版が残ります。</div>'; return; } const arr = await histList(); if (st.side !== 'hist') return;
    const sel = st.histSel != null && arr[st.histSel] ? st.histSel : null;
    if (sel != null) { const v = arr[sel]; const D = histDiff(v.text); const CAT = { body: '本文', struct: '構造', link: 'リンク・参照', emph: '強調' };
      const secs = D ? D.secs.slice(0, 12).map(([nm, e]) => `<div class="li hvs"><span class="t">${esc(nm)}<br><span class="d">${[['chg', '直す'], ['add', 'この版にだけある'], ['del', '今の版にだけある']].filter(([k]) => e[k]).map(([k, t]) => t + ' ' + e[k]).join('・')}</span></span></div>`).join('') + (D.secs.length > 12 ? `<div class="side-empty">ほか ${D.secs.length - 12} 節</div>` : '') : '';
      const cats = D ? Object.entries(D.cats).filter(([, n]) => n).map(([c, n]) => CAT[c] + ' ' + n).join('・') : '';
      body.innerHTML = `<div class="hvhead"><b>${sel + 1}</b>　${esc(histTime(v.time))}　${esc(v.kind)}${v.label ? `　<b>「${esc(v.label)}」</b>` : ''}<br><span class="d">${v.text.length.toLocaleString()} 字。この欄で見ているだけでは、今の文書は変わりません</span></div>`
        + (D ? (D.n ? `<div class="side-empty hint">今の版との違い ${D.n} か所（${cats}）。違う節：</div>${secs}` : '<div class="side-empty">今の版と同じ中身です。</div>') : '<div class="side-empty">この版は読めません。</div>')
        + `<div class="hvact"><button type="button" class="pri" data-hact="restore">この版を戻す</button><button type="button" data-hact="pick" title="違いを 1 つずつ見て、戻す所だけ選ぶ（Ctrl+Z で戻せる）">節ごとに選んで戻す</button><button type="button" data-hact="back">一覧へ</button></div>`
        + `<div class="hvact"><input class="sb-input" data-hname placeholder="版の名前（例：提出前）" value="${esc(v.label || '')}" maxlength="20"><button type="button" data-hact="name">名前を付ける</button></div>`
        + '<div class="side-empty hint">戻すと、戻す前の今の版を履歴の 1 番目に残します（未保存の変更も）。名前を付けた版は、数の上限（10 版）で消えません</div>'; return; }
    body.innerHTML = (arr.length ? arr.map((v, i) => { const t = (v.text.split('\n---\n')[1] || '').split('\n').find(l => l.trim()) || ''; return `<div class="li hv" data-hist="${i}"><span class="t"><b>${i + 1}</b>　${esc(histTime(v.time))}　${esc(v.kind)}${v.label ? `　<b>「${esc(v.label)}」</b>` : ''}<br><span class="d">${esc(t.replace(/^\[[^\]]*\]/, '').slice(0, 30))}　${v.text.length.toLocaleString()} 字</span></span></div>`; }).join('') : '<div class="side-empty">まだ版がありません。</div>') + '<div class="side-empty hint">選ぶとその版の中身と今の版との違いを見る（今の文書は変わらない）。戻すのはその中の「この版を戻す」。ファイルごとに直近 10 版</div>'; return; }
  if (false) { const items = ed.outline(); const cur = ed.caret.line; let here = -1; items.forEach((it, k) => { const [a, b] = ed.sectionRange(it.line); if (cur >= a && cur <= b) here = k; }); body.innerHTML = (items.length ? items.map((it, k) => { const [a, b] = ed.sectionRange(it.line); const inCur = cur >= a && cur <= b; return `<div class="li lv${it.level}${inCur ? ' cur' : ''}${k === here ? ' here' : ''}" data-line="${it.line}" style="padding-left:${8 + Math.min(it.depth, 12) * 10}px"><span class="t">${esc(it.text) || '（空）'}</span><button class="b" data-act="up" title="上へ">▲</button><button class="b" data-act="down" title="下へ">▼</button><button class="b" data-act="out" title="レベル上げ">◀</button><button class="b" data-act="in" title="レベル下げ">▶</button></div>`; }).join('') : '<div class="side-empty">見出しや箇条書きの行がここに並びます。</div>') + '<div class="side-empty hint">▲▼ 節ごと移動（Alt+↑↓）　◀▶ レベル</div>'; return; }
  if (st.side === 'help') { body.innerHTML = hereHtml() + FZ.help.toHtml(helpCtx()); return; }
  if (st.side === 'notes') { const list = notesInOrder(); const shown = list.filter(x => !st.noteOnlyOpen || !x.n.done);
    body.innerHTML = `<div class="nlhead"><label>名前 <input class="sb-input nme" id="noteMe" value="${esc(noteAuthor())}"></label><label><input type="checkbox" id="noteOnly"${st.noteOnlyOpen ? ' checked' : ''}> 未解決だけ</label>${list.some(x => x.n.done) ? '<button class="sb-btn" id="noteClear" title="解決した付箋をまとめて消す（Ctrl+Z で戻る）">解決済みを消す</button>' : ''}</div>` + (shown.length ? shown.map(({ n, i, k }) => `<div class="li nli${n.done ? ' done' : ''}${st.noteOpen === n.id ? ' cur' : ''}" data-note="${n.id}"><span class="t"><b>${k + 1}</b>${n.done ? '<span class="nd">済</span>' : ''} ${esc(n.author || '')} <span class="d">${esc(noteDate(n.date))}</span><br>${n.quote ? '<span class="q">「' + esc(n.quote.slice(0, 24)) + '」</span> ' : ''}${esc((n.text || '（本文なし）').split('\n')[0].slice(0, 60))}${n.replies.length ? ' <span class="d">返信 ' + n.replies.length + '</span>' : ''}</span></div>`).join('') : '<div class="side-empty">付箋はありません。範囲を選んで ' + esc(K('noteAdd')) + ' で付けます。</div>');
    const me = $('noteMe'); me.addEventListener('change', () => { try { localStorage.setItem('fz.noteAuthor', me.value.trim()); } catch (e) { } }); const only = $('noteOnly'); only.addEventListener('change', () => { st.noteOnlyOpen = only.checked; drawSide(); }); const cl = $('noteClear'); if (cl) cl.addEventListener('click', () => noteClearDone()); return; }
  if (st.side === 'palette') { body.innerHTML = `<input class="sb-input" id="palInput" placeholder="コマンドを検索（例：中央、表、印刷）"><div id="palList"></div>`; const inpEl = $('palInput'); palFilter(''); inpEl.addEventListener('input', () => palFilter(inpEl.value)); inpEl.addEventListener('keydown', e => { if (imeKey(e)) return; if (e.key === 'ArrowDown') { palSel = Math.min(palItems.length - 1, palSel + 1); drawPal(); e.preventDefault(); } else if (e.key === 'ArrowUp') { palSel = Math.max(0, palSel - 1); drawPal(); e.preventDefault(); } else if (e.key === 'Enter') { e.preventDefault(); const c = palItems[palSel]; closeSide(); if (c) run(c.id); } else if (e.key === 'Escape') { e.preventDefault(); closeSide(); } }); st.formFocus = true; inpEl.focus(); return; }
}
let palSel = 0, palItems = [];
function palFilter(q) { q = q.trim().toLowerCase(); palItems = CMDS.filter(c => !q || (c.label + ' ' + c.group + ' ' + c.kw + ' ' + keysOf(c)).toLowerCase().includes(q)); palSel = 0; drawPal(); }
function drawPal() { const el = $('palList'); if (!el) return; el.innerHTML = palItems.map((c, i) => `<div class="li${i === palSel ? ' cur' : ''}" data-i="${i}"><span class="t"><span class="g">${c.group}</span>${esc(c.label)}</span><span class="k">${esc(keysOf(c))}</span></div>`).join('') || '<div class="side-empty">該当なし</div>'; const cur = el.querySelector('.cur'); if (cur) cur.scrollIntoView({ block: 'nearest' }); }
$('sideBody').addEventListener('pointerdown', e => { if (e.target.closest('input,label,textarea,select')) return; e.preventDefault(); });
$('sideBody').addEventListener('click', e => {
  if (st.side === 'health' && healthClick(e)) return; /* 1.0.15b */
  if (st.side === 'find' && findClick(e)) return; /* 1.0.15d */
  if (st.side === 'drawer') { drawerClick(e); return; }
  if (st.side === 'request') { rqClick(e); return; } /* 1.0.16b */
  const sa = e.target.closest('[data-srcact]'); if (sa) { if (sa.dataset.srcact === 'apply') srcApply(); else srcLoad(true); return; }
  const ms = e.target.closest('[data-act="manualSec"]'); if (ms) { openManual(ms.dataset.sec); return; }
  const go = e.target.closest('[data-go]'); if (go) { const t = document.getElementById(go.dataset.go); if (t) t.scrollIntoView({ block: 'start' }); return; } // 取説の目次
  if (e.target.closest('[data-act="manual"]')) { openManual(); return; }
  const ha = e.target.closest('[data-hact]'); if (ha && st.side === 'hist') { const i = st.histSel; if (ha.dataset.hact === 'back') { st.histSel = null; drawSide(); } else if (ha.dataset.hact === 'restore') histRestore(i, true); else if (ha.dataset.hact === 'pick') histPick(i); else if (ha.dataset.hact === 'name') { const inp = $('sideBody').querySelector('[data-hname]'); histName(i, inp ? inp.value : ''); } return; }
  const li = e.target.closest('.li'); if (!li) return;
  if (false) { const i = +li.dataset.line; const act = e.target.dataset.act; if (act === 'up') ed.moveSection(i, -1); else if (act === 'down') ed.moveSection(i, 1); else if (act === 'out') ed.changeLevel(i, -1); else if (act === 'in') ed.changeLevel(i, 1); else { ed.setCaret({ line: i, seg: 0, off: 0 }); scrollToCaret(); } focusTA(); return; }
  if (st.side === 'palette') { const c = palItems[+li.dataset.i]; closeSide(); if (c) run(c.id); return; }
  if (st.side === 'hist' && li.dataset.hist != null) { histView(+li.dataset.hist); return; }
  if (st.side === 'notes' && li.dataset.note) { noteGo(li.dataset.note); return; }
  if (st.side === 'conv' && li.dataset.cvl != null) { const L = +li.dataset.cvl; if (st.mode !== 'text') exitMode(); ed.anchor = null; ed.caret = { line: L, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); render(); scrollToCaret(true); return; }
});
/* 取説の中身は fz-help.js（右の欄と取扱説明書.fzk を同じ中身から作る）。ここはキーの引き方と、全キーの一覧を渡す */
function helpIndex() {
  const ORDER = ['説明', 'ファイル', '編集', '構造', '文字', '配置', '挿入', '罫線・飾り', '見出し飾り', '表の様式', '書式', '表示', 'アウトライン', '図', '網掛け（範囲）'];
  const groups = {}; for (const g of ORDER) groups[g] = []; for (const c of CMDS) { const k = keysOf(c); if (!k) continue; (groups[c.group] = groups[c.group] || []).push(c); }
  const out = Object.entries(groups).filter(([, cs]) => cs.length).map(([g, cs]) => ({ group: g, rows: cs.map(c => [keysOf(c), c.label]) }));
  return out;
}
function helpCtx() { return { K: id => K(id) || '（キーなし）', A: id => { const c = cmdById(id); return (c && keysOf(c)) || '（キーなし）'; }, version: FZ.VERSION, index: helpIndex(), env: `ファイルの扱い：${FZ.files.kind}　／　${navigator.userAgent.replace(/^.*\) /, '')}` }; }
FZ.manualText = () => FZ.MANUAL_FZK || FZ.help.toFzk(helpCtx()); // 取扱説明書（tools/build-kaisetsu.js が作る js/fz-manual.js。無ければガイドの中身）
FZ.guideText = () => FZ.help.toFzk(helpCtx()); // ガイド（F1 の右の欄）の中身を原本にしたもの（試験が中身の載り漏れを見る）
/* 取扱説明書を開く：別の窓で（今の文書はそのまま）。窓を開けなければ、この窓で（未保存なら確かめる） */
function openManual(sec) { if (typeof sec !== 'string') sec = ''; if (st.side === 'help') closeSide(); if (liveWindows() < MAX_WINDOWS) { let free = 0; for (let n = 1; n <= MAX_WINDOWS && !free; n++) if (!slotAlive(n) && n !== st.slot) free = n; const url = location.href.split('?')[0].split('#')[0] + '?w=' + free + '&open=manual' + (sec ? '&sec=' + encodeURIComponent(sec) : ''); let w = null; try { w = window.open(url, '_blank', 'popup,width=1180,height=900'); } catch { } if (w) return; }
  withDiscard(() => loadManualHere(sec)); }
async function loadManualHere(sec) { await loadText(FZ.manualText(), '取扱説明書.fzk', null); ed.dirty = false; status(); msg('取扱説明書を開きました（文書なので、そのまま編集・印刷できます）'); if (sec) manualJump(sec); }
/* ================= 状態行 ================= */
/* 案内（専用機のガイダンス行）：今の状態で次に押せるキー */
function updateGuide() { const gd = $('stGuide'); if (!gd) return; const g = guideText(); if (gd.innerHTML !== g) gd.innerHTML = g; gd.classList.toggle('arm', !!st.armed && st.mode === 'text' && !st.form); } // 知らせ（msg）と並べて出す。狭いときは案内の方が先に縮む
/* P09：帯の欄の案内（状態行の右）。欄ごとに Enter・Esc が実際に何をするかを出す（いつも「Esc 取消」ではない）。
   既定（確定型）：Enter で確定、Esc で取消（何も変えない）。
   preview（仮表示型。図表の設定・区画）：変更はその場で紙面に仮に出し、Enter で確定、Esc で開く前に戻す。確定した変更は 1 回の Ctrl+Z で戻る。
   live（反映型。グラフ・工程表・番号の形）：押した変更はすぐ反映、Esc は閉じるだけ。この欄での変更は 1 回の Ctrl+Z でまとめて戻る（保留の島は 1 つずつ） */
const FORM_GUIDE = {
  find: [['Enter', '次を探す'], ['Shift+Enter', '前へ'], ['Esc', '閉じる']], replace: [['Enter', '次を探す'], ['Shift+Enter', '前へ'], ['Esc', '閉じる']],
  tfind: [['Enter', '次'], ['Shift+Enter', '前'], ['Esc', '閉じる']], scheck: [['Enter', '次の指摘'], ['Shift+Enter', '前の指摘'], ['Esc', '閉じる']],
  count: [['Esc', '閉じる']], conflict: [['A', '別名で保存'], ['O', '上書き'], ['Esc', '取消（保存しない）']],
  ask: () => [['S', '保存して' + askVerb], ['D', '保存せずに' + askVerb], ['Esc', '取消']],
  newdoc: [['1〜9・S', '選ぶ'], ['Esc', '取消']], figtree: [['1・2', '向きを選ぶ'], ['Esc', '取消']], figref: [['1〜9', '選ぶ'], ['Esc', '取消']], skeleton: [['1〜9', '型を選ぶ'], ['Esc', '取消']],
  moveTo: [['↑↓', '選ぶ'], ['Enter', '決める'], ['Esc', '取消（何も変えない）']], secref: [['↑↓', '選ぶ'], ['Enter', '入れる'], ['Esc', '取消（何も変えない）']],
  shadeType: [['字', '文様を選ぶ'], ['Esc', '取消']],
  aiback: () => st.aiBack ? [['Enter', '取り込む'], ['Delete', '捨てる'], ['↑↓', '前・次'], ['Ctrl+Z', '取り込みを戻す'], ['Esc', '閉じる']] : [['Ctrl+Enter', '比べる'], ['Esc', '閉じる']],
  marker: [['1〜9', '形を選ぶ（すぐ反映）'], ['Esc', '閉じる'], ['Ctrl+Z', 'まとめて戻す']], parked: [['1〜9', '戻す（すぐ反映）'], ['Esc', '閉じる'], ['Ctrl+Z', '1 つずつ戻す']], fit: [['目標・最小の字', '直すと組み直して確かめる'], ['案', '押すと試す（Ctrl+Z で戻る）'], ['Esc', '閉じる']], why: [['ボタン', 'この行だけ外す・設定を見る'], ['Esc', '閉じる']],
  gantt: [['Enter', '確定'], ['Esc', '閉じる（＋−・行・列の変更は反映済み）'], ['Ctrl+Z', 'まとめて戻す']],
};
function formGuide(name) { const F = FORMS[name] || {}; const G = FORM_GUIDE[name]; if (G) return typeof G === 'function' ? G() : G;
  if (F.preview) return [['仮表示中', ''], ['Enter', '確定'], ['Esc', '元に戻す']];
  if (F.live) return [['変更は反映済み', ''], ['Esc', '閉じる'], ['Ctrl+Z', 'まとめて戻す']];
  return [['Enter', '確定'], ['Esc', '取消（何も変えない）'], ['Tab', '次の欄']]; }
FZ.formGuide = formGuide;
/* 仮表示型・反映型の欄：開いた時の取消の位置を覚え、閉じる時にこの欄での変更を取消 1 回分にまとめる（Esc の仮表示型は開く前に戻す） */
function formSessionStart(name) { const F = FORMS[name]; if (!F || !(F.preview || F.live)) return; const U = ed.undoStack; st.formSession = { name, top: U[U.length - 1] || null, n: U.length }; }
function formSessionEnd(revert) { const S = st.formSession; st.formSession = null; if (!S) return 0; const U = ed.undoStack; const k = S.top ? U.lastIndexOf(S.top) + 1 : (S.n === 0 ? 0 : -1); if (k <= 0 && S.top) return 0; if (k < 0 || k >= U.length) return 0;
  const n = U.length - k; U.splice(k + 1); ed.breakUndo(); if (revert) { ed.undo(); if (st.mode === 'tree') treeRefresh(); render(); } return n; }
function cancelForm() { if (!st.form) return; const F = FORMS[st.form]; const rv = !!(F && F.preview && st.formSession && st.formSession.name === st.form); const n = rv ? formSessionEnd(true) : 0; closeForm(); if (n) msg(`この欄での変更（${n} 回）を元に戻しました（${K('redo')} でやり直す）`); }
function guideText() {
  const g = (...p) => p.map(([k, t]) => `<b>${esc(k)}</b>${t ? ' ' + esc(t) : ''}`).join('　');
  if (st.rec) return `<b>記録中</b> ${st.rec.length} 手　<b>道具</b> 記録を止める`; /* 1.0.15f */
  if (st.form) return g(...formGuide(st.form));
  if (st.tprev) return `<b>対象</b> ${esc(st.tprev.text)}`; /* P07：操作の対象を先に */
  if (st.bandKb) return g(['←→↑↓', '選ぶ'], ['Enter・Space', '実行'], ['Esc', '本文へ']);
  if (st.fkPrev && (st.mode === 'text' || st.mode === 'tree')) return g([st.fkPrev + ' もう一度', '帯の項目をキーで選ぶ']);
  if (st.mode === 'rule') return g(['矢印', '引く'], ['Shift+矢印', '動く'], ['Esc', '本文へ']);
  if (st.mode === 'fill') return g(['矢印', '範囲'], ['Enter', '掛ける'], ['Esc', '本文へ']);
  if (st.mode === 'tree') return g(['矢印', '移る'], ['Enter／Tab', '弟／子を足す'], ['ドラッグ', '動かす'], ['Esc', '紙面へ']);
  if (st.mode === 'fig') return st.fig && st.fig.connecting ? g(['クリック', '矢印の先の箱'], ['Esc', 'やめる']) : g(['ダブルクリック', '箱を足す・文字'], ['ドラッグ', '動かす'], ['辺の点', 'つなぐ'], ['Esc', '本文へ']);
  if (st.side === 'palette') return g(['↑↓', '選ぶ'], ['Enter', '実行'], ['Esc', '閉じる']);
  const a = ed.line().attrs;
  if (st.cells) return g(['Delete', '中身を消す'], ['右クリック', '網・揃え'], ['Ctrl+C', '写す'], ['Esc', 'やめる']);
  if (ed.sel()) return g(['F5・右クリック', '字の飾り'], ['Ctrl+Alt+M', '付箋'], ['Ctrl+C', '写す']);
  if (a.cells && FZ.inTable(ed.doc, ed.caret.line)) return g(['Tab', '次のセル'], ['Shift+Enter', 'セルの中で改行'], ['右クリック', '行・列・網'], ['罫をドラッグ', '列の幅']);
  if (a.figure) return g(['クリック・Enter', '図を描く'], ['Backspace', '図を消す']);
  if (a.toc) return g(['Enter', '範囲を変える'], ['Backspace', '目次を消す']);
  if (a.list || a.style === 'num' || a.style === 'sym') return g(['Tab', '深く'], ['Shift+Tab', '浅く'], ['Shift+Enter', '項目の中で改行']);
  return g(['F1', 'ガイド'], ['F2〜F10', 'メニュー'], ['Shift+Enter', '段落の中で改行']);
}
const MARK_LABEL = [[M.SHADOW, '影'], [M.BOLD, '太'], [M.UNDER, '下'], [M.UNDER2, '二重下'], [M.WAVE, '波'], [M.DOT, '点'], [M.SHADE, '網'], [M.CODE, 'コード'], [M.OUTLINE, '白'], [M.STRIKE, '消'], [M.STRIKE2, '二重消'], [M.WIDE, '横倍'], [M.TALL, '縦倍']];
function status() {
  syncKind(); syncView(); updateFwGuide();
  const name = (st.file && st.file.name) || (ed.doc.title ? ed.doc.title + '.fzk' : '無題'); $('stFile').innerHTML = `${esc(name)}${ed.dirty ? ' <span class="dirty">●</span>' : ''}${st.trial ? ` <b class="trialtag" title="構成を試している（${K('trial')}）">［${st.trial.view === 'orig' ? '元の案' : '試案'}］</b>` : ''}`;
  const title = `${ed.dirty ? '● ' : ''}${name} — 文机${st.slot > 1 ? ' ' + st.slot : ''}`; if (document.title !== title) { document.title = title; if (typeof globalThis.fzSetTitle === 'function') { try { globalThis.fzSetTitle(title); } catch { } } }
  if (st.mode === 'text') { const xy = ed.xy(); $('stPos').textContent = xy ? (xy.y < 0 ? `柱 ${fmtCol(xy.col + 1)} 桁` : `${xy.y + 1} 行 ${fmtCol(xy.col + 1)} 桁`) : ''; $('stPage').textContent = xy ? `${xy.page + 1} / ${ed.lay.pages.length}${ed.layoutDone ? '' : '+'} 頁` : ''; }
  else if (st.mode === 'tree') { const n = treeNodeSel(); const KN = { root: '根', title: '表題', num: '数字見出し', sym: '記号見出し', list: '箇条書き', body: '本文', block: '表・図' }; const dn = n ? treeDesc(n) : 0; $('stPos').textContent = n ? `${KN[n.kind] || ''}${n.kind === 'num' || n.kind === 'sym' || n.kind === 'list' ? n.level + 1 : ''}　子 ${n.children.length}${dn > n.children.length ? '・子孫 ' + dn : ''}` : ''; $('stPage').textContent = st.tree.view ? `節 ${st.tree.view.tr.nodes.length}` : ''; }
  else if (st.mode === 'fig') { const fi = figInfo(); const n = figIds().length; const b = fi && n === 1 ? FZ.figureBox(fi.F, figIds()[0]) : null; $('stPos').textContent = b ? `箱${b.id} (${b.x},${b.y}) ${b.w}×${b.h}` : n > 1 ? `箱 ${n} 個` : fi ? `図 高さ${fi.F.h}` : ''; $('stPage').textContent = fi ? `${fi.page + 1} / ${ed.lay.pages.length} 頁` : ''; }
  else { $('stPos').textContent = `交点 ${st.rc.y} , ${st.rc.col}`; $('stPage').textContent = `${st.rc.page + 1} / ${ed.lay.pages.length} 頁`; }
  { const s = st.mode === 'text' ? ed.sel() : null; let sc = ''; if (s) { let k = 0; for (const ch of ed.textOf(s)) if (!/[\s\u3000]/.test(ch)) k++; sc = '選択 ' + k.toLocaleString() + '／'; } $('stChars').textContent = sc + ed.charCount().toLocaleString() + ' 字'; } // 選んでいれば選択の字数も（空白を除く）
  const modeEl = $('stMode'); modeEl.className = 'st mode' + (st.mode !== 'text' ? ' rule' : '');
  modeEl.textContent = st.mode === 'text' ? '本文' : st.mode === 'tree' ? `ツリー（${st.tree.depth > 0 ? st.tree.depth + ' 段' : st.tree.depth === -1 ? '文まで' : '本文まで'}）` : st.mode === 'fig' ? `図（箱${(figInfo() || { F: { boxes: [] } }).F.boxes.length}）` : st.mode === 'fill' ? `網掛け（${st.shade === 'none' ? '消す' : (FZ.SHADE_BY[st.shade] || {}).name || st.shade}）${st.ranchor ? ' 範囲指定中' : ''}` : `罫線（${({ thin: '細', thick: '太', double: '二重', dotted: '点線', arrow: '矢印' })[st.ruleKind]}）${st.sub === 'erase' ? ' 消去' : st.sub === 'rect' ? ' 囲み' : ''}`;
  const a = ed.line().attrs; const sty = (a.style === 'title' && ed.lay.headY != null) ? (ed.caret.line === ed.lay.coverTitle ? '表題（表紙）' : '表題（柱）') : a.hr ? '区切り線' : a.toc ? '目次（Enter で範囲）' : a.figure ? '図（Enter で編集）' : a.cells && FZ.inTable(ed.doc, ed.caret.line) ? (a.sumRow ? '表の合計の行（自動で計算）' : '表（様式は ' + K('tableGroup') + '）') : a.style === 'num' ? `数字見出し${(a.level | 0) + 1}${(a.level | 0) < (ed.doc.format.titleLevels | 0) ? '（題）' : ''}` : a.style === 'sym' ? `記号見出し${(a.level | 0) + 1}` : { title: '表題', speech: '発言録' }[a.style] || '本文';
  let pfr = ''; if (st.mode === 'text' && pufuCtxCached()) { const pz0 = FZ.pufuAt(ed.doc, ed.caret.line), X = pufuCtx(); const sn = k => FZ.pufuShowName(pz0.B, k); pfr = !pz0 ? '' : !pz0.it ? '題' : pz0.it.kind === 'frame' ? sn('取組') + (pz0.it.no || '') : sn(FZ.pufuRoleOf(pz0.B, pz0.it)) + (X && X.frame ? '（' + sn('取組') + (X.frame.no || '') + '）' : ''); } /* 1.0.16g プ譜の役 */
  const lst = a.list ? ' ' + (a.list.kind === 'arrow' ? '→' : a.list.kind === 'todo' ? '❏' : a.list.kind === 'done' ? '☑' : a.list.kind === 'cont' ? '続き' : a.list.kind === 'num' ? '番号付き箇条書き' : '箇条書き') + ((a.list.level | 0) + 1) + (a.list.kind ? '' : ' ' + FZ.normalizeScheme(ed.doc.format.bulletScheme, FZ.DEFAULT_BULLET)[Math.min(7, a.list.level | 0)]) : ''; const al = { center: ' 中央', right: ' 右', justify: ' 均等' }[a.align] || '';
  const pz = a.indent != null && FZ.nodeKind(a) ? ' 位置' + (a.indent | 0) + '固定' : a.indent ? ' 字下げ' + a.indent : ''; const lk = st.mode === 'text' ? FZ.linkAt(ed.seg(), ed.caret.off) : null; $('stStyle').textContent = pfr ? 'プ譜：' + pfr : sty + lst + pz + al + (a.quote ? ' 引用' + (a.quote > 1 ? a.quote : '') : '') + (a.code ? ' コード' : '') + (a.breakBefore ? ' 改頁' : '') + (a.figs ? ' 図表' + a.figs.length : '') + (lk ? ' → ' + lk.url : '');
  $('stMarks').textContent = MARK_LABEL.filter(([b]) => ed.typing & b).map(([, l]) => l).join('') || (ed.doc.format.font === 'gothic' ? 'ゴシック' : ed.doc.format.font === 'system' ? 'システム' : '明朝');
  const m = $('stMsg'); m.textContent = st.msg; m.className = 'st msg' + (st.msgAlert ? ' alert' : '');
  $('stView').textContent = st.mode === 'tree' ? 'ツリー ' + Math.round(st.tree.scale * 100) + '%' : st.zoom === 'width' ? '幅合わせ' : st.zoom === 'page' ? '頁全体' : Math.round(Number(st.zoom) * 100) + '%';
  const hm = t => { const d = new Date(t); return d.getHours() + ':' + String(d.getMinutes()).padStart(2, '0'); };
  const sv = $('stSave'); sv.textContent = saving ? '保存中…' : ed.dirty ? '未保存' : !st.file ? '未保存（新規）' : st.savedAt ? '保存済 ' + hm(st.savedAt) : '保存済';
  updateGuide(); sv.className = 'st' + (ed.dirty ? ' dirty' : ''); if (pufuAutoBand() && !st.form) drawSub(); updateNext(); updateHere(); drawPageMap(); if (st.side === 'src' && document.activeElement !== $('srcTa')) srcLoad();
}
function fmtCol(c) { return Number.isInteger(c) ? String(c) : c.toFixed(1); }
$('stFile').onclick = () => run('open'); $('stView').onclick = () => { if (st.mode === 'tree') { treeZoom(0); return; } openForm('zoom'); };
/* 重い処理の前に「〜中…」を出し、画面に描かせてから始める（固まったように見せない） */
async function busy(text) { msg(text, false, 0); await new Promise(r => requestAnimationFrame(() => setTimeout(r, 0))); }
function msg(text, alert = false, ms = 5000) { st.msg = text; st.msgAlert = alert; status(); clearTimeout(st.msgTimer); if (ms) st.msgTimer = setTimeout(() => { st.msg = ''; status(); }, ms); }
const TREE_SCALES = [0.6, 0.7, 0.8, 0.9, 1, 1.15, 1.3, 1.5, 1.75, 2, 2.5];
/* ツリーの倍率：d = ±1 で 1 段、0 で等倍。選んだ節が見えるところへ */
function treeZoom(d) { const cur = st.tree.scale; let i = TREE_SCALES.findIndex(x => Math.abs(x - cur) < 1e-6); if (i < 0) i = TREE_SCALES.findIndex(x => x > cur); if (i < 0) i = TREE_SCALES.length - 1; st.tree.scale = d === 0 ? 1 : TREE_SCALES[clamp(i + d, 0, TREE_SCALES.length - 1)]; try { localStorage.setItem('fz.treeScale', String(st.tree.scale)); } catch (e) { /* 覚えられなくても動く */ } render(); drawSub(); status(); treeScrollToSel(); }
function zoomStep(d) { if (st.mode === 'tree') { treeZoom(d); return; } pageZoomStep(d); }
function pageZoomStep(d) { const steps = ['page', 'width', 0.75, 1, 1.25, 1.5, 2, 3]; let i = steps.indexOf(st.zoom); if (i < 0) { const z = Number(st.zoom); i = steps.findIndex(x => typeof x === 'number' && x > z); if (i < 0) i = steps.length - 1; if (d > 0) i--; } i = clamp(i + d, 0, steps.length - 1); st.zoom = steps[i]; render(); }
/* ================= 表示モード ================= */
new ResizeObserver(es => { for (const e of es) { if (e.target === main) { mainW = e.contentRect.width; mainH = e.contentRect.height; } } geomDirty = true; requestRender(); }).observe(main);
new ResizeObserver(() => { if (st.view === 'split') { try { localStorage.setItem('fz.treeW', String(Math.round(tpane.offsetWidth))); } catch (e) { /* 覚えられなくても動く */ } } requestRender(); }).observe(tpane);
try { const w = +localStorage.getItem('fz.treeW'); if (w >= 200) document.documentElement.style.setProperty('--tw', w + 'px'); } catch (e) { /* 既定の幅 */ }
/* 並べる：ツリーと紙面の境目をドラッグで動かす（ダブルクリックで半々） */
{ const sp = $('tsplit'); const setW = px => { const max = Math.round(window.innerWidth * 0.8); const w = Math.max(220, Math.min(max, Math.round(px))); document.documentElement.style.setProperty('--tw', w + 'px'); };
  sp.addEventListener('pointerdown', e => { if (e.button !== 0) return; e.preventDefault(); sp.setPointerCapture(e.pointerId); sp.classList.add('drag'); const x0 = e.clientX, w0 = tpane.offsetWidth;
    const mv = ev => setW(w0 + ev.clientX - x0); const up = ev => { sp.releasePointerCapture(ev.pointerId); sp.classList.remove('drag'); sp.removeEventListener('pointermove', mv); sp.removeEventListener('pointerup', up); focusTA(); };
    sp.addEventListener('pointermove', mv); sp.addEventListener('pointerup', up); });
  sp.addEventListener('dblclick', e => { e.preventDefault(); setW((window.innerWidth - ($('side') && $('side').offsetWidth || 0)) / 2); }); }
let scrollTick = false; main.addEventListener('scroll', () => { if (scrollTick) return; scrollTick = true; requestAnimationFrame(() => { scrollTick = false; skipTree = true; try { render(); } finally { skipTree = false; } }); }, { passive: true });
/* ================= ファイル ================= */
/* ================= 既定の書式・テンプレート ================= */
const DEFAULTS_KEY = 'fz.defaults', TEMPLATES_KEY = 'fz.templates';
/* 既定の書式。新しい文書と Markdown の読み込みに使う。構造から引く見た目は既定で入：戻り空き（本文から見出しに戻るとき 1 行）、本文の位置（本文を直前の見出しの文字位置に揃える）。
   保存した既定はそれに従う。ただし 1.0.10a.4 より前に保存した既定は、この 2 つを持っていなかった頃のものなので、新しい既定（入）にする */
function defaultFormat() { let d = null; try { d = JSON.parse(localStorage.getItem(DEFAULTS_KEY) || 'null'); } catch { } const base = FZ.newDoc(); base.format.returnGap = true; base.format.bodyFollow = 'step'; base.format.titleAfter = true; base.format.tableGap = true;
  if (d && typeof d === 'object') { const old = !(d._v >= 2); const dd = { ...d }; delete dd._v; if (old) { delete dd.returnGap; delete dd.bodyFollow; } base.format = FZ.normalize({ ...base, format: { ...base.format, ...dd } }).format; } return base.format; }
function saveDefaults(f) { try { localStorage.setItem(DEFAULTS_KEY, JSON.stringify({ ...f, _v: 2 })); } catch { } }
function templates() { try { const a = JSON.parse(localStorage.getItem(TEMPLATES_KEY) || '[]'); return Array.isArray(a) ? a.filter(t => t && t.name && typeof t.text === 'string') : []; } catch { return []; } }
function saveTemplates(a) { try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(a)); } catch { } }
function blankDoc() { const d = FZ.newDoc(); d.format = JSON.parse(JSON.stringify(defaultFormat())); st.file = null; ed.setDoc(d); clearRecovery(); msg('新しい文書（既定の書式）'); render(); scrollToCaret(); focusTA(); }
function docFromTemplate(t) { let d; try { d = FZ.parse(t.text); } catch (e) { msg('テンプレートを読めません：' + e.message, true); return; } st.file = null; ed.setDoc(d); ed.dirty = false; clearRecovery(); msg('テンプレート「' + t.name + '」から新しい文書'); render(); scrollToCaret(); focusTA(); }
function newDoc() { withDiscard(() => openForm('newdoc')); }
/* 資料書式の新しい文書：A4 横 60 字×26 行、本文欄 60%、柱 2 行（題・機密表示・日付と作成者・頁番号）。1 行目は表題（柱に入る） */
const SLIDE_DEFAULTS_KEY = 'fz.defaults.slide'; /* 資料の既定の版面（文書の既定とは別） */
function slidePageDefault() { try { const d = JSON.parse(localStorage.getItem(SLIDE_DEFAULTS_KEY) || 'null'); return d && typeof d === 'object' ? d : null; } catch { return null; } }
function slideFormat(base) { const f = JSON.parse(JSON.stringify(base || defaultFormat())); delete f.pageAlt; if (!f.returnGap) f.returnGap = true; if (!f.bodyFollow) f.bodyFollow = 'step'; if (f.titleAfter === undefined) f.titleAfter = true; if (f.tableGap === undefined) f.tableGap = true; Object.assign(f, { kind: 'slide', paper: 'A4', widthMm: 297, heightMm: 210, landscape: true, cols: 60, rows: 26, headerRows: 2, footerRows: 0, hfGap: 1, margins: { top: 12, right: 15, bottom: 12, left: 15 }, bodyPct: f.bodyPct || 60 });
  { const sd = slidePageDefault(); if (sd) for (const k of FZ.PAGE_KEYS) if (sd[k] !== undefined) f[k] = JSON.parse(JSON.stringify(sd[k])); } /* 資料の既定（書式の「資料の既定にする」で保存） */
  if (!f.date) { const d = new Date(); f.date = `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`; } return f; }
function slideDoc() { const d = FZ.newDoc(); d.format = slideFormat(); d.lines = [FZ.newLine('', { style: 'title' }), FZ.newLine('')]; st.file = null; ed.setDoc(d); clearRecovery(); msg('新しい資料：1 行目は柱に入る表題。画像は貼り付け・ドラッグ＆ドロップか ' + K('figOpen') + '、図番は ' + K('figRef')); render(); scrollToCaret(); focusTA(); }
FORMS.newdoc = { html() { const ts = templates(); return `<span class="ttl">新しい文書</span><button type="button" class="pri" data-act="blank">1 白紙（既定の書式）</button><button type="button" data-act="slide">S 資料（A4 横）</button>${ts.map((t, i) => `<button type="button" data-act="t${i}">${i < 8 ? (i + 2) + ' ' : ''}${esc(t.name)}</button><button type="button" class="pal" data-act="x${i}" title="このテンプレートを消す">×</button>`).join('')}<button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { const k = e.key; if (k.toLowerCase() === 's') { e.preventDefault(); this.act('slide'); } else if (k === '1') { e.preventDefault(); this.act('blank'); } else if (/^[2-9]$/.test(k)) { e.preventDefault(); this.act('t' + (+k - 2)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a === 'blank') { closeForm(); blankDoc(); return; } if (a === 'slide') { closeForm(); slideDoc(); return; } let m; if ((m = a.match(/^t(\d+)$/))) { const t = templates()[+m[1]]; closeForm(); if (t) docFromTemplate(t); return; } if ((m = a.match(/^x(\d+)$/))) { const ts = templates(); const t = ts[+m[1]]; if (!t) return; ts.splice(+m[1], 1); saveTemplates(ts); msg('テンプレート「' + t.name + '」を消しました'); if (ts.length) drawSub(); else { closeForm(); } } } };
FORMS.tplname = { html() { return `<span class="ttl">テンプレートとして保存</span><label>名前 ${inp('name', ed.doc.title || baseTitle(), 'w')}</label><button type="button" class="pri" data-act="apply">保存 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'input[name="name"]', enter() { this.act('apply'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const name = fval('name').trim(); if (!name) { msg('名前を入れてください', true); return; } const ts = templates().filter(t => t.name !== name); ts.unshift({ name, text: FZ.serialize(ed.doc) }); saveTemplates(ts.slice(0, 30)); closeForm(); msg('テンプレート「' + name + '」を保存（新規 ' + K('new') + ' で選べる）'); } };
/* 設定の書き出し・読み込み：既定の書式・体系プリセット・テンプレート・書体一覧を 1 つの JSON に */
function exportSettings() { const data = { 文机設定: FZ.VERSION, 既定の書式: defaultFormat(), 体系: userSchemes(), 書体の組: userFontProfiles(), テンプレート: templates(), 和文番号を起こす: st.jaLift, 断片: lsJ('fz.snippets', []), 表記の決まり: proofUser, 道具: toolsGet(), ...(stdUser ? { 基準: stdUser } : {}), ...(rqMasks.length ? { 伏せる名前: rqMasks } : {}), '手元の AI': { url: rqLocal.url, model: rqLocal.model, budget: rqLocal.budget }, 送り先: rqOpt.dests }; exportVia('設定', '文机設定.json', () => JSON.stringify(data, null, 1)); }
async function importSettings() { try { const r = await FZ.files.open(); if (!r) return; const data = JSON.parse(r.text); if (!data || !data.文机設定) { msg('文机の設定ファイルではありません', true); return; } if (data.既定の書式) saveDefaults(data.既定の書式); if (Array.isArray(data.体系)) saveUserSchemes(data.体系); if (Array.isArray(data.書体の組)) { const cur = userFontProfiles(); const names = new Set(data.書体の組.map(p => p && p.name)); saveUserFontProfiles([...cur.filter(p => !names.has(p.name)), ...data.書体の組.filter(p => p && p.name)]); } if (Array.isArray(data.テンプレート)) { const cur = templates(); const names = new Set(cur.map(t => t.name)); saveTemplates([...cur, ...data.テンプレート.filter(t => t && t.name && !names.has(t.name))]); } if (Array.isArray(data.断片)) { const cur = lsJ('fz.snippets', []); const have = new Set(cur.map(x => String(x.t || x))); lsW('fz.snippets', cur.concat(data.断片.filter(x => x && (x.t || typeof x === 'string') && !have.has(String(x.t || x))).map(x => ({ t: String(x.t || x) })))); } if (Array.isArray(data.道具)) { const cur = toolsGet(); const names = new Set(cur.map(t => t.name)); const keys = new Set(cur.map(t => String(t.key)).filter(Boolean)); for (const t of data.道具) if (t && t.name && Array.isArray(t.steps) && !names.has(t.name)) cur.push({ name: String(t.name), key: t.key && !keys.has(String(t.key)) ? String(t.key) : '', steps: t.steps.filter(x => x && (typeof x.cmd === 'string' || typeof x.text === 'string')) }); toolsPut(cur); } if (Array.isArray(data.表記の決まり)) { const have = new Set(proofUser.map(x => x.from)); for (const r of data.表記の決まり) if (r && r.from && !have.has(r.from)) proofUser.push({ from: String(r.from), to: String(r.to || '') }); saveProof(); healthCache = null; } if (data['手元の AI'] && typeof data['手元の AI'] === 'object') { const L = data['手元の AI']; if (L.url) rqLocal.url = String(L.url); if (L.model) rqLocal.model = String(L.model); if (+L.budget) rqLocal.budget = +L.budget; rqLocalSave(); } if (data.送り先 && typeof data.送り先 === 'object') { for (const k of Object.keys(RQ_DEST0)) if (data.送り先[k] === 'clip' || data.送り先[k] === 'local') rqOpt.dests[k] = data.送り先[k]; rqSave(); } if (Array.isArray(data.伏せる名前)) { for (const m of data.伏せる名前) if (m && m.from && !rqMasks.some(x => x.from === m.from)) rqMasks.push({ from: String(m.from), to: String(m.to || '上位者'), person: !!m.person }); rqMaskSave(); } if (data.基準 && typeof data.基準 === 'object' && data.基準.name) { stdUser = { ...FZ.STD_DEFAULT, ...data.基準 }; saveReview(); healthCache = null; } if (typeof data.和文番号を起こす === 'boolean') { st.jaLift = data.和文番号を起こす; try { localStorage.setItem('fz.jaLift', st.jaLift ? '1' : '0'); } catch { } } msg('設定を読み込みました（既定の書式・体系・書体の組・テンプレート）'); } catch (e) { msg('読み込めませんでした：' + e.message, true); } }
/* 大きな文書の解析は Worker で（画面を止めない）。file:// では別ファイルの Worker を作れないので、束ねたソース（fz-worker-src.js）から Blob で作る */
const BIG_TEXT = 3000000; /* これより大きい文字列だけ Worker で解析（Worker は往復の複製に時間がかかるので、数 MB までは本スレッドの方が速い。組版は段階的なので画面は止まらない） */ let worker = null, workerSeq = 0; const workerJobs = new Map();
function getWorker() {
  if (worker || !FZ.WORKER_SRC || typeof Worker !== 'function') return worker;
  try { const url = URL.createObjectURL(new Blob([FZ.WORKER_SRC], { type: 'text/javascript' })); worker = new Worker(url); worker.onmessage = e => { const d = e.data; const job = workerJobs.get(d.id); if (!job) return; workerJobs.delete(d.id); if (d.ok) job.res(d.doc); else job.rej(new Error(d.error)); }; worker.onerror = e => { for (const j of workerJobs.values()) j.rej(new Error(e.message || 'worker error')); workerJobs.clear(); }; } catch { worker = null; }
  return worker;
}
function parseText(text, kind, opts, format) { // kind: 'md' | 'fzk' → Promise<doc>。format：貼付のときの文書の書式
  const w = text.length > BIG_TEXT ? getWorker() : null;
  if (!w) return Promise.resolve(kind === 'md' ? FZ.fromMarkdown(text, format ? { ...FZ.newDoc(), format } : null, opts) : FZ.parse(text));
  msg('読み込み中…（' + Math.round(text.length / 1024) + ' KB）', false, 0);
  return new Promise((res, rej) => { const id = ++workerSeq; workerJobs.set(id, { res, rej }); w.postMessage({ id, kind, text, opts, format: format || null }); });
}
async function loadText(text, name, ref, keepDirty) {
  const isMd = /\.(md|markdown)$/i.test(name || '');
  let doc; try { doc = await parseText(text, isMd ? 'md' : 'fzk', {}, isMd ? JSON.parse(JSON.stringify(defaultFormat())) : null); } /* Markdown は既定の書式（本文の位置・戻り空き・体系）で組む */ catch (e) { msg('開けませんでした：' + e.message, true); return; }
  if (!doc.title && name) doc.title = name.replace(/\.[^.]+$/, '');
  try { pufuMigrate(doc); } catch { } /* 1.0.16h */
  if (isMd && !doc.format.header && doc.format.headerRows > 0 && doc.format.kind !== 'slide') doc.format.header = '{file}'; // Markdown を開いたら柱上にファイル名（{file}：保存し直すとその名前に。既定の書式で柱上を決めていればそちら）
  if (st.jaLift && /\.(md|txt)$/i.test(name || '')) { const n = FZ.liftJaMarkers(doc); if (n) msg('和文の番号・記号を ' + n + ' 行起こしました'); }
  if (isMd && doc.lines.some(l => l.attrs.cells)) { try { FZ.tbl.alignToText(doc, FZ.layout(doc)); } catch (e) { /* 揃えられなくても開く */ } } /* Markdown の表の左端は直前の文の左端に */
  st.file = ref || null; if (st.file) st.file.hash = FZ.files.hash(text); st.savedAt = 0; stampFile(); ed.setDoc(doc); setFileName(String(name || '').split(/[\\/]/).pop()); if (keepDirty) ed.dirty = true; if (ref && /\.(md|markdown|txt)$/i.test(name)) { ed.dirty = true; st.file = null; msg('.fzk として保存し直してください（元のファイルは変更しません）'); } else msg('開きました');
  clearRecovery(); st.mode = 'text'; drawFkeys(); drawSub(); render(); main.scrollTop = 0; focusTA(); if (st.side === 'hist') drawSide();
  if (st.file && !keepDirty) histPush(st.file, text, '開いたとき'); // 版の履歴：開いた時点の原本
  if (st.file) libTouch(st.file, st.file.name || name); /* 1.0.15d 文庫に */
  { const n = ed.countMdStars(); if (n >= 2) msg(`文中に ** が ${n} 個、文字のまま残っています。${K('mdStars')}（編集の「** を太字に」）で太字に直せます`); } // 以前に取り込んだ文書の救済
}
function openFile() { withDiscard(async () => { try { const r = await FZ.files.open(); if (!r) return; loadText(r.text, r.name, (r.handle || r.path) ? { handle: r.handle, path: r.path, name: r.name } : null); } catch (e) { msg('開けませんでした：' + e.message, true); } }); }
/* ---------- 保存（P01：「保存済」の印を、実際に書いた中身と一致させる） ----------
   書き始めた時の文書（ed.docId）と編集の世代（ed.gen）を覚え、書き終わった時に同じ文書・同じ世代のときだけ「保存済」にする。
   保存中に打った字は未保存のまま残る（閉じる前の確認も、復旧用の退避も効く）。手動・自動・別名の保存は一列に並べ、同時には書かない */
let saveChain = Promise.resolve(), saving = 0;
function queueSave(fn) { const p = saveChain.then(fn); saveChain = p.catch(() => { }); return p; }
function saveFile(saveAs, force = false) { if (st.composing) { msg('変換を確定してから保存してください', true); return Promise.resolve(false); } return queueSave(() => saveNow(saveAs, force, false)); }
async function saveNow(saveAs, force, auto) {
  if (st.composing) { if (!auto) msg('変換を確定してから保存してください', true); return false; }
  if (auto && (!ed.dirty || !st.file || !(st.file.handle || st.file.path))) return false; /* 並んでいる間に保存済み・保存先なしになった */
  const ref = saveAs ? null : st.file;
  if (ref && !force && ref.mtime) { const o = await FZ.files.outside(ref); if (o.changed) { if (auto) { msg(`「${ref.name}」が外で書き換えられたので自動保存しませんでした（${K('save')} で上書きか別名かを選べます）`, true, 0); return false; } conflictInfo = o; openForm('conflict'); return false; } } /* 外で書き換えられていたら黙って上書きしない */
  const docId = ed.docId, gen = ed.gen, text = FZ.serialize(ed.doc), name = auto ? ref.name : baseTitle() + '.fzk';
  const label = auto ? '自動保存' : saveAs ? '名前を付けて保存' : '保存', hm = () => new Date().toLocaleTimeString();
  saving++; status();
  try { const r = await FZ.files.save(text, ref, name, auto ? { auto: true } : {}); if (!r) return false; /* 保存先を選ばなかった：何も変えない */
    const f = { ...r, hash: FZ.files.hash(text) }; await stampFile(f); histPush(f, text, label);
    if (ed.docId !== docId) { msg(`${label}しました（保存中に別の文書へ替えたので、いまの文書は保存していません）`, true, 8000); return true; }
    st.file = f; st.savedAt = Date.now(); if (r.name && r.name !== ed.doc.fileName) { setFileName(r.name); render(); } /* 柱の {file} を保存先の名前に */ if (!auto) libTouch(f, f.name); /* 1.0.15d 文庫に */
    if (ed.gen === gen) { ed.dirty = false; clearRecovery(); msg((auto ? '自動保存 ' : '保存しました ') + hm()); }
    else { saveRecovery(); msg(`${label}完了・その後の入力は未保存（${hm()}）`, true, 10000); } /* 書いている間に打った字：未保存のまま・退避は残す */
    if (!auto && FZ.files.kind === 'basic') msg('ダウンロードとして保存（このブラウザは直接保存に非対応）', true);
    return true; }
  catch (e) { const rec = await saveRecovery(); msg(`${auto ? '自動保存' : '保存'}できませんでした：${e.message}${rec ? '（未保存の変更は復旧用に退避しました）' : ''}`, true, 0); return false; }
  finally { saving--; status(); } }
/* 自動保存：5 分ごと。保存先（ファイルの参照）が決まっていて未保存の変更があるときだけ、同じファイルに上書きする。保存先が無い文書は復旧用の退避だけ */
const AUTOSAVE_MS = 5 * 60 * 1000;
setInterval(() => { if (!ed.dirty || st.composing || saving || !st.file || !(st.file.handle || st.file.path)) return; queueSave(() => saveNow(false, false, true)); }, AUTOSAVE_MS);
let recTimer; function scheduleRecovery() { clearTimeout(recTimer); recTimer = setTimeout(saveRecovery, clamp(700 + ed.doc.lines.length / 10, 700, 15000)); } // 大きい文書ほど間隔を空ける（直列化が重い）
/* ---------- 複数の窓（最大 8） ----------
 * 窓ごとに番号（1〜8）を取り、復旧データを窓ごとに分ける（fz.recover.N）。生きている窓は 4 秒ごとに印（fz.slot.N）を更新し、
 * 15 秒更新の無い番号は空きとみなす。新しい窓は空いている一番小さい番号を取るので、落ちた窓の未保存の文書は次に開いた窓が引き継ぐ */
const MAX_WINDOWS = 8, SLOT_TTL = 15000; const WIN_ID = Math.random().toString(36).slice(2);
function slotInfo(n) { try { return JSON.parse(localStorage.getItem('fz.slot.' + n) || 'null'); } catch { return null; } }
function slotAlive(n) { const s = slotInfo(n); return !!(s && s.id !== WIN_ID && Date.now() - s.time < SLOT_TTL); }
function liveWindows() { let k = 0; for (let n = 1; n <= MAX_WINDOWS; n++) if (slotAlive(n) || st.slot === n) k++; return k; }
function claimSlot() { let pick = 0; const want = +(new URLSearchParams(location.search).get('w') || 0); if (want >= 1 && want <= MAX_WINDOWS && !slotAlive(want)) pick = want; for (let n = 1; n <= MAX_WINDOWS && !pick; n++) if (!slotAlive(n)) pick = n; st.slot = pick || 0; beat(); return st.slot; }
function beat() { if (!st.slot) return; try { localStorage.setItem('fz.slot.' + st.slot, JSON.stringify({ id: WIN_ID, time: Date.now() })); } catch { } }
const RECOVER_KEY = () => st.slot ? 'fz.recover.' + st.slot : 'fz.recover.x';
function newWindow() { if (liveWindows() >= MAX_WINDOWS) { msg(`窓は ${MAX_WINDOWS} つまでです。どれかを閉じてください`, true); return; } let free = 0; for (let n = 1; n <= MAX_WINDOWS && !free; n++) if (!slotAlive(n) && n !== st.slot) free = n; const url = location.href.split('?')[0].split('#')[0] + '?w=' + free; const w = window.open(url, '_blank', 'popup,width=1180,height=900'); if (!w) msg('新しい窓を開けませんでした（ポップアップが止められています）。文机を起動.bat をもう一度実行しても開けます', true); }
setInterval(beat, 4000);
window.addEventListener('pagehide', () => { try { const s = slotInfo(st.slot); if (s && s.id === WIN_ID) localStorage.removeItem('fz.slot.' + st.slot); } catch { } });
/* 復旧データの置き場。まず localStorage（同期で読めるので起動してすぐ戻せる）。上限（全窓あわせて 5MB ほど）を超える文書・画像は、
   全文を IndexedDB（上限が大きい）に置き、localStorage には印（full: 'idb'）と画像を除いた本文を残す。起動時は本文をすぐ戻し、画像はあとから IndexedDB から足す */
const RDB = (() => { let dbp = null;
  const open = () => dbp || (dbp = new Promise((res, rej) => { try { const r = indexedDB.open('fuzukue', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('blocked')); } catch (e) { rej(e); } }).catch(e => { dbp = null; throw e; }));
  const tx = (mode, f) => open().then(db => new Promise((res, rej) => { const t = db.transaction('kv', mode); const q = f(t.objectStore('kv')); t.oncomplete = () => res(q && q.result); t.onerror = t.onabort = () => rej(t.error); }));
  return { get: k => tx('readonly', x => x.get(k)), put: (k, v) => tx('readwrite', x => x.put(v, k)), del: k => tx('readwrite', x => x.delete(k)) }; })();
FZ.RDB = RDB; let idbHeld = false;
/* 復旧用の退避。戻り値は退避できたか（Promise）。退避できなかった時だけ「復旧用の退避に失敗」と知らせる（続けて失敗しても 1 度だけ。成功すれば知らせを戻す） */
let recWarned = false;
function recoveryDone(ok, why) { if (ok) { recWarned = false; return true; } if (!recWarned) { recWarned = true; msg('復旧用の退避に失敗しました' + (why ? '（' + why + '）' : '') + '。落ちると未保存の変更が戻せません。保存してください', true, 0); } return false; }
function saveRecovery() { if (!ed.dirty) return Promise.resolve(true); let text, key, rec; try { text = FZ.serialize(ed.doc); key = RECOVER_KEY(); rec = { text, name: st.file ? st.file.name : '', time: Date.now(), gen: ed.gen }; } catch (e) { return Promise.resolve(recoveryDone(false, e.message)); }
  try { localStorage.setItem(key, JSON.stringify(rec)); if (idbHeld) { idbHeld = false; RDB.del(key).catch(() => { }); } return Promise.resolve(recoveryDone(true)); } catch { }
  idbHeld = true; const body = text.split('\n===\n#添付')[0] + '\n'; let mark = false;
  try { localStorage.setItem(key, JSON.stringify({ ...rec, text: body, full: 'idb' })); mark = true; } catch { try { localStorage.setItem(key, JSON.stringify({ ...rec, text: '', full: 'idb' })); } catch { } }
  return RDB.put(key, rec).then(() => recoveryDone(true), () => recoveryDone(false, mark ? '画像を除いた本文だけ退避' : '保存の場所が足りない')); }
function clearRecovery() { const key = RECOVER_KEY(); try { localStorage.removeItem(key); } catch { } idbHeld = false; RDB.del(key).catch(() => { }); }
/* 起動時：印が IndexedDB を指していたら全文を読み、画像を足す（本文が localStorage に無ければ文書ごと戻す） */
function restoreFromIdb(mark) { const key = RECOVER_KEY(); idbHeld = true;
  return RDB.get(key).then(v => { if (!v || !v.text || (v.time || 0) < (mark.time || 0)) { if (!mark.text) msg('前回の未保存の文書を IndexedDB から戻せませんでした', true, 0); else msg('前回の続きを復元（画像は戻せませんでした）', true, 8000); return; }
    const full = FZ.parse(v.text); if (mark.text) { ed.doc.images = { ...full.images, ...ed.doc.images }; ed.relayout(); render(); msg('前回の続きを復元（画像も戻しました）', false, 6000); }
    else { ed.setDoc(full); ed.dirty = true; st.file = v.name ? { name: v.name } : null; setFileName(v.name || ''); render(); msg('前回の続きを復元（未保存）', false, 8000); } }).catch(() => msg('前回の未保存の文書を IndexedDB から戻せませんでした', true, 0)); }
window.addEventListener('beforeunload', e => { saveRecovery(); if (ed.dirty) { e.preventDefault(); e.returnValue = ''; } });
/* ================= 書体 ================= */
/* 画面の書体：文書の書式（明朝の書体・ゴシックの書体）を CSS 変数に流す。同梱フォントは持たず、PC に入っている書体を使う */
let fontSig = '';
function applyFonts() {
  const f = ed.doc.format; const mi = f.fontMincho || 'BIZ UDMincho', go = f.fontGothic || 'BIZ UDGothic'; const sig = mi + '|' + go; if (sig === fontSig) return; fontSig = sig; ADV.clear(); advFont = null;
  const q = n => '"' + String(n).replace(/"/g, '') + '"';
  const al = n => { const o = FZ.officeFont ? FZ.officeFont(n) : { latin: n, ea: n }; return [q(n), q(o.latin), q(o.ea)].join(','); }; // 画面でも Windows の正式名（BIZ UD明朝 Medium など）で探せるように
  document.documentElement.style.setProperty('--mincho', `${al(mi)},"BIZ UDMincho","BIZ UDMincho Medium","BIZ UD明朝 Medium","Yu Mincho","游明朝","MS Mincho",serif`);
  document.documentElement.style.setProperty('--gothic', `${al(go)},"BIZ UDGothic","BIZ UDゴシック","Yu Gothic","游ゴシック","MS Gothic",sans-serif`);
}
/* 1.0.11d 字の送り幅（em に対する比）：基準の字幅で字をマスの中ほどに置くために、画面の書体（明朝・ゴシック・ゴシック太字）で測る */
const ADV = new Map(); let advFont = null, advCv = null;
FZ.glyphAdv = (t, cls) => { const key = cls + '\u0000' + t; let a = ADV.get(key); if (a != null) return a;
  if (!advFont) { const rs = getComputedStyle(document.documentElement); const mi = rs.getPropertyValue('--mincho').trim() || 'serif', go = rs.getPropertyValue('--gothic').trim() || 'sans-serif'; advFont = { fm: '400 100px ' + mi, fgr: '400 100px ' + go, fg: '700 100px ' + go }; }
  try { advCv = advCv || document.createElement('canvas').getContext('2d'); advCv.font = advFont[cls] || advFont.fm; a = advCv.measureText(t).width / 100; } catch (e) { a = FZ.isHalf(t.codePointAt(0)) ? 0.5 : 1; }
  ADV.set(key, a); return a; };
/* インストール済み書体の一覧：Local Font Access API（Edge／Chrome、許可が要る）→ 無ければ候補を描画幅で判定 */
const FONT_CANDIDATES = ['BIZ UDMincho', 'BIZ UDMincho Medium', 'BIZ UD明朝 Medium', 'BIZ UDPMincho', 'BIZ UDPMincho Medium', 'BIZ UDGothic', 'BIZ UDゴシック', 'BIZ UDPGothic', '游明朝', '游ゴシック', 'ＭＳ 明朝', 'ＭＳ ゴシック', 'メイリオ', 'UD デジタル 教科書体 N-R', 'Yu Mincho', 'Yu Gothic', 'Yu Gothic UI', 'Meiryo', 'Meiryo UI', 'MS Mincho', 'MS PMincho', 'MS Gothic', 'MS PGothic', 'MS UI Gothic', 'UD Digi Kyokasho N-R', 'UD Digi Kyokasho NK-R', 'UD Digi Kyokasho NP-R', 'HGMinchoE', 'HGPMinchoE', 'HGGothicE', 'HGPGothicE', 'HGGothicM', 'HGSoeiKakugothicUB', 'HGMaruGothicMPRO', 'HGKyokashotai', 'HGSeikaishotaiPRO', 'HGGyoshotai', 'Noto Sans JP', 'Noto Serif JP', 'Noto Sans CJK JP', 'Noto Serif CJK JP', 'Source Han Sans', 'Source Han Serif', 'IPAexMincho', 'IPAexGothic', 'IPAMincho', 'IPAGothic', 'Hiragino Mincho ProN', 'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Hiragino Maru Gothic ProN', 'Klee', 'Toppan Bunkyu Mincho', 'Toppan Bunkyu Gothic', 'Tsukushi A Round Gothic', 'YuKyokasho', 'Osaka', 'Consolas', 'Courier New', 'Arial', 'Segoe UI', 'Georgia', 'Times New Roman'];
function fontAvailable(name) { const c = document.createElement('canvas').getContext('2d'); const t = 'あいう漢字Wgmi12'; const w = fam => { c.font = `20px ${fam}`; return c.measureText(t).width; }; const a = w('monospace'), b = w('serif'); const q = `"${name}"`; return w(`${q},monospace`) !== a || w(`${q},serif`) !== b; }
/* full：Local Font Access API で全書体を読む（許可が要る）。既定は候補の描画幅で判定（許可不要・すぐ終わる） */
async function loadFontList(full) {
  let names = null;
  if (full && typeof window.queryLocalFonts === 'function') { try { const fonts = await window.queryLocalFonts(); names = [...new Set(fonts.map(x => x.family))]; } catch (e) { names = null; } }
  if (!names || !names.length) names = FONT_CANDIDATES.filter(fontAvailable);
  const ja = n => /[\u3040-\u30ff\u4e00-\u9fff]|Mincho|Gothic|Kyokasho|Meiryo|Hiragino|Noto (Sans|Serif) (JP|CJK)|Source Han|IPA|BIZ|UD /i.test(n);
  names.sort((a, b) => (ja(b) - ja(a)) || a.localeCompare(b, 'ja')); st.fontList = names; try { localStorage.setItem('fz.fontList', JSON.stringify(names)); } catch { }
}
/* 書体の選択欄：一覧（和文の書体が先）＋今の値。一覧が無ければ開いたときに候補から判定する */
function fontOptions(cur) { const list = st.fontList && st.fontList.length ? st.fontList : FONT_CANDIDATES.filter(fontAvailable); if (!st.fontList || !st.fontList.length) st.fontList = list; const all = list.includes(cur) ? list : [cur, ...list]; const o = FZ.officeFont ? FZ.officeFont(cur) : { latin: cur, ea: cur }; const have = list.includes(cur) || [cur, o.latin, o.ea].some(fontAvailable); return all.map(n => `<option value="${esc(n)}"${n === cur ? ' selected' : ''} style="font-family:'${esc(n).replace(/'/g, '')}'">${esc(n)}${n === cur && !list.includes(cur) ? (have ? (o.ea !== cur ? '（= ' + esc(o.ea) + '）' : '') : '（この PC に無い）') : ''}</option>`).join(''); }
function fontPicker(name, cur) { let o = fontOptions(cur); const miss = o.includes('（この PC に無い）'); o = o.replace('（この PC に無い）', ''); return `<select name="${name}" class="font">${o}</select>${miss ? '<b class="miss" title="この PC に無い書体（代わりの書体で組む）">無</b>' : ''}`; } /* 無い書体は名前を切らず、赤い「無」 */
try { st.fontList = JSON.parse(localStorage.getItem('fz.fontList') || 'null') || null; } catch { }
/* 1.0.11d 書体の組：明朝・ゴシック・基準の字幅（全角・半角）をひと組にして名前で呼ぶ。内蔵の組（auto は当てるときにこの PC で測る）＋自分で保存した組（localStorage） */
const FONT_PROFILES = [
  { name: 'BIZ UD（等幅）', mincho: 'BIZ UDMincho', gothic: 'BIZ UDGothic', zen: 100, han: 100 },
  { name: 'BIZ UDP（プロポーショナル）', mincho: 'BIZ UDPMincho', gothic: 'BIZ UDPGothic', auto: true },
  { name: '游明朝・游ゴシック', mincho: 'Yu Mincho', gothic: 'Yu Gothic', auto: true },
  { name: 'MS 明朝・MS ゴシック（等幅）', mincho: 'MS Mincho', gothic: 'MS Gothic', zen: 100, han: 100 },
  { name: 'MS P明朝・MS Pゴシック', mincho: 'MS PMincho', gothic: 'MS PGothic', auto: true }].map(p => ({ ...p, builtin: true }));
const FONTPROF_KEY = 'fz.fontProfiles';
function userFontProfiles() { try { const a = JSON.parse(localStorage.getItem(FONTPROF_KEY) || '[]'); return Array.isArray(a) ? a.filter(p => p && p.name && p.mincho && p.gothic).map(p => ({ name: String(p.name), mincho: String(p.mincho), gothic: String(p.gothic), zen: Math.round(FZ.glyphPct(p.zen) * 100), han: Math.round(FZ.glyphPct(p.han) * 100) })) : []; } catch { return []; } }
function saveUserFontProfiles(a) { try { localStorage.setItem(FONTPROF_KEY, JSON.stringify(a)); } catch { } }
function fontProfiles() { return [...FONT_PROFILES, ...userFontProfiles()]; }
function fontProfVals() { return [...fontProfiles().map((p, i) => [String(i), p.name + (p.builtin ? '' : '＊')]), ['-', '（自由）']]; }
function fontProfMatch(f) { const zen = Math.round(FZ.glyphPct(f.zenW) * 100), han = Math.round(FZ.glyphPct(f.hanW) * 100); const ps = fontProfiles(); let k = -1; for (let i = ps.length - 1; i >= 0 && k < 0; i--) { const p = ps[i]; if (p.mincho === (f.fontMincho || 'BIZ UDMincho') && p.gothic === (f.fontGothic || 'BIZ UDGothic') && (p.auto || (p.zen === zen && p.han === han))) k = i; } return k >= 0 ? k : '-'; }
function setVal(name, v) { const el = sub.querySelector(`[name="${name}"]`); if (el) el.value = v; }
function setFontSel(name, v) { const el = sub.querySelector(`select[name="${name}"]`); if (!el) return; el.innerHTML = fontOptions(v); el.value = v; const b = el.parentNode.querySelector('b.miss'); const miss = !(st.fontList || []).includes(v) && ![v, FZ.officeFont(v).latin, FZ.officeFont(v).ea].some(fontAvailable); if (miss && !b) el.insertAdjacentHTML('afterend', '<b class="miss" title="この PC に無い書体（代わりの書体で組む）">無</b>'); else if (!miss && b) b.remove(); }
function fillFontProf(p) { setFontSel('fontMincho', p.mincho); setFontSel('fontGothic', p.gothic); const r = p.auto ? measureFit(p.mincho, p.gothic) : { zen: p.zen, han: p.han }; setVal('zenW', r.zen); setVal('hanW', r.han); if (p.auto) msg(`「${p.name}」：この PC で測って全角 ${r.zen}%・半角 ${r.han}%（${r.note}）`, !!r.miss); }
/* 測る：英数字（半角）・かな漢字（全角）の送り幅を明朝・ゴシック・ゴシック太字で測り、9 割の字がマスに収まる％（5％刻みで切り捨て、100％ まで）。残りの幅広の字は描くときにさらに縮める */
function fontFamilyCss(n, generic) { const q = x => '"' + String(x).replace(/"/g, '') + '"'; const o = FZ.officeFont ? FZ.officeFont(n) : { latin: n, ea: n }; return [q(n), q(o.latin), q(o.ea), generic].join(','); }
function measureFit(mincho, gothic) {
  const cv = document.createElement('canvas').getContext('2d'); const fams = [['400', fontFamilyCss(mincho, 'serif')], ['400', fontFamilyCss(gothic, 'sans-serif')], ['700', fontFamilyCss(gothic, 'sans-serif')]];
  const adv = (chars, [w, fam]) => Array.from(chars).map(c => { cv.font = `${w} 100px ${fam}`; return cv.measureText(c).width / 100; });
  const p90 = a => { const s = a.slice().sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * 0.9))]; };
  const HALF = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', FULL = 'あいうえおかきくけこさしすせそアイウエオカキクケコ日本語文書会議資料国';
  const h = p90(fams.flatMap(fm => adv(HALF, fm))), z = p90(fams.flatMap(fm => adv(FULL, fm)));
  const pct = (cell, a) => a > 0 ? clamp(Math.floor((cell / a * 100 + 0.2) / 5) * 5, 30, 100) : 100;
  const miss = [mincho, gothic].filter(n => !(st.fontList || []).includes(n) && ![n, FZ.officeFont(n).latin, FZ.officeFont(n).ea].some(fontAvailable));
  return { zen: pct(1, z), han: pct(0.5, h), miss: miss.length > 0, note: miss.length ? `この PC に無い書体（${miss.join('・')}）は代わりの書体で測った` : '9 割の字がマスに収まる幅。幅広の字は描くときにさらに縮める' }; }
try { st.jaLift = localStorage.getItem('fz.jaLift') === '1'; } catch { }
/* ================= 図版の画像（資料書式） =================
 * 原本は base64 のまま持ち、表示・印刷は Blob の URL で。白黒の印刷イメージに合わせて、画像は灰色に落として網点（45°、1.5pt）にする。
 * 真っ黒・真っ白に近い所はそのまま（グラフの線や文字が崩れない）。網点化は非同期で、できるまでは元の画像を出す */
const IMGC = new Map(); const HT_S = 4, HT_PITCH = 1.5;
function b64ToBlob(img) { const bin = atob(img.data); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new Blob([u], { type: img.mime }); }
function imgRec(name, img) { let r = IMGC.get(name); if (!r || r.data !== img.data) { if (r) { URL.revokeObjectURL(r.url); for (const h of r.ht.values()) if (h.url && h.url !== r.url) URL.revokeObjectURL(h.url); } r = { data: img.data, url: URL.createObjectURL(b64ToBlob(img)), ht: new Map() }; IMGC.set(name, r); } return r; }
const htKey = (w, h) => Math.round(w * 2) + 'x' + Math.round(h * 2);
function imageHref(name, img, w, h) {
  let r; try { r = imgRec(name, img); } catch { return `data:${img.mime};base64,${img.data}`; }
  const k = htKey(w, h); let e = r.ht.get(k); if (e && e.url) return e.url;
  if (!e) { e = {}; r.ht.set(k, e); e.p = halftoneImage(r.url, w, h).then(u => { e.url = u; }).catch(() => { e.url = r.url; }).then(() => { pageCache = pageCache.map(() => ''); requestRender(); }); }
  return r.url;
}
async function prepareImages() { const lay = ed.lay, ps = []; for (const pg of lay.pages) for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) { const img = lay.images && lay.images[im.file]; if (!img) continue; const w = im.w * lay.geo.cw, h = im.h * lay.geo.ch; imageHref(im.file, img, w, h); const e = IMGC.get(im.file) && IMGC.get(im.file).ht.get(htKey(w, h)); if (e && e.p) ps.push(e.p); } await Promise.all(ps); }
async function halftoneImage(url, wPt, hPt) {
  const im = new Image(); im.src = url; await im.decode(); const nw = im.naturalWidth || 300, nh = im.naturalHeight || 225;
  const sc = Math.min(wPt / nw, hPt / nh); const W = Math.max(1, Math.round(nw * sc * HT_S)), H = Math.max(1, Math.round(nh * sc * HT_S));
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.drawImage(im, 0, 0, W, H);
  const d = ctx.getImageData(0, 0, W, H), px = d.data; const P = HT_PITCH * HT_S, R = Math.SQRT1_2;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const o = (y * W + x) * 4; const ink = 1 - (0.299 * px[o] + 0.587 * px[o + 1] + 0.114 * px[o + 2]) / 255; let black;
    if (ink < 0.06) black = false; else if (ink > 0.94) black = true;
    else { const u = R * (x + y) / P, v = R * (y - x) / P; const X = 2 * (u - Math.floor(u)) - 1, Y = 2 * (v - Math.floor(v)) - 1; const ax = Math.abs(X), ay = Math.abs(Y); const s = ax + ay <= 1 ? 1 - (X * X + Y * Y) : (ax - 1) * (ax - 1) + (ay - 1) * (ay - 1) - 1; black = ink > (1 - s) / 2; } // ユークリッドの網点
    const c = black ? 0 : 255; px[o] = px[o + 1] = px[o + 2] = c; px[o + 3] = black ? 255 : 0; }
  ctx.putImageData(d, 0, 0); const blob = await new Promise(res => cv.toBlob(res, 'image/png')); return URL.createObjectURL(blob);
}
/* 画像を選ぶ（PNG／JPEG／GIF／SVG／WebP）→ { name, mime, data } */
function pickImage() { return new Promise(res => { const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/png,image/jpeg,image/gif,image/svg+xml,image/webp'; inp.onchange = () => { const f = inp.files[0]; if (!f) return res(null); readImageBlob(f, f.name).then(res, e => { msg('画像を読めませんでした：' + e.message, true); res(null); }); }; inp.click(); }); }
function readImageBlob(blob, name = '') { return new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => { const m = String(fr.result).match(/^data:([^;,]+);base64,(.*)$/); if (!m || !/^image\//.test(m[1])) return rej(new Error('画像ではありません')); res({ name, mime: m[1], data: m[2] }); }; fr.onerror = () => rej(fr.error || new Error('読めません')); fr.readAsDataURL(blob); }); }
function addImageFigure(r) { const nm = ed.addImage(r.mime, r.data, r.name); const id = ed.addFigure({ file: nm, kind: '図', title: '' }); st.figSel = id; openForm('fig');
  const mb = r.data.length * 3 / 4 / 1048576; msg((ed.doc.format.kind === 'slide' ? '図表欄に置きました' : '行の下に置きました') + '：題を入れて Enter' + (mb > 3 ? `（画像が ${mb.toFixed(1)}MB と大きいので、原本も大きくなります）` : ''), mb > 3); }
/* 画面上の図版（画像と番号・題の行）に当たったか */
function figHit(g) { const pg = ed.lay.pages[g.page]; if (!pg) return null; for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) if (g.col >= im.col && g.col < im.col + im.w && g.row >= im.y - 1 && g.row < im.y + im.h) return im; return null; }
/* 1.0.11e 図表の大きさの欄：欄の幅・1/2・1/3・1/4・原寸 ＋ ％。決まった大きさ（マス・mm）を横に出す */
function figSizeHtml(fg) { return `<label title="欄（区画・図表欄・本文）の幅を何等分した 1 つ分か、または原寸（画像の画素、グラフは Excel の既定の大きさ）">大きさ ${cyc('fsz', [['1', '欄の幅'], ['2', '1/2'], ['3', '1/3'], ['4', '1/4'], ['o', '原寸']], fg.orig ? 'o' : String(fg.div || 1))}</label><label title="その幅の何％か（原寸なら原寸の何％か）。高さは縦横の比で決まる">${inp('fpc', fg.orig || fg.width || 100, 'n', 'number', `min="10" max="${fg.orig ? 400 : 100}" step="5"`)}%</label><span class="info" id="figSz">${esc(figSizeInfo(fg))}</span>`; }
function figSizeRead() { const z = cycVal('fsz'), p = +fval('fpc') || 100; return z === 'o' ? { orig: clamp(Math.round(p), 10, 400), width: 100, div: 1 } : { width: clamp(Math.round(p), 10, 100), div: +z || 1, orig: 0 }; }
function figSizeSame(a, b) { const x = FZ.figSize(a), y = FZ.figSize(b); return x.width === y.width && (x.div || 1) === (y.div || 1) && (x.orig || 0) === (y.orig || 0); }
function figSizeInfo(fg) { const L = ed.lay; for (const pg of L.pages) for (const im of (pg.images || []).concat(pg.side ? pg.side.images : [])) if (im.id === fg.id) return `→ ${im.w}×${im.h} マス（幅 ${Math.round(im.w * L.geo.cw / FZ.PT)}mm）`; return ''; }
let figSizeT = 0; function figSizeLater(fn) { clearTimeout(figSizeT); figSizeT = setTimeout(() => { if (st.form === 'fig' || st.form === 'chart') fn(); }, 450); }
function figSizeChange(name) { if (name !== 'fsz') return; const el = sub.querySelector('[name="fpc"]'); if (!el) return; const o = cycVal('fsz') === 'o'; el.max = o ? 400 : 100; if (!o && +el.value > 100) el.value = 100; }
FORMS.fig = {
  cur() { return ed.figById(st.figSel); },
  html() { const x = this.cur(); if (!x) return `<span class="ttl">図表</span><span class="info alert">図表がありません</span><button type="button" data-act="cancel">閉じる Esc</button>`; const fg = x.fg; const n = ed.lay.figNums && ed.lay.figNums.get(fg.id); const L = ed.figList(); const idx = L.findIndex(y => y.fg.id === fg.id);
    return `<span class="ttl">図表 ${esc(n ? n.label : '')}（${idx + 1}/${L.length}）</span><label>種別 ${cyc('kind', [['図', '図'], ['表', '表']], fg.kind)}</label><label>題 ${inp('title', fg.title, 'w')}</label>${figSizeHtml(fg)}
      <button type="button" data-act="prev" title="前の図表を開く">← 前</button><button type="button" data-act="next" title="次の図表を開く">次 →</button><button type="button" data-act="up" title="順番を 1 つ前へ（番号も変わる）">↑ 前へ送る</button><button type="button" data-act="down" title="順番を 1 つ後ろへ">↓ 後へ送る</button><button type="button" data-act="ref" title="本文の今の位置に「${esc(n ? n.label : '図')}」を入れる">図番</button><button type="button" data-act="replace" title="画像を別のものに差し替える">差し替え…</button><button type="button" data-act="del">削除</button>
      <span class="info" title="${ed.doc.format.kind === 'slide' ? '' : '文書の書式では本文の流れ（行の下）に置く。資料書式なら右の図表欄'}">${esc(fg.file || '（画像なし）')}</span><button type="button" class="pri" data-act="apply">確定 Enter</button><button type="button" data-act="cancel" title="この欄を開いてからの変更を元に戻して閉じる">元に戻す Esc</button>`; },
  focus: 'input[name="title"]', enter() { this.act('apply'); },
  read() { return { kind: cycVal('kind'), title: fval('title').trim(), ...figSizeRead() }; },
  save() { const x = this.cur(); if (!x) return; const v = this.read(); if (v.kind !== x.fg.kind || v.title !== x.fg.title || !figSizeSame(v, x.fg)) { ed.setFig(x.fg.id, v); const el = $('figSz'); if (el) el.textContent = figSizeInfo(ed.figById(x.fg.id).fg); } },
  change(name) { figSizeChange(name); if (name === 'fsz') this.save(); else if (name === 'fpc') figSizeLater(() => this.save()); }, /* 大きさはその場で紙面に（％は打ち終わってから） */
  act(a) { const x = this.cur(); if (a === 'cancel' || !x) { if (a === 'cancel' && x) cancelForm(); else closeForm(); return; }
    if (a === 'apply') { this.save(); closeForm(); return; }
    this.save();
    if (a === 'prev' || a === 'next') { const L = ed.figList(); const i = L.findIndex(y => y.fg.id === x.fg.id); const t = L[i + (a === 'next' ? 1 : -1)]; if (t) { st.figSel = t.fg.id; drawSub(); } else msg(a === 'next' ? '最後の図表です' : '最初の図表です'); return; }
    if (a === 'up' || a === 'down') { if (!ed.moveFig(x.fg.id, a === 'up' ? -1 : 1)) msg('これ以上動かせません'); drawSub(); return; }
    if (a === 'del') { ed.removeFig(x.fg.id); closeForm(); msg('図表を削除しました（Ctrl+Z で戻す。文中の図番は「図 ?」になります）'); return; }
    if (a === 'ref') { closeForm(); ed.insertRef(x.fg.id); return; }
    if (a === 'replace') { pickImage().then(r => { if (!r) return; const nm = ed.addImage(r.mime, r.data, r.name); ed.setFig(x.fg.id, { file: nm }); drawSub(); }); return; } } };
/* ツリーで探す（G3）：当たった節に印、Enter で次の節へ（畳まれた所・深さの外なら開いて見せる） */
const treeNorm = t => String(t || '').normalize('NFKC').toLowerCase();
function treeFindHits() { const q = treeNorm(st.tree.find).trim(); if (!q) return []; const tr = FZ.tree.build(ed.doc, { body: true, figs: true, sentences: st.tree.depth === -1, figLabel: fg => fg.title || '' }); const all = [...tr.nodes, ...(tr.figs || []), ...(tr.sents || [])].filter(n => !n.root && treeNorm(n.text).includes(q)); all.sort((a, b) => a.line - b.line || (a.kind === 'sent' ? a.si + 1 : 0) - (b.kind === 'sent' ? b.si + 1 : 0)); return all; }
function treeFindStep(d) { const hits = treeFindHits(); if (!hits.length) { msg('見つかりません', true); return; } const cur = treeNodeSel(); const keys = hits.map(treeKey); let k = keys.indexOf(st.tree.sel);
  if (k < 0) { const L = cur && cur.line != null ? cur.line : -1; k = d > 0 ? hits.findIndex(n => n.line > L) : (() => { let j = -1; hits.forEach((n, i) => { if (n.line < L) j = i; }); return j; })(); if (k < 0) k = d > 0 ? 0 : hits.length - 1; } else k = (k + d + hits.length) % hits.length;
  const n = hits[k]; const body = n.kind === 'body' || n.kind === 'block' || n.kind === 'fig'; if (n.kind === 'sent' && st.tree.depth !== -1) st.tree.depth = -1; else if (body && st.tree.depth > 0) st.tree.depth = 0; else if (st.tree.depth > 0 && st.tree.depth !== 9) st.tree.depth = 9;
  for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); }
  st.tree.sel = keys[k]; render(); treeScrollToSel(); const info = sub.querySelector('.tfinfo'); if (info) info.textContent = `${k + 1}/${hits.length} 件`; status(); }
FORMS.tfind = {
  html() { const q = st.tree.find || ''; const h = treeFindHits(); const k = h.map(treeKey).indexOf(st.tree.sel);
    return `<span class="ttl">ツリーで探す</span><label>${inp('q', q, 'w')}</label><button type="button" data-act="prev" title="前の節（Shift+Enter）">↑ 前</button><button type="button" data-act="next" title="次の節（Enter）">次 ↓</button><span class="info tfinfo">${q ? (h.length ? (k >= 0 ? `${k + 1}/` : '') + `${h.length} 件` : '見つかりません') : '見出し・箇条書き・本文・図表の題'}</span><span class="hintl">当たった節に破線の印。紙面の検索・置換は Esc で紙面へ戻ってから</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'input[name="q"]',
  change(name) { if (name !== 'q') return; st.tree.find = fval('q'); render(); const h = treeFindHits(); const info = sub.querySelector('.tfinfo'); if (info) info.textContent = st.tree.find.trim() ? (h.length ? `${h.length} 件` : '見つかりません') : ''; },
  enter(e) { this.act(e && e.shiftKey ? 'prev' : 'next'); },
  act(a) { if (a === 'cancel') { st.tree.find = ''; closeForm(); render(); return; } if (a === 'next' || a === 'prev') treeFindStep(a === 'next' ? 1 : -1); } };
/* 構造から図（R3）：節と子（見出し・箇条書き）を箱と矢印の構成図に自動で並べる。手で直すのは微調整だけ */
function figTreeRoot() { if (st.mode === 'tree') { const n = treeNodeSel(); const v = st.tree.view; return n && !n.root && n.kind !== 'body' && n.kind !== 'sent' && n.kind !== 'block' && n.kind !== 'fig' ? n : v ? v.top : null; }
  const tr = FZ.tree.build(ed.doc, {}); const L = ed.caret.line; let best = null; for (const n of tr.nodes) if (n.line <= L && n.end >= L && !n.root && (n.kind === 'num' || n.kind === 'sym' || n.kind === 'title') && (!best || n.depth > best.depth)) best = n; if (!best) best = tr.root.children.length === 1 ? tr.root.children[0] : tr.root; return best; }
function figFromTree(dir, maxDepth) {
  const root = figTreeRoot(); if (!root) return; const kids = n => (n.children || []).filter(c => c.kind === 'num' || c.kind === 'sym' || c.kind === 'list' || c.kind === 'title');
  if (!kids(root).length) { msg('この節には子（見出し・箇条書き）がありません', true); return; }
  let N = 0; const mk = (n, d) => { N++; const o = { src: n, d, children: [] }; if (d < maxDepth) for (const c of kids(n)) { if (N >= 40) break; o.children.push(mk(c, d + 1)); } return o; }; const T = mk(root, 0);
  const endLine = root.root ? ed.doc.lines.length - 1 : root.end; const host = ed.lay.lineMap[Math.min(endLine, ed.lay.lineMap.length - 1)]; const r0 = host && host.segs[0].rows[0]; const W = Math.max(16, r0 ? Math.floor(r0.right - r0.left) : ed.lay.geo.cols); const maxH = Math.max(8, ed.lay.geo.rows - 2);
  let depthN = 0; const walk = (o) => { depthN = Math.max(depthN, o.d + 1); o.children.forEach(walk); }; walk(T);
  const label = o => String(o.src.root ? (ed.doc.title || '文書') : o.src.text || '').replace(/\s+/g, ' ').trim().slice(0, 28) || '（空）';
  const tryLayout = d0 => { const gapD = d0 === 'h' ? 3 : 2, gapS = 1; const colW = d0 === 'h' ? Math.max(6, Math.min(16, Math.floor((W - gapD * (depthN - 1)) / depthN))) : 12;
    const size = o => { const tw = FZ.textWidth(label(o)); const w = Math.max(4, Math.min(colW, Math.ceil(tw) + 2)); const lines = Math.max(1, Math.ceil(tw / Math.max(1, w - 2))); return { w, h: Math.min(4, lines) + 2 }; };
    const L = FZ.tree.layout(T, { dir: d0, visible: o => o.children, size, gapDepth: gapD, gapSib: gapS }); return { L, size }; };
  let use = dir, R = tryLayout(dir); const fits = R2 => R2.L.W <= W && R2.L.H + 2 <= maxH;
  if (!fits(R) && dir === 'v') { const R2 = tryLayout('h'); if (fits(R2) || R2.L.W <= W) { use = 'h'; R = R2; } }
  if (R.L.W > W + 0.5) { msg(`構成図が欄の幅（${W} 字）に収まりません。深さを浅くしてください`, true); return; }
  const boxes = [], arrows = [], ids = new Map(); let id = 0, H = 0; const all = []; const walk2 = o => { all.push(o); o.children.forEach(walk2); }; walk2(T);
  for (const o of all) { const p = R.L.pos.get(o); const x = Math.max(0, Math.min(W - p.w, Math.round(p.x))), y = Math.round(p.y) + 1; ids.set(o, ++id); boxes.push({ id, x, y, w: p.w, h: p.h, text: label(o), kind: o === T ? 'thick' : 'thin', shade: o === T ? 'gray' : null, bold: o === T || o.d === 1 }); H = Math.max(H, y + p.h + 1); }
  for (const o of all) for (const c of o.children) arrows.push({ from: ids.get(o), to: ids.get(c), label: '', kind: 'thin' });
  if (H > maxH) { msg(`構成図が 1 頁に収まりません（${H} 行）。深さを浅くするか、下の節で作ってください`, true); return; }
  const fig = FZ.normalizeFigure({ h: H, boxes, arrows, lanes: null }); let at = -1;
  ed.mutate('', () => { at = endLine + 1; while (at < ed.doc.lines.length && FZ.inTable(ed.doc, at)) at++; ed.insertLine(at, { segs: [FZ.newSeg(0, '')], attrs: { figure: fig } }); if (at + 1 >= ed.doc.lines.length) ed.insertLine(at + 1, FZ.newLine()); ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; });
  if (st.mode === 'tree') { st.tree.sel = ed.doc.lines[at]; treeRefresh(); } else { render(); scrollToCaret(true); }
  msg(`「${label(T)}」の構成図を節の後ろに入れました（${all.length} 個の箱。${use === 'h' ? '左から右へ' : '上から下へ'}${use !== dir ? '：上から下では幅に収まらないため' : ''}）。箱の位置は図の中で直せます（Enter）`, false, 8000); }
FORMS.figtree = {
  html() { const r = figTreeRoot(); const name = r ? String(r.root ? (ed.doc.title || '文書') : r.text).slice(0, 20) : ''; return `<span class="ttl">構成図を作る</span><span class="info">「${esc(name)}」と子の見出し・箇条書き</span><label>深さ ${cyc('depth', [['1', '子まで'], ['2', '孫まで'], ['3', '3 段まで']], String(st.figTreeDepth || 2))}</label><button type="button" class="pri" data-act="h"><span class="kk">1</span>左から右へ</button><button type="button" data-act="v"><span class="kk">2</span>上から下へ</button><span class="hintl">節の後ろに図として入る。並べ直しは図の中で</span><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'button.pri', key(e) { if (e.key === '1' || e.key === '2') { e.preventDefault(); this.act(e.key === '1' ? 'h' : 'v'); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a !== 'h' && a !== 'v') return; const d = +cycVal('depth') || 2; st.figTreeDepth = d; closeForm(); figFromTree(a, d); } };
/* 送り先を選んで移す（S3）：見出しの一覧から移し先。紙面はカーソルの節（範囲なら複数）、ツリーは選んだ節 */
function moveTargets() { const tr = FZ.tree.build(ed.doc, {}); const out = [{ n: tr.root, label: '（文書のいちばん上の段）', depth: 0, obj: null }]; for (const n of tr.nodes) if (n.kind === 'title' || n.kind === 'num' || n.kind === 'sym') out.push({ n, label: (treeMarker(n) ? treeMarker(n) + ' ' : '') + n.text, depth: n.depth, obj: n.obj }); return out; }
FORMS.moveTo = {
  html() { const q = st.moveQ || ''; const all = moveTargets(); const nq = treeNorm(q); const L = all.filter(t => !nq || treeNorm(t.label).includes(nq)).slice(0, 300); if (st.moveIdx == null || st.moveIdx >= L.length) st.moveIdx = 0;
    return `<span class="ttl">送り先を選んで移す</span><label>${inp('q', q, 'w', 'text', 'placeholder="見出しの文字で絞る"')}</label><label>${cyc('rel', [['child', '子の末尾へ'], ['before', 'その前へ'], ['after', 'その後へ']], 'child')}</label><span class="hintl">↑↓ で選び Enter（子と本文ごと移る）</span><button type="button" data-act="cancel">取消 Esc</button><div class="mvlist">${L.map((t, i) => `<button type="button" class="mv${i === st.moveIdx ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'}</div>`; },
  list() { const nq = treeNorm(st.moveQ || ''); return moveTargets().filter(t => !nq || treeNorm(t.label).includes(nq)).slice(0, 300); },
  focus: 'input[name="q"]',
  change(name) { if (name === 'q') { st.moveQ = fval('q'); st.moveIdx = 0; const box = sub.querySelector('.mvlist'); if (box) { const L = this.list(); box.innerHTML = L.map((t, i) => `<button type="button" class="mv${i === 0 ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'; } } if (name === 'rel') st.moveRel = cycVal('rel'); },
  key(e) { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const L = sub.querySelectorAll('.mvlist .mv'); if (!L.length) return; st.moveIdx = Math.max(0, Math.min(L.length - 1, (st.moveIdx || 0) + (e.key === 'ArrowDown' ? 1 : -1))); L.forEach((b, i) => b.classList.toggle('on', i === st.moveIdx)); L[st.moveIdx].scrollIntoView({ block: 'nearest' }); } },
  enter() { this.act('m' + (st.moveIdx || 0)); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^m(\d+)$/); if (!m) return; const t = this.list()[+m[1]]; if (!t) return; const rel = t.obj ? (cycVal('rel') || 'child') : 'child'; st.moveRel = cycVal('rel') || st.moveRel; closeForm();
    const go = () => { const v = st.tree.view; const tr = v.tr; const target = t.obj ? tr.byObj.get(t.obj) : tr.root; if (!target) { msg('移し先が見つかりません', true); return; } treeMoveSel(list => FZ.tree.move(ed, tr, list, target, rel)); };
    if (st.mode === 'tree') { go(); return; } const u0 = ed.undoStack.length; withCaretNode(go, { noSent: true }); if (ed.undoStack.length !== u0) msg(`「${t.label.slice(0, 20)}」の${{ child: '子の末尾', before: '前', after: '後' }[rel]}へ移しました（Ctrl+Z で戻す）`); } };
/* 節の参照（S5）：見出しを選ぶと本文に「2. 構成」。中身は見出しの名札への参照なので、並べ替え・番号の付け替えに追う */
FORMS.secref = {
  list() { const nq = treeNorm(st.secQ || ''); return moveTargets().filter(t => t.obj && (!nq || treeNorm(t.label).includes(nq))).slice(0, 300); },
  html() { const L = this.list(); if (st.secIdx == null || st.secIdx >= L.length) st.secIdx = 0; return `<span class="ttl">節の参照を入れる</span><label>${inp('q', st.secQ || '', 'w', 'text', 'placeholder="見出しの文字で絞る"')}</label><span class="hintl">↑↓ で選び Enter。本文に「番号 題」が入り、並べ替えても追う</span><button type="button" data-act="cancel">取消 Esc</button><div class="mvlist">${L.map((t, i) => `<button type="button" class="mv${i === st.secIdx ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見出しがありません</span>'}</div>`; },
  focus: 'input[name="q"]',
  change(name) { if (name !== 'q') return; st.secQ = fval('q'); st.secIdx = 0; const box = sub.querySelector('.mvlist'); if (box) box.innerHTML = this.list().map((t, i) => `<button type="button" class="mv${i === 0 ? ' on' : ''}" data-act="m${i}" style="padding-left:${6 + Math.max(0, t.depth - 1) * 14}px">${esc(t.label)}</button>`).join('') || '<span class="info">見つかりません</span>'; },
  key(e) { FORMS.moveTo.key.call(this, e); if (e.key === 'ArrowDown' || e.key === 'ArrowUp') st.secIdx = st.moveIdx; },
  enter() { this.act('m' + (st.secIdx || 0)); },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^m(\d+)$/); if (!m) return; const t = this.list()[+m[1]]; if (!t) return; st.secQ = ''; closeForm();
    let an = t.obj.attrs.anchor; if (!an) { const used = new Set(ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean)); let k = 1; while (used.has('h' + k)) k++; an = 'h' + k; ed.mutate('', () => { t.obj.attrs.anchor = an; }); }
    ed.insertRef('§' + an); msg(`節の参照を入れました：${(ed.lay.figNums && ed.lay.figNums.get('§' + an) || {}).label || t.label}（見出しが動いても番号が追う）`); } };
/* 構成の型（S6）：骨組み（見出しと、何を書くかの手引き）を流し込む。霞が関の資料は体系も「霞が関」に */
const SKELETONS = [
  { id: 'report', name: '報告書', kasumi: false, body: '[表題]〇〇に関する報告\n[番号1]目的\n（何を報告し、何を決めてほしいかを 1 文で）\n[番号1]背景\n（なぜ今この報告か）\n[番号1]現状\n（数字と事実で）\n[番号1]課題\n（現状と目標の差）\n[番号1]対応策\n[項目1]（案 1）\n[項目1]（案 2）\n[番号1]今後の予定\n（いつ・誰が・何を）\n' },
  { id: 'plan', name: '企画書', kasumi: false, body: '[表題]〇〇の企画\n[番号1]企画の概要\n（ひと言で何をするか）\n[番号1]背景と課題\n[番号1]ねらい\n（目的と目標の数字）\n[番号1]内容\n[番号2]具体策\n[項目1]（施策）\n[番号1]体制とスケジュール\n[番号1]費用と効果\n[番号1]リスクと対応\n' },
  { id: 'minutes', name: '議事録', kasumi: false, body: '[表題]〇〇会議　議事録\n日時：\n場所：\n出席者：\n[番号1]議題\n[項目1]（議題 1）\n[番号1]議事の概要\n[番号1]決定事項\n[項目1]（決めたこと）\n[番号1]今後の対応\n[項目1]（担当・期限・内容）\n' },
  { id: 'prep', name: '提案（結論から：PREP）', kasumi: false, body: '[表題]〇〇の提案\n[番号1]結論\n（提案を 1 文で）\n[番号1]理由\n[項目1]（理由 1）\n[項目1]（理由 2）\n[番号1]具体例・根拠\n[番号1]結論（再掲）と依頼\n' },
  { id: 'kasumi1', name: '霞が関：説明資料（1 枚もの）', kasumi: true, body: '[表題]〇〇について（案）\n[番号1]背景・経緯\n[項目1]（いつ・何があったか）\n[番号1]現状と課題\n[記号1]現状\n[項目1]（数字・事実）\n[記号1]課題\n[項目1]（何が問題か）\n[番号1]対応の方向性\n[項目1]（基本的な考え方）\n[番号1]具体的な取組\n[番号2]（取組 1）\n[項目1]（内容）\n[番号2]（取組 2）\n[項目1]（内容）\n[番号1]今後のスケジュール\n[項目1]〇月　（予定）\n' },
  { id: 'kasumi2', name: '霞が関：論点整理（検討会資料）', kasumi: true, body: '[表題]〇〇に関する論点整理（案）\n[番号1]検討の経緯\n[項目1]（これまでの検討会の開催状況）\n[番号1]主な論点\n[番号2]論点 1：〇〇をどう考えるか\n[記号1]これまでの主な意見\n[項目1]（意見）\n[記号1]考えられる対応\n[項目1]（案）\n[番号2]論点 2：〇〇の範囲\n[記号1]これまでの主な意見\n[項目1]（意見）\n[番号1]今後の検討の進め方\n[項目1]（次回までに整理すること）\n' },
  { id: 'kasumi3', name: '霞が関：事業概要（予算要求）', kasumi: true, body: '[表題]〇〇事業\n[番号1]事業の目的・必要性\n[項目1]（政策目標と、なぜ国が行うか）\n[番号1]事業の概要\n[項目1]（何を・どのように）\n[番号1]事業スキーム\n[項目1]国　→　（補助・委託先）　→　（対象）\n[番号1]期待される効果（成果目標）\n[項目1]（KPI と目標年度）\n[番号1]予算額\n[項目1]令和〇年度要求額　〇〇億円（前年度　〇〇億円）\n' },
  { id: 'kasumi4', name: '霞が関：報告書（答申・中間とりまとめ）', kasumi: true, body: '[表題]〇〇について（中間とりまとめ）\n[記号1]はじめに\n（審議の経緯と、この文書の位置づけ）\n[番号1]現状と課題\n[番号2]（項目）\n[番号1]基本的な考え方\n[番号1]具体的な方策\n[番号2]（方策 1）\n[番号2]（方策 2）\n[番号1]今後の進め方\n[記号1]おわりに\n' },
];
FORMS.skeleton = {
  html() { return `<span class="ttl">構成の型</span>${SKELETONS.map((t, i) => `<button type="button" class="${t.kasumi ? 'kasumi' : ''}" data-act="t${i}"><span class="kk">${i + 1}</span>${esc(t.name)}</button>`).join('')}<label>${cyc('where', [['here', 'カーソルの後ろに'], ['new', '新しい文書で']], st.skelWhere || (ed.doc.lines.length <= 1 && !ed.doc.lines[0].segs[0].text ? 'new' : 'here'))}</label><span class="hintl">見出しと「何を書くか」の手引き（ ）が入る。霞が関の型は体系も「霞が関」（1. （1） ① と ○ ・）に</span><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'button', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('t' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^t(\d+)$/); const t = m && SKELETONS[+m[1]]; if (!t) return; const where = cycVal('where') || 'here'; st.skelWhere = where; closeForm(); if (st.mode === 'tree') exitTree(false);
    const preset = t.kasumi ? FZ.SCHEME_PRESETS.find(p => p.name === '霞が関') : null; const src = FZ.parse('#fzk 2\n---\n' + t.body);
    const applyPreset = f => { if (!preset) return; f.scheme = FZ.normalizeScheme(preset.num); f.symScheme = FZ.normalizeScheme(preset.sym, FZ.DEFAULT_SYM); f.bulletScheme = FZ.normalizeScheme(preset.bullet, FZ.DEFAULT_BULLET); f.titleLevels = preset.title; };
    if (where === 'new') { const go = () => { const d = FZ.newDoc(); d.format = JSON.parse(JSON.stringify(ed.doc.format)); applyPreset(d.format); d.lines = src.lines; d.title = ''; d.kata = t.id; ed.setDoc(FZ.normalize(d)); st.file = null; render(); msg(`「${t.name}」の型で新しい文書を作りました（（ ）の手引きを書き換える）`); }; withDiscard(go, '新しくする'); return; }
    let at = ed.caret.line + 1; while (at < ed.doc.lines.length && FZ.inTable(ed.doc, at)) at++; if (ed.doc.lines.some(l => l.attrs.style === 'title') && src.lines[0] && src.lines[0].attrs.style === 'title') src.lines.shift(); /* 題のある文書へは題の行を除いて */ ed.mutate('', () => { src.lines.forEach((ln, k) => ed.insertLine(at + k, ln)); if (preset) applyPreset(ed.doc.format); if (!ed.doc.kata) ed.doc.kata = t.id; /* 1.0.15b 型の必須の節を健康診断で見る */ ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; }); render(); scrollToCaret(true);
    msg(`「${t.name}」の骨組みを入れました（${src.lines.length} 行${preset ? '・体系を「霞が関」に' : ''}。Ctrl+Z で戻す）`, false, 7000); } };
/* 保留の島（S4）：使うか決めていない節・文を文書の外に退避。原本には残り、組版・書き出し・AI に渡す Markdown には出ない */
const parkLabel = lines => String((lines.find(l => l.segs.some(sg => sg.text.trim())) || lines[0]).segs.map(sg => sg.text).join(' ')).replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕').replace(/\s+/g, ' ').trim().slice(0, 30) || '（空）';
function parkPush(lines) { const used = new Set((ed.doc.parked || []).map(p => p.id)); let k = 1; while (used.has('p' + k)) k++; (ed.doc.parked = ed.doc.parked || []).push({ id: 'p' + k, label: parkLabel(lines), lines: JSON.parse(JSON.stringify(lines)) }); }
function parkSel() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode();
  const doRanges = (ranges, sentNode) => { if (sentNode) { const n = sentNode; const seg = n.obj.segs[0]; const ss = FZ.tree.sentences(seg.text); const x = ss[n.si]; if (!x) return false; ed.mutate('', () => { { const t0 = x.text.replace(/^[ 　]+/, ''), off = x.start + (x.text.length - t0.length), t1 = t0.replace(/[ 　]+$/, ''); const sg2 = FZ.newSeg(0, t1); sg2.marks = seg.marks.slice(off, off + t1.length); parkPush([{ segs: [sg2], attrs: {} }]); } ed.spliceSeg(seg, x.start, x.end, '', []); }); return true; }
    if (!ranges.length) return false; ed.mutate('', () => { for (const [a, b] of ranges.sort((p, q) => q[0] - p[0])) { parkPush(ed.doc.lines.slice(a, b + 1)); FZ.tree.removeRange(ed, a, b); } }); return true; };
  let done = false;
  if (st.mode === 'tree') { const sel = treeSelected().filter(n => !n.root && n !== st.tree.view.top && n.kind !== 'fig'); const sent = sel.length === 1 && sel[0].kind === 'sent' ? sel[0] : null; const tops = sel.filter(n => n.kind !== 'sent' && !sel.some(m => m !== n && FZ.tree.isAncestor(m, n)));
    done = doRanges(tops.map(n => [n.line, n.end]), sent); if (done) treeRefresh(); }
  else { const s2 = ed.sel(); if (sentSelOk()) { const tr = FZ.tree.build(ed.doc, { body: true, sentences: true }); const ln = ed.doc.lines[ed.caret.line]; const n = tr.sents.find(x => x.obj === ln && x.si === st.sentSel.si); if (n) done = doRanges([], n); st.sentSel = null; ed.anchor = null; }
    else if (s2 && s2.a.line !== s2.b.line) done = doRanges([[s2.a.line, s2.b.line]]);
    else { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(ed.doc.lines[ed.caret.line]); if (n && !(n.root || n === tr.root)) done = doRanges([[n.line, n.end]]); }
    if (done) { render(); requestOverlay(); } }
  msg(done ? `保留の島へ送りました（${(ed.doc.parked || []).length} 件。${K('parkList')} で見る・戻す。書き出しには出ない）` : '保留へ送るものがありません（節・文・範囲を選ぶ）', !done); }
/* 島の全文：保留した行を書き出しと同じ字（番号・記号つき）で */
/* 島の全文（HTML）：番号・記号と段の字下げ付きで読める形に（番号は島の中で数え直す） */
function parkHtml(p) { const f = ed.doc.format, S = FZ.normalizeScheme(f.scheme), SY = FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM), BU = FZ.normalizeScheme(f.bulletScheme || FZ.DEFAULT_BULLET, FZ.DEFAULT_BULLET), LS = FZ.normalizeScheme(f.listScheme || FZ.DEFAULT_LIST, FZ.DEFAULT_LIST);
  const cnt = [], lc = [], out = []; let base = 0;
  for (const ln of p.lines) { const a = ln.attrs, t = FZ.expandRefsText(ed.doc, ln.segs.map(sg => sg.text).join('　')); let mk = '', ind = base, bold = false;
    if (a.style === 'title') { bold = true; ind = 0; base = 0; }
    else if (a.style === 'num') { const lv = Math.min(7, a.level | 0); if (a.restart) cnt[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; cnt.length = lv + 1; cnt[lv] = (cnt[lv] || 0) + 1; mk = FZ.schemeMarker(S, lv, cnt[lv], cnt.slice(0, lv)).trim(); ind = lv; base = lv + 2; bold = true; }
    else if (a.style === 'sym') { const lv = Math.min(7, a.level | 0); mk = FZ.schemeMarker(SY, lv, 0).trim(); ind = base + lv; bold = true; }
    else if (a.list) { const lv = Math.min(7, a.list.level | 0), k = a.list.kind; lc.length = lv + 1; if (k === 'num') lc[lv] = (lc[lv] || 0) + 1; mk = k === 'cont' ? '' : k === 'arrow' ? '→' : k === 'todo' ? '❏' : k === 'done' ? '☑' : k === 'num' ? FZ.schemeMarker(LS, lv, lc[lv]).trim() : FZ.schemeMarker(BU, lv, 0).trim(); ind = base + lv * 2 + (k === 'cont' ? 1.5 : 0); }
    if (!a.list) lc.length = 0;
    out.push(`<div class="il${bold ? ' b' : ''}" style="padding-left:${ind}em">${mk ? `<span class="mk">${esc(mk)}</span>` : ''}${esc(t) || '&nbsp;'}</div>`); }
  return out.join(''); }
function drawIsland() { const el = $('island'); const on = st.form === 'parked'; document.body.classList.toggle('island', on); if (!on) { el.innerHTML = ''; return; } const P = ed.doc.parked || [];
  el.innerHTML = `<div class="islt">保留の島<span class="info">${P.length ? `${P.length} 件。戻す＝今の節（ツリーは選んだ節）の後ろへ。数字キー 1〜9 でも戻せる` : '保留しているものはありません（F3 編集の「保留」で送る）'}</span></div>` + P.map((p, i) => `<div class="isl"><div class="islh"><span class="no">${i + 1}</span><b>${esc(p.label)}</b><span class="info">${p.lines.length} 行</span><button type="button" data-isl="b${i}" title="今の節の後ろに戻す">戻す</button><button type="button" data-isl="x${i}" title="保留から消す">消す</button></div><div class="islb">${parkHtml(p)}</div></div>`).join(''); }
$('island').addEventListener('pointerdown', e => { const b = e.target.closest('button[data-isl]'); if (!b) return; e.preventDefault(); if (st.form === 'parked') FORMS.parked.act(b.dataset.isl); });
FORMS.parked = {
  html() { const P = ed.doc.parked || []; return `<span class="ttl">保留の島</span><span class="info">${P.length ? `${P.length} 件：全文は画面の下に` : '保留しているものはありません（F3 編集の「保留」で送る）'}</span><span class="hintl">保留は原本に残り、組版・書き出し・AI に渡す Markdown には出ない</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('b' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^([bx])(\d+)$/); if (!m) return; const P = ed.doc.parked || []; const p = P[+m[2]]; if (!p) return;
    if (m[1] === 'x') { ed.mutate('', () => { ed.doc.parked.splice(+m[2], 1); if (!ed.doc.parked.length) delete ed.doc.parked; }); drawSub(); msg('保留から消しました（Ctrl+Z で戻す）'); return; }
    let at; if (st.mode === 'tree') { const n = treeNodeSel(); at = n && !n.root ? n.end + 1 : ed.doc.lines.length; } else { const tr = FZ.tree.build(ed.doc, { body: true }); const n = tr.byObj.get(ed.doc.lines[ed.caret.line]); at = n ? n.end + 1 : ed.caret.line + 1; }
    const lines = JSON.parse(JSON.stringify(p.lines)); ed.mutate('', () => { lines.forEach((ln, k) => ed.insertLine(at + k, ln)); ed.doc.parked.splice(+m[2], 1); if (!ed.doc.parked.length) delete ed.doc.parked; if (st.mode !== 'tree') { ed.anchor = null; ed.caret = { line: at, seg: 0, off: 0, vcol: null, vrow: 0 }; } });
    if (st.mode === 'tree') { st.tree.sel = ed.doc.lines[at]; treeRefresh(); } else render(); drawSub(); msg(`「${p.label}」を戻しました`); } };
/* ================= AI からの戻し（X3） =================
   写した範囲（行の番号の列＋その時の全行の署名）を覚え、戻ってきた Markdown と比べて、違う所（塊）を 1 つずつ取り込む／捨てる。
   直す行はその場で直す（飾り・揃え・罫・傍点など Markdown に無いものが残る）。塊ごとに Ctrl+Z で戻せる */
const docSigs = () => ed.doc.lines.map(l => FZ.lineSig(ed.doc, l));
function rangeIdx(a, b) { const r = []; for (let k = Math.max(0, a); k <= b; k++) r.push(k); return r; }
function rememberScope(idx, what) { const base = idx ? sliceDoc(idx[0], idx[idx.length - 1]) : sliceDoc(0, ed.doc.lines.length - 1); st.aiScope = idx ? { idx, snap: docSigs(), what, base } : { whole: true, what: '文書全体', base }; } /* P17：写した時の本文（base）も覚える */
function scopeNow(sc) { if (!sc) return null; const n = ed.doc.lines.length; if (sc.whole) return rangeIdx(0, n - 1); const idx = FZ.remapIdx(sc.idx, sc.snap, docSigs()).filter(i => i < n); return idx.length ? idx : null; }
const AI_KIND = { add: '足す', del: '消す', chg: '直す' }, DIFF_CAT = { body: '本文', struct: '構造', link: 'リンク・参照', emph: '強調' };
const catLabel = h => (h.cats && h.cats.length) ? '（' + h.cats.map(c => DIFF_CAT[c]).join('・') + '）' : '';
/* 比べる範囲の候補：写した範囲・カーソル（ツリーは選んだ節）の節・文書全体 */
function aiCandidates() { const out = [], n = ed.doc.lines.length; const last = scopeNow(st.aiScope); if (last) out.push({ key: 'last', name: '写した範囲' + (st.aiScope.whole ? '（文書全体）' : '（' + st.aiScope.what + '）'), idx: last });
  let sec = null; if (st.mode === 'tree') { const t = treeNodeSel(); if (t && !t.root && t.obj && t.kind !== 'sent') { const a = ed.doc.lines.indexOf(t.obj); if (a >= 0) sec = { a, b: a + (t.end - t.line), text: t.text }; } } else { const b = sectionAt(ed.caret.line); if (b) sec = { a: b.line, b: b.end, text: b.text }; }
  if (sec) out.push({ key: 'sec', name: '「' + String(sec.text).slice(0, 12) + '」の節', idx: rangeIdx(sec.a, sec.b) });
  out.push({ key: 'doc', name: '文書全体', idx: rangeIdx(0, n - 1) }); return out; }
/* AI の返事から Markdown を取り出す（```markdown で囲まれていれば中身） */
function aiUnwrap(md) { md = String(md || '').replace(/\r\n?/g, '\n'); const m = md.match(/```(?:markdown|md)[ \t]*\n([\s\S]*?)\n```/i) || md.match(/^\s*```[ \t]*\n([\s\S]*?)\n```\s*$/); return m ? m[1] : md; }
/* 1.0.14d 役の名前付きの答え → 比べる相手のプ譜と同じ書き方（見出し・項目の段）の行に。比べる相手は写したプ譜か、カーソルのプ譜 */
function pufuReturnBlock() { const sc = scopeNow(st.aiScope); if (sc) { const pz = FZ.pufuAt(ed.doc, sc[0]); if (pz && pz.B.head === sc[0]) return pz.B; } const pz2 = FZ.pufuAt(ed.doc, ed.caret.line); return pz2 ? pz2.B : null; }
function pufuAnswerDoc(P, blk) { const L = ed.doc.lines; const head = L[blk.head]; const root0 = blk.roots.length ? L[blk.roots[0]] : null; const lvA = a => lvOfA(a); const rootLv = root0 ? lvA(root0.attrs) : lvA(head.attrs) + 1;
  const tpl = new Map(); for (let q = blk.start; q < blk.end; q++) { const it = blk.map.get(q); if (!it || it.kind === 'res' || it.kind === 'resItem' || it.kind === 'resCont') continue; const a = L[q].attrs, lv = lvA(a); if (lv >= 99) continue; if (!tpl.has(lv - rootLv)) tpl.set(lv - rootLv, a); }
  const clean = a => { const b = JSON.parse(JSON.stringify(a)); for (const k of ['pufu', 'pufuForm', 'pufuFrame', 'pufuRes', 'notes', 'anchor', 'tid', 'fw', 'restart']) delete b[k]; return b; };
  const mk = rel => { if (tpl.has(rel)) return clean(tpl.get(rel)); const r = root0 ? root0.attrs : null; if (r && r.list) return { list: { kind: 'bullet', level: Math.max(0, Math.min(7, (r.list.level | 0) + rel)) } }; if (r && (r.style === 'num' || r.style === 'sym')) return { style: r.style, level: Math.max(0, Math.min(7, (r.level | 0) + rel)) }; return { list: { kind: 'bullet', level: Math.max(0, Math.min(7, rel)) } }; };
  const d = FZ.newDoc(); d.format = JSON.parse(JSON.stringify(ed.doc.format)); const hd = clean(head.attrs); hd.pufu = true; const lines = [FZ.newLine(P.title || head.segs.map(sg => sg.text).join(''), hd)];
  for (const it of P.items) { if (it.para) { lines.push(FZ.newLine(it.text, {})); continue; } const a = mk(it.level); if (it.frame) a.pufuFrame = true; lines.push(FZ.newLine(it.text, a)); }
  if (P.res.length) { const rl = blk.res ? L[blk.res.line] : null; const ra = rl ? clean(rl.attrs) : mk(0); ra.pufuRes = true; lines.push(FZ.newLine(rl ? rl.segs.map(sg => sg.text).join('') : '資源と制約（廟算八要素）', ra)); const ia = blk.res && blk.res.items.length ? clean(L[blk.res.items[0].line].attrs) : mk(1); for (const t of P.res) lines.push(FZ.newLine(t, JSON.parse(JSON.stringify(ia)))); }
  d.lines = lines; return d; }
function aiParse(md) { st.pufuAnswer = null; if (FZ.pufuIsMd && FZ.pufuIsMd(md)) { const blk = pufuReturnBlock(); if (blk) { const P = FZ.pufuFromMd(aiUnwrap(md)); if (P.items.length) { st.pufuAnswer = P; return pufuAnswerDoc(P, blk); } } }
  const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(ed.doc.format)); const anchors = ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean), figs = ed.figList().map(x => x.fg.id); return FZ.fromGfm(aiUnwrap(md), base, { refTargets: { anchors, figs } }); }
function aiCompare(md, pick) { if (!String(md || '').trim()) { msg('貼り付けた Markdown がありません', true); return false; }
  let B; try { B = aiParse(md); } catch (e) { msg('読めませんでした：' + e.message, true); return false; }
  if (!B.lines.some(l => FZ.lineSig(B, l) !== '|')) { msg('貼り付けたものに中身がありません（Markdown の本文を貼ってください）', true); return false; } /* 空を比べると「すべて消す」になる */
  const sigA = docSigs(); const cands = aiCandidates(); let best = null;
  for (const c of (pick && pick !== 'auto' ? cands.filter(x => x.key === pick) : cands)) { const B2 = JSON.parse(JSON.stringify(B)); FZ.alignLevels(ed.doc, c.idx, B2); const sigB = B2.lines.map(l => FZ.lineSig(B2, l)); const H = FZ.diffDocs(ed.doc, c.idx, B2, sigA, sigB); const cost = H.reduce((t, h) => t + h.size, 0);
    if (!best || cost < best.cost) best = { c, B: B2, sigB, cost }; } /* 自動：違いのいちばん少ない範囲（同じなら写した範囲・狭い範囲を先に） */
  if (!best) { msg('比べる範囲がありません', true); return false; }
  st.aiBack = { B: best.B, sigB: best.sigB, idx: best.c.idx, snap: sigA, skip: new Set(), i: 0, hunks: [], name: best.c.name, auto: !pick || pick === 'auto', taken: 0, md, base: best.c.key === 'last' && st.aiScope && st.aiScope.base ? st.aiScope.base : null, showSelf: false, selfN: 0 };
  aiSync(); aiShow();
  { const P = st.pufuAnswer; if (P && (P.changes.length || P.questions.length || P.notes.length || P.warn.length)) { const items = [...P.changes.filter(t => !/^なし$/.test(t)).map(t => ({ what: '直した・変えた所：' + t, lines: [] })), ...P.questions.map(t => ({ what: '問い：' + t.replace(/^\d+[.)．]\s*/, ''), lines: [] })), ...P.notes.map(t => ({ what: '注：' + t, lines: [] })), ...P.warn.map(t => ({ what: '取り込みの注意：' + t, lines: [] }))]; if (items.length) { setConvLog({ title: 'AI の答えの注記（プ譜）', target: 'ai', items, time: Date.now() }); msg(`AI の答えの注記 ${items.length} 件を右の欄「変換の記録」に置きました（${K('convLog')}）`, false, 7000); } } }
  return true; }
function aiSync() { const S = st.aiBack; if (!S) return; const now = docSigs(); S.idx = [...new Set(FZ.remapIdx(S.idx, S.snap, now))].filter(i => i < ed.doc.lines.length); S.snap = now; /* 文書が他の操作で変わっていても（Ctrl+Z など）範囲を付け替える */
  S.hunks = FZ.diffDocs(ed.doc, S.idx, S.B, now, S.sigB).filter(h => !S.skip.has(h.key)); threeWay(S); S.selfN = S.hunks.filter(h => h.who === 'self').length; if (!S.showSelf) S.hunks = S.hunks.filter(h => h.who !== 'self'); if (S.i >= S.hunks.length) S.i = Math.max(0, S.hunks.length - 1); } /* P17：自分だけの直しは既定で候補にしない */
const aiLine = h => Math.min(h.rem.length ? h.rem[0] : Math.max(0, h.at - 1), ed.doc.lines.length - 1); /* 足す所：その前の行（の末尾）に */
function aiShow() { const S = st.aiBack; const h = S && S.hunks[S.i]; if (!h) { render(); return; } const L = aiLine(h);
  if (st.mode === 'tree') { const v = st.tree.view; let n = null; if (v) for (let k = L; k >= 0 && !n; k--) n = v.tr.byObj.get(ed.doc.lines[k]) || null; if (n) { for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); } st.tree.sel = n.obj; } render(); treeScrollToSel(); }
  else { const ln = ed.doc.lines[L], end = !h.rem.length && h.at > 0; const sg = end ? ln.segs.length - 1 : 0; ed.anchor = null; ed.caret = { line: L, seg: sg, off: end ? ln.segs[sg].text.length : 0, vcol: null, vrow: 0 }; ed.onCaret(); render(); scrollToCaret(true); requestOverlay(); } }
/* 範囲の付け替え（自分で取り込んだ時）：塊の窓 [s0, e0] が新しい行に置き換わり、後ろは d だけずれる */
function aiShiftIdx(idx, h, d) { const s0 = h.rem.length ? h.rem[0] : h.at, e0 = h.rem.length ? h.rem[h.rem.length - 1] : h.at - 1; const out = new Set(); for (const i of idx) { if (i < s0) out.add(i); else if (i > e0) out.add(i + d); } for (let k = s0; k <= e0 + d; k++) out.add(k); return [...out].filter(i => i >= 0).sort((x, y) => x - y); }
function aiTake(all) { const S = st.aiBack; if (!S) return; aiSync(); const list = all ? S.hunks.slice() : [S.hunks[S.i]].filter(Boolean); if (!list.length) return; const warn = all && FZ.collate ? list.filter(h => !h.detail && aiPreview(h).col.n).length : 0; /* 1.0.16a 照合 */
  const sigA = docSigs(); let idx = S.idx, first = 0; const keepMode = st.mode;
  ed.mutate('', () => { for (const h of list.slice().reverse()) { const n0 = ed.doc.lines.length; first = FZ.applyHunk(ed, S.B, h, { sigA, sigB: S.sigB }); idx = aiShiftIdx(idx, h, ed.doc.lines.length - n0); } }); /* 下から：上の塊の位置は変わらない */
  S.idx = idx; S.snap = docSigs(); S.taken += list.length; aiSync(); if (keepMode === 'tree') treeRefresh();
  if (S.hunks.length) aiShow(); else { if (keepMode !== 'tree') { ed.anchor = null; ed.caret = { line: Math.min(first, ed.doc.lines.length - 1), seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); scrollToCaret(true); } render(); }
  drawSub(); msg(`${list.length} 件を取り込みました（Ctrl+Z で戻す）${warn ? `。うち ${warn} 件は照合で数・否定・敬称・日付が変わる所（確かめる）` : ''}${S.hunks.length ? `：残り ${S.hunks.length} 件` : '：違いはもうありません'}`, !!warn, warn ? 9000 : undefined); }
function aiDrop() { const S = st.aiBack; const h = S && S.hunks[S.i]; if (!h) return; S.skip.add(h.key); aiSync(); aiShow(); drawSub(); }
function aiStep(d) { const S = st.aiBack; if (!S || !S.hunks.length) return; S.i = (S.i + d + S.hunks.length) % S.hunks.length; aiShow(); drawSub(); }
/* 塊の中身を短く：直すは「頭…〔今→案〕…尻」 */
function detailPreview(h) { const d = h.detail; const sp = s => s ? s.split('\u0002') : []; const parts = [];
  if (d.a.link !== d.b.link) { const A = sp(d.a.link), B = sp(d.b.link); const gone = A.filter(x => !B.includes(x)), come = B.filter(x => !A.includes(x)); const f = x => { const k = x.indexOf('>'); return `「${x.slice(0, k)}」→ ${x.slice(k + 1)}`; };
    parts.push('リンク先 ' + (gone.length ? `<del>${esc(gone.map(f).join('、').slice(0, 60))}</del>` : '') + (come.length ? `<ins>${esc(come.map(f).join('、').slice(0, 60))}</ins>` : '')); }
  if (d.a.emph !== d.b.emph) { const nm = v => { const M = FZ.M; const o = []; if (v & M.BOLD) o.push('太字'); if (v & M.DOT) o.push('傍点'); if (v & M.UNDER) o.push('下線'); if (v & M.STRIKE) o.push('取消線'); if (v & M.SHADE) o.push('網掛け'); if (v & M.CODE) o.push('コード'); return o.join('・'); };
    const f = x => { const k = x.indexOf(':'); return `${x.slice(k + 1)}（${nm(+x.slice(0, k))}）`; }; const A = sp(d.a.emph), B = sp(d.b.emph); const gone = A.filter(x => !B.includes(x)), come = B.filter(x => !A.includes(x));
    parts.push('強調 ' + (gone.length ? `<del>${esc(gone.map(f).join('、').slice(0, 60))}</del>` : '') + (come.length ? `<ins>${esc(come.map(f).join('、').slice(0, 60))}</ins>` : '')); }
  const tx = FZ.expandRefsText(ed.doc, ed.doc.lines[h.rem[0]].segs.map(sg => sg.text).join(' ')).replace(/\s+/g, ' ').trim(); return { html: parts.join('　'), full: '字は同じ：' + tx }; }
function aiPreview(h) { if (h.detail) return detailPreview(h); const S = st.aiBack; const tx = (doc, l) => FZ.expandRefsText(doc, l.segs.map(sg => sg.text).join(' ')).replace(/\s+/g, ' ').trim(); const isC = (doc, l) => FZ.lineSig(doc, l) !== '|';
  const A = h.rem.map(i => ed.doc.lines[i]).filter(l => isC(ed.doc, l)).map(l => tx(ed.doc, l)), Bt = []; for (let j = h.b[0]; j < h.b[1]; j++) if (S.sigB[j] !== '|') Bt.push(tx(S.B, S.B.lines[j]));
  const cut = (t, n) => [...t].length > n ? [...t].slice(0, n).join('') + '…' : t; const more = (L) => L.length > 1 ? `<span class="info">（ほか ${L.length - 1} 行）</span>` : '';
  const full = (A.length ? '今：' + A.join(' / ') : '') + (A.length && Bt.length ? '\n' : '') + (Bt.length ? '案：' + Bt.join(' / ') : '');
  let html; if (h.kind === 'chg' && A.length && Bt.length) { const a = A[0], b = Bt[0]; const n = Math.min(a.length, b.length); let p = 0; while (p < n && a[p] === b[p]) p++; let q = 0; while (q < n - p && a[a.length - 1 - q] === b[b.length - 1 - q]) q++;
      const hira = c => /[\u3041-\u309f]/.test(c || ''), kan = c => /[\u4e00-\u9fff\u3005]/.test(c || ''); while (q > 0 && hira(a[a.length - q]) && (kan(a[a.length - q - 1]) || kan(b[b.length - q - 1]))) q--; /* 送り仮名は語に含めて見せる（「重い→大きい」） */
      const pre = a.slice(0, p), mid1 = a.slice(p, a.length - q), mid2 = b.slice(p, b.length - q), suf = a.slice(a.length - q); const pr = [...pre].length > 10 ? '…' + [...pre].slice(-10).join('') : pre, su = [...suf].length > 10 ? [...suf].slice(0, 10).join('') + '…' : suf;
      html = `${esc(pr)}${mid1 ? `<del>${esc(cut(mid1, 24))}</del>` : ''}${mid2 ? `<ins>${esc(cut(mid2, 24))}</ins>` : ''}${esc(su)}${more(A.length > Bt.length ? A : Bt)}`; }
  else if (h.kind === 'add') html = `<ins>${esc(cut(Bt[0] || '', 40))}</ins>${more(Bt)}`; else html = `<del>${esc(cut(A[0] || '', 40))}</del>${more(A)}`;
  const col = FZ.collate ? FZ.collate(A.join('\n'), Bt.join('\n')) : null; /* 1.0.16a 照合：数・否定・敬称・日付が変わる所は、取り込む前に確かめる */
  return { html, full: full + (col && col.n ? '\n照合：' + col.text : ''), col }; }
FORMS.aiback = {
  html() { const S = st.aiBack;
    if (!S) { const cs = aiCandidates(); return `<span class="ttl">AI から戻す</span><label>範囲 ${cyc('scope', [['auto', '自動（いちばん合う所）'], ...cs.map(c => [c.key, c.name])], st.aiPick || 'auto')}</label><textarea name="md" class="chdata aimd" rows="3" spellcheck="false" placeholder="AI が直した Markdown をここに貼る（${K('aiCopySec')} で写して渡したもの）"></textarea><button type="button" data-act="file" title="Markdown ファイルから読む">ファイル…</button><span class="hintl">貼って Ctrl+Enter で比べる。違う所を 1 つずつ見て取り込む・捨てる（飾り・罫は今のまま）</span><button type="button" class="pri" data-act="cmp">比べる</button><button type="button" data-act="cancel">閉じる Esc</button>`; }
    /* 帯は 2 段に収める：説明は title に */
    const WHO = { ai: '<span title="写した後に AI だけが直した所">AI だけ</span>', self: '<span title="自分だけが直した所。取り込むと自分の直しが AI の古い字に戻る">自分だけ</span>', both: '<b class="alert" title="自分も AI も直した所。どちらを残すか選ぶ">両方で変更</b>' };
    const mode = S.base ? `<span title="写した時・今・返事の 3 つを比べ、誰が直したかで分けています">三者比較</span>${S.selfN ? `<span title="AI が元の字のまま返した所（自分だけの直し）は${S.showSelf ? '候補に出しています' : '候補に出さず、自分の直しを保ちます'}">・自分の直し ${S.selfN} 件${S.showSelf ? '表示' : '保持'}</span>` : ''}` : '<span title="写した時の本文が無いので、今と返事だけを比べています">二者比較</span>';
    const h = S.hunks[S.i]; const tail = `<span class="info">${mode}　範囲：${esc(S.name)}${S.auto ? '（自動）' : ''}${S.skip.size ? `・捨てた ${S.skip.size}` : ''}${S.taken ? `・取り込んだ ${S.taken}` : ''}</span>${S.selfN ? `<button type="button" data-act="selfs" title="AI が元の字のまま返した所（自分だけの直し）も候補に出す／隠す">${S.showSelf ? '自分の直しを隠す' : '自分の直しも見る'}</button>` : ''}${S.hist ? '' : '<button type="button" data-act="back" title="貼り直す・範囲を選び直す">貼り直す</button>'}<button type="button" data-act="cancel">閉じる Esc</button>`;
    if (!h) return `<span class="ttl">${S.title || 'AI からの戻し'}</span><span class="info">違いはありません${S.taken || S.skip.size ? '（すべて見終わりました）' : '（同じ中身です）'}</span><span class="hintl" title="比べないもの：${esc(FZ.DIFF_SKIP)}">字・種類・リンク先・強調を比べました（比べないもの：${esc(FZ.DIFF_SKIP)}）</span>${tail}`;
    const pv = aiPreview(h); return `<span class="ttl">${S.title || 'AI からの戻し'}</span><span class="info" title="比べないもの：${esc(FZ.DIFF_SKIP)}"><b>${S.i + 1}</b>/${S.hunks.length}　${AI_KIND[h.kind]}${catLabel(h)}${h.who ? '　' + WHO[h.who] : ''}</span>${pv.col && pv.col.n ? `<b class="alert shogo" title="照合：${esc(pv.col.text)}（取り込む前に確かめる）">止 照合：${esc(pv.col.items.map(x => x.kind).join('・'))}</b>` : ''}<span class="aiprev" title="${esc(pv.full)}">${pv.html}</span><button type="button" data-act="prev" title="前の違い（↑）">↑</button><button type="button" data-act="next" title="次の違い（↓）">↓</button><button type="button" class="pri" data-act="take" title="この違いを取り込む（Enter）">取り込む</button><button type="button" data-act="drop" title="この違いを捨てる（Delete）">捨てる</button><button type="button" data-act="all" title="残りの違いをすべて取り込む（1 回の Ctrl+Z で戻る）">残りを全部</button>${tail}`; },
  get focus() { return st.aiBack ? 'button.pri' : 'textarea'; },
  enter(e) { if (!st.aiBack) { if (e && e.target && e.target.tagName === 'TEXTAREA' || (e && (e.ctrlKey || e.metaKey))) this.act('cmp'); return; } this.act('take'); },
  key(e) { if (!st.aiBack) return; const tag = e.target && e.target.tagName;
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); if (ed.undo()) { aiSync(); if (st.mode === 'tree') treeRefresh(); aiShow(); drawSub(); msg('元に戻しました'); } return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); if (ed.redo()) { aiSync(); if (st.mode === 'tree') treeRefresh(); aiShow(); drawSub(); } return; }
    if (tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'INPUT') return;
    if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') { e.preventDefault(); this.act('prev'); } else if (e.key === 'ArrowDown' || e.key === 'ArrowRight') { e.preventDefault(); this.act('next'); } else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); this.act('drop'); } },
  change(name) { if (name === 'scope') st.aiPick = cycVal('scope'); },
  act(a) { if (a === 'cancel') { closeForm(); return; }
    if (a === 'cmp') { let md = fval('md'); { const P = FZ.askParse ? FZ.askParse(md) : null; if (P && P.ok) { const r = rqTake(P); if (r === null) return; if (!r) { closeForm(); return; } md = r; } } /* 1.0.16b 区切りつきの答え */ st.aiPick = cycVal('scope') || 'auto'; if (aiCompare(md, st.aiPick)) { drawSub(); const S = st.aiBack; msg((st.rqAnswer && st.rqAnswer.hasDraft ? `判定は右の欄、指摘は付箋 ${st.rqAnswer.made} 枚${st.rqAnswer.lost ? `（場所の分からない ${st.rqAnswer.lost} 件は欄に）` : ''}。稿との` : '') + (S.hunks.length ? `違いが ${S.hunks.length} 件あります：Enter で取り込む、Delete で捨てる、↑↓ で移る` : '違いはありません'), st.rqAnswer && st.rqAnswer.level === '止', 8000); st.rqAnswer = null; } return; }
    if (a === 'file') { const inp2 = document.createElement('input'); inp2.type = 'file'; inp2.accept = '.md,.markdown,.txt,text/markdown,text/plain'; inp2.onchange = async () => { const f = inp2.files[0]; if (!f) return; const t = await f.text(); const ta2 = sub.querySelector('textarea[name="md"]'); if (ta2) ta2.value = t; this.act('cmp'); }; inp2.click(); return; }
    if (a === 'selfs' && st.aiBack) { st.aiBack.showSelf = !st.aiBack.showSelf; aiSync(); aiShow(); drawSub(); return; }
    if (a === 'back') { const md = st.aiBack ? st.aiBack.md : ''; st.aiBack = null; drawSub(); const ta2 = sub.querySelector('textarea[name="md"]'); if (ta2) ta2.value = md || ''; render(); return; }
    if (a === 'take') aiTake(false); else if (a === 'all') aiTake(true); else if (a === 'drop') aiDrop(); else if (a === 'prev') aiStep(-1); else if (a === 'next') aiStep(1); } };
function aiReturn() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); if (st.form === 'aiback') { closeForm(); return; } st.aiBack = null; openForm('aiback'); }
/* ================= 霞が関型の区画（V3） =================
   見出しに attrs.panels（2〜4）：その子の節（見出し・項目）を横に並べた枠の区画に組む。区画の見出しは帯（黒地白抜き／網／下線） */
function panelTarget(up) { const tr = FZ.tree.build(ed.doc, {}); let n = null;
  if (st.panelObj && up) { n = tr.byObj.get(st.panelObj); if (n) n = n.parent; }
  else if (st.mode === 'tree') { const t = treeNodeSel(); n = t && t.obj ? tr.byObj.get(t.obj) || null : null; } else n = FZ.tree.nodeAt(tr, ed.caret.line);
  const isHead = x => x && (x.kind === 'title' || x.kind === 'num' || x.kind === 'sym'); const kids = x => x.children.filter(c => c.kind !== 'body' && c.kind !== 'block');
  if (!up) { for (let p = n; p && !p.root; p = p.parent) if (p.obj && p.obj.attrs.panels) return p; } /* 区画の中なら、その区画の見出し */
  while (n && !n.root && !(isHead(n) && kids(n).length >= 2)) n = n.parent; return n && !n.root ? n : null; }
function openPanels() { if (st.mode !== 'tree' && st.mode !== 'text') exitMode(); const n = panelTarget(false); st.panelObj = n ? n.obj : null; if (!n) { msg('区画にできる節がありません（子の見出し・項目を 2 つ以上持つ見出しで）', true); return; } toggleForm('panels'); }
/* 1.0.12c 区画の型（霞が関の 1 枚もの）：wide は全幅にする子の番号（負は後ろから） */
const PANEL_TPL = [{ id: 'lr21', label: '左右 2:1', panels: 2, ratio: [2, 1] }, { id: 'lr12', label: '左右 1:2', panels: 2, ratio: [1, 2] }, { id: 'top2', label: '上に全幅＋下に 2 列', panels: 2, wide: [0] }, { id: 'c3end', label: '3 列＋結論の帯', panels: 3, wide: [-1] }, { id: 'top3', label: '上に全幅＋下に 3 列', panels: 3, wide: [0] }, { id: 'g22end', label: '2×2＋結論の帯', panels: 2, wide: [-1] }, { id: 'sand', label: '全幅＋2 列＋全幅', panels: 2, wide: [0, -1] }];
FORMS.panels = {
  node() { const tr = FZ.tree.build(ed.doc, {}); return st.panelObj ? tr.byObj.get(st.panelObj) || null : null; },
  html() { const n = this.node(); if (!n) return `<span class="ttl">区画</span><span class="info alert">区画にできる節がありません</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    const a = n.obj.attrs, m = n.children.filter(c => c.kind !== 'body' && c.kind !== 'block').length;
    const cur = String(a.panels || 0), cols = a.panels === 'v' ? 1 : a.panels === 'h' ? m : (a.panels | 0), rows = cols ? Math.ceil(m / cols) : 0;
    return `<span class="ttl">区画</span><span class="info">「${esc(String(n.text).slice(0, 14))}」の子 ${m} 個${cols ? `（縦 ${rows}×横 ${cols}）` : ''}を</span><label>並べ方 ${cyc('n', [['0', '並べない'], ['h', '横に並べる'], ['v', '縦に並べる'], ['2', '縦横 2 列'], ['3', '縦横 3 列'], ['4', '縦横 4 列'], ['5', '縦横 5 列'], ['6', '縦横 6 列']], cur)}</label><label>見出し ${cyc('head', [['dark', '黒地白抜き'], ['ink', '濃灰白抜き'], ['gray', '網'], ['line', '下線']], a.panelHead || 'dark')}</label><label>つなぎ ${cyc('link', [['', 'なし'], ['arrow', '矢印（→）'], ['tri', '三角（▶）']], a.panelLink || '')}</label><label title="霞が関の 1 枚ものによくある組み方。選ぶと並べ方・幅の比・全幅の区画をまとめて設定する">型 ${cyc('tpl', [['', '—'], ...PANEL_TPL.map(t => [t.id, t.label])], '')}</label><label title="列の幅の比（例 3:2、2:1:1）。空なら等分。区画の境の縦罫をドラッグしても変わる">幅の比 ${inp('ratio', Array.isArray(a.panelRatio) ? a.panelRatio.join(':') : '', 's')}</label><button type="button" data-act="ratio">比を適用</button><button type="button" data-act="wide" title="カーソルのある区画を全幅に（段を 1 つ使う）／戻す">全幅</button><button type="button" data-act="up" title="一つ上の見出しを区画の親に">一つ上へ</button><span class="hintl">子の節がそれぞれ枠の区画になる（霞が関の 1 枚もの）。中身は文書のまま・ツリーでも直せる</span><button type="button" class="pri" data-act="ok">確定 Enter</button><button type="button" data-act="cancel" title="この欄を開いてからの変更を元に戻して閉じる">元に戻す Esc</button>`; },
  focus: 'select', change(name) { if (name === 'tpl') { const tp = PANEL_TPL.find(t => t.id === cycVal('tpl')); const n = this.node(); if (!tp || !n) return; const a = n.obj.attrs; const kids = n.children.filter(c => c.kind !== 'body' && c.kind !== 'block').map(c => c.obj); ed.mutate('', () => { a.panels = tp.panels; if (tp.ratio) a.panelRatio = tp.ratio.slice(); else delete a.panelRatio; kids.forEach((o, k) => { const w = (tp.wide || []).some(x => x === k || (x < 0 && kids.length + x === k)); if (w) o.attrs.panelWide = true; else delete o.attrs.panelWide; }); }); if (st.mode === 'tree') treeRefresh(); else render(); msg(`区画を「${tp.label}」に組みました（${K('undo')} で戻す）`); drawSub(); return; } /* 1.0.12c 型 */ if (name !== 'n' && name !== 'head' && name !== 'link') return; const n = this.node(); if (!n) return; const raw = cycVal('n'), v = raw === 'h' || raw === 'v' ? raw : (+raw || 0), h = cycVal('head'), lk = cycVal('link') || ''; const a = n.obj.attrs;
    if ((a.panels || 0) === v && (a.panelHead || 'dark') === h && (a.panelLink || '') === lk) return; const L = ed.doc.lines.indexOf(n.obj);
    ed.mutate('', () => { if (v) a.panels = v; else delete a.panels; if (h && h !== 'dark') a.panelHead = h; else delete a.panelHead; if (lk) a.panelLink = lk; else delete a.panelLink; }); if (st.mode === 'tree') treeRefresh(); else render(); if (L >= 0) msg(v ? `「${String(n.text).slice(0, 12)}」の子を${v === 'h' ? '横に並べた' : v === 'v' ? '縦に並べた' : ` ${v} 列の`}区画にしました（Ctrl+Z で戻す）` : '区画をやめました'); drawSub(); },
  enter() { closeForm(); },
  act(a) { if (a === 'cancel') { if (this.node()) cancelForm(); else closeForm(); return; } if (a === 'ok') { closeForm(); return; } if (a === 'wide') { run('panelWide'); drawSub(); return; } if (a === 'ratio') { const n = this.node(); if (!n) return; const raw = String(fval('ratio') || '').trim(); const r = raw ? raw.split(/[:：,，\s]+/).map(Number).filter(x => x > 0) : []; const at = n.obj.attrs; ed.mutate('', () => { if (r.length > 1 && !r.every(x => x === r[0])) at.panelRatio = r; else delete at.panelRatio; }); render(); msg(r.length > 1 ? '区画の幅の比を ' + r.join(':') + ' にしました（列の数と合わないときは等分）' : '区画の幅を等分にしました'); drawSub(); return; } /* 1.0.12c 幅の比 */ if (a === 'up') { const n = panelTarget(true); if (n) { st.panelObj = n.obj; drawSub(); } else msg('これより上に区画にできる見出しはありません', true); } } };
/* 構造の点検（S2） */
const KEITAI = /(です|ます|でした|ました|ません|でしょう|ください|ましょう)[。．]?[」』）)]*$/, JOTAI = /(である|だ|た|ない|る|う|い|ぬ|か)[。．][」』）)]*$/;
function structIssues() { const tr = FZ.tree.build(ed.doc, { body: true }); const out = []; const add = (n, kind, msg2, extra = {}) => out.push({ line: n.line, obj: n.obj, kind, msg: msg2, ...extra });
  for (const n of tr.nodes) { if (n.kind === 'title' || n.kind === 'num' || n.kind === 'sym' || n.kind === 'list') { const sameFam = n.children.filter(c => c.kind === 'num' || c.kind === 'sym' || c.kind === 'list');
      if (sameFam.length === 1 && n.kind !== 'title') add(n, 'one', '子が 1 つだけ（分けるなら 2 つ以上、でなければ上の段に含める）');
      if ((n.kind === 'num' || n.kind === 'sym') && !n.children.length) add(n, 'empty', '中身がない（本文・箇条書き・子の見出しが無い）');
      if (n.kind === 'num' && n.parent && n.parent.kind === 'num' && n.level > n.parent.level + 1) add(n, 'jump', `段が飛んでいる（${n.parent.level + 1} 段の下に ${n.level + 1} 段）`);
      if (n.kind === 'num' && (!n.parent || n.parent.kind !== 'num') && n.level > 0 && !tr.nodes.some(m => m.kind === 'num' && m.level < n.level && m.line < n.line)) add(n, 'jump', `段が飛んでいる（上に浅い番号見出しが無いのに ${n.level + 1} 段）`);
      if (n.obj && typeof n.obj.attrs.restart === 'number') { const sib = n.parent.children.filter(c => c.kind === n.kind && c.level === n.level); const k = sib.indexOf(n); if (k > 0 && n.obj.attrs.restart > k + 1) add(n, 'jump', `番号が飛ぶ（${k + 1} の所が ${n.obj.attrs.restart}）`); } } }
  const sents = []; for (const n of tr.nodes) { if ((n.kind !== 'body' && n.kind !== 'list') || !n.obj || n.obj.segs.length !== 1) continue; const ss = FZ.tree.sentences(n.obj.segs[0].text); ss.forEach((x, k) => sents.push({ n, x, k })); }
  for (const e of sents) { const len = [...e.x.text.replace(/[\u{F0000}-\u{FFFFD}]/gu, '図')].length; if (len > 80) add(e.n, 'long', `長い文（${len} 字。80 字までが読みやすい）`, { si: e.k, a: e.x.start, b: e.x.start + e.x.text.length }); }
  const cls = sents.map(e => { const t = e.x.text.trim(); return KEITAI.test(t) ? 'k' : JOTAI.test(t) ? 'j' : null; }); const nk = cls.filter(c => c === 'k').length, nj = cls.filter(c => c === 'j').length;
  if (nk && nj) { const minor = nk >= nj ? 'j' : 'k'; sents.forEach((e, i) => { if (cls[i] === minor) add(e.n, 'style', `文末が${minor === 'j' ? '常体（だ・である）' : '敬体（です・ます）'}（この文書は${minor === 'j' ? '敬体' : '常体'}が多い）`, { si: e.k, a: e.x.start, b: e.x.start + e.x.text.length }); }); }
  out.sort((p, q) => p.line - q.line || (p.a || 0) - (q.a || 0)); return out; }
const CHECK_NAMES = { one: '子が 1 つ', empty: '中身なし', long: '長い文', style: '文末の不統一', jump: '段・番号の飛び' };
function checkStep(d) { const L = structIssues(); if (!L.length) { msg('気になる所はありません'); return; } st.checkIdx = st.checkIdx == null ? (d > 0 ? 0 : L.length - 1) : (st.checkIdx + d + L.length) % L.length; const it = L[st.checkIdx];
  if (st.mode === 'tree') { const v = st.tree.view; const n = v && v.tr.byObj.get(it.obj); if (n) { for (let p = n.parent; p; p = p.parent) { const pk = treeKey(p); if (typeof pk === 'object') st.tree.folds.delete(pk); } if ((n.kind === 'body') && st.tree.depth > 0) st.tree.depth = 0; st.tree.sel = it.obj; render(); treeScrollToSel(); } }
  else { const L2 = ed.doc.lines.indexOf(it.obj); if (L2 >= 0) { if (it.a != null) { ed.anchor = { line: L2, seg: 0, off: it.a }; ed.caret = { line: L2, seg: 0, off: it.b, vcol: null, vrow: 0 }; st.sentSel = { obj: it.obj, si: it.si, a: it.a, b: it.b, n: 2 }; } else { ed.anchor = null; ed.caret = { line: L2, seg: 0, off: 0, vcol: null, vrow: 0 }; } ed.onCaret(); scrollToCaret(true); requestOverlay(); } }
  const info = sub.querySelector('.ckinfo'); if (info) info.textContent = `${st.checkIdx + 1}/${L.length}：${CHECK_NAMES[it.kind]}　${it.msg}`; }
FORMS.scheck = {
  html() { const L = structIssues(); const by = {}; for (const it of L) by[it.kind] = (by[it.kind] || 0) + 1; st.checkIdx = null;
    return `<span class="ttl">構造の点検</span><span class="info">${L.length ? Object.keys(CHECK_NAMES).filter(k => by[k]).map(k => `${CHECK_NAMES[k]} <b>${by[k]}</b>`).join('　') : '気になる所はありません'}</span><button type="button" data-act="prev">↑ 前</button><button type="button" class="pri" data-act="next">次 ↓</button><span class="info ckinfo">${L.length ? `${L.length} 件：Enter で順に見る（ツリーでは節に「！」）` : ''}</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.pri', enter(e) { this.act(e && e.shiftKey ? 'prev' : 'next'); },
  act(a) { if (a === 'cancel') { closeForm(); if (st.mode === 'tree') render(); return; } if (a === 'next' || a === 'prev') checkStep(a === 'next' ? 1 : -1); } };
/* 文の分け方（S7） */
FORMS.sentopt = {
  html() { const o = FZ.tree.sentOpts; return `<span class="ttl">文の分け方</span><label>「．」も文末に ${cyc('period', [['0', 'しない'], ['1', 'する']], o.period ? '1' : '0')}</label><label>箇条書きの中の文 ${cyc('lists', [['0', '分けない'], ['1', '分ける']], o.lists ? '1' : '0')}</label><span class="hintl">ツリーの深さ「文」・文を選ぶ・構造の点検に効く（この機械の設定）</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'select', enter() { this.act('apply'); },
  act(a) { if (a !== 'apply') { closeForm(); return; } FZ.tree.sentOpts = { period: cycVal('period') === '1', lists: cycVal('lists') === '1' }; try { localStorage.setItem('fz.sentOpts', JSON.stringify(FZ.tree.sentOpts)); } catch (e) { /* 保存できなくても今は効く */ } closeForm(); render(); msg('文の分け方を変えました'); } };
try { const o = JSON.parse(localStorage.getItem('fz.sentOpts') || 'null'); if (o) FZ.tree.sentOpts = { period: !!o.period, lists: !!o.lists }; } catch (e) { /* 既定のまま */ }
/* 番号・記号の形（今の節の種類と段。この段のものすべて） */
FORMS.marker = {
  node() { if (st.mode === 'tree') return treeNodeSel(); const tr = FZ.tree.build(ed.doc, { body: true }); return tr.byObj.get(ed.doc.lines[ed.caret.line]) || null; },
  choices() { const n = this.node(); const m = n && treeMarkerNow(n); if (!m) return null; const ch = treeMarkerChoices(m.k); if (!ch.includes(m.tok)) ch.unshift(m.tok); return { m, ch }; },
  html() { const c = this.choices(); if (!c) return `<span class="ttl">番号・記号の形</span><span class="info alert">番号見出し・記号見出し・箇条書きの行（節）で使います</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    return `<span class="ttl">${esc(c.m.name)}${c.m.lv + 1} の形</span>${c.ch.map((t, i) => `<button type="button" class="pal${t === c.m.tok ? ' on' : ''}" data-act="t${i}" title="${esc(t === FZ.NONE_TOKEN ? '番号・記号なし' : t)}">${i < 9 ? `<span class="kk">${i + 1}</span>` : ''}${esc(t === FZ.NONE_TOKEN ? 'なし' : t)}</button>`).join('')}<span class="hintl">この段のものすべてが変わる。全体は ${K('scheme')}</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.on', key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('t' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^t(\d+)$/); const c = this.choices(); if (!m || !c) return; const tok = c.ch[+m[1]]; if (!tok) return;
    if (st.mode === 'tree') treeSetMarker(tok); else withCaretNode(() => treeSetMarker(tok), { noSent: true }); drawSub(); } };
/* ================= グラフ ================= */
/* 表の範囲（今の行を含む表）→ { a, b, rows: [[セルの文字]] } */
function tableAt(line) { const doc = ed.doc; if (!FZ.inTable(doc, line)) return null; let a = line, b = line; while (a > 0 && FZ.inTable(doc, a - 1)) a--; while (b + 1 < doc.lines.length && FZ.inTable(doc, b + 1)) b++;
  const cols = doc.format.cols; const rows = []; for (let k = a; k <= b; k++) { const ln = doc.lines[k]; rows.push(FZ.cellsAt(doc, k, cols).map(c => ln.segs.filter(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6).map(s => s.text).join('').trim())); } return { a, b, rows }; }
function chartCmd() {
  if (st.mode === 'tree') exitTree(false); else if (st.mode !== 'text') exitMode();
  const here = (ed.line().attrs.figs || []).find(fg => fg.chart); if (here) { st.figSel = here.id; openForm('chart'); return; }
  let t = tableAt(ed.caret.line); if (!t && ed.caret.line > 0 && !ed.line().segs.some(sg => sg.text.trim())) t = tableAt(ed.caret.line - 1); /* 表のすぐ下の空行（Excel のセルを貼った直後）でも、その表から */
  if (t) { if (!FZ.chartable(t.rows)) { msg('この表には数がありません（グラフにできるのは数の入った表）', true); return; }
    const chart = FZ.chartFromGrid(t.rows); const host = t.b + 1; let id; ed.mutate('', () => { const top = ed.doc.lines[t.a].attrs; if (!top.tid) top.tid = newTid(ed.doc); chart.link = top.tid; chart.linkCols = !!chart.byCols; /* P12 表とつなぐ */ if (host >= ed.doc.lines.length || FZ.inTable(ed.doc, host)) ed.insertLine(host, FZ.newLine()); const at = ed.doc.lines[host].attrs; id = ed.newFigId(); (at.figs = at.figs || []).push({ id, kind: '図', title: '', file: '', width: 100, chart: FZ.normalizeChart(chart) }); }); /* 図版は表のすぐ下の行に付ける（表の行に付けると文書の書式では置き場が無い） */ st.figSel = id; st.chartData = false; openForm('chart'); msg('表からグラフを作りました。表と連動しているので、表を直すとグラフも変わります：種類・題を選んで Enter。データの向きが違えば「行と列を入れ替え」'); return; }
  const id = ed.addFigure({ kind: '図', title: '', chart: FZ.chartSample() }); st.figSel = id; st.chartData = true; openForm('chart');
  msg('見本のデータでグラフを入れました：データの欄に Excel のセルを貼るか書き換えて Ctrl+Enter（表の中で ' + K('chart') + ' なら表から作る）', false, 8000); }
const chartTSV = c => FZ.chartToGrid(c).map(r => r.join('\t')).join('\n');
/* 1.0.11e グラフのデータの表：Excel のようにセルで直す。1 行目＝角・項目、1 列目＝系列の名前、残り＝値。
   ↑↓・Enter で上下、字の端の ←→ で左右、Tab で右。セルに Excel の範囲を貼ると、そのセルから広げて埋める。セルを離れると紙面に反映 */
const colName = k => { let t = ''; k++; while (k > 0) { const m = (k - 1) % 26; t = String.fromCharCode(65 + m) + t; k = Math.floor((k - 1) / 26); } return t; };
function chartGridHtml(g) { const C = Math.max(...g.map(r => r.length));
  const head = `<tr><th></th>${Array.from({ length: C }, (_, k) => `<th>${colName(k)}</th>`).join('')}</tr>`;
  return `<div class="chgrid"><table>${head}${g.map((r, i) => `<tr><th>${i + 1}</th>${Array.from({ length: C }, (_, k) => `<td class="${i === 0 || k === 0 ? 'h' : 'v'}"><input class="cg" data-r="${i}" data-c="${k}" value="${esc(r[k] ?? '')}" spellcheck="false" autocomplete="off"></td>`).join('')}</tr>`).join('')}</table></div>
    <span class="chgb"><button type="button" data-act="gr+" title="系列（行）を足す">＋系列</button><button type="button" data-act="gr-" title="最後の系列（行）を消す">−系列</button><button type="button" data-act="gc+" title="項目（列）を足す">＋項目</button><button type="button" data-act="gc-" title="最後の項目（列）を消す">−項目</button></span><span class="hintl">1 行目：角・項目／1 列目：系列の名前。セルに Excel の範囲を貼れる（左上 A1 に貼ると表ごと置き換え）。セルを離れると反映</span>`; }
function chartGridRead() { const cells = [...sub.querySelectorAll('.chgrid input.cg')]; if (!cells.length) return null; const g = []; for (const el of cells) { const r = +el.dataset.r, c = +el.dataset.c; (g[r] = g[r] || [])[c] = el.value.trim(); } return g.map(r => Array.from(r, v => v ?? '')); }
function chartGridFocus(r, c) { const el = sub.querySelector(`.chgrid input.cg[data-r="${r}"][data-c="${c}"]`); if (el) { el.focus(); el.select(); } return !!el; }
FORMS.chart = {
  cur() { const x = ed.figById(st.figSel); return x && x.fg.chart ? x : null; },
  html() { const x = this.cur(); if (!x) return `<span class="ttl">グラフ</span><span class="info alert">グラフがありません</span><button type="button" data-act="cancel">閉じる Esc</button>`; const fg = x.fg, c = fg.chart; const n = ed.lay.figNums && ed.lay.figNums.get(fg.id);
    const L = ed.figList().filter(y => y.fg.chart); const idx = L.findIndex(y => y.fg.id === fg.id);
    return `<span class="ttl">グラフ ${esc(n ? n.label : '')}${L.length > 1 ? `（${idx + 1}/${L.length}）` : ''}</span><label>種類 ${cyc('type', FZ.CHART_TYPES, c.type)}</label><label>題 ${inp('title', fg.title, 'w')}</label><label>種別 ${cyc('kind', [['図', '図'], ['表', '表']], fg.kind)}</label>${figSizeHtml(fg)}
      <label>単位 ${inp('unit', c.unit, 's')}</label><label title="値の小数の桁（自動はデータの桁）">小数 ${cyc('dec', [['', '自動'], ['0', '0'], ['1', '1'], ['2', '2'], ['3', '3']], c.dec == null ? '' : String(c.dec))}</label><label title="値の千の位の区切り（1,234）">千区切り ${cyc('sep', [['1', 'あり'], ['0', 'なし']], c.sep === false ? '0' : '1')}</label><label>凡例 ${cyc('legend', FZ.CHART_LEGENDS, c.legend)}</label><label>値 ${cyc('labels', [['1', '出す'], ['0', '出さない']], c.labels ? '1' : '0')}</label><label>縦横 ${cyc('ratio', [['0.4', '横長'], ['0.5', 'やや横長'], ['0.6', '標準'], ['0.75', '4:3'], ['1', '正方形']], String(c.ratio))}</label><label title="縦軸を 0 から始めず、波線で省略を示す（自動：折れ線で値が高い所に固まっていれば省く）">軸の省略 ${cyc('brk', [['', '自動'], ['1', 'あり'], ['0', 'なし']], c.brk == null ? '' : c.brk ? '1' : '0')}</label>${c.type === 'waterfall' ? `<label title="滝：0 から立つ合計の棒（最初の項目＝元の値、最後の項目＝合計。空なら計算）">合計 ${cyc('tot', [['', '両端'], ['first', '最初だけ'], ['none', 'なし']], c.tot || '')}</label>` : ''}
      <button type="button" data-act="swap" title="系列と項目を入れ替える（Excel の「行/列の切り替え」）">行と列を入れ替え</button>${c.link ? chartLinkHtml(c) : `<button type="button" data-act="data" title="データの欄を出す／隠す">${st.chartData ? 'データを隠す' : 'データ…'}</button>`}<button type="button" data-act="ref" title="本文の今の位置に図番を入れる">図番</button><button type="button" data-act="del">削除</button>
      ${st.chartData && !c.link ? chartGridHtml(FZ.chartToGrid(c)) : ''}
      <button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'select[name="type"]', enter(e) { const t = e && e.target; if (t && t.classList && t.classList.contains('cg')) { this.save(); if (!chartGridFocus(+t.dataset.r + (e.shiftKey ? -1 : 1), +t.dataset.c)) t.select(); return; } this.act('apply'); }, /* データの表の Enter は下のセルへ（反映して） */
  key(e) { const t = e.target; if (!t.classList || !t.classList.contains('cg')) return; const r = +t.dataset.r, c = +t.dataset.c; let to = null;
    if (e.key === 'ArrowUp') to = [r - 1, c]; else if (e.key === 'ArrowDown') to = [r + 1, c]; else if (e.key === 'ArrowLeft' && t.selectionStart === 0 && t.selectionEnd === 0) to = [r, c - 1]; else if (e.key === 'ArrowRight' && t.selectionStart === t.value.length) to = [r, c + 1];
    if (to && chartGridFocus(...to)) e.preventDefault(); },
  commit(e) { if (e.target.classList && e.target.classList.contains('cg')) this.save(); }, /* セルを離れたら紙面に（欄は描き直さない） */
  paste(e) { const t = e.target; if (!t.classList || !t.classList.contains('cg')) return; const tx = (e.clipboardData && e.clipboardData.getData('text/plain')) || ''; if (!/[\t\n]/.test(tx.replace(/\n$/, ''))) return; e.preventDefault();
    const rows = FZ.parseTSV(tx.replace(/\r/g, '').replace(/\n$/, '')).map(r => r.map(v => String(v).trim())); let g = chartGridRead(); const r0 = +t.dataset.r, c0 = +t.dataset.c; if (!r0 && !c0) g = []; /* 左上（A1）に貼ると表ごと置き換える */
    rows.forEach((row, i) => row.forEach((v, k) => { const rr = r0 + i, cc = c0 + k; while (g.length <= rr) g.push([]); g[rr][cc] = v; })); const C = Math.max(...g.map(r => r.length)); g.forEach(r => { for (let k = 0; k < C; k++) if (r[k] == null) r[k] = ''; });
    this.setGrid(g); chartGridFocus(r0, c0); msg(`${rows.length}×${Math.max(...rows.map(r => r.length))} のセルを貼りました`); },
  setGrid(g) { const x = this.cur(); if (!x) return; const c = x.fg.chart; const d = FZ.normalizeChart({ ...c, _rows: g }); d.series.forEach((sr, k) => { if (c.series[k]) sr.shade = c.series[k].shade; }); ed.setFig(x.fg.id, { chart: d }); drawSub(); },
  read(x) { const c = x.fg.chart; const nc = { ...c, type: cycVal('type'), unit: fval('unit').trim(), legend: cycVal('legend'), labels: cycVal('labels') === '1', ratio: +cycVal('ratio') || 0.6 }; delete nc.dec; delete nc.sep; { const d = cycVal('dec'); if (d) nc.dec = +d; } if (cycVal('sep') === '0') nc.sep = false; /* 小数（空＝自動）・千区切り */ delete nc.brk; { const b = cycVal('brk'); if (b) nc.brk = b === '1'; } if (cycVal('tot') != null) { delete nc.tot; if (cycVal('tot')) nc.tot = cycVal('tot'); }
    const g = chartGridRead(); if (g && JSON.stringify(g) !== JSON.stringify(FZ.chartToGrid(c))) { const rows = g; if (rows.length) { const d = FZ.normalizeChart({ ...nc, _rows: rows }); d.series.forEach((sr, k) => { if (c.series[k]) sr.shade = c.series[k].shade; }); Object.assign(nc, { corner: d.corner, cats: d.cats, series: d.series }); } }
    return { kind: cycVal('kind'), title: fval('title').trim(), ...figSizeRead(), chart: FZ.normalizeChart(nc) }; },
  save() { const x = this.cur(); if (!x) return false; const v = this.read(x); if (v.kind === x.fg.kind && v.title === x.fg.title && figSizeSame(v, x.fg) && JSON.stringify(v.chart) === JSON.stringify(x.fg.chart)) return false; ed.setFig(x.fg.id, v); const el = $('figSz'); if (el) el.textContent = figSizeInfo(ed.figById(x.fg.id).fg); return true; },
  change(name) { figSizeChange(name); if (['type', 'legend', 'labels', 'ratio', 'kind', 'fsz', 'dec', 'sep', 'brk', 'tot'].includes(name)) { this.save(); if (name === 'type' && (cycVal('tot') != null) !== (cycVal('type') === 'waterfall')) { drawSub(); const t = sub.querySelector('select[name="type"]'); if (t) t.focus(); } } else if (name === 'fpc') figSizeLater(() => this.save()); }, /* 滝にした・やめた時は欄を描き直す（合計の欄） */ /* 選択はその場で紙面に */
  act(a) { const x = this.cur(); if (a === 'cancel' || !x) { closeForm(); return; }
    if (a === 'apply') { this.save(); closeForm(); return; }
    this.save(); const y = this.cur(); if (!y) { closeForm(); return; }
    if (a === 'swap') { const c = y.fg.chart; if (c.link) ed.setFig(y.fg.id, { chart: { ...c, linkCols: !c.linkCols } }); else ed.setFig(y.fg.id, { chart: FZ.chartTranspose(c) }); drawSub(); return; } /* 連動中は向きを替えて表から作り直す */
    if (a === 'toTable') { const i = tidLine(ed.doc, y.fg.chart.link); closeForm(); if (i >= 0) { ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); render(); scrollToCaret(true); } return; }
    if (a === 'unlink') { const c = { ...y.fg.chart }; delete c.link; delete c.linkCols; ed.setFig(y.fg.id, { chart: c }); drawSub(); msg('表との連動を切りました（今の値のグラフ。Ctrl+Z で戻す）'); return; }
    if (a === 'data') { st.chartData = !st.chartData; drawSub(); if (st.chartData) chartGridFocus(1, 1); return; }
    if (/^g[rc][+-]$/.test(a)) { const g = chartGridRead() || FZ.chartToGrid(y.fg.chart); const C = Math.max(...g.map(r => r.length));
      if (a === 'gr+') g.push(['系列' + g.length, ...Array(C - 1).fill('')]); else if (a === 'gc+') g.forEach((r, i) => r.push(i === 0 ? '項目' + C : ''));
      else if (a === 'gr-') { if (g.length <= 2) { msg('系列は 1 つ以上', true); return; } g.pop(); } else if (a === 'gc-') { if (C <= 2) { msg('項目は 1 つ以上', true); return; } g.forEach(r => r.splice(C - 1)); }
      this.setGrid(g); if (a === 'gr+') chartGridFocus(g.length - 1, 0); else if (a === 'gc+') chartGridFocus(0, C); return; }
    if (a === 'ref') { closeForm(); ed.insertRef(y.fg.id); return; }
    if (a === 'del') { ed.removeFig(y.fg.id); closeForm(); msg('グラフを削除しました（Ctrl+Z で戻す）'); return; } } };
/* ---------- P10：配置の理由 ----------
   カーソルの行に組版が実際に採った決まり（組版が lineMap[行].why に残したもの：位置・太字・番号・次頁へ移った理由）を帯に出す。
   「この行だけ」の指定は外せる。決まり（文書全体の書式）は「同じ種類の設定」で開く。紙面の行は細い枠で示す（印刷には出ない） */
cmd('whyPlace', '配置の理由…（この行の位置・太字・番号・次頁へ移った理由。この行だけの指定を外す）', '配置', '', () => { if (st.mode !== 'text') exitMode(); finishLayout(); openForm('why'); }, '理由 なぜ 位置 太字 番号 改頁 送り 次頁');
FORMS.why = {
  html() { const L = ed.caret.line, lm = ed.lay.lineMap[L], W = lm && lm.why;
    const B = (act, t, tip) => `<button type="button" data-act="${act}"${tip ? ` title="${esc(tip)}"` : ''}>${t}</button>`;
    if (!W) return `<span class="ttl">配置の理由</span><span class="info">この行は図の行か、まだ組み終わっていません</span>${B('cancel', '閉じる Esc')}`;
    const row = (label, text, btns) => `<span class="why"><b>${esc(label)}</b>${esc(text)}${btns}</span>`; const parts = [];
    if (W.pos) parts.push(row(`行頭 ${W.pos.col + 1} 字目：`, W.pos.why, (W.pos.own === 'indent' ? B('unIndent', 'この行だけ指定を外す', '位置の固定・字下げを外して自動に（段から決まる位置へ）') : '') + B('seeScheme', '同じ種類の設定', '体系と空き（見出し・箇条書きの位置、本文の位置）。文書全体に効く')));
    if (W.bold) parts.push(row('太字：', W.bold.why, W.bold.own === 'thin' ? B('unThin', 'この行だけ指定を外す', '細字の指定を外す（組版の太字に戻る）') : W.bold.own === 'marks' ? '' : B('thin', 'この行だけ細字に') + B('seeScheme', '同じ種類の設定')));
    if (W.num) parts.push(row(`番号「${W.num.mark}」：`, W.num.why, (W.num.own === 'restart' ? B('unRestart', 'この行だけ指定を外す', '数え直しを外す') : '') + B('seeMarker', '同じ段の番号の形', 'この段の番号・記号の形（文書全体）')));
    if (W.brk) parts.push(row('次頁へ：', W.brk.why, W.brk.own === 'breakBefore' || W.brk.own === 'keepLine' || W.brk.own === 'keepNext' ? B(W.brk.own === 'breakBefore' ? 'unBreak' : 'unKeep', 'この行だけ指定を外す') : W.brk.own === 'implicitNext' ? B('free', 'この行は送らない', '次の行と同じ頁に置く決まりを、この行だけ外す') : ''));
    else if (W.split) parts.push(row('頁：', W.split, ''));
    if (!parts.length) parts.push('<span class="info">この行に効いている特別な決まりはありません（版面の左端から、ふつうに組んでいます）</span>');
    return `<span class="ttl">配置の理由</span>${parts.join('')}${B('cancel', '閉じる Esc')}`; },
  focus: 'button',
  act(a) { if (a === 'cancel') { closeForm(); return; } const L = ed.caret.line;
    const set = (fn, m) => { ed.mutate('', () => fn(ed.doc.lines[L].attrs)); finishLayout(); render(); drawSub(); msg(m + '（Ctrl+Z で戻す）'); };
    if (a === 'unIndent') { if (ed.posReset()) { finishLayout(); render(); drawSub(); msg('この行の位置の指定を外しました（段から決まる位置へ。Ctrl+Z で戻す）'); } return; }
    if (a === 'thin') return set(at => { at.thin = true; }, 'この行だけ細字にしました');
    if (a === 'unThin') return set(at => { delete at.thin; }, 'この行の細字を外しました');
    if (a === 'unRestart') return set(at => { delete at.restart; }, 'この行の数え直しを外しました');
    if (a === 'unBreak') return set(at => { delete at.breakBefore; }, 'この行の「ここから改頁」を外しました');
    if (a === 'unKeep') return set(at => { delete at.keep; }, 'この行の送りの指定を外しました');
    if (a === 'free') return set(at => { at.keep = 'free'; }, 'この行は次の行と同じ頁に送らないようにしました');
    if (a === 'seeScheme') { openForm('scheme'); return; } if (a === 'seeMarker') { openForm('marker'); return; } } };
/* ---------- P12：表とグラフを同じデータに ----------
   表から作ったグラフは、表の 1 行目の名札（attrs.tid。原本は「[表:t1]」）とつなぐ（chart.link、原本は「#グラフ設定 連動=t1:行」）。
   表を直すと、同じ取消の単位の中でグラフの項目・系列・値が揃う（ed.onMutate）。系列の網などは名前で受け継ぐ。
   表を消すとグラフは値のまま残る（「元の表が見つかりません」）。「連動を切る」で値だけのグラフに */
function tableRowsIn(doc, i) { let a = i, b = i; while (a > 0 && FZ.inTable(doc, a - 1)) a--; while (b + 1 < doc.lines.length && FZ.inTable(doc, b + 1)) b++; const cols = doc.format.cols; const rows = [];
  for (let k = a; k <= b; k++) { const ln = doc.lines[k]; if (ln.attrs.sumRow) continue; rows.push(FZ.cellsAt(doc, k, cols).map(c => ln.segs.filter(sg => sg.col >= c.left - 1e-6 && sg.col < c.right - 1e-6).map(sg => sg.text).join('').trim())); } return { a, b, rows }; }
const tidLine = (doc, tid) => doc.lines.findIndex(l => l.attrs.tid === tid);
function chartSync(doc) { let tids = null;
  for (const ln of doc.lines) { const F = ln.attrs.figs; if (!F) continue;
    for (const fg of F) { const c = fg.chart; if (!c || !c.link) continue;
      if (!tids) { tids = new Map(); doc.lines.forEach((l, k) => { if (l.attrs.tid) tids.set(l.attrs.tid, k); }); }
      const i = tids.get(c.link); if (i == null || !FZ.inTable(doc, i)) continue; const t = tableRowsIn(doc, i); if (!FZ.chartable(t.rows)) continue;
      const n = FZ.chartFromGrid(t.rows, { byCols: !!c.linkCols }); const key = x => JSON.stringify([x.corner, x.cats, x.series.map(sr => [sr.name, sr.values])]);
      if (key(n) === key(c)) continue; const old = c.series;
      fg.chart = FZ.normalizeChart({ ...c, corner: n.corner, cats: n.cats, series: n.series.map((sr, k) => ({ name: sr.name, values: sr.values, shade: ((old.find(o => o.name === sr.name) || old[k] || {}).shade) || null })) }); } } }
ed.onMutate = doc => { const n = FZ.tbl.sumSync(doc, ed.caret); chartSync(doc); /* 1.0.15d 合計の行 → グラフ（合計の行はグラフに入れない） */
  if (n) { const L = doc.lines[ed.caret.line]; if (L && L.attrs.sumRow && st.lastTypeSum !== ed.gen) { st.lastTypeSum = ed.gen; setTimeout(() => msg('合計の行の数は表から計算します（手で直すなら 表 → 合計 で外す）'), 0); } } };
const newTid = doc => { const used = new Set(doc.lines.map(l => l.attrs.tid).filter(Boolean)); let k = 1; while (used.has('t' + k)) k++; return 't' + k; };
function chartLinkHtml(c) { if (!c.link) return ''; const i = tidLine(ed.doc, c.link);
  return i >= 0 ? `<span class="info">表と連動：表を直すとグラフも変わる（${c.linkCols ? '表の列' : '表の行'}が系列）</span><button type="button" data-act="toTable" title="元の表の 1 行目へ">元の表へ</button><button type="button" data-act="unlink" title="表とのつながりを切り、今の値だけのグラフにする">連動を切る</button>`
    : `<span class="info alert">元の表が見つかりません（表を消した？ グラフは値のまま残しています）</span><button type="button" data-act="unlink">連動を切る</button>`; }
/* ---------- A-4：版面の物差し ----------
   版面を「見ながら設計する」：方眼を版面にして、余白（mm）・字数・行数を欄で、または紙面の版面の縁をドラッグして変える。変えたことは紙面に仮に出し、
   Enter で確定（1 回の取消で戻る）、Esc で開く前に戻す。版面の型（目安）から選んでもよい。字の大きさは版面の幅と字数から決まる（1 字＝1 マス） */
const LAYOUT_PRESETS = [
  { id: 'kobun', label: '公用文（A4 縦・40 字×30 行）', f: { paper: 'A4', landscape: false, cols: 40, rows: 30, margins: { top: 30, right: 20, bottom: 25, left: 25 } } },
  { id: 'report', label: '報告書（A4 縦・40 字×36 行）', f: { paper: 'A4', landscape: false, cols: 40, rows: 36, margins: { top: 20, right: 20, bottom: 20, left: 20 } } },
  { id: 'one', label: '1 枚もの（A3 横・90 字×44 行）', f: { paper: 'A3', landscape: true, cols: 90, rows: 44, margins: { top: 12, right: 12, bottom: 12, left: 12 } } },
  { id: 'book', label: '書籍（A5 縦・35 字×28 行）', f: { paper: 'A5', landscape: false, cols: 35, rows: 28, margins: { top: 18, right: 15, bottom: 20, left: 18 } } },
  { id: 'minutes', label: '議事録（A4 縦・40 字×40 行）', f: { paper: 'A4', landscape: false, cols: 40, rows: 40, margins: { top: 20, right: 20, bottom: 20, left: 20 } } }];
function setFormat(patch, live) { const f0 = ed.doc.format; const nf = { ...JSON.parse(JSON.stringify(f0)), ...patch }; if (patch.paper && FZ.PAPERS[patch.paper]) { let [w, h] = FZ.PAPERS[patch.paper]; if (patch.landscape) [w, h] = [h, w]; nf.widthMm = w; nf.heightMm = h; }
  if (patch.landscape != null && !patch.paper) { const a = Math.min(nf.widthMm, nf.heightMm), b = Math.max(nf.widthMm, nf.heightMm); nf.widthMm = patch.landscape ? b : a; nf.heightMm = patch.landscape ? a : b; }
  if (live) { ed.doc.format = FZ.normalize({ ...ed.doc, format: nf }).format; ed.relayout(); ed.dirty = true; } else ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: nf }).format; });
  pageCache = pageCache.map(() => ''); render(); }
const geoInfo = () => { const g = ed.lay.geo, f = ed.doc.format, mm = v => (v * 25.4 / 72).toFixed(1); return `字 ${(+g.fs).toFixed(1)} pt・版面 ${mm(g.cols * g.cw)}×${mm(g.rows * g.ch)} mm・${ed.lay.pages.length} 頁${f.minPt && g.fs < f.minPt - 1e-6 ? `　<b class="alert">最小の字 ${f.minPt} pt を下回る</b>` : ''}`; };
cmd('ruler', '版面の物差し…（余白・字数・行数を紙面で直に。版面の型）', '書式', '', () => { if (st.mode !== 'text') exitMode(); openForm('ruler'); }, '物差し 版面 余白 字数 行数 グリッド 型 プリセット');
FORMS.ruler = {
  preview: true,
  html() { const f = ed.doc.format, m = f.margins; if (!st.rulerGrid) { st.rulerGrid = { grid: st.grid, mode: st.gridMode }; st.grid = true; st.gridMode = 'all'; pageCache = pageCache.map(() => ''); requestRender(); }
    return `<span class="ttl">版面の物差し</span><label>型 ${cyc('preset', [['', '今のまま'], ...LAYOUT_PRESETS.map(p => [p.id, p.label])], '')}</label><label>上${inp('mt', m.top, 'n', 'number', 'step="0.5" min="0"')}</label><label>右${inp('mr', m.right, 'n', 'number', 'step="0.5" min="0"')}</label><label>下${inp('mb', m.bottom, 'n', 'number', 'step="0.5" min="0"')}</label><label>左${inp('ml', m.left, 'n', 'number', 'step="0.5" min="0"')}</label><span class="u">mm</span><label>字数${inp('cols', f.cols, 'n', 'number', 'min="4" max="200"')}</label><label>行数${inp('rows', f.rows, 'n', 'number', 'min="2" max="300"')}</label><span class="info" id="rulerInfo">${geoInfo()}</span><span class="hintl">紙面の版面の縁（四辺）をドラッグで余白</span><button type="button" class="pri" data-act="ok">確定 Enter</button><button type="button" data-act="cancel" title="この欄を開いてからの変更を元に戻して閉じる">元に戻す Esc</button>`; },
  focus: 'input[name="mt"]', enter() { this.act('ok'); },
  change(name) { if (name === 'preset') { const P = LAYOUT_PRESETS.find(p => p.id === cycVal('preset')); if (!P) return; setFormat(JSON.parse(JSON.stringify(P.f))); drawSub(); return; }
    const n = v => +fval(v); const m = { top: n('mt'), right: n('mr'), bottom: n('mb'), left: n('ml') }; if (Object.values(m).some(v => !Number.isFinite(v) || v < 0)) return; const cols = Math.round(n('cols')), rows = Math.round(n('rows')); if (!(cols >= 4 && rows >= 2)) return;
    const f = ed.doc.format; if (JSON.stringify(f.margins) === JSON.stringify(m) && f.cols === cols && f.rows === rows) return; clearTimeout(st.rulerT); st.rulerT = setTimeout(() => { setFormat({ margins: m, cols, rows }); const el = $('rulerInfo'); if (el) el.innerHTML = geoInfo(); }, 250); },
  act(a) { if (a === 'ok') { closeForm(); return; } if (a === 'cancel') { cancelForm(); return; } } };
/* 版面の縁のドラッグ（物差しを開いている間だけ） */
function rulerEdge(e) { const g = eventToGrid(e); if (!g) return null; const geo = ed.lay.geo, tol = 0.6; if (g.row >= -1 && g.row <= geo.rows + 1) { if (Math.abs(g.col) < tol) return { edge: 'left', g }; if (Math.abs(g.col - geo.cols) < tol) return { edge: 'right', g }; } if (g.col >= -1 && g.col <= geo.cols + 1) { if (Math.abs(g.row) < tol * 0.8) return { edge: 'top', g }; if (Math.abs(g.row - geo.rows) < tol * 0.8) return { edge: 'bottom', g }; } return null; }
main.addEventListener('pointerdown', e => { if (st.form !== 'ruler' || e.button !== 0) return; const h = rulerEdge(e); if (!h) return; e.preventDefault(); e.stopPropagation(); const geo = ed.lay.geo; st.rulerDrag = { edge: h.edge, m0: { ...ed.doc.format.margins }, x0: e.clientX, y0: e.clientY, scale: (pageGeom[h.g.page] ? pageGeom[h.g.page].width : geo.W) / geo.W }; ed.pushUndo(''); try { main.setPointerCapture(e.pointerId); } catch { } }, true);
main.addEventListener('pointermove', e => { const D = st.rulerDrag; if (!D) { if (st.form === 'ruler') main.style.cursor = (h => h ? (h.edge === 'left' || h.edge === 'right' ? 'ew-resize' : 'ns-resize') : '')(rulerEdge(e)); return; }
  const dx = (e.clientX - D.x0) / D.scale * 25.4 / 72, dy = (e.clientY - D.y0) / D.scale * 25.4 / 72; const m = { ...D.m0 }; const r5 = v => Math.max(3, Math.round(v * 2) / 2);
  if (D.edge === 'left') m.left = r5(D.m0.left + dx); else if (D.edge === 'right') m.right = r5(D.m0.right - dx); else if (D.edge === 'top') m.top = r5(D.m0.top + dy); else m.bottom = r5(D.m0.bottom - dy);
  if (JSON.stringify(m) === JSON.stringify(ed.doc.format.margins)) return; cancelAnimationFrame(st.rulerRaf); st.rulerRaf = requestAnimationFrame(() => { setFormat({ margins: m }, true); for (const [k, nm] of [['top', 'mt'], ['right', 'mr'], ['bottom', 'mb'], ['left', 'ml']]) { const el = sub.querySelector(`[name="${nm}"]`); if (el) el.value = m[k]; } const el = $('rulerInfo'); if (el) el.innerHTML = geoInfo(); }); }, true);
main.addEventListener('pointerup', () => { if (!st.rulerDrag) return; st.rulerDrag = null; main.style.cursor = ''; ed.onChange('edit'); status(); }, true);
/* ---------- P11：紙幅の使い道 ----------
   目標（頁数・本文の最小の字の大きさ）を決め、今の組版の結果から、何が紙幅を使っているか（節・区画・表・図・長い段落）と、はみ出す原因を出す。
   試す案（図の幅・区画の並べ方・字数・行数）は、写しを組み直して頁数を確かめてから出す（最小の字は破らない）。何を削るかは書き手が決める（自動の要約はしない） */
function spanOf(a, b, lay) { const m = new Map(); for (let k = a; k <= b; k++) { const lm = lay.lineMap[k]; if (!lm) continue; for (const r of lm.rows) { const q = m.get(r.page) || [1e9, -1]; q[0] = Math.min(q[0], r.y); q[1] = Math.max(q[1], r.y + r.h); m.set(r.page, q); } } let n = 0; for (const [, q] of m) n += q[1] - q[0]; return { n, pages: [...m.keys()].sort((x, y) => x - y) }; }
function fitBlocks() { const lay = ed.lay, doc = ed.doc, items = []; const tr = FZ.tree.build(doc, {}); const tx = i => lineText(i, 14);
  for (let i = 0; i < doc.lines.length; i++) { if (!doc.lines[i].attrs.cells || (i > 0 && FZ.inTable(doc, i - 1) && FZ.inTable(doc, i))) continue; if (!FZ.inTable(doc, i)) continue; let b = i; while (b + 1 < doc.lines.length && FZ.inTable(doc, b + 1)) b++; const sp = spanOf(i, b, lay); const gt = doc.lines[i].attrs.gantt;
    const nm = (doc.lines[i].segs.find(sg => sg.text.trim()) || { text: '' }).text.trim().slice(0, 12); items.push({ kind: gt ? '工程表' : '表', line: i, n: sp.n, pages: sp.pages, text: `${gt ? '工程表' : '表'}「${nm}」が ${b - i + 1} 行（${sp.n} 行分）` }); i = b; }
  for (const n of tr.nodes) { const ln = n.obj; if (!ln || !ln.attrs.panels) continue; const L = doc.lines.indexOf(ln); const kids = n.children.filter(c => c.kind !== 'body' && c.kind !== 'block'); if (!kids.length) continue; const all = spanOf(L, L + Math.max(0, n.end - n.line), lay); let best = null;
    for (const c of kids) { const a = doc.lines.indexOf(c.obj); const sp = spanOf(a, a + Math.max(0, c.end - c.line), lay); if (!best || sp.n > best.n) best = { n: sp.n, line: a, text: c.text }; }
    items.push({ kind: '区画', line: L, n: all.n, pages: all.pages, text: `区画「${tx(L)}」（${kids.length} 区画・${all.n} 行分）：高さは最も長い「${String(best.text).slice(0, 12)}」の ${best.n} 行で決まる`, tall: best.line }); }
  for (const pg of lay.pages.map((pg, p) => ({ pg, p }))) for (const im of (pg.pg.images || []).concat(pg.pg.side ? pg.pg.side.images || [] : [])) { if (im.line == null) continue; items.push({ kind: '図', line: im.line, n: (im.h | 0) + 1, pages: [pg.p], text: `${im.chart ? 'グラフ' : '図'}「${String(im.title || '').slice(0, 12) || tx(im.line)}」が ${(im.h | 0) + 1} 行分（幅 ${im.w | 0} 字）`, fig: im.id }); }
  doc.lines.forEach((ln, i) => { const a = ln.attrs; if (a.cells || a.figure || a.style || a.list || a.toc || a.hr || !lineText(i)) return; const lm = lay.lineMap[i]; if (!lm) return; const h = lm.rows.reduce((t, r) => t + r.h, 0); if (h >= 3) items.push({ kind: '段落', line: i, n: h, pages: [...new Set(lm.rows.map(r => r.page))], text: `段落「${tx(i)}」が ${h} 行` }); });
  for (const n of tr.nodes) { if (n.kind !== 'num' || (n.level | 0) !== 0) continue; const L = doc.lines.indexOf(n.obj); if (L < 0) continue; const sp = spanOf(L, L + Math.max(0, n.end - n.line), lay); items.push({ kind: '節', line: L, n: sp.n, pages: sp.pages, text: `節「${tx(L)}」が ${sp.n} 行分`, sec: true }); }
  return items; }
function docClone(d) { return { ...d, format: JSON.parse(JSON.stringify(d.format)), lines: d.lines.map(l => JSON.parse(JSON.stringify(l))), rules: d.rules.map(r => ({ ...r })), fills: (d.fills || []).map(f => ({ ...f })), images: d.images }; }
function fitTry(label, mut) { const d = docClone(ed.doc); mut(d); let lay; try { lay = FZ.layout(FZ.normalize(d)); } catch (e) { return null; } return { label, pages: lay.pages.length, fs: lay.geo.fs, mut }; }
function fitCandidates() { const doc = ed.doc, f = doc.format, now = ed.lay.pages.length, minPt = f.minPt || 0, out = [];
  doc.lines.forEach((ln, i) => (ln.attrs.figs || []).forEach((fg, j) => { if (fg.orig) return; const w0 = fg.width || 100; for (const w of [75, 50]) if (w < w0) out.push(fitTry(`図「${String(fg.title || '').slice(0, 10) || lineText(i, 8)}」の幅を ${w}% に`, d => { d.lines[i].attrs.figs[j].width = w; })); }));
  doc.lines.forEach((ln, i) => { const p0 = ln.attrs.panels; if (!p0) return; for (const p of ['h', 2, 3]) if (p !== p0) out.push(fitTry(`区画「${lineText(i, 10)}」を${p === 'h' ? '横 1 段' : `${p} 列`}に並べる`, d => { d.lines[i].attrs.panels = p; })); });
  for (const dc of [2, 4, 6, 8]) out.push(fitTry(`1 行の字数を ${f.cols + dc} 字に（字が小さくなる）`, d => { d.format.cols = f.cols + dc; }));
  for (const dr of [2, 4, 6, 8]) out.push(fitTry(`1 頁の行数を ${f.rows + dr} 行に（行が詰まる）`, d => { d.format.rows = f.rows + dr; }));
  return out.filter(Boolean).filter(c => c.pages < now && (!minPt || c.fs >= minPt - 1e-6)).sort((a, b) => a.pages - b.pages || b.fs - a.fs).slice(0, 4); }
cmd('fitCheck', '紙幅の使い道…（目標の頁数・最小の字の大きさ。何が紙幅を使っているか、はみ出す原因、試す案）', '書式', '', () => { if (st.mode !== 'text') exitMode(); finishLayout(); openForm('fit'); }, '紙幅 頁数 1 枚 はみ出し 収める 最小 字の大きさ');
FORMS.fit = {
  html() { finishLayout(); const f = ed.doc.format, n = ed.lay.pages.length, tgt = f.targetPages || 0, fs = ed.lay.geo.fs;
    const B = fitBlocks().filter(x => !x.sec).sort((a, b) => b.n - a.n).slice(0, 4); st.fitView = true; const over = tgt && n > tgt; const C = over ? fitCandidates() : []; st.fitCands = C;
    const head = `<span class="ttl">紙幅の使い道</span><label title="この文書を何頁に収めたいか（0＝決めない）">目標 ${inp('tp', tgt, 'n', 'number', 'min="0" max="99"')} 頁</label><label title="本文の字をこれより小さくしない（pt。0＝決めない）">最小の字 ${inp('mp', f.minPt || 0, 'n', 'number', 'min="0" max="40" step="0.5"')} pt</label><span class="info">いま ${n} 頁・字 ${(+fs).toFixed(1)} pt${f.minPt && fs < f.minPt - 1e-6 ? '　<b class="alert">最小の字を下回る</b>' : ''}${tgt ? (over ? `　<b class="alert">${n - tgt} 頁はみ出し</b>` : '　目標に収まっている') : ''}</span>`;
    const blocks = B.length ? `<span class="info">紙幅を多く使うもの：</span>${B.map((x, k) => `<button type="button" data-act="go${k}" title="その位置へ">${esc(x.text)}</button>`).join('')}` : '';
    const cands = over ? (C.length ? `<span class="info">試す案（組み直して確かめた頁数）：</span>${C.map((c, k) => `<button type="button" data-act="try${k}" title="1 回の取消で戻る">${esc(c.label)} → ${c.pages} 頁${f.minPt ? `（字 ${(+c.fs).toFixed(1)} pt）` : ''}</button>`).join('')}` : `<span class="info">図の幅・区画の並べ方・字数・行数では収まりません${f.minPt ? '（最小の字を守ると）' : ''}。長い段落を短くするか、${tgt + 1} 頁にするかを決めてください</span>`) : '';
    return head + blocks + cands + '<button type="button" data-act="cancel">閉じる Esc</button>'; },
  focus: 'input[name="tp"]',
  change(name) { if (name !== 'tp' && name !== 'mp') return; clearTimeout(st.fitT); st.fitT = setTimeout(() => { const tp = Math.max(0, Math.round(+fval('tp') || 0)), mp = Math.max(0, +fval('mp') || 0); const f = ed.doc.format; if ((f.targetPages || 0) === tp && (f.minPt || 0) === mp) return; ed.mutate('', () => { f.targetPages = tp; f.minPt = mp; ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; }); const foc = document.activeElement && document.activeElement.name; drawSub(); const el = foc && sub.querySelector(`[name="${foc}"]`); if (el) { el.focus(); try { const v = el.value; el.value = ''; el.value = v; } catch { } } }, 400); },
  act(a) { if (a === 'cancel') { closeForm(); return; } let m;
    if ((m = a.match(/^go(\d+)$/))) { const B = fitBlocks().filter(x => !x.sec).sort((x, y) => y.n - x.n).slice(0, 4); const x = B[+m[1]]; if (!x) return; ed.anchor = null; ed.caret = { line: x.tall != null ? x.tall : x.line, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); render(); scrollToCaret(true); return; }
    if ((m = a.match(/^try(\d+)$/))) { const c = (st.fitCands || [])[+m[1]]; if (!c) return; const before = ed.lay.pages.length; ed.mutate('', () => c.mut(ed.doc)); finishLayout(); pageCache = pageCache.map(() => ''); render(); drawSub(); msg(`${c.label}：${before} 頁 → ${ed.lay.pages.length} 頁（Ctrl+Z で戻す）`, false, 8000); } } };
/* ---------- P13：構成を試す ----------
   本文は 1 つのまま、節の順番と親子（見出しの段）だけの試案を 1 つ持つ。始めた時の構成を「元の案」として覚え、ふだんの操作（上へ・下へ・上げる・下げる・移す・ツリーのドラッグ）で組み替える。
   「元の案を見る」「試案を見る」で行き来して読み比べ、「試案を採る」「試案を捨てる」で終える。行き来も採る・捨てるも 1 回の操作（1 回の取消）。
   本文の直し・足した節は、どちらの案にも残る（足した節は直前の節の後ろに）。見出しは行そのもの、なければ見出しの字（同じ字は何番目か）で見分ける */
const headOf = a => a.style === 'num' || a.style === 'sym';
function headKeys(doc) { const seen = new Map(); return doc.lines.map(ln => { if (!headOf(ln.attrs)) return null; const t = ln.segs.map(sg => sg.text).join(' ').trim(); const n = (seen.get(t) || 0) + 1; seen.set(t, n); return t + '#' + n; }); }
function structSnap(doc) { const K2 = headKeys(doc); const out = []; doc.lines.forEach((ln, i) => { if (headOf(ln.attrs)) out.push({ obj: ln, key: K2[i], style: ln.attrs.style, level: ln.attrs.level | 0 }); }); return out; }
function applyStruct(target) { const doc = ed.doc, K2 = headKeys(doc); const B = []; let cur = { a: 0, head: true }; doc.lines.forEach((ln, i) => { if (headOf(ln.attrs)) { cur.b = i - 1; B.push(cur); cur = { a: i, obj: ln, key: K2[i] }; } }); cur.b = doc.lines.length - 1; B.push(cur);
  const head = B[0], rest = B.slice(1), used = new Set(), seq = [];
  for (const t of target) { const blk = rest.find(b => !used.has(b) && b.obj === t.obj) || rest.find(b => !used.has(b) && b.key === t.key); if (!blk) continue; used.add(blk); seq.push({ blk, t }); }
  rest.forEach((b, k) => { if (used.has(b)) return; const prev = k ? rest[k - 1] : null; const at = prev ? seq.findIndex(x => x.blk === prev) : -1; seq.splice(at + 1, 0, { blk: b, t: null }); used.add(b); }); /* 試案で足した節：直前の節の後ろに */
  const order = []; for (let k = head.a; k <= head.b; k++) order.push(k); for (const { blk } of seq) for (let k = blk.a; k <= blk.b; k++) order.push(k);
  if (order.length !== doc.lines.length) return false;
  ed.mutate('', () => { if (order.some((o, k) => o !== k)) ed.reorderLines(order); for (const { blk, t } of seq) if (t) { blk.obj.attrs.style = t.style; blk.obj.attrs.level = t.level; } }); return true; }
const sameStruct = (A, B) => A.length === B.length && A.every((x, k) => (x.obj === B[k].obj || x.key === B[k].key) && x.level === B[k].level && x.style === B[k].style);
cmd('trial', '構成を試す…（本文はそのまま、節の順番と親子だけの試案。元の案と行き来して採る・捨てる）', '構造', '', () => { if (st.mode === 'tree') exitTree(false); else if (st.mode !== 'text') exitMode(); if (!st.trial) { const S0 = structSnap(ed.doc); if (!S0.length) { msg('見出しがありません（構成を試すのは見出しのある文書）', true); return; } st.trial = { orig: S0, alt: null, view: 'trial' }; msg('構成の試案を始めました：ふだんの操作で節を組み替えてください（元の案はいつでも見られる）', false, 8000); } openForm('trial'); status(); }, '構成 試案 並べ替え 比べる 元に戻す');
FORMS.trial = {
  html() { const T = st.trial; if (!T) return `<span class="ttl">構成を試す</span><span class="info">試案はありません</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    const now = structSnap(ed.doc), other = T.view === 'orig' ? (T.alt || now) : T.orig; const moved = now.filter((x, k) => { const j = other.findIndex(y => y.obj === x.obj || y.key === x.key); return j < 0 || j !== k || other[j].level !== x.level; }).length;
    return `<span class="ttl">構成を試す</span><span class="info">いま <b>${T.view === 'orig' ? '元の案' : '試案'}</b> を表示（見出し ${now.length}・元の案と違う所 ${moved}）。本文の直しはどちらにも残る</span>${T.view === 'orig' ? '<button type="button" class="pri" data-act="alt">試案を見る</button>' : '<button type="button" data-act="orig">元の案を見る</button>'}<button type="button" data-act="adopt" title="試案を今の構成にして試しを終える（1 回の取消で戻る）">試案を採る</button><button type="button" data-act="discard" title="元の案に戻して試しを終える（1 回の取消で戻る）">試案を捨てる</button><button type="button" data-act="cancel" title="試しを続けたまま閉じる">閉じる Esc</button>`; },
  focus: 'button',
  act(a) { const T = st.trial; if (a === 'cancel' || !T) { closeForm(); return; }
    const done = m => { finishLayout(); if (st.mode === 'tree') treeRefresh(); else render(); status(); drawSub(); msg(m, false, 7000); };
    if (a === 'orig' && T.view !== 'orig') { T.alt = structSnap(ed.doc); applyStruct(T.orig); T.view = 'orig'; return done('元の案を表示しています（本文の直しは残っています）'); }
    if (a === 'alt' && T.view === 'orig') { T.orig = structSnap(ed.doc); applyStruct(T.alt); T.view = 'trial'; return done('試案を表示しています'); }
    if (a === 'adopt') { if (T.view === 'orig' && T.alt) applyStruct(T.alt); st.trial = null; closeForm(); return done('試案を採りました（Ctrl+Z で戻す）'); }
    if (a === 'discard') { if (T.view !== 'orig') applyStruct(T.orig); st.trial = null; closeForm(); return done('試案を捨てて元の案に戻しました（Ctrl+Z で戻す）'); } } };
FZ.app_trial = () => st.trial;
/* ---------- 1.0.14a プ譜 ----------
   「プ譜」の節の子の木を、紙面で右から左へ枝分かれする形に組む（組版は fz-core の pufuRow、木と点検は fz-pufu.js）。
   書くのはふだんのアウトライン：Enter で同じ役、Tab で一段深く（役が替わる）。枠は中間目的をまとめる取組の節（深さに数えない） */
const pufuBlank = ln => !ln.segs.some(sg => sg.text.trim()) && !ln.attrs.list && !ln.attrs.style;
/* 行を入れる（1 回の取消）。カーソルの行が空の本文なら、その行を区切りの空行に使う。後ろに本文が続くなら空行を挟む（プ譜は空行で終わる） */
function pufuInsert(specs, note, caretAt = 1) {
  if (st.mode === 'tree') exitTree(false); else if (st.mode !== 'text') exitMode();
  let head = -1;
  ed.mutate('', () => { ed.deleteSelection(); ed.materialize(); const c = ed.caret; const cur = ed.line(); const empty = pufuBlank(cur) && !FZ.inTable(ed.doc, c.line);
    const at = empty ? c.line : c.line + 1; specs.forEach((sp, k) => ed.insertLine(at + k, FZ.newLine(sp.text, JSON.parse(JSON.stringify(sp.attrs)))));
    const after = at + specs.length; const nx = ed.doc.lines[after]; if (nx && !pufuBlank(nx)) ed.insertLine(after, FZ.newLine(''));
    head = at; if (note) { let k = 1; const ids = new Set((ed.doc.notes || []).map(n => n.id)); while (ids.has('n' + k)) k++; const id = 'n' + k; (ed.doc.notes = ed.doc.notes || []).push({ id, author: 'AI（プ譜の取り込み）', date: noteNow(), done: false, quote: '', text: note, replies: [] }); const a = ed.doc.lines[at].attrs; a.notes = [...(a.notes || []), id]; }
    const L = Math.min(ed.doc.lines.length - 1, at + caretAt); ed.caret = { line: L, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; });
  st.fwGuideOff = false; render(); scrollToCaret(true); focusTA(); return head; }
function pufuNew() { const lv = fwLevelAt(ed.caret.line); pufuInsert(FZ.pufuSkeleton(lv)); msg(`プ譜の型を入れました。空の箱の薄い字は手引き（消さずにそのまま打つ）。Enter で同じ役を足し、Tab で一段深く（${K('undo')} で取り消し）`, false, 8000); }
/* この節をプ譜にする／戻す：見出し・項目の行に「プ譜」の印 */
function pufuMark() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); let line = pz ? pz.B.head : ed.caret.line; const a = ed.doc.lines[line].attrs;
  if (!pz && !(a.style === 'num' || a.style === 'sym' || (a.list && a.list.kind !== 'cont'))) { msg('プ譜にするのは見出しか項目の行（その子の木がプ譜になる）', true); return; }
  const on = !a.pufu; ed.mutate('', () => { if (on) ed.doc.lines[line].attrs.pufu = true; else { delete ed.doc.lines[line].attrs.pufu; delete ed.doc.lines[line].attrs.pufuForm; } }); render();
  msg(on ? 'この節をプ譜にしました：子の木を、右から左へ枝分かれする形に組みます（1 段目＝獲得目標・2 段目＝勝利条件・3 段目＝中間目的・4 段目＝施策・その下＝段取り）' : 'プ譜を戻しました（ふつうの見出し・箇条書きに）', false, 8000); }
/* 1.0.14g 紙面の形：自動（横長の紙面・広い版面なら列の図）／字下げ／列。プ譜の見出しの行に持つ */
function pufuFormOf() { const pz = FZ.pufuAt && FZ.pufuAt(ed.doc, ed.caret.line); return pz ? (ed.doc.lines[pz.B.head].attrs.pufuForm || 'auto') : 'auto'; }
function pufuFormIs() { const pz = FZ.pufuAt && FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) return null; const lay = ed.lay; const pf = lay && lay.pufuAt && lay.pufuAt.get(pz.B.start); return pf && pf.fig ? 'cols' : 'tree'; }
function pufuForm(v) { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) { msg('プ譜の節にカーソルを置いてください', true); return; } const head = pz.B.head;
  ed.mutate('', () => { const a = ed.doc.lines[head].attrs; if (v === 'tree' || v === 'cols') a.pufuForm = v; else delete a.pufuForm; }); render();
  const now = pufuFormIs(); msg(v === 'cols' && now !== 'cols' ? '列の図にできません（版面が 40 字より狭い・1 頁に入らない・取組が中間目的以外をまとめている・木の途中に前書きの段落がある、のどれか）。字下げの形のままです' : v === 'cols' ? 'プ譜を列の図にしました（右から 勝利条件・獲得目標｜中間目的｜施策）' : v === 'tree' ? 'プ譜を字下げの形にしました' : `プ譜の形を自動にしました（いまは${now === 'cols' ? '列の図' : '字下げ'}）`, v === 'cols' && now !== 'cols', 8000); }
/* 段を 1 つ深く／浅く（見出し・項目の印の段） */
const pufuShift = (a, d) => { if (a.list) a.list.level = Math.max(0, Math.min(7, (a.list.level | 0) + d)); else if (a.style === 'num' || a.style === 'sym') a.level = Math.max(0, Math.min(7, (a.level | 0) + d)); };
const lvOfA = a => a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : (a.list && a.list.kind !== 'cont') ? 17 + (a.list.level | 0) : 99;
const subEnd = (L, q, end) => { const lv = lvOfA(L[q].attrs); let z = q + 1; while (z < end && lvOfA(L[z].attrs) > lv) z++; return z - 1; };
/* 取組でまとめる／外す：中間目的（選んだ兄弟の範囲）の上に取組の節を入れて一段深く。取組の上なら、取組を外して中身を一段浅く */
function pufuFrameToggle() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz || !pz.it) { msg('取組は、プ譜の中の中間目的をまとめるもの（プ譜の節の中で使う）', true); return; }
  const B = pz.B, L = ed.doc.lines; let it = pz.it; if (it.kind === 'cont') it = B.map.get(it.owner);
  if (!it || (it.kind !== 'node' && it.kind !== 'frame') || it.parent == null) { msg('取組でまとめられるのは、勝利条件より下の項目（中間目的など）', true); return; }
  if (it.kind === 'frame') { const q = it.line, z = subEnd(L, q, B.end); ed.mutate('', () => { for (let k = q + 1; k <= z; k++) pufuShift(ed.doc.lines[k].attrs, -1); ed.removeLine(q); ed.caret = { line: Math.min(q, ed.doc.lines.length - 1), seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; }); render(); msg('取組を外しました（中身は一段浅く）'); return; }
  const s = ed.sel(); let q0 = it.line, q1 = subEnd(L, it.line, B.end);
  if (s && s.a.line !== s.b.line) { const par = it.parent; const sib = B.map.get(par).kids.filter(k => k >= Math.min(s.a.line, it.line) && k <= Math.max(s.b.line, s.a.line)); if (sib.length) { q0 = sib[0]; q1 = subEnd(L, sib[sib.length - 1], B.end); } }
  const a0 = JSON.parse(JSON.stringify(L[q0].attrs)); for (const k of ['pufu', 'pufuForm', 'pufuRes', 'notes', 'anchor', 'tid', 'fw', 'restart']) delete a0[k]; a0.pufuFrame = true;
  ed.mutate('', () => { for (let k = q0; k <= q1; k++) pufuShift(ed.doc.lines[k].attrs, 1); ed.insertLine(q0, FZ.newLine('', a0)); ed.caret = { line: q0, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; });
  render(); msg('取組でまとめました：名前を目的の言い方（〜を〜にする）で打つ', false, 7000); }
/* ---------- 1.0.16g プ譜の編集：役の名前で足す・組み替える（紙面でもツリーでも同じ）。プ譜に入ると帯がプ譜の帯に替わり、状態行に役が出る ---------- */
const PUFU_PH = { win: '', frame: '', mid: '', act: '', step: '', out: '成果物：' }; /* 1.0.16h 手引きは字にしない：空の箱に薄く出す（打ち始めると消える） */
const PUFU_GHOST = { 獲得目標: '与えられた使命を 1 文で', 勝利条件: 'どうなっていたら成功と言えるか', 取組: 'まとめる目的を「〜を〜にする」で', 中間目的: '〜している・〜できている状態', 施策: '誰が・何を・いつまでに', 段取り: '施策を進める手順・作業', 成果物: 'その状態に達したと判断する証拠になる物', 題: '題' };
const PUFU_LEGACY = /^[\s　]*（(?:獲得目標|勝利条件|取組|中間目的|施策|段取り)：[^）]*）[\s　]*$/; /* 1.0.16g までの、字で入れた手引き */
let pufuGh = { gen: -1, doc: null, map: new Map() };
function pufuGhostMap() { if (pufuGh.gen === ed.gen && pufuGh.doc === ed.doc) return pufuGh.map; const m = new Map(); const tx = i => ed.doc.lines[i].segs.map(g => g.text).join('');
  if (FZ.pufuBlocks) for (const B of FZ.pufuBlocks(ed.doc)) { const h = tx(B.head); if (!h.trim() || /^プ譜[：:][\s　]*$/.test(h)) m.set(B.head, PUFU_GHOST.題); for (const [q, it] of B.map) { const t = tx(q); if ((it.kind === 'node' || it.kind === 'frame') && !t.trim()) m.set(q, PUFU_GHOST[it.kind === 'frame' ? '取組' : FZ.pufuRoleName(it.depth)] || ''); else if (it.kind === 'cont' && it.out && /^[\s　]*成果物[\s　]*[：:][\s　]*$/.test(t)) m.set(q, PUFU_GHOST.成果物); } }
  pufuGh = { gen: ed.gen, doc: ed.doc, map: m }; return m; }
/* 薄い手引き：紙面の重ね（印刷・書き出しには出ない）。IME で打っている行には出さない */
function pufuGhosts(ov) { if (st.mode === 'tree' || !ed.lay) return; const M = pufuGhostMap(); if (!M.size) return; const pmap = ed.lay.pufuAt; ov.ghosts = []; ov.font = ed.doc.format.font;
  for (const [i, text] of M) { if (!text || (st.composing && ed.caret.line === i)) continue; const lm = ed.lay.lineMap[i]; const r = lm && lm.segs[0] && lm.segs[0].rows[0]; if (!r) continue; const col = r.glyphs.length ? (r.endCol != null ? r.endCol : r.left) : r.left; const pf = pmap && pmap.get(i); const right = pf ? pf.bx1 - 0.4 : (r.right || col + 30); ov.ghosts.push({ page: r.page, col, y: r.y, h: r.h || 1, text, max: Math.max(2, right - col) }); } }
/* 1.0.16g までの字の手引き（（勝利条件：…）など）は、開いたときに空にする（薄い手引きになる） */
function pufuMigrate(doc) { if (!FZ.pufuBlocks) return 0; let n = 0; for (const B of FZ.pufuBlocks(doc)) { const h = doc.lines[B.head]; if (h.segs.length === 1 && /^プ譜[：:]（題）$/.test(h.segs[0].text)) { h.segs[0].text = 'プ譜：'; h.segs[0].marks = h.segs[0].marks.slice(0, 3); n++; } for (const [q, it] of B.map) { if (it.kind !== 'node' && it.kind !== 'frame') continue; const ln = doc.lines[q]; if (ln.segs.length === 1 && PUFU_LEGACY.test(ln.segs[0].text)) { ln.segs[0].text = ''; ln.segs[0].marks = []; n++; } } } return n; }
const PUFU_NM = { win: '勝利条件', frame: '取組', mid: '中間目的', act: '施策', step: '段取り', out: '成果物' };
function pufuCtx(line = ed.caret.line) { const pz = FZ.pufuAt && FZ.pufuAt(ed.doc, line); if (!pz) return null; const B = pz.B; let it = pz.it; if (it && it.kind === 'cont') it = B.map.get(it.owner); const chain = []; for (let x = it; x && (x.kind === 'node' || x.kind === 'frame'); x = x.parent != null ? B.map.get(x.parent) : null) chain.push(x);
  const nd = d => chain.find(x => x.kind === 'node' && x.depth === d) || null; const goal = B.roots.map(q => B.map.get(q)).find(x => x && x.kind === 'node') || null;
  return { B, it, goal, win: nd(1), mid: nd(2), act: nd(3), step: chain.find(x => x.kind === 'node' && x.depth >= 4) || null, frame: chain.find(x => x.kind === 'frame') || null, res: !!(it && /^res/.test(it.kind)) }; }
const pufuClean = a => { const b = JSON.parse(JSON.stringify(a)); for (const k of ['pufu', 'pufuForm', 'pufuRes', 'pufuFrame', 'notes', 'anchor', 'tid', 'fw', 'restart', 'figs', 'breakBefore']) delete b[k]; return b; };
const pufuChildA = a => a.list ? { list: { kind: a.list.kind === 'num' ? 'num' : 'bullet', level: Math.min(7, (a.list.level | 0) + 1) } } : (a.style === 'num' || a.style === 'sym') && (a.level | 0) < 7 ? { style: a.style, level: (a.level | 0) + 1 } : { list: { kind: 'bullet', level: 0 } };
/* 役で足す：いまいる所（カーソル・選んだ節）から、その役の入る所を決める。置いた字（（ ）の手引き）は選んだ状態にして、打てば置き換わる */
function pufuAdd(k) { const X = pufuCtx(); if (!X) { msg('プ譜の中にカーソルを置いてから（プ譜が無ければ「入れる」で型を）', true); return false; } if (X.res) { msg('資源と制約の中には足せない：プ譜の項目を選んでから', true); return false; }
  const B = X.B, L = ed.doc.lines, end = q => subEnd(L, q, B.end); const sib = x => ({ at: end(x.line) + 1, attrs: pufuClean(L[x.line].attrs), frame: x.kind === 'frame' }); const kid = x => ({ at: end(x.line) + 1, attrs: pufuChildA(L[x.line].attrs) });
  let P = null, why = '';
  if (k === 'win') { if (X.win) P = sib(X.win); else if (X.goal) P = kid(X.goal); else why = '先に獲得目標を書く（プ譜の題のすぐ下の項目）'; }
  else if (k === 'frame') { const w = X.win || (X.goal && X.goal.kids.length ? B.map.get(X.goal.kids[0]) : null); if (!w) why = '取組は勝利条件の下に作る：先に勝利条件を'; else if (X.frame) P = sib(X.frame); else if (X.mid) P = { ...sib(X.mid), frame: true }; else P = { ...kid(w), frame: true }; }
  else if (k === 'mid') { if (X.mid) P = sib(X.mid); else if (X.frame) P = kid(X.frame); else if (X.win) P = kid(X.win); else why = '中間目的は勝利条件（か取組）の下に作る：勝利条件を選んでから'; }
  else if (k === 'act') { if (X.act) P = sib(X.act); else if (X.mid) P = kid(X.mid); else why = '施策は中間目的の下に作る：中間目的を選んでから'; }
  else if (k === 'step') { if (X.step) P = sib(X.step); else if (X.act) P = kid(X.act); else why = '段取りは施策の下に作る：施策を選んでから'; }
  else if (k === 'out') { if (!X.mid) why = '成果物は中間目的の箱に書く：中間目的を選んでから'; else { const oc = X.mid.conts.find(q => (B.map.get(q) || {}).out); if (oc != null) { ed.anchor = null; ed.setCaret({ line: oc, seg: 0, off: L[oc].segs[0].text.length }); render(); scrollToCaret(true); msg('成果物はもうある：続きを書く'); return true; } P = { at: X.mid.line + 1, attrs: pufuChildA(L[X.mid.line].attrs) }; } }
  if (!P) { msg(why, true); return false; }
  const text = PUFU_PH[k], fr = k === 'frame' || P.frame; ed.mutate('', () => { const a = JSON.parse(JSON.stringify(P.attrs)); if (fr) a.pufuFrame = true; else delete a.pufuFrame; ed.insertLine(P.at, FZ.newLine(text, a)); if (k === 'frame') ed.insertLine(P.at + 1, FZ.newLine(PUFU_PH.mid, pufuChildA(a)));
    const n = ed.doc.lines[P.at].segs[0].text.length; ed.caret = { line: P.at, seg: 0, off: n, vcol: null, vrow: 0 }; ed.anchor = null; });
  if (st.mode !== 'tree') { render(); scrollToCaret(true); } msg(k === 'out' ? '成果物を書く（その状態に達したと判断する証拠になる物）' : `${PUFU_NM[k]}を足しました：そのまま打つ（薄い字は手引き。打ち始めると消える）${k === 'frame' ? '。中に中間目的を 1 つ入れた' : ''}`, false, 7000); return true; }
/* 消す：項目を子ごと（取組なら外して中身を残す）。獲得目標・題は消さない */
function pufuDel() { const X = pufuCtx(); if (!X || !X.it) { msg('消す項目にカーソルを置いてから（プ譜の題は「プ譜に」で外す）', true); return false; } if (X.it.kind === 'frame') { pufuFrameToggle(); return true; } if (X.res) { msg('資源と制約の行は紙面で消す', true); return false; }
  if (X.it.depth === 0) { msg('獲得目標は消さない（書き換える）', true); return false; } const L = ed.doc.lines, q = X.it.line, z = subEnd(L, q, X.B.end), nm = FZ.pufuRoleOf(X.B, X.it);
  ed.mutate('', () => { for (let k = z; k >= q; k--) ed.removeLine(k); const to = Math.max(0, q - 1); ed.caret = { line: to, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; }); if (st.mode !== 'tree') render(); msg(`${nm}を消しました${z > q ? `（子・続き ${z - q} 行も）` : ''}。Ctrl+Z で戻る`); return true; }
/* 紙面でもツリーでも：ツリーなら選んだ節の行で行い、できた行を選んでその場で書く */
function pufuRun(fn) { if (st.mode !== 'tree') return fn(); const n = treeNodeSel(); if (!n || n.line == null || n.root) { msg('プ譜の節を選んでから', true); return false; } ed.anchor = null; ed.caret = { line: n.line, seg: 0, off: 0, vcol: null, vrow: 0 }; const before = ed.doc.lines.length; const ok = fn(); if (!ok) return false;
  const L = ed.doc.lines[Math.min(ed.caret.line, ed.doc.lines.length - 1)]; st.tree.sel = L; st.tree.multi.clear(); treeRefresh(); if (ed.doc.lines.length > before && !L.segs.map(g => g.text).join('').trim()) { ed.anchor = null; openTreeEdit(true); } return true; }
function pufuMove(d) { if (st.mode === 'tree') { run('tv:' + d); return; } if (!pufuCtx()) { msg('プ譜の中にカーソルを置いてから', true); return; } run('sx:' + d); }
/* プ譜に入ったら帯をプ譜の帯に、出たら元の帯に（自分で別の帯にしたら追わない） */
function pufuAutoBand() { if (st.mode !== 'text' || st.form) return false; const inP = !!pufuCtxCached(); if (inP === st.pufuIn) return false; st.pufuIn = inP;
  if (inP && st.group !== 'pufu' && st.group !== 'pufuAi') { st.pufuPrev = st.group; st.group = 'pufu'; st.pufuAuto = true; st.armed = false; drawFkeys(); } else if (!inP && st.pufuAuto && (st.group === 'pufu' || st.group === 'pufuAi')) { st.group = st.pufuPrev || null; st.pufuAuto = false; drawFkeys(); } else return false; return true; }
let pufuSpan = { gen: -1, doc: null, list: [] }; function pufuCtxCached() { if (pufuSpan.gen !== ed.gen || pufuSpan.doc !== ed.doc) pufuSpan = { gen: ed.gen, doc: ed.doc, list: FZ.pufuBlocks ? FZ.pufuBlocks(ed.doc).map(B => [B.head, B.end]) : [] }; const L = ed.caret.line; return pufuSpan.list.some(([h, e]) => L >= h && L < e); }
/* 資源と制約（廟算八要素）を足す：プ譜の最後に。あればそこへ */
function pufuRes() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) { msg('資源と制約は、プ譜の節の中で足す', true); return; } const B = pz.B;
  if (B.res) { ed.setCaret({ line: B.res.line, seg: 0, off: 0 }); render(); scrollToCaret(true); msg('資源と制約はもうあります'); return; }
  const r0 = B.roots.length ? ed.doc.lines[B.roots[0]].attrs : { list: { kind: 'bullet', level: 0 } }; const base = JSON.parse(JSON.stringify(r0)); for (const k of ['pufu', 'pufuFrame', 'notes', 'anchor', 'tid', 'fw', 'restart']) delete base[k]; base.pufuRes = true;
  const item = base.list ? { list: { kind: 'bullet', level: Math.min(7, (base.list.level | 0) + 1) } } : { list: { kind: 'bullet', level: 0 } }; delete item.pufuRes;
  const at = B.end; ed.mutate('', () => { const specs = [{ text: '資源と制約（廟算八要素）', attrs: base }, ...FZ.PUFU_RES_KEYS.map(k => ({ text: k + '：', attrs: item }))]; specs.forEach((sp, k) => ed.insertLine(at + k, FZ.newLine(sp.text, JSON.parse(JSON.stringify(sp.attrs))))); ed.caret = { line: at + 1, seg: 0, off: ed.doc.lines[at + 1].segs[0].text.length, vcol: null, vrow: 0 }; ed.anchor = null; });
  render(); scrollToCaret(true); msg('資源と制約（廟算八要素）を足しました：いまの状況を書く（無いものは「記載なし」）', false, 7000); }
/* 文章からプ譜の下書きを起こす指示文を写す（1.0.14e：欄で元の文章の種類と本文の範囲を選ぶ。議事録・発言録・個人の文章ごとの読み方） */
function pufuDraftBody(range) { if (range === 'paste') return { md: (st.pdraft && st.pdraft.text) || '', what: '貼った文章' }; if (range === 'doc') return { md: FZ.toGfm(ed.doc, { fz: false }), what: '文書全体' };
  const sc = aiScope(false); if (range === 'sel') { const sl = ed.sel(); if (sl && !(sl.a.line === sl.b.line && sl.a.off === sl.b.off)) { const a = Math.min(sl.a.line, sl.b.line), b = Math.max(sl.a.line, sl.b.line); return { md: FZ.toGfm(sliceDoc(a, b), { fz: false }), what: '選んだ範囲' }; } }
  if (sc.tree) return { md: treeCopyText(), what: sc.what }; if (sc.range) return { md: FZ.toGfm(sliceDoc(sc.range[0], sc.range[1]), { fz: false }), what: sc.what }; return { md: FZ.toGfm(ed.doc, { fz: false }), what: '文書全体' }; }
async function pufuPromptCopy(kind = 'auto', range = 'sec', title = '') { const { md, what } = pufuDraftBody(range); if (!md.trim()) { msg('本文がありません', true); return false; }
  const t = FZ.pufuPrompt(md, title, pufuToday(), kind); const ok = await copyText(t); const kn = (FZ.PUFU_SOURCES.find(x => x[0] === kind) || [0, ''])[1];
  msg(ok ? `プ譜の下書きを起こす指示文を写しました（本文：${what}、${md.length.toLocaleString()} 字、${kn}）。AI に貼り、答えは ${K('pufuImport')} で取り込む` : '写せませんでした', !ok, 10000); return ok; }
FORMS.pdraft = {
  html() { const P = st.pdraft = st.pdraft || { kind: 'auto', range: ed.sel() ? 'sel' : 'sec', title: '', text: '' };
    return `<span class="ttl">プ譜の下書きを AI に</span><label>元の文章 ${cyc('kind', FZ.PUFU_SOURCES, P.kind)}</label><label>本文 ${cyc('range', [['sel', '選んだ範囲'], ['sec', 'この節'], ['doc', '文書全体'], ['paste', '下に貼る']], P.range)}</label><label>題 <input name="title" value="${esc(P.title)}" placeholder="空なら AI が付ける" size="14"></label>${P.range === 'paste' ? `<textarea name="text" class="chdata aimd" rows="3" spellcheck="false" placeholder="議事録・発言録・メモなどを貼る（文書には入れない）">${esc(P.text)}</textarea>` : ''}<button type="button" class="pri" data-act="go" title="指示文を写す（Ctrl+Enter）">写す</button><span class="hintl">答えは ${esc(K('pufuImport'))} で取り込む</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.pri', enter(e) { if (!e || e.ctrlKey || e.metaKey || e.target.tagName !== 'TEXTAREA') this.act('go'); },
  change(name) { const P = st.pdraft; if (!P || !name) return; if (name === 'kind') P.kind = cycVal('kind'); if (name === 'range') { P.range = cycVal('range'); drawSub(); } if (name === 'title') P.title = (sub.querySelector('input[name="title"]') || {}).value || ''; if (name === 'text') P.text = (sub.querySelector('textarea[name="text"]') || {}).value || ''; },
  async act(a) { if (a === 'cancel') { closeForm(); return; } if (a !== 'go') return; const P = st.pdraft; const ta = sub.querySelector('textarea[name="text"]'); if (ta) P.text = ta.value; const ti = sub.querySelector('input[name="title"]'); if (ti) P.title = ti.value; closeForm(); await pufuPromptCopy(P.kind, P.range, P.title.trim()); } };
/* 1.0.14d 点検を頼む・次の局面を頼む：このプ譜を役の名前付きで指示文に入れて写す。写した範囲を覚えるので、答えは「AI から戻す」で三者比較 */
function pufuToday() { const d = new Date(), z = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`; }
async function pufuAsk(kind, info) { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) { msg('カーソルをプ譜の中に置いてから', true); return false; } const B = pz.B; const md = FZ.pufuToMd(ed.doc, B);
  const t = kind === 'next' ? FZ.pufuPromptNext(md, info, pufuToday()) : FZ.pufuPromptReview(md); rememberScope(rangeIdx(B.head, B.end - 1), 'プ譜「' + ed.doc.lines[B.head].segs.map(sg => sg.text).join('').slice(0, 16) + '」');
  const ok = await copyText(t); msg(ok ? `${kind === 'next' ? '次の局面' : '点検と直し'}の指示文を写しました（このプ譜入り）。AI に貼り、答えは ${K('aiReturn')} に貼って比べる（自分の直しは保たれる）` : '写せませんでした', !ok, 10000); return ok; }
FORMS.pnext = {
  html() { return `<span class="ttl">次の局面を頼む</span><textarea name="info" class="chdata aimd" rows="3" spellcheck="false" placeholder="新しい情報（会議の記録・進捗・やってみてわかったこと）を貼る。このプ譜と一緒に指示文に入れて写す"></textarea><button type="button" class="pri" data-act="go" title="指示文を写す（Ctrl+Enter）">写す</button><span class="hintl">答えは ${esc(K('aiReturn'))} で比べる</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'textarea', enter(e) { if (e && (e.ctrlKey || e.metaKey)) this.act('go'); },
  async act(a) { if (a === 'cancel') { closeForm(); return; } if (a !== 'go') return; const ta = sub.querySelector('textarea[name="info"]'); const v = ta ? ta.value.trim() : ''; if (!v) { msg('新しい情報を貼ってください', true); return; } closeForm(); await pufuAsk('next', v); } };
/* ---------- 1.0.14e 局面と気づき ----------
   局面：今のプ譜を、その時点の認識として原本に記録する（役の名前付きの Markdown。見出しの節の名札で結ぶ）。後で今のプ譜と比べて、足した・直した・消した所を示す。
   気づき：やってみてわかったことを、項目のすぐ後の「気づき：」の段落に書く（箱の中の点線の吹き出し。次の局面の指示文が反映する） */
const toHalf = t => String(t).replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0));
function pufuPhaseList(B) { const key = ed.doc.lines[B.head].attrs.anchor; return key ? (ed.doc.pufuPhases || []).filter(p => p.key === key).sort((a, b) => a.no - b.no) : []; }
function pufuPhaseSave() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) { msg('カーソルをプ譜の中に置いてから', true); return; } const B = pz.B, L = ed.doc.lines; const title = L[B.head].segs.map(sg => sg.text).join(''); const m = toHalf(title).match(/局面\s*(\d+)/);
  const list = pufuPhaseList(B); const no = m ? +m[1] : (list.length ? list[list.length - 1].no + 1 : 1); const md = FZ.pufuToMd(ed.doc, B).replace(/\n+$/, ''); const had = list.some(p => p.no === no);
  ed.mutate('', () => { const a = ed.doc.lines[B.head].attrs; if (!a.anchor) { const used = new Set(ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean)); let k = 1; while (used.has('h' + k)) k++; a.anchor = 'h' + k; }
    const arr = (ed.doc.pufuPhases = ed.doc.pufuPhases || []); const rec = { key: a.anchor, no, date: pufuToday(), title, md }; const ex = arr.findIndex(p => p.key === a.anchor && p.no === no); if (ex >= 0) arr[ex] = rec; else arr.push(rec); });
  render(); msg(`局面 ${no} を${had ? '記録し直しました' : '記録しました'}（原本に残る。${K('pufuPhaseCmp')} で今と比べる）。次の局面へ進むときは、題の「局面」の番号を進めて書き直す`, false, 9000); }
function pufuCmpNow() { const C = st.pufuCmp; if (!C) return null; const head = ed.doc.lines.indexOf(C.headObj); if (head < 0) return null; const B = FZ.pufuBlocks(ed.doc).find(b => b.head === head); if (!B) return null; const ph = pufuPhaseList(B).find(p => p.no === C.no); if (!ph) return null; return { B, ph, ...FZ.pufuPhaseDiff(ed.doc, B, ph.md) }; }
function pufuPhaseCmp() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz) { msg('カーソルをプ譜の中に置いてから', true); return; } const list = pufuPhaseList(pz.B); if (!list.length) { msg(`このプ譜には記録した局面がありません（${K('pufuPhaseSave')} で記録する）`, true); return; }
  st.pufuCmp = { headObj: ed.doc.lines[pz.B.head], no: list[list.length - 1].no, i: -1 }; openForm('phase'); FORMS.phase.log(); requestOverlay(); }
function pufuInsight() { const pz = FZ.pufuAt(ed.doc, ed.caret.line); if (!pz || !pz.it) { msg('気づきは、プ譜の項目に付ける（カーソルを項目に）', true); return; } const B = pz.B; let it = pz.it; if (it.kind === 'cont') it = B.map.get(it.owner); if (!it || it.kind !== 'node') { msg('気づきは、獲得目標・勝利条件・中間目的・施策・段取りの項目に付ける', true); return; }
  const at = (it.conts.length ? it.conts[it.conts.length - 1] : it.line) + 1; ed.mutate('', () => { ed.insertLine(at, FZ.newLine('気づき：', {})); ed.caret = { line: at, seg: 0, off: 4, vcol: null, vrow: 0 }; ed.anchor = null; }); render(); scrollToCaret(true); focusTA(); msg('気づきの段落を足しました：やってみてわかったことを書く（箱の中の点線の吹き出し。次の局面の指示文が反映する）', false, 8000); }
FORMS.phase = {
  html() { const R2 = pufuCmpNow(); if (!R2) return `<span class="ttl">局面と比べる</span><span class="info">比べる局面がありません</span><button type="button" data-act="cancel">閉じる Esc</button>`;
    const list = pufuPhaseList(R2.B); const a = [...R2.status.values()].filter(v => v === 'add').length, c = R2.status.size - a, r = R2.removed.length; const C = st.pufuCmp; const ch = [...R2.status.keys()].sort((x, y) => x - y); const cur = C.i >= 0 && C.i < ch.length ? ch[C.i] : null;
    const curTxt = cur == null ? (a + c + r ? 'Enter で順に見る' : '違いはありません') : R2.status.get(cur) === 'add' ? 'この局面で足した' : '直した：前は「' + String(R2.was.get(cur) || '').replace(/^\s*-\s*/, '').slice(0, 40) + '」';
    return `<span class="ttl">局面と比べる</span><label>前の局面 ${cyc('ph', list.map(p => [String(p.no), `局面 ${p.no}（${p.date}）`]), String(C.no))}</label><span class="info">足した <b>${a}</b>　直した <b>${c}</b>　<span title="${esc(R2.removed.join('\n'))}">消した <b>${r}</b></span></span><button type="button" data-act="prev">↑ 前</button><button type="button" class="pri" data-act="next">次 ↓</button><span class="info ckinfo">${esc(curTxt)}</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'button.pri', enter(e) { this.act(e && e.shiftKey ? 'prev' : 'next'); },
  change(name) { if (name !== 'ph' || !st.pufuCmp) return; st.pufuCmp.no = +cycVal('ph'); st.pufuCmp.i = -1; this.log(); drawSub(); requestOverlay(); },
  log() { const R2 = pufuCmpNow(); if (!R2) return; setConvLog({ title: `局面 ${R2.ph.no}（${R2.ph.date}）からの変化`, target: 'phase', items: [...[...R2.status.entries()].sort((x, y) => x[0] - y[0]).map(([q, v]) => ({ what: v === 'add' ? '足した' : '直した（前は「' + String(R2.was.get(q) || '').replace(/^\s*-\s*/, '').slice(0, 60) + '」）', lines: [q] })), ...R2.removed.map(t => ({ what: '消した：' + t.replace(/^\s*-\s*/, ''), lines: [] }))], time: Date.now() }); },
  act(a) { if (a === 'cancel') { st.pufuCmp = null; closeForm(); requestOverlay(); return; } const R2 = pufuCmpNow(); if (!R2) return; const ch = [...R2.status.keys()].sort((x, y) => x - y); if (!ch.length) return; const C = st.pufuCmp;
    C.i = C.i < 0 ? (a === 'next' ? 0 : ch.length - 1) : (C.i + (a === 'next' ? 1 : -1) + ch.length) % ch.length; ed.setCaret({ line: ch[C.i], seg: 0, off: 0 }); render(); scrollToCaret(true); drawSub(); requestOverlay(); } };
/* AI の答えを取り込む */
FORMS.pimport = {
  html() { return `<span class="ttl">プ譜を取り込む</span><textarea name="md" class="chdata aimd" rows="3" spellcheck="false" placeholder="AI の答え（「# プ譜：題」「- 獲得目標：…」の箇条書き）を貼る。${K('pufuPrompt')} の指示文で起こしたもの"></textarea><button type="button" class="pri" data-act="go" title="カーソルの所にプ譜の節として入れる（Ctrl+Enter）">取り込む</button><span class="hintl">役の名前は外して段に、〔推測〕は点線の箱、読み取れなかったことは付箋に</span><button type="button" data-act="cancel">閉じる Esc</button>`; },
  focus: 'textarea', enter(e) { if (e && (e.ctrlKey || e.metaKey)) this.act('go'); },
  act(a) { if (a === 'cancel') { closeForm(); return; } if (a !== 'go') return; const ta = sub.querySelector('textarea[name="md"]'); const P = FZ.pufuFromMd(ta ? ta.value : '');
    if (!P.items.length) { msg('役の名前付きの箇条書き（「- 獲得目標：…」）が見つかりません', true); return; }
    const { lines, note } = FZ.pufuLinesFromMd(P, fwLevelAt(ed.caret.line)); closeForm(); pufuInsert(lines, note);
    const g = P.items.filter(x => /〔推測〕/.test(x.text)).length; msg(`プ譜を取り込みました：項目 ${P.items.length}${g ? `・〔推測〕 ${g}（点線の箱）` : ''}${P.questions.length ? `・問い ${P.questions.length}（付箋）` : ''}${P.warn.length ? '・注意 ' + P.warn.length + '（付箋）' : ''}。${K('pufuCheck')} で点検`, false, 10000); } };
/* 点検：Enter で順に見る */
/* 1.0.16h プ譜の役の名前：構造の名前（獲得目標…）はそのまま、紙面・書き出し・ツリーで見せる名前だけを変える（プ譜の題の行に覚える。同じ役はすべて同じ名前） */
FORMS.pnames = {
  html() { const X = pufuCtx(); if (!X) return `<span class="ttl">役の名前</span><span class="info">プ譜の中で使う</span><button type="button" data-act="cancel">閉じる Esc</button>`; const cur = ed.doc.lines[X.B.head].attrs.pufuNames || {};
    return `<span class="ttl">役の名前</span><label>型 <select name="preset"><option value="">（選ぶ）</option>${FZ.PUFU_NAME_PRESETS.map(([id, nm]) => `<option value="${id}">${esc(nm)}</option>`).join('')}</select></label>${FZ.PUFU_NAME_KEYS.map(k => `<label class="pn">${esc(k)} <input name="n_${esc(k)}" value="${esc(cur[k] || '')}" placeholder="${esc(k)}" size="${Math.max(4, k.length + 2)}"></label>`).join('')}<button type="button" class="pri" data-act="ok" title="この名前で見せる（Enter）">決める</button><button type="button" data-act="std" title="すべてプ譜の言葉に戻す">既定に</button><button type="button" data-act="cancel">閉じる Esc</button><span class="hintl">空欄はプ譜の言葉のまま</span>`; },
  focus: 'input', enter() { this.act('ok'); },
  change(name) { if (name !== 'preset') return; const P = FZ.PUFU_NAME_PRESETS.find(x => x[0] === fval('preset')); if (!P) return; for (const k of FZ.PUFU_NAME_KEYS) { const el = sub.querySelector(`input[name="n_${k}"]`); if (el) el.value = P[2][k] && P[2][k] !== k ? P[2][k] : ''; } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const X = pufuCtx(); if (!X) { closeForm(); return; } const m = {}; if (a === 'ok') for (const k of FZ.PUFU_NAME_KEYS) { const v = (fval('n_' + k) || '').replace(/[\s\[\]|=]/g, ''); if (v && v !== k) m[k] = v; }
    ed.mutate('', () => { const at = ed.doc.lines[X.B.head].attrs; if (Object.keys(m).length) at.pufuNames = m; else delete at.pufuNames; }); closeForm(); render(); msg(Object.keys(m).length ? `役の名前を変えました（${Object.entries(m).map(([k, v]) => k + '→' + v).join('・')}）。構造はそのまま。Ctrl+Z で戻る` : '役の名前をプ譜の言葉に戻しました', false, 8000); } };
cmd('pufuGroup', 'プ譜…（ゴールから逆算して道筋を描く。紙面では右から左へ枝分かれ）', '挿入', '', () => toggleGroup('pufu'), 'プ譜 プロジェクト 進行 勝利条件 中間目的 施策 逆算 企画');
cmd('pufuAiGroup', 'プ譜の AI（下書き・下読みを頼む・次の局面・取り込む・戻す）', '挿入', '', () => toggleGroup('pufuAi'), 'プ譜 AI 下書き 点検 局面 取り込む');
for (const [k, nm, tip] of [['win', '勝利条件', '獲得目標の下。いまの勝利条件の後に'], ['frame', '取組', '勝利条件の下に、中間目的を 1 つ入れて'], ['mid', '中間目的', 'いまの中間目的の後。取組・勝利条件を選んでいればその中の最後に'], ['act', '施策', 'いまの施策の後。中間目的を選んでいればその下の最後に'], ['step', '段取り', '施策の下'], ['out', '成果物', '中間目的の箱の中に']]) cmd('pfAdd:' + k, `プ譜：${nm}を足す（${tip}）`, '挿入', '', () => pufuRun(() => pufuAdd(k)), 'プ譜 足す ' + nm);
cmd('pf:up', 'プ譜：上へ（同じ役の中で、子ごと）', '挿入', '', () => pufuMove('up'), 'プ譜 上へ 並べ替え'); cmd('pf:down', 'プ譜：下へ（同じ役の中で、子ごと）', '挿入', '', () => pufuMove('down'), 'プ譜 下へ 並べ替え');
cmd('pf:out', 'プ譜：上の役へ（子ごと一段浅く。施策→中間目的など）', '挿入', '', () => pufuMove('out'), 'プ譜 役 浅く 格上げ'); cmd('pf:in', 'プ譜：下の役へ（子ごと一段深く。中間目的→施策など）', '挿入', '', () => pufuMove('in'), 'プ譜 役 深く 格下げ');
cmd('pf:del', 'プ譜：この項目を消す（子ごと。取組なら外して中身を残す）', '挿入', '', () => pufuRun(() => pufuDel()), 'プ譜 消す 削除');
cmd('pufuNew', 'プ譜を入れる（獲得目標・勝利条件・取組・中間目的・施策・資源と制約の型）', '挿入', '', () => pufuNew(), 'プ譜 型 雛形 プロジェクト');
cmd('pufuMark', 'この節をプ譜にする／戻す（子の木を右から左へ枝分かれする形に組む）', '挿入', '', () => pufuMark(), 'プ譜 印');
cmd('pufuFrame', '取組でまとめる／外す（中間目的をまとめ、目的の名前を付ける。紙面では太罫で囲み、取組1・取組2…）', '挿入', '', () => pufuFrameToggle(), 'プ譜 取組 枠 グループ 囲む まとめる');
cmd('pufuRes', '資源と制約（廟算八要素）を足す', '挿入', '', () => pufuRes(), 'プ譜 廟算八要素 資源 制約 ひと お金 時間');
cmd('pufuFormAuto', 'プ譜の形：自動（横長の紙面なら列の図、縦長なら字下げ）', '挿入', '', () => pufuForm('auto'), 'プ譜 形 自動');
cmd('pufuFormTree', 'プ譜の形：字下げ（字下げの木を左右逆転）', '挿入', '', () => pufuForm('tree'), 'プ譜 形 字下げ 縦長');
cmd('pufuFormCols', 'プ譜の形：列の図（右から 勝利条件・獲得目標｜中間目的｜施策）', '挿入', '', () => pufuForm('cols'), 'プ譜 形 列 横長 図');
cmd('pufuCheck', 'プ譜の診断（右の欄の「プ譜」：中間目的は状態か・数・施策の担当と期日・取組の名前・〔推測〕）', '挿入', '', () => { healthCache = null; const H = healthGet(); const r = H.rows.find(x => x.sec === 'プ譜'); st.healthOpen = r ? r.key : null; if (st.side !== 'health') toggleSide('health'); else drawSide(); requestOverlay(); msg(r ? `プ譜：直す所 ${H.rows.filter(x => x.sec === 'プ譜' && !x.info).reduce((t, x) => t + x.n, 0)}・確かめる所 ${H.rows.filter(x => x.sec === 'プ譜' && x.info).reduce((t, x) => t + x.n, 0)}（右の欄の「プ譜」）` : FZ.pufuBlocks(ed.doc).length ? 'プ譜：気になる所はありません' : 'プ譜がありません'); }, 'プ譜 診断 点検 確認 チェック');
cmd('pufuNames', 'プ譜の役の名前…（紙面・書き出しで見せる名前。獲得目標→目指すこと など。構造の名前はそのまま）', '挿入', '', () => { if (!pufuCtxCached()) { msg('プ譜の中にカーソルを置いてから', true); return; } toggleForm('pnames'); }, 'プ譜 役 名前 表示 呼び方 言い換え 獲得目標 勝利条件');
cmd('pufuPrompt', 'プ譜の下書きを AI に…（議事録・発言録・個人の文章などから。元の種類と本文の範囲を選んで指示文を写す）', '挿入', '', () => { st.pdraft = null; toggleForm('pdraft'); }, 'プ譜 AI ChatGPT Copilot プロンプト 指示文 文章から 議事録 発言録 メモ 下書き');
cmd('pufuPhaseSave', '局面を記録（今のプ譜を、その時点の認識として原本に残す。題の「局面 n」の番号で）', '挿入', '', () => pufuPhaseSave(), 'プ譜 局面 記録 スナップショット 版');
cmd('pufuPhaseCmp', '局面と比べる…（記録した局面から、足した・直した・消した所を紙面に印）', '挿入', '', () => pufuPhaseCmp(), 'プ譜 局面 比べる 差分 変化');
cmd('pufuInsight', '気づきを書く（やってみてわかったことを、この項目の箱の中の吹き出しに）', '挿入', '', () => pufuInsight(), 'プ譜 気づき 吹き出し やってみて 振り返り');
cmd('pufuReview', 'プ譜の点検と直しを AI に頼む（このプ譜入りの指示文を写す。答えは AI から戻すで比べる）', '挿入', '', () => pufuAsk('review'), 'プ譜 AI 点検 直し 壁打ち ChatGPT Copilot');
cmd('pufuNext', 'プ譜の次の局面を AI に頼む…（新しい情報を貼り、このプ譜と一緒に指示文を写す）', '挿入', '', () => { if (!FZ.pufuAt(ed.doc, ed.caret.line)) { msg('カーソルをプ譜の中に置いてから', true); return; } openForm('pnext'); }, 'プ譜 AI 局面 更新 議事録 進捗');
cmd('pufuImport', 'AI の答えをプ譜として取り込む…（役の名前付きの箇条書きを貼る）', '挿入', '', () => openForm('pimport'), 'プ譜 AI 貼り付け 取り込む');
/* ---------- P17：写した時・今・返事の三者比較 ----------
   AI に写した時の範囲の本文（st.aiScope.base）を覚えておき、戻ってきた返事と今の文書を比べる時に、違いを「AI だけ」「自分だけ」「両方」に分ける。
   自分だけの直し（AI が元の字のまま返した所）は既定で取り込みの候補に出さない（自分の直しを AI の古い字で戻さない）。両方で直した所は「両方で変更」と出して選ばせる。
   写した時の本文が無い（写した範囲以外と比べる・写していない）時は二者比較と出す */
function threeWay(S) { if (!S.base) { for (const h of S.hunks) h.who = null; return; }
  const O = S.base, sigO = O.lines.map(l => FZ.lineSig(O, l)), sigA = S.snap, A = ed.doc; const PA = S.idx.filter(i => sigA[i] !== '|'), PO = sigO.map((x, k) => k).filter(k => sigO[k] !== '|'), PB = S.sigB.map((x, k) => k).filter(k => S.sigB[k] !== '|');
  const pairs = (X, Y, PX, PY) => { const H = FZ.diffSigs(PX.map(i => X[i]), PY.map(j => Y[j])); const m = new Map(); let a = 0, b = 0; for (const h of H) { while (a < h.a[0] && b < h.b[0]) m.set(PX[a++], PY[b++]); a = h.a[1]; b = h.b[1]; } while (a < PX.length && b < PY.length) m.set(PX[a++], PY[b++]); return m; };
  const AO = pairs(sigA, sigO, PA, PO), BO = pairs(S.sigB, sigO, PB, PO); const det = (doc, l) => { const d = FZ.lineDetail(doc, l); return d.link + '\u0003' + d.emphLoose; };
  /* 何行かにまたがる塊は、行の対ごとに分ける（隣り合う行の一方を自分が、もう一方を AI が直した時に混ぜない） */
  const split = []; for (const h of S.hunks) { const rem = h.rem.filter(i => sigA[i] !== '|'), bs = []; for (let j = h.b[0]; j < h.b[1]; j++) if (S.sigB[j] !== '|') bs.push(j);
    if (h.detail || rem.length + bs.length <= 2 && !(rem.length === 2 || bs.length === 2)) { split.push(h); continue; }
    let last = rem.length ? rem[0] - 1 : h.at - 1; for (const op of FZ.alignLines(rem.map(i => sigA[i]), bs.map(j => S.sigB[j]))) {
      if (op.t === 'p') { const i = rem[op.i], j = bs[op.j]; split.push({ rem: [i], at: i, b: [j, j + 1], kind: 'chg', cats: FZ.hunkCats([sigA[i]], [S.sigB[j]]), size: 2, key: sigA[i] + '\u0001' + S.sigB[j] }); last = i; }
      else if (op.t === 'd') { const i = rem[op.i]; split.push({ rem: [i], at: i, b: [0, 0], kind: 'del', cats: FZ.hunkCats([sigA[i]], []), size: 1, key: sigA[i] + '\u0001' }); last = i; }
      else { const j = bs[op.j]; split.push({ rem: [], at: last + 1, b: [j, j + 1], kind: 'add', cats: FZ.hunkCats([], [S.sigB[j]]), size: 1, key: '\u0001' + S.sigB[j] }); } } }
  S.hunks = split.filter(h => !S.skip.has(h.key));
  for (const h of S.hunks) { const rem = h.rem.filter(i => sigA[i] !== '|'), bs = []; for (let j = h.b[0]; j < h.b[1]; j++) if (S.sigB[j] !== '|') bs.push(j);
    let self, ai;
    if (h.detail) { const L = rem[0], j = bs[0], o = AO.get(L); const dO = o != null ? det(O, O.lines[o]) : null, dA = det(A, A.lines[L]), dB = det(S.B, S.B.lines[j]); self = dO == null || dA !== dO; ai = dO == null || dB !== dO; }
    else { self = rem.some(i => !AO.has(i)) || (!rem.length && bs.some(j => BO.has(j))); ai = bs.some(j => !BO.has(j)) || (!bs.length && rem.some(i => AO.has(i))); if (!self && !ai) ai = true; }
    h.who = self && ai ? 'both' : self ? 'self' : 'ai'; } }
FORMS.figref = {
  html() { const L = ed.figList(); const nums = ed.lay.figNums; return `<span class="ttl">図番を入れる</span>${L.map((x, i) => { const n = nums && nums.get(x.fg.id); return `<button type="button" data-act="r${i}">${i < 9 ? (i + 1) + ' ' : ''}${esc(n ? n.label : x.fg.kind)}${x.fg.title ? '　' + esc(x.fg.title) : ''}</button>`; }).join('')}<span class="hintl">番号は図表の順番に追従します</span><button type="button" data-act="cancel">取消 Esc</button>`; }, focus: 'button',
  key(e) { if (/^[1-9]$/.test(e.key)) { e.preventDefault(); this.act('r' + (+e.key - 1)); } },
  act(a) { if (a === 'cancel') { closeForm(); return; } const m = a.match(/^r(\d+)$/); if (!m) return; const x = ed.figList()[+m[1]]; closeForm(); if (x) ed.insertRef(x.fg.id); } };
FORMS.slide = {
  html() { const f = ed.doc.format; return `<span class="ttl">資料の柱と欄</span><label>本文欄の幅 ${inp('bodyPct', f.bodyPct, '', 'number', 'min="20" max="100" step="5"')}%</label><label>仕切り ${cyc('divider', [['none', 'なし'], ['thin', '細'], ['dotted', '点線']], f.divider)}</label>
    <label>柱の題 ${cyc('headTitle', [['page', '頁ごと（表題の行）'], ['doc', '通し（題名）']], f.headTitle)}</label><label>題名 ${inp('title', ed.doc.title, 'w')}</label><label>機密表示 ${inp('secret', f.secret, 'm')}</label><label>作成日 ${inp('date', f.dateAuto ? FZ.todayJa() : f.date, 'm')}</label><button type="button" data-act="today" title="作成日の欄を今日の日付にする">今日</button><label>${cyc('dateAuto', [['0', '固定'], ['1', '自動（毎日今日に）']], f.dateAuto ? '1' : '0')}</label><label>作成者 ${inp('author', f.author, 'm')}</label>
    <label>頁番号 ${cyc('pageMark', [['box', '四角'], ['circle', '丸'], ['none', 'なし']], f.pageMark)}</label><label>柱の罫 ${cyc('headRule', [['thin', '細'], ['thick', '太']], f.headRule)}</label>
    <label>表紙 ${cyc('cover', [['0', 'なし'], ['1', 'あり']], f.cover ? '1' : '0')}</label><label>表紙の型 ${cyc('coverStyle', [['', '本文のまま'], ['std', '題・日付・作成者'], ['toc', '題・日付・作成者・目次']], f.coverStyle || '')}</label><label>表紙の機密表示 ${cyc('coverSecret', [['0', '出さない'], ['1', '出す（右上）']], f.coverSecret ? '1' : '0')}</label><label>表紙の頁番号 ${cyc('coverNum', [['0', '出さない'], ['1', '出す']], f.coverNum ? '1' : '0')}</label><label>開始番号 ${inp('pageStart', f.pageStart, '', 'number', 'min="0" max="9999" step="1"')}</label>
    <span class="hintl">頁ごと：表題の行が柱に入る（無いページは前の題）。表紙あり：最初のページは柱なし。表紙の型「本文のまま」は最初の表題を紙面の題に（大きくするなら倍角）、「題・日付・作成者」は中央に題（四倍角）と日付・作成者、「…・目次」は中ほどに目次の箱（各頁の表題と頁番号）。開始番号 0：表紙を数えず本文が 1 から</span><button type="button" class="pri" data-act="apply">適用 Enter</button><button type="button" data-act="cancel">取消 Esc</button>`; },
  focus: 'input[name="bodyPct"]', enter() { this.act('apply'); },
  act(a) { if (a === 'today') { const el = sub.querySelector('input[name="date"]'); if (el) { el.value = FZ.todayJa(); el.focus(); } return; } if (a !== 'apply') { closeForm(); return; } const f = JSON.parse(JSON.stringify(ed.doc.format)); Object.assign(f, { kind: 'slide', dateAuto: cycVal('dateAuto') === '1', bodyPct: +fval('bodyPct') || 60, divider: cycVal('divider'), headTitle: cycVal('headTitle'), secret: fval('secret').trim(), date: fval('date').trim(), author: fval('author').trim(), pageMark: cycVal('pageMark'), headRule: cycVal('headRule'), cover: cycVal('cover') === '1', coverNum: cycVal('coverNum') === '1', coverStyle: cycVal('coverStyle') || '', coverSecret: cycVal('coverSecret') === '1', pageStart: fval('pageStart').trim() === '' ? 1 : +fval('pageStart') }); if (f.headerRows < 1) f.headerRows = 2; const title = fval('title').trim();
    closeForm(); ed.mutate('', () => { ed.doc.format = FZ.normalize({ ...ed.doc, format: f }).format; ed.doc.title = title; ed.normalizeSegs(); }); msg('資料の柱と欄を変えました'); } };
/* ================= 印刷 ================= */
/* 印刷・PDF は常に「印刷イメージ」：白黒＋網点（画面の二値表示と同じ描画）、全ページを描いてから印刷する
   （画面は見えているページしか描いていないので、そのまま印刷すると見えていないページが白紙になる） */
/* ================= 付箋（Word のコメントと同じ）=================
   行の attrs.notes に id、中身は doc.notes（作成者・日時・済・引用・本文・返信）。紙面には、引用の字に点線の下線、同じ高さの右の余白に番号のつまみ。
   カーソルが付箋の付いた行に入ると、その行のすぐ下に札が重なって開く（組版は動かない）。札の中でそのまま直す・返信・解決 */
function noteAuthor() { try { const v = localStorage.getItem('fz.noteAuthor'); if (v) return v; } catch (e) { } return ed.doc.format.author || '自分'; }
function noteNow() { const d = new Date(), z = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`; }
function noteDate(t) { const m = String(t || '').match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/); return m ? `${+m[2]}/${+m[3]}${m[4] ? ' ' + m[4] + ':' + m[5] : ''}` : String(t || ''); }
function noteById(id) { return (ed.doc.notes || []).find(n => n.id === id) || null; }
function notesInOrder() { const out = []; ed.doc.lines.forEach((ln, i) => { for (const id of ln.attrs.notes || []) { const n = noteById(id); if (n) out.push({ n, i, k: out.length }); } }); return out; }
function noteRange(n, i) { if (!n.quote) return null; const segs = ed.doc.lines[i].segs; for (let s = 0; s < segs.length; s++) { const k = segs[s].text.indexOf(n.quote); if (k >= 0) return { seg: s, start: k, end: k + n.quote.length }; } return null; }
function noteAdd() { if (st.mode === 'tree') { const nd = treeNodeSel(); const i = nd && nd.obj ? ed.doc.lines.indexOf(nd.obj) : -1; if (i < 0) { msg('付箋を付ける節を選んでください', true); return; } exitTree(); ed.setCaret({ line: i, seg: 0, off: 0 }); }
  const sel = ed.sel(); let quote = ''; if (sel && sel.a.line === sel.b.line && sel.a.seg === sel.b.seg) quote = ed.doc.lines[sel.a.line].segs[sel.a.seg].text.slice(sel.a.off, sel.b.off).replace(/[\r\n]+/g, ' ').trim();
  const line = sel ? sel.a.line : ed.caret.line; let k = 1; const ids = new Set((ed.doc.notes || []).map(n => n.id)); while (ids.has('n' + k)) k++; const id = 'n' + k;
  ed.mutate('', () => { (ed.doc.notes = ed.doc.notes || []).push({ id, author: noteAuthor(), date: noteNow(), done: false, quote: quote.slice(0, 400), text: '', replies: [] }); const a = ed.doc.lines[line].attrs; a.notes = [...(a.notes || []), id]; });
  st.noteOpen = id; st.noteClosed = null; st.noteFocus = 'body'; render(); if (st.side === 'notes') drawSide(); }
function noteClearDone() { const gone = new Set((ed.doc.notes || []).filter(n => n.done).map(n => n.id)); if (!gone.size) { msg('解決した付箋はありません'); return; }
  ed.mutate('', () => { ed.doc.notes = ed.doc.notes.filter(n => !gone.has(n.id)); for (const l of ed.doc.lines.concat(...(ed.doc.parked || []).map(p => p.lines))) if (l.attrs.notes) { const k = l.attrs.notes.filter(id => !gone.has(id)); if (k.length) l.attrs.notes = k; else delete l.attrs.notes; } });
  if (gone.has(st.noteOpen)) st.noteOpen = null; render(); if (st.side === 'notes') drawSide(); msg('解決した付箋を ' + gone.size + ' 枚消しました（Ctrl+Z で戻る）'); }
function noteGo(id) { const L = ed.doc.lines; const i = L.findIndex(l => (l.attrs.notes || []).includes(id)); if (i < 0) return; const n = noteById(id); const r = n && noteRange(n, i); if (st.mode === 'tree') exitTree(); ed.setCaret(r ? { line: i, seg: r.seg, off: r.start } : { line: i, seg: 0, off: 0 }); st.noteOpen = id; st.noteClosed = null; scrollToCaret(); render(); if (st.side === 'notes') drawSide(); }
function noteStep(dir) { const list = notesInOrder(); if (!list.length) { msg('付箋はありません'); return; } const cur = ed.caret.line; const k0 = list.findIndex(x => x.n.id === st.noteOpen);
  let t; if (k0 >= 0) t = list[(k0 + dir + list.length) % list.length]; else t = dir > 0 ? (list.find(x => x.i > cur) || list[0]) : ([...list].reverse().find(x => x.i < cur) || list[list.length - 1]); noteGo(t.n.id); }
/* カーソルが付箋の付いた行に入ったら開く（閉じた札はその行にいる間は開かない） */
function noteFollowCaret() { const ns = st.mode === 'text' ? (ed.doc.lines[ed.caret.line] || { attrs: {} }).attrs.notes : null; const want = ns && ns.length ? (ns.includes(st.noteOpen) ? st.noteOpen : ns[0]) : null;
  if (want && want === st.noteClosed) { if (st.noteOpen) { st.noteOpen = null; drawNotes(); } return; } if (!want) st.noteClosed = null; if (want !== st.noteOpen) { st.noteOpen = want; drawNotes(); if (st.side === 'notes') drawSide(); } }
let notesLayer = null;
function drawNotes() { if (!notesLayer) { notesLayer = document.createElement('div'); notesLayer.id = 'notesLayer'; notesLayer.addEventListener('pointerdown', e => e.stopPropagation()); notesLayer.addEventListener('click', noteClick); notesLayer.addEventListener('input', noteInput); notesLayer.addEventListener('keydown', noteKey); notesLayer.addEventListener('focusout', () => { st.noteEditing = null; }); }
  if (notesLayer.parentNode !== pagesEl) pagesEl.append(notesLayer); const L = ed.lay; const list = notesInOrder();
  const keepFocus = document.activeElement && notesLayer.contains(document.activeElement) ? { cls: document.activeElement.className, s: document.activeElement.selectionStart, e: document.activeElement.selectionEnd } : null;
  if (!L || !list.length || st.notesHidden || pagesEl.style.display === 'none') { notesLayer.innerHTML = ''; return; } const geo = L.geo; const out = []; const lastY = {}; let card = '';
  for (const { n, i, k } of list) { const lm = L.lineMap[i]; if (!lm || !lm.rows.length) continue; const r0 = lm.rows[0]; const w = wraps[r0.page]; if (!w || !w.clientWidth) continue; const sc = w.clientWidth / geo.W, ox = w.offsetLeft, oy = w.offsetTop;
    const X = c => ox + (geo.left + c * geo.cw) * sc, Y = r => oy + (geo.top + (geo.bodyTop + r) * geo.ch) * sc; const open = st.noteOpen === n.id;
    const rg = noteRange(n, i); let ux = null;
    if (rg && (!n.done || open)) { const runs = new Map(); for (const sl of lm.segs[rg.seg] ? lm.segs[rg.seg].rows : []) for (const g of sl.glyphs) { if (g.off < rg.start || g.off >= rg.end || g.marker) continue; const key = sl.page + ':' + sl.y; const rr = runs.get(key) || { page: sl.page, y: sl.y, h: sl.h, x0: Infinity, x1: -Infinity }; rr.x0 = Math.min(rr.x0, g.col); rr.x1 = Math.max(rr.x1, g.col + g.w); runs.set(key, rr); }
      for (const rr of runs.values()) { const w2 = wraps[rr.page]; if (!w2) continue; const s2 = w2.clientWidth / geo.W; const x0 = w2.offsetLeft + (geo.left + rr.x0 * geo.cw) * s2, x1 = w2.offsetLeft + (geo.left + rr.x1 * geo.cw) * s2, yb = w2.offsetTop + (geo.top + (geo.bodyTop + rr.y + rr.h) * geo.ch) * s2; if (ux == null) ux = x0; out.push(`<div class="nund${open ? ' on' : ''}" style="left:${x0}px;top:${yb - 3}px;width:${x1 - x0}px"></div>`); } }
    let ty = Y(r0.y); if (lastY[r0.page] != null && ty < lastY[r0.page] + 20) ty = lastY[r0.page] + 20; lastY[r0.page] = ty; const tx = ox + (geo.left + geo.cols * geo.cw) * sc + Math.max(4, 3 * sc);
    out.push(`<div class="ntab${n.done ? ' done' : ''}${open ? ' on' : ''}" data-note="${n.id}" title="付箋 ${k + 1}：${esc((n.text || '').slice(0, 40))}" style="left:${tx}px;top:${ty}px">${k + 1}${n.done ? '<i>済</i>' : ''}</div>`);
    if (open) { const left = Math.max(ox + 4, Math.min(ux != null ? ux - 8 : X(0), ox + w.clientWidth - 380)); const top = Y(r0.y + (lm.rows.filter(r => r.page === r0.page).reduce((t, r) => t + r.h, 0))) + 6;
      card = `<div class="ncard${n.done ? ' done' : ''}" data-note="${n.id}" style="left:${left}px;top:${top}px"><div class="nh"><b>${k + 1}</b> ${esc(n.author || '')} <span class="d">${esc(noteDate(n.date))}</span>${n.done ? ' <span class="nd">済</span>' : ''}<span class="sp"></span><button type="button" data-na="done">${n.done ? '再開' : '解決'}</button><button type="button" data-na="del">削除</button><button type="button" data-na="close" title="閉じる（Esc）">×</button></div>`
        + `<textarea class="nbody" rows="${Math.min(6, Math.max(1, String(n.text || '').split('\n').length))}" placeholder="付箋の中身を書く">${esc(n.text || '')}</textarea>`
        + n.replies.map((r, ri) => `<div class="nrep"><span class="who">→ ${esc(r.author || '')} <span class="d">${esc(noteDate(r.date))}</span></span>${esc(r.text).replace(/\n/g, '<br>')}<button type="button" class="x" data-na="delrep" data-ri="${ri}" title="この返信を消す">×</button></div>`).join('')
        + `<textarea class="nreply" rows="1" placeholder="返信を書く（Ctrl+Enter で付ける）"></textarea></div>`; } }
  notesLayer.innerHTML = out.join('') + card;
  const ta2 = st.noteFocus ? notesLayer.querySelector(st.noteFocus === 'reply' ? '.nreply' : '.nbody') : keepFocus ? notesLayer.querySelector('.' + keepFocus.cls.split(' ')[0]) : null; if (ta2) { ta2.focus(); if (keepFocus && !st.noteFocus) try { ta2.setSelectionRange(keepFocus.s, keepFocus.e); } catch (e) { } } st.noteFocus = null; }
function noteClick(e) { const b = e.target.closest('[data-na]'), tab = e.target.closest('.ntab'); if (tab) { const id = tab.dataset.note; if (st.noteOpen === id) { st.noteOpen = null; st.noteClosed = id; drawNotes(); } else noteGo(id); return; }
  if (!b) return; const card = b.closest('.ncard'); const n = card && noteById(card.dataset.note); if (!n) return; const act = b.dataset.na;
  if (act === 'close') { st.noteClosed = n.id; st.noteOpen = null; drawNotes(); focusTA(); return; }
  if (act === 'done') { ed.mutate('', () => { n.done = !n.done; }); render(); if (st.side === 'notes') drawSide(); return; }
  if (act === 'delrep') { ed.mutate('', () => { n.replies.splice(+b.dataset.ri, 1); }); render(); return; }
  if (act === 'del') { ed.mutate('', () => { ed.doc.notes = ed.doc.notes.filter(x => x !== n); for (const ln of ed.doc.lines) if (ln.attrs.notes) { ln.attrs.notes = ln.attrs.notes.filter(x => x !== n.id); if (!ln.attrs.notes.length) delete ln.attrs.notes; } }); st.noteOpen = null; render(); if (st.side === 'notes') drawSide(); focusTA(); msg('付箋を消しました（Ctrl+Z で戻る）'); } }
/* 札の本文：打つたびに描き直さない（IME の変換を切らない）。直し始めに取消の印を 1 つ置き、中身だけ書き換えて未保存にする */
function noteInput(e) { if (!e.target.classList.contains('nbody')) return; const card = e.target.closest('.ncard'); const n = card && noteById(card.dataset.note); if (!n) return; if (st.noteEditing !== n.id) { ed.pushUndo('note:' + n.id); ed.breakUndo(); st.noteEditing = n.id; }
  n.text = e.target.value; e.target.rows = Math.min(6, Math.max(1, n.text.split('\n').length)); ed.dirty = true; status(); scheduleRecovery(); clearTimeout(st.noteSideT); st.noteSideT = setTimeout(() => { if (st.side === 'notes') drawSide(); const tb = notesLayer && notesLayer.querySelector(`.ntab[data-note="${n.id}"]`); if (tb) tb.title = '付箋：' + n.text.slice(0, 40); }, 400); }
function noteKey(e) { e.stopPropagation(); if (e.isComposing || e.keyCode === 229) return; const card = e.target.closest('.ncard'); const n = card && noteById(card.dataset.note); if (!n) return;
  if (e.key === 'Escape') { e.preventDefault(); st.noteClosed = n.id; st.noteOpen = null; drawNotes(); focusTA(); return; }
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); if (e.target.classList.contains('nreply')) { const v = e.target.value.trim(); if (!v) return; ed.mutate('', () => { n.replies.push({ author: noteAuthor(), date: noteNow(), text: v }); }); st.noteFocus = 'reply'; render(); if (st.side === 'notes') drawSide(); } else { focusTA(); } } }
/* 工程表の 1 行のモデル：期間の番号を単位にした位置（u）で、矢羽根 {type:'bar',u0,u1,label} と ◆ {type:'ms',u,label}。書き戻しは 1/4 刻みの記号に */
function ganttCellsOf(i, G) { return FZ.tableCells(ed.doc, i, ed.lay.geo.bodyCols).slice(G.labels | 0); }
function ganttItems(i, G) { const cells = ganttCellsOf(i, G), L = ed.doc.lines[i]; const items = []; let cur = null;
  cells.forEach((c, k) => { const sg = L.segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); const g = FZ.ganttCell(sg ? sg.text : '');
    if (g.kind === 'empty') { if (cur) { items.push(cur); cur = null; } return; }
    if (g.kind === 'ms') { if (cur) { items.push(cur); cur = null; } items.push({ type: 'ms', u: k + g.f, label: g.label }); return; }
    if (g.kind === 'cont') { if (!cur) cur = { type: 'bar', u0: k, u1: k + 1, label: '' }; cur.u1 = g.end != null ? k + g.end : k + 1; if (g.end != null) { items.push(cur); cur = null; } return; }
    if (cur) items.push(cur); cur = { type: 'bar', u0: k + (g.f || 0), u1: k + 1, label: g.label }; });
  if (cur) items.push(cur); return { cells, items }; }
function ganttWrite(i, G, items) { const cells = ganttCellsOf(i, G), n = cells.length, tx = cells.map(() => ''); const fr = f => { const q = Math.round(f * 4); return q === 2 ? '［1/2］' : '［' + q + '/4］'; };
  for (const it of items.filter(x => x.type === 'bar').sort((a, b) => a.u0 - b.u0)) { const u0 = clamp(it.u0, 0, n - 0.25), u1 = clamp(it.u1, u0 + 0.25, n); const sc = Math.floor(u0 + 1e-6), sf = u0 - sc; let ec = Math.ceil(u1 - 1e-6) - 1; if (ec < sc) ec = sc; const ef = u1 - ec;
    tx[sc] = ((sf > 0.01 ? fr(sf) : '') + (it.label || '')) || '→'; for (let k = sc + 1; k <= ec; k++) tx[k] = '→'; if (ec > sc && ef < 0.99) tx[ec] = '→' + fr(ef); }
  for (const m of items.filter(x => x.type === 'ms')) { const k = clamp(Math.floor(m.u + 1e-6), 0, n - 1), f = clamp(m.u - k, 0, 1); tx[k] = '◆' + (Math.abs(f - 0.5) > 0.01 ? fr(f) : '') + (m.label || ''); }
  const L = ed.doc.lines[i]; cells.forEach((c, k) => { let sg = L.segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); if (!sg) { if (!tx[k]) return; sg = FZ.newSeg(c.left, ''); L.segs.push(sg); L.segs.sort((a, b) => a.col - b.col); } if (sg.text !== tx[k]) { sg.text = tx[k]; sg.marks = FZ.marksFor(tx[k], 0); } }); }
/* 矢羽根の端（始め・終わり）・本体（全体を動かす）・◆ をドラッグ。1/4 刻みで吸い付き、動かすたびにセルの字を書き直す（取消は 1 回でまとまる） */
/* 当たり：矢羽根（端・本体）か ◆ か。無ければ null */
function ganttHitAt(g) { const pg = ed.lay.pages[g.page]; if (!pg || !pg.shapes || !pg.shapes.length) return null;
  const hit = pg.shapes.find(sh => sh.kind !== 'base' && g.row >= sh.y && g.row < sh.y + sh.h && (sh.kind === 'ms' ? Math.abs(g.col - sh.x) < 0.7 : g.col > sh.x0 - 0.45 && g.col < sh.x1 + 0.45)); if (!hit) return null;
  const T = ganttTable(hit.line); if (!T) return null; const i = hit.line, G = T.G; const M0 = ganttItems(i, G); const uOf = ganttUOf(M0.cells); const u = uOf(g.col);
  let idx = -1, which = null; if (hit.kind === 'ms') { idx = M0.items.findIndex(it => it.type === 'ms' && Math.abs(it.u - uOf(hit.x)) < 0.01); which = 'ms'; }
  else { let best = 1e9; M0.items.forEach((it, k) => { if (it.type !== 'bar') return; const d = u < it.u0 ? it.u0 - u : u > it.u1 ? u - it.u1 : 0; if (d < best && d < 0.4) { best = d; idx = k; } }); const it = M0.items[idx]; if (it) { const d0 = Math.abs(u - it.u0), d1 = Math.abs(u - it.u1); which = Math.min(d0, d1) < Math.min(0.3, (it.u1 - it.u0) / 3) ? (d0 <= d1 ? 'u0' : 'u1') : 'move'; } }
  return idx < 0 ? null : { hit, i, G, M0, uOf, u, idx, which }; }
function ganttUOf(cs) { return col => { for (let k = 0; k < cs.length; k++) if (col < cs[k].right || k === cs.length - 1) return k + clamp((col - cs[k].left) / (cs[k].right - cs[k].left), 0, 1); return 0; }; }
/* 期間のセルの空いた所：その行（工程表の本体の行）と位置。矢羽根を引いて作る */
function ganttEmptyAt(g) { const pos = FZ.xyToPos(ed.lay, g.page, Math.floor(g.row), g.col); if (!pos) return null; const T = ganttTable(pos.line); if (!T || pos.line - T.ts < (T.G.heads || 1)) return null; const M0 = ganttItems(pos.line, T.G); const cs = M0.cells; if (!cs.length || g.col < cs[0].left || g.col > cs[cs.length - 1].right) return null;
  const uOf = ganttUOf(cs), u = uOf(g.col); if (M0.items.some(it => it.type === 'bar' ? u >= it.u0 - 0.05 && u <= it.u1 + 0.05 : Math.abs(u - it.u) < 0.3)) return null; return { i: pos.line, G: T.G, M0, uOf, u, pos }; }
/* 矢羽根の端（始め・終わり）・本体（全体を動かす）・◆ をドラッグ。1/4 刻みで吸い付き、動かすたびにセルの字を書き直す（取消は 1 回でまとまる）。
   空いた所から横に引くと新しい矢羽根（放すと始まりのセルにカーソル：そのまま名前を打つ） */
function ganttPointerDown(e, g) { const H = ganttHitAt(g); const snap = u => Math.round(u * 4) / 4;
  if (!H) { const E = ganttEmptyAt(g); if (!E) return false; const { i, G, M0, uOf } = E; const n = M0.cells.length; const u0 = Math.floor(E.u * 4) / 4; /* 空いた範囲（両隣の項目の間） */ let lo = 0, hi = n; for (const it of M0.items) { const a = it.type === 'bar' ? it.u0 : it.u, b = it.type === 'bar' ? it.u1 : it.u; if (b <= E.u && b > lo) lo = b; if (a >= E.u && a < hi) hi = a; }
    let made = null; pagesEl.setPointerCapture(e.pointerId); pagesEl.style.cursor = 'crosshair';
    const move = ev => { const g2 = eventToGrid(ev); if (!g2 || g2.page !== g.page) return; const u2 = snap(uOf(g2.col)); let a = Math.min(u0, u2), b = Math.max(u0 + 0.25, u2); a = clamp(a, lo, hi - 0.25); b = clamp(b, a + 0.25, hi); if (Math.abs(uOf(g2.col) - E.u) < 0.2 && !made) return; const key = a + ':' + b; if (made === key) return; made = key; const items = JSON.parse(JSON.stringify(M0.items)); items.push({ type: 'bar', u0: a, u1: b, label: '' }); ed.mutate('gdrag', () => ganttWrite(i, G, items)); };
    const up = ev => { pagesEl.removeEventListener('pointermove', move); pagesEl.removeEventListener('pointerup', up); pagesEl.style.cursor = ''; try { pagesEl.releasePointerCapture(ev.pointerId); } catch (x) { } ed.breakUndo();
      if (made) { const a = +made.split(':')[0]; const cs = ganttCellsOf(i, G); const c = cs[Math.floor(a + 1e-6)]; const L = ed.doc.lines[i]; const si = L.segs.findIndex(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); if (si >= 0) ed.setCaret({ line: i, seg: si, off: L.segs[si].text.length }); msg('矢羽根を引きました：そのまま名前を打つ（端・本体はドラッグで動く）'); }
      else ed.setCaret(E.pos); };
    pagesEl.addEventListener('pointermove', move); pagesEl.addEventListener('pointerup', up); return true; }
  const { i, G, M0, uOf, u, idx, which } = H;
  const base = JSON.parse(JSON.stringify(M0.items)); let last = null; pagesEl.setPointerCapture(e.pointerId); pagesEl.style.cursor = which === 'move' || which === 'ms' ? 'grabbing' : 'ew-resize'; st.ganttHover = null;
  const move = ev => { const g2 = eventToGrid(ev); if (!g2 || g2.page !== g.page) return; const uu = snap(uOf(g2.col)), du = snap(uOf(g2.col) - u); const items = JSON.parse(JSON.stringify(base)); const it = items[idx];
    if (which === 'u0') it.u0 = Math.min(uu, it.u1 - 0.25); else if (which === 'u1') it.u1 = Math.max(uu, it.u0 + 0.25); else if (which === 'move') { const n = M0.cells.length; const d = clamp(du, -it.u0, n - it.u1); it.u0 += d; it.u1 += d; } else it.u = clamp(uu, 0, M0.cells.length - 0.01);
    const key = JSON.stringify(it); if (key === last) return; last = key; ed.mutate('gdrag', () => ganttWrite(i, G, items)); };
  const up = ev => { pagesEl.removeEventListener('pointermove', move); pagesEl.removeEventListener('pointerup', up); pagesEl.style.cursor = ''; try { pagesEl.releasePointerCapture(ev.pointerId); } catch (x) { } ed.breakUndo(); if (last == null) { const pos = FZ.xyToPos(ed.lay, g.page, Math.floor(g.row), g.col); if (pos) ed.setCaret(pos); } };
  pagesEl.addEventListener('pointermove', move); pagesEl.addEventListener('pointerup', up); return true; }
/* 掴める所を見せる：矢羽根の上では両端につまみ（近い端は濃く）、端では ⇔、本体では掴む手、空いた期間のセルでは十字（引いて作る） */
function ganttHoverMove(e) { if (st.mode !== 'text' || e.buttons || drag) return; const g = eventToGrid(e); let hv = null, cur = '';
  if (g && ed.lay && ed.lay.pages[g.page] && ed.lay.pages[g.page].shapes && ed.lay.pages[g.page].shapes.length) { const H = ganttHitAt(g); if (H) { const sh = H.hit; hv = sh.kind === 'ms' ? { kind: 'ms', page: g.page, x: sh.x, y: sh.y, h: sh.h } : { kind: 'bar', page: g.page, x0: sh.x0, x1: sh.x1, y: sh.y, h: sh.h, which: H.which }; cur = H.which === 'move' || H.which === 'ms' ? 'grab' : 'ew-resize'; } else if (ganttEmptyAt(g)) cur = 'crosshair'; }
  const k = hv ? JSON.stringify(hv) : ''; if (k !== (st.ganttHover ? JSON.stringify(st.ganttHover) : '')) { st.ganttHover = hv; requestOverlay(); } if (pagesEl.style.cursor !== cur && (cur || /grab|ew-resize|crosshair/.test(pagesEl.style.cursor))) pagesEl.style.cursor = cur; }
pagesEl.addEventListener('pointermove', ganttHoverMove); pagesEl.addEventListener('pointerleave', () => { if (st.ganttHover) { st.ganttHover = null; requestOverlay(); } });
/* 工程表：カーソルが期間のセルにあれば、そのセルの字を見せる（ほかは矢羽根だけ） */
function ganttTable(i) { const d = ed.doc; if (!FZ.inTable(d, i)) return null; let ts = i; while (ts > 0 && FZ.inTable(d, ts - 1)) ts--; let te = i; while (te + 1 < d.lines.length && FZ.inTable(d, te + 1)) te++; const G = d.lines[ts].attrs.gantt; return G ? { ts, te, G } : null; }
/* 期間のセルの守る字（位置の［3/4］・◆・→）。カーソルはその後ろ（名前）だけを動く */
function ganttPrefixLen(t) { t = String(t || ''); if (/^[\s　]*[→⇒]/.test(t)) return t.length; const m = t.match(/^[\s　]*[◆◇]?(?:[［\[][^］\]]*[］\]])?/); return m ? m[0].length : 0; }
function ganttCellRect(rv) { const L = ed.lay, lm = L && L.lineMap[rv.line]; if (!lm || !lm.rows.length) return null; const seg = ed.doc.lines[rv.line].segs[rv.seg]; if (!seg) return null; const c = FZ.tableCells(ed.doc, rv.line, L.geo.bodyCols).find(x => seg.col >= x.left - 1e-6 && seg.col < x.right - 1e-6); if (!c) return null; const r0 = lm.rows[0]; let h = 0; for (const r of lm.rows) if (r.page === r0.page) h += r.h; return { page: r0.page, col: c.left + 0.06, y: r0.y + 0.06, w: c.right - c.left - 0.12, h: h - 0.12 }; }
/* 「→」のセルに名前を打ったら、そこから新しい矢羽根（→ を外す）。変換中は触らない */
function ganttNormalizeCell() { if (!st.reveal || st.composing) return; const c = ed.caret, sg = ed.doc.lines[c.line] && ed.doc.lines[c.line].segs[c.seg]; if (!sg) return; const m = sg.text.match(/^([\s　]*[→⇒](?:[［\[][^］\]]*[］\]])?)(.*\S.*)$/); if (!m) return; const cut = m[1].length; ed.mutate('type', () => { ed.spliceSeg(sg, 0, cut, ''); c.off = Math.max(0, c.off - cut); }); syncTA(); }
/* 期間のセルのキー：Backspace は名前だけを消す（名前が空なら矢羽根・◆ の始まりごと消す）。← は前のセルへ */
function ganttGuardKey(k) { if (!st.reveal || ed.sel()) return false; const c = ed.caret, sg = ed.seg(), pl = ganttPrefixLen(sg.text);
  if (k === 'Backspace' && c.off <= pl) { if (pl && !/^[\s　]*[→⇒]/.test(sg.text) && !sg.text.slice(pl).trim()) ed.mutate('', () => { ed.spliceSeg(sg, 0, sg.text.length, ''); c.off = 0; }); else if (!pl && c.seg > 0) ed.backspace(); return true; }
  if (k === 'ArrowLeft' && c.off <= pl && c.seg > 0) { const p2 = ed.doc.lines[c.line].segs[c.seg - 1]; ed.setCaret({ line: c.line, seg: c.seg - 1, off: p2.text.length }); return true; }
  return false; }
function ganttReveal() { if (st.mode !== 'text' || !ed.lay) return null; const c = ed.caret, i = c.line; const T = ganttTable(i); if (!T || i - T.ts < (T.G.heads || 1)) return null; const seg = ed.doc.lines[i].segs[c.seg]; if (!seg) return null;
  const cells = FZ.tableCells(ed.doc, i, ed.lay.geo.bodyCols); const k = cells.findIndex(x => seg.col >= x.left - 1e-6 && seg.col < x.right - 1e-6); return k >= (T.G.labels | 0) ? { line: i, seg: c.seg } : null; }
/* ブラウザのメニューから刷られたとき（doPrint を通らない）も、紙面の全頁を組んで描いてから刷る（描いていない頁・図表が空欄になっていた） */
window.addEventListener('beforeprint', () => { if (st.printing || document.body.classList.contains('ptree')) return; try { finishLayout(); const s0 = $('printStyle') || Object.assign(document.createElement('style'), { id: 'printStyle' }); if (!s0.parentNode) document.head.append(s0); const g0 = ed.lay.geo; s0.textContent = `@page{size:${g0.W}pt ${g0.H}pt;margin:0}`; renderForPrint(); const back = () => { pageCache = pageCache.map(() => ''); render(); window.removeEventListener('afterprint', back); }; window.addEventListener('afterprint', back); } catch (e) { } });
async function doPrint() { st.printing = true; setTimeout(() => { st.printing = false; }, 3000);
  try { finishLayout(); await prepareImages(); } catch { } // 図版の画像の網点化を待つ
  let s = $('printStyle'); if (!s) { s = document.createElement('style'); s.id = 'printStyle'; document.head.append(s); }
  const g = ed.lay.geo; s.textContent = `@page{size:${g.W}pt ${g.H}pt;margin:0}`;
  printRootFill(); document.body.classList.add('printing'); /* 1.0.15c 刷りの専用の器に組む（画面の頁はそのまま） */
  const restore = () => { document.body.classList.remove('printing'); const pr = $('printRoot'); if (pr) pr.innerHTML = ''; window.removeEventListener('afterprint', restore); };
  window.addEventListener('afterprint', restore);
  setTimeout(() => { window.print(); setTimeout(restore, 0); }, 60);
}
/* 1.0.15a 手当ても刷る（A-7。レビュー用の刷り）：付箋の番号を右の余白に朱の札で、付けた字に朱の点線、中身は最後の頁に一覧 */
function careMarksSvg(p) { const L = ed.lay, geo = L.geo, cw = geo.cw, ch = geo.ch, X = c => geo.left + c * cw, Y = r => geo.top + (geo.bodyTop + r) * ch; const out = []; let lastY = -1e9; const n2 = v => Math.round(v * 100) / 100;
  for (const { n, i, k } of notesInOrder()) { if (n.done) continue; const lm = L.lineMap[i]; if (!lm || !lm.rows.length) continue; const rg = noteRange(n, i);
    if (rg) for (const sl of lm.segs[rg.seg] ? lm.segs[rg.seg].rows : []) { if (sl.page !== p) continue; let x0 = Infinity, x1 = -Infinity; for (const g of sl.glyphs) { if (g.off < rg.start || g.off >= rg.end || g.marker) continue; x0 = Math.min(x0, g.col); x1 = Math.max(x1, g.col + g.w); } if (x1 > x0) { const yb = Y(sl.y + sl.h) - 0.6; out.push(`<line x1="${n2(X(x0))}" y1="${n2(yb)}" x2="${n2(X(x1))}" y2="${n2(yb)}" stroke="${FZ.SHU}" stroke-width="0.8" stroke-dasharray="1.6 1.2"/>`); } }
    const r0 = lm.rows[0]; if (r0.page !== p) continue; let ty = Y(r0.y); if (ty < lastY + 11) ty = lastY + 11; lastY = ty; const tx = X(geo.cols) + 3, fs = 7.5;
    out.push(`<rect x="${n2(tx)}" y="${n2(ty)}" width="15" height="10" fill="${FZ.SHU}"/><text x="${n2(tx + 7.5)}" y="${n2(ty + 7.8)}" font-size="${fs}" fill="#fff" text-anchor="middle" font-family="sans-serif" font-weight="700">${k + 1}</text>`); }
  return out.length ? `<g class="printcare">${out.join('')}</g>` : ''; }
function careListHtml() { const list = notesInOrder().filter(x => !x.n.done); if (!list.length) return ''; const pg = i => { const lm = ed.lay.lineMap[i]; return lm && lm.rows[0] ? (lm.rows[0].page + 1) + ' 頁' : ''; };
  return `<section class="printnotes" aria-label="付箋の一覧"><h2>付箋（${list.length} 件）　${esc(ed.doc.title || (st.file && st.file.name) || '')}</h2>${list.map(({ n, i, k }) => `<div class="pn"><b>${k + 1}</b>${esc(n.text || '').replace(/\n/g, '<br>')}　<span class="w">${esc(n.author || '')}・${esc(pg(i))}${n.quote ? '・「' + esc(String(n.quote).slice(0, 30)) + '」' : ''}</span>${(n.replies || []).map(r => `<div class="w">→ ${esc(r.author || '')}：${esc(r.text || '')}</div>`).join('')}</div>`).join('')}</section>`; }
function printRootFill(care = printLayer === 'care') { finishLayout(); const lay = ed.lay, n = lay.pages.length; const pr = $('printRoot'); if (!pr) return renderForPrint(care); pr.style.setProperty('--pw', lay.geo.W + 'pt'); pr.style.setProperty('--ph', lay.geo.H + 'pt'); const out = [];
  for (let p = 0; p < n; p++) out.push(`<div class="pgp" data-page="${p}">${FZ.renderPage(lay, p, { grid: false, font: ed.doc.format.font, mono: true, imageHref })}</div>`);
  pr.innerHTML = out.join('') + (care ? careListHtml() : ''); pr.querySelectorAll('.pgp').forEach((w, p) => { const svg = w.querySelector('svg'); if (!svg) return; if (FZ.rasterizeFills) FZ.rasterizeFills(svg); if (care) { const g = careMarksSvg(p); if (g) svg.insertAdjacentHTML('beforeend', g); } }); return pr; }
function renderForPrint(care = printLayer === 'care') {
  finishLayout(); const lay = ed.lay, n = lay.pages.length; pagesEl.style.setProperty('--pw', lay.geo.W + 'pt'); pagesEl.style.setProperty('--ph', lay.geo.H + 'pt'); /* ツリーだけの表示から印刷しても頁の大きさが決まっているように */
  while (wraps.length > n) { wraps.pop().remove(); pageCache.pop(); }
  while (wraps.length < n) { const d = document.createElement('div'); d.className = 'pgwrap'; d.dataset.page = wraps.length; pagesEl.append(d); wraps.push(d); pageCache.push(''); }
  for (let p = 0; p < n; p++) { wraps[p].style.height = ''; wraps[p].innerHTML = FZ.renderPage(lay, p, { grid: false, font: ed.doc.format.font, mono: true, imageHref }); pageCache[p] = ''; const svg = wraps[p].querySelector('svg'); if (svg && FZ.rasterizeFills) FZ.rasterizeFills(svg); if (care && svg) { const g = careMarksSvg(p); if (g) svg.insertAdjacentHTML('beforeend', g); } } // 網は画像にして印刷（PDF 出力とプレビューが速い）
  let pn = $('printNotes'); if (pn) pn.remove(); if (care) { const h = careListHtml(); if (h) { pagesEl.insertAdjacentHTML('beforeend', h.replace('<section class="printnotes"', '<section id="printNotes" class="printnotes"')); } }
}
/* ================= 起動 ================= */
try { const gm = localStorage.getItem('fz.gridMode'); if (gm && gm !== 'off') st.gridMode = gm; } catch { } /* 方眼の種類は覚えておく（出すかどうかは毎回なし） */
/* 文書を替えたら（開く・新しく・復元）、前の文書に結び付いた欄と状態は閉じる：AI からの戻し・構成の試案・対象の先見せは前の文書の行を指している */
function docReplaced() { st.aiBack = null; st.trial = null; st.tprev = null; st.tprevCmd = null; if (st.formSession) st.formSession = null; if (st.form) closeForm(); }
ed.onChange = why => { if (why === 'doc') docReplaced(); requestRender(); syncTA(); scrollToCaret(); scheduleRecovery(); if (!st.form && st.mode !== 'tree') drawSub();
  if ((st.side === 'drawer' && st.drawerTab === 'ruler') || st.side === 'find') { clearTimeout(st.sideT); st.sideT = setTimeout(() => { if (st.side === 'find' || (st.side === 'drawer' && st.drawerTab === 'ruler')) drawSide(); }, 400); } }; /* 1.0.15d 量・検索の一覧は直すと追う */
/* 段階的な組版：巨大な文書は最初の画面だけ同期で組み、残りは空き時間に少しずつ。終わるまで状態行の頁数に「+」が付く */
let layoutTimer = 0;
function continueLayoutLater() { if (layoutTimer) return; const go = () => { layoutTimer = 0; if (ed.layoutDone) return; const done = ed.continueLayout(14); requestRender(); if (!done) continueLayoutLater(); }; layoutTimer = (typeof requestIdleCallback === 'function') ? requestIdleCallback(go, { timeout: 60 }) : setTimeout(go, 0); }
function finishLayout() { if (ed.layoutDone) return; while (!ed.continueLayout(200)) { } render(); }
ed.onLayoutPending = continueLayoutLater;
ed.onCaret = () => { noteFollowCaret(); { const rv = ganttReveal(); const k = rv ? rv.line + ':' + rv.seg : ''; if (k !== (st.reveal ? st.reveal.line + ':' + st.reveal.seg : '')) { st.reveal = rv; requestRender(); } if (rv && !ed.anchor) { const sg = ed.seg(), pl = ganttPrefixLen(sg.text); if (ed.caret.off < pl) ed.caret.off = pl; } } requestOverlay(); syncTA(); scrollToCaret(); pufuAutoBand(); if (!st.form && st.mode !== 'tree') drawSub(); treeFollowCaret(); };
function boot() {
  document.body.classList.add('mono');
  drawFkeys(); drawSub();
  claimSlot();
  let restored = null; try { restored = JSON.parse(localStorage.getItem(RECOVER_KEY()) || 'null'); if (!restored && st.slot === 1) { restored = JSON.parse(localStorage.getItem('fz.recover') || 'null'); if (restored) { localStorage.setItem(RECOVER_KEY(), JSON.stringify(restored)); localStorage.removeItem('fz.recover'); } } } catch { } // 1.0.9e までの復旧データは窓 1 が引き継ぐ
  if (restored && restored.text) { try { ed.setDoc(FZ.parse(restored.text)); ed.dirty = true; st.file = restored.name ? { name: restored.name } : null; setFileName(restored.name || ''); msg('前回の続きを復元（未保存）', false, 8000); } catch { } }
  if (new URLSearchParams(location.search).get('open') === 'manual' && !(restored && (restored.text || restored.full === 'idb'))) loadManualHere(new URLSearchParams(location.search).get('sec') || ''); // 取説の「文書で開く」から開いた窓（1.0.15d：&sec= でその節へ）
  const initial = typeof window.fzInitialFile === 'function'; if (restored && restored.full === 'idb' && !initial) restoreFromIdb(restored); // 大きい文書・画像は IndexedDB から（exe 版で起動引数のファイルがあるときは退避が先）
  if (!st.slot) msg(`窓が ${MAX_WINDOWS} つを超えました。この窓は復旧データを残しません`, true, 0);
  else { let orphan = 0; for (let n = 1; n <= MAX_WINDOWS; n++) { if (n === st.slot || slotAlive(n)) continue; try { if (localStorage.getItem('fz.recover.' + n)) orphan++; } catch { } } if (orphan && !restored) msg(`閉じた窓の未保存の文書が ${orphan} 件あります（${K('newWindow')} 新しい窓 で開くと復元します）`, false, 10000); }
  render(); focusTA(); syncTA();
  if (initial) openInitialFile(restored && (restored.text || restored.full === 'idb') ? restored : null); // exe 版：ダブルクリック・「送る」で渡されたファイル
  if (FZ.files.kind === 'basic') msg('このブラウザは直接保存に非対応（Edge／Chrome 推奨）', true, 0);
  document.fonts && document.fonts.ready.then(() => { geomDirty = true; render(); });
}
/* exe 版の起動引数のファイルを開く。この窓に前回の未保存の文書が復元されていたら、空いている窓の番号へ退避してから開く（ファイルの「新しい窓」で復元できる） */
async function openInitialFile(restored) {
  let r; try { r = await window.fzInitialFile(); } catch (e) { msg('開けませんでした：' + e, true); r = null; } if (!r || r.text == null) { if (restored && restored.full === 'idb') restoreFromIdb(restored); return; }
  if (restored) { let park = 0; for (let n = 1; n <= MAX_WINDOWS && !park; n++) { if (n === st.slot || slotAlive(n)) continue; try { if (!localStorage.getItem('fz.recover.' + n)) park = n; } catch { } }
    if (!park) { msg(`「${r.name}」を開く前に、復元した未保存の文書を保存してください（${K('open')} で開き直せます）`, true, 0); return; }
    try { localStorage.setItem('fz.recover.' + park, JSON.stringify(restored)); } catch { msg('未保存の文書を退避できませんでした。保存してから開いてください', true, 0); return; }
    if (restored.full === 'idb') { try { const v = await RDB.get(RECOVER_KEY()); if (v) await RDB.put('fz.recover.' + park, v); } catch { } } } // IndexedDB の全文も退避先へ写す（開いたあとの消去より前に）
  await loadText(r.text, r.name, { path: r.path, name: r.name }); if (restored) msg(`「${r.name}」を開きました。前回の未保存の文書は ${K('newWindow')} 新しい窓 で復元できます`, false, 10000);
}
boot();
/* ================= フレームワーク（1.0.12）=================
 * 選ぶ窓（種類・探す・説明）→ 紙面に枠（見出し＋表・区画・見出しの並び）→ 枠の中にカーソルがある間、画面の下に枠ごとの書き方 */
var FWP = { cat: '', q: '', sel: 0, list: [] };
function fwFiltered() { let L = FZ.fwSearch(FWP.q); if (FWP.cat) L = L.filter(e => e.cat === FWP.cat); return L; }
const FW_FORM = { m2: '2 軸 4 象限の表', panels: '区画', sheet: '項目と記入の表', ledger: '台帳の表', grid: '行と列の表', list: '見出しの並び', tree: '箇条書きの木' };
const FW_SRC = { P: 'プロジェクト', B: 'ビジネス', PB: '両方', U: '定番ストーリー' };
function drawFwPick() { const box = $('fwpick'); FWP.list = fwFiltered(); FWP.sel = clamp(FWP.sel, 0, Math.max(0, FWP.list.length - 1)); const cur = FWP.list[FWP.sel];
  const cats = [['', 'すべて（' + FZ.FW.length + '）'], ...FZ.FW_CATS.map(([k, n]) => [k, n + '（' + FZ.FW.filter(e => e.cat === k).length + '）'])];
  box.querySelector('.fwp-c').innerHTML = cats.map(([k, n]) => `<li data-cat="${k}" class="${FWP.cat === k ? 'on' : ''}">${esc(n)}</li>`).join('');
  box.querySelector('.fwp-l').innerHTML = FWP.list.map((e, i) => `<li data-i="${i}" class="${i === FWP.sel ? 'on' : ''}"><b>${esc(e.name)}</b><span class="w">${esc(e.when)}</span><span class="s" title="${e.src === 'U' ? 'ご提供の定番ストーリー（空・雨・傘）' : '出典：' + FW_SRC[e.src] + 'のフレームワーク集'}">${e.src === 'U' ? '定番' : e.src}</span></li>`).join('') || '<li><span class="w">当てはまる型がありません</span></li>';
  box.querySelector('.fwp-n').textContent = FWP.list.length + ' 件';
  box.querySelector('.fwp-v').innerHTML = cur ? `<div class="pv" title="紙面に入る姿（この文書の版面で）">${fwPreview(cur)}</div><b>${esc(cur.name)}</b><span class="k">${esc(FW_FORM[cur.form] || '')}・${esc((FZ.FW_CATS.find(c => c[0] === cur.cat) || [, ''])[1])}</span><div>${esc(cur.when)}</div><div class="ps">${cur.parts.map(p => `<span><b>${esc(p.n)}</b>${p.g ? '：' + esc(p.g) : ''}</span>`).join('')}</div>` : '';
  const li = box.querySelector('.fwp-l li.on'); if (li) li.scrollIntoView({ block: 'nearest' }); }
/* 1.0.12b 枠の見本：この文書の版面（字数・書体）で、型の枠だけを組んで描く（版面の上下は切り詰める） */
const FWPV = new Map();
function fwPreview(e) { const f = ed.doc.format; const key = e.id + '|' + JSON.stringify([f.cols, f.rows, f.kind, f.paper, f.font, f.bodyPct]); if (FWPV.has(key)) return FWPV.get(key);
  let svg = ''; try { const cols = tableW(); const lines = FZ.fwBuild(e, { lv: 1, cols, theme: '' }); const d = FZ.parse('#fzk 2\n文字数: ' + ed.lay.geo.cols + '\n---\n' + lines.join('\n') + '\n'); d.format = { ...f, header: '', footer: '', title: '' };
    const lay = FZ.layout(d); const geo = lay.geo; let yMax = 1; for (const lm of lay.lineMap) for (const r of (lm && lm.rows) || []) if (r.page === 0) yMax = Math.max(yMax, r.y + r.h); for (const pg of lay.pages.slice(0, 1)) for (const r of pg.hrules || []) yMax = Math.max(yMax, r.y);
    svg = FZ.renderPage(lay, 0, { grid: false, font: f.font, mono: true }); const x0 = geo.left - geo.cw * 0.6, y0 = geo.top + geo.bodyTop * geo.ch - geo.ch * 0.4, w = geo.cols * geo.cw + geo.cw * 1.2, h = yMax * geo.ch + geo.ch * 0.8;
    svg = svg.replace(/viewBox="[^"]*" width="[^"]*" height="[^"]*"/, `viewBox="${x0.toFixed(1)} ${y0.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)}" preserveAspectRatio="xMinYMin meet"`).replace(/id="([^"]+)"/g, 'id="$1_pv"').replace(/url\(#([^)]+)\)/g, 'url(#$1_pv)'); } catch (err) { svg = ''; }
  if (FWPV.size > 80) FWPV.clear(); FWPV.set(key, svg); return svg; }
function openFwPick() { if (st.form) closeForm(); if (st.mode !== 'text') exitMode(); const box = $('fwpick');
  if (!box.firstChild) { box.innerHTML = `<div class="fwp" role="dialog"><div class="fwp-h"><b>フレームワーク</b><input class="fwp-q" placeholder="名前・使いどころ・枠の名前で探す（例：顧客、優先、振り返り）"><span class="fwp-n"></span><button type="button" data-fw="close">閉じる Esc</button></div><div class="fwp-b"><ul class="fwp-c"></ul><ul class="fwp-l"></ul><div class="fwp-v"></div></div><div class="fwp-f"><label>題に添える語 <input class="fwp-t" placeholder="例：新商品A の市場"></label><span class="sp"></span><span class="hint">↑↓ 選ぶ　←→ 種類　Enter 入れる</span><button type="button" class="pri" data-fw="ins">入れる Enter</button></div></div>`;
    box.addEventListener('click', e => { const c = e.target.closest('[data-cat]'), l = e.target.closest('[data-i]'), b = e.target.closest('[data-fw]'); if (c) { FWP.cat = c.dataset.cat; FWP.sel = 0; drawFwPick(); box.querySelector('.fwp-q').focus(); } else if (l) { FWP.sel = +l.dataset.i; drawFwPick(); } else if (b) { if (b.dataset.fw === 'ins') insertFw(); else closeFwPick(); } else if (e.target === box) closeFwPick(); });
    box.addEventListener('dblclick', e => { const l = e.target.closest('[data-i]'); if (l) { FWP.sel = +l.dataset.i; insertFw(); } });
    box.querySelector('.fwp-q').addEventListener('input', e => { FWP.q = e.target.value; FWP.sel = 0; drawFwPick(); });
    box.addEventListener('keydown', e => { e.stopPropagation(); if (imeKey(e)) return; const k = e.key; if (k === 'Escape') { e.preventDefault(); closeFwPick(); return; } if (k === 'Enter') { e.preventDefault(); insertFw(); return; }
      if (k === 'ArrowDown' || k === 'ArrowUp') { e.preventDefault(); FWP.sel = clamp(FWP.sel + (k === 'ArrowDown' ? 1 : -1), 0, Math.max(0, FWP.list.length - 1)); drawFwPick(); return; }
      if ((k === 'ArrowLeft' || k === 'ArrowRight') && (e.target.classList.contains('fwp-q') ? !e.target.value : true)) { e.preventDefault(); const ks = ['', ...FZ.FW_CATS.map(c => c[0])]; const i = ks.indexOf(FWP.cat); FWP.cat = ks[(i + (k === 'ArrowRight' ? 1 : ks.length - 1)) % ks.length]; FWP.sel = 0; drawFwPick(); } }); }
  box.hidden = false; drawFwPick(); const q = box.querySelector('.fwp-q'); q.value = FWP.q; q.focus(); q.select(); drawFkeys(); }
function closeFwPick() { $('fwpick').hidden = true; drawFkeys(); focusTA(); }
/* 入れる：今の節の子の深さに、見出し（枠:ID）と中身。空の行ならその行に、ほかは次の行から */
function fwLevelAt(line) { const L = ed.doc.lines; const fb = fwBlockAt(line); if (fb) { const a = L[fb.h].attrs; return a.style === 'num' ? Math.min(6, (a.level | 0) + 1) : 1; } /* 枠の中・直後なら、その枠と同じ深さ（兄弟）に */ for (let i = line; i >= 0 && i > line - 2000; i--) { const a = L[i].attrs; if (a.style === 'num') return Math.min(6, (a.level | 0) + 2); if (a.style === 'title') return 1; } return 1; }
function insertFw(e) { e = e || FWP.list[FWP.sel]; if (!e) return; const theme = ($('fwpick').querySelector('.fwp-t') || { value: '' }).value.trim(); closeFwPick();
  const lv = fwLevelAt(ed.caret.line); const lines = FZ.fwBuild(e, { lv, cols: tableW(), theme }); /* 1.0.12b 版面の幅いっぱい（資料でも図表欄まで） */ const d = FZ.parse('#fzk 2\n文字数: ' + ed.lay.geo.cols + '\n---\n' + lines.join('\n') + '\n'); /* 仮の文書も同じ字数で読む（40 字に切られない） */
  const jl = st.jaLift; st.jaLift = false; try { insertDoc(d); } finally { st.jaLift = jl; }
  const head = ed.doc.lines.findIndex((ln, i) => ln.attrs.fw === e.id && i >= ed.caret.line - d.lines.length - 1); const at = head >= 0 ? Math.min(ed.doc.lines.length - 1, head + (e.form === 'panels' || e.form === 'list' ? 2 : 1)) : ed.caret.line;
  ed.setCaret({ line: at, seg: 0, off: 0 }); if (FZ.inTable(ed.doc, at)) { let done = false; for (let q = at; q < Math.min(ed.doc.lines.length, at + 30) && FZ.inTable(ed.doc, q) && !done; q++) { const k = ed.doc.lines[q].segs.findIndex(sg => sg.text === '・'); if (k >= 0) { ed.setCaret({ line: q, seg: k, off: 1 }); done = true; } } /* 最初の「・」の後ろ */ if (!done) { const ln = ed.doc.lines[at + 1] && FZ.inTable(ed.doc, at + 1) ? at + 1 : at; const segs = ed.doc.lines[ln].segs; ed.setCaret({ line: ln, seg: Math.min(1, segs.length - 1), off: 0 }); } }
  st.fwGuideOff = false; render(); focusTA(); msg(`「${e.name}」の枠を入れました。画面の下に、枠ごとの書き方が出ます（${K('undo')} で取り消し）`, false, 7000); }
/* 解説：カーソルの行から上へ「枠:ID」の見出しを探し、その節の中なら出す */
function fwBlockAt(line) { const pz = FZ.pufuAt ? FZ.pufuAt(ed.doc, line) : null; if (pz) return { e: FZ.PUFU_GUIDE, h: pz.B.head, pufu: pz }; /* 1.0.14a プ譜の中ではプ譜の書き方 */ const L = ed.doc.lines; let h = -1; for (let i = line; i >= 0 && i > line - 1500; i--) { if (L[i].attrs.fw) { h = i; break; } }
  if (h < 0) return null; const e = FZ.fwById(L[h].attrs.fw); if (!e) return null; const a = L[h].attrs, lv = a.style === 'num' ? a.level | 0 : -1;
  for (let i = h + 1; i <= line; i++) { const b = L[i].attrs; if (b.style === 'title' || (b.style === 'num' && (b.level | 0) <= lv) || b.fw) return null; } return { e, h }; }
/* 1.0.12d 解説の当たり：カーソルのある所が枠のどの項目か。表は「論理のセル」（行続き・結合を上へたどった頭）から、
   4 象限＝そのますの名前（太字の行）、項目と記入・行と列＝行の見出し、台帳＝列の見出し。名前で合わなければ位置（行・列の番号）で。
   区画・見出しは、カーソルより上のいちばん近い子の見出し（名前 → 何番目か）。木は何番目の項目か（同じ名前が並ぶため）。打った字は頭合わせに使わない */
function fwPartAt(b, line, seg) { if (b.pufu) return FZ.pufuGuidePart(FZ.pufuRoleOf(b.pufu.B, b.pufu.B.map.get(line) || null)); const d = ed.doc, L = d.lines, e = b.e, n = e.parts.length; const ok = k => k >= 0 && k < n ? k : -1;
  if (FZ.inTable(d, line)) { const ln = L[line]; const sg = ln.segs[seg] || ln.segs[0]; const col = sg ? sg.col || 0 : 0; let t = line; while (t > b.h + 1 && FZ.inTable(d, t - 1)) t--;
    const I = FZ.tbl.info(ed, line); const B = I ? I.B : [0]; const j = Math.max(0, B.filter(c => c <= col + 1e-6).length - 1); const x0 = B[j], x1 = B[j + 1] != null ? B[j + 1] : x0 + 1, L0 = B[0], L1 = B[1] != null ? B[1] : L0 + 1;
    const ruled = (i, a, z) => d.rules.some(r => r.axis === 'h' && r.line === i && r.from < z - 1e-6 && r.to > a + 1e-6);
    const head = (i, a, z) => { while (i > t && (L[i].attrs.crow || !ruled(i, a, z))) i--; return i; }; /* 上に罫が無い（行続き・結合）間は上へ */
    const txt = (i, c) => { const s2 = L[i] && L[i].segs.find(x => Math.abs((x.col || 0) - c) < 1e-6); return s2 ? s2.text : ''; };
    const cs = head(line, x0, x1), rs = head(line, L0, L1); const cands = []; if (line === t) cands.push({ t: sg ? sg.text : '' }); /* 見出しの行：そのセルの字が列の見出し */
    if (cs !== line) cands.push({ t: txt(cs, x0) }); /* 4 象限：ますの名前（行続きの頭の行） */
    if (j > 0) cands.push({ t: txt(rs, L0) }); /* 行の見出し */
    if (line !== t) cands.push({ t: txt(t, x0) }); /* 列の見出し */
    if (j > 0 && cs === line && !txt(rs, L0).trim() && line - 1 > t) cands.push({ t: txt(line - 1, x0) }); /* 1.0.12 の 4 象限（名前の行と書く行の間に罫） */
    cands.push({ t: sg ? sg.text : '', loose: false });
    let k = FZ.fwMatch(e, cands); if (k >= 0) return k;
    let r = 0; for (let i = t + 1; i <= rs; i++) if (!L[i].attrs.crow && ruled(i, L0, L1)) r++; /* 何番目の行か（見出しの行の下から 1） */
    if (e.form === 'm2') { if (r >= 1 && r <= 2 && j >= 1 && j <= 2) return ok((r - 1) * 2 + (j - 1)); return -1; }
    if (e.form === 'sheet' || e.form === 'grid') return r >= 1 ? ok(r - 1) : -1;
    if (e.form === 'ledger') return ok(j);
    return -1; }
  const a0 = L[b.h].attrs; const lv0 = a0.style === 'num' ? a0.level | 0 : -1;
  if (e.form === 'tree') { let c = -1; for (let i = b.h + 1; i <= line; i++) if (L[i].attrs.list && L[i].attrs.list.kind !== 'cont') c++; return ok(c); }
  let hd = -1, idx = -1; for (let i = b.h + 1; i <= line; i++) { const a = L[i].attrs; if ((a.style === 'num' && (a.level | 0) === lv0 + 1) || (a.style === 'sym' && lv0 < 0)) { hd = i; idx++; } }
  if (hd < 0) return -1; const k = FZ.fwMatch(e, [{ t: L[hd].segs.map(x => x.text).join('') }]); return k >= 0 ? k : ok(idx); }
var fwgKey = ''; /* var：起動中の status() から呼ばれても未初期化にならない */
function updateFwGuide() { const el = $('fwguide'); if (!el) return; const b0 = st.mode === 'text' ? fwBlockAt(ed.caret.line) : null; const b = b0 && !st.fwGuideOff ? b0 : null; document.body.classList.toggle('fwg', !!b); document.body.classList.toggle('fwgmin', !!b0 && !b);
  if (!b) { if (b0) { const key = 'min|' + b0.e.id; if (fwgKey !== key) { fwgKey = key; el.innerHTML = `<div class="fwg-min"><button type="button" data-fwg="open" title="隠した解説をまた出す">▲ ${esc(b0.e.name)}の書き方を出す</button></div>`; } return; } /* 1.0.12b 隠した後も、枠の中にいる間は小さな「出す」ボタンを残す */ if (fwgKey) { fwgKey = ''; el.innerHTML = ''; } return; }
  const k = fwPartAt(b, ed.caret.line, ed.caret.seg); const key = b.e.id + '|' + k; if (key === fwgKey) return; fwgKey = key;
  el.innerHTML = `<div class="fwg-h"><b>${esc(b.e.name)}</b><span class="w">${esc(b.e.when)}</span><span class="sp"></span><span class="hint">${b.pufu ? 'Enter で同じ役を足す・Tab で一段深く（役が替わる）・Shift+Tab で浅く' : '枠の名前の所に書く・表のセルは Tab で移る'}</span><button type="button" data-fwg="close" title="解説を隠す（隠した後は、枠の中にいる間「書き方を出す」のボタンが残る）">隠す ×</button></div><div class="fwg-p">${b.e.parts.map((p, i) => `<div class="${i === k ? 'on' : ''}"><b>${esc(p.n)}</b><span>${esc(p.g || '')}</span></div>`).join('')}</div>`;
  const on = el.querySelector('.fwg-p div.on'); if (on) on.scrollIntoView({ block: 'nearest' }); }
document.getElementById('fwguide').addEventListener('click', e => { if (e.target.closest('[data-fwg="close"]')) { st.fwGuideOff = true; updateFwGuide(); focusTA(); } else if (e.target.closest('[data-fwg="open"]')) { st.fwGuideOff = false; updateFwGuide(); focusTA(); } });
/* P09：欄の型（formGuide を見よ） */
FORMS.fig.preview = true; FORMS.panels.preview = true; /* A-4 物差しは仮表示型（ruler.preview） */ FORMS.chart.live = true; FORMS.gantt.live = true; FORMS.marker.live = true; /* 保留の島は 1 つずつ戻す・消すので、取消も 1 つずつ（まとめない） */
FZ.app = { _menu: () => ({ FK, GROUPS, GROUP_OF, SUBGROUP_OF, MSEL }), _fig: { figInfo: l => figInfo(l), enter: (l, sel) => enterFigMode(l, sel), exit: () => exitFigMode() }, _care: { toggle: on => careToggle(on), print: care => renderForPrint(care), histPickText: (t, n) => histPickText(t, n), setPrint: v => { printLayer = v; } }, ed, st, saveFile, importPptx: f => importPptxFile(f), importDocx: f => importDocxFile(f), saveRecovery, autoSave: () => queueSave(() => saveNow(false, false, true)), histKeyOf: f => histKeyOf(f), histList: f => histList(f), histView: i => histView(i), histRestore: (i, ok) => histRestore(i, ok), RECOVER_KEY: () => RECOVER_KEY(), run, render, treeModel, flush, openForm, toggleGroup, toggleSide, renderForPrint, loadText, drawSub, drawFkeys, prepareImages, officeDoc, openFwPick, insertFw, fwBlockAt, cmds: () => CMDS.map(c => ({ id: c.id, label: c.label, group: c.group, keys: c.keys, path: (menuPaths().get(c.id) || []).join(" / "), kw: c.kw })), keysOf: id => { const c = cmdById(id); return c ? keysOf(c) : ''; }, GROUPS, _d: { findMatches: () => findMatches(), findGo: d => findGo(d), libList: () => libList(), libTouch: (r, n) => libTouch(r, n), insertSym: c => insertSym(c), insertSnippet: t => insertSnippet(t), nextCmds: () => nextCmds(), hereTopic: () => hereTopic(), manualJump: s => manualJump(s), drawSide: () => drawSide(), openDrawer: t => openDrawer(t) }, _f: { toolRun: t => toolRun(t), toolsGet: () => toolsGet(), recStart: () => recStart(), recStop: () => recStop(), practiceDoc: () => practiceDoc() }, _e: { compareText: (t, n) => compareText(t, n), srcApply: () => srcApply(), drawPageMap: () => drawPageMap() }, _g: { healthGet: () => { healthCache = null; return healthGet(); }, reviewOpen: () => reviewOpen(), reviewSet: v => { reviewOn = !!v; saveReview(); healthCache = null; }, stdSet: v => { stdUser = v; saveReview(); healthCache = null; }, aiPreview: h => aiPreview(h), docKind: d => docKind(d) }, _h: { shelfAdd: l => shelfAdd(l), shelfLoad: () => shelfLoad(), shelfReset: async () => { rqShelf = []; rqParsed.clear(); await shelfSave(); }, rqBuildNow: () => rqBuildNow(), rqOpt, rqMasks: v => { if (v) { rqMasks = v; rqMaskSave(); } return rqMasks; }, rqTake: P => rqTake(P), rqMatch: () => rqMatch(), rqRecordMissed: () => rqRecordMissed(), rqLog: () => rqLog(), rqSend: () => rqSend(), rqModels: () => rqModels(), rqLocal, rqReceive: (t, s) => rqReceive(t, s), rqBusy: () => !!rqRun, rqLogReset: async () => { await RDB.put('rq:log', []); await RDB.put('rq:pred', []); } } };
})(window.FZ);
