/* 文机 — AI に頼む（1.0.16b）：部品棚と依頼の組み立て、答えの区切りの読み取り
 * 部品棚：利用者が足した Markdown（核・基準・書き手・型・知識）。頭の「---」の「種類:」か、ファイル名・中身から種類を推す。本文は見出し（#〜###）で節に切る。
 * 依頼は 8 つを決まった順に：核 → 型 → 基準（読み手の種類つき）→ 書き手（メール・依頼のときだけ）→ 場面の知識 → 機械の下読みで見つけた所 → 文書 → 答えの形。
 * 大きさの上限（既定 4 万字）を超えたら、知識 → 書き手 → 基準の実例 の順に削る。核・型・文書・答えの形は削らない。
 * 部品の中の人名は「伏せる名前」で置き換えて送る（基準とノウハウだけを引き継ぐ。文書そのものは置き換えない）。
 * FZ.askBuild(o) → { text, items:[{ key, label, chars, cut }], total, budget, over }。o.compact（手元の AI）：核は内蔵の短いもの、基準の要の節も上限で削れる、機械の下読みは 15 件まで
 * FZ.askStrip(text)：考えの跡（<think>…</think>）を外す
 * FZ.askParse(text) → { verdict, one, findings:[{ sev, quote, problem, ask, fix, need }], draft, draft2, needs, gates, minutes, gist, ok } */
(function (FZ) {
  'use strict';
  const TYPES = [
    { id: 'review', name: '下読み', steps: 'あなたは提出前の下読みをする。読み手がこの文書を読んで最初に言う突っ込みを予測し、提出を左右するものから重さ順に指摘する。各指摘には原文からそのまま 8〜40 字を引用する（引用できない指摘は書かない）。最小修正稿は、原文の構成と良い所を残し、指摘を直すのに要る所だけを変える。構成から直す価値があるときだけ推奨修正稿を付ける。事実が足りない所は稿に「[要確認：何が要るか]」と書き、作り足さない。' },
    { id: 'proof', name: '校正', steps: 'あなたは校正をする。誤字・脱字・表記の揺れ・文法・係り受け・敬語・句読点だけを直す。内容・主張・構成・数字・固有名は変えない。判定は書かず、直した所ごとの指摘（重さは「整」）と最小修正稿だけを返す。' },
    { id: 'minutes', name: '議事録に起こす', steps: 'あなたは文字起こし・メモを議事録にする。順は、結論（決まったこと）→ 議事内容（論点ごとに事実と各意見）→ Todo（担当・期限）→ 次回決めること → 留意点。権限のある人が決めたものだけを「決定」と書き、意見・提案と分ける。発言に無いことは書かない。担当・期限が分からなければ「[要確認：…]」にする。' },
    { id: 'gist', name: '要点に絞る', steps: 'あなたは原文の要点を、読み手が判断に使う順に絞る。結論を一文 → 根拠は 3 点以内（数字は比較起点・時点つき）→ 残る論点・リスク → 次の一手（誰が・いつ）。原文に無いことは足さない。' },
  ];
  const READERS = [
    ['上位者', '判断・承認する人。結論 → 比較起点つきの根拠 → リスク → 次の判断の順で読む。活動より成果、背景より判断'],
    ['役員', '経営判断をする人。1 枚 1 主張、数字と判断事項だけ。専門語と社内の経緯を減らす'],
    ['他部門', '前提を共有していない人。用語と背景を最小限補い、相手にしてほしいことを 1 つに絞る'],
    ['部下', '実行する人。何を・いつまでに・どの基準で、を具体的に。理由も短く添える'],
    ['社外', '取引先など。敬語と表記を整え、社内用語・内部事情を出さない'],
  ];
  const SCENES = [
    { id: 'auto', name: '自動' },
    { id: 'sales', name: '販売・受注', kw: ['販売', '受注', '売上', '需要', '出荷', '顧客'] },
    { id: 'inv', name: '在庫・資産', kw: ['在庫', '資産', 'キャッシュ', '保有', '棚卸', '回転'] },
    { id: 'prod', name: '生産・調達・供給', kw: ['生産', '調達', '供給', '部品', '工場', '発注'] },
    { id: 'adverse', name: '不振・未達・逆風', kw: ['未達', '不振', '逆風', '挽回', '下方修正', '減益'] },
    { id: 'eval', name: '評価・昇格', kw: ['評価', '昇格', '基幹職', '成果', '目標'] },
    { id: 'req', name: '要件・改革', kw: ['要件', 'システム', '改革', '業務', 'データ', '定義'] },
    { id: 'mail', name: 'メール・依頼', kw: ['メール', '依頼', '件名', 'お願い', 'ご確認'] },
    { id: 'none', name: 'なし' },
  ];
  const DEPTHS = [['light', '軽く', 3, '止・直だけ'], ['std', '標準', 7, '止・直を中心に'], ['hard', '厳しく', 12, '整まで']];
  const BUDGETS = [[40000, '4 万字'], [16000, '1.6 万字'], [100000, '10 万字']];
  const KINDS = ['核', '基準', '書き手', '型', '知識'];
  const CORE = `# 核：判断に耐える提出物にする決まり
あなたは、読み手が判断・承認・実行できる提出物へ直す編集責任者である。言い換え装置ではない。

## 規則の優先順位
1. 事実・出典・意味・確度・責任・権限・数字・否定・重要なリスクを守る。
2. 読み手の判断・行動に合わせる。
3. 結論・比較・因果・成果・誤読の欠陥を潰す。
4. 文書の種類に合う構成にする。
5. 最後に日本語・敬語・表記を整える。
短さのために重要な条件を消さない。強く見せるために仮説を事実にしない。上位の欠陥を日本語の手直しで隠さない。原文の良い所を無意味に書き換えない。

## 絶対にしないこと
- 原文に無い事実・数量・原因・経緯・合意・成果を作らない。足りなければ「[要確認：何が要るか]」と書く。
- 数字・否定・敬称・日付・固有名を変えない。変えるべきなら指摘に書き、稿では「[要確認]」にする。
- 活動を成果、送付を受入、説明を理解、沈黙を合意、計画を達成として書かない。
- 後で分かった原因を、当初から予見していたように書かない。

## 文末の確度
実現した・削減した＝実績。決定した・合意した＝正式な決定。実行中＝着手済み。予定・見込み＝将来。主因とみている＝仮説。未確認＝分からない。

## 重さ
- 止：このままでは出せない（結論が無い、比較起点・単位・対象の違いで意味が変わる、因果・時系列の矛盾、事実と仮説の混同、責任・期限の欠落、重要なリスクを隠す、原資料の意味を変えている）
- 直：直してから出す（活動ばかりで成果が見えない、参照先・範囲が不明、反対の意味に読める、判断まで遠い）
- 整：整える（主述・係り受け・指示語・重複・表記）
- 好：良い所（残す理由）

## 読み手の問い
結論は？／何と比べて？／いつの数字？／誰が？／それで何が変わった？／本当にその原因？／前回との差は？／誰が決め、誰がいつ実行する？　答えが採否を変えるものだけを指摘する。揚げ足は取らない。`;
  const FORM = {
    review: g => `＝＝判定＝＝
判定：止（このままでは出せない）｜直してから出す｜出してよい　のどれか
一言：（1〜3 文）
＝＝指摘＝＝
- 重さ：止｜直｜整｜好
  引用：「原文からそのまま 8〜40 字」
  問題：
  突っ込み：「…？」
  直し方：
  要確認：（事実が足りないときだけ）
＝＝最小修正稿＝＝
（直した文書。Markdown）
＝＝推奨修正稿＝＝
（構成から直す価値があるときだけ。無ければこの区切りごと書かない）
＝＝要確認＝＝
- 必要な情報｜なぜ必要か｜入るとどこが変わるか
${g ? '＝＝ゲート＝＝\n- ゲートの番号 PASS｜FAIL：理由\n' : ''}`,
    proof: () => `＝＝指摘＝＝
- 重さ：整
  引用：「原文からそのまま 8〜40 字」
  問題：
  直し方：
＝＝最小修正稿＝＝
（直した文書。Markdown）
`,
    minutes: () => `＝＝議事録＝＝
（議事録。Markdown。# 題、## 結論・議事内容・Todo・次回決めること・留意点）
＝＝要確認＝＝
- 必要な情報｜なぜ必要か
`,
    gist: () => `＝＝要点＝＝
（要点。Markdown。# 題、結論の一文、## 根拠・残る論点・次の一手）
＝＝要確認＝＝
- 必要な情報｜なぜ必要か
`,
  };
  FZ.ASK = { TYPES, READERS, SCENES, DEPTHS, BUDGETS, KINDS, CORE };
  const nfk = s => String(s || '').normalize('NFKC');
  const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  /* 部品の種類を推す：頭の「種類:」→ ファイル名 → 中身 */
  FZ.partKindGuess = function (name, text) { const fm = String(text || '').match(/^﻿?---\s*\n([\s\S]*?)\n---/); if (fm) { const m = fm[1].match(/^\s*種類\s*[:：]\s*(\S+)/m); if (m && KINDS.includes(m[1])) return m[1]; }
    const n = nfk(name), head = nfk(String(text || '').slice(0, 3000));
    if (/審査|基準|指導|レビュー|部長|役員/.test(n)) return '基準'; if (/校正|推敲|議事録|会議|要する|要約|要点|プロンプト|型/.test(n)) return '型'; if (/文体|書き手|スタイル|style/i.test(n)) return '書き手';
    if (/データバンク|バンドル|bundle|知識|事例|用例/i.test(n)) return '知識'; if (/コンパイラ|核|原則|compiler/i.test(n)) return '核';
    if (/あなたは.{0,30}(?:編集|審査|校正)/.test(head)) return '型'; return '知識'; };
  /* 部品を節に切る（#〜### の見出し。コードの囲みの中は切らない）。頭の --- は定義 */
  FZ.parsePart = function (name, text, kind) { let s = String(text || '').replace(/^﻿/, '').replace(/\r\n?/g, '\n'); const fm = {}; const m = s.match(/^---\s*\n([\s\S]*?)\n---\s*(?:\n|$)/);
    if (m) { for (const raw of m[1].split('\n')) { const p = raw.match(/^\s*([^:：#][^:：]*?)\s*[:：]\s*(.*)$/); if (p) fm[p[1].trim()] = p[2].trim(); } s = s.slice(m[0].length); }
    const sections = []; let cur = { h: '', lv: 0, lines: [] }; let fence = false;
    for (const ln of s.split('\n')) { if (/^\s*(```|~~~)/.test(ln)) fence = !fence; const h = !fence && ln.match(/^(#{1,3})\s+(.+?)\s*#*\s*$/); if (h) { if (cur.h || cur.lines.some(x => x.trim())) sections.push(cur); cur = { h: h[2], lv: h[1].length, lines: [] }; } else cur.lines.push(ln); }
    if (cur.h || cur.lines.some(x => x.trim())) sections.push(cur);
    const secs = sections.map(x => { const body = x.lines.join('\n').replace(/^\n+|\s+$/g, ''); return { h: x.h, lv: x.lv, body, n: body.length + x.h.length + 4 }; });
    return { name, kind: kind || FZ.partKindGuess(name, text), fm, title: fm.名前 || (secs.find(x => x.lv === 1) || {}).h || name.replace(/\.[^.]+$/, ''), sections: secs, chars: s.length }; };
  const secText = x => (x.h ? '#'.repeat(Math.max(2, x.lv + 1)) + ' ' + x.h + '\n' : '') + x.body; /* 部品の見出しは 1 段下げて入れる（依頼の大見出しと並ばない） */
  const partText = (p, pick) => (pick || p.sections).map(secText).join('\n\n');
  /* 場面を本文から推す（場面表の語の数） */
  FZ.askSceneGuess = function (text) { const t = nfk(text); let best = null; for (const s of SCENES) { if (!s.kw) continue; const n = s.kw.reduce((a, w) => a + (t.split(w).length - 1), 0); if (n >= 2 && (!best || n > best.n)) best = { id: s.id, n }; } return best ? best.id : 'none'; };
  /* 人名を伏せる：[{ from, to }]。長い名前から */
  /* 姓だけを書けば（person）、姓・名・敬称・役職をまとめて置き換える（「渡辺信一さん」「渡辺部長」「渡辺 信一」→ 上位者） */
  const HONS = '本部長|部長|課長|室長|係長|主任|社長|所長|局長|次長|先生|さん|さま|様|氏|君|殿';
  FZ.askMask = function (text, masks) { let s = String(text || ''); for (const m of (masks || []).filter(x => x && x.from).sort((a, b) => b.from.length - a.from.length)) { const f = escRe(m.from); const re = m.person ? new RegExp(`${f}(?:[\\s　]?[一-鿿々]{1,2}(?=(?:${HONS})|[^一-鿿々]|$))?(?:${HONS})?`, 'g') : new RegExp(f, 'g'); s = s.replace(re, m.to || '〇〇'); } return s; };
  /* 伏せる名前の候補：部品の中で 3 回以上出る「姓＋敬称・役職」 */
  FZ.askNameCands = function (texts) { const cnt = new Map(); const re = /(?<![一-鿿々ァ-ヶー])([一-鿿々]{2,3}?)(本部長|部長|課長|室長|社長|さん|様|氏)(?![一-鿿])/g; const NOT = /^(?:営業|総務|人事|経理|財務|企画|開発|技術|製造|購買|調達|物流|品質|管理|事業|担当|代表|各位|皆|お客)$/;
    for (const t of texts) { re.lastIndex = 0; let m; while ((m = re.exec(t))) { if (NOT.test(m[1]) || /[部課室局所]$/.test(m[1])) continue; const k = m[1] + m[2]; cnt.set(k, (cnt.get(k) || 0) + 1); } }
    const sur = new Map(); for (const [k, n] of cnt) { const m = k.match(new RegExp(`^(.+?)(?:${HONS})$`)); const s = m ? m[1] : k; sur.set(s, (sur.get(s) || 0) + n); }
    return [...sur].filter(([, n]) => n >= 3).sort((a, b) => b[1] - a[1]).map(([k, n]) => ({ name: k, n })); }; /* 姓ごと（敬称・役職を合わせた回数） */

  /* 依頼を組み立てる */
  /* 核の部品：「第 I 部」（毎回使う実行の決まり）があればそこだけ。無ければ頭から 8 千字まで。残りの節は場面の知識の候補 */
  function coreSlice(p) { const S = p.sections; const k = S.findIndex(x => x.lv === 1 && /第\s*[I1一Ⅰ]\s*部|実行プロンプト|毎回/.test(x.h)); if (k >= 0) { let e = S.findIndex((x, j) => j > k && x.lv === 1); if (e < 0) e = S.length; return { core: S.slice(k, e), rest: [...S.slice(0, k), ...S.slice(e)] }; }
    const core = []; let n = 0; for (const x of S) { if (n > 8000 && core.length) break; core.push(x); n += x.n; } return { core, rest: S.slice(core.length) }; }
  const KEY_STD = /問|重視|ゲート|規則|禁止|基準|判定|チェック|W\d|G\d|ルール|審査|語尾|NG/;
  const EX_STD = /実例|例文|事例|記録|出典|修正前|改善例/;
  const cap = (t, n) => t.length > n ? t.slice(0, n) + '\n…（以下略）' : t;
  FZ.askBuild = function (o) { const T = TYPES.find(t => t.id === o.type) || TYPES[0]; const budget = o.budget || 40000; const shelf = (o.shelf || []).filter(p => p.use !== false); const masks = o.masks || [];
    const of = k => shelf.filter(p => p.kind === k); const items = []; const put = (key, label, text, prio) => items.push({ key, label, text: String(text || '').trim(), prio, cut: false });
    const named = p => `（プロジェクトに置いた資料「${p.name}」を使う）`; const only = !!o.namesOnly; const M = t => FZ.askMask(t, masks);
    /* 1 核（棚の核は第 I 部だけ。残りは知識の候補） */ const cores = of('核'); const coreRest = [];
    if (cores.length && !o.compact) { const parts = cores.map(p => { const c = coreSlice(p); coreRest.push(...c.rest.map(x => ({ p, x }))); return only ? named(p) : M(c.core.map(secText).join('\n\n')); }); put('core', '核：' + cores.map(p => p.title).join('・'), parts.join('\n\n'), 0); } else { put('core', '核（内蔵）', CORE, 0); if (o.compact) for (const p of cores) coreRest.push(...coreSlice(p).rest.map(x => ({ p, x }))); } /* 手元の AI（compact）は文脈が短いので、核は内蔵の短いものに */
    /* 2 型：内蔵の手順（削らない）＋棚の型（その仕事に合う 1 つ。上限で削る） */ { const D = DEPTHS.find(d => d[0] === o.depth) || DEPTHS[1]; let tx = '# 頼む仕事：' + T.name + '\n' + T.steps; if (o.type === 'review') tx += `\n深さ：${D[1]}。指摘は最大 ${D[2]} 件（${D[3]}）。`; put('type', '型：' + T.name, tx, 0);
      const RE = { review: /下読み|審査|レビュー/, proof: /校正|推敲/, minutes: /議事録|会議|文字起こし/, gist: /要する|要約|要点/ }[T.id]; let best = null; for (const p of of('型')) { const whole = RE.test(p.name) || RE.test(p.title); const pick = p.sections.filter(x => RE.test(x.h)); const sc = whole ? 2 : pick.length ? 1 : 0; if (sc && (!best || sc > best.sc)) best = { p, sc, pick: whole ? null : pick }; }
      if (best) put('typeUser', '棚の型：' + best.p.title, '## 棚の型（この手順で進める。答えの形だけは最後の「答えの形」に従い、棚の型の出力の形は使わない）\n' + (only ? named(best.p) : M(partText(best.p, best.pick))), 4); }
    /* 3 基準（読み手の種類つき）：要の節は削らない。実例 → ほかの節の順に削る */ if (o.type !== 'proof') { const R = READERS.find(r => r[0] === o.reader) || READERS[0]; const S = o.type === 'review' ? of('基準') : []; const std = o.std; /* 基準の部品の中身は下読みのときだけ。議事録・要点は読み手と基準の数だけ */
      const rule = std ? `基準「${std.name}」：一文 ${std.maxSent} 字まで${std.bullets ? '・箇条書きを既定' : ''}。空語（それだけで終わらせない語）：${(std.empty || []).join('・')}。反対の意味に読める語：${(std.misread || []).map(w => w.replace(/\*/g, '〜')).join('・')}。` : '';
      put('std', '基準と読み手（' + R[0] + '）', [`# 基準と読み手\n読み手：${R[0]}（${R[1]}）。この文書は、この読み手が判断・行動に使う。\n文書の種類：${o.kind || '（指定なし）'}。`, rule].filter(Boolean).join('\n'), 0);
      const secs = []; for (const p of S) { if (only) { put('stdPart', '基準：' + p.title, named(p), 0); continue; } for (const x of p.sections) secs.push({ p, x }); } if (std && std.body && !only && o.type === 'review') for (const x of FZ.parsePart('基準', std.body, '基準').sections) secs.push({ p: { title: std.name }, x });
      for (const { p, x } of secs) { if (!x.body.trim()) continue; const pr = EX_STD.test(x.h) ? 3 : KEY_STD.test(x.h) && !o.compact ? 0 : 4; put(pr === 3 ? 'stdEx' : 'stdPart', pr === 3 ? '基準の実例' : '基準：' + p.title, M(cap(secText(x), 12000)), pr); } }
    /* 4 書き手（メール・依頼のときだけ） */ if ((o.kind === 'メール' || o.scene === 'mail') && of('書き手').length) put('writer', '書き手：' + of('書き手').map(p => p.title).join('・'), '# 書き手の文体\n' + of('書き手').map(p => only ? named(p) : M(cap(partText(p), 15000))).join('\n\n'), 2);
    /* 5 場面の知識：場面の語が見出しに多い節から（知識の部品と、核の第 I 部の外）。校正には入れない */ { const sc = SCENES.find(s => s.id === o.scene); if (sc && sc.kw && o.type !== 'proof') { const cand = []; const pool = [...of('知識').flatMap(p => p.sections.map(x => ({ p, x }))), ...coreRest];
      for (const { p, x } of pool) { const h = nfk(x.h), b = nfk(x.body.slice(0, 4000)); const s2 = sc.kw.reduce((a, w) => a + (h.split(w).length - 1) * 5 + Math.min(5, b.split(w).length - 1), 0); if (s2 >= 5 && x.body.length > 20) cand.push({ p, x, s: s2 }); }
      cand.sort((a, b) => b.s - a.s); const pick = cand.slice(0, 40); if (pick.length) { put('knowHead', '知識：' + sc.name, '# 場面の知識（' + sc.name + '。使えるものだけ使う）', 1); if (only) put('know', '知識', [...new Set(pick.map(c => c.p))].map(p => named(p) + 'の「' + pick.filter(c => c.p === p).slice(0, 6).map(c => c.x.h).join('」「') + '」').join('\n'), 1); else for (const c of pick) put('know', '知識：' + c.x.h, M(cap(secText(c.x), 6000)), 1); } } }
    /* 6 機械の下読み */ if (o.machine && o.machine.length && (o.type === 'review' || o.type === 'proof')) put('machine', `機械の下読み ${o.machine.length} 件`, '# 文机が既に見つけた所（重ねて指摘しなくてよい。直し方は稿に入れる）\n' + o.machine.slice(0, o.compact ? 15 : 40).map(x => '- ' + x).join('\n'), 0);
    /* 7 文書 */ put('doc', '文書：' + (o.docName || '本文'), '# 文書（' + (o.docName || '本文') + '）\n' + String(o.doc || ''), 0);
    /* 8 答えの形 */ put('form', '答えの形', '# 答えの形\n次の区切りの行（＝＝…＝＝）をそのまま書き、その間を埋める。区切りの外には何も書かない。稿は Markdown（# 見出し・- 箇条書き・| 区切りの表）で、コードの囲みに入れない。\n' + FORM[T.id](S_gate(of('基準'), o.std)), 0);
    /* 上限：知識 → 書き手 → 基準の実例 → 基準のほかの節・棚の型 の順に、後ろから削る */ const sum = () => items.filter(x => !x.cut).reduce((t, x) => t + x.text.length + 2, 0); let total = sum();
    for (const pr of [1, 2, 3, 4]) { if (total <= budget) break; for (let k = items.length - 1; k >= 0 && total > budget; k--) { const it = items[k]; if (it.prio !== pr || it.cut) continue; it.cut = true; total = sum(); } }
    if (items.some(x => x.key === 'knowHead') && items.filter(x => x.key === 'know').every(x => x.cut)) items.find(x => x.key === 'knowHead').cut = true;
    const order = []; const row = new Map(); for (const it of items) { const k = it.key === 'knowHead' ? 'know' : it.key; if (!row.has(k)) { row.set(k, { key: k, label: k === 'know' ? '知識' : it.label, chars: 0, n: 0, cutN: 0 }); order.push(row.get(k)); } const r = row.get(k); if (it.key === 'knowHead') { r.label = it.label; continue; } if (it.cut) r.cutN++; else { r.chars += it.text.length; r.n++; } }
    for (const r of order) { r.cut = !r.n; if (r.key === 'know' || r.key === 'stdPart' || r.key === 'stdEx') r.label = (r.key === 'stdPart' ? '基準の節' : r.key === 'stdEx' ? '基準の実例' : r.label) + `（${r.n} 節${r.cutN ? `・${r.cutN} 節は削った` : ''}）`; }
    const text = items.filter(x => !x.cut).map(x => x.text).join('\n\n') + '\n';
    return { text, items: order, total: text.length, budget, over: text.length > budget }; };
  function S_gate(parts, std) { return parts.some(p => p.sections.some(x => /ゲート|G\d\d/.test(x.h))) || !!(std && std.body && /ゲート/.test(std.body)); }

  /* 答えの区切りを読む（表記の揺れは寛容に：＝＝判定＝＝・==判定==・## 判定・【判定】・■判定） */
  const MARK = /^\s*(?:[＝=]{2,}\s*|#{1,4}\s*|【\s*|■\s*|\*\*\s*)(判定|指摘|最小修正稿|推奨修正稿|修正稿|要確認|ゲート|議事録|要点)\s*(?:[＝=]{2,}|】|\*\*)?\s*$/;
  FZ.askParse = function (text) { const L = String(text || '').replace(/\r\n?/g, '\n').split('\n'); const B = {}; let cur = null;
    for (const ln of L) { const m = ln.match(MARK); if (m) { cur = m[1] === '修正稿' ? '最小修正稿' : m[1]; B[cur] = B[cur] || []; continue; } if (cur) B[cur].push(ln); }
    const get = k => B[k] ? B[k].join('\n').replace(/^\s+|\s+$/g, '') : ''; const out = { ok: Object.keys(B).length > 0, verdict: '', one: '', findings: [], draft: get('最小修正稿'), draft2: get('推奨修正稿'), needs: [], gates: [], minutes: get('議事録'), gist: get('要点') };
    { const t = get('判定'); const v = t.match(/判定\s*[:：]\s*(.+)/); out.verdict = v ? v[1].trim() : (t.split('\n')[0] || '').trim(); const o = t.match(/一言\s*[:：]\s*([\s\S]+)/); out.one = o ? o[1].trim() : ''; const s = nfk(out.verdict); out.level = /止|出せない|提出不可/.test(s) ? '止' : /直して/.test(s) ? '直' : /出してよい|提出可/.test(s) ? '可' : ''; }
    { const t = get('指摘'); let f = null; const flush = () => { if (f && (f.quote || f.problem)) out.findings.push(f); f = null; };
      for (const raw of t.split('\n')) { const isHead = /^\s*[-・*]\s+/.test(raw); const ln = raw.replace(/^\s*[-・*]?\s*/, ''); const kv = ln.match(/^(重さ|引用|問題|突っ込み|直し方|要確認)\s*[:：]\s*(.*)$/);
        if (isHead && (!kv || kv[1] === '重さ' || (f && f[keyOf(kv[1])]))) { flush(); f = { sev: '', quote: '', problem: '', ask: '', fix: '', need: '' }; }
        if (!f) f = { sev: '', quote: '', problem: '', ask: '', fix: '', need: '' };
        if (kv) { const k = keyOf(kv[1]); let v = kv[2].trim(); if (k === 'quote' || k === 'ask') v = v.replace(/^[「『"“]|[」』"”]$/g, ''); if (k === 'sev') v = (v.match(/[止直整好]/) || [''])[0]; f[k] = v; } else if (ln.trim() && f.fix) f.fix += '\n' + ln.trim(); else if (ln.trim() && f.problem && !f.ask) f.problem += ln.trim(); }
      flush(); }
    for (const raw of get('要確認').split('\n')) { const t = raw.replace(/^\s*[-・*]\s*/, '').trim(); if (t && !/^（|^\(/.test(t)) out.needs.push(t); }
    for (const raw of get('ゲート').split('\n')) { const m = raw.match(/^\s*[-・*]?\s*(G?\s*\d+|[^\s:：]+)\s*[:：]?\s*(PASS|FAIL|合格|不合格|OK|NG)\s*[:：｜|]?\s*(.*)$/i); if (m) out.gates.push({ id: m[1].replace(/\s/g, ''), pass: /PASS|合格|OK/i.test(m[2]), why: m[3].trim() }); }
    return out; };
  FZ.askStrip = t => String(t || '').replace(/<think>[\s\S]*?<\/think>/g, '').replace(/^[\s\S]*?<\/think>/, '').replace(/^\s+/, '');
  const keyOf = k => ({ 重さ: 'sev', 引用: 'quote', 問題: 'problem', 突っ込み: 'ask', 直し方: 'fix', 要確認: 'need' })[k];
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
