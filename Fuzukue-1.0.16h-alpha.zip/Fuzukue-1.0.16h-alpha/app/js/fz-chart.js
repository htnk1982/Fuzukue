/* 文机 — グラフ（図版の一種）
 * 図版に chart を持たせる：fig = { id, kind:'図'|'表', title, file:'', width, chart }
 *   chart = { type, corner, cats: [文字], series: [{ name, values: [数|null], shade }], unit, legend, labels, ratio }
 * 描き方は白黒：系列は網の文様（棒・積み上げ・帯・円）か線種と印（折れ線）で分ける。
 * 原本は「#グラフ」「#データ」「#グラフ設定」の指示行。PowerPoint・Word には編集できるグラフ（データは埋め込みの Excel）で渡す。Markdown は表（前に種類の注記） */
(function (FZ) {
'use strict';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const TYPES = [['bar', '棒'], ['barh', '横棒'], ['stack', '積み上げ'], ['line', '折れ線'], ['pie', '円'], ['band', '帯'],
  /* 1.0.11f 新聞のグラフ：面（積み上げ）・棒と折れ線（2 軸）・ドーナツ（中に合計）・滝（増減の要因）・段々の折れ線（系列ごとに上下に並べ横軸は共通）・左右の棒（人口ピラミッド型）・階段（金利など）・矢印（前→後の変化） */
  ['area', '面'], ['combo', '棒と折れ線'], ['donut', 'ドーナツ'], ['waterfall', '滝'], ['panels', '段々の折れ線'], ['pyramid', '左右の棒'], ['step', '階段'], ['arrow', '矢印']];
/* Excel のグラフで渡せる種類。ほか（滝・段々・左右・階段・矢印）は Word・PowerPoint に図形の組で渡す */
const NATIVE = new Set(['bar', 'barh', 'stack', 'line', 'pie', 'band', 'area', 'combo', 'donut']);
const TN = Object.fromEntries(TYPES), TK = Object.fromEntries(TYPES.map(([k, v]) => [v, k]));
const LEG = [['auto', '自動'], ['bottom', '下'], ['right', '右'], ['top', '上'], ['end', '線の端'], ['none', 'なし']]; /* 線の端：折れ線・階段の系列名を線の右端に（新聞の書き方） */
const LN = Object.fromEntries(LEG), LK = Object.fromEntries(LEG.map(([k, v]) => [v, k]));
/* 系列の網：黒・白・中・斜線・点・濃網…（隣どうしが白黒ではっきり分かれる順） */
const PALETTE = ['dark', 'none', 'mid', 'hatch', 'dots', 'deep', 'hatch2', 'grid', 'horz', 'check', 'gray', 'vert'];
/* 折れ線の線種と印 */
const LINES = [{ dash: '', mk: 'circle', fill: true, ppt: 'solid' }, { dash: '3 1.6', mk: 'circle', fill: false, ppt: 'dash' }, { dash: '0.8 1.3', mk: 'square', fill: true, ppt: 'sysDot' }, { dash: '4 1.4 1 1.4', mk: 'square', fill: false, ppt: 'dashDot' }, { dash: '', mk: 'tri', fill: false, ppt: 'solid' }, { dash: '2 1.8', mk: 'tri', fill: true, ppt: 'sysDash' }];
FZ.CHART_TYPES = TYPES; FZ.CHART_LEGENDS = LEG; FZ.CHART_PALETTE = PALETTE; FZ.CHART_NAMES = TN; FZ.chartNative = c => NATIVE.has(c.type) && !((c.type === 'pyramid' || c.type === 'arrow'));
const DARK = new Set(['dark', 'deep']); // 白い字を載せる網

/* ---------- 数 ---------- */
/* 表の文字 → 数。全角・桁区切り・単位（% 円 億円 人 …）・△ ▲（負）・(123)（負）を読む。数でなければ null */
function parseNum(v) {
  if (v == null) return null; if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  let s = String(v).normalize('NFKC').trim(); if (!s) return null; let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1).trim(); }
  if (/^[△▲]/.test(s)) { neg = !neg; s = s.slice(1).trim(); }
  s = s.replace(/[,\s]/g, '').replace(/^[¥$€£]/, '');
  const m = s.match(/^([+\-−‐])?(\d+(?:\.\d+)?|\.\d+)(?:e([+-]?\d+))?([^\d.]*)$/i); if (!m) return null;
  let x = parseFloat(m[2] + (m[3] ? 'e' + m[3] : '')); if (m[1] && m[1] !== '+') x = -x; if (neg) x = -x; return Number.isFinite(x) ? x : null;
}
FZ.parseChartNum = parseNum;
const decimalsOf = vals => { let d = 0; for (const v of vals) { if (v == null) continue; const s = String(Math.abs(v)); const k = s.indexOf('.'); if (k >= 0 && !/e/i.test(s)) d = Math.max(d, s.length - k - 1); } return Math.min(d, 3); };
let SEP = true; /* 千区切り：描くグラフの設定（chartSvg が描く間だけ切り替える） */
const fmt = (v, d, sep = SEP) => (v < 0 ? '−' : '') + Math.abs(v).toLocaleString('ja-JP', { minimumFractionDigits: d, maximumFractionDigits: d, useGrouping: sep });
FZ.chartFmt = fmt;

/* ---------- 形を整える ---------- */
const shadeOk = id => id === 'none' || (id && id !== 'text' && FZ.SHADE_BY && FZ.SHADE_BY[id]);
const shadeFromName = nm => { if (!nm || nm === '-') return null; if (nm === '白') return 'none'; const id = FZ.SHADE_KEYS && FZ.SHADE_KEYS[nm]; return shadeOk(id) ? id : (shadeOk(nm) ? nm : null); };
function normalizeChart(c) {
  c = c && typeof c === 'object' ? { ...c } : {};
  if (Array.isArray(c._rows) && c._rows.length) { const [h, ...rs] = c._rows; c.corner = h[0] || ''; c.cats = h.slice(1); c.series = rs.map((r, k) => ({ name: r[0] || '', values: r.slice(1), shade: shadeFromName(c._shades && c._shades[k]) })); }
  const type = TN[c.type] ? c.type : (TK[c.type] || 'bar');
  const cats = (Array.isArray(c.cats) ? c.cats : []).slice(0, 120).map(x => String(x ?? '').replace(/[\r\n]+/g, ' '));
  const series = (Array.isArray(c.series) ? c.series : []).filter(Boolean).slice(0, 24).map(s => ({ name: String(s.name ?? '').replace(/[\r\n]+/g, ' '), values: (Array.isArray(s.values) ? s.values : []).map(parseNum), shade: shadeOk(s.shade) ? s.shade : null }));
  const n = Math.max(1, cats.length, ...series.map(s => s.values.length)); while (cats.length < n) cats.push('');
  if (!series.length) series.push({ name: '', values: [], shade: null });
  for (const s of series) { s.values = s.values.slice(0, n); while (s.values.length < n) s.values.push(null); }
  return { type, corner: String(c.corner ?? ''), cats, series, unit: String(c.unit ?? ''), legend: LN[c.legend] ? c.legend : 'auto', labels: c.labels !== false, ratio: clamp(+c.ratio || 0.6, 0.3, 1.5), ...(c.dec != null && c.dec !== '' && Number.isFinite(+c.dec) ? { dec: clamp(+c.dec | 0, 0, 4) } : {}), ...(c.sep === false ? { sep: false } : {}), ...(c.brk === true || c.brk === false ? { brk: c.brk } : {}), ...(c.tot === 'first' || c.tot === 'none' ? { tot: c.tot } : {}), ...(c.link && /^[A-Za-z0-9_-]+$/.test(c.link) ? { link: c.link, linkCols: !!c.linkCols } : {}) }; /* 1.0.13c link：つないだ表の名札（attrs.tid）、linkCols：表の列を系列に */ /* brk：縦軸の省略（無し＝自動）、tot：滝の合計の棒（無し＝両端） */ /* 1.0.11e dec：小数の桁（無ければデータから）、sep：千区切り（既定あり） */
}
FZ.normalizeChart = normalizeChart;
FZ.chartShade = (c, k) => (c.series[k] && c.series[k].shade) || PALETTE[k % PALETTE.length];
const sliceShade = j => PALETTE[j % PALETTE.length];

/* ---------- 表（行×セルの文字）との行き来 ---------- */
/* グラフ → 表：1 行目は［角・項目…］、2 行目から［系列の名前・値…］ */
FZ.chartToGrid = c => [[c.corner, ...c.cats], ...c.series.map(s => [s.name, ...s.values.map(v => v == null ? '' : String(v))])];
/* 表 → グラフ。見出しの行・列があるかを中身から見分け、系列の向きは Excel と同じ（データの行が列より多ければ列が系列）。base.byCols で向きを決め打ち */
FZ.chartFromGrid = function (rows, base = {}) {
  let R = (rows || []).map(r => (r || []).map(x => String(x ?? '').replace(/\s+/g, ' ').trim()));
  while (R.length && R[R.length - 1].every(x => !x)) R.pop(); while (R.length && R[0].every(x => !x)) R.shift();
  let C = Math.max(0, ...R.map(r => r.length)); R = R.map(r => { const a = r.slice(0, C); while (a.length < C) a.push(''); return a; });
  for (let j = C - 1; j >= 0; j--) if (R.every(r => !r[j])) { R.forEach(r => r.splice(j, 1)); C--; }
  if (!R.length || !C) return normalizeChart(base);
  const isNum = x => x !== '' && parseNum(x) != null; const yearish = x => /^(19|20)\d\d(年度?|年|度)?$/.test(x);
  const headRow = R.length > 1 && (R[0][0] === '' || R[0].slice(1).some(x => x && !isNum(x)) || R[0].slice(C > 1 ? 1 : 0).every(yearish));
  const headCol = C > 1 && (R.slice(headRow ? 1 : 0).some(r => r[0] && !isNum(r[0])) || (headRow && R[0][0] !== '' && !isNum(R[0][0])) || R.slice(headRow ? 1 : 0).every(r => yearish(r[0])));
  const body = R.slice(headRow ? 1 : 0).map(r => r.slice(headCol ? 1 : 0)); if (!body.length || !body[0].length) return normalizeChart(base);
  const nr = body.length, nc = body[0].length; const byCols = base.byCols != null ? !!base.byCols : nr > nc;
  const rowLab = k => headCol ? R[(headRow ? 1 : 0) + k][0] : '', colLab = j => headRow ? R[0][(headCol ? 1 : 0) + j] : '';
  let cats, series;
  if (!byCols) { cats = Array.from({ length: nc }, (_, j) => colLab(j) || String(j + 1)); series = body.map((r, k) => ({ name: rowLab(k) || (nr > 1 ? '系列' + (k + 1) : ''), values: r })); }
  else { cats = Array.from({ length: nr }, (_, k) => rowLab(k) || String(k + 1)); series = Array.from({ length: nc }, (_, j) => ({ name: colLab(j) || (nc > 1 ? '系列' + (j + 1) : ''), values: body.map(r => r[j]) })); }
  const timeish = cats.length >= 8 && cats.filter(x => /^(19|20)\d\d|[年月期度]|^Q\d|^\d{1,2}$/.test(x)).length >= cats.length * 0.7;
  delete base.byCols; const out = normalizeChart({ type: timeish ? 'line' : 'bar', ...base, corner: headRow && headCol ? R[0][0] : '', cats, series }); Object.defineProperty(out, 'byCols', { value: byCols, enumerable: false }); return out;
};
/* 表の中身が数のグラフにできるか（数のセルが 2 つ以上） */
FZ.chartable = rows => { let n = 0; for (const r of rows || []) for (const x of r) if (parseNum(x) != null) n++; return n >= 2; };
FZ.chartTranspose = c => normalizeChart({ ...c, cats: c.series.map(s => s.name), series: c.cats.map((cat, j) => ({ name: cat, values: c.series.map(s => s.values[j]) })) });
FZ.chartSample = () => normalizeChart({ type: 'bar', corner: '', cats: ['2023年度', '2024年度', '2025年度'], series: [{ name: '国内', values: [120, 135, 150] }, { name: '海外', values: [80, 95, 130] }], unit: '億円' });

/* ---------- 原本の指示行 ---------- */
const escC = t => String(t).replace(/\|/g, '｜').replace(/[\r\n]+/g, ' ');
const escId = u => String(u).replace(/[\s<>]/g, c => encodeURIComponent(c)), unescId = u => String(u).replace(/%(20|09|3C|3E)/gi, m => decodeURIComponent(m));
const chartOpts = c => { const opt = []; if (c.link) opt.push('連動=' + c.link + ':' + (c.linkCols ? '列' : '行')); if (c.unit) opt.push('単位=' + c.unit.replace(/ /g, '%20')); if (c.legend !== 'auto') opt.push('凡例=' + LN[c.legend]); if (!c.labels) opt.push('値=なし'); if (c.dec != null) opt.push('小数=' + c.dec); if (c.sep === false) opt.push('千区切り=なし'); if (c.brk != null) opt.push('省略=' + (c.brk ? 'あり' : 'なし')); if (c.tot) opt.push('合計=' + (c.tot === 'first' ? '最初' : 'なし')); if (Math.abs(c.ratio - 0.6) > 1e-6) opt.push('縦横=' + Math.round(c.ratio * 100));
  if (c.series.some(s => s.shade)) opt.push('網=' + c.series.map(s => s.shade ? (s.shade === 'none' ? '白' : FZ.SHADE_NAMES[s.shade]) : '-').join(',')); return opt; };
FZ.chartLines = function (fg) {
  const c = fg.chart; const tt = String(fg.title || '').replace(/[\r\n]+/g, ' ').trim(); const zt = FZ.figSizeToks ? FZ.figSizeToks(fg) : []; const wd = zt.length ? ' ' + zt.join(' ') : FZ.figSizeTok && FZ.figSizeTok(tt.split(' ')[0] || '') ? ' 100%' : '';
  const L = ['#グラフ ' + escId(fg.id) + ' ' + fg.kind + ' ' + TN[c.type] + wd + (tt ? ' ' + tt : '')];
  for (const row of FZ.chartToGrid(c)) L.push('#データ | ' + row.map(escC).join(' | ') + ' |');
  const opt = chartOpts(c);
  if (opt.length) L.push('#グラフ設定 ' + opt.join(' '));
  return L;
};
/* 「#グラフ 」の後 → 図版（データは続く #データ 行で埋める） */
FZ.chartFigFromLine = function (rest) {
  const toks = String(rest).trim().split(/[ \t]+/); if (toks.length < 3) return null;
  const kind = toks[1] === '表' ? '表' : '図', type = TK[toks[2]] || (TN[toks[2]] ? toks[2] : 'bar'); let k = 3; const sz = {};
  while (toks[k] && FZ.figSizeTok && FZ.figSizeTok(toks[k])) Object.assign(sz, FZ.figSizeTok(toks[k++])); /* 大きさ：1/2・80%・原寸80% */
  return { id: unescId(toks[0]), kind, title: toks.slice(k).join(' '), file: '', ...(FZ.figSize ? FZ.figSize(sz) : { width: 100 }), chart: { type, _rows: [] } };
};
/* #データ・#グラフ設定 を組み立て中の図版へ。該当しなければ false */
FZ.chartDirective = function (raw, fg) {
  let m; const c = fg && fg.chart; if (!c) return false;
  if ((m = raw.match(/^#データ\s*\|(.*)\|\s*$/))) { (c._rows = c._rows || []).push(m[1].split('|').map(x => x.trim())); return true; }
  if ((m = raw.match(/^#グラフ設定\s+(.*)$/))) { for (const t of m[1].trim().split(/\s+/)) { const q = t.indexOf('='); if (q < 0) continue; const k = t.slice(0, q), v = t.slice(q + 1);
      if (k === '連動') { const mm = v.match(/^([A-Za-z0-9_-]+)(?::(列|行))?$/); if (mm) { c.link = mm[1]; c.linkCols = mm[2] === '列'; } } else if (k === '単位') c.unit = v.replace(/%20/g, ' '); else if (k === '凡例') c.legend = LK[v] || 'auto'; else if (k === '値') c.labels = v !== 'なし'; else if (k === '小数') c.dec = /^\d$/.test(v) ? +v : null; else if (k === '千区切り') c.sep = v !== 'なし'; else if (k === '省略') c.brk = v === 'あり' ? true : v === 'なし' ? false : undefined; else if (k === '合計') c.tot = v === '最初' ? 'first' : v === 'なし' ? 'none' : undefined; else if (k === '縦横') c.ratio = (+v || 60) / 100; else if (k === '網') c._shades = v.split(','); } return true; }
  return false;
};
/* Markdown：種類の注記（<!-- グラフ：棒 単位=億円 … -->）＋表 */
FZ.chartNote = c => '<!-- グラフ：' + TN[c.type] + chartOpts(c).map(o => ' ' + o).join('') + ' -->';
FZ.chartFromNote = function (note, rows) { const m = String(note).match(/^<!--\s*グラフ[:：]\s*(\S+)(.*?)-->\s*$/); if (!m) return null; const fg = { chart: { type: TK[m[1]] || 'bar', _rows: rows } }; if (m[2].trim()) FZ.chartDirective('#グラフ設定 ' + m[2].trim(), fg); return normalizeChart(fg.chart); };

/* ---------- 描く（図形の一覧。画面・印刷の SVG と当たり判定が同じものを使う） ---------- */
/* 目盛：lo〜hi を 1・2・5 の刻みで */
function niceTicks(lo, hi, maxN) {
  if (!(hi > lo)) hi = lo + 1; const raw = (hi - lo) / Math.max(1, maxN); const p = Math.pow(10, Math.floor(Math.log10(raw))); const f = raw / p; const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
  const a = Math.floor(lo / step + 1e-9) * step, b = Math.ceil(hi / step - 1e-9) * step; const out = []; for (let v = a; v <= b + step * 1e-6; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : +v.toPrecision(12));
  return { ticks: out, step, lo: a, hi: b };
}
const tw = (s, size) => FZ.textWidth(String(s)) * size; // 文字の幅（pt）
/* 長い項目名を幅 w（pt）に収まるよう 2 行まで折る（溢れは …） */
function wrapLabel(s, size, w, maxLines = 2) {
  s = String(s); if (tw(s, size) <= w || w <= size) return [s]; const out = []; let cur = '';
  for (const g of FZ.graphemes(s)) { if (tw(cur + g.text, size) > w && cur) { out.push(cur); cur = ''; if (out.length >= maxLines) break; } cur += g.text; }
  if (out.length < maxLines) out.push(cur); else { const last = out[maxLines - 1]; out[maxLines - 1] = last.slice(0, Math.max(1, last.length - 1)) + '…'; }
  return out;
}
FZ.chartShapes = function (c, W, H, fs) {
  const S = []; const base = clamp(fs * 0.82, 6, 12), small = base * 0.92, pad = base * 0.55;
  const ns = c.series.length, nc = c.cats.length; const type = c.type;
  const allVals = c.series.flatMap(s => s.values).filter(v => v != null); const dec = c.dec != null ? c.dec : decimalsOf(allVals); SEP = c.sep !== false;
  let top = pad * 0.6, bottom = H - pad * 0.6, left = pad * 0.6, right = W - pad * 0.6;
  const text = (x, y, t, o = {}) => S.push({ t: 'text', x, y, text: String(t), size: o.size || base, anchor: o.anchor || 'start', white: !!o.white, halo: !!o.halo, bold: !!o.bold });
  /* 凡例 */
  if ((type === 'pyramid' || type === 'arrow') && ns < 2) return FZ.chartShapes({ ...c, type: 'barh' }, W, H, fs); /* 2 系列が要る形：1 系列なら横棒 */
  const pieLike = type === 'pie' || type === 'donut', lineSer = k => type === 'line' || type === 'step' || (type === 'combo' && k > 0);
  const legItems = pieLike ? [] : c.series.map((s, k) => ({ name: s.name || ('系列' + (k + 1)), k }));
  let leg = c.legend === 'auto' ? (pieLike ? 'none' : ns > 1 ? 'bottom' : 'none') : c.legend;
  if (type === 'waterfall' || type === 'panels' || type === 'pyramid' || type === 'arrow') leg = 'none'; /* 凡例の代わりに形の中に名前を書く */
  const endLab = leg === 'end' && (type === 'line' || type === 'step'); if (leg === 'end') leg = endLab ? 'none' : (ns > 1 ? 'bottom' : 'none');
  if (pieLike && leg !== 'none') c.cats.forEach((cat, j) => legItems.push({ name: cat || String(j + 1), j }));
  if (!legItems.length) leg = 'none';
  const sw = base * 1.5, sh = base * 0.85, gapI = base * 1.1;
  const legSwatch = (it, x, y) => { if (it.k != null && lineSer(it.k)) { const L = LINES[it.k % LINES.length]; S.push({ t: 'line', x1: x, y1: y, x2: x + sw, y2: y, sw: it.k === 0 ? 1.3 : 1, dash: L.dash }); S.push({ t: 'mark', x: x + sw / 2, y, mk: L.mk, fill: L.fill, size: base * 0.42, s: it.k }); }
    else S.push({ t: 'rect', x, y: y - sh / 2, w: sw, h: sh, fill: it.j != null ? sliceShade(it.j) : FZ.chartShade(c, it.k), sw: 0.5, s: it.k, j: it.j, leg: true }); };
  if (leg === 'bottom' || leg === 'top') {
    const rows = [[]]; let x = 0; const avail = right - left; for (const it of legItems) { const w = sw + base * 0.35 + tw(it.name, small); if (x > 0 && x + w > avail) { rows.push([]); x = 0; } rows[rows.length - 1].push({ it, w }); x += w + gapI; }
    const rh = base * 1.45, lh = rows.length * rh; let y0 = leg === 'bottom' ? bottom - lh : top;
    for (const r of rows) { const tot = r.reduce((t, e) => t + e.w, 0) + gapI * (r.length - 1); let xx = left + (avail - tot) / 2; const cy = y0 + rh / 2;
      for (const e of r) { legSwatch(e.it, xx, cy); text(xx + sw + base * 0.35, cy + small * 0.36, e.it.name, { size: small }); xx += e.w + gapI; } y0 += rh; }
    if (leg === 'bottom') bottom -= lh + pad * 0.4; else top += lh + pad * 0.4;
  } else if (leg === 'right') {
    const lw = Math.min((right - left) * 0.4, sw + base * 0.35 + Math.max(...legItems.map(it => tw(it.name, small)))); const rh = base * 1.45; let y = (top + bottom) / 2 - legItems.length * rh / 2 + rh / 2; const x = right - lw;
    for (const it of legItems) { legSwatch(it, x, y); text(x + sw + base * 0.35, y + small * 0.36, it.name, { size: small }); y += rh; } right -= lw + pad;
  }
  /* 単位 */
  if (c.unit && !pieLike && type !== 'band') { const [u1, u2] = c.unit.split('|'); text(left, top + small * 0.9, '（' + u1 + '）', { size: small }); if (u2 && type === 'combo') text(right, top + small * 0.9, '（' + u2 + '）', { size: small, anchor: 'end' }); top += small * 1.45; } /* 棒と折れ線は「億円|%」で左右の軸の単位 */
  if (pieLike) return pieShapes(c, S, text, { left, right, top, bottom, base, small, pad, dec, leg, donut: type === 'donut' });
  if (type === 'band') return bandShapes(c, S, text, { left, right, top, bottom, base, small, pad, dec });
  if (NEWS[type]) return NEWS[type](c, S, text, { left, right, top, bottom, base, small, pad, dec, endLab });
  const horiz = type === 'barh';
  /* 値の範囲 */
  let mn = Infinity, mx = -Infinity;
  if (type === 'stack') for (let j = 0; j < nc; j++) { let p = 0, q = 0; for (const s of c.series) { const v = s.values[j]; if (v == null) continue; if (v >= 0) p += v; else q += v; } mn = Math.min(mn, q); mx = Math.max(mx, p); }
  else for (const v of allVals) { mn = Math.min(mn, v); mx = Math.max(mx, v); }
  if (!Number.isFinite(mn)) { mn = 0; mx = 1; }
  let [lo, hi] = valRange(type === 'line', mn, mx, horiz || type === 'stack' ? false : c.brk);
  const valLabelRoom = c.labels ? base * 1.1 : base * 0.3;
  if (!horiz) {
    const plotH0 = bottom - top; if (c.labels && type === 'bar' && lo > 0) hi += (hi - lo) * 0.08; const T = niceTicks(lo, hi, clamp(Math.round(plotH0 / (base * 2.6)), 2, 8)); lo = T.lo; hi = T.hi; const tdec = decimalsOf([T.step]);
    const labs = T.ticks.map(v => fmt(v, tdec)); const bk = lo > 0 && type !== 'bar' ? base * 0.5 : 0; left += Math.max(...labs.map(l => tw(l, small))) + pad * 0.6 + bk; if (endLab) right -= endRoom(c, small, pad, right - left);
    const bandW = (right - left) / nc; const catLines = c.cats.map(t => wrapLabel(t, small, bandW * 0.96)); const nl = Math.max(1, ...catLines.map(l => l.length));
    bottom -= nl * small * 1.2 + pad * 0.3; const plotTop = top + (c.labels ? valLabelRoom * 0.6 : 0);
    const Y = v => bottom - (v - lo) / (hi - lo) * (bottom - plotTop);
    T.ticks.forEach((v, k) => { const y = Y(v); if (v !== 0) S.push({ t: 'line', x1: left, y1: y, x2: right, y2: y, sw: 0.3, dash: '0.6 1.2' }); text(left - pad * 0.4 - bk, y + small * 0.35, labs[k], { size: small, anchor: 'end' }); });
    S.push({ t: 'line', x1: left, y1: Y(Math.max(lo, Math.min(hi, 0))), x2: right, y2: Y(Math.max(lo, Math.min(hi, 0))), sw: 0.6 });
    catLines.forEach((ls, j) => ls.forEach((l, q) => text(left + (j + 0.5) * bandW, bottom + pad * 0.3 + small * (q + 1) * 1.1, l, { size: small, anchor: 'middle' })));
    if (type === 'bar') { const gw = bandW * (ns > 1 ? 0.78 : 0.6), bw = gw / ns;
      for (let j = 0; j < nc; j++) for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null) continue; const x = left + j * bandW + (bandW - gw) / 2 + k * bw; const y1 = Y(Math.max(v, lo, 0)), y2 = Y(Math.max(lo, Math.min(v, 0))); /* 軸を省略した棒は下端から */
        S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill: FZ.chartShade(c, k), sw: 0.5, s: k, j, hit: true });
        if (c.labels) { const lab = fmt(v, dec); const size = Math.max(base * 0.6, Math.min(small, bw * 1.15 / Math.max(1, FZ.textWidth(lab)))); text(x + bw / 2, v >= 0 ? y1 - size * 0.3 : y2 + size * 1.05, lab, { size, anchor: 'middle' }); } } }
    else if (type === 'stack') { const bw = bandW * 0.56;
      for (let j = 0; j < nc; j++) { let p = 0, q = 0; const x = left + j * bandW + (bandW - bw) / 2;
        for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null || v === 0) continue; const a = v >= 0 ? p : q, b = a + v; if (v >= 0) p = b; else q = b; const y1 = Y(Math.max(a, b)), y2 = Y(Math.min(a, b)); const sh2 = FZ.chartShade(c, k);
          S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill: sh2, sw: 0.5, s: k, j, hit: true });
          if (c.labels && y2 - y1 > small * 1.15) { const lab = fmt(v, dec); if (tw(lab, small) < bw * 0.98) text(x + bw / 2, (y1 + y2) / 2 + small * 0.36, lab, { size: small, anchor: 'middle', white: DARK.has(sh2), halo: !DARK.has(sh2) && sh2 !== 'none' }); } }
        if (c.labels && ns > 1 && p > 0) text(x + bw / 2, Y(p) - small * 0.3, fmt(p, dec), { size: small, anchor: 'middle', bold: true }); } }
    else { // 折れ線
      const X = j => left + (j + 0.5) * bandW;
      c.series.forEach((s, k) => { const L = LINES[k % LINES.length]; let d = '', pen = false; const pts = [];
        s.values.forEach((v, j) => { if (v == null) { pen = false; return; } const x = X(j), y = Y(v); d += (pen ? 'L' : 'M') + x.toFixed(2) + ' ' + y.toFixed(2); pen = true; pts.push({ x, y, v, j }); });
        if (d) S.push({ t: 'path', d, fill: 'none', sw: k === 0 ? 1.4 : 1.05, dash: L.dash, s: k, pts, hit: true });
        for (const p of pts) S.push({ t: 'mark', x: p.x, y: p.y, mk: L.mk, fill: L.fill, size: base * 0.44, s: k, j: p.j, hit: true });
        if (c.labels && ns <= 3) for (const p of pts) text(p.x, k % 2 ? p.y + small * 1.35 : p.y - small * 0.55, fmt(p.v, dec), { size: small * 0.95, anchor: 'middle', halo: true }); });
      if (endLab) endLabels(c, S, text, X, Y, right, small, pad); }
    if (lo > 0) breakMark(S, left, right, bottom, plotTop, base, type === 'bar'); /* 縦軸を 0 から始めない：波線で省略を示す */
    return S;
  }
  /* 横棒：項目は上から下へ、値の軸は下 */
  const catW = Math.min((right - left) * 0.36, Math.max(...c.cats.map(t => tw(t, small))) + pad * 0.6);
  const T = niceTicks(lo, hi, clamp(Math.round((right - left - catW) / (base * 4.5)), 2, 7)); lo = T.lo; hi = T.hi; const tdec = decimalsOf([T.step]); const labs = T.ticks.map(v => fmt(v, tdec));
  bottom -= small * 1.4; const lab0 = c.labels ? Math.max(...allVals.map(v => tw(fmt(v, dec), small))) + pad * 0.3 : 0; right -= Math.min(lab0, (right - left) * 0.2); left += catW;
  const Xv = v => left + (v - lo) / (hi - lo) * (right - left); const bandH = (bottom - top) / nc;
  T.ticks.forEach((v, k) => { const x = Xv(v); if (v !== 0) S.push({ t: 'line', x1: x, y1: top, x2: x, y2: bottom, sw: 0.3, dash: '0.6 1.2' }); text(x, bottom + small * 1.15, labs[k], { size: small, anchor: 'middle' }); });
  S.push({ t: 'line', x1: Xv(Math.max(lo, Math.min(hi, 0))), y1: top, x2: Xv(Math.max(lo, Math.min(hi, 0))), y2: bottom, sw: 0.6 });
  c.cats.forEach((t, j) => { const ls = wrapLabel(t, small, catW - pad * 0.6); const cy = top + (j + 0.5) * bandH; ls.forEach((l, q) => text(left - pad * 0.5, cy + small * 0.36 + (q - (ls.length - 1) / 2) * small * 1.1, l, { size: small, anchor: 'end' })); });
  const gh = bandH * (ns > 1 ? 0.78 : 0.6), bh = gh / ns;
  for (let j = 0; j < nc; j++) for (let k = 0; k < ns; k++) { const v = c.series[k].values[j]; if (v == null) continue; const y = top + j * bandH + (bandH - gh) / 2 + k * bh; const x1 = Xv(Math.min(v, 0)), x2 = Xv(Math.max(v, 0));
    S.push({ t: 'rect', x: x1, y, w: Math.max(0.01, x2 - x1), h: bh, fill: FZ.chartShade(c, k), sw: 0.5, s: k, j, hit: true });
    if (c.labels) { const size = Math.max(base * 0.6, Math.min(small, bh * 0.95)); text(v >= 0 ? x2 + pad * 0.3 : x1 - pad * 0.3, y + bh / 2 + size * 0.36, fmt(v, dec), { size, anchor: v >= 0 ? 'start' : 'end' }); } }
  return S;
};
/* 帯グラフ（100% の横棒）：項目ごとに 1 本、系列の構成比 */
function bandShapes(c, S, text, g) {
  let { left, right, top, bottom, base, small, pad, dec } = g; const nc = c.cats.length, ns = c.series.length;
  const catW = Math.min((right - left) * 0.3, Math.max(0, ...c.cats.map(t => tw(t, small))) + pad * 0.6); left += catW;
  const bandH = (bottom - top) / nc; const bh = Math.min(bandH * 0.62, base * 2.6);
  for (let j = 0; j < nc; j++) { const vals = c.series.map(s => Math.max(0, s.values[j] || 0)); const tot = vals.reduce((a, b) => a + b, 0); const pctIn = Math.abs(tot - 100) < 1.5; const cy = top + (j + 0.5) * bandH; let x = left;
    const ls = wrapLabel(c.cats[j], small, catW - pad * 0.6); ls.forEach((l, q) => text(left - pad * 0.5, cy + small * 0.36 + (q - (ls.length - 1) / 2) * small * 1.1, l, { size: small, anchor: 'end' }));
    if (!tot) continue;
    vals.forEach((v, k) => { if (!v) return; const w = (right - left) * v / tot; const sh2 = FZ.chartShade(c, k); S.push({ t: 'rect', x, y: cy - bh / 2, w, h: bh, fill: sh2, sw: 0.5, s: k, j, hit: true });
      if (c.labels) { const lab = pctIn ? fmt(v, dec) + '%' : fmt(Math.round(v / tot * 1000) / 10, v / tot < 0.1 ? 1 : 0) + '%'; if (tw(lab, small) < w * 0.96) text(x + w / 2, cy + small * 0.36, lab, { size: small, anchor: 'middle', white: DARK.has(sh2), halo: !DARK.has(sh2) && sh2 !== 'none' }); }
      x += w; }); }
  return S;
}
function donutCenter(c, S, text, cx, cy, r, tot, g) { const ri = r * 0.56; const t = fmt(tot, g.dec); const size = Math.min(g.base * 1.5, ri * 1.5 / Math.max(1, FZ.textWidth(t))); const nm = c.series[0].name;
  if (nm && tw(nm, g.small) < ri * 1.7) text(cx, cy - size * 0.55, nm, { size: g.small, anchor: 'middle' }); text(cx, cy + size * 0.4 + (nm ? size * 0.15 : 0), t, { size, anchor: 'middle', bold: true }); if (c.unit) text(cx, cy + size * 0.4 + g.small * 1.2 + (nm ? size * 0.15 : 0), c.unit, { size: g.small, anchor: 'middle' }); }
/* 円：最初の系列。12 時から時計回り。入る切れは中に名前と率、入らない切れは外に引き出し線（左右それぞれ上下に重ならないよう詰め直す） */
function pieShapes(c, S, text, g) {
  const { left, right, top, bottom, base, small, pad, leg } = g; const DN = !!g.donut; /* ドーナツ：内側を抜き、中に合計（と単位） */ const vals = c.series[0].values.map(v => Math.max(0, v || 0)); const tot = vals.reduce((a, b) => a + b, 0);
  const cx = (left + right) / 2, cy = (top + bottom) / 2; const W2 = (right - left) / 2, H2 = (bottom - top) / 2;
  if (!tot) { S.push({ t: 'circle', cx, cy, r: Math.max(4, Math.min(W2, H2) - pad), sw: 0.5 }); return S; }
  const sl = []; let a = -Math.PI / 2;
  vals.forEach((v, j) => { if (!v) return; const da = v / tot * Math.PI * 2; const pct = Math.round(v / tot * 1000) / 10; const name = leg === 'none' ? (c.cats[j] || '') : ''; const pl = fmt(pct, pct < 10 ? 1 : 0) + '%'; sl.push({ j, a0: a, a1: a + da, da, mid: a + da / 2, name, pl, sh: sliceShade(j) }); a += da; });
  const fits = (x, r) => { const w = Math.max(tw(x.pl, small), x.name ? tw(x.name, small) : 0) * 1.08, h = small * (x.name ? 2.4 : 1.3); const rm = DN ? r * 0.78 : r * 0.6; return x.da >= 0.3 && 2 * rm * Math.sin(Math.min(Math.PI / 2, x.da / 2)) > w && (DN ? r * 0.44 > h : r * 0.75 > h); };
  const r0 = Math.max(4, Math.min(W2 - pad, H2 - pad * 0.4)); let r = r0;
  if (c.labels) { const outs = sl.filter(x => !fits(x, r)); if (outs.length) { const ow = Math.max(...outs.map(x => tw((x.name ? x.name + ' ' : '') + x.pl, small))); r = Math.max(4, Math.min(W2 - ow - base * 1.6, H2 - small * 0.9)); } }
  /* 狭くて円が小さくなりすぎる時は、円の右に「網・名前・率」の一覧（凡例に率を添えたもの） */
  if (c.labels && r < r0 * 0.7) { const sw = base * 1.5, sh = base * 0.85, rh = small * 1.45; const items = sl.map(x => ({ x, t: (c.cats[x.j] || String(x.j + 1)) + ' ' + x.pl })); const lw = sw + base * 0.35 + Math.max(...items.map(e => tw(e.t, small)));
    const rr = Math.max(4, Math.min(H2 - pad * 0.4, ((right - left) - lw - base * 0.8) / 2)); const ccx = left + rr + pad * 0.2; const lx = ccx + rr + base * 0.8; let y = cy - items.length * rh / 2 + rh / 2;
    for (const x of sl) S.push({ t: 'wedge', cx: ccx, cy, r: rr, ri: DN ? rr * 0.56 : 0, a0: x.a0, a1: x.a1, fill: x.sh, sw: 0.6, s: 0, j: x.j, hit: true }); if (DN) donutCenter(c, S, text, ccx, cy, rr, tot, g);
    for (const e of items) { S.push({ t: 'rect', x: lx, y: y - sh / 2, w: sw, h: sh, fill: e.x.sh, sw: 0.5, j: e.x.j, leg: true }); text(lx + sw + base * 0.35, y + small * 0.36, e.t, { size: small }); y += rh; }
    return S; }
  for (const x of sl) S.push({ t: 'wedge', cx, cy, r, ri: DN ? r * 0.56 : 0, a0: x.a0, a1: x.a1, fill: x.sh, sw: 0.6, s: 0, j: x.j, hit: true }); if (DN) donutCenter(c, S, text, cx, cy, r, tot, g);
  if (!c.labels) return S;
  const outs = { l: [], r: [] };
  for (const x of sl) { if (fits(x, r)) { const rm = DN ? r * 0.78 : r * 0.6; const tx = cx + Math.cos(x.mid) * rm, ty = cy + Math.sin(x.mid) * rm; const o = { size: small, anchor: 'middle', white: DARK.has(x.sh), halo: !DARK.has(x.sh) && x.sh !== 'none' };
      if (x.name) { text(tx, ty - small * 0.2, x.name, o); text(tx, ty + small * 1.0, x.pl, o); } else text(tx, ty + small * 0.36, x.pl, o); continue; }
    const side = Math.cos(x.mid) >= 0 ? 'r' : 'l'; outs[side].push({ x, y: cy + Math.sin(x.mid) * r * 1.15 }); }
  const gap = small * 1.25;
  for (const side of ['l', 'r']) { const L = outs[side].sort((p, q) => p.y - q.y); const lo = top + small * 0.6, hi = bottom - small * 0.3;
    for (let k = 0; k < L.length; k++) L[k].y = Math.max(L[k].y, k ? L[k - 1].y + gap : lo); /* 上から詰める */
    for (let k = L.length - 1; k >= 0; k--) L[k].y = Math.min(L[k].y, k < L.length - 1 ? L[k + 1].y - gap : hi); /* 下からはみ出しを戻す */
    for (const e of L) { const x = e.x, rs = side === 'r'; const x1 = cx + Math.cos(x.mid) * r * 0.92, y1 = cy + Math.sin(x.mid) * r * 0.92; const x2 = cx + (rs ? 1 : -1) * Math.max(Math.abs(Math.cos(x.mid)) * r * 1.1, r * 0.35 + Math.sqrt(Math.max(0, r * r * 1.21 - (e.y - cy) * (e.y - cy))) * 0.7); const x3 = x2 + (rs ? base * 0.6 : -base * 0.6);
      S.push({ t: 'line', x1, y1, x2, y2: e.y, sw: 0.4 }, { t: 'line', x1: x2, y1: e.y, x2: x3, y2: e.y, sw: 0.4 }); text(x3 + (rs ? 2 : -2), e.y + small * 0.36, (x.name ? x.name + ' ' : '') + x.pl, { size: small, anchor: rs ? 'start' : 'end' }); } }
  return S;
}
/* ---------- 1.0.11f 新聞のグラフ ---------- */
/* 値の範囲：既定は 0 を含む。折れ線は値が高い所に固まっていれば 0 を省く（自動）。brk=true で棒も省く、false で省かない */
function valRange(lineLike, mn, mx, brk) { let lo = Math.min(0, mn), hi = Math.max(0, mx); if (brk !== false && mn > 0 && (brk === true || (lineLike && mn > mx * 0.55))) lo = Math.max(0, mn - (mx - mn) * 0.25); return [lo, hi]; }
/* 波線（省略の印）：bars なら棒を横切る白い帯と 2 本の波線、そうでなければ縦軸を描いてその下の方に波線 */
function breakMark(S, x0, x1, bottom, top, base, bars) {
  const amp = base * 0.16, per = base * 0.5, gap = base * 0.3; const zig = (xa, xb, y) => { let d = `M${xa.toFixed(2)} ${y.toFixed(2)}`, k = 0; for (let x = xa + per / 2; x < xb + per / 2; x += per / 2) d += `L${Math.min(x, xb).toFixed(2)} ${(y + (k++ % 2 ? amp : -amp)).toFixed(2)}`; return d; };
  if (bars) { const y = bottom - (bottom - top) * 0.07; S.push({ t: 'poly', pts: [[x0, y - gap / 2 - amp], [x1, y - gap / 2 - amp], [x1, y + gap / 2 + amp], [x0, y + gap / 2 + amp]], fill: 'none', sw: 0, white: true }); S.push({ t: 'path', d: zig(x0, x1, y - gap / 2), sw: 0.5 }, { t: 'path', d: zig(x0, x1, y + gap / 2), sw: 0.5 }); return; }
  S.push({ t: 'line', x1: x0, y1: top, x2: x0, y2: bottom, sw: 0.6 }); const y = bottom - base * 0.75, xa = x0 - base * 0.45, xb = x0 + base * 0.45;
  S.push({ t: 'poly', pts: [[xa, y - gap / 2], [xb, y - gap / 2], [xb, y + gap / 2], [xa, y + gap / 2]], fill: 'none', sw: 0, white: true }); S.push({ t: 'path', d: zig(xa, xb, y - gap / 2), sw: 0.5 }, { t: 'path', d: zig(xa, xb, y + gap / 2), sw: 0.5 }); }
/* 線の端の名前：右に空ける幅と、重ならないように上下に詰めて置く */
const endRoom = (c, small, pad, w) => Math.min(w * 0.3, Math.max(...c.series.map((s, k) => tw(s.name || '系列' + (k + 1), small))) + pad * 0.8);
function endLabels(c, S, text, X, Y, right, small, pad) { const L = [];
  c.series.forEach((s, k) => { let j = s.values.length - 1; while (j >= 0 && s.values[j] == null) j--; if (j >= 0) L.push({ k, x: X(j), y: Y(s.values[j]), name: s.name || '系列' + (k + 1) }); });
  L.sort((a, b) => a.y - b.y); const gap = small * 1.15; for (let i = 1; i < L.length; i++) L[i].y = Math.max(L[i].y, L[i - 1].y + gap);
  for (const e of L) { text(right + pad * 0.4, e.y + small * 0.36, e.name, { size: small, bold: e.k === 0 }); S.push({ t: 'line', x1: e.x + 2, y1: e.y, x2: right + pad * 0.25, y2: e.y, sw: 0.3, dash: '0.6 1' }); } }
/* 縦の値軸・横の項目軸の枠：目盛と罫と項目名を描き、座標の関数を返す。o.y2：右の軸の範囲 [lo, hi]、o.room：値を書く上の余白、o.right：右に空ける幅 */
function frameV(c, S, text, g, lo, hi, o = {}) { let { left, right, top, bottom, base, small, pad } = g; const nc = c.cats.length;
  const T = niceTicks(lo, hi, clamp(Math.round((bottom - top) / (base * 2.6)), 2, 8)); lo = T.lo; hi = T.hi; const labs = T.ticks.map(v => fmt(v, decimalsOf([T.step])));
  const bk = lo > 0 ? base * 0.5 : 0; left += Math.max(...labs.map(l => tw(l, small))) + pad * 0.6 + bk; let T2 = null, labs2 = null; if (o.y2) { T2 = niceTicks(o.y2[0], o.y2[1], T.ticks.length - 1); labs2 = T2.ticks.map(v => fmt(v, decimalsOf([T2.step]))); right -= Math.max(...labs2.map(l => tw(l, small))) + pad * 0.6; } if (o.right) right -= o.right;
  const bandW = (right - left) / nc; const catLines = c.cats.map(t => wrapLabel(t, small, bandW * 0.96)); const nl = Math.max(1, ...catLines.map(l => l.length));
  bottom -= nl * small * 1.2 + pad * 0.3; const plotTop = top + (o.room || 0); const Y = v => bottom - (v - lo) / (hi - lo) * (bottom - plotTop);
  T.ticks.forEach((v, k) => { const y = Y(v); if (v !== 0 && y < bottom - 0.5) S.push({ t: 'line', x1: left, y1: y, x2: right, y2: y, sw: 0.3, dash: '0.6 1.2' }); text(left - pad * 0.4 - bk, y + small * 0.35, labs[k], { size: small, anchor: 'end' }); });
  let Y2 = null; if (T2) { Y2 = v => bottom - (v - T2.lo) / (T2.hi - T2.lo) * (bottom - plotTop); T2.ticks.forEach((v, k) => text(right + pad * 0.4, Y2(v) + small * 0.35, labs2[k], { size: small })); }
  S.push({ t: 'line', x1: left, y1: Y(clamp(0, lo, hi)), x2: right, y2: Y(clamp(0, lo, hi)), sw: 0.6 });
  catLines.forEach((ls, j) => ls.forEach((l, q) => text(left + (j + 0.5) * bandW, bottom + pad * 0.3 + small * (q + 1) * 1.1, l, { size: small, anchor: 'middle' })));
  return { Y, Y2, left, right, top: plotTop, bottom, bandW, X: j => left + (j + 0.5) * bandW, lo, hi }; }
const minMax = vals => { let mn = Infinity, mx = -Infinity; for (const v of vals) if (v != null) { if (v < mn) mn = v; if (v > mx) mx = v; } return Number.isFinite(mn) ? [mn, mx] : [0, 1]; };
const signed = (v, dec) => (v > 0 ? '+' : '') + fmt(v, dec);
const NEWS = {
  /* 面：系列を下から積み上げた面（空の値は 0） */
  area(c, S, text, g) { const nc = c.cats.length; const cum = []; let acc = c.cats.map(() => 0); c.series.forEach(s => { acc = acc.map((a, j) => a + (s.values[j] || 0)); cum.push(acc.slice()); });
    const [mn, mx] = minMax(cum.flat()); const F = frameV(c, S, text, g, Math.min(0, mn), Math.max(0, mx)); const X = F.X;
    cum.forEach((top, k) => { const bot = k ? cum[k - 1] : c.cats.map(() => 0); const pts = [...top.map((v, j) => [X(j), F.Y(v)]), ...bot.map((v, j) => [X(j), F.Y(v)]).reverse()]; S.push({ t: 'poly', pts, fill: FZ.chartShade(c, k), sw: 0.5, s: k, hit: true }); });
    if (c.labels && nc) cum.forEach((top, k) => { const bot = k ? cum[k - 1][nc - 1] : 0, v = top[nc - 1] - bot; const y = (F.Y(top[nc - 1]) + F.Y(bot)) / 2, sh = FZ.chartShade(c, k); if (F.Y(bot) - F.Y(top[nc - 1]) > g.small * 1.1) text(X(nc - 1) - g.pad * 0.3, y + g.small * 0.36, fmt(v, g.dec), { size: g.small, anchor: 'end', white: DARK.has(sh), halo: !DARK.has(sh) && sh !== 'none' }); });
    return S; },
  /* 棒と折れ線：最初の系列は棒（左の軸）、2 つ目からは折れ線（右の軸）。売上高と利益率など */
  combo(c, S, text, g) { const b = c.series[0].values, rest = c.series.slice(1); const [m1, x1] = minMax(b), [m2, x2] = minMax(rest.flatMap(s => s.values));
    const F = frameV(c, S, text, g, Math.min(0, m1), Math.max(0, x1) * (rest.length ? 1.9 : 1), { y2: rest.length ? [Math.min(0, m2), Math.max(0, x2)] : null, room: c.labels ? g.base * 0.7 : 0 }); const bw = F.bandW * 0.56; const d0 = c.dec != null ? c.dec : decimalsOf(b); /* 棒は下の半分、折れ線は上に（重ならないよう左の軸を伸ばす） */
    b.forEach((v, j) => { if (v == null) return; const x = F.X(j) - bw / 2, y1 = F.Y(Math.max(v, 0)), y2 = F.Y(Math.min(v, 0)); S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill: FZ.chartShade(c, 0), sw: 0.5, s: 0, j, hit: true }); if (c.labels) text(x + bw / 2, v >= 0 ? y1 - g.small * 0.3 : y2 + g.small * 1.05, fmt(v, d0), { size: g.small, anchor: 'middle' }); });
    const Y2 = F.Y2 || F.Y; rest.forEach((s, q) => { const k = q + 1, L = LINES[q % LINES.length]; let d = '', pen = false; const pts = []; s.values.forEach((v, j) => { if (v == null) { pen = false; return; } const x = F.X(j), y = Y2(v); d += (pen ? 'L' : 'M') + x.toFixed(2) + ' ' + y.toFixed(2); pen = true; pts.push({ x, y, v, j }); });
      if (d) S.push({ t: 'path', d, sw: 1.4, dash: L.dash, s: k, pts, hit: true }); for (const p of pts) { S.push({ t: 'mark', x: p.x, y: p.y, mk: L.mk, fill: L.fill, size: g.base * 0.44, s: k, j: p.j, hit: true }); if (c.labels && rest.length <= 2) text(p.x, p.y - g.small * 0.6, fmt(p.v, c.dec != null ? c.dec : decimalsOf(s.values)), { size: g.small * 0.95, anchor: 'middle', halo: true }); } });
    return S; },
  /* 滝：最初の項目は元の値（0 から立つ棒）、間は増減（前の棒の端から浮く棒）、最後は合計（空なら計算）。増は黒、減は白、合計は中の網。棒の間を点線でつなぐ */
  waterfall(c, S, text, g) { const v = c.series[0].values, n = v.length, tot = c.tot || 'both'; const bars = []; let run = 0;
    v.forEach((x, j) => { const first = j === 0 && tot !== 'none', last = j === n - 1 && n > 1 && tot === 'both';
      if (first) { run = x || 0; bars.push({ j, a: 0, b: run, kind: 'tot', v: run }); } else if (last) { const t = x == null ? run : x; bars.push({ j, a: 0, b: t, kind: 'tot', v: t }); run = t; } else { if (x == null) return; bars.push({ j, a: run, b: run + x, kind: x >= 0 ? 'up' : 'down', v: x }); run += x; } });
    const [mn, mx] = minMax(bars.flatMap(b => [b.a, b.b])); const F = frameV(c, S, text, g, Math.min(0, mn), Math.max(0, mx), { room: c.labels ? g.base * 0.7 : 0 }); const bw = F.bandW * 0.6;
    bars.forEach((b, i) => { const x = F.X(b.j) - bw / 2, y1 = F.Y(Math.max(b.a, b.b)), y2 = F.Y(Math.min(b.a, b.b)); const fill = b.kind === 'tot' ? 'mid' : b.kind === 'up' ? 'dark' : 'none';
      S.push({ t: 'rect', x, y: y1, w: bw, h: Math.max(0.01, y2 - y1), fill, sw: 0.5, s: 0, j: b.j, hit: true });
      const nx = bars[i + 1]; if (nx) { const yy = F.Y(b.b); S.push({ t: 'line', x1: x + bw, y1: yy, x2: F.X(nx.j) - bw / 2, y2: yy, sw: 0.4, dash: '1 1' }); }
      if (c.labels) { const lab = b.kind === 'tot' ? fmt(b.v, g.dec) : signed(b.v, g.dec); const up = b.kind !== 'down'; text(x + bw / 2, up ? y1 - g.small * 0.3 : y2 + g.small * 1.05, lab, { size: g.small, anchor: 'middle', bold: b.kind === 'tot' }); } });
    return S; },
  /* 段々の折れ線：系列ごとに段を分けて上下に並べる（目盛は段ごと、横軸は一番下に共通）。段の左上に系列名、線の右端に最後の値 */
  panels(c, S, text, g) { let { left, right, top, bottom, base, small, pad } = g; const ns = c.series.length, nc = c.cats.length;
    const lastLab = s => { let j = s.values.length - 1; while (j >= 0 && s.values[j] == null) j--; return j >= 0 ? fmt(s.values[j], decimalsOf(s.values)) : ''; };
    const phEst = (bottom - top - small * 2.4) / ns - small * 1.4; const nT = clamp(Math.floor(phEst / (small * 1.25)), 1, 3);
    const Ts = c.series.map(s => { let [mn, mx] = minMax(s.values); if (mn === mx) { mn -= 1; mx += 1; } const [lo, hi] = valRange(true, mn, mx, c.brk); const T = niceTicks(lo, hi, nT); if (T.ticks.length > nT + 1) T.ticks = T.ticks.filter((_, q) => q % 2 === 0); return T; }); /* 段が低ければ目盛を間引く */
    const labsAll = Ts.map(T => T.ticks.map(v => fmt(v, decimalsOf([T.step])))); const bk = Ts.some(T => T.lo > 0) ? base * 0.5 : 0; left += Math.max(...labsAll.flat().map(l => tw(l, small))) + pad * 0.6 + bk;
    right -= Math.max(...c.series.map(s => tw(lastLab(s), small))) + base * 0.8; const bandW = (right - left) / nc; const catLines = c.cats.map(t => wrapLabel(t, small, bandW * 0.96)); const nl = Math.max(1, ...catLines.map(l => l.length));
    bottom -= nl * small * 1.2 + pad * 0.3; const gapP = small * 0.6, ph = (bottom - top - gapP * (ns - 1)) / ns; const X = j => left + (j + 0.5) * bandW;
    c.series.forEach((s, k) => { const T = Ts[k], y0 = top + k * (ph + gapP), pT = y0 + small * 1.35, pB = y0 + ph; const Y = v => pB - (v - T.lo) / (T.hi - T.lo) * (pB - pT);
      text(left, y0 + small * 0.95, s.name || '系列' + (k + 1), { size: small, bold: true });
      T.ticks.forEach((v, q) => { const y = Y(v); if (q) S.push({ t: 'line', x1: left, y1: y, x2: right, y2: y, sw: 0.3, dash: '0.6 1.2' }); text(left - pad * 0.4 - bk, y + small * 0.35, labsAll[k][q], { size: small, anchor: 'end' }); });
      S.push({ t: 'line', x1: left, y1: pB, x2: right, y2: pB, sw: 0.6 }); if (T.lo > 0) breakMark(S, left, right, pB, pT, base, false);
      let d = '', pen = false; const pts = []; s.values.forEach((v, j) => { if (v == null) { pen = false; return; } const x = X(j), y = Y(v); d += (pen ? 'L' : 'M') + x.toFixed(2) + ' ' + y.toFixed(2); pen = true; pts.push({ x, y, v, j }); });
      if (d) S.push({ t: 'path', d, sw: 1.3, s: k, pts, hit: true }); const lp = pts[pts.length - 1]; if (lp) { S.push({ t: 'mark', x: lp.x, y: lp.y, mk: 'circle', fill: true, size: base * 0.38, s: k, j: lp.j, hit: true }); text(lp.x + base * 0.65, lp.y + small * 0.36, lastLab(s), { size: small, bold: true }); }
      if (nc <= 14) for (const p of pts.slice(0, -1)) S.push({ t: 'mark', x: p.x, y: p.y, mk: 'circle', fill: true, size: base * 0.22, s: k, j: p.j, hit: true }); });
    catLines.forEach((ls, j) => ls.forEach((l, q) => text(X(j), bottom + pad * 0.3 + small * (q + 1) * 1.1, l, { size: small, anchor: 'middle' })));
    return S; },
  /* 左右の棒：1 つ目の系列を左へ、2 つ目を右へ。項目名は真ん中の列。目盛は左右対称（人口ピラミッド・輸出入・男女） */
  pyramid(c, S, text, g) { let { left, right, top, bottom, base, small, pad } = g; const nc = c.cats.length; const A = c.series[0], B = c.series[1];
    const [, mx] = minMax([...A.values, ...B.values].map(v => v == null ? null : Math.abs(v))); const T = niceTicks(0, mx || 1, 3); const hi = T.hi;
    const midW = Math.min((right - left) * 0.28, Math.max(...c.cats.map(t => tw(t, small))) + pad * 1.2); const cx = (left + right) / 2; const lab0 = c.labels ? Math.max(...[...A.values, ...B.values].filter(v => v != null).map(v => tw(fmt(v, g.dec), small))) + pad * 0.3 : 0;
    const half = (right - left - midW) / 2 - lab0; const L0 = cx - midW / 2, R0 = cx + midW / 2;
    text(L0 - half / 2, top + small * 0.95, A.name || '系列1', { size: small, anchor: 'middle', bold: true }); text(R0 + half / 2, top + small * 0.95, B.name || '系列2', { size: small, anchor: 'middle', bold: true }); top += small * 1.5; bottom -= small * 1.4;
    const bandH = (bottom - top) / nc, bh = bandH * 0.68; const sx = v => Math.abs(v) / hi * half;
    T.ticks.forEach(v => { const lab = fmt(v, decimalsOf([T.step])); for (const x of [L0 - sx(v), R0 + sx(v)]) { if (v) S.push({ t: 'line', x1: x, y1: top, x2: x, y2: bottom, sw: 0.3, dash: '0.6 1.2' }); text(x, bottom + small * 1.15, lab, { size: small, anchor: 'middle' }); } });
    S.push({ t: 'line', x1: L0, y1: top, x2: L0, y2: bottom, sw: 0.6 }, { t: 'line', x1: R0, y1: top, x2: R0, y2: bottom, sw: 0.6 });
    c.cats.forEach((t, j) => { const y = top + j * bandH + (bandH - bh) / 2, cy = y + bh / 2; text(cx, cy + small * 0.36, t, { size: small, anchor: 'middle' });
      const a = A.values[j], b = B.values[j]; if (a != null) { const w = sx(a); S.push({ t: 'rect', x: L0 - w, y, w: Math.max(0.01, w), h: bh, fill: FZ.chartShade(c, 0), sw: 0.5, s: 0, j, hit: true }); if (c.labels) text(L0 - w - pad * 0.3, cy + small * 0.36, fmt(a, g.dec), { size: small, anchor: 'end' }); }
      if (b != null) { const w = sx(b); S.push({ t: 'rect', x: R0, y, w: Math.max(0.01, w), h: bh, fill: FZ.chartShade(c, 1), sw: 0.5, s: 1, j, hit: true }); if (c.labels) text(R0 + w + pad * 0.3, cy + small * 0.36, fmt(b, g.dec), { size: small }); } });
    return S; },
  /* 階段：値が次の項目まで水平に続き、変わる所で縦に上下する（政策金利・税率など） */
  step(c, S, text, g) { const all = c.series.flatMap(s => s.values); const [mn, mx] = minMax(all); const [lo, hi] = valRange(true, mn, mx, c.brk);
    const F = frameV(c, S, text, g, lo, hi, { right: g.endLab ? endRoom(c, g.small, g.pad, g.right - g.left) : 0, room: c.labels ? g.base * 0.7 : 0 });
    c.series.forEach((s, k) => { const L = LINES[k % LINES.length]; let d = '', prev = null; const pts = []; s.values.forEach((v, j) => { if (v == null) { prev = null; return; } const x0 = F.left + j * F.bandW, x1 = x0 + F.bandW, y = F.Y(v);
        d += prev == null ? `M${x0.toFixed(2)} ${y.toFixed(2)}` : `L${x0.toFixed(2)} ${y.toFixed(2)}`; d += `L${x1.toFixed(2)} ${y.toFixed(2)}`; pts.push({ x: (x0 + x1) / 2, y, v, j }); if (c.labels && ns1(c) && (prev == null || prev !== v)) text(x0 + g.pad * 0.2, y - g.small * 0.4, fmt(v, g.dec), { size: g.small * 0.95, halo: true }); prev = v; });
      if (d) S.push({ t: 'path', d, sw: k === 0 ? 1.5 : 1.1, dash: L.dash, s: k, pts, hit: true }); });
    if (g.endLab) endLabels(c, S, text, j => F.left + (j + 1) * F.bandW, F.Y, F.right, g.small, g.pad);
    if (F.lo > 0) breakMark(S, F.left, F.right, F.bottom, F.top, g.base, false); return S; },
  /* 矢印：項目ごとに 1 つ目の系列（○）から 2 つ目（矢じり）へ。前年→今年・目標→実績の変化 */
  arrow(c, S, text, g) { let { left, right, top, bottom, base, small, pad } = g; const nc = c.cats.length; const A = c.series[0], B = c.series[1];
    const hdr = `○ ${A.name || '系列1'} → ▶ ${B.name || '系列2'}`; text((left + right) / 2, top + small * 0.95, hdr, { size: small, anchor: 'middle' }); top += small * 1.6;
    const [mn, mx] = minMax([...A.values, ...B.values]); const span = (mx - mn) || Math.abs(mx) || 1; let lo = mn - span * 0.08, hi = mx + span * 0.08; if (mn >= 0 && mn < span * 0.6) lo = 0; const T = niceTicks(lo, hi, clamp(Math.round((right - left) / (base * 5)), 2, 7)); lo = T.lo; hi = T.hi;
    const catW = Math.min((right - left) * 0.34, Math.max(...c.cats.map(t => tw(t, small))) + pad * 0.6); left += catW; bottom -= small * 1.4; const lab0 = c.labels ? Math.max(...B.values.filter(v => v != null).map(v => tw(fmt(v, g.dec), small))) + pad * 0.4 : 0; left += lab0 * 0.5; right -= lab0 * 0.5;
    const Xv = v => left + (v - lo) / (hi - lo) * (right - left), bandH = (bottom - top) / nc; const tdec = decimalsOf([T.step]);
    T.ticks.forEach(v => { const x = Xv(v); S.push({ t: 'line', x1: x, y1: top, x2: x, y2: bottom, sw: 0.3, dash: '0.6 1.2' }); text(x, bottom + small * 1.15, fmt(v, tdec), { size: small, anchor: 'middle' }); });
    c.cats.forEach((t, j) => { const cy = top + (j + 0.5) * bandH; const ls = wrapLabel(t, small, catW - pad * 0.6); ls.forEach((l, q) => text(left - lab0 * 0.5 - pad * 0.5, cy + small * 0.36 + (q - (ls.length - 1) / 2) * small * 1.1, l, { size: small, anchor: 'end' }));
      const a = A.values[j], b = B.values[j]; if (a == null || b == null) return; const xa = Xv(a), xb = Xv(b), hd = base * 0.8, dir = xb >= xa ? 1 : -1; if (Math.abs(xb - xa) > base * 0.5) { S.push({ t: 'line', x1: xa, y1: cy, x2: xb - dir * hd * 0.8, y2: cy, sw: 1.3, s: 1, j }); S.push({ t: 'poly', pts: [[xb, cy], [xb - dir * hd, cy - hd * 0.45], [xb - dir * hd, cy + hd * 0.45]], fill: 'dark', sw: 0, s: 1, j, hit: true }); }
      S.push({ t: 'mark', x: xa, y: cy, mk: 'circle', fill: false, size: base * 0.4, s: 0, j, hit: true }); if (Math.abs(xb - xa) <= base * 0.5) S.push({ t: 'mark', x: xb, y: cy, mk: 'circle', fill: true, size: base * 0.4, s: 1, j, hit: true });
      if (c.labels) { const r = b >= a; text(r ? xb + pad * 0.5 : xb - pad * 0.5, cy + small * 0.36, fmt(b, g.dec), { size: small, anchor: r ? 'start' : 'end', bold: true }); } });
    return S; } };
const ns1 = c => c.series.length <= 2;

/* SVG（ページの座標 X, Y に幅 W・高さ H）。F：文様の id → 塗り（url(#…)）。cls：字の書体のクラス */
const n2 = v => String(Math.round(v * 100) / 100);
const escX = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
FZ.chartSvg = function (c, X, Y, W, H, o = {}) {
  const F = o.F || {}; const fill = id => id === 'none' ? '#fff' : (F[id] || '#000'); const out = []; let polyN = 0; const shapes = FZ.chartShapes(c, W, H, o.fs || 10.5); const cls = o.cls || 'fgr', bcls = o.bcls || 'fg';
  const markPath = (m) => { const s = m.size; if (m.mk === 'square') return `<rect x="${n2(m.x - s)}" y="${n2(m.y - s)}" width="${n2(2 * s)}" height="${n2(2 * s)}"`; if (m.mk === 'tri') return `<polygon points="${n2(m.x)},${n2(m.y - s * 1.15)} ${n2(m.x + s * 1.1)},${n2(m.y + s * 0.8)} ${n2(m.x - s * 1.1)},${n2(m.y + s * 0.8)}"`; return `<circle cx="${n2(m.x)}" cy="${n2(m.y)}" r="${n2(s)}"`; };
  for (const s of shapes) {
    if (s.t === 'rect') out.push(`<rect x="${n2(s.x)}" y="${n2(s.y)}" width="${n2(s.w)}" height="${n2(s.h)}" fill="${fill(s.fill)}"/><rect x="${n2(s.x)}" y="${n2(s.y)}" width="${n2(s.w)}" height="${n2(s.h)}" fill="none" stroke="#000" stroke-width="${s.sw}"/>`); // 網（印刷では画像に置き換わる）と枠を分ける
    else if (s.t === 'line') out.push(`<line x1="${n2(s.x1)}" y1="${n2(s.y1)}" x2="${n2(s.x2)}" y2="${n2(s.y2)}" stroke="#000" stroke-width="${s.sw}"${s.dash ? ` stroke-dasharray="${s.dash}"` : ''}/>`);
    else if (s.t === 'path') out.push(`<path d="${s.d}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"${s.dash ? ` stroke-dasharray="${s.dash}"` : ''}/>`);
    else if (s.t === 'poly') { const d = 'M' + s.pts.map(p => n2(p[0]) + ' ' + n2(p[1])).join('L') + 'Z'; const st = s.sw ? ` stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"` : '';
      if (s.white || s.fill === 'none' || s.fill === 'dark' || !F[s.fill]) out.push(`<path d="${d}" fill="${s.white ? '#fff' : fill(s.fill)}"${st || ' stroke="none"'}/>`);
      else { const xs = s.pts.map(p => p[0]), ys = s.pts.map(p => p[1]); const x0 = Math.min(...xs), y0 = Math.min(...ys); const cid = (o.uid || 'ch') + '_p' + (polyN++); out.push(`<clipPath id="${cid}"><path d="${d}"/></clipPath><rect x="${n2(x0 - 1)}" y="${n2(y0 - 1)}" width="${n2(Math.max(...xs) - x0 + 2)}" height="${n2(Math.max(...ys) - y0 + 2)}" fill="${fill(s.fill)}" clip-path="url(#${cid})"/>${st ? `<path d="${d}" fill="none"${st}/>` : ''}`); } } /* 網の面は矩形を切り抜く（印刷で網を画像にするのは矩形だけ） */
    else if (s.t === 'mark') out.push(markPath(s) + ` fill="${s.fill ? '#000' : '#fff'}" stroke="#000" stroke-width="0.6"/>`);
    else if (s.t === 'circle') out.push(`<circle cx="${n2(s.cx)}" cy="${n2(s.cy)}" r="${n2(s.r)}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-dasharray="2 1.5"/>`);
    else if (s.t === 'wedge') { const full = s.a1 - s.a0 >= Math.PI * 2 - 1e-6; const p0x = s.cx + Math.cos(s.a0) * s.r, p0y = s.cy + Math.sin(s.a0) * s.r, p1x = s.cx + Math.cos(s.a1) * s.r, p1y = s.cy + Math.sin(s.a1) * s.r; const lg = s.a1 - s.a0 > Math.PI ? 1 : 0; const ri = s.ri || 0;
      const d = ri ? (full ? `M${n2(s.cx - s.r)} ${n2(s.cy)}a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(2 * s.r)} 0a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(-2 * s.r)} 0ZM${n2(s.cx - ri)} ${n2(s.cy)}a${n2(ri)} ${n2(ri)} 0 1 1 ${n2(2 * ri)} 0a${n2(ri)} ${n2(ri)} 0 1 1 ${n2(-2 * ri)} 0Z` : `M${n2(s.cx + Math.cos(s.a0) * ri)} ${n2(s.cy + Math.sin(s.a0) * ri)}L${n2(p0x)} ${n2(p0y)}A${n2(s.r)} ${n2(s.r)} 0 ${lg} 1 ${n2(p1x)} ${n2(p1y)}L${n2(s.cx + Math.cos(s.a1) * ri)} ${n2(s.cy + Math.sin(s.a1) * ri)}A${n2(ri)} ${n2(ri)} 0 ${lg} 0 ${n2(s.cx + Math.cos(s.a0) * ri)} ${n2(s.cy + Math.sin(s.a0) * ri)}Z`) : full ? `M${n2(s.cx - s.r)} ${n2(s.cy)}a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(2 * s.r)} 0a${n2(s.r)} ${n2(s.r)} 0 1 0 ${n2(-2 * s.r)} 0Z` : `M${n2(s.cx)} ${n2(s.cy)}L${n2(p0x)} ${n2(p0y)}A${n2(s.r)} ${n2(s.r)} 0 ${lg} 1 ${n2(p1x)} ${n2(p1y)}Z`;
      if (s.fill === 'none' || !F[s.fill]) out.push(`<path d="${d}" fill="${fill(s.fill)}" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"/>`);
      else { const cid = (o.uid || 'ch') + '_w' + s.j; out.push(`<clipPath id="${cid}"><path d="${d}"/></clipPath><rect x="${n2(s.cx - s.r - 1)}" y="${n2(s.cy - s.r - 1)}" width="${n2(2 * s.r + 2)}" height="${n2(2 * s.r + 2)}" fill="${fill(s.fill)}" clip-path="url(#${cid})"/><path d="${d}" fill="none" stroke="#000" stroke-width="${s.sw}" stroke-linejoin="round"/>`); } } /* 網の切れは矩形を扇で切り抜く（印刷で網を画像にするのは矩形だけ） */
    else if (s.t === 'text') out.push(`<text class="${s.bold ? bcls : cls}" x="${n2(s.x)}" y="${n2(s.y)}" font-size="${n2(s.size)}"${s.anchor !== 'start' ? ` text-anchor="${s.anchor}"` : ''} fill="${s.white ? '#fff' : '#000'}"${s.halo ? ' stroke="#fff" stroke-width="' + n2(s.size * 0.28) + '" paint-order="stroke" stroke-linejoin="round"' : ''}>${escX(s.text)}</text>`);
  }
  if (o.frame !== false) out.push(`<rect class="chframe" x="0.25" y="0.25" width="${n2(Math.max(0, W - 0.5))}" height="${n2(Math.max(0, H - 0.5))}" fill="none" stroke="#000" stroke-width="0.5"/>`); /* 1.0.11a：グラフに細い枠 */
  return `<g class="chart" transform="translate(${n2(X)} ${n2(Y)})">${out.join('')}</g>`;
};
/* 1.0.11f Word・PowerPoint へ図形の組で渡す（Excel のグラフに無い形：滝・段々の折れ線・左右の棒・階段・矢印）。
   画面と同じ図形の一覧（chartShapes）を DrawingML の図形にする。o = { host: 'p'（PowerPoint）|'w'（Word）, id: () => 次の id, font: { latin, ea }, wfonts: Word の rFonts }。座標は pt（グループの中、左上が 0,0） */
const EMUc = v => Math.round(v * 12700);
const fillDml = id => id === 'none' ? '<a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>' : id === 'dark' ? '<a:solidFill><a:srgbClr val="000000"/></a:solidFill>' : `<a:pattFill prst="${(FZ.SHADE_BY[id] || {}).ppt || 'pct30'}"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>`;
const dashDml = d => { if (!d) return ''; const a = String(d).split(/\s+/).map(Number); return `<a:prstDash val="${a[0] < 1.2 ? 'sysDot' : a.length >= 4 ? 'dashDot' : a[0] <= 2 ? 'sysDash' : 'dash'}"/>`; };
const lnDml = (sw, dash) => sw ? `<a:ln w="${EMUc(sw)}" cap="rnd"><a:solidFill><a:srgbClr val="000000"/></a:solidFill>${dashDml(dash)}<a:round/></a:ln>` : '<a:ln><a:noFill/></a:ln>';
FZ.chartDml = function (c, W, H, fs, o = {}) {
  const P = o.host === 'w' ? 'wps' : 'p'; const out = []; const nm = t => (o.host === 'w' ? '' : '') + t;
  const xf = (x, y, w, h, flip = '') => `<a:xfrm${flip}><a:off x="${EMUc(x)}" y="${EMUc(y)}"/><a:ext cx="${Math.max(1, EMUc(w))}" cy="${Math.max(1, EMUc(h))}"/></a:xfrm>`;
  const sp = (name, geom, txt) => { const id = o.id ? o.id() : out.length + 2; if (P === 'p') return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${xe(name)}"/><p:cNvSpPr${txt ? ' txBox="1"' : ''}/><p:nvPr/></p:nvSpPr><p:spPr>${geom}</p:spPr>${txt || ''}</p:sp>`;
    return `<wps:wsp><wps:cNvPr id="${id}" name="${xe(name)}"/><wps:cNvSpPr${txt ? ' txBox="1"' : ''}/><wps:spPr>${geom}</wps:spPr>${txt || '<wps:bodyPr/>'}</wps:wsp>`; };
  const prst = (g, x, y, w, h, fill, ln, flip = '', av = '') => xf(x, y, w, h, flip) + `<a:prstGeom prst="${g}"><a:avLst>${av}</a:avLst></a:prstGeom>` + fill + ln;
  const cust = (subs, closed, fill, ln) => { const xs = subs.flat().map(p => p[0]), ys = subs.flat().map(p => p[1]); const x0 = Math.min(...xs), y0 = Math.min(...ys), w = Math.max(0.01, Math.max(...xs) - x0), h = Math.max(0.01, Math.max(...ys) - y0); const E = v => Math.round(v * 12700);
    const path = subs.map(pts => `<a:moveTo><a:pt x="${E(pts[0][0] - x0)}" y="${E(pts[0][1] - y0)}"/></a:moveTo>${pts.slice(1).map(p => `<a:lnTo><a:pt x="${E(p[0] - x0)}" y="${E(p[1] - y0)}"/></a:lnTo>`).join('')}${closed ? '<a:close/>' : ''}`).join('');
    return xf(x0, y0, w, h) + `<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/><a:pathLst><a:path w="${Math.max(1, E(w))}" h="${Math.max(1, E(h))}"${closed ? '' : ' fill="none"'}>${path}</a:path></a:pathLst></a:custGeom>` + fill + ln; };
  const parseD = d => { const subs = []; const re = /([ML])\s*(-?[\d.]+)[ ,]+(-?[\d.]+)/g; let m; while ((m = re.exec(d))) { if (m[1] === 'M' || !subs.length) subs.push([]); subs[subs.length - 1].push([+m[2], +m[3]]); } return subs.filter(p => p.length > 1); };
  const textSp = t => { const w = tw(t.text, t.size) * 1.25 + 3, h = t.size * 1.4, cy = t.y - t.size * 0.36; const x = t.anchor === 'middle' ? t.x - w / 2 : t.anchor === 'end' ? t.x - w + 1 : t.x - 1; const al = t.anchor === 'middle' ? 'ctr' : t.anchor === 'end' ? 'r' : 'l';
    const geom = xf(x, cy - h / 2, w, h) + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln>'; const col = t.white ? 'FFFFFF' : '000000';
    if (P === 'p') { const f = o.font || {}; return sp('字', geom, `<p:txBody><a:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></a:bodyPr><a:lstStyle/><a:p><a:pPr algn="${al}"/><a:r><a:rPr lang="ja-JP" sz="${Math.round(t.size * 100)}" b="${t.bold ? 1 : 0}" dirty="0"><a:solidFill><a:srgbClr val="${col}"/></a:solidFill><a:latin typeface="${xe(f.latin || 'Yu Gothic')}"/><a:ea typeface="${xe(f.ea || f.latin || 'Yu Gothic')}"/></a:rPr><a:t>${xe(t.text)}</a:t></a:r></a:p></p:txBody>`); }
    const hs = Math.max(2, Math.round(t.size * 2)); return sp('字', geom, `<wps:txbx><w:txbxContent><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="${al === 'ctr' ? 'center' : al === 'r' ? 'right' : 'left'}"/></w:pPr><w:r><w:rPr>${o.wfonts || ''}${t.bold ? '<w:b/><w:bCs/>' : ''}<w:color w:val="${col}"/><w:sz w:val="${hs}"/><w:szCs w:val="${hs}"/></w:rPr><w:t xml:space="preserve">${xe(t.text)}</w:t></w:r></w:p></w:txbxContent></wps:txbx><wps:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></wps:bodyPr>`); };
  out.push(sp('地', prst('rect', 0, 0, W, H, '<a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>', '<a:ln><a:noFill/></a:ln>')));
  for (const s of FZ.chartShapes(c, W, H, fs)) {
    if (s.t === 'rect') out.push(sp('棒', prst('rect', s.x, s.y, s.w, s.h, fillDml(s.fill), lnDml(s.sw))));
    else if (s.t === 'line') { const fh = s.x2 < s.x1, fv = s.y2 < s.y1; out.push(sp('線', prst('line', Math.min(s.x1, s.x2), Math.min(s.y1, s.y2), Math.abs(s.x2 - s.x1), Math.abs(s.y2 - s.y1), '<a:noFill/>', lnDml(s.sw, s.dash), `${fh ? ' flipH="1"' : ''}${fv ? ' flipV="1"' : ''}`))); }
    else if (s.t === 'path') { const subs = parseD(s.d); if (subs.length) out.push(sp('折れ線', cust(subs, false, '<a:noFill/>', lnDml(s.sw, s.dash)))); }
    else if (s.t === 'poly') out.push(sp('面', cust([s.pts], true, s.white ? '<a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>' : fillDml(s.fill), lnDml(s.sw))));
    else if (s.t === 'mark') { const z = s.size; out.push(sp('印', prst(s.mk === 'square' ? 'rect' : s.mk === 'tri' ? 'triangle' : 'ellipse', s.x - z, s.y - z, 2 * z, 2 * z, s.fill ? fillDml('dark') : fillDml('none'), lnDml(0.6)))); }
    else if (s.t === 'circle') out.push(sp('円', prst('ellipse', s.cx - s.r, s.cy - s.r, 2 * s.r, 2 * s.r, '<a:noFill/>', lnDml(s.sw, '2 1.5'))));
    else if (s.t === 'wedge') { const full = s.a1 - s.a0 >= Math.PI * 2 - 1e-6, ri = s.ri || 0;
      if (full) { out.push(sp('円', ri ? prst('donut', s.cx - s.r, s.cy - s.r, 2 * s.r, 2 * s.r, fillDml(s.fill), lnDml(s.sw), '', `<a:gd name="adj" fmla="val ${Math.round((s.r - ri) / (2 * s.r) * 100000)}"/>`) : prst('ellipse', s.cx - s.r, s.cy - s.r, 2 * s.r, 2 * s.r, fillDml(s.fill), lnDml(s.sw)))); continue; }
      const n = Math.max(2, Math.ceil((s.a1 - s.a0) / (Math.PI / 60))); const arc = (r, rev) => Array.from({ length: n + 1 }, (_, k) => { const a = rev ? s.a1 - (s.a1 - s.a0) * k / n : s.a0 + (s.a1 - s.a0) * k / n; return [s.cx + Math.cos(a) * r, s.cy + Math.sin(a) * r]; });
      out.push(sp('扇', cust([[...arc(s.r, false), ...(ri ? arc(ri, true) : [[s.cx, s.cy]])]], true, fillDml(s.fill), lnDml(s.sw)))); }
    else if (s.t === 'text') out.push(textSp(s));
  }
  out.push(sp('枠', prst('rect', 0.25, 0.25, Math.max(0, W - 0.5), Math.max(0, H - 0.5), '<a:noFill/>', lnDml(0.5))));
  return out.join('');
};
/* 当たり判定：グラフの中の点 (x, y)（pt、グラフの左上が原点）→ { s: 系列, j: 項目 }（円の切れは j だけ意味がある） */
FZ.chartHit = function (c, W, H, fs, x, y) {
  const shapes = FZ.chartShapes(c, W, H, fs); let best = null;
  for (let q = shapes.length - 1; q >= 0; q--) { const s = shapes[q]; if (!s.hit && !s.leg) continue;
    if (s.t === 'rect' && x >= s.x - 1 && x <= s.x + s.w + 1 && y >= s.y - 1 && y <= s.y + s.h + 1) return { s: s.s ?? null, j: s.j ?? null };
    if (s.t === 'mark' && Math.hypot(x - s.x, y - s.y) <= s.size + 2.5) return { s: s.s, j: s.j };
    if (s.t === 'wedge') { const dx = x - s.cx, dy = y - s.cy; const dd = Math.hypot(dx, dy); if (dd > s.r + 1 || dd < (s.ri || 0) - 1) continue; let a = Math.atan2(dy, dx); while (a < s.a0) a += Math.PI * 2; if (a <= s.a1) return { s: 0, j: s.j }; }
    if (s.t === 'poly' && s.hit) { let inside = false; const P = s.pts; for (let a = 0, b = P.length - 1; a < P.length; b = a++) if ((P[a][1] > y) !== (P[b][1] > y) && x < (P[b][0] - P[a][0]) * (y - P[a][1]) / (P[b][1] - P[a][1]) + P[a][0]) inside = !inside; if (inside) return { s: s.s ?? null, j: s.j ?? null }; }
    if (s.t === 'path' && s.pts) for (let k = 1; k < s.pts.length; k++) { const A = s.pts[k - 1], B = s.pts[k]; const vx = B.x - A.x, vy = B.y - A.y; const t = clamp(((x - A.x) * vx + (y - A.y) * vy) / (vx * vx + vy * vy || 1), 0, 1); const d = Math.hypot(A.x + vx * t - x, A.y + vy * t - y); if (d < 2.5 && (!best || d < best.d)) best = { s: s.s, j: null, d }; }
  }
  return best ? { s: best.s, j: null } : null;
};
/* 系列 k の図形の外枠（選んだ系列を画面で示す）：[{ x, y, w, h }]（pt） */
FZ.chartSeriesBoxes = function (c, W, H, fs, k, j) {
  const out = []; for (const s of FZ.chartShapes(c, W, H, fs)) { if (s.leg) continue;
    if (c.type === 'pie' || c.type === 'donut') { if (s.t === 'wedge' && s.j === j) out.push({ x: s.cx - s.r, y: s.cy - s.r, w: 2 * s.r, h: 2 * s.r }); continue; }
    if (s.s !== k) continue; if (s.t === 'rect') out.push({ x: s.x, y: s.y, w: s.w, h: s.h }); else if (s.t === 'poly' && s.hit) { const xs = s.pts.map(p => p[0]), ys = s.pts.map(p => p[1]); out.push({ x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) }); } else if (s.t === 'mark') out.push({ x: s.x - s.size, y: s.y - s.size, w: s.size * 2, h: s.size * 2 }); }
  return out;
};

/* ---------- PowerPoint・Word：編集できるグラフ（c:chartSpace）と埋め込みの Excel ---------- */
const colName = k => { let s = ''; k++; while (k > 0) { const m = (k - 1) % 26; s = String.fromCharCode(65 + m) + s; k = Math.floor((k - 1) / 26); } return s; };
const xe = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
/* 書き出す値：帯は構成比（0〜1）にする（Office の 100% 積み上げの値ラベルは元の値を出すため） */
function exportValues(c) {
  if (c.type !== 'band') return c.series.map(s => s.values);
  const tot = c.cats.map((_, j) => c.series.reduce((t, s) => t + Math.max(0, s.values[j] || 0), 0)); return c.series.map(s => s.values.map((v, j) => v == null ? null : tot[j] ? Math.max(0, v) / tot[j] : 0));
}
FZ.chartXlsx = function (c) {
  const V = exportValues(c); const pct = c.type === 'band'; const rows = [];
  const cellS = (r, k, t) => `<c r="${colName(k)}${r}" t="inlineStr"><is><t xml:space="preserve">${xe(t)}</t></is></c>`, cellN = (r, k, v) => `<c r="${colName(k)}${r}"${pct ? ' s="1"' : ''}><v>${v}</v></c>`;
  rows.push(`<row r="1">${cellS(1, 0, c.corner)}${c.series.map((s, k) => cellS(1, k + 1, s.name || '系列' + (k + 1))).join('')}</row>`);
  c.cats.forEach((cat, j) => rows.push(`<row r="${j + 2}">${cellS(j + 2, 0, cat)}${c.series.map((s, k) => V[k][j] == null ? '' : cellN(j + 2, k + 1, V[k][j])).join('')}</row>`));
  const NSM = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', NSR = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', H = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  const files = [
    { name: '[Content_Types].xml', data: `${H}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>` },
    { name: '_rels/.rels', data: `${H}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${NSR}/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: 'xl/workbook.xml', data: `${H}<workbook xmlns="${NSM}" xmlns:r="${NSR}"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>` },
    { name: 'xl/_rels/workbook.xml.rels', data: `${H}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${NSR}/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="${NSR}/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: `${H}<styleSheet xmlns="${NSM}"><fonts count="1"><font><sz val="11"/><name val="Yu Gothic"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="9" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>` },
    { name: 'xl/worksheets/sheet1.xml', data: `${H}<worksheet xmlns="${NSM}"><sheetData>${rows.join('')}</sheetData></worksheet>` },
  ];
  return FZ.zip(files);
};
/* o = { latin, ea, sz（1/100 pt）, ext: 埋め込みの Excel の関係 ID } */
FZ.chartXml = function (c, o = {}) {
  const sz = o.sz || 900; const font = `<a:latin typeface="${xe(o.latin || 'Yu Gothic')}"/><a:ea typeface="${xe(o.ea || o.latin || 'Yu Gothic')}"/>`;
  const txPr = (size = sz, white = false, bold = false) => `<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${size}" b="${bold ? 1 : 0}"><a:solidFill><a:srgbClr val="${white ? 'FFFFFF' : '000000'}"/></a:solidFill>${font}</a:defRPr></a:pPr><a:endParaRPr lang="ja-JP"/></a:p></c:txPr>`;
  const solid = hex => `<a:solidFill><a:srgbClr val="${hex}"/></a:solidFill>`; const ln = (w = 6350, dash) => `<a:ln w="${w}">${solid('000000')}${dash && dash !== 'solid' ? `<a:prstDash val="${dash}"/>` : ''}</a:ln>`;
  const fillX = id => id === 'none' ? solid('FFFFFF') : id === 'dark' ? solid('000000') : `<a:pattFill prst="${(FZ.SHADE_BY[id] || {}).ppt || 'pct30'}"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>`;
  const V = exportValues(c); const dec = c.dec != null ? c.dec : decimalsOf(c.series.flatMap(s => s.values)); const g0 = c.sep === false ? '0' : '#,##0'; const numCode = c.type === 'band' ? '0%' : dec ? g0 + '.' + '0'.repeat(dec) : g0;
  const nC = c.cats.length; const catRef = `Sheet1!$A$2:$A$${nC + 1}`;
  const strCache = arr => `<c:strCache><c:ptCount val="${arr.length}"/>${arr.map((t, i) => `<c:pt idx="${i}"><c:v>${xe(t)}</c:v></c:pt>`).join('')}</c:strCache>`;
  const numCache = arr => `<c:numCache><c:formatCode>${c.type === 'band' ? '0%' : 'General'}</c:formatCode><c:ptCount val="${arr.length}"/>${arr.map((v, i) => v == null ? '' : `<c:pt idx="${i}"><c:v>${v}</c:v></c:pt>`).join('')}</c:numCache>`;
  const legK = (c.legend === 'auto' || c.legend === 'end') ? (c.type === 'pie' || c.type === 'donut' ? 'none' : c.series.length > 1 ? 'bottom' : 'none') : c.legend;
  const codeOf = vals => { const d = c.dec != null ? c.dec : decimalsOf(vals); return d ? g0 + '.' + '0'.repeat(d) : g0; };
  const dl = (pos, white, extra = '', code = numCode) => c.labels ? `<c:dLbls><c:numFmt formatCode="${extra === 'pie' ? '0%' : code}" sourceLinked="0"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>${txPr(sz, white)}${pos ? `<c:dLblPos val="${pos}"/>` : ''}<c:showLegendKey val="0"/><c:showVal val="${extra === 'pie' ? 0 : 1}"/><c:showCatName val="${extra === 'pie' && legK === 'none' ? 1 : 0}"/><c:showSerName val="0"/><c:showPercent val="${extra === 'pie' ? 1 : 0}"/><c:showBubbleSize val="0"/>${extra === 'pie' ? `<c:separator>${legK === 'none' ? '\n' : ' '}</c:separator><c:showLeaderLines val="1"/>` : ''}</c:dLbls>` : '';
  const serHead = k => `<c:idx val="${k}"/><c:order val="${k}"/><c:tx><c:strRef><c:f>Sheet1!$${colName(k + 1)}$1</c:f>${strCache([c.series[k].name || '系列' + (k + 1)])}</c:strRef></c:tx>`;
  const catVal = k => `<c:cat><c:strRef><c:f>${catRef}</c:f>${strCache(c.cats)}</c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$${colName(k + 1)}$2:$${colName(k + 1)}$${nC + 1}</c:f>${numCache(V[k])}</c:numRef></c:val>`;
  const AX1 = 50010001, AX2 = 50010002; let plot = '', axes = '';
  const lineSerX = (k, q) => { const L = LINES[q % LINES.length]; return `<c:ser>${serHead(k)}<c:spPr><a:ln w="${q === 0 ? 19050 : 15875}" cap="rnd">${solid('000000')}${L.ppt !== 'solid' ? `<a:prstDash val="${L.ppt}"/>` : ''}<a:round/></a:ln></c:spPr><c:marker><c:symbol val="${L.mk === 'tri' ? 'triangle' : L.mk}"/><c:size val="6"/><c:spPr>${solid(L.fill ? '000000' : 'FFFFFF')}${ln(9525)}</c:spPr></c:marker>${c.series.length <= 3 ? dl(q % 2 ? 'b' : 't', false, '', c.type === 'combo' ? codeOf(c.series[k].values) : numCode) : ''}${catVal(k)}<c:smooth val="0"/></c:ser>`; };
  const horiz = c.type === 'barh' || c.type === 'band';
  const [U1, U2] = String(c.unit || '').split('|'); const utitle = u => u ? `<c:title><c:tx><c:rich><a:bodyPr rot="0" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${sz}" b="0">${font}</a:defRPr></a:pPr><a:r><a:rPr lang="ja-JP" sz="${sz}" b="0">${font}</a:rPr><a:t>（${xe(u)}）</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>` : '';
  const unitTitle = c.type === 'combo' ? utitle(U1) : c.unit && c.type !== 'pie' && c.type !== 'band' && c.type !== 'donut' ? `<c:title><c:tx><c:rich><a:bodyPr rot="0" vert="horz"/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${sz}" b="0">${font}</a:defRPr></a:pPr><a:r><a:rPr lang="ja-JP" sz="${sz}" b="0">${font}</a:rPr><a:t>（${xe(c.unit)}）</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>` : '';
  const catAx = `<c:catAx><c:axId val="${AX1}"/><c:scaling><c:orientation val="${horiz ? 'maxMin' : 'minMax'}"/></c:scaling><c:delete val="0"/><c:axPos val="${horiz ? 'l' : 'b'}"/><c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="low"/><c:spPr><a:noFill/>${ln(9525)}</c:spPr>${txPr()}<c:crossAx val="${AX2}"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>`;
  const valAx = `<c:valAx><c:axId val="${AX2}"/><c:scaling><c:orientation val="minMax"/>${c.type === 'band' ? '<c:max val="1"/><c:min val="0"/>' : ''}</c:scaling><c:delete val="${c.type === 'band' ? 1 : 0}"/><c:axPos val="${horiz ? 'b' : 'l'}"/><c:majorGridlines><c:spPr><a:ln w="3175">${solid('808080')}<a:prstDash val="sysDot"/></a:ln></c:spPr></c:majorGridlines>${unitTitle}<c:numFmt formatCode="${c.type === 'band' ? '0%' : g0}" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>${txPr()}<c:crossAx val="${AX1}"/><c:crosses val="${horiz ? 'max' : 'autoZero'}"/><c:crossBetween val="between"/></c:valAx>`;
  if (c.type === 'bar' || c.type === 'barh' || c.type === 'stack' || c.type === 'band') {
    const grouping = c.type === 'stack' ? 'stacked' : c.type === 'band' ? 'percentStacked' : 'clustered'; const stacked = grouping !== 'clustered';
    const sers = c.series.map((s, k) => { const sh = FZ.chartShade(c, k); return `<c:ser>${serHead(k)}<c:spPr>${fillX(sh)}${ln(6350)}</c:spPr><c:invertIfNegative val="0"/>${dl(stacked ? 'ctr' : 'outEnd', stacked && DARK.has(sh))}${catVal(k)}</c:ser>`; }).join('');
    plot = `<c:barChart><c:barDir val="${horiz ? 'bar' : 'col'}"/><c:grouping val="${grouping}"/><c:varyColors val="0"/>${sers}<c:gapWidth val="${stacked ? 80 : c.series.length > 1 ? 40 : 70}"/>${stacked ? '<c:overlap val="100"/>' : ''}<c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:barChart>`; axes = catAx + valAx;
  } else if (c.type === 'line') {
    const sers = c.series.map((s, k) => lineSerX(k, k)).join('');
    plot = `<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${sers}<c:marker val="1"/><c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:lineChart>`; axes = catAx + valAx;
  } else if (c.type === 'area') {
    const sers = c.series.map((s, k) => `<c:ser>${serHead(k)}<c:spPr>${fillX(FZ.chartShade(c, k))}${ln(6350)}</c:spPr>${catVal(k)}</c:ser>`).join('');
    plot = `<c:areaChart><c:grouping val="stacked"/><c:varyColors val="0"/>${sers}<c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:areaChart>`; axes = catAx + valAx;
  } else if (c.type === 'combo') { /* 棒（左の軸）と折れ線（右の軸）。棒は下の半分に（画面と同じく左の軸の上限を伸ばす） */
    const AX3 = 50010003, AX4 = 50010004; const b0 = c.series[0].values.filter(v => v != null); const hi1 = niceTicks(Math.min(0, ...b0, 0), Math.max(0, ...b0, 0) * (c.series.length > 1 ? 1.9 : 1), 5).hi;
    const bar = `<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/><c:ser>${serHead(0)}<c:spPr>${fillX(FZ.chartShade(c, 0))}${ln(6350)}</c:spPr><c:invertIfNegative val="0"/>${dl('outEnd', false, '', codeOf(c.series[0].values))}${catVal(0)}</c:ser><c:gapWidth val="80"/><c:axId val="${AX1}"/><c:axId val="${AX2}"/></c:barChart>`;
    const lines = c.series.slice(1).map((s, q) => lineSerX(q + 1, q)).join('');
    const catAx2 = `<c:catAx><c:axId val="${AX3}"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="1"/><c:axPos val="b"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="${AX4}"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>`;
    const valAx2 = `<c:valAx><c:axId val="${AX4}"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="r"/>${utitle(U2)}<c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="none"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>${txPr()}<c:crossAx val="${AX3}"/><c:crosses val="max"/><c:crossBetween val="between"/></c:valAx>`;
    plot = bar + (lines ? `<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>${lines}<c:marker val="1"/><c:axId val="${AX3}"/><c:axId val="${AX4}"/></c:lineChart>` : ''); axes = catAx + valAx.replace('<c:orientation val="minMax"/>', `<c:orientation val="minMax"/>${lines ? `<c:max val="${hi1}"/>` : ''}`) + (lines ? catAx2 + valAx2 : '');
  } else if (c.type === 'donut') { /* ドーナツ：合計は題に（Office のグラフは真ん中に字を置けない） */
    const dpts = c.cats.map((_, j) => `<c:dPt><c:idx val="${j}"/><c:bubble3D val="0"/><c:spPr>${fillX(sliceShade(j))}${ln(7620)}</c:spPr></c:dPt>`).join('');
    plot = `<c:doughnutChart><c:varyColors val="1"/><c:ser>${serHead(0)}${dpts}${dl('', false, 'pie')}${catVal(0)}</c:ser><c:firstSliceAng val="0"/><c:holeSize val="56"/></c:doughnutChart>`;
  } else { // 円
    const dpts = c.cats.map((_, j) => `<c:dPt><c:idx val="${j}"/><c:bubble3D val="0"/><c:spPr>${fillX(sliceShade(j))}${ln(7620)}</c:spPr></c:dPt>`).join('');
    plot = `<c:pieChart><c:varyColors val="1"/><c:ser>${serHead(0)}${dpts}${dl('bestFit', false, 'pie')}${catVal(0)}</c:ser><c:firstSliceAng val="0"/></c:pieChart>`;
  }
  const totD = c.series[0].values.reduce((t, v) => t + Math.max(0, v || 0), 0); const donutTitle = `<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="${sz}" b="1">${font}</a:defRPr></a:pPr><a:r><a:rPr lang="ja-JP" sz="${sz}" b="1">${font}</a:rPr><a:t>${xe((c.series[0].name ? c.series[0].name + ' ' : '合計 ') + fmt(totD, dec) + (c.unit ? ' ' + c.unit : ''))}</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>`;
  const legPos = { bottom: 'b', right: 'r', top: 't' }; const leg = legK;
  const legend = leg !== 'none' ? `<c:legend><c:legendPos val="${legPos[leg]}"/><c:overlay val="0"/>${txPr()}</c:legend>` : '';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="ja-JP"/><c:roundedCorners val="0"/><c:chart>${c.type === 'donut' ? donutTitle + '<c:autoTitleDeleted val="0"/>' : '<c:autoTitleDeleted val="1"/>'}<c:plotArea><c:layout/>${plot}${axes}<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr></c:plotArea>${legend}<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:spPr>${solid('FFFFFF')}<a:ln w="6350">${solid('000000')}</a:ln></c:spPr>${txPr()}${o.ext ? `<c:externalData r:id="${o.ext}"><c:autoUpdate val="0"/></c:externalData>` : ''}</c:chartSpace>`;
};
FZ.CHART_CT = 'application/vnd.openxmlformats-officedocument.drawingml.chart+xml';
FZ.XLSX_CT = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
