/* 文机 — 変換の記録（P18）
 * 書き出し・取り込みで、近似になる所・入らない所を、位置（行）と一緒に並べる。右の欄「変換の記録」で 1 件ずつその行へ飛べる。
 * Word・PowerPoint の書き出しは、文机の書き出しの仕様（はじめに.md「Word・PowerPoint への書き出し」の表）から引いた決まりで調べる。
 * Markdown は実際に読み戻して、行ごとに比べる（推測ではなく結果）。
 * 記録 = { title, items: [{ what, lines: [行の番号…] }] }。lines が空の項目は文書全体のこと */
(function (FZ) {
  'use strict';
  const M = FZ.M;
  const marksOf = ln => ln.segs.flatMap(sg => sg.marks.slice(0, sg.text.length));
  const has = (ln, f) => marksOf(ln).some(m => f(m >>> 0));
  const big = m => ((m & M.SZW) >>> 20) > 1 || ((m & M.SZH) >>> 24) > 1; /* 3 倍以上（m×n 倍角） */
  const isHead = a => a.style === 'num' || a.style === 'sym';
  const ROMAN = /[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫⅰⅱⅲⅳⅴⅵⅶⅷⅸⅹ]/;
  /* 決まり：{ what, test(ln, doc, i) } */
  const PUFU = new WeakMap(); const inPufu = doc => { let S = PUFU.get(doc); if (!S) { S = new Set(); for (const B of (FZ.pufuBlocks ? FZ.pufuBlocks(doc) : [])) for (let q = B.start; q < B.end; q++) S.add(q); PUFU.set(doc, S); } return S; };
  const R = {
    shadow: { test: ln => has(ln, m => m & M.SHADOW) },
    mxn: { test: ln => has(ln, big) },
    wide: { test: ln => has(ln, m => (m & (M.WIDE | M.TALL)) && !big(m)) },
    narrow: { test: ln => has(ln, m => (m & M.NAR) && !(m & M.WIDE) && !big(m)) },
    dot: { test: ln => has(ln, m => m & M.DOT) },
    sht: { test: ln => has(ln, m => (m & M.SHT) >>> 16) },
    shade: { test: ln => has(ln, m => (m & M.SHADE) && !((m & M.SHT) >>> 16)) },
    outline: { test: ln => has(ln, m => m & M.OUTLINE) },
    anyMark: { test: ln => has(ln, m => (m & ~M.LINK) >>> 0) },
    numbered: { test: ln => isHead(ln.attrs) || !!ln.attrs.list },
    symHead: { test: ln => ln.attrs.style === 'sym' },
    roman: { test: (ln, doc) => ln.attrs.style === 'num' && ROMAN.test(String((FZ.normalizeScheme(doc.format.scheme, FZ.DEFAULT_SCHEME) || [])[ln.attrs.level | 0] || '')) },
    cells: { test: ln => !!ln.attrs.cells },
    figs: { test: ln => (ln.attrs.figs || []).length > 0 },
    figure: { test: ln => !!ln.attrs.figure },
    panels: { test: ln => !!ln.attrs.panels },
    pufu: { test: (ln, doc, i) => inPufu(doc).has(i) }, /* 1.0.14a プ譜の行（印の節の子） */
  };
  const RULES = {
    docx: [['shadow', '影文字は Word の「影」に（字の右下の黒い影の形ではない）'], ['mxn', 'm×n 倍角は字の大きさと字幅の比率で近似'], ['sht', '網の文様は Word の網掛けの種類（近い柄）に'], ['outline', '白抜きは Word の輪郭の字に'],
      ['symHead', '記号見出しの記号は字として入る（Word の自動の記号ではない）'], ['roman', 'ローマ数字の番号は半角の I・II に'], ['pufu', 'プ譜は図形のグループ（役の札・字の箱・取組の囲み・矢印の線）として入る。字は箱の中で直せる。項目を足す・段を変える時は文机で直して書き出し直す']],
    pptx: [['numbered', '番号・記号は字として入る（PowerPoint は段の体系を持てない）'], ['dot', '傍点は入らない'], ['wide', '倍角は字の大きさで近似（PowerPoint は字幅の比率を持てない）'], ['mxn', 'm×n 倍角は字の大きさで近似'],
      ['narrow', '長体は字幅を持てないので、元の幅に'], ['shadow', '影文字は外側の影に'], ['shade', '字の網掛けは蛍光ペン（灰色）に'], ['sht', '網の文様は PowerPoint のパターン（近い柄）に'], ['outline', '白抜きは輪郭の字に'], ['pufu', 'プ譜は図形のグループ（役の札・字の箱・取組の囲み・矢印の線）として入る。字は箱の中で直せる。項目を足す・段を変える時は文机で直して書き出し直す']],
    txt: [['anyMark', '字の飾り（太字・下線・網・倍角など）は入らない'], ['numbered', '見出しの番号・箇条書きの記号は入らない（組版が付ける印のため）'], ['cells', '表はセルをタブで区切る（罫・網は入らない）'], ['figs', '画像は入らない（グラフは表の字に）'], ['figure', '図（流れ図）は入らない'], ['pufu', 'プ譜の箱・線は入らない（箇条書きの並びとして入る）']],
  };
  RULES.docxSlide = RULES.pptx.map(([k, w]) => [k, w.replace(/PowerPoint/g, 'Word の図形')]); /* 資料の Word（紙面のまま）は PowerPoint の紙面を Word の図形に置き直す */
  RULES.docxFlow = [...RULES.docx, ['panels', '区画の並び（横・縦・m×n）は流れの順に（紙面の配置は捨てる）']];
  function byRules(doc, rules) { const out = [];
    for (const [k, what] of rules) { const r = R[k]; const lines = []; doc.lines.forEach((ln, i) => { if (r.test(ln, doc, i)) lines.push(i); }); if (lines.length) out.push({ what, lines }); }
    if (/\{pages\}/.test((doc.format.header || '') + (doc.format.footer || '')) && rules === RULES.pptx) out.push({ what: '柱の総頁数（{pages}）は PowerPoint に欄が無いので、頁番号だけ', lines: [] });
    return out; }
  /* Markdown：書き出して読み戻し、行の対ごとに字の飾り・揃え・位置・見出し飾りを比べる。対にならない行は「形が変わる行」 */
  const LOST = [[M.OUTLINE, '白抜き'], [M.WIDE | M.TALL | M.SZW | M.SZH, '倍角'], [M.SHADOW, '影文字'], [M.NAR, '長体'], [M.SHT, '網の文様'], [M.UNDER2 | M.WAVE, '二重下線・波線'], [M.STRIKE2, '二重取消線'], [M.BOLD, '太字']];
  function byMarkdown(doc, opts) { const md = FZ.toGfm(doc, { fz: opts.fz !== false }); const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(doc.format));
    const anchors = doc.lines.map(l => l.attrs.anchor).filter(Boolean), figs = doc.lines.flatMap(l => (l.attrs.figs || []).map(f => f.id));
    const B = FZ.fromGfm(md, base, { refTargets: { anchors, figs } }); const sa = doc.lines.map(l => FZ.lineSig(doc, l)), sb = B.lines.map(l => FZ.lineSig(B, l));
    const SA = [], PA = [], SB = [], PB = []; sa.forEach((x, i) => { if (x !== '|') { SA.push(x); PA.push(i); } }); sb.forEach((x, j) => { if (x !== '|') { SB.push(x); PB.push(j); } });
    const hunks = FZ.diffSigs(SA, SB); const pairs = []; let ai = 0, bj = 0; for (const h of hunks) { while (ai < h.a[0] && bj < h.b[0]) pairs.push([PA[ai++], PB[bj++]]); ai = h.a[1]; bj = h.b[1]; } while (ai < SA.length && bj < SB.length) pairs.push([PA[ai++], PB[bj++]]);
    const bucket = new Map(); const add = (what, i) => { if (!bucket.has(what)) bucket.set(what, []); const L = bucket.get(what); if (!L.includes(i)) L.push(i); };
    for (const [i, j] of pairs) { const a = doc.lines[i], b = B.lines[j]; const ma = marksOf(a), mb = marksOf(b); const n = Math.min(ma.length, mb.length);
      for (const [bit, nm] of LOST) { if (bit === M.BOLD && (isHead(a.attrs) || a.attrs.style === 'title' || a.attrs.cells || a.attrs.deco)) continue; /* 題の太字は組版が付ける */
        for (let k = 0; k < n; k++) if ((ma[k] & bit) && !(mb[k] & bit)) { add(`Markdown に入らない字の飾り：${nm}`, i); break; } }
      if ((a.attrs.align || '') !== (b.attrs.align || '') && a.attrs.style !== 'title' && b.attrs.style !== 'title') add('揃え（中央・右・均等）は Markdown に入らない', i); /* 表題の揃えは種類から */
      if ((a.attrs.indent | 0) !== (b.attrs.indent | 0) && !a.attrs.cells) add('行の位置（字下げ）は Markdown に入らない', i);
      if (a.attrs.deco && a.attrs.deco !== b.attrs.deco) add('見出し飾りは Markdown に入らない', i); }
    for (const h of hunks) for (let k = h.a[0]; k < h.a[1]; k++) add('Markdown で形が変わる行（読み戻すと字・種類が違う）', PA[k]);
    { const P = inPufu(doc); if (P.size) bucket.set('プ譜の印（プ譜・取組・資源と制約）は Markdown に入らない（箇条書きとして入る）', [...P].sort((x, y) => x - y)); }
    const fillLines = new Set(); for (const f of doc.fills || []) if (!(B.fills || []).some(g => g.shade === f.shade)) for (let y = f.from; y <= f.to; y++) fillLines.add(y);
    if (fillLines.size) bucket.set('網掛け（範囲）は Markdown に入らない', [...fillLines].filter(y => y < doc.lines.length).slice(0, 400));
    return [...bucket.entries()].map(([what, lines]) => ({ what, lines: lines.sort((x, y) => x - y) })); }
  const TITLES = { docx: 'Word（.docx）', docxSlide: 'Word（紙面のまま）', docxFlow: 'Word（構成）', pptx: 'PowerPoint（.pptx）', txt: 'テキスト', md: 'Markdown' };
  /* 1.0.15a 写しの見通し（C-12）：字の飾りの項目の説明に、Word・PowerPoint・Markdown・テキストでどうなるかを出す（作る前に知らせる）。印刷・PDF は紙面のまま */
  const CMD_RULE = { shadow: 'shadow', wide: 'wide', tall: 'wide', quad: 'wide', scale: 'mxn', dot: 'dot', shadeType: 'sht', shade: 'shade', outline: 'outline' };
  const MD_LOSE = { outline: 1, wide: 1, tall: 1, quad: 1, scale: 1, shadow: 1, shadeType: 1, under2: 1, wave: 1, strike2: 1 };
  FZ.degradeTip = function (cmd) { const k = CMD_RULE[cmd]; if (!k && !MD_LOSE[cmd]) return ''; const pick = t => { const r = k && RULES[t].find(x => x[0] === k); return r ? r[1] : 'そのまま'; };
    return `Word：${pick('docx')}／PowerPoint：${pick('pptx')}／Markdown：${MD_LOSE[cmd] ? '入らない（文机の原本には残る）' : 'そのまま'}／テキスト：入らない／印刷・PDF：そのまま`; };
  FZ.convAudit = function (doc, target, opts = {}) { const items = target === 'md' ? byMarkdown(doc, opts) : byRules(doc, RULES[target] || []); return { title: (TITLES[target] || target) + 'への書き出し', target, items, time: Date.now() }; };
  FZ.CONV_TITLES = TITLES;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
