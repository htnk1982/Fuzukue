/* 文机（Fuzukue）コア：文書モデル・組版・原本形式
 * 依存なし。ブラウザ／Node 両用（globalThis.FZ に登録）。
 * 文書は「行（論理行）の列」。版面は文字数×行数のグリッド。文字は流れ、罫線は行に付随する。 */
(function (FZ) {
'use strict';

/* ---------- 文字修飾ビット ---------- */
FZ.VERSION = '1.0.16h-alpha';
const M = { BOLD: 1, UNDER: 2, DOT: 4, SHADE: 8, OUTLINE: 16, STRIKE: 32, WIDE: 64, TALL: 128, LINK: 256, UNDER2: 512, WAVE: 1024, STRIKE2: 2048, CODE: 4096, SHADOW: 8192, SHT: 0xF << 16, SZW: 0xF << 20, SZH: 0xF << 24, NAR: 0x3 << 28 }; // SHADOW：影文字。SHT：網掛けの文様（0＝既定の文字の網）。SZW・SZH：m×n 倍角の倍率−1（2 倍までは WIDE・TALL で表す） // CODE：文中のコード（意味。Markdown の ` と往復。K-5）
M.ANY_UNDER = M.UNDER | M.UNDER2 | M.WAVE; M.ANY_STRIKE = M.STRIKE | M.STRIKE2;
FZ.M = M;
/* 字の倍率：横 m・縦 n（1〜9）。2 倍までは WIDE・TALL、それより大きいときは SZW・SZH に m−1・n−1 */
const NARROW = [1, 0.9, 0.75, 0.5]; /* 長体（字の幅を 90%・75%・50% に）：倍角の亜種。横倍角・m×n と重なれば倍角を優先 */
const scaleW = mk => { const v = (mk & M.SZW) >>> 20; return v ? v + 1 : (mk & M.WIDE) ? 2 : NARROW[(mk & M.NAR) >>> 28]; }, scaleH = mk => { const v = (mk & M.SZH) >>> 24; return v ? v + 1 : (mk & M.TALL) ? 2 : 1; };
const withScale = (mk, w, h) => { mk &= ~(M.WIDE | M.TALL | M.SZW | M.SZH); w = clamp(w | 0, 1, 9); h = clamp(h | 0, 1, 9); if (w > 2 || h > 2) return mk | ((w - 1) << 20) | ((h - 1) << 24); return mk | (w === 2 ? M.WIDE : 0) | (h === 2 ? M.TALL : 0); };
FZ.scaleW = scaleW; FZ.scaleH = scaleH; FZ.withScale = withScale;
const SIZE_BITS = M.WIDE | M.TALL | M.SZW | M.SZH; FZ.SIZE_BITS = SIZE_BITS;
FZ.MARK_NAMES = [['BOLD', '太'], ['UNDER', '下'], ['DOT', '点'], ['SHADE', '網'], ['OUTLINE', '白'], ['STRIKE', '消'], ['WIDE', '横倍'], ['TALL', '縦倍']];

/* ---------- 文字列ユーティリティ ---------- */
const segmenter = (typeof Intl !== 'undefined' && Intl.Segmenter) ? new Intl.Segmenter('ja', { granularity: 'grapheme' }) : null;
const gCache = new Map(); const G_CACHE_MAX = 20000;
/* 1 符号単位がそのまま 1 書記素になる字の表（ASCII・ラテン・ギリシャ・キリル・記号・CJK・かな・全角形）。結合文字・ZWJ・異体字セレクタ・サロゲート・ハングル字母・CR・半角濁点は外す（それを含む文字列だけ Intl.Segmenter に回す） */
const G_SIMPLE = (() => { const t = new Uint8Array(65536); const on = (a, b) => t.fill(1, a, b + 1); on(0x00, 0x2ff); t[0x0d] = 0; on(0x370, 0x482); on(0x2000, 0x20cf); t[0x200c] = t[0x200d] = 0; on(0x2100, 0x2bff); on(0x2e80, 0x3029); on(0x3030, 0x3098); on(0x309b, 0xa4cf); on(0xe000, 0xfaff); on(0xfe10, 0xfe1f); on(0xfe30, 0xfe6f); on(0xff00, 0xff9d); on(0xffa0, 0xffef); return t; })();
function simpleGraphemes(s) { const n = s.length; for (let i = 0; i < n; i++) if (!G_SIMPLE[s.charCodeAt(i)]) return null; const out = new Array(n); for (let i = 0; i < n; i++) out[i] = { text: s[i], start: i, end: i + 1 }; return out; }
function graphemes(text) {
  const s = String(text ?? '');
  const hit = gCache.get(s); if (hit) return hit;
  let out = simpleGraphemes(s); if (out) { if (s.length <= 64) { if (gCache.size >= G_CACHE_MAX) { let k = G_CACHE_MAX >> 2; for (const key of gCache.keys()) { gCache.delete(key); if (--k <= 0) break; } } gCache.set(s, out); } return out; } // 速い道（日本語の本文の大半）。長い文字列は覚えない（作り直しの方が安い）
  if (segmenter) out = Array.from(segmenter.segment(s), p => ({ text: p.segment, start: p.index, end: p.index + p.segment.length }));
  else { let i = 0; out = Array.from(s, ch => { const g = { text: ch, start: i, end: i + ch.length }; i += ch.length; return g; }); }
  if (gCache.size >= G_CACHE_MAX) { let k = G_CACHE_MAX >> 2; for (const key of gCache.keys()) { gCache.delete(key); if (--k <= 0) break; } } gCache.set(s, out); return out; // 古い方から 1/4 だけ捨てる（全消しすると巨大な文書で切り直しの嵐になる）
}
function isHalf(cp) { return (cp >= 0x20 && cp <= 0x7e) || (cp >= 0xff61 && cp <= 0xff9f) || cp === 0xa5 || cp === 0x203e; }
function baseWidth(g) { return isHalf(g.codePointAt(0)) ? 0.5 : 1; }
function gWidth(g, marks) { const w = baseWidth(typeof g === 'string' ? g : g.text); return w * scaleW(marks); }
function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
const half = v => Math.round(v * 2) / 2;
FZ.graphemes = graphemes; FZ.gWidth = gWidth; FZ.isHalf = isHalf;

/* 禁則 */
const NO_START = new Set(Array.from('、。，．）」』】〕｝〉》〙〗〟’”‐゠–〜～？！：；゛゜ゝゞヽヾー々ぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮヵヶ,.)]}!?:;%'));
const NO_END = new Set(Array.from('（「『【〔｛〈《〘〖〝‘“([{'));
const HANG = new Set(Array.from('、。，．,.'));

/* ---------- 文書 ---------- */
const PAPERS = { A4: [210, 297], A5: [148, 210], B5: [182, 257], B4: [257, 364], A3: [297, 420], Letter: [215.9, 279.4] };
FZ.PAPERS = PAPERS;
function defaultFormat() {
  return { paper: 'A4', widthMm: 210, heightMm: 297, landscape: false, cols: 40, rows: 36,
    margins: { top: 20, right: 20, bottom: 20, left: 20 }, header: '', footer: '{page} / {pages}', headerRows: 1, footerRows: 1, hfGap: 1,
    font: 'mincho', fontMincho: 'BIZ UDMincho', fontGothic: 'BIZ UDGothic', hang: true, gridLines: true,
    /* 三体系：数字見出しの番号体系（scheme）と題のレベル数、記号見出しの体系、箇条書きの体系。記号見出しで番号を仕切り直すか */
    scheme: ['1.', '（1）', '①', 'ア', '（ア）', 'a）', 'ⅰ）', 'A.'], titleLevels: 2, symScheme: ['■', '◆', '●', '○', '▲', '△', '◇', '□'], bulletScheme: ['・', '‐', '◦', '▪', '▫', '‣', '⁃', '∙'], listScheme: ['1）', 'a）', 'ⅰ）', '1）', 'a）', 'ⅰ）', '1）', 'a）'], symResetsNum: false,
    /* 見出しの前の空き：戻り空き＝レベルが戻る見出しの前に 1 行、題の前空き＝本文・箇条書きの後の題（と記号見出し）の前に 1 行 */
    returnGap: false, titleGap: false, titleAfter: false, tableGap: false,
    /* 本文（見出しでも箇条書きでもない段落）を直前の見出しの文字位置に揃える（K-7）。位置を明示した行は従わない */
    bodyFollow: false,
    /* 書式の種類（資料書式 1.0.10）：'doc'＝文書、'slide'＝資料（本文欄＋図表欄、柱に題と管理情報） */
    kind: 'doc', bodyPct: 60, divider: 'none', headTitle: 'page', author: '', date: '', secret: '', pageMark: 'box', headRule: 'thin',
    /* 表紙（資料）：1 頁目に柱を出さない。表紙の頁番号を出すか。開始番号＝1 頁目の番号（PowerPoint の「スライド開始番号」と同じ。表紙に番号を出さず 0 にすると次の頁が 1） */
    cover: false, coverNum: false, coverStyle: '', coverSecret: false, pageStart: 1 };
}
function marksFor(text, m = 0) { const a = new Array(String(text).length); a.fill(m); return a; }
function newSeg(col = 0, text = '', m = 0) { return { col, text, marks: marksFor(text, m) }; }
function newLine(text = '', attrs = {}) { return { segs: [newSeg(0, text)], attrs: { ...attrs } }; }
function newDoc() { return { version: 1, title: '', format: defaultFormat(), lines: [newLine()], rules: [], fills: [] }; }
FZ.defaultFormat = defaultFormat; FZ.newSeg = newSeg; FZ.newLine = newLine; FZ.newDoc = newDoc; FZ.marksFor = marksFor;

let idSerial = 1;
FZ.uid = () => 'r' + (idSerial++) + '-' + Math.random().toString(36).slice(2, 7);

/* 正規化：壊れた原本・古い構造を安全な形に揃える */
function normalize(doc) {
  const d = doc && typeof doc === 'object' ? doc : {};
  const f = { ...defaultFormat(), ...(d.format || {}) };
  f.margins = { ...defaultFormat().margins, ...(d.format?.margins || {}) };
  f.cols = clamp(Math.round(+f.cols || 40), 4, 200); f.rows = clamp(Math.round(+f.rows || 36), 2, 300);
  f.targetPages = clamp(Math.round(+f.targetPages || 0), 0, 99); if (!f.targetPages) delete f.targetPages; f.minPt = clamp(Math.round((+f.minPt || 0) * 2) / 2, 0, 40); if (!f.minPt) delete f.minPt; /* 1.0.13d P11 目標の頁数・本文の最小の字の大きさ（pt） */
  f.headerRows = clamp(Math.round(+f.headerRows || 0), 0, 8); f.footerRows = clamp(Math.round(+f.footerRows || 0), 0, 8);
  if (f.headingNumbers != null || f.levelStart != null) migrateLegacyFormat(f); // 1.0.8 以前の単一体系
  f.scheme = normalizeScheme(f.scheme, FZ.DEFAULT_SCHEME); f.symScheme = normalizeScheme(f.symScheme, FZ.DEFAULT_SYM); f.bulletScheme = normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET); f.listScheme = normalizeScheme(f.listScheme, FZ.DEFAULT_LIST); f.titleLevels = clamp(f.titleLevels == null ? 2 : f.titleLevels | 0, 0, 8); f.symResetsNum = !!f.symResetsNum; f.returnGap = f.returnGap === 'rule' ? 'rule' : !!f.returnGap; f.titleGap = !!f.titleGap; f.titleAfter = !!f.titleAfter; f.tableGap = !!f.tableGap; f.bodyFollow = f.bodyFollow === 'mark' || f.bodyFollow === 'step' ? f.bodyFollow : !!f.bodyFollow; /* 'step'＝見出しの頭から 1 字下げ、'mark'＝見出しの頭（印の桁）、true＝見出しの文字、false＝左端 */ f.kind = f.kind === 'slide' ? 'slide' : 'doc'; f.bodyPct = clamp(Math.round((+f.bodyPct || 60) / 5) * 5, 20, 100); if (!['none', 'thin', 'dotted'].includes(f.divider)) f.divider = 'none'; f.headTitle = f.headTitle === 'doc' ? 'doc' : 'page'; for (const k of ['author', 'date', 'secret']) f[k] = String(f[k] || ''); f.dateAuto = !!f.dateAuto; if (!['box', 'circle', 'none'].includes(f.pageMark)) f.pageMark = 'box'; f.cover = !!f.cover; f.coverNum = !!f.coverNum; f.coverStyle = ['std', 'toc'].includes(f.coverStyle) ? f.coverStyle : ''; f.coverSecret = !!f.coverSecret; delete f.columns; f.pageStart = Number.isFinite(+f.pageStart) ? clamp(Math.round(+f.pageStart), 0, 9999) : 1; f.headRule = f.headRule === 'thick' ? 'thick' : 'thin'; delete f.numberStart; delete f.bulletStart;
  f.widthMm = clamp(+f.widthMm || 210, 50, 1000); f.heightMm = clamp(+f.heightMm || 297, 50, 1000);
  if (f.pageAlt && typeof f.pageAlt === 'object') { const pa = {}; for (const k of ['doc', 'slide']) { const v = f.pageAlt[k]; if (v && typeof v === 'object') { const o = {}; for (const key of FZ.PAGE_KEYS) if (v[key] !== undefined) o[key] = JSON.parse(JSON.stringify(v[key])); if (Object.keys(o).length) pa[k] = o; } } if (Object.keys(pa).length) f.pageAlt = pa; else delete f.pageAlt; } else delete f.pageAlt; /* 文書と資料それぞれの版面の控え（種類を切り替えると入れ替わる） */
  const lines = Array.isArray(d.lines) && d.lines.length ? d.lines : [newLine()]; const anchors = new Set(), tids = new Set();
  for (const ln of lines) {
    if (!Array.isArray(ln.segs) || !ln.segs.length) ln.segs = [newSeg(0, String(ln.text || ''))];
    for (const s of ln.segs) {
      s.text = String(s.text ?? ''); s.col = half(clamp(+s.col || 0, 0, f.cols));
      if (!Array.isArray(s.marks)) s.marks = marksFor(s.text);
      if (s.marks.length !== s.text.length) { const m = marksFor(s.text); for (let i = 0; i < Math.min(m.length, s.marks.length); i++) m[i] = s.marks[i] | 0; s.marks = m; }
    }
    ln.segs.sort((a, b) => a.col - b.col);
    ln.attrs = ln.attrs && typeof ln.attrs === 'object' ? ln.attrs : {};
    if (ln.segs.length > 1) ln.attrs.cells = true;
    if (ln.attrs.figure) { ln.attrs.figure = FZ.normalizeFigure ? FZ.normalizeFigure(ln.attrs.figure) : ln.attrs.figure; ln.segs = [newSeg(0, '')]; delete ln.attrs.cells; delete ln.attrs.list; }
    if (ln.attrs.hr) { ln.attrs = { hr: true, ...(ln.attrs.quote ? { quote: ln.attrs.quote } : {}), ...(ln.attrs.breakBefore ? { breakBefore: true } : {}) }; ln.segs = [newSeg(0, '')]; } // 区切り線（K-6）：文字を持たない行
    if (ln.attrs.toc) { ln.attrs.toc = normalizeToc(ln.attrs.toc); ln.segs = [newSeg(0, '')]; delete ln.attrs.cells; delete ln.attrs.list; delete ln.attrs.style; delete ln.attrs.figure; }
    if (ln.attrs.notes) { const ns = [...new Set((Array.isArray(ln.attrs.notes) ? ln.attrs.notes : []).filter(x => typeof x === 'string' && /^[A-Za-z0-9_-]+$/.test(x)))]; if (ns.length) ln.attrs.notes = ns; else delete ln.attrs.notes; }
    if (ln.attrs.gantt) { const g = ln.attrs.gantt; ln.attrs.gantt = { labels: clamp(g.labels ?? 1, 0, 6) | 0, heads: clamp(g.heads | 0 || 1, 1, 3), ...(g.base != null && isFinite(+g.base) ? { base: Math.max(1, +g.base) } : {}) }; }
    if (ln.attrs.list) { const l = ln.attrs.list; ln.attrs.list = { level: clamp(l.level | 0, 0, 7), ...(['arrow', 'todo', 'done', 'cont', 'num'].includes(l.kind) ? { kind: l.kind } : {}) }; }
    if (ln.attrs.style === 'h1' || ln.attrs.style === 'h2' || ln.attrs.style === 'h3') { ln.attrs.level = headingLevel(ln.attrs.style); ln.attrs.style = f._legacy ? (f._legacyNum ? 'num' : 'sym') : 'num'; } // 1.0.8 以前の見出し（旧ファイルは見た目を保つため印なしの記号見出し、それ以外は数字見出し）
    if (ln.attrs.style === 'num' || ln.attrs.style === 'sym') { ln.attrs.level = clamp(ln.attrs.level | 0, 0, 7); delete ln.attrs.list; } else delete ln.attrs.level;
    if (ln.attrs.quote != null) { ln.attrs.quote = clamp(ln.attrs.quote | 0, 0, 8); if (!ln.attrs.quote) delete ln.attrs.quote; }
    if (ln.attrs.anchor != null) { const an = String(ln.attrs.anchor).replace(/[^A-Za-z0-9_-]/g, ''); if (!an || anchors.has(an)) delete ln.attrs.anchor; else { ln.attrs.anchor = an; anchors.add(an); } } // 節の名札：重なったら後の方を外す
    if (ln.attrs.tid != null) { const t = String(ln.attrs.tid).replace(/[^A-Za-z0-9_-]/g, ''); if (!t || tids.has(t)) delete ln.attrs.tid; else { ln.attrs.tid = t; tids.add(t); } } /* 1.0.13c 表の名札（グラフとつなぐ）：重なったら後の方を外す */
    if (ln.attrs.deco != null && !DECO_SPECS[ln.attrs.deco]) delete ln.attrs.deco;
    if (ln.attrs.code != null && ln.attrs.code !== true && typeof ln.attrs.code !== 'string') ln.attrs.code = true;
    if (ln.attrs.restart != null && ln.attrs.restart !== true) { ln.attrs.restart = Math.max(1, ln.attrs.restart | 0); if (ln.attrs.restart === 1) ln.attrs.restart = true; }
    for (const sg of ln.segs) { // リンク：範囲の整合と LINK 印の同期
      const links = Array.isArray(sg.links) ? sg.links.filter(l => l && Number.isFinite(+l.start) && Number.isFinite(+l.end) && l.end > l.start && typeof l.url === 'string').map(l => ({ start: clamp(l.start | 0, 0, sg.text.length), end: clamp(l.end | 0, 0, sg.text.length), url: l.url, ...(l.image ? { image: true } : {}), ...(l.title ? { title: String(l.title) } : {}) })).filter(l => l.end > l.start).sort((x, y) => x.start - y.start) : [];
      if (links.length) { sg.links = links; for (let q = 0; q < sg.marks.length; q++) sg.marks[q] &= ~M.LINK; for (const l of links) for (let q = l.start; q < l.end; q++) sg.marks[q] |= M.LINK; }
      else { delete sg.links; for (let q = 0; q < sg.marks.length; q++) sg.marks[q] &= ~M.LINK; }
    }
  }
  if (f._legacy) { const L = f._legacy; for (const ln of lines) { const l = ln.attrs.list; if (!l || ln.attrs.style === 'num' || ln.attrs.style === 'sym') continue; const idx = clamp(L.base + (l.level | 0), 0, 7); const sp = levelSpec(L.scheme[idx]); const count = type => { let c = 0; for (let k = 0; k < idx; k++) if (levelSpec(L.scheme[k]).type === type) c++; return c; };
      if (sp.type === 'num' && !l.kind) { ln.attrs.style = 'num'; ln.attrs.level = clamp(count('num'), 0, 7); delete ln.attrs.list; } else ln.attrs.list = { ...l, level: clamp(count('sym'), 0, 7) }; } }
  delete f._legacy; delete f._legacyNum;
  /* K-1：題の太字は組版が付ける。全文が太字の題の行は、焼いた太字（旧版・Markdown 読み込み）とみなして外す。細字の行は触らない */
  for (const ln of lines) { if (!titleLike(ln.attrs, f) || ln.attrs.thin) { if (!titleLike(ln.attrs, f)) delete ln.attrs.thin; continue; } let all = true, any = false; for (const sg of ln.segs) for (let q = 0; q < sg.marks.length; q++) { if (/[\s　]/.test(sg.text[q])) continue; any = true; if (!(sg.marks[q] & M.BOLD)) { all = false; break; } } if (any && all) for (const sg of ln.segs) for (let q = 0; q < sg.marks.length; q++) sg.marks[q] &= ~M.BOLD; }
  const rules = (Array.isArray(d.rules) ? d.rules : []).filter(r => r && (r.axis === 'h' || r.axis === 'v')).map(r => ({ ...r, id: r.id || FZ.uid(), kind: r.kind || 'thin' }));
  const fills = (Array.isArray(d.fills) ? d.fills : []).filter(x => x && Number.isFinite(+x.from)).map(x => ({ ...x, id: x.id || FZ.uid(), shade: x.shade || 'gray' }));
  /* 画像（資料書式）：名前 → { mime, data(base64) }。図版：行の attrs.figs = [{ id, kind:'図'|'表', title, file, width:100|75|50, chart? }]（chart はグラフのデータ。fz-chart.js） */
  const images = {}; if (d.images && typeof d.images === 'object') for (const [k, v] of Object.entries(d.images)) if (v && typeof v.data === 'string' && /^image\//.test(v.mime || '')) images[k] = { mime: v.mime, data: v.data };
  const figSeen = new Set(); const uniq = id => { let v = String(id).replace(/\s+/g, '_') || 'f'; if (figSeen.has(v)) { let n = 2; while (figSeen.has(v + '_' + n)) n++; v = v + '_' + n; } figSeen.add(v); return v; };
  for (const ln of lines) if (ln.attrs.figs) { const figs = (Array.isArray(ln.attrs.figs) ? ln.attrs.figs : []).filter(x => x && x.id).map(x => ({ id: uniq(x.id), kind: x.kind === '表' ? '表' : '図', title: String(x.title || ''), file: x.chart ? '' : String(x.file || ''), ...figSize(x), ...(x.chart && FZ.normalizeChart ? { chart: FZ.normalizeChart(x.chart) } : {}) })); /* グラフ（fz-chart.js）：画像の代わりにデータを持つ */ if (figs.length) ln.attrs.figs = figs; else delete ln.attrs.figs; }
  const parked = Array.isArray(d.parked) ? d.parked.filter(p => p && Array.isArray(p.lines) && p.lines.length).map((p, k) => ({ id: String(p.id || 'p' + (k + 1)).replace(/[^A-Za-z0-9_-]/g, '') || 'p' + (k + 1), label: String(p.label || '').replace(/[\r\n]+/g, ' ').slice(0, 40), lines: normalize({ format: f, lines: p.lines, rules: [], fills: [] }).lines })) : []; /* 保留の島（S4）：文書の外に退避した行。組版・書き出しには出ない */
  const notes = Array.isArray(d.notes) ? d.notes.filter(n => n && typeof n.id === 'string' && /^[A-Za-z0-9_-]+$/.test(n.id)).map(n => ({ id: n.id, author: String(n.author || ''), date: String(n.date || ''), done: !!n.done, quote: String(n.quote || ''), text: String(n.text || ''), replies: Array.isArray(n.replies) ? n.replies.map(r => ({ author: String(r.author || ''), date: String(r.date || ''), text: String(r.text || '') })) : [] })) : []; /* 付箋 */
  const phases = Array.isArray(d.pufuPhases) ? d.pufuPhases.filter(p => p && /^[A-Za-z0-9_-]+$/.test(p.key || '')).map(p => ({ key: p.key, no: p.no | 0, date: String(p.date || ''), title: String(p.title || ''), md: String(p.md || '') })) : []; /* 1.0.14e プ譜の局面の記録 */
  return { version: 1, title: String(d.title || ''), format: f, lines, rules, fills, images, refs: d.refs && typeof d.refs === 'object' ? d.refs : { ids: [] }, ...(parked.length ? { parked } : {}), ...(notes.length ? { notes } : {}), ...(phases.length ? { pufuPhases: phases } : {}), ...(typeof d.kata === 'string' && /^[A-Za-z0-9_-]+$/.test(d.kata) ? { kata: d.kata } : {}), ...(typeof d.kind === 'string' && /^[^\s#]{1,12}$/.test(d.kind) ? { kind: d.kind } : {}), ...(Array.isArray(d.proofIgnore) && d.proofIgnore.length ? { proofIgnore: [...new Set(d.proofIgnore.map(x => String(x)).filter(Boolean))] } : {}), ...(Array.isArray(d.extra) && d.extra.length ? { extra: d.extra.filter(x => Array.isArray(x) && x.length === 2).map(([k, v]) => [String(k), String(v)]) } : {}) };
}
FZ.normalize = normalize;
/* 文中の図番：図版の ID ごとに私用面の 1 字（U+F0000〜。BMP の私用領域は Windows の外字が使うので避ける）を割り当てて本文に置く。
   組版がその字を「図 1」のような現在の番号に置き換えて描く。原本では <図番 ID>。割り当ては文書ごと・追加のみ（取消しても字が迷子にならない） */
const REF_BASE = 0xF0000, REF_MAX = 0xFFFFD; const REF_RE = /[\u{F0000}-\u{FFFFD}]/u;
FZ.refChar = function (doc, id) { if (!doc.refs) doc.refs = { ids: [] }; let k = doc.refs.ids.indexOf(id); if (k < 0) { k = doc.refs.ids.length; doc.refs.ids.push(id); } return String.fromCodePoint(REF_BASE + Math.min(k, REF_MAX - REF_BASE)); };
FZ.refId = function (doc, ch) { const c = String(ch).codePointAt(0); if (!(c >= REF_BASE && c <= REF_MAX) || !doc || !doc.refs) return null; return doc.refs.ids[c - REF_BASE] ?? null; };
/* 開いてよいリンク：http(s)・mailto・tel・file と、スキームの無い相対の参照だけ。javascript: data: vbscript: などは開かない・書き出さない（文書を開いた人の画面で何かが走るのを防ぐ） */
FZ.safeUrl = function (u) { const s = String(u ?? '').trim(); if (!s) return null; const m = /^([a-zA-Z][a-zA-Z0-9+.-]*):/.exec(s.replace(/[\u0000-\u001F\u007F\s]+/g, '')); if (!m) return s; if (/^[a-zA-Z]$/.test(m[1])) return s; /* C:\… のようなドライブ */ return /^(https?|mailto|tel|file)$/i.test(m[1]) ? s : null; };
const isRefChar = ch => { const c = String(ch).codePointAt(0); return c >= REF_BASE && c <= REF_MAX; }; FZ.isRefChar = isRefChar; FZ.hasRefs = t => REF_RE.test(t);
/* 図版の番号：文書の順に図・表を別々に数える。戻り値 Map(id → { label, kind, n, title, file, width, line }) */
FZ.figureNumbers = function (doc) { const out = new Map(), cnt = { 図: 0, 表: 0 }; let anyAnchor = false; doc.lines.forEach((ln, i) => { if (ln.attrs.anchor) anyAnchor = true; for (const fg of ln.attrs.figs || []) { const n = ++cnt[fg.kind]; out.set(fg.id, { ...fg, n, label: fg.kind + ' ' + n, line: i }); } }); if (anyAnchor) sectionLabels(doc, out); return out; };
/* 節の参照（S5）：見出しの行に名札（attrs.anchor）。参照の id は '§' ＋ 名札。番号見出しは「番号 題」、ほかは「題」を括弧で */
function sectionLabels(doc, out) { const f = doc.format || {}; const S = normalizeScheme(f.scheme); const counters = [], ordAt = []; const anc = lv => { const r = []; for (let k = 0; k < lv; k++) if (ordAt[k] != null) r.push(ordAt[k]); return r; };
  const mks = []; doc.lines.forEach((ln, i) => { const a = ln.attrs; let mk = '';
    if (a.style === 'title') { counters.length = 0; ordAt.length = 0; }
    else if (a.style === 'num') { const lv = clamp(a.level | 0, 0, 7); if (a.restart) counters[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; counters.length = lv + 1; counters[lv] = (counters[lv] || 0) + 1; ordAt.length = lv; mk = schemeMarker(S, lv, counters[lv], anc(lv)).replace(/[ 　]+$/, ''); ordAt[lv] = counters[lv]; mks.length = lv; mks[lv] = mk; if (lv > 0 && !/\d[.．]\d/.test(String(S[lv]))) mk = mks.slice(0, lv).filter(Boolean).map(x => x.replace(/[.．]$/, '')).join('') + mk; } /* 深い見出しは上の番号を前に（2（1）） */
    if (!a.anchor || out.has('§' + a.anchor)) return; const text = ln.segs.map(sg => sg.text).join(' ').replace(REF_RE_G, '').replace(/\s+/g, ' ').trim().slice(0, 24);
    out.set('§' + a.anchor, { label: mk ? (/[）)】」』〕］]$/.test(mk) ? mk + text : mk + ' ' + text) : '「' + text + '」', line: i, section: true }); }); }
const REF_RE_G = /[\u{F0000}-\u{FFFFD}]/gu;
/* 本文の図番の字を番号の文字列に開く（書き出し・コピー用）。marks も字数に合わせる */
FZ.expandRefs = function (doc, seg, nums, linkify) { if (!REF_RE.test(seg.text)) return seg; nums = nums || FZ.figureNumbers(doc); let text = '', marks = []; const t = seg.text; const at = new Array(t.length + 1); const add = []; for (let q = 0; q < t.length; q++) { at[q] = text.length; const cp = t.codePointAt(q); if (cp >= REF_BASE && cp <= REF_MAX) { const id = doc.refs ? doc.refs.ids[cp - REF_BASE] : null; const known = !!(id && nums.get(id)); const lb = known ? nums.get(id).label : (id && id[0] === '§' ? '節 ?' : '図 ?'); const s0 = text.length; text += lb; const lk = linkify && known && !(seg.links || []).some(l => l.start <= q && l.end > q); for (let k = 0; k < lb.length; k++) marks.push((seg.marks[q] | 0) | (lk ? M.LINK : 0)); if (lk) add.push({ start: s0, end: text.length, url: id[0] === '§' ? '#節-' + id.slice(1) : '#図-' + id }); at[q + 1] = text.length; q++; } else { text += t[q]; marks.push(seg.marks[q] | 0); } } at[t.length] = text.length; /* linkify：参照を文書の中へのリンクに（文机 Markdown。読み込むと参照に戻る） */
  const out = { ...seg, text, marks }; const ls = (seg.links || []).map(l => ({ ...l, start: at[l.start] ?? text.length, end: at[l.end] ?? text.length })).concat(add).sort((a, b) => a.start - b.start); if (ls.length) out.links = ls; else delete out.links; return out; };
FZ.expandRefsText = function (doc, t, nums) { if (!REF_RE.test(t)) return t; return FZ.expandRefs(doc, { text: t, marks: marksFor(t) }, nums).text; };
/* 画像の大きさ（px）：PNG／JPEG／GIF／SVG の頭を読む。読めなければ 4:3 */
FZ.imageSize = function (img) { if (!img) return { w: 4, h: 3 }; if (img._size) return img._size; let w = 4, h = 3; try { const b64 = img.data.slice(0, 120000); const bin = typeof atob === 'function' ? atob(b64.slice(0, b64.length - (b64.length % 4))) : Buffer.from(b64, 'base64').toString('binary'); const u = i => bin.charCodeAt(i) & 255;
    if (img.mime === 'image/png' && bin.slice(1, 4) === 'PNG') { w = (u(16) << 24 | u(17) << 16 | u(18) << 8 | u(19)) >>> 0; h = (u(20) << 24 | u(21) << 16 | u(22) << 8 | u(23)) >>> 0; }
    else if (img.mime === 'image/gif') { w = u(6) | u(7) << 8; h = u(8) | u(9) << 8; }
    else if (/jpe?g/.test(img.mime)) { let p = 2; while (p < bin.length - 9) { if (u(p) !== 0xFF) { p++; continue; } const mk = u(p + 1); const len = u(p + 2) << 8 | u(p + 3); if (mk >= 0xC0 && mk <= 0xCF && mk !== 0xC4 && mk !== 0xC8 && mk !== 0xCC) { h = u(p + 5) << 8 | u(p + 6); w = u(p + 7) << 8 | u(p + 8); break; } p += 2 + len; } }
    else if (/svg/.test(img.mime)) { const t = bin.slice(0, 4000); const vb = t.match(/viewBox=["']\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/); const ww = t.match(/\swidth=["']([\d.]+)/), hh = t.match(/\sheight=["']([\d.]+)/); if (vb) { w = +vb[1]; h = +vb[2]; } else if (ww && hh) { w = +ww[1]; h = +hh[1]; } }
  } catch (e) { } if (!(w > 0 && h > 0)) { w = 4; h = 3; } Object.defineProperty(img, '_size', { value: { w, h }, enumerable: false, configurable: true, writable: true }); return img._size; };

/* ---------- 幾何 ---------- */
const PT = 72 / 25.4;
function geometry(f, opts = {}) {
  const W = f.widthMm * PT, H = f.heightMm * PT, left = f.margins.left * PT, top = f.margins.top * PT;
  const areaW = W - left - f.margins.right * PT, areaH = H - top - f.margins.bottom * PT;
  const gap = f.hfGap == null ? 1 : clamp(f.hfGap | 0, 0, 4); const hGap = f.headerRows > 0 ? gap : 0, fGap = f.footerRows > 0 ? gap : 0; // 柱と本文の間の空き（行）
  const total = f.headerRows + hGap + f.rows + fGap + f.footerRows;
  const cw = areaW / f.cols, ch = areaH / total;
  /* 資料書式：本文欄 [0, bodyCols) と図表欄 [sideLeft, cols)。欄の間は 1 マス（仕切りの縦罫はその中ほど） */
  const slide = f.kind === 'slide'; /* 2 段組（資料だけ）：本文を左右 2 段に流す（図表欄は使わない。段の間は 2 マス、真ん中に仕切り）。組版は段を 1 頁として組み、最後に 2 段ずつ 1 頁にまとめる */
  const cols2 = false; /* 2 段組は 1.0.10u で撤去（A3 は区画で組む）。段を頁として組んでまとめる仕組みは残すが使わない */ const colW = cols2 ? Math.floor((f.cols - 2) / 2) : 0;
  const side = !cols2 && slide && (f.bodyPct | 0) < 100 && f.cols >= 16; const bodyCols = cols2 ? colW : side ? clamp(Math.round(f.cols * f.bodyPct / 100), 8, f.cols - 6) : f.cols;
  return { W, H, left, top, areaW, areaH, cw, ch, fs: Math.min(cw, ch), cols: f.cols, rows: f.rows, headerRows: f.headerRows, footerRows: f.footerRows, hGap, fGap, total, bodyTop: f.headerRows + hGap, footerTop: f.headerRows + hGap + f.rows + fGap,
    slide, bodyCols, side, sideLeft: side ? bodyCols + 1 : f.cols, sideRight: f.cols, cols2, colW, colX2: cols2 ? f.cols - colW : 0,
    zw: glyphPct(f.zenW), hw: glyphPct(f.hanW) }; /* 1.0.11d 基準の字幅（全角・半角）：元の書体に対する横の倍率。描くときだけに効く（組版のマスは変わらない） */
}
function glyphPct(v) { v = +v; return v > 0 ? clamp(Math.round(v), 30, 200) / 100 : 1; }
FZ.glyphPct = glyphPct;
/* 1.0.11e 図表の大きさ：欄（区画・図表欄・本文の幅）を n 等分した 1 つ分（間は 1 マス）の何％か、または原寸（画像の画素を 96dpi、グラフは Excel の既定 12.7cm 幅）の何％か。高さは縦横の比で決まる */
const figPct = v => clamp(Math.round(+v || 100), 10, 100), figDiv = v => clamp(v | 0 || 1, 1, 4), figOrig = v => clamp(Math.round(+v || 100), 10, 400);
function figSize(x) { const o = { width: figPct(x.width) }; if (figDiv(x.div) > 1) o.div = figDiv(x.div); if (+x.orig > 0) o.orig = figOrig(x.orig); return o; }
FZ.figSize = figSize;
FZ.figSizeToks = fg => fg.orig ? ['原寸' + figOrig(fg.orig) + '%'] : [...(figDiv(fg.div) > 1 ? ['1/' + figDiv(fg.div)] : []), ...(figPct(fg.width) !== 100 ? [figPct(fg.width) + '%'] : [])];
FZ.figSizeTok = t => { let m; t = String(t); if ((m = t.match(/^1\/([1-4])$/))) return { div: +m[1] }; if ((m = t.match(/^原寸(\d+)[%％]$/))) return { orig: figOrig(+m[1]) }; if ((m = t.match(/^(\d+)[%％]$/))) return { width: figPct(+m[1]) }; return null; };
FZ.figSizeLabel = fg => fg.orig ? '原寸の ' + figOrig(fg.orig) + '%' : (figDiv(fg.div) > 1 ? '1/' + figDiv(fg.div) + ' の ' : '欄の ') + figPct(fg.width) + '%';
/* 幅（マス）：avail＝欄の幅（マス）、cw＝1 マスの pt、px＝画像の大きさ（画素、無ければ null） */
function figCells(fg, avail, cw, px) {
  const h2 = v => Math.floor(v * 2 + 1e-6) / 2; /* 半マス刻み（1/2 の 2 つと間の 1 マスで欄ちょうど） */
  if (+fg.orig > 0) { const wpt = fg.chart ? 360 : px ? px.w * 0.75 : avail * cw; return clamp(Math.round(wpt * figOrig(fg.orig) / 100 / cw * 2) / 2, 2, Math.max(2, avail)); }
  const n = figDiv(fg.div), slot = n <= 1 ? avail : h2((avail + 1) / n - 1), pc = figPct(fg.width); /* ％は間の 1 マス込みの割合（50% は 1/2 と同じ） */
  return Math.max(2, Math.min(avail, pc >= 100 ? slot : h2((slot + 1) * pc / 100 - 1))); }
FZ.figCells = figCells;
FZ.geometry = geometry; FZ.PT = PT;

/* ---------- 表（罫線）の判定 ---------- */
/* 縦罫の行ごとの索引。文書全体を走る処理（組版・原本の書き出し・書き出しの模型・見出しの空き）の間だけ使う（その間は罫を変えない）。
 * 索引が無いと vRulesAt が罫を毎回全部なめるので、表の多い文書で「行数×罫の数」に膨らむ（1645 頁・罫 1.7 万本で 1 打鍵 0.3 秒、保存 6.6 秒だった） */
let RIDX = null; const NO_RULES = Object.freeze([]);
function buildRuleIndex(doc) { const v = new Map(), h = new Map(), N = doc.lines.length; for (const r of doc.rules) { if (r.axis === 'h') { let L = h.get(r.line); if (!L) h.set(r.line, L = []); L.push(r); continue; } if (r.axis !== 'v') continue; const a = Math.max(0, r.from | 0), b = Math.min(N - 1, r.to | 0); for (let q = a; q <= b; q++) { let L = v.get(q); if (!L) v.set(q, L = []); L.push(r); } } return { doc, rules: doc.rules, n: doc.rules.length, N, v, h }; }
function idxOk(doc) { return RIDX && RIDX.doc === doc && RIDX.rules === doc.rules && RIDX.n === doc.rules.length && RIDX.N === doc.lines.length; }
function withRuleIndex(doc, fn) { if (idxOk(doc)) return fn(); const prev = RIDX; RIDX = buildRuleIndex(doc); try { return fn(); } finally { RIDX = prev; } }
FZ.withRuleIndex = withRuleIndex;
function hRulesAt(doc, line) { if (idxOk(doc)) return RIDX.h.get(line) || NO_RULES; return doc.rules.filter(r => r.axis === 'h' && r.line === line); } // 横罫（その行の上）
FZ.hRulesAt = (doc, line) => hRulesAt(doc, line);
function vRulesAt(doc, i) { if (idxOk(doc)) return RIDX.v.get(i) || NO_RULES; return doc.rules.filter(r => r.axis === 'v' && r.from <= i && i <= r.to); }
/* セル行（表の行）：attrs.cells が真で、縦罫線がかかっている行だけが縦線をセル境界として折り返す */
function inTable(doc, i) { const ln = doc.lines[i]; return !!(ln && ln.attrs && ln.attrs.cells) && vRulesAt(doc, i).length > 0; }
function cellsAt(doc, i, cols = doc.format.cols) {
  const set = new Set([0, cols]);
  for (const r of vRulesAt(doc, i)) if (r.col > 0 && r.col < cols) set.add(r.col);
  const b = [...set].sort((a, c) => a - c), cells = [];
  for (let k = 0; k < b.length - 1; k++) cells.push({ left: b[k], right: b[k + 1] });
  return cells;
}
/* 表の行のセル（表の左右の縦罫の内側だけ。空のセルも含む） */
function tableCells(doc, i, cols) { const vs = vRulesAt(doc, i).map(r => r.col); if (vs.length < 2) return cellsAt(doc, i, cols); const lo = Math.min(...vs), hi = Math.max(...vs); return cellsAt(doc, i, cols).filter(c => c.left >= lo - 1e-6 && c.right <= hi + 1e-6); }
FZ.tableCells = tableCells;
function cellFor(doc, i, col, cols) { const cs = cellsAt(doc, i, cols); return cs.find(c => col >= c.left && col < c.right) || cs[cs.length - 1]; }
FZ.vRulesAt = vRulesAt; FZ.hasRuleIndex = doc => !!idxOk(doc); FZ.inTable = inTable; FZ.cellsAt = cellsAt; FZ.cellFor = cellFor;

/* ---------- 三体系（数字見出し・記号見出し・箇条書き） ----------
 * 本文の行は、ただの段落か、次の 3 種類の節点のどれか：
 *   数字見出し attrs.style='num', attrs.level 0-7：レベル別の番号（format.scheme＝番号体系）。同じレベルの兄弟は連番。題のレベル数 titleLevels より浅いレベルは「題」（太字・次と同頁が既定）
 *   記号見出し attrs.style='sym', attrs.level 0-7：レベル別の記号（format.symScheme）。番号を持たない
 *   箇条書き   attrs.list={ level 0-7, kind?: 'arrow'|'todo'|'done'|'cont' }：レベル別の記号（format.bulletScheme）。→／❏／☑ は記号の置き換え
 * 3 種類は独立したレベル体系を持ち、レベルは「同じ種類の先祖の数」。入れ子の順位は 数字見出し ＞ 記号見出し ＞ 箇条書き。
 * 各体系は 8 トークン：番号書式（Ⅰ 1. 1） （1） ① A. a） ⅰ） 1 (1) 1) 1.1 第1 第1条 一 ア （ア） a （a））／記号（任意の文字列）／「なし」。
 *   番号書式と同じ文字を記号として固定したいときは先頭に ' を付ける。
 * 数字見出しの連番は記号見出しをまたいで続く。format.symResetsNum で記号見出しごとに仕切り直せる。 */
const BULLETS = ['■', '・', '‐', '◦', '▪', '▫'];
function roman(n, upper) { if (n >= 1 && n <= 12) return String.fromCodePoint((upper ? 0x2160 : 0x2170) + n - 1); const t = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']]; let r = ''; for (const [v, c] of t) while (n >= v) { r += c; n -= v; } return upper ? r : r.toLowerCase(); }
function circled(n) { if (n <= 20) return String.fromCodePoint(0x2460 + n - 1); if (n <= 35) return String.fromCodePoint(0x3251 + n - 21); if (n <= 50) return String.fromCodePoint(0x32b1 + n - 36); return '(' + n + ')'; }
function alpha(n, upper) { let r = ''; for (let v = n; v > 0; v = Math.floor((v - 1) / 26)) r = String.fromCharCode((upper ? 65 : 97) + (v - 1) % 26) + r; return r; }
function kanjiNum(n) { const K = '〇一二三四五六七八九'; if (n < 10) return K[n]; if (n < 100) { const t = Math.floor(n / 10), u = n % 10; return (t > 1 ? K[t] : '') + '十' + (u ? K[u] : ''); } return String(n); }
const KATA = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
function kata(n) { return n >= 1 && n <= KATA.length ? KATA[n - 1] : String(n); }
/* [トークン, 生成関数(null=複合番号 1.1.1), 区切り] */
const NUMBER_FORMAT_DEFS = [
  ['Ⅰ', n => roman(n, true), '　'], ['1.', n => n + '.', '　'], ['1）', n => n + '）', ''], ['（1）', n => '（' + n + '）', ''], ['①', circled, ' '], ['A.', n => alpha(n, true) + '.', '　'], ['a）', n => alpha(n, false) + '）', ''], ['ⅰ）', n => roman(n, false) + '）', ''],
  ['1', n => String(n), '　'], ['(1)', n => '(' + n + ')', ''], ['1)', n => n + ')', ' '], ['1.1', null, '　'], ['第1', n => '第' + n, '　'], ['第1条', n => '第' + n + '条', '　'], ['一', kanjiNum, '　'], ['ア', kata, '　'], ['（ア）', n => '（' + kata(n) + '）', ''], ['a', n => alpha(n, false), '　'], ['（a）', n => '（' + alpha(n, false) + '）', ''],
];
const NUMBER_FORMATS = Object.fromEntries(NUMBER_FORMAT_DEFS.map(([k, fn, sep]) => [k, { fn, sep }]));
FZ.NUMBER_KEYS = NUMBER_FORMAT_DEFS.map(d => d[0]);
FZ.NUMBER_LEVELS = FZ.NUMBER_KEYS.slice(0, 8); FZ.BULLET_LEVELS = BULLETS;
FZ.SYMBOL_PRESETS = ['■', '・', '‐', '◦', '▪', '▫', '●', '○', '◆', '◇', '□', '★', '☆', '※', '✓', '▶', '→', '⇒'];
FZ.NONE_TOKEN = 'なし';
FZ.DEFAULT_SYM = ['■', '◆', '●', '○', '▲', '△', '◇', '□'];
FZ.DEFAULT_BULLET = ['・', '‐', '◦', '▪', '▫', '‣', '⁃', '∙'];
/* 番号付き箇条書き（1.0.10a.3）：箇条書きの体系の中の「番号を振る項目」。見出しの番号（1. （1） ①）と紛れない形を既定に */
FZ.DEFAULT_LIST = ['1）', 'a）', 'ⅰ）', '1）', 'a）', 'ⅰ）', '1）', 'a）'];
/* プリセット：番号体系（num）・題のレベル数（title）・記号見出し（sym）・箇条書き（bullet） */
FZ.SCHEME_PRESETS = [
  { name: '標準', num: ['1.', '（1）', '①', 'ア', '（ア）', 'a）', 'ⅰ）', 'A.'], title: 2, sym: FZ.DEFAULT_SYM, bullet: FZ.DEFAULT_BULLET },
  { name: '報告書', num: ['Ⅰ', '1.', '（1）', '①', 'ア', '（ア）', 'a）', 'ⅰ）'], title: 2, sym: FZ.DEFAULT_SYM, bullet: FZ.DEFAULT_BULLET },
  { name: '公用文', num: ['第1', '1', '（1）', 'ア', '（ア）', 'a', '（a）', 'ⅰ）'], title: 1, sym: ['なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし'], bullet: ['・', '‐', '◦', '▪', '▫', '‣', '⁃', '∙'] },
  { name: '霞が関', num: ['1.', '（1）', '①', 'ア', '（ア）', 'a', '（a）', 'ⅰ）'], title: 1, sym: ['【】', '■', '●', '◆', '▲', '△', '◇', '□'], bullet: ['○', '・', '－', '▪', '▫', '‣', '⁃', '∙'] },
  { name: '契約書', num: ['第1条', '1', '（1）', 'ア', '（ア）', 'a', '（a）', 'ⅰ）'], title: 1, sym: ['なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし'], bullet: ['・', '‐', '◦', '▪', '▫', '‣', '⁃', '∙'] },
  { name: '技術文書', num: ['1.', '1.1', '1.1', '1.1', '（1）', '①', 'a）', 'ⅰ）'], title: 3, sym: FZ.DEFAULT_SYM, bullet: FZ.DEFAULT_BULLET },
  { name: '論文', num: ['1', '1.1', '1.1', '1.1', '（1）', '①', 'a', '（a）'], title: 3, sym: ['なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし'], bullet: ['・', '‐', '◦', '▪', '▫', '‣', '⁃', '∙'] },
];
FZ.DEFAULT_SCHEME = FZ.SCHEME_PRESETS[0].num;
/* 1.0.8 以前の単一体系（scheme 8 段に番号と記号が混ざる、見出し番号・開始階層）を三体系へ読み替える。
   番号の段を番号体系に、記号の段を箇条書きに分け、旧 [項目N] の行は読み込み側で種類を振り分ける（parse を参照） */
function migrateLegacyFormat(f) {
  const old = normalizeScheme(f.scheme, FZ.DEFAULT_SCHEME); const nums = [], syms = [];
  for (const t of old) { const sp = levelSpec(t); if (sp.type === 'num') nums.push(t); else if (sp.type === 'sym') syms.push(t); }
  f._legacy = { scheme: old, base: f.headingNumbers ? (clamp(f.levelStart | 0, 0, 7) > 0 ? clamp(f.levelStart | 0, 0, 7) : 3) : clamp(f.levelStart | 0, 0, 7), headingNumbers: !!f.headingNumbers };
  f._legacyNum = !!f.headingNumbers;
  f.scheme = normalizeScheme(nums, FZ.DEFAULT_SCHEME); f.bulletScheme = normalizeScheme(syms, FZ.DEFAULT_BULLET);
  f.symScheme = f.headingNumbers ? FZ.DEFAULT_SYM.slice() : ['なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし', 'なし']; // 旧「見出し」（無番号）は印なしの記号見出しに
  f.titleLevels = f.headingNumbers ? 3 : 0;
  delete f.headingNumbers; delete f.levelStart;
}
FZ.MAX_LEVEL = { item: 7, number: 7, bullet: 7, arrow: 7, todo: 7, done: 7, cont: 7 };
function textWidth(t) { let w = 0; for (const g of graphemes(t)) w += baseWidth(g.text); return w; }
const CELL_BUL = /^[・•◦‐▪▫○●■□◆◇※]/; FZ.CELL_BUL = CELL_BUL; /* 1.0.12b セルの中の箇条書きの印（この字で始まるセルは、折り返しを印の後ろに揃える） */
function normalizeToken(t) { t = String(t == null ? '' : t).replace(/[\s　]+/g, ''); return t || FZ.NONE_TOKEN; }
function normalizeScheme(a, dflt) { const src = Array.isArray(a) ? a : (typeof a === 'string' ? a.split(/\s+/) : []); const d = dflt || FZ.DEFAULT_SCHEME; return Array.from({ length: 8 }, (_, i) => normalizeToken(src[i] != null && src[i] !== '' ? src[i] : d[i])); }
/* トークン → { type: 'num'|'sym'|'none', key?, s? } */
/* 囲み見出し：記号見出しの体系に「【】」「《》」「〈〉」のような対を置くと、本文を 【…】 のように囲む（開きが印、閉じは本文の後ろに付く） */
FZ.WRAP_PAIRS = ['【】', '《》', '〈〉', '「」', '『』', '〔〕', '［］', '（）', '｛｝', '≪≫'];
function levelSpec(tok) {
  tok = normalizeToken(tok);
  if (tok === FZ.NONE_TOKEN) return { type: 'none' };
  if (FZ.WRAP_PAIRS.includes(tok)) { const cp = Array.from(tok); return { type: 'wrap', open: cp[0], close: cp[1] }; }
  if (tok.startsWith("'")) return tok.length > 1 ? { type: 'sym', s: tok.slice(1) } : { type: 'none' };
  if (NUMBER_FORMATS[tok]) return { type: 'num', key: tok };
  return { type: 'sym', s: tok };
}
/* 階層 idx の記号文字列（区切り・半端幅の詰めを含む）。anc は複合番号用の上位番号列 */
function schemeMarker(scheme, idx, ordinal, anc) {
  const sp = levelSpec(scheme[clamp(idx | 0, 0, 7)]);
  if (sp.type === 'none') return '';
  let s;
  if (sp.type === 'sym') s = sp.s; else if (sp.type === 'wrap') s = sp.open;
  else { const d = NUMBER_FORMATS[sp.key], n = Math.max(1, ordinal | 0); s = (d.fn ? d.fn(n) : [...(anc || []), n].join('.')) + d.sep; }
  if (textWidth(s) % 1) s += ' ';
  return s;
}
/* 囲み見出しの閉じ（無ければ ''） */
function schemeClose(scheme, idx) { const sp = levelSpec(scheme[clamp(idx | 0, 0, 7)]); return sp.type === 'wrap' ? sp.close : ''; }
FZ.schemeClose = schemeClose;
/* 体系エディタの見本：囲みなら 【題】 */
FZ.schemeSample = function (scheme, idx, anc) { const sp = levelSpec(scheme[clamp(idx | 0, 0, 7)]); if (sp.type === 'wrap') return sp.open + '題' + sp.close; return schemeMarker(scheme, idx, 1, anc).trim(); };
/* 見出しのレベル（0-7）。数字見出し・記号見出し以外は -1 */
function headingLevel(style, attrs) { if (style === 'h1') return 0; if (style === 'h2') return 1; if (style === 'h3') return 2; if ((style === 'num' || style === 'sym') && attrs) return clamp(attrs.level | 0, 0, 7); return -1; }
const isHeading = a => a && (a.style === 'num' || a.style === 'sym');
/* 節点の種類：'num'|'sym'|'bullet'|null */
function nodeKind(a) { if (!a) return null; if (a.style === 'num' || a.style === 'sym') return a.style; if (a.list) return 'bullet'; return null; }
/* Markdown 読み込みなど、入れ子の深さで来た項目の整え（三体系では種類ごとのレベルがそのまま体系のレベル）。残っているのは「続き」の整合だけ */
function fitItems(doc) {
  let last = null;
  for (const ln of doc.lines) { const l = ln.attrs.list; if (!l) { if (isHeading(ln.attrs) || ln.attrs.style === 'title' || (ln.segs.length === 1 && ln.segs[0].text === '')) last = null; continue; }
    if (l.kind === 'cont') { ln.attrs.list = { kind: 'cont', level: last != null ? last : clamp(l.level | 0, 0, 7) }; continue; } last = clamp(l.level | 0, 0, 7); }
}
FZ.levelSpec = levelSpec; FZ.schemeMarker = schemeMarker; FZ.normalizeToken = normalizeToken; FZ.normalizeScheme = normalizeScheme; FZ.fitItems = fitItems; FZ.nodeKind = nodeKind; FZ.isHeading = isHeading;
FZ.headingLevel = headingLevel; FZ.textWidth = textWidth;
/* 箇条書きの記号（kind と レベルから） */
/* 見出しの前の空き（書式 returnGap／titleGap）：行ごとに「前に 1 行空ける」か。
 * 深さ：表題 0、数字見出し 1+レベル、記号見出し 9+レベル、本文・箇条書き・表・図は最深（100）。
 * 戻り空き＝見出し（表題・数字・記号）の直前の行がそれより深いとき。題の前空き＝題（題レベルの数字見出し・記号見出し・表題）の直前が本文・箇条書き・表・図のとき。
 * 空行の後・文書の先頭は空けない。ページ頭で空けないのは組版側の仕事。Word の書き出しは段落前の間隔にする。 */
function headingDepth(a, f) { if (!a) return 100; if (a.style === 'title') return 0; if (a.style === 'num') return 1 + clamp(a.level | 0, 0, 7); if (a.style === 'sym') return 9 + clamp(a.level | 0, 0, 7); const hl = headingLevel(a.style); if (hl >= 0) return 1 + hl; return 100; }
/* 文章の構造の単位（節）の頭になる行：表題・記号見出し・題のレベルの数字見出しは常に。
   題より深い数字見出し（番号で分けた本文）は、配下に中身（本文・箇条書き・表・さらに深い番号）があるときだけ頭。中身の無い 1 行の番号の行は、囲む節の中の項目
   → Uint8Array（1＝頭）。見出しの前の空き・PowerPoint の箱（書き出しの編集単位）に使う */
function structUnits(doc) {
  const L = doc.lines, N = L.length, f = doc.format, out = new Uint8Array(N);
  const blank = ln => !ln.attrs.figure && !ln.attrs.toc && !ln.attrs.hr && ln.segs.every(s => s.text === '');
  for (let i = 0; i < N; i++) { const a = L[i].attrs;
    if (a.style === 'title' || a.style === 'sym' || (a.style === 'num' && titleLike(a, f))) { out[i] = 1; continue; }
    if (a.style !== 'num') continue; const lv = a.level | 0;
    for (let j = i + 1; j < N; j++) { const b = L[j].attrs; if (b.style === 'title' || b.style === 'sym' || (b.style === 'num' && (b.level | 0) <= lv)) break; if (!blank(L[j])) { out[i] = 1; break; } } }
  return out;
}
FZ.structUnits = structUnits;
/* 見出しの前の空き（構造から引く見た目）。戻り空き＝節の頭の前で、前の行が中身（本文・箇条書き・1 行の番号の項目）か、より深い節の頭のとき 1 行。
   見出しから下の本文・子の見出しへ下りるときは空けない。題の前空き＝中身の後の題の前。空行・区切り線の行の後・ページの頭は空けない（重ねない）。
   戻り空き「区切り線」：大きな節（表題と、文書でいちばん浅い数字・記号見出し）の前の空きの行の真ん中に線を引く → 値は true／'rule' */
function headingGaps(doc) { return withRuleIndex(doc, () => headingGapsBody(doc)); }
function headingGapsBody(doc) {
  const f = doc.format || {}; const N = doc.lines.length; const out = new Array(N).fill(false); if (!f.returnGap && !f.titleGap && !f.titleAfter && !f.tableGap) return out;
  const units = structUnits(doc); let top = Infinity;
  if (f.returnGap === 'rule') for (let i = 0; i < N; i++) { const a = doc.lines[i].attrs; if (units[i] && (a.style === 'num' || a.style === 'sym')) top = Math.min(top, headingDepth(a, f)); }
  let prev = -1, prevBlank = true, prevTitle = false, prevTable = false;
  doc.lines.forEach((ln, i) => {
    const a = ln.attrs || {}; if (f.titleAfter && prevTitle && !prevBlank && a.style !== 'title' && !(ln.segs.length === 1 && ln.segs[0].text === '' && !a.hr && !a.figure && !a.toc && !a.cells)) out[i] = true; // 表題の後空き：表題のすぐ後の行の前に 1 行（表題が続くときは空けない）
    const blank = a.hr || (!a.figure && !a.cells && !a.list && !a.style && !a.toc && ln.segs.length === 1 && ln.segs[0].text === ''); // 区切り線の行は、それ自体が節の区切り
    const isTable = !!a.cells && inTable(doc, i); if (f.tableGap && isTable && !prevTable && i > 0 && !prevBlank) out[i] = true; // 表の前空き：表の直前が中身なら 1 行
    if (blank) { prevBlank = true; prevTitle = false; prevTable = false; return; }
    const d = units[i] ? headingDepth(a, f) : 100;
    if (units[i] && i > 0 && !prevBlank) { let g = false; if (f.returnGap && prev > d) g = true; if (f.titleGap && prev === 100 && (a.style !== 'num' || (a.level | 0) < (f.titleLevels | 0))) g = true;
      if (g) out[i] = f.returnGap === 'rule' && (a.style === 'title' || d === top) ? 'rule' : true; }
    prev = d; prevBlank = false; prevTitle = a.style === 'title'; prevTable = isTable;
  });
  return out;
}
FZ.headingGaps = headingGaps; FZ.headingDepth = headingDepth;
/* 番号付き箇条書きの番号：同じレベルの番号の項目が続く間 1, 2, 3…。浅い項目が来れば深いレベルは数え直し、同じレベルに記号の項目が来れば切れる。
   見出し・本文・表など（空行と「続き」の段落以外）で全部切れる（空行は空きだけ：K-2）。「再開N」で N から。
   戻り値 { ord：番号（番号の項目以外は 0）, fresh：新しい番号の列の頭（Word の番号の実体を分ける） } */
function listNumbering(doc) {
  const L = doc.lines, N = L.length, ord = new Int32Array(N), fresh = new Uint8Array(N); const lc = [], lk = [];
  for (let i = 0; i < N; i++) { const ln = L[i], a = ln.attrs;
    if (a.list) { const k = a.list.kind; if (k === 'cont') continue; const lv = clamp(a.list.level | 0, 0, 7); lc.length = lv + 1; lk.length = lv + 1;
      if (k === 'num') { const cont = lk[lv] === 'num'; if (!cont) lc[lv] = 0; if (a.restart) lc[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; lc[lv] = (lc[lv] || 0) + 1; ord[i] = lc[lv]; let above = false; for (let q = 0; q < lv; q++) if (lk[q] === 'num') above = true; if ((!cont || a.restart) && !above) fresh[i] = 1; lk[lv] = 'num'; }
      else { lk[lv] = k || 'bullet'; lc[lv] = 0; }
      continue; }
    if (!a.style && !a.cells && !a.figure && !a.toc && !a.hr && ln.segs.length === 1 && ln.segs[0].text === '') continue; // 空行
    lc.length = 0; lk.length = 0; }
  return { ord, fresh };
}
FZ.listNumbering = listNumbering;
/* ---------- 和文の番号・記号を起こす（C-3、任意機能） ----------
 * 段落の頭の「１．」「（１）」「①」「第1章」「ア」などを文書の番号体系に照らして数字見出しに、「■」「◆」などを記号見出し体系に照らして記号見出しに、
 * 「・」「－」などを箇条書きにする。頭の全角空白（半角 2 つ）1 つにつき箇条書きのレベルを 1 深くする。番号が数えた値と違えば再開。
 * 体系に無い番号の形は起こさない（本文のまま）。戻り値：起こした行数 */
const JA_NUM_PATS = [
  [/^第([0-9０-９]+)条/, '第1条', 'd'], [/^第([0-9０-９]+)[章節項]?(?=[\s　]|$)/, '第1', 'd'],
  [/^([0-9０-９]+(?:[.．][0-9０-９]+)+)[.．]?(?=[\s　]|$)/, '1.1', 'dots'],
  [/^([0-9０-９]+)[.．](?![0-9０-９.．])/, '1.', 'd'], [/^[（(]([0-9０-９]+)[）)]/, '（1）', 'd'], [/^([0-9０-９]+)[）)]/, '1）', 'd'], [/^([0-9０-９]+)(?=[\s　])/, '1', 'd'],
  [/^([①-⑳㉑-㉟㊱-㊿])/, '①', 'circ'], [/^([ⅰ-ⅻ])[）)]?(?=[\s　]|$)/, 'ⅰ）', 'rl'], [/^([Ⅰ-Ⅻ])[.．]?(?=[\s　]|$)/, 'Ⅰ', 'ru'],
  [/^([A-ZＡ-Ｚ])[.．](?![A-Za-zＡ-Ｚａ-ｚ0-9０-９.．])/, 'A.', 'A'], [/^([a-zａ-ｚ])[）)](?![A-Za-zＡ-Ｚａ-ｚ0-9０-９])/, 'a）', 'a'], [/^[（(]([a-zａ-ｚ])[）)]/, '（a）', 'a'], [/^([a-zａ-ｚ])(?=[\s　])/, 'a', 'a'],
  [/^[（(]([ア-ン])[）)]/, '（ア）', 'kata'], [/^([ア-ン])[.．]?(?=[\s　])/, 'ア', 'kata'], [/^([一二三四五六七八九十]+)[、，.．]?(?=[\s　]|$)/, '一', 'kanji'],
];
function jaNumValue(kind, t) {
  const z = t.replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xfee0)).replace(/[Ａ-Ｚａ-ｚ]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
  if (kind === 'd') return +z; if (kind === 'dots') return +z.split(/[.．]/).pop();
  if (kind === 'circ') { const cp = t.codePointAt(0); return cp >= 0x2460 && cp <= 0x2473 ? cp - 0x2460 + 1 : cp >= 0x3251 && cp <= 0x325f ? cp - 0x3251 + 21 : cp >= 0x32b1 && cp <= 0x32bf ? cp - 0x32b1 + 36 : 1; }
  if (kind === 'rl') return t.codePointAt(0) - 0x2170 + 1; if (kind === 'ru') return t.codePointAt(0) - 0x2160 + 1;
  if (kind === 'A' || kind === 'a') return z.toLowerCase().charCodeAt(0) - 96; if (kind === 'kata') return KATA.indexOf(t) + 1;
  if (kind === 'kanji') { const K = '〇一二三四五六七八九'; if (t === '十') return 10; const m = t.match(/^([一二三四五六七八九])?十?([一二三四五六七八九])?$/); if (!m) return 1; return (t.includes('十') ? (m[1] ? K.indexOf(m[1]) : 1) * 10 : 0) + (m[2] ? K.indexOf(m[2]) : (t.includes('十') ? 0 : K.indexOf(t))); }
  return 1;
}
FZ.jaMarkerAt = function (text) { // 行頭の和文の印 → { kind:'num'|'sym'|'bullet', key|s, value, cut, indent } か null
  const m0 = String(text).match(/^((?:　| {2})*)/); const indent = m0 ? m0[1].replace(/ {2}/g, '　').length : 0; const t = String(text).slice(m0 ? m0[0].length : 0);
  for (const [re, key, kind] of JA_NUM_PATS) { const m = t.match(re); if (m) { const rest = t.slice(m[0].length); const cut = m[0].length + (rest.match(/^[\s　]*/) || [''])[0].length; if (key === 'a' || key === 'ア' || key === '1') { if (!rest.match(/^[\s　]/)) continue; } return { kind: 'num', key, comps: kind === 'dots' ? m[1].split(/[.．]/).length : 1, value: jaNumValue(kind, m[1]), cut: (m0 ? m0[0].length : 0) + cut, indent }; } }
  let m = t.match(/^([■◆●○▲△◇□★☆※◎])[\s　]*/); if (m) return { kind: 'sym', s: m[1], cut: (m0 ? m0[0].length : 0) + m[0].length, indent };
  m = t.match(/^([・･‐‑–—－\-◦▪▫‣⁃∙])[\s　]*/); if (m && (!/^[‐‑–—－\-]$/.test(m[1]) || /[\s　]/.test(t[1] || ''))) return { kind: 'bullet', s: m[1], cut: (m0 ? m0[0].length : 0) + m[0].length, indent };
  return null;
};
FZ.jaMarkerCount = function (text) { let n = 0; for (const l of String(text).replace(/\r/g, '').split('\n')) if (FZ.jaMarkerAt(l)) n++; return n; };
FZ.liftJaMarkers = function (doc) {
  const f = doc.format; const S = normalizeScheme(f.scheme), SY = normalizeScheme(f.symScheme, FZ.DEFAULT_SYM), BU = normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET);
  const numLevel = (key, comps) => { if (key === '1.1') { const k = S.indexOf('1.1'); return k < 0 ? -1 : Math.min(7, k + comps - 2); } return S.indexOf(key); };
  const counters = []; let changed = 0;
  doc.lines.forEach((ln, i) => {
    const a = ln.attrs; if (a.style || a.list || a.cells || a.figure || a.toc || a.code || ln.segs.length !== 1) { if (a.style === 'title') counters.length = 0; return; }
    const sg = ln.segs[0]; let mk = FZ.jaMarkerAt(sg.text);
    if (!mk) { const t = sg.text.trim(); for (let k = 0; k < 8; k++) { const sp = levelSpec(SY[k]); if (sp.type === 'wrap' && t.startsWith(sp.open) && t.endsWith(sp.close) && Array.from(t).length >= 3) { mk = { kind: 'wrap', level: k, close: sp.close, cut: sg.text.indexOf(sp.open) + sp.open.length, indent: 0 }; break; } } } // 体系にある対で囲まれた行（【題】）は囲み見出し
    if (!mk) return;
    let lv;
    if (mk.kind === 'num') { lv = numLevel(mk.key, mk.comps); if (lv < 0) return; counters.length = lv + 1; counters[lv] = (counters[lv] || 0) + 1; if (mk.value !== counters[lv]) { a.restart = mk.value > 1 ? mk.value : true; counters[lv] = mk.value; } a.style = 'num'; a.level = lv; }
    else if (mk.kind === 'wrap') { lv = mk.level; a.style = 'sym'; a.level = lv; sg.text = sg.text.slice(0, sg.text.length - mk.close.length); sg.marks = sg.marks.slice(0, sg.text.length); if (sg.links) FZ.syncLinks(sg); }
    else if (mk.kind === 'sym') { const k = SY.indexOf(mk.s); lv = k >= 0 ? k : 0; a.style = 'sym'; a.level = lv; }
    else { const k = BU.indexOf(mk.s); lv = clamp(Math.max(k >= 0 ? k : 0, mk.indent), 0, 7); a.list = { level: lv }; }
    sg.text = sg.text.slice(mk.cut); sg.marks = sg.marks.slice(mk.cut); if (sg.links) FZ.spliceLinks(sg, 0, mk.cut, 0); changed++;
  });
  return changed;
};
function listMarker(kind, level, ordinal, format) { if (kind === 'arrow') return '→'; if (kind === 'todo') return '❏'; if (kind === 'done') return '☑'; if (kind === 'cont') return ''; const f = format || defaultFormat(); return schemeMarker(f.bulletScheme || FZ.DEFAULT_BULLET, level | 0, 0); }
FZ.listMarker = listMarker;

/* ---------- 組版 ----------
 * layout(doc, opts) → { geo, pages:[{glyphs,carets,rowmap,hrules,vrules,fills,headerGlyphs,footerGlyphs}], lineMap:[{segs:[{rows:[...]}], rows:[{page,y,h}]}] }
 */
/* ---------- 目次 ----------
 * attrs.toc = { num: [from, to] | null, sym: [from, to] | null }（レベルは 0 始まり）。両方 null なら「題のレベル」（番号体系の 1〜題のレベル数）。
 * 目次の行は本文を持たず、組版で見出しの数だけの行に展開する（見出し文字 … 頁）。頁は組版の後に埋める。 */
function normalizeToc(t) { const rng = v => Array.isArray(v) && v.length === 2 ? [clamp(Math.min(v[0] | 0, v[1] | 0), 0, 7), clamp(Math.max(v[0] | 0, v[1] | 0), 0, 7)] : null; return { num: rng(t && t.num), sym: rng(t && t.sym) }; }
function tocRange(t, f) { const T = normalizeToc(t); if (!T.num && !T.sym) T.num = [0, Math.max(0, (f.titleLevels | 0) - 1)]; return T; }
function tocEntries(doc, i, effList) {
  const T = tocRange(doc.lines[i].attrs.toc, doc.format); const out = [];
  doc.lines.forEach((ln, j) => { if (j === i) return; const e = effList[j]; if (!e) return; let indent = -1;
    if (e.kind === 'num' && T.num && e.level >= T.num[0] && e.level <= T.num[1]) indent = e.level - T.num[0];
    else if (e.kind === 'sym' && T.sym && e.level >= T.sym[0] && e.level <= T.sym[1]) indent = (T.num ? T.num[1] - T.num[0] + 1 : 0) + e.level - T.sym[0];
    if (indent < 0) return; out.push({ line: j, indent, level: indent, marker: String(e.text || '').trim(), close: e.close || '', text: ln.segs.map(sg => sg.text).join(''), page: 0 }); });
  return out;
}
FZ.normalizeToc = normalizeToc; FZ.tocRange = tocRange;
/* ---------- 組版 ----------
 * layoutJob(doc, opts, prev)：再開できる組版の仕事。
 *  prepass：番号・記号（effList）、見出しの前の空き、縦罫の表、行ごとの署名（sig：属性・文字・修飾・番号・罫の有無。これが前回と同じ行は同じに組める）
 *  配置：行 i から状態（ページ・行位置・項目の入れ子・字下げの基準）を持って進める。run(maxLines) で途中まで進めて画面に出せる（段階的な読み込み）
 *  後処理：目次の頁番号、罫線・網、柱
 *  prev（前回の lay）があれば：変わっていない前半のページを使い回し、変わった行を含むページから置き直す。置き直しが「きれいなページの頭」に来て、
 *  そこから先の行がすべて前回と同じで、持ち越す状態（項目の入れ子・基準）も同じなら、残りのページも使い回す（キー 1 打で全行を置き直さない） */
/* 見出し飾り（K-3）：行の属性 attrs.deco に名前で持ち、罫・網は組版が名前から引く。手で引いた罫は飾りにならない。
   size は飾りを付けたときに文字に付ける修飾（利用者が後から変えられる文字の書式）。heading：Markdown で # にするか */
const DECO_SPECS = { '中見出し': { heading: true }, '横倍角': { size: 64, heading: true }, '四倍角': { size: 64 | 128, heading: true }, 'ベタ白抜き': { fill: 'dark', heading: true }, 'ベタ2行': { fill: 'dark', size: 64 | 128, heading: true }, '薄網': { fill: 'gray', heading: true }, '地紋斜線': { fill: 'hatch', heading: true }, '地紋点': { fill: 'dots', heading: true }, '罫囲み': { box: 'thin', heading: true }, '太罫下線': { under: 'thick', heading: true }, '二重罫下線': { under: 'double', heading: true }, '細罫下線': { under: 'thin', heading: true }, '袋文字': { size: 64 | 16, heading: true } };
FZ.DECO_SPECS = DECO_SPECS; FZ.decoSpec = n => DECO_SPECS[n] || null;
function marksHash(m) { let h = 0x811c9dc5; for (let q = 0; q < m.length; q++) h = Math.imul(h ^ ((m[q] | 0) + 1), 0x01000193); return h >>> 0; }
/* 行の内容の署名：2 本の 32 ビットのハッシュ（属性・各セグメントの位置・文字・修飾・リンク）。文字列を作らないので GC を起こさない。
   取消の履歴の判定にも使う（内容が同じ行は JSON を作り直さない） */
let HA0 = 0, HA1 = 0; // 作業用（a, b）
function hFold(n) { HA0 = Math.imul(HA0 ^ n, 0x01000193); HA1 = (Math.imul(HA1, 0x5bd1e995) + n) | 0; HA1 ^= HA1 >>> 15; }
function hStr(s) { let a = HA0, b = HA1; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); a = Math.imul(a ^ c, 0x01000193); b = (Math.imul(b, 0x5bd1e995) + c) | 0; b ^= b >>> 15; } HA0 = a; HA1 = b; hFold(0x1f); }
function hAttrs(a) {
  for (const k in a) { const v = a[k]; if (v == null || v === false) continue; hStr(k);
    if (typeof v === 'number') hFold(v * 1000 | 0); else if (v === true) hFold(1); else if (typeof v === 'string') hStr(v);
    else if (k === 'list') { hFold(v.level | 0); if (v.kind) hStr(v.kind); } else hStr(JSON.stringify(v)); }
}
const HA = [0, 0];
function contentHash(ln) {
  HA0 = 0x811c9dc5; HA1 = 0x9e3779b9; const at = ln.attrs; if (at) hAttrs(at);
  for (const sg of ln.segs) {
    let a = HA0, b = HA1; a = Math.imul(a ^ 0x2a, 0x01000193); b = (Math.imul(b, 0x5bd1e995) + (sg.col * 2 | 0)) | 0; b ^= b >>> 15;
    const m = sg.marks; for (let q = 0; q < m.length; q++) { const v = (m[q] | 0) + 1; a = Math.imul(a ^ v, 0x01000193); b = (Math.imul(b, 0x5bd1e995) + v) | 0; b ^= b >>> 15; }
    const t = sg.text; for (let i = 0; i < t.length; i++) { const c = t.charCodeAt(i); a = Math.imul(a ^ c, 0x01000193); b = (Math.imul(b, 0x5bd1e995) + c) | 0; b ^= b >>> 15; }
    HA0 = a; HA1 = b; if (sg.links) hStr(JSON.stringify(sg.links));
  }
  HA[0] = HA0; HA[1] = HA1; return HA;
}
FZ.contentSig = ln => { const h = contentHash(ln); return (h[0] >>> 0) + ':' + (h[1] >>> 0); };
/* 今日の日付（和文）：2026年11月2日 */
FZ.todayJa = (d = new Date()) => `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
/* 資料書式の柱の右側（機密表示・日付と作成者・頁番号）の配置。題はその左に 1 行で入る（titleMax まで） */
function slideHeadInfo(f, geo) {
  const COLS = geo.cols, HY = -geo.bodyTop, HH = geo.headerRows, S2 = 0.8; const glyphs = [], boxes = [], lines = []; // lines：書き出し用（文字・位置・幅）
  const put = (text, col, y, h) => { lines.push({ text, col, y, h, w: textWidth(text) * S2 }); for (const g of graphemes(text)) { const w = baseWidth(g.text) * S2; glyphs.push({ text: g.text, start: -1, end: -1, col, w, marks: 0, y, h, sx: S2, sy: S2, line: -1, seg: 0, off: -1, len: 0, head: true }); col += w; } };
  const pb = f.pageMark === 'none' ? 0 : 3; let right = COLS - pb - (pb ? 1 : 0);
  const date = f.dateAuto ? FZ.todayJa() : String(f.date || ''), author = String(f.author || ''), secret = String(f.secret || ''); // 作成日「自動」：組むたびに今日の日付
  const two = HH >= 2 && date && author; const one = two ? '' : [date, author].filter(Boolean).join('　');
  const bw = two ? Math.max(textWidth(date), textWidth(author)) * S2 : textWidth(one) * S2;
  if (bw > 0) { const col = half(right - bw); if (two) { const y0 = HY + (HH - 2) / 2; put(date, col, y0, 1); put(author, col, y0 + 1, 1); } else put(one, col, HY + (HH - 1) / 2, 1); right = col - 1; }
  let secretBox = null; if (secret) { const sw = textWidth(secret) * S2 + 1; const col = half(right - sw); const bh = Math.min(HH, 1.2); secretBox = { col, y: HY + (HH - bh) / 2, w: sw, h: bh, shape: 'rect', text: secret }; boxes.push(secretBox); const n = lines.length; put(secret, col + 0.5, HY + (HH - 1) / 2, 1); lines.splice(n, 1); right = col - 1; }
  const pbh = Math.min(HH, 1.4); const pageBox = pb ? { col: COLS - pb, y: HY + (HH - pbh) / 2, w: pb, h: pbh, shape: f.pageMark === 'circle' ? 'circle' : 'rect' } : null; // 柱の上下の中ほど（日付と作成者の境目の線）に中心を揃える
  return { glyphs, boxes, lines, secretBox, pageBox, titleMax: Math.max(4, right), HY, HH, S: HH >= 2 ? 1.5 : 1, S2, key: JSON.stringify([date, author, secret, pb, HH]) };
}
let REFLABEL = () => '図 ?'; // 組版中の図番の文字 → 番号（layoutJob が run のたびに差し替える）
function layoutJob(doc, opts = {}, prev = null) { const pv = RIDX; try { return layoutJobBody(doc, opts, prev); } finally { RIDX = pv; } } // 前処理で例外が出ても縦罫の索引を残さない
/* ---------- 工程表（ガントチャート）：表のまま、期間のセルの字から矢羽根を描く ----------
   セルの字：空＝何もない／「→」＝前の矢羽根が延びる（「→［1/4］」はその期間の 1/4 で終わる）／「◆」＝マイルストーン（「◆［3/4］名前」）／
   それ以外＝そこから矢羽根が始まり、字が名前（「［1/2］設計」は期間の半ばから）。位置は［a/b］か［15日］（列が月のとき） */
function ganttPos(t) { let m = t.match(/^[\s　]*[［\[][\s　]*(\d+)[\s　]*[\/／][\s　]*(\d+)[\s　]*[］\]][\s　]*/); if (m && +m[2] > 0) return { f: clamp(+m[1] / +m[2], 0, 1), rest: t.slice(m[0].length) };
  m = t.match(/^[\s　]*[［\[][\s　]*(\d+)[\s　]*日[\s　]*[］\]][\s　]*/); if (m) return { f: clamp((+m[1] - 0.5) / 30.5, 0, 1), rest: t.slice(m[0].length) }; return { f: null, rest: t }; }
function ganttCell(text) { const t = String(text || '').replace(/^[\s　]+|[\s　]+$/g, ''); if (!t) return { kind: 'empty' };
  if (t[0] === '◆' || t[0] === '◇') { const p = ganttPos(t.slice(1)); return { kind: 'ms', f: p.f == null ? 0.5 : p.f, label: p.rest.trim() }; }
  if (/^[→⇒]/.test(t)) { const p = ganttPos(t.slice(1)); return { kind: 'cont', end: p.f }; }
  const p = ganttPos(t); return { kind: 'start', f: p.f == null ? 0 : p.f, label: p.rest.trim() }; }
/* 1 行の期間のセル [{left,right,text}]（左から） → 矢羽根 [{x0,x1,label,c0,c1}] と ◆ [{x,label,c}]（c はセルの番号） */
function ganttRowShapes(cells) { const bars = [], ms = []; let cur = null; const PAD = 0.15; /* 始めは期間の線ちょうど（線と矢羽根の辺が重なる）、終わりは先が次の線に触れないだけ空ける */
  cells.forEach((C, ci) => { const g = ganttCell(C.text), L = C.left, R = C.right, W = R - L;
    if (g.kind === 'empty') { if (cur) { bars.push(cur); cur = null; } return; }
    if (g.kind === 'ms') { if (cur) { bars.push(cur); cur = null; } ms.push({ x: L + g.f * W, label: g.label, c: ci }); return; }
    if (g.kind === 'cont') { if (!cur) cur = { x0: L, x1: R - PAD, label: '', c0: ci, c1: ci }; cur.c1 = ci; if (g.end != null) { cur.x1 = Math.max(cur.x0 + 0.3, L + g.end * W); bars.push(cur); cur = null; } else cur.x1 = R - PAD; return; }
    if (cur) bars.push(cur); cur = { x0: L + (g.f ? g.f * W : 0), x1: R - PAD, label: g.label, c0: ci, c1: ci }; });
  if (cur) bars.push(cur); return { bars, ms }; }
/* 基準の位置（期間の番号 1 始まり＋端数）→ 桁 */
function ganttBaseX(cells, base) { const k = Math.floor(base) - 1, fr = base - Math.floor(base); const c = cells[k]; if (c) return c.left + fr * (c.right - c.left); if (k === cells.length && cells.length) return cells[cells.length - 1].right; return null; }
/* 工程表の年度の段（見出しが 2 段以上のときの 1 段目）：期間のセルの字から右の空のセルまでを 1 つの帯にする。帯の中の縦罫は描かず、字は帯の幅で組む（表の罫は変えない＝原本は表のまま）。
   左の列の見出しは、2 段目の左の列が空なら上下 2 段を 1 つのセルに見せる（間の横罫を描かない） */
function ganttBand(doc, ts, cols) { const ln = doc.lines[ts], G = ln && ln.attrs.gantt; if (!G || (G.heads || 1) < 2) return null; const cells = tableCells(doc, ts, cols), lab = G.labels | 0;
  const txtIn = (l, c) => l ? l.segs.filter(sg => sg.col >= c.left - 1e-6 && sg.col < c.right - 1e-6).map(sg => sg.text).join('').trim() : '';
  const cuts = new Set(), spans = []; let cur = null;
  for (let k = lab; k < cells.length; k++) { const c = cells[k]; if (txtIn(ln, c) || !cur) { cur = { left: c.left, right: c.right, k0: k, k1: k }; spans.push(cur); } else { cuts.add(c.left); cur.right = c.right; cur.k1 = k; } }
  const l2 = doc.lines[ts + 1], lr = lab > 0 && cells[lab - 1] ? cells[lab - 1].right : null; const vmerge = lr != null && !!l2 && cells.slice(0, lab).every(c => !txtIn(l2, c));
  return { cuts, spans, labelsRight: vmerge ? lr : null, left: cells.length ? cells[0].left : 0 }; }
FZ.ganttCell = ganttCell; FZ.ganttRowShapes = ganttRowShapes; FZ.ganttBaseX = ganttBaseX; FZ.ganttBand = ganttBand;
/* 付箋の中身の行（原本の末尾・文机 Markdown の注記で共通）。行に付いていない付箋は書かない */
function notesLines(doc) { const L = []; if (!doc.notes || !doc.notes.length) return L; const used = new Set(); for (const ln of doc.lines.concat(...(doc.parked || []).map(p => p.lines))) for (const id of ln.attrs.notes || []) used.add(id);
  const one = t => String(t || '').replace(/\s+/g, '_') || '-', body = t => String(t || '').split('\n').map(x => /^#/.test(x) ? '\\' + x : x);
  for (const n of doc.notes) { if (!used.has(n.id)) continue; L.push('#付箋 ' + n.id + ' ' + one(n.author) + ' ' + one(n.date) + ' ' + (n.done ? '済' : '未') + (n.quote ? ' 「' + String(n.quote).replace(/[\r\n]+/g, ' ') + '」' : ''), ...body(n.text));
    for (const r of n.replies || []) L.push('#返信 ' + one(r.author) + ' ' + one(r.date), ...body(r.text)); L.push('#付箋ここまで'); }
  return L; }
FZ.notesLines = notesLines;
function layoutJobBody(doc, opts = {}, prev = null) {
  const f = doc.format, geo = geometry(f, opts), COLS = geo.cols, ROWS = geo.rows; const N = doc.lines.length; const BODY = geo.bodyCols; const BANDS = new Map(); const bandOf = ts => { if (!BANDS.has(ts)) BANDS.set(ts, ganttBand(doc, ts, BODY)); return BANDS.get(ts); }; const COL2 = !!geo.cols2; const PG = p => COL2 ? p >> 1 : p; /* 2 段組：組版の頁（段）→ 紙の頁 */
  /* 資料書式：柱（題・管理情報）。柱の題「頁ごと」は表題の行を柱に引き上げて組む（本文の行を使わない） */
  const slideHead = geo.slide && geo.headerRows > 0; const headInfo = slideHead ? slideHeadInfo(f, geo) : null; const liftTitle = slideHead && f.headTitle === 'page'; const HY = -geo.bodyTop, HH = geo.headerRows;
  const images = doc.images || {}; const refIds = doc.refs && doc.refs.ids ? doc.refs.ids : [];
  const IDX = buildRuleIndex(doc); const prevIdx = RIDX; RIDX = IDX; // 前処理の間だけ（「状態」の前で戻す）。run・finish は入るたびに効かせる
  const coverOn = !!(slideHead && f.cover); const PS = f.pageStart == null ? 1 : f.pageStart; /* 表紙の頁は柱を出さない。文書が表題で始まれば、その表題は表紙の題（引き上げない）。次の表題から本文の頁 */
  const coverTpl = coverOn ? (f.coverStyle || '') : ''; /* 表紙の型：std＝中央に題・その下に日付と作成者、toc＝それに目次の箱 */
  const coverTitle = coverOn ? (() => { for (let q = 0; q < N; q++) { const l = doc.lines[q]; if (l.segs.some(sg => sg.text.trim()) || l.attrs.figure || l.attrs.cells) return l.attrs.style === 'title' ? q : -1; } return -1; })() : -1;
  const globalSig = JSON.stringify([geo.cols, geo.rows, geo.W, geo.H, geo.bodyTop, geo.footerTop, !!f.hang, f.font, opts.draft || 0, BODY, geo.slide, liftTitle, headInfo ? headInfo.titleMax : 0, coverOn, coverTpl, !!f.coverSecret, COL2]);
  // ---- prepass：番号・記号 ----
  const ordinals = new Array(N).fill(0); const effList = new Array(N).fill(null); const figLines = []; // 図版を持つ行 [{line, figs}]（文書の順）
  const listOrd = listNumbering(doc).ord; const LS = f.listScheme || FZ.DEFAULT_LIST; // 番号付き箇条書きの番号
  { const counters = [], ordAt = []; const S = f.scheme, SY = f.symScheme || FZ.DEFAULT_SYM, BU = f.bulletScheme || FZ.DEFAULT_BULLET; let lastNum = -1; const symStack = []; // 開いている記号見出し [{lv, parentNum, firstNum}]：仕切り直しは「その記号見出しの節で最初に出た番号レベル」から下を 1 に戻す
    const ancOf = lv => { const a = []; for (let k = 0; k < lv; k++) if (ordAt[k] != null) a.push(ordAt[k]); return a; };
    for (let i = 0; i < N; i++) { const a = doc.lines[i].attrs; if (a.figs) figLines.push({ line: i, figs: a.figs });
      if (a.style === 'num') { const lv = clamp(a.level | 0, 0, 7); if (a.restart) counters[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; counters.length = lv + 1; counters[lv] = (counters[lv] || 0) + 1; ordinals[i] = counters[lv]; ordAt.length = lv; const text = schemeMarker(S, lv, counters[lv], ancOf(lv)); ordAt[lv] = counters[lv]; effList[i] = { kind: 'num', level: lv, text, title: lv < (f.titleLevels | 0) }; while (symStack.length && lv <= symStack[symStack.length - 1].parentNum) symStack.pop(); for (const sy of symStack) if (sy.firstNum == null) sy.firstNum = lv; lastNum = lv; continue; }
      if (a.style === 'sym') { const lv = clamp(a.level | 0, 0, 7); let parentNum = lastNum; while (symStack.length && symStack[symStack.length - 1].lv >= lv) { const p = symStack.pop(); if (p.lv === lv) { parentNum = p.parentNum; if (f.symResetsNum && p.firstNum != null) { counters.length = p.firstNum; ordAt.length = p.firstNum; } } } symStack.push({ lv, parentNum, firstNum: null }); effList[i] = { kind: 'sym', level: lv, text: schemeMarker(SY, lv, 0), close: schemeClose(SY, lv) }; continue; }
      if (a.list) { const lv = clamp(a.list.level | 0, 0, 7); const k = a.list.kind; const text = k === 'arrow' ? '→' : k === 'todo' ? '❏' : k === 'done' ? '☑' : k === 'cont' ? '' : k === 'num' ? schemeMarker(LS, lv, listOrd[i]) : schemeMarker(BU, lv, 0); effList[i] = { kind: 'bullet', level: lv, text, lkind: k }; continue; }
      if (a.style === 'title') { counters.length = 0; ordAt.length = 0; lastNum = -1; symStack.length = 0; } } }
  /* 図版の番号（図・表を別々に、文書の順）と文中の図番の文字 → 番号の文字列 */
  const figNums = (figLines.length || refIds.length) ? FZ.figureNumbers(doc) : null;
  const refLabel = cp => { const id = refIds[cp - REF_BASE]; const n = id != null && figNums ? figNums.get(id) : null; return n ? n.label : (id && id[0] === '§' ? '節 ?' : '図 ?'); };
  const refKey = t => { let k = ''; for (let q = 0; q < t.length; q++) { const cp = t.codePointAt(q); if (cp >= REF_BASE && cp <= REF_MAX) { k += refLabel(cp) + '|'; q++; } } return k; };
  const figDims = (fg, avail) => { const fw = figCells(fg, avail, geo.cw, !fg.chart && images[fg.file] ? FZ.imageSize(images[fg.file]) : null); /* 1/2 は 2 つと間の 1 マスで欄いっぱい */ const sz = fg.chart ? { w: 1, h: fg.chart.ratio || 0.6 } : FZ.imageSize(images[fg.file]); const ih = Math.max(1, Math.min(ROWS - 1, Math.round(fw * geo.cw * sz.h / sz.w / geo.ch))); return { w: fw, ih }; }; /* グラフは縦横の比（高さ÷幅）で */
  const figLabel = fg => { const n = figNums && figNums.get(fg.id); return (n ? n.label : fg.kind + ' ?') + (fg.title ? '　' + fg.title : ''); };
  // 右端に縦罫がある行（表のセル・囲み）：ぶら下げを使わない判定に使う
  const vAt = new Map(); for (const r of doc.rules) if (r.axis === 'v') for (let q = Math.max(0, r.from | 0); q <= Math.min(N - 1, r.to | 0); q++) { if (!vAt.has(q)) vAt.set(q, []); vAt.get(q).push(r.col); }
  const gaps = headingGaps(doc); // 見出しの前の空き（戻り空き・題の前空き）
  /* 表：続いたセルの行を 1 つの表とみなす。tStart／tEnd＝その行の表の先頭／末尾の行。見出し行（先頭の行）の繰り返しは既定で入、先頭の行の「見出し繰り返しなし」で切 */
  const tStart = new Int32Array(N).fill(-1), tEnd = new Int32Array(N).fill(-1);
  for (let q = 0; q < N; q++) if (doc.lines[q].attrs.cells && inTable(doc, q)) tStart[q] = q > 0 && tStart[q - 1] >= 0 ? tStart[q - 1] : q;
  for (let q = N - 1; q >= 0; q--) if (tStart[q] >= 0) tEnd[q] = q + 1 < N && tStart[q + 1] === tStart[q] ? tEnd[q + 1] : q;
  const repOn = ts => ts >= 0 && tEnd[ts] > ts && !doc.lines[ts].attrs.noRepeat;
  /* 霞が関型の区画（V3）：attrs.panels を持つ見出し（項目）の子の節を、横に n 列の区画に並べる。区画は枠と見出しの帯。
     区画の行は頁で割らない（行ごとに入らなければ区画の段の頭で改頁）。表・図・目次・改頁を含む節は区画にしない（ふつうに流す） */
  const panelAt = new Map(), panelGroups = new Map(); /* panelGroups：区画の親の行 → 列の境（画面で境をドラッグして比を変える） */
  { const lvP = a => a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : (a.list && a.list.kind !== 'cont') ? 17 + (a.list.level | 0) : 99;
    for (let g = 0; g < N; g++) { const ga = doc.lines[g].attrs; if (!ga.panels || tStart[g] >= 0 || inTable(doc, g)) continue; const G = lvP(ga); if (G >= 17) continue; /* 区画にするのは見出し（表題・番号・記号）の子 */
      let e = g + 1; while (e < N && lvP(doc.lines[e].attrs) > G) e++;
      let ok = true, cl = 99; for (let q = g + 1; q < e; q++) { const a = doc.lines[q].attrs; if (inTable(doc, q) || a.figure || a.toc || a.breakBefore || a.panels || (liftTitle && a.style === 'title')) { ok = false; break; } const v = lvP(a); if (v < cl) cl = v; }
      if (!ok || cl >= 99) { continue; } const starts = []; for (let q = g + 1; q < e; q++) if (lvP(doc.lines[q].attrs) === cl) starts.push(q);
      const blankL = q => { const l = doc.lines[q]; return l.segs.every(sg => !sg.text.trim()) && !(l.attrs.figs || []).length && !l.attrs.list && !l.attrs.style; }; /* 空の箇条書き（書き込む所）は区画の中に残す */ let e2 = e; const boxL = q => !inTable(doc, q) && (vAt.get(q) || []).length >= 2; while (e2 > starts[starts.length - 1] + 1 && (blankL(e2 - 1) || boxL(e2 - 1))) e2--; /* 区画の後ろの空行は区画の外（区画の下の空き）。1.0.12c 最後の節の末尾の囲みも区画の外 */
      const nWide = ga.panels === 'v' ? 0 : starts.filter(q => doc.lines[q].attrs.panelWide).length; const n = ga.panels === 'v' ? 1 : ga.panels === 'h' ? clamp(starts.length - nWide, 1, 8) : clamp(ga.panels | 0, 2, 6), link = ga.panelLink || null, GAP = link ? 2 : 1, /* つなぎ（矢印・三角）があれば区画の間を 2 マス */ /* 横＝1 段に全部、縦＝1 列に積む、数＝その列数で段を重ねる（m×n） */ W = geo.side ? COLS : BODY, style = ga.panelHead || 'dark'; /* 資料（図表欄あり）でも区画は全幅。区画の図表は区画の中に */ const ps = [];
      /* 1.0.12c 区画比（列の幅の比）と、全幅の区画（段を 1 つ使う） */ const rat = Array.isArray(ga.panelRatio) && ga.panelRatio.length === n && n > 1 ? ga.panelRatio : null; const rtot = rat ? rat.reduce((x, y) => x + y, 0) : n; const edge = c => Math.round((rat ? rat.slice(0, c).reduce((x, y) => x + y, 0) : c) * (W + GAP) / rtot);
      { let c = 0, row = 0; starts.forEach((s0, k) => { const wide = n > 1 && !!doc.lines[s0].attrs.panelWide; if (wide && c > 0) { row++; c = 0; } ps.push({ g, k, s0, s1: k + 1 < starts.length ? starts[k + 1] : e2, row, c: wide ? -1 : c, L: wide ? 0 : edge(c), R: wide ? W : edge(c + 1) - GAP }); if (wide || ++c >= n) { row++; c = 0; } }); }
      panelGroups.set(g, { n, W, GAP, edges: Array.from({ length: n + 1 }, (_, c) => edge(c)), lines: [g + 1, e2 - 1] });
      const rows = []; for (const p2 of ps) (rows[p2.row] = rows[p2.row] || []).push(p2);
      for (const p2 of ps) { const rp = rows[p2.row]; for (let q = p2.s0; q < p2.s1; q++) panelAt.set(q, { ...p2, style, link, vert: n === 1, head: q === p2.s0, first: q === p2.s0, last: q === p2.s1 - 1, rowFirst: q === p2.s0 && rp[0] === p2, rowEnd: q === p2.s1 - 1 && rp[rp.length - 1] === p2, gFirst: q === p2.s0 && p2.k === 0, gEnd: q === p2.s1 - 1 && p2.k === ps.length - 1, rowPanels: rp }); }
      g = e - 1; } }
  const panelEst = ps => { let mx = 1; for (const p2 of ps) { let h = 0; const w = Math.max(2, p2.R - p2.L - 2); for (let q = p2.s0; q < p2.s1; q++) { const ln = doc.lines[q]; const t = ln.segs.map(sg => sg.text).join(''); h += Math.max(1, Math.ceil((textWidth(t) + 2) / w)); for (const fg of ln.attrs.figs || []) h += 1 + figDims(fg, w).ih; } if (h > mx) mx = h; } return mx; };
  /* 1.0.14a プ譜：「プ譜」の節の子の木を、字下げの木を左右逆転した記法で組む（fz-pufu.js）。区画・表の中は対象外 */
  const pfMeasure = (q, L, R, bold) => { const ln = doc.lines[q], a = ln.attrs || {}; const base = bold && !a.thin ? M.BOLD : 0; const hk = []; for (const seg of ln.segs) wrapSeg(seg, L, L, R, false, a, null, L, null, base).forEach((r, k) => { hk[k] = Math.max(hk[k] || 1, r.h || 1); }); return hk.reduce((t, h) => t + h, 0) || 1; }; /* 1.0.14g 列の図：行数を組版と同じ折り返しで数える */
  const pufuAt = FZ.pufuLayoutMap ? FZ.pufuLayoutMap(doc, { L0: 0, R0: geo.side ? COLS : BODY, skip: q => panelAt.has(q) || inTable(doc, q), measure: pfMeasure, rows: ROWS, landscape: !!f.landscape }) : new Map(); const PTW = FZ.PUFU_GEOM ? FZ.PUFU_GEOM.TW : 4.5, PD = FZ.PUFU_GEOM ? FZ.PUFU_GEOM.D : 3;
  // 行の署名。目次の行は載せる見出しの一覧まで含める
  const tocCache = {}; const sigA = new Uint32Array(N), sigB = new Uint32Array(N), csigA = new Uint32Array(N), csigB = new Uint32Array(N);
  for (let i = 0; i < N; i++) { const ln = doc.lines[i]; const h = contentHash(ln); csigA[i] = h[0] >>> 0; csigB[i] = h[1] >>> 0;
    const e = effList[i]; if (e) { hStr(e.kind); hFold(e.level); hStr(e.text); hFold(e.title ? 1 : 0); if (e.lkind) hStr(e.lkind); if (e.close) hStr(e.close); }
    if (tStart[i] >= 0 && tStart[i] < i && repOn(tStart[i])) { hFold(0x5248); hFold(csigA[tStart[i]]); hFold(csigB[tStart[i]]); }
    if (tStart[i] >= 0 && doc.lines[tStart[i]].attrs.gantt) { hFold(0x4754); hStr(JSON.stringify(doc.lines[tStart[i]].attrs.gantt)); hFold(i - tStart[i]); } /* 工程表：表の 1 行目の設定が変われば全行を組み直す */
    { const pf = pufuAt.get(i); if (pf) { hFold(0x5046); hStr(pf.sig); } } /* プ譜：段差・線・枠が変われば組み直す */
    if (gaps[i]) hFold(gaps[i] === 'rule' ? 0x48 : 0x47); const v = vAt.get(i); if (v) { hFold(0x56); for (const c of v) hFold(c * 2 | 0); }
    if (figNums) { for (const sg of ln.segs) if (REF_RE.test(sg.text)) { hFold(0x52); hStr(refKey(sg.text)); } if (ln.attrs.figs) for (const fg of ln.attrs.figs) { hStr(figLabel(fg)); const sz = FZ.imageSize(images[fg.file]); hFold(sz.w | 0); hFold(sz.h | 0); } }
    if (ln.attrs.toc) { const es = tocEntries(doc, i, effList); tocCache[i] = es; hFold(0x54); for (const en of es) { hFold(en.line); hFold(en.indent); hStr(en.marker); hStr(en.text); } }
    sigA[i] = HA0 >>> 0; sigB[i] = HA1 >>> 0; }
  // ---- 前回との差分 ----
  const usable = !COL2 && prev && prev.globalSig === globalSig && prev.sigA && prev.cps; /* 2 段組は毎回はじめから組む（資料は短い） */
  let start = 0, tailFrom = N, delta = 0; // start：最初に変わった行。tailFrom：これ以降の行はすべて前回の（添字−delta の）行と同じ
  if (usable) { const PA = prev.sigA, PB = prev.sigB, PN = PA.length; delta = N - PN; let a = 0; while (a < N && a < PN && sigA[a] === PA[a] && sigB[a] === PB[a]) a++; start = a; let t = N; while (t > start && t - delta > start && t - delta > 0 && sigA[t - 1] === PA[t - 1 - delta] && sigB[t - 1] === PB[t - 1 - delta]) t--; tailFrom = Math.max(t, start); }
  RIDX = prevIdx;
  // ---- 状態 ----
  const pages = [], lineMap = new Array(N), cps = []; // cps[p] = { line, clean, open, headBase, numBase }：ページ p の頭の状態
  let page = null, pi = -1, y = 0, i = 0; const open = []; let headBase = 0, numBase = 0, headMark = -1; // headMark：直前の見出しの頭（印の桁。見出しが無ければ −1）。 open：開いている箇条書き [{lv, col}]。headBase／numBase：直前の見出し／数字見出しの本文開始位置（領域の左端からの相対）
  const tocFix = [], tocs = {}; // 目次：頁番号を後から埋める位置、行番号→見出しの一覧
  let done = false, tailReused = false, endPos = null; const dbg = { start, tailFrom, delta, P: -1, tailAt: -1 };
  let pRowY0 = 0, pRowMax = 0, pSave = null, pfTop = 0; /* pfTop：プ譜の列の図の頭の y（1.0.14g） */ /* 区画：今の段の頭の y・いちばん下・区画に入る前の入れ子の状態 */
  const blankPage = () => ({ glyphs: [], rowmap: new Map(), hrules: [], vrules: [], fills: [], hf: [], images: [], repeats: [], shapes: [] }); /* shapes：工程表の矢羽根・◆・基準の線 */
  const newPage = () => { const p = blankPage(); pages.push(p); return p; };
  let preOpen = open, preHB = 0, preNB = 0, preHM = -1; // 今の行を組む前の状態（ページの頭の記録と、後半の使い回しの比較に使う）
  const advancePage = (clean) => { page = newPage(); pi++; y = 0; cps[pi] = { line: i, clean: !!clean, open: clean ? preOpen : open.slice(), headBase: clean ? preHB : headBase, numBase: clean ? preNB : numBase, headMark: clean ? preHM : headMark }; };
  /* 改頁・柱の題・表紙の後：2 段組では紙の頁を変える（左の段にいれば右の段を空のまま飛ばす） */
  const hardPage = (clean) => { if (COL2 && !(pi & 1)) { newPage(); pi++; cps[pi] = { line: i, clean: false, open: open.slice(), headBase, numBase, headMark }; } advancePage(clean); };
  const inRight = () => COL2 && (pi & 1) === 1;
  const placeRow = (li, k, rowH, segRows) => { // 1物理行を現在の page/y に置く
    lineMap[li].rows.push({ page: pi, y, h: rowH, k });
    for (const sr of segRows) {
      const r = sr.row; r.page = pi; r.y = y; r.h = rowH;
      for (const g of r.glyphs) { g.page = pi; g.y = y; g.h = rowH; g.line = li; g.seg = sr.s; g.off = g.start; g.len = g.end - g.start; g.sy = scaleH(g.marks); g.sx = scaleW(g.marks); page.glyphs.push(g); }
      const entry = { line: li, seg: sr.s, k: r.k, y, page: pi, h: rowH, startCol: r.startCol, endCol: r.endCol, left: r.left, right: r.right, carets: r.carets, startOff: r.startOff, endOff: r.endOff }; if (sr.cell) entry.cell = true;
      if (!page.rowmap.has(y)) page.rowmap.set(y, []); page.rowmap.get(y).push(entry);
    }
    y += rowH;
  };
  // ---- 前半の使い回し：変わった行 start を含む「きれいなページ」の頭から置き直す ----
  if (usable && start > 0) {
    let P = -1; for (let p = 0; p < prev.cps.length; p++) { const cp = prev.cps[p]; if (cp.clean && cp.line < start) P = p; else if (cp.line >= start) break; } // ページの頭の行が変わっていないなら、そこで改ページした判断も同じ
    if (P > 0) { const cp = prev.cps[P]; dbg.P = P;
      for (let p = 0; p < P; p++) { const pg = prev.pages[p]; cleanPage(pg); pages.push(pg); cps[p] = prev.cps[p]; }
      for (let q = 0; q < cp.line; q++) lineMap[q] = prev.lineMap[q];
      for (const t of prev.tocFix || []) if (t.tocLine < cp.line) tocFix.push(t); for (const k in tocCache) if (+k < cp.line) tocs[k] = tocCache[k];
      pi = P - 1; i = cp.line; open.push(...cp.open.map(o => ({ lv: o.lv, col: o.col }))); headBase = cp.headBase; numBase = cp.numBase; headMark = cp.headMark ?? -1; }
  }
  preOpen = open.slice(); preHB = headBase; preNB = numBase; preHM = headMark; advancePage(true);
  const regionFor = () => ({ left: 0, right: BODY }); // 資料書式では本文欄だけ
  // ---- 後半の使い回し：きれいなページの頭で、前回の同じ行から先が全部同じなら、残りのページを前回から持ってくる ----
  const tryReuseTail = () => {
    if (!usable || i < tailFrom || i >= N || y !== 0 || page.glyphs.length || page.rowmap.size) return false;
    const pp = prev.cpByLine.get(i - delta); if (pp == null) return false; const cp = prev.cps[pp]; if (!cp.clean || cp.headBase !== preHB || cp.numBase !== preNB || (cp.headMark ?? -1) !== preHM || cp.open.length !== preOpen.length) return false;
    for (let k = 0; k < preOpen.length; k++) if (preOpen[k].lv !== cp.open[k].lv || preOpen[k].col !== cp.open[k].col) return false;
    const pageDelta = pi - pp; pages.pop(); // 今作った空のページを捨てて前回のページに差し替える
    const upto = prev.done ? N : prev.placed + delta; // 前回が途中までなら、置いてあった所まで使い、その続きから組む
    for (let p = pp; p < (prev.bodyPages ?? prev.pages.length); p++) { const pg = prev.pages[p]; cleanPage(pg); if (pageDelta || delta) shiftPage(pg, pageDelta, delta); pages.push(pg); const c = prev.cps[p]; cps[p + pageDelta] = { line: c.line + delta, clean: c.clean, open: c.open, headBase: c.headBase, numBase: c.numBase, headMark: c.headMark }; }
    for (let q = i; q < upto; q++) { const lm = prev.lineMap[q - delta]; if (pageDelta) { for (const r of lm.rows) r.page += pageDelta; for (const sl of lm.segs) for (const r of sl.rows) r.page += pageDelta; if (lm.figParts) for (const p of lm.figParts) p.page += pageDelta; } lineMap[q] = lm; } /* 1.0.14f 頁に分けた図の部分の頁も */
    for (const t of prev.tocFix || []) if (t.tocLine >= i - delta && t.tocLine + delta < upto) tocFix.push({ ...t, page: t.page + pageDelta, tocLine: t.tocLine + delta }); /* 載せる見出しの行番号は署名が同じ＝同じなので動かさない */ for (const k in tocCache) if (+k >= i && +k < upto) tocs[k] = tocCache[k];
    dbg.tailAt = i; pi = pages.length - 1; page = pages[pi];
    if (prev.done) { const ep = prev.endPos; endPos = { page: ep.page + pageDelta, y: ep.y }; i = N; tailReused = true; return true; }
    const es = prev.endState; y = es.y; pfTop = es.pfTop || 0; open.length = 0; for (const o of es.open) open.push({ lv: o.lv, col: o.col }); headBase = es.headBase; numBase = es.numBase; headMark = es.headMark ?? -1; i = upto; return true;
  };
  // ---- 配置 ----
  /* 柱に引き上げる表題（資料書式・柱の題「頁ごと」）：1 行で、1.5 倍・太字。入りきらない分は … で切る */
  const placeHeadTitle = (li, ln, a) => {
    const S = headInfo.S, maxC = headInfo.titleMax, base = a.thin ? 0 : M.BOLD; let at = 0; const segRows = [];
    lineMap[li] = { rows: [{ page: pi, y: HY, h: HH, k: 0 }], segs: [] };
    ln.segs.forEach((seg, s) => {
      const r = wrapSeg(seg, at, at, 1e6, false, a, null, at, null, base)[0];
      for (const g of r.glyphs) { g.col *= S; g.w *= S; } for (const c of r.carets) c.col *= S; r.startCol *= S; r.endCol *= S; r.left = 0; r.right = maxC; r.h = HH; r.k = 0;
      if (r.endCol > maxC + 1e-6) { const lim = maxC - S; let cutAt = null; for (const g of r.glyphs) if (g.col + g.w > lim + 1e-6) { g.hidden = true; if (cutAt == null) cutAt = g.col; } r.glyphs.push({ text: '…', start: -1, end: -1, col: cutAt ?? lim, w: S, marks: base, marker: true }); for (const c of r.carets) if (c.col > lim) c.col = lim; r.endCol = Math.min(r.endCol, maxC); }
      at = r.endCol / S + 1; lineMap[li].segs.push({ rows: [r] }); segRows.push({ s, r });
    });
    const tg = [];
    for (const { s, r } of segRows) { r.page = pi; r.y = HY;
      for (const g of r.glyphs) { g.page = pi; g.y = HY; g.h = HH; g.line = li; g.seg = s; g.off = g.start; g.len = g.end - g.start; g.sx = S * scaleW(g.marks); g.sy = S; g.headTitle = true; if (!g.hidden) { page.glyphs.push(g); tg.push(g); } }
      if (!page.rowmap.has(HY)) page.rowmap.set(HY, []); page.rowmap.get(HY).push({ line: li, seg: s, k: 0, y: HY, page: pi, h: HH, startCol: r.startCol, endCol: r.endCol, left: 0, right: maxC, carets: r.carets, startOff: r.startOff, endOff: r.endOff, head: true }); }
    page.titleLine = li; page.titleGlyphs = tg;
  };
  /* 図版を本文の流れに置く（図表欄の無い書式）：行の後に、番号と題の 1 行＋画像の行。入らなければ次のページへ */
  const placeInlineFigs = (li, figs, region, noBreak) => {
    const avail = region.right - region.left;
    /* 1.0.11e：続く図版は入るだけ横に並べ（間は 1 マス）、並びごと欄の中ほどに。1/2 の 2 つは欄いっぱい */
    const q = figs.map(fg => ({ fg, d: figDims(fg, avail) }));
    while (q.length) { const band = []; let used = 0; for (const it of q) { if (band.length && used + 1 + it.d.w > avail) break; band.push(it); used += (band.length > 1 ? 1 : 0) + it.d.w; } q.splice(0, band.length);
      const ih = Math.max(...band.map(b => b.d.ih)), need = 1 + ih; if (!noBreak && y + need > ROWS && y > 0) advancePage(false);
      let col = region.left + half((avail - used) / 2);
      for (const { fg, d } of band) { capGlyphs(page.glyphs, figLabel(fg), col, col + d.w, y, pi, { line: li, figcap: true });
        page.images.push({ id: fg.id, file: fg.file, col, y: y + 1, w: d.w, h: noBreak ? d.ih : Math.min(d.ih, ROWS - y - 1), line: li, title: fg.title, kind: fg.kind, chart: fg.chart || null }); col += d.w + 1; }
      y += noBreak ? need : Math.min(need, ROWS - y); }
  };
  /* 工程表の 1 行：期間のセルの字を隠し（g.gh）、矢羽根・◆・基準の線を頁の shapes に置く（行の最初の頁に、行の高さいっぱい） */
  const ganttRow = (i, sls, GC) => { const ts = tStart[i], G = ts >= 0 ? doc.lines[ts].attrs.gantt : null; if (!G || i - ts < (G.heads || 1) || !GC) return;
    const rows = lineMap[i].rows; if (!rows.length) return; const r0 = rows[0], P = r0.page, pgx = pages[P]; if (!pgx) return; let h = 0; for (const r of rows) if (r.page === P) h += r.h;
    const cells = GC.slice(G.labels | 0).map(c => { const sl = sls.find(x => Math.abs(x.left - c.left) < 1e-6); return { left: c.left, right: c.right, text: sl ? sl.seg.text : '', sl }; });
    for (const c of cells) if (c.sl) for (const r of c.sl.rows) for (const g of r.glyphs) g.gh = 1;
    const { bars, ms } = ganttRowShapes(cells);
    for (const b of bars) pgx.shapes.push({ kind: 'bar', x0: b.x0, x1: b.x1, y: r0.y, h, label: b.label, line: i, c0: b.c0, c1: b.c1 });
    const xr = cells.length ? cells[cells.length - 1].right : null; for (const m of ms) pgx.shapes.push({ kind: 'ms', x: m.x, y: r0.y, h, label: m.label, line: i, c: m.c, xr }); /* xr：表の右端（名前がはみ出すなら ◆ の左に） */
    if (G.base != null) { const bx = ganttBaseX(cells, G.base); if (bx != null) pgx.shapes.push({ kind: 'base', x: bx, y: r0.y, h, first: i - ts === (G.heads || 1), line: i }); } };
  /* 1.0.14a プ譜の 1 行：箱（役の札・帯の網）・枠の太罫・背骨と枝。矢印は親へ（施策 → 中間目的 → 勝利条件）。印刷にも出る（deco） */
  const pufuRow = (pf, li, k, n, y0, h, pg, gap = 0) => {
    const y1 = y0 + h, first = k === 0, last = k === n - 1, atTop = y0 === 0, id = 'pf' + li + ':' + k + ':';
    const H = (yy, a, b, kind, sfx) => pg.hrules.push({ id: id + sfx, y: yy, from: a, to: b, kind, line: li, deco: true });
    const V = (x, ya, yb, kind, sfx, head) => pg.vrules.push({ id: id + sfx, col: x, y1: ya, y2: yb, kind, dir: 'u', from: li, to: li, headTop: !!head, headBottom: false, deco: true });
    if (pf.fill) pg.fills.push({ id: id + 'f', col: pf.bx0, cols: pf.bx1 - pf.bx0, y1: y0, y2: y1, shade: pf.fill, from: li, to: li, deco: true });
    if (pf.tagShade) pg.fills.push({ id: id + 'tf', col: pf.bx0, cols: PTW, y1: y0, y2: y1, shade: pf.tagShade, from: li, to: li, deco: true });
    if (pf.box) {
      if ((first && pf.top) || atTop) H(y0, pf.bx0, pf.bx1, pf.topKind, 'bt');
      if (last && (pf.end || pf.frameEnd)) H(y1, pf.bx0, pf.bx1, pf.frameEnd ? 'thick' : pf.bottomKind, 'bb');
      V(pf.bx0, y0, y1, pf.sideKind, 'bl'); V(pf.bx1, y0, y1, pf.sideKind, 'br');
      if (pf.tag != null || pf.tagShade) V(pf.bx0 + PTW, y0, y1, 'thin', 'tv'); }
    if (first && pf.bullet != null) pg.glyphs.push({ text: '・', start: -1, end: -1, col: pf.bullet, w: 1, marks: 0, page: pi, y: y0, h: 1, line: li, seg: 0, off: -1, len: 0, sx: 1, sy: 1, deco: true, pufuTag: true }); /* 1.0.14g 列の図の段取り：施策の箱の中の「・」 */
    if (first && pf.tag) { const w0 = textWidth(pf.tag), k = w0 > PTW - 0.3 ? (PTW - 0.3) / w0 : 1; /* 1.0.16h 長い名前（見せる名前）は長体で札に収める */ const w = w0 * k; let col = pf.bx0 + Math.max(0, (PTW - w) / 2); for (const g of graphemes(pf.tag)) { const gw = baseWidth(g.text) * k; pg.glyphs.push({ text: g.text, start: -1, end: -1, col, w: gw, marks: pf.tagBold ? M.BOLD : 0, page: pi, y: y0, h: 1, line: li, seg: 0, off: -1, len: 0, sx: k, sy: 1, deco: true, pufuTag: true }); col += gw; } }
    for (const fr of pf.frames) { V(fr.x0, y0, y1, 'thick', 'fl' + fr.x1); V(fr.x1, y0, y1, 'thick', 'fr' + fr.x1); if (atTop) H(y0, fr.x0, fr.x1, 'thick', 'ft' + fr.x1); if (last && fr.end) H(y1, fr.x0, fr.x1, 'thick', 'fb' + fr.x1); }
    const ext = first && gap > 0 && y0 - gap >= 0; /* 上の空きを背骨が通る。矢じりは空きの上（親の箱の下） */
    if (ext) for (const fr of pf.frames) { V(fr.x0, y0 - gap, y0, 'thick', 'gl' + fr.x1); V(fr.x1, y0 - gap, y0, 'thick', 'gr' + fr.x1); } /* 取組の中の空き：囲みの左右を通す */
    for (const sp of pf.spines) { if (ext) V(sp.x, y0 - gap, y0, sp.head ? 'arrow' : 'thin', 'sg' + sp.x, sp.head); const hd = sp.head && first && !ext; if (sp.half) { if (first) V(sp.x, y0, y0 + Math.min(h, 1) / 2, hd ? 'arrow' : 'thin', 'sp' + sp.x, hd); } else V(sp.x, y0, y1, hd ? 'arrow' : 'thin', 'sp' + sp.x, hd); }
    if (first && pf.tick) H(y0 + Math.min(h, 1) / 2, pf.tick.x0, pf.tick.x1, 'thin', 'tk');
    if (pf.insight) { const a = pf.L - 0.25, b = pf.R + 0.25, t = first ? y0 + 0.12 : y0, u = last ? y1 - 0.12 : y1; pg.fills.push({ id: id + 'if', col: a, cols: b - a, y1: t, y2: u, shade: 'text', from: li, to: li, deco: true }); if (first) H(t, a, b, 'dotted', 'it'); if (last) H(u, a, b, 'dotted', 'ib'); V(a, t, u, 'dotted', 'il'); V(b, t, u, 'dotted', 'ir'); } /* 1.0.14e 気づき：箱の中の点線の吹き出し */
  };
  /* 1.0.14g プ譜の列の図：列の名前の帯（墨に白抜き）・矢印（施策 → 中間目的 → 勝利条件 → 獲得目標）・取組の太罫。図の最初の行で一度に置く（印刷にも出る） */
  const pufuFig = (pf, li) => { const D = pf.fig.deco; if (!D) return; const id = 'pfx' + li + ':'; let n = 0; const Y = v => pfTop + v;
    for (const h of D.heads) { page.fills.push({ id: id + (n++), col: h.x0, cols: h.x1 - h.x0, y1: Y(h.y0), y2: Y(h.y1), shade: 'ink', from: li, to: li, deco: true }); const w = textWidth(h.text); let col = h.x0 + Math.max(0, (h.x1 - h.x0 - w) / 2); const gy = Y(h.y0 + Math.floor((h.y1 - h.y0 - 1) / 2));
      for (const g of graphemes(h.text)) { const gw = baseWidth(g.text); page.glyphs.push({ text: g.text, start: -1, end: -1, col, w: gw, marks: M.BOLD, page: pi, y: gy, h: 1, line: li, seg: 0, off: -1, len: 0, sx: 1, sy: 1, deco: true, pufuTag: true }); col += gw; } }
    for (const r of D.hrules) page.hrules.push({ id: id + (n++), y: Y(r.y), from: r.from, to: r.to, kind: r.kind, dir: r.dir, line: li, deco: true });
    for (const r of D.vrules) page.vrules.push({ id: id + (n++), col: r.col, y1: Y(r.y1), y2: Y(r.y2), kind: r.kind, dir: r.dir === 'd' ? 'd' : 'u', from: li, to: li, headTop: r.dir === 'u', headBottom: r.dir === 'd', deco: true }); };
  function run(maxLines = Infinity) { const pv = RIDX; RIDX = IDX; try { return runBody(maxLines); } finally { RIDX = pv; } }
  function runBody(maxLines) {
    if (done) return true; let budget = maxLines; REFLABEL = refLabel;
    for (; i < N && budget > 0; i++, budget--) {
      preOpen = open.slice(); preHB = headBase; preNB = numBase; preHM = headMark;
      if (tryReuseTail()) break;
      const ln = doc.lines[i], a = ln.attrs || {};
      lineMap[i] = { rows: [], segs: [] }; const W = lineMap[i].why = {}; /* P10 配置の理由：組版が実際に採った決まり（pos・bold・num・brk）。画面の「配置の理由」が読む。印刷には出ない */
      const pp = panelAt.get(i); const pf = pp ? null : pufuAt.get(i); /* 1.0.14a プ譜の行 */
      if (pp && pp.first) { /* 区画の頭：段の頭なら入るか見て、区画ごとに段の頭の y から組む。入れ子は区画の中で数え直す */
        if (pp.rowFirst) { if (pp.gFirst) pSave = { open: open.slice(), headBase, numBase, headMark }; else y = pRowMax + 1;
          const est = panelEst(pp.rowPanels); if (y > 0 && y + est > ROWS && est <= ROWS) { W.brk = { why: `区画の段（横に並ぶ区画）が頁の残りに入らない。段の高さは最も長い区画で決まる（およそ ${Math.ceil(est)} 行）`, own: null }; advancePage(false); } pRowY0 = y; pRowMax = y; }
        else y = pRowY0;
        open.length = 0; headBase = 0; numBase = 0; headMark = -1; }
      // 見出し・表題で項目の入れ子を閉じる。空行は空きだけで、入れ子を切らない（K-2）。説明文の段落も入れ子を保つ
      if (!effList[i] || effList[i].kind !== 'bullet') { if (isHeading(a) || a.style === 'title') open.length = 0; if (a.style === 'title') { headBase = 0; numBase = 0; headMark = -1; } }
      if (coverTpl && pi === 0) { const ct = Math.max(1, Math.round(ROWS * 0.26)); if (i === coverTitle) { if (y < ct) y = ct; } else if (coverTitle < 0 || i > coverTitle) { hardPage(true); if (tryReuseTail()) break; } } /* 表紙の型：題は表紙の中ほど、本文は次の頁から */
      if (a.breakBefore && (y > 0 || inRight())) { W.brk = { why: 'ここから改頁（この行の指定）', own: 'breakBefore' }; hardPage(true); if (tryReuseTail()) break; }
      const pff = pf && pf.fig; if (pff) { if (pff.first) { if (y > 0 && y + pff.H > ROWS) { W.brk = { why: 'プ譜の列の図は頁で割らない：頁の残りに入らないので次の頁へ', own: null }; advancePage(true); if (tryReuseTail()) break; } pfTop = y; pufuFig(pf, i); } y = pfTop + pff.dy; } /* 1.0.14g 列の図：図の頭からの位置に置く */
      let pfGap = 0; if (pf && pf.gapAbove && y > 0) { y += pf.gapAbove; pfGap = pf.gapAbove; } /* プ譜：獲得目標と勝利条件・勝利条件と取組・取組と取組・木と資源と制約の間を 1 行空ける（頁の頭では空けない） */
      let pfPair = null; if (pf && pf.pair === 1) { const pm = lineMap[i - 1]; const r0 = pm && pm.rows[0]; if (r0 && r0.page === pi) { pfPair = { y0: y }; y = r0.y; } } /* 資源と制約の右の列：左の項目と同じ高さから */
      let region0 = pp ? { left: pp.L + 1, right: pp.R - 1 } : pf ? { left: pf.L, right: pf.R } : coverTpl && i === coverTitle ? { left: 0, right: COLS } : regionFor(i); /* 表紙の型の題は頁の全幅の中央 */
      if (!pp && !pf && !inTable(doc, i)) { const vv = vAt.get(i); if (vv && vv.length >= 2) { const lo = Math.min(...vv), hi = Math.max(...vv); if (hi - lo >= 4 && lo >= -1e-6 && hi <= (geo.side ? COLS : region0.right) + 1e-6 && (lo > region0.left + 1e-6 || hi < region0.right - 1e-6)) region0 = { left: lo, right: hi }; } } /* 1.0.12c 位置と幅のある囲み：左右の縦罫の間に組む */ const qd = clamp(a.quote | 0, 0, 8);
      const region = qd && !pf && !inTable(doc, i) ? { left: Math.min(region0.right - 2, region0.left + 2 * qd), right: region0.right } : region0; // 引用：2 マス／段の字下げ（左に引用の線）
      if (a.figure && FZ.figureLayout) { // 図ブロック：高さ h 行を占め、箱・矢印・レーンを罫線／網／文字として置く
        const F = a.figure, h = Math.max(1, F.h | 0);
        /* 頁の残りに入らない図：1 頁に入るなら次の頁へ送る。1 頁より高い図（1.0.14f）は、残りが 4 分の 1 頁以上あればここから描き始め、続きを次の頁に描く */
        if (y + h > ROWS && y > 0 && (h <= ROWS || !FZ.figureCuts || ROWS - y < Math.max(4, Math.ceil(ROWS / 4)))) { W.brk = { why: h <= ROWS ? '図は頁で割らない：頁の残りに入らないので次の頁へ' : '1 頁より高い図：頁の残りが少ないので次の頁から描く', own: null }; advancePage(true); if (tryReuseTail()) break; }
        const L2 = region.left, R2 = region.right; const parts = y + h > ROWS && FZ.figureCuts ? FZ.figureCuts(F, R2 - L2, ROWS - y, ROWS) : [[0, h]];
        if (parts.length > 1) W.split = `図が 1 頁に入らないので、${parts.length} 頁に分けて描く（箱をまたがない行の境で切る）`;
        const carets = [{ off: 0, col: L2 }]; lineMap[i] = { rows: [], segs: [{ rows: [] }], figParts: [], why: W };
        parts.forEach(([f0, f1], k) => { if (k > 0) advancePage(false);
          const Y0 = y, ph = f1 - f0; const fg = FZ.figureLayout(parts.length > 1 ? FZ.figureSlice(F, R2 - L2, f0, f1) : F, L2, R2); const pfx = 'fig' + i + ':' + (k ? k + ':' : '');
          for (const g of fg.glyphs) page.glyphs.push({ ...g, y: Y0 + g.dy, h: 1, page: pi, line: i, seg: 0, off: -1, len: 0, sx: 1, sy: 1 });
          for (const r of fg.hrules) page.hrules.push({ id: pfx + r.id, y: Y0 + r.y, from: r.from, to: r.to, kind: r.kind, dir: r.dir, line: i, fig: true });
          for (const r of fg.vrules) page.vrules.push({ id: pfx + r.id, col: r.col, y1: Y0 + r.y1, y2: Y0 + r.y2, kind: r.kind, dir: r.dir, from: i, to: i, headTop: true, headBottom: true, fig: true });
          for (const x of fg.fills) page.fills.push({ id: pfx + x.id, col: x.col, cols: x.cols, y1: Y0 + x.y1, y2: Y0 + x.y2, shade: x.shade, from: i, to: i, fig: true });
          const row = { glyphs: [], carets, startCol: L2, endCol: L2, startOff: 0, endOff: 0, h: ph, left: L2, right: R2, k, page: pi, y: Y0, fig: true };
          lineMap[i].rows.push({ page: pi, y: Y0, h: ph, k }); lineMap[i].segs[0].rows.push(row); lineMap[i].figParts.push({ page: pi, y0: Y0, f0, f1 });
          for (let q = 0; q < ph; q++) { const yy = Y0 + q; if (!page.rowmap.has(yy)) page.rowmap.set(yy, []); page.rowmap.get(yy).push({ line: i, seg: 0, k, y: Y0, page: pi, h: ph, startCol: L2, endCol: L2, left: L2, right: R2, carets, startOff: 0, endOff: 0, fig: true }); }
          y += ph; });
        open.length = 0; continue;
      }
      if (a.toc) { // 目次ブロック：見出し 1 つにつき 1 行（字下げ・番号・文字 … 頁）。1 ページに収まるなら切らない
        const entries = tocCache[i] || tocEntries(doc, i, effList); tocs[i] = entries; const L2 = region.left, R2 = region.right; const n = Math.max(1, entries.length);
        if (y > 0 && y + n > ROWS && n <= ROWS) { advancePage(true); if (tryReuseTail()) break; }
        const carets = [{ off: 0, col: L2 }]; const segRows = []; let cur = null;
        const put = (text, col, marks) => { const w = baseWidth(text); page.glyphs.push({ text, start: -1, end: -1, col, w, marks, page: pi, y, h: 1, line: i, seg: 0, off: -1, len: 0, sx: 1, sy: 1, toc: true }); return w; };
        for (let k = 0; k < n; k++) {
          if (y >= ROWS) advancePage(k === 0);
          if (!cur || cur.page !== pi) { cur = { glyphs: [], carets, startCol: L2, endCol: L2, startOff: 0, endOff: 0, h: 0, left: L2, right: R2, k: segRows.length, page: pi, y, block: true }; segRows.push(cur); lineMap[i].rows.push({ page: pi, y, h: 0, k: cur.k }); }
          const ent = entries[k];
          if (!ent) { let col = L2; for (const g of graphemes('（目次：載せる見出しがありません）')) col += put(g.text, col, 0); }
          else { let col = L2 + Math.min(ent.indent, Math.max(0, R2 - L2 - 8)); const maxEnd = R2 - 4; const mk = String(ent.marker || '').trim(); const text = ent.close ? mk + ent.text + ent.close : (mk ? mk + ' ' : '') + ent.text;
            for (const g of graphemes(text)) { const w = baseWidth(g.text); if (col + w > maxEnd - 1) { col += put('…', col, 0); break; } col += put(g.text, col, 0); }
            for (let c = Math.ceil(col); c <= R2 - 3; c++) put('…', c, 0);
            tocFix.push({ page: pi, y, right: R2, line: ent.line, tocLine: i, k }); }
          if (!page.rowmap.has(y)) page.rowmap.set(y, []); page.rowmap.get(y).push({ line: i, seg: 0, k: cur.k, y: cur.y, page: pi, h: 1, startCol: L2, endCol: L2, left: L2, right: R2, carets, startOff: 0, endOff: 0, block: true });
          cur.h++; lineMap[i].rows[cur.k].h++; y++;
        }
        lineMap[i].segs = [{ rows: segRows }]; open.length = 0; continue;
      }
      if (liftTitle && a.style === 'title' && !inTable(doc, i) && i !== coverTitle) { // 柱の題（頁ごと）：表題はページの頭に来て柱に入る
        if (y > 0 || page.titleLine != null || inRight()) { hardPage(true); if (tryReuseTail()) break; }
        placeHeadTitle(i, ln, a); open.length = 0; continue; }
      const table = inTable(doc, i); const TBW = table && geo.side && vRulesAt(doc, i).some(r => r.col > BODY + 1e-6) ? COLS : BODY; /* 1.0.12b 資料（図表欄あり）で本文欄より広い表は、区画と同じく全幅 */
      // 各セグメントを組む
      const GT = table && tStart[i] >= 0 ? doc.lines[tStart[i]].attrs.gantt : null; const gBody = !!GT && i - tStart[i] >= (GT.heads || 1); const gB = GT && i === tStart[i] ? bandOf(i) : null; /* 年度の段：帯の幅で組み、中央に */ const GC = gBody ? tableCells(doc, i, BODY) : null; const gIdx = col => GC.findIndex(c => col >= c.left - 1e-6 && col < c.right - 1e-6); /* 工程表の期間のセル：折り返さない（字は隠して矢羽根を描く） */
      const segLayouts = ln.segs.map((seg, s) => {
        let left, right, firstL, contL, marker = null, tail = null, bodyShift = 0;
        if (table) { const c = cellFor(doc, i, seg.col, TBW); left = c.left; right = c.right; firstL = contL = left; if (CELL_BUL.test(seg.text)) contL = Math.min(right - 1, left + textWidth(seg.text[0])); } /* 1.0.12b セルの字が「・」で始まれば、2 行目からは「・」の後ろに揃える（セルの中の箇条書き） */
        else { left = region.left; right = region.right; const indent = clamp(a.indent | 0, 0, right - left - 1); firstL = left + indent; contL = left + clamp(a.hanging | 0, 0, right - left - 1); if (a.hanging == null) contL = firstL; if (a.hanging != null && a.hanging < indent) contL = left + (a.hanging | 0);
          const fb = f.bodyFollow === 'mark' ? Math.max(0, headMark) : f.bodyFollow === 'step' ? (headMark >= 0 ? headMark + 1 : 0) : headBase; /* 見出しの頭／頭＋1 字（既定）／文字 */ if (pf) { firstL = contL = left; } else if (f.bodyFollow && !effList[i] && a.indent == null && a.style !== 'speech' && a.style !== 'title' && fb) { const bb = Math.min(fb, right - left - 4); firstL += bb; contL += bb; bodyShift = bb; } } // 本文を見出しの文字位置に揃える（K-7）
        const eff = pf ? null : effList[i];
        const base = pf ? ((pf.bold && !a.thin) ? M.BOLD : 0) : ((!table && !a.thin && (a.style === 'title' || (pp && pp.head) || (eff && (eff.kind === 'sym' || (eff.kind === 'num' && eff.title))))) ? M.BOLD : 0) | (coverTpl && i === coverTitle && !seg.marks.some(m => (m & SIZE_BITS)) ? (M.WIDE | M.TALL) : 0); /* 表紙の型の題は四倍角（字に倍角を付けていなければ） */ // 題の太字（組版が付ける見た目。K-1）
        /* 位置とレベルは別：見出し・箇条書きの行頭の桁は、位置（attrs.indent）が明示されていればその桁、無ければレベルから決まる自然な桁 */
        const pos = (eff && s === 0 && !table && pp && pp.head) ? left : (eff && s === 0 && !table && a.indent != null) ? left + clamp(a.indent | 0, 0, Math.max(0, right - left - 2)) : null; /* 区画の見出しは区画の左から */
        if (eff && s === 0 && !table) { const lv = eff.level; const mk = eff.text; let lm = 0; { const t = seg.text, m = seg.marks; let all = -1, any = false; for (let q = 0; q < m.length; q++) { if (/[\s　]/.test(t[q])) continue; all &= (m[q] | 0); any = true; } lm = (any ? all & (M.BOLD | SIZE_BITS) : 0) | base; } /* 印の太字・倍角：本文の（空白を除く）全部の字に共通する修飾だけ。一部の語だけ太字なら印は太くしない */ const mw = scaleW(lm) > 1 ? textWidth(mk.replace(/[\s　]+$/, '')) * scaleW(lm) + textWidth(mk) - textWidth(mk.replace(/[\s　]+$/, '')) : textWidth(mk); // 番号・記号は本文の先頭の文字と同じ太さ・倍角（横倍角でも後ろの空きは倍にしない）
          if (eff.kind === 'bullet' && eff.lkind === 'cont') { // 項目の続きの段落：同じレベルの項目の本文開始位置に揃える（記号なし）
            let e = null; for (let q = open.length - 1; q >= 0; q--) if (open[q].lv === lv) { e = open[q]; break; } if (!e) e = open[open.length - 1]; const mcol = pos != null ? pos : e ? Math.max(left, e.col) : left; marker = null; firstL = contL = Math.min(right - 1, mcol); }
          else if (eff.kind === 'num') { // 数字見出し：レベル n は n マス下げ
            const mcol = Math.min(right - 2, pos != null ? pos : left + lv); marker = mw ? { text: mk, col: mcol, w: mw, marks: lm } : null; firstL = contL = Math.min(right - 1, mcol + mw); numBase = headBase = firstL - left; headMark = mcol - left; open.length = 0; }
          else if (eff.kind === 'sym') { // 記号見出し：直前の数字見出しの本文開始位置 ＋ レベル
            const mcol = Math.min(right - 2, pos != null ? pos : left + numBase + lv); marker = mw ? { text: mk, col: mcol, w: mw, marks: lm } : null; firstL = contL = Math.min(right - 1, mcol + mw); headBase = firstL - left; headMark = mcol - left; open.length = 0; if (eff.close) tail = { text: eff.close, marks: lm }; }
          else { // 箇条書き：直前の見出しの本文開始位置を基準に、入れ子は親の本文開始位置へ。レベルを飛ばした分は 2 マスずつ
            while (open.length && open[open.length - 1].lv >= lv) open.pop();
            const base = pos != null ? pos : open.length ? open[open.length - 1].col + 2 * (lv - open[open.length - 1].lv - 1) : left + headBase + 2 * lv;
            const mcol = Math.min(right - 2, base); marker = mw ? { text: mk, col: mcol, w: mw, marks: lm } : null; firstL = contL = Math.min(right - 1, mcol + mw);
            open.push({ lv, col: firstL }); } }
        if (s === 0 && !table) { /* P10 位置・太字・番号の理由 */
          const KN = { num: '番号見出し', sym: '記号見出し', bullet: '箇条書き' }; const col = Math.round(((marker ? marker.col : firstL) - region0.left) * 2) / 2; /* 見出し・箇条書きは印の桁 */
          const pw = pp && pp.head && eff ? '区画の見出し：区画の左から' : eff && a.indent != null ? `位置 ${a.indent | 0} を固定（この行の指定。段を変えても動かない）` : eff ? (eff.kind === 'num' ? `番号見出しの段 ${eff.level + 1}：段の数だけ下げる` : eff.kind === 'sym' ? `記号見出しの段 ${eff.level + 1}：直前の番号見出しの本文の位置＋段` : eff.lkind === 'cont' ? '項目の続きの段落：同じ段の項目の本文の位置' : `箇条書きの段 ${eff.level + 1}：見出しの本文の位置から（入れ子は親の項目の本文の位置へ）`)
            : a.indent ? `字下げ ${a.indent | 0}（この行の指定）` : bodyShift ? `本文の位置：見出しに揃える（書式の「本文の位置」）` : qd ? `引用：段ごとに 2 字` : a.style === 'speech' ? '発言録：名前の欄の後ろに揃える' : '版面の左端から';
          W.pos = { col, why: pw, own: a.indent != null ? 'indent' : null };
          W.bold = (base & M.BOLD) ? { why: a.style === 'title' ? '表題は太字（組版の決まり）' : pp && pp.head ? '区画の見出しは太字（組版の決まり）' : eff && eff.kind === 'sym' ? '記号見出しは太字（組版の決まり）' : '題の段の番号見出しは太字（書式の「題の段数」）', own: null } : a.thin ? { why: '細字（この行の指定）：組版の太字を外している', own: 'thin' } : seg.marks.some(m => m & M.BOLD) ? { why: '字に太字を付けている（字の飾り）', own: 'marks' } : null;
          if (pf) { W.pos = { col, why: pf.fig ? `プ譜の${pf.role}：列の図（横長の紙面。右から 勝利条件・獲得目標｜中間目的｜施策）の列に置く` : `プ譜の${pf.role}：右端を深さごとに ${PD} 字ずつ下げ、字の頭は左で揃える（字下げの木を左右逆転）`, own: null }; if (base & M.BOLD) W.bold = { why: 'プ譜の獲得目標・勝利条件・枠の名前は太字（組版の決まり）', own: null }; }
          if (eff && eff.text) W.num = { mark: eff.text, why: `${KN[eff.kind] || '項目'}の段 ${eff.level + 1} の印：書式の体系（F9「体系」・番号の形）で決まる${a.restart ? '。この行から数え直し（この行の指定）' : ''}`, own: a.restart ? 'restart' : null }; }
        if (a.style === 'speech' && s === 0 && !table) { const n = clamp(a.speakerCols || 6, 1, right - left - 2); firstL = left; contL = left + n; }
        const gP = gBody && gIdx(seg.col) >= (GT.labels | 0); /* セルの番号（空のセルは seg が無いので桁から引く） */ const bsp = gB && gB.spans.find(sp => seg.col >= sp.left - 1e-6 && seg.col < sp.right - 1e-6 && sp.k1 > sp.k0); const wr = gP ? 1e6 : bsp ? bsp.right : right;
        const align = gP ? 'left' : (table && a.cellAlign && a.cellAlign[s]) || (bsp ? 'center' : '') || (coverTpl && i === coverTitle ? 'center' : a.align) || 'left';
        const hang = f.hang && !table && !pf && !(a.deco && DECO_SPECS[a.deco] && DECO_SPECS[a.deco].box) && !(vAt.get(i) || []).some(c => Math.abs(c - right) < 1e-6); // 右端に縦罫がある（セル・囲み）ならぶら下げず追い出す
        // 折返し結果はセグメント自身に保持（行ごとに別オブジェクト。共有すると配置情報が混ざる）。文字列・修飾（のハッシュ）・位置の条件が同じなら使い回す
        const w0 = seg._wrap; const mh = marksHash(seg.marks); const rk = figNums && REF_RE.test(seg.text) ? refKey(seg.text) : '';
        const mkey = (marker ? marker.text + '@' + marker.col + '/' + (marker.marks | 0) : '') + (tail ? '>' + tail.text + '/' + (tail.marks | 0) : '');
        let rows = (w0 && w0.text === seg.text && w0.mh === mh && w0.firstL === firstL && w0.contL === contL && w0.right === wr && w0.left === left && w0.hang === hang && w0.speech === (a.style === 'speech') && w0.mkey === mkey && w0.align === align && w0.cols === COLS && w0.code === !!a.code && w0.base === base && w0.rk === rk) ? w0.rows : null;
        if (!rows) { rows = wrapSeg(seg, firstL, contL, wr, hang, a, marker, left, tail, base); rows.forEach((r, k) => { alignRow(r, align, k, rows.length, wr); r.h0 = r.h; }); if (gP) for (const r of rows) r.right = right; /* h0：このセグメント自身の高さ（r.h は置くときに行の高さで上書きされる） */ Object.defineProperty(seg, '_wrap', { value: { text: seg.text, mh, firstL, contL, right: wr, left, hang, speech: a.style === 'speech', mkey, align, cols: COLS, code: !!a.code, base, rk, rows }, enumerable: false, writable: true, configurable: true }); }
        return { s, seg, rows, left, right };
      });
      let nRows = 1; for (const sl of segLayouts) if (sl.rows.length > nRows) nRows = sl.rows.length;
      const rowH = []; let total = 0; for (let k = 0; k < nRows; k++) { let h = 1; for (const sl of segLayouts) { const r = sl.rows[k]; const rh = r ? (r.h0 ?? r.h) : 0; if (rh > h) h = rh; } rowH[k] = h; total += h; } // 表の行：セルごとの自身の高さの最大（別のセルが四倍角だったときの高さを引きずらない）
      lineMap[i].segs = segLayouts.map(sl => ({ rows: sl.rows }));
      const keep = table || a.keep === 'line' || ln.segs.length > 1 || !!pf;
      const pfNextH = j => { const nx = pufuAt.get(j + 1); return nx && nx.fig && nx.fig.first ? Math.min(ROWS, nx.fig.H) : 1; }; /* 1.0.14g プ譜の見出しは列の図と同じ頁に */
      const tableRowEst = j => { const l2 = doc.lines[j]; if (!l2 || !inTable(doc, j)) return 1; let mx = 1; for (const c of cellsAt(doc, j, COLS)) { let w = 0; for (const g of l2.segs) if (g.col >= c.left - 1e-6 && g.col < c.right - 1e-6) w += textWidth(g.text); mx = Math.max(mx, Math.ceil(w / Math.max(1, c.right - c.left - 1))); } return mx; }; /* 表の行の高さの見積もり（セルの字の幅 ÷ セルの幅） */
      const keepNext = (pf && pf.keepNext) || a.keep === 'next' || (a.keep !== 'free' && ((effList[i] && (effList[i].kind === 'sym' || (effList[i].kind === 'num' && effList[i].title))) || a.style === 'title')) || (table && tStart[i] === i && repOn(i)); // 題は既定で次と同頁。「送らない」で外せる（K-12）。繰り返す表の見出し行も次の行と一緒に
      // 見出しの前の空き：ページ頭では空けない。空きを入れると（次と一緒の 1 行も含めて）入らないなら、空き無しで押し込まず次ページへ
      let moved = false;
      if (!pp && !pf && gaps[i] && y > 0) { const need = 1 + total + (keepNext ? 1 : 0); if (y + need <= ROWS) { y += 1; if (gaps[i] === 'rule') page.hrules.push({ id: 'sec' + i, y: y - 0.5, from: region0.left, to: region0.right, kind: 'thin', line: i, deco: true, sec: true }); } else if (total + (keepNext ? 1 : 0) <= ROWS) { W.brk = { why: keepNext ? '見出しの前の空きと、次の行と同じ頁に置く分が、頁の残りに入らない' : '見出しの前の空きを入れると頁の残りに入らない', own: keepNext && a.keep === 'next' ? 'keepNext' : keepNext ? 'implicitNext' : null }; advancePage(true); moved = true; } } // 節の区切り線：空きの行の真ん中
      if (!pp && !pff && !moved && keep && y + total > ROWS && y > 0 && total <= ROWS) { W.brk = { why: table ? '表の行は頁で割らない' : a.keep === 'line' ? '分割禁止（この行の指定）：この段落を頁で割らない' : '横に並ぶ字の行は割らない', own: a.keep === 'line' ? 'keepLine' : null }; advancePage(true); moved = true; }
      // 見出しの「次と一緒に」：次行の最初の1行分が入らないなら繰り越す
      if (!pp && !moved && keepNext && y > 0 && y + total + (table && tStart[i] === i ? tableRowEst(i + 1) : pfNextH(i)) > ROWS) { W.brk = { why: a.keep === 'next' ? '次と同頁（この行の指定）：次の行と同じ頁に置く' : a.style === 'title' ? '表題は次の行と同じ頁に置く（組版の決まり）' : table ? '繰り返す表の見出し行は、次の行と一緒に送る' : '題の見出しは次の行と同じ頁に置く（組版の決まり。「送らない」で外せる）', own: a.keep === 'next' ? 'keepNext' : table ? null : 'implicitNext' }; advancePage(true); moved = true; } // 表の見出し行は、次の行（割らずに置く）が丸ごと入らなければ一緒に送る
      if (moved && tryReuseTail()) break;
      if (table && y === 0 && tStart[i] >= 0 && tStart[i] < i && repOn(tStart[i])) { // ページをまたいだ表：ページの頭に見出し行を写す（文字は写し。カーソルは入らない）
        const ts = tStart[i], hl = lineMap[ts]; const hr0 = hl && hl.rows[0]; const GH = doc.lines[ts].attrs.gantt; const nh = Math.max(1, Math.min(GH ? GH.heads | 0 || 1 : 1, i - ts)); /* 工程表は見出しの段数ぶん（年度の段＋期間の段）を写す */
        if (hr0 && hr0.page < pi) { const hy0 = hr0.y; let hh = 0; const offs = [0]; let okP = true; for (let q = ts; q < ts + nh; q++) { const m = lineMap[q]; if (!m || !m.rows.length || m.rows[0].page !== hr0.page) { okP = false; break; } let h = 0; for (const r of m.rows) if (r.page === hr0.page) h += r.h; hh += h; offs.push(hh); }
          if (okP && hh > 0 && hh + total <= ROWS) { for (let q = ts; q < ts + nh; q++) for (const sl of lineMap[q].segs) for (const r of sl.rows) { if (r.page !== hr0.page) continue; for (const g of r.glyphs) page.glyphs.push({ ...g, page: pi, y: g.y - hy0, line: -1, seg: 0, start: -1, end: -1, off: -1, len: 0, rep: true }); }
            page.repeats.push({ next: i, y0: 0, hh, nh, offs }); y = hh; } } }
      for (let k = 0; k < nRows; k++) {
        if (!pp && !pff && y + rowH[k] > ROWS) { if (y === 0 && rowH[k] > ROWS) {/* 1行がページより高い：置く */ } else { if (k === 0 && !W.brk) W.brk = { why: '頁の残りが無いので次の頁へ（ふつうの送り）', own: null }; else if (k > 0) W.split = `この段落は ${k} 行目で頁が替わる`; advancePage(k === 0); if (k === 0 && tryReuseTail()) { i = N; break; } } }
        const segRows = []; for (const sl of segLayouts) if (sl.rows[k]) segRows.push({ s: sl.s, row: sl.rows[k], cell: table });
        const yRow = y, pgRow = page; placeRow(i, k, rowH[k], segRows);
        if (pf) pufuRow(pf, i, k, nRows, yRow, rowH[k], pgRow, pfGap);
        const ds = a.deco && !table ? DECO_SPECS[a.deco] : null; // 見出し飾りの罫・網（全幅）
        if (a.hr) pgRow.hrules.push({ id: 'hr' + i + ':' + k, y: yRow + rowH[k] / 2, from: region.left, to: region.right, kind: 'thin', line: i, deco: true }); // 区切り線：行の中ほどに全幅の細罫
        if (ds) { const L0 = region0.left, R0 = region0.right, first = k === 0, last = k === nRows - 1; if (ds.fill) pgRow.fills.push({ id: 'deco' + i + ':f' + k, col: L0, cols: R0 - L0, y1: yRow, y2: yRow + rowH[k], shade: ds.fill, from: i, to: i, deco: true });
          if (ds.box) { if (first) pgRow.hrules.push({ id: 'deco' + i + ':t', y: yRow, from: L0, to: R0, kind: ds.box, line: i, deco: true }); if (last) pgRow.hrules.push({ id: 'deco' + i + ':b', y: yRow + rowH[k], from: L0, to: R0, kind: ds.box, line: i + 1, deco: true }); for (const c of [L0, R0]) pgRow.vrules.push({ id: 'deco' + i + ':v' + c + ':' + k, col: c, y1: yRow, y2: yRow + rowH[k], kind: ds.box, from: i, to: i, headTop: first, headBottom: last, deco: true }); }
          if (ds.under && last) pgRow.hrules.push({ id: 'deco' + i + ':u', y: yRow + rowH[k], from: L0, to: R0, kind: ds.under, line: i + 1, deco: true }); }
        if (pp && pp.head) { if (pp.style === 'line') { if (k === nRows - 1) pgRow.hrules.push({ id: 'pnl' + i + ':u', y: yRow + rowH[k], from: pp.L, to: pp.R, kind: 'thick', line: i + 1, deco: true }); } else pgRow.fills.push({ id: 'pnl' + i + ':f' + k, col: pp.L, cols: pp.R - pp.L, y1: yRow, y2: yRow + rowH[k], shade: pp.style === 'gray' ? 'gray' : pp.style === 'ink' ? 'ink' : 'dark', from: i, to: i, deco: true }); } /* 区画の見出しの帯 */
        if (a.code && !table) pgRow.fills.push({ id: 'code' + i + ':' + k, col: region.left, cols: region.right - region.left, y1: yRow, y2: yRow + rowH[k], shade: 'light', from: i, to: i, deco: true }); // コード：淡い地
        for (let q = 0; q < qd && !table; q++) pgRow.vrules.push({ id: 'quote' + i + ':' + k + ':' + q, col: region0.left + 2 * q + 0.5, y1: yRow, y2: yRow + rowH[k], kind: 'thick', from: i, to: i, deco: true }); // 引用の線
      }
      if (gBody) ganttRow(i, segLayouts, GC);
      if (pfPair) y = Math.max(y, pfPair.y0); if (pff) y = pfTop + pff.H;
      if (i >= N) break;
      if (a.figs && (pp || !geo.side) && !table) placeInlineFigs(i, a.figs, region0, !!pp);
      if (pp) { if (y > pRowMax) pRowMax = y; if (pp.head) { headBase = 0; numBase = 0; headMark = -1; open.length = 0; } /* 区画の中身は区画の左から（見出しの番号の幅で下げない） */
        if (pp.rowEnd && pp.link) { const LT = pp.link === 'tri' ? ['▶', '▼'] : ['→', '↓']; const put = (text, col, yy) => page.glyphs.push({ text, start: -1, end: -1, col, w: 1, marks: 0, page: pi, y: yy, h: 1, line: pp.s0, seg: 0, off: -1, len: 0, sx: 1, sy: 1, deco: true });
          const yMid = Math.max(pRowY0, Math.floor((pRowY0 + pRowMax - 1) / 2)); const rp = pp.rowPanels; for (let q = 1; q < rp.length; q++) put(LT[0], (rp[q - 1].R + rp[q].L) / 2 - 0.5, yMid); /* 横に並ぶ区画の間：→ か ▶ */
          if (pp.vert && pp.row > 0) { const prevBottom = pRowY0 - 1; const q0 = rp[0]; put(LT[1], (q0.L + q0.R) / 2 - 0.5, prevBottom); } } /* 縦に積む区画の間：↓ か ▼（前の区画との間の行） */
        if (pp.rowEnd) { for (const q of pp.rowPanels) { const id = 'pnl' + q.g + ':' + q.k; page.hrules.push({ id: id + ':t', y: pRowY0, from: q.L, to: q.R, kind: 'thin', line: q.s0, deco: true }, { id: id + ':b', y: pRowMax, from: q.L, to: q.R, kind: 'thin', line: q.s1, deco: true }); for (const c of [q.L, q.R]) page.vrules.push({ id: id + ':v' + c, col: c, y1: pRowY0, y2: pRowMax, kind: 'thin', from: q.s0, to: q.s1 - 1, headTop: true, headBottom: true, deco: true }); } y = pRowMax; } /* 段の区画を同じ高さの枠で囲む */
        if (pp.gEnd) { if (pSave) { open.length = 0; open.push(...pSave.open); headBase = pSave.headBase; numBase = pSave.numBase; headMark = pSave.headMark; } pSave = null; y = pRowMax; } }
    }
    if (i >= N) { done = true; if (!tailReused) endPos = { page: pi, y }; }
    return done;
  }
  // ---- 後処理（途中でも呼べる：置いた行の分だけ）。途中の呼び出しでは、前回の後処理から変わり得るページ（最後のページ以降と目次のページ）だけやり直す ----
  let postedFrom = 0;
  function finish() { const pv = RIDX; RIDX = IDX; try { return finishBody(); } finally { RIDX = pv; } }
  function finishBody() {
    const placed = done ? N : i; const full = done; const from = full ? 0 : postedFrom; const tocPages = new Set(); for (const t of tocFix) if (t.page >= 0) tocPages.add(t.page);
    const redo = p => full || p >= from || tocPages.has(p);
    for (let p = 0; p < pages.length; p++) { const pg = pages[p]; if (pg._post && redo(p)) cleanPage(pg); }
    // 目次の頁番号：見出しの最初の行があるページ。右端に右寄せ（半角）
    for (const t of tocFix) { const pg = pages[t.page]; if (!pg) continue; const hr = lineMap[t.line] && lineMap[t.line].rows[0]; const pno = hr ? String(PG(hr.page) + 1) : (t.line < placed ? '-' : '…'); let col = t.right - 0.5 * pno.length; for (const ch of pno) { pg.glyphs.push({ text: ch, start: -1, end: -1, col, w: 0.5, marks: 0, page: t.page, y: t.y, h: 1, line: t.tocLine, seg: 0, off: -1, len: 0, sx: 1, sy: 1, toc: true, tocDigit: true }); col += 0.5; } if (tocs[t.tocLine] && tocs[t.tocLine][t.k]) tocs[t.tocLine][t.k].page = hr ? hr.page + 1 : 0; }
    // 罫線・網掛けの配置
    const topOf = q => (q < placed ? lineMap[q].rows[0] : null);
    const bottomOf = q => { const rows = lineMap[Math.min(q, placed - 1)].rows; const r = rows[rows.length - 1]; return { page: r.page, y: r.y + r.h }; };
    const endY = endPos ? endPos.y : y, endPage = endPos ? endPos.page : pi;
    /* 表がページをまたぐとき：そのページに載った表の最後の行の下端（縦罫・網をページの下まで伸ばさない）。表でない範囲（囲みなど）は従来どおりページの下まで */
    const lastBottoms = (from0, to) => { const m = new Map(); for (let q = from0; q <= to; q++) { const lm = lineMap[q]; if (!lm) continue; for (const r of lm.rows) { const b = r.y + r.h; if (!(m.get(r.page) >= b)) m.set(r.page, b); } } return m; };
    const isTableSpan = (from0, to) => tStart[from0] >= 0 && tStart[to] === tStart[from0];
    const hRulesAt = new Map(); for (const r of doc.rules) if (r.axis === 'h') { if (!hRulesAt.has(r.line)) hRulesAt.set(r.line, []); hRulesAt.get(r.line).push(r); }
    const repAt = (pg, line) => pg && pg.repeats && pg.repeats.length ? pg.repeats.find(q => q.next === line) : null;
    const closesAbove = L => L > 0 && L < N && tStart[L] !== L && vRulesAt(doc, L - 1).some(v => v.to === L - 1); // 行 L の上の横罫が、上で終わる縦罫の塊（表・囲み）を閉じる罫か
    for (const r of doc.rules) {
      if (r.axis === 'h') { if (r.line > placed || (r.line === placed && !done)) continue;
        let pos; if (r.line >= N) { const b2 = bottomOf(N - 1); pos = { page: b2.page, y: b2.y }; } else if (closesAbove(r.line)) { const b2 = bottomOf(r.line - 1); if (!b2) continue; pos = { page: b2.page, y: b2.y }; } else { const t = topOf(r.line); if (!t) continue; pos = { page: t.page, y: t.y }; } // 表・囲みの下端の罫は上の塊の下に（次の行の前の空き〔戻り空き・題の前空き〕の下に落とさない）
        const L0 = r.line; let hf = r.from; if (L0 > 0 && L0 < N && tStart[L0 - 1] === L0 - 1) { const B = bandOf(L0 - 1); if (B && B.labelsRight != null && hf < B.labelsRight - 1e-6) { if (r.to <= B.labelsRight + 1e-6) continue; hf = B.labelsRight; } } /* 工程表の左の列の見出し：2 段を 1 つに */
        const rp = L0 < N ? repAt(pages[pos.page], L0) : null; if (rp && (hRulesAt.get(tStart[L0] + (rp.nh || 1)) || []).some(x => x.from < r.to && x.to > r.from)) continue; // 写した見出し行の下の罫を優先（重ねない）
        if (pages[pos.page] && redo(pos.page)) pages[pos.page].hrules.push({ id: r.id, y: pos.y, from: clamp(hf, 0, COLS), to: clamp(r.to, 0, COLS), kind: r.kind, dir: r.dir, line: r.line }); }
      else { let from0 = clamp(r.from, 0, N - 1); if (tStart[from0] === from0) { const B = bandOf(from0); if (B && B.cuts.has(r.col)) { if (r.to <= from0) continue; from0++; } } /* 工程表の年度の段：帯の中の縦罫は描かない */ if (from0 >= placed) continue; const to = clamp(Math.min(r.to, placed - 1), from0, N - 1);
        const t = topOf(from0), bt = bottomOf(to); const lb = t.page !== bt.page && isTableSpan(from0, to) ? lastBottoms(from0, to) : null;
        for (let p = t.page; p <= bt.page; p++) { if (!pages[p] || !redo(p)) continue; const y1 = p === t.page ? t.y : 0; const y2 = p === bt.page ? bt.y : lb && lb.has(p) ? lb.get(p) : (p === endPage ? endY : ROWS); if (y2 > y1) pages[p].vrules.push({ id: r.id, col: clamp(r.col, 0, COLS), y1, y2, kind: r.kind, dir: r.dir, from: from0, to, headTop: p === t.page, headBottom: p === bt.page }); } }
    }
    for (const x of doc.fills) {
      const from0 = clamp(x.from, 0, N - 1); if (from0 >= placed) continue; const to = clamp(Math.min(x.to, placed - 1), from0, N - 1);
      const t = topOf(from0), bt = bottomOf(to); const lb = t.page !== bt.page && isTableSpan(from0, to) ? lastBottoms(from0, to) : null;
      for (let p = t.page; p <= bt.page; p++) { if (!pages[p] || !redo(p)) continue; const y1 = p === t.page ? t.y : 0; const y2 = p === bt.page ? bt.y : lb && lb.has(p) ? lb.get(p) : ROWS; if (y2 > y1) pages[p].fills.push({ id: x.id, col: clamp(x.col, 0, COLS), cols: clamp(x.cols, 0, COLS - x.col), y1, y2, shade: x.shade, from: from0, to }); }
    }
    /* 表がページで切れたところ：前のページの表の下を閉じる（表の下端の罫の種類で。無ければ行の境の罫） */
    for (let q = 1; q < placed; q++) { const ts = tStart[q]; if (ts < 0 || ts >= q) continue; const b0 = lineMap[q]; if (!b0 || !b0.rows.length || !lineMap[q - 1]) continue; const pb = bottomOf(q - 1); if (b0.rows[0].page <= pb.page || !pages[pb.page] || !redo(pb.page)) continue;
      const outer = hRulesAt.get(tEnd[ts] + 1); const src = outer && outer.length ? outer : (hRulesAt.get(q) || []);
      for (const r of src) pages[pb.page].hrules.push({ id: r.id + '@close' + q, y: pb.y, from: clamp(r.from, 0, COLS), to: clamp(r.to, 0, COLS), kind: r.kind, line: q, closing: true }); }
    /* 写した見出し行の罫（上・下）と、見出し行だけの網 */
    for (let p = 0; p < pages.length; p++) { const pg = pages[p]; if (!pg.repeats || !pg.repeats.length || !redo(p)) continue;
      for (const rp of pg.repeats) { const ts = rp.next < N ? tStart[rp.next] : -1; if (ts < 0) continue;
        const nh = rp.nh || 1, offs = rp.offs || [0, rp.hh]; const B = bandOf(ts);
        for (let q = 0; q <= nh; q++) { const ln = ts + q, yy = rp.y0 + offs[q]; for (const r of hRulesAt.get(ln) || []) { let fr = r.from; if (q === 1 && B && B.labelsRight != null && nh > 1) { if (r.to <= B.labelsRight + 1e-6) continue; fr = Math.max(fr, B.labelsRight); } pg.hrules.push({ id: r.id + '@rep' + p, y: yy, from: clamp(fr, 0, COLS), to: clamp(r.to, 0, COLS), kind: r.kind, line: ln, rep: true }); } } /* 見出しの段の上・間・下の罫（年度の段の下は項目欄を除く） */
        for (let q = 0; q < nh; q++) for (const x of doc.fills) if (x.from === ts + q && x.to === ts + q) pg.fills.push({ id: x.id + '@rep' + p, col: clamp(x.col, 0, COLS), cols: clamp(x.cols, 0, COLS - x.col), y1: rp.y0 + offs[q], y2: rp.y0 + offs[q + 1], shade: x.shade, from: ts + q, to: ts + q, rep: true });
        if (B && nh > 1) for (const v of pg.vrules) if (B.cuts.has(v.col) && v.from <= ts + 1 && v.to >= ts + 1 && v.y1 <= rp.y0 + 1e-6) v.y1 = rp.y0 + offs[1]; } } /* 写した年度の段：帯の中の縦罫は 2 段目から */
    // 図表欄（資料書式）：各ページに、そのページに載った行の図版を上から積む。幅の合計が欄に入る図版は横に並べる。入らない図版は次のページへ（本文は動かさない）。
    // 本文の後にも残れば図表だけのページを足す（組み終わったときだけ）。毎回すべてのページを組み直す（図版は数が少ない）
    let all = pages;
    if (geo.side) { all = pages.slice(); const SL = geo.sideLeft, SR = geo.sideRight, SW = SR - SL; const byPage = new Map();
      for (const fl of figLines) { if (fl.line >= placed) break; if (panelAt.has(fl.line)) continue; /* 区画の図表は区画の中に置いた */ const lm = lineMap[fl.line]; const r = lm && lm.rows[0]; if (!r) continue; if (!byPage.has(r.page)) byPage.set(r.page, []); byPage.get(r.page).push(...fl.figs.map(fg => ({ fg, line: fl.line }))); }
      const queue = [];
      for (let p = 0; p < all.length || (done && queue.length); p++) {
        if (p >= all.length) { const op = blankPage(); op.overflow = true; all.push(op); }
        const pg = all[p]; const side = { glyphs: [], images: [], rules: [] }; pg.side = side; queue.push(...(byPage.get(p) || []));
        if (f.divider !== 'none') side.rules.push({ id: 'div' + p, col: BODY + 0.5, y1: 0, y2: ROWS, kind: f.divider === 'dotted' ? 'dotted' : 'thin' });
        let yy = 0;
        while (queue.length) { const band = []; let used = 0;
          for (const it of queue) { const d = figDims(it.fg, SW); if (band.length && used + 1 + d.w > SW) break; band.push({ it, d }); used += (band.length > 1 ? 1 : 0) + d.w; }
          let bh = 1 + Math.max(...band.map(b => b.d.ih)); if (yy > 0 && yy + bh > ROWS) break;
          if (yy + bh > ROWS) { for (const b of band) b.d.ih = Math.max(1, Math.min(b.d.ih, ROWS - yy - 1)); bh = ROWS - yy; } // ページより高い図版：縮めて置く
          let x = SL; for (const b of band) { const fg = b.it.fg; capGlyphs(side.glyphs, figLabel(fg), x, x + b.d.w, yy, p, { line: b.it.line, figcap: true, figId: fg.id }); side.images.push({ id: fg.id, file: fg.file, col: x, y: yy + 1, w: b.d.w, h: b.d.ih, line: b.it.line, title: fg.title, kind: fg.kind, chart: fg.chart || null }); x += b.d.w + 1; }
          queue.splice(0, band.length); yy += bh + 1; }
      } }
    // ヘッダ・フッタ（途中は総頁数を … にしておき、終わったときに全ページ入れ直す）
    const np = all.length, NP = COL2 ? Math.ceil(np / 2) : np; for (let idx = 0; idx < np; idx++) { if (!redo(idx) && idx < pages.length) continue; const p = all[idx]; const sub = s => String(s || '').replace(/\{page\}/g, String(PG(idx) + PS)).replace(/\{pages\}/g, done ? String(NP) : '…').replace(/\{file\}/g, doc.fileName || ''); // {file}：今のファイル名（保存し直すと変わる。原本には持たない）
      const ht = f.headerRows > 0 && f.header && !geo.slide ? sub(f.header) : '', ft = f.footerRows > 0 && f.footer ? sub(f.footer) : ''; const key = ht + '\u0001' + ft + '\u0001' + COLS + ',' + geo.footerTop;
      if (p._hfKey !== key || !p.hf) { p.hf = []; if (ht) p.hf.push(...hfGlyphs(ht, 0, COLS, 'left')); if (ft) p.hf.push(...hfGlyphs(ft, geo.footerTop, COLS, 'center')); p._hfKey = key; } p._post = true; }
    // 資料書式の柱：題（引き上げた表題／題名）・機密表示・日付と作成者・頁番号・柱の罫。表題の無いページは前のページの題を引き継ぐ
    if (slideHead) { const S = headInfo.S, maxC = headInfo.titleMax;
      let docTitle = null; const titleText = () => { if (docTitle) return docTitle; let t = doc.title || ''; if (!t) { const tl = doc.lines.find(l => l.attrs.style === 'title'); if (tl) t = tl.segs.map(sg => FZ.expandRefs(doc, sg, figNums || undefined).text).join('　'); }
        const out = []; let col = 0; const gs = graphemes(t.trim()); for (let k = 0; k < gs.length; k++) { const w = baseWidth(gs[k].text) * S; if (col + w > maxC - (k < gs.length - 1 ? S : 0) + 1e-6) { out.push({ text: '…', col, w: S }); break; } out.push({ text: gs[k].text, col, w }); col += w; }
        return (docTitle = out.map(o => ({ ...o, start: -1, end: -1, marks: M.BOLD, y: HY, h: HH, sx: S, sy: S, line: -1, seg: 0, off: -1, len: 0, head: true }))); };
      /* 表紙の型：題（無ければ題名）の下に日付と作成者、toc なら目次の箱（頁ごとの表題、無ければいちばん浅い見出しと頁番号） */
      const coverHead = (pg, head, p) => { const G = (t, col, yy, w, S0 = 1, mk = 0) => { for (const g of graphemes(t)) { const gw = baseWidth(g.text) * S0; head.glyphs.push({ text: g.text, start: -1, end: -1, col, w: gw, marks: mk, y: yy, h: S0 >= 2 ? 2 : 1, sx: S0, sy: S0, line: -1, seg: 0, off: -1, len: 0, page: p, head: true, cover: true }); col += gw; } };
        const ctr = (t, yy, S0 = 1, mk = 0) => { const w = textWidth(t) * S0; G(t, half((COLS - w) / 2), yy, w, S0, mk); };
        const ct = Math.max(1, Math.round(ROWS * 0.26)); let yb = ct + 2;
        const lm = coverTitle >= 0 ? lineMap[coverTitle] : null; if (lm && lm.rows.length) { let b = 0; for (const r of lm.rows) if (r.page === 0) b = Math.max(b, r.y + r.h); if (b) yb = b; }
        else { const t = (doc.title || '').trim(); if (t) { let tt = t; while (textWidth(tt) * 2 > COLS - 2 && tt.length > 1) tt = tt.slice(0, -1); ctr(tt, ct, 2, M.BOLD); yb = ct + 2; } }
        const date = f.dateAuto ? FZ.todayJa() : String(f.date || ''), author = String(f.author || ''); let yy = yb + 1; if (date) { ctr(date, yy); yy++; } if (author) { ctr(author, yy); yy++; }
        if (coverTpl !== 'toc') return; const ents = [];
        if (liftTitle) { for (let q = 1; q < all.length; q++) if (all[q].titleLine != null && all[q].titleLine !== coverTitle) ents.push({ t: doc.lines[all[q].titleLine].segs.map(sg => FZ.expandRefs(doc, sg, figNums || undefined).text).join('　').trim(), pg: PG(q) + PS }); }
        if (!ents.length) { let minLv = 99; for (let q = 0; q < N; q++) { const a = doc.lines[q].attrs; if (a.style === 'num') minLv = Math.min(minLv, a.level | 0); } for (let q = 0; q < N; q++) { const a = doc.lines[q].attrs; if (a.style !== 'num' || (a.level | 0) !== minLv) continue; const m2 = lineMap[q]; const r0 = m2 && m2.rows[0]; if (!r0) continue; const row = m2.segs[0] && m2.segs[0].rows[0]; const mk = row ? row.glyphs.filter(g => g.marker).map(g => g.text).join('').trim() : ''; ents.push({ t: (mk ? mk + ' ' : '') + doc.lines[q].segs.map(sg => sg.text).join('').trim(), pg: PG(r0.page) + PS }); } }
        if (!ents.length) return; const bw = Math.max(16, Math.round(COLS * 0.6)), bx = half((COLS - bw) / 2), by = yy + 2, room = Math.max(3, ROWS - by - 1); const show = ents.slice(0, Math.max(1, room - 3)); const bh = show.length + 2 + (ents.length > show.length ? 1 : 0);
        head.boxes.push({ col: bx, y: by, w: bw, h: bh, shape: 'rect', coverToc: true }); G('目次', bx + 1, by + 0.3, 2, 1, M.BOLD);
        show.forEach((e, k) => { const yy2 = by + 1.4 + k; const ps = String(e.pg); const right = bx + bw - 1 - 0.5 * ps.length; let t = e.t; while (textWidth(t) > right - (bx + 1.5) - 2 && t.length > 1) t = t.slice(0, -1); if (t !== e.t) t = t.slice(0, -1) + '…'; G(t, bx + 1.5, yy2, textWidth(t)); let c = bx + 1.5 + textWidth(t) + 0.5; while (c + 1 <= right - 0.5) { G('・', c, yy2, 1); c += 1; } G(ps, right, yy2, 0.5 * ps.length); });
        if (ents.length > show.length) G('…', bx + 1.5, by + 1.4 + show.length, 1); };
      let inherit = null;
      for (let p = 0; p < all.length; p++) { const pg = all[p]; const head = { glyphs: [], boxes: [], rules: [] }; pg.head = head;
        if (coverOn && PG(p) === 0) { pg.cover = true; const pb0 = f.coverNum ? headInfo.pageBox : null; if (pb0) { head.boxes.push(pb0); const t = String(PG(p) + PS); let col = pb0.col + (pb0.w - 0.5 * t.length) / 2; for (const ch of t) { head.glyphs.push({ text: ch, start: -1, end: -1, col, w: 0.5, marks: 0, y: pb0.y + (pb0.h - 1) / 2, h: 1, sx: 1, sy: 1, line: -1, seg: 0, off: -1, len: 0, page: p, head: true }); col += 0.5; } }
          if (f.coverSecret && headInfo.secretBox) { const b = headInfo.secretBox; head.boxes.push(b); for (const g of headInfo.glyphs) if (g.y === HY + (HH - 1) / 2 && g.col >= b.col && g.col < b.col + b.w) head.glyphs.push({ ...g, page: p }); } /* 表紙の機密表示（右上。ほかの頁の柱と同じ所） */
          if (coverTpl) coverHead(pg, head, p); continue; } // 表紙：柱なし（頁番号だけ・機密表示も出せる。型があれば日付・作成者・目次）
        if (liftTitle && pg.titleLine != null && pg.titleGlyphs) inherit = pg.titleGlyphs;
        else { const src = liftTitle && inherit ? inherit.map(g => ({ ...g, line: -1, seg: 0, off: -1, len: 0, start: -1, end: -1, headTitle: false, head: true })) : titleText(); for (const g of src) head.glyphs.push({ ...g, page: p }); }
        for (const g of headInfo.glyphs) head.glyphs.push({ ...g, page: p }); for (const b of headInfo.boxes) head.boxes.push(b);
        const pb = headInfo.pageBox; if (pb) { head.boxes.push(pb); const t = String(PG(p) + PS); let col = pb.col + (pb.w - 0.5 * t.length) / 2; for (const ch of t) { head.glyphs.push({ text: ch, start: -1, end: -1, col, w: 0.5, marks: 0, y: pb.y + (pb.h - 1) / 2, h: 1, sx: 1, sy: 1, line: -1, seg: 0, off: -1, len: 0, page: p, head: true }); col += 0.5; } }
        head.rules.push({ id: 'head' + p, y: HY + HH, from: 0, to: COLS, kind: f.headRule === 'thick' ? 'thick' : 'thin' }); } }
    postedFrom = done ? np : Math.max(0, np - 1);
    const cpByLine = new Map(); cps.forEach((c, p) => { if (c && c.clean) cpByLine.set(c.line, p); });
    let ep = done ? endPos : { page: pi, y };
    let lmOut = lineMap;
    if (COL2) { /* 2 段組：段の頁 2 つ（左・右）を紙の 1 頁にまとめる。右の段の物は colX2 だけ右へ。組版の物（行の折返しの覚えと共有）は書き換えず、写しを作る */
      const DX = geo.colX2, gm = new Map(), cm = new Map(), out = [];
      const gC = (g, d, P) => { let c = gm.get(g); if (!c) { c = { ...g, page: P }; if (d) c.col = g.col + d; gm.set(g, c); } return c; };
      const caC = (arr, d) => { if (!arr || !d) return arr; let c = cm.get(arr); if (!c) { c = arr.map(x => ({ ...x, col: x.col + d })); cm.set(arr, c); } return c; };
      const rC = (r, d, P) => { const c = { ...r, page: P, x0: d }; if (d) { for (const k of ['startCol', 'endCol', 'left', 'right']) if (typeof r[k] === 'number') c[k] = r[k] + d; c.carets = caC(r.carets, d); } if (r.glyphs) c.glyphs = r.glyphs.map(g => gC(g, d, P)); return c; };
      for (let P = 0; P * 2 < all.length; P++) { const a0 = all[P * 2], a1 = all[P * 2 + 1];
        const pg = { ...a0, glyphs: [], rowmap: new Map(), hrules: [], vrules: [], fills: [], images: [], repeats: [] };
        for (const [v, src] of [[P * 2, a0], [P * 2 + 1, a1]]) { if (!src) continue; const d = (v & 1) ? DX : 0;
          for (const g of src.glyphs) pg.glyphs.push(gC(g, d, P));
          for (const [yy, es] of src.rowmap) { const cs = es.map(e => rC(e, d, P)); const cur = pg.rowmap.get(yy); pg.rowmap.set(yy, cur ? cur.concat(cs) : cs); }
          for (const r of src.hrules) pg.hrules.push(d ? { ...r, from: r.from + d, to: r.to + d } : r);
          for (const r of src.vrules) pg.vrules.push(d ? { ...r, col: r.col + d } : r);
          for (const x of src.fills) pg.fills.push(d ? { ...x, col: x.col + d } : x);
          for (const im of src.images || []) pg.images.push(d ? { ...im, col: im.col + d } : im);
          for (const rp of src.repeats || []) pg.repeats.push(rp); }
        if (a0.titleGlyphs) pg.titleGlyphs = a0.titleGlyphs.map(g => gC(g, 0, P));
        if (a0.head) pg.head = { ...a0.head, glyphs: a0.head.glyphs.map(g => ({ ...g, page: P })) };
        const used = a1 && (a1.glyphs.length || a1.rowmap.size || (a1.images || []).length);
        pg.side = { glyphs: [], images: [], rules: used && f.divider !== 'none' ? [{ id: 'col' + P, col: (geo.colW + DX) / 2, y1: 0, y2: ROWS, kind: f.divider === 'dotted' ? 'dotted' : 'thin' }] : [] };
        out.push(pg); }
      lmOut = new Array(N); for (let q = 0; q < N; q++) { const lm = lineMap[q]; if (!lm) continue; lmOut[q] = { ...lm, rows: lm.rows.map(r => ({ ...r, page: r.page >> 1, x0: (r.page & 1) ? DX : 0 })), segs: lm.segs.map(sl => ({ ...sl, rows: sl.rows.map(r => rC(r, (r.page & 1) ? DX : 0, r.page >> 1)) })) }; }
      all = out; ep = { page: ep.page >> 1, y: ep.y, x0: (ep.page & 1) ? DX : 0 }; }
    return job.lay = { geo, panelGroups, pages: all, bodyPages: COL2 ? all.length : pages.length, headY: liftTitle ? HY : null, cover: coverOn, coverTitle, pageStart: PS, headInfo, images, figNums, lineMap: lmOut, endPos: ep, endState: done ? null : { y, open: open.map(o => ({ lv: o.lv, col: o.col })), headBase, numBase, headMark, pfTop }, tocs, pufuAt, placed, done, globalSig, sigA, sigB, csigA, csigB, cps, cpByLine, tocFix, dbg };
  }
  const job = { run, finish, get done() { return done; }, get placed() { return i; }, lay: null, N };
  return job;
}
/* 使い回すページから、後処理が足したもの（罫線・網の配置、柱、目次の頁番号）を取り除く */
function cleanPage(pg) { if (!pg._post) return; pg.hrules = pg.hrules.filter(r => r.fig || r.deco); pg.vrules = pg.vrules.filter(r => r.fig || r.deco); pg.fills = pg.fills.filter(x => x.fig || x.deco); if (pg.glyphs.length && pg.glyphs[pg.glyphs.length - 1].tocDigit) pg.glyphs = pg.glyphs.filter(g => !g.tocDigit); pg._post = false; }
/* 使い回すページの行番号・ページ番号をずらす */
function shiftPage(pg, pageDelta, delta) {
  for (const g of pg.glyphs) { g.page += pageDelta; if (g.line >= 0) g.line += delta; }
  for (const im of pg.images || []) im.line += delta; for (const sh of pg.shapes || []) sh.line += delta; if (pg.titleLine != null) pg.titleLine += delta; for (const rp of pg.repeats || []) rp.next += delta;
  for (const es of pg.rowmap.values()) for (const e of es) { e.page += pageDelta; e.line += delta; }
  const reId = (o, n) => { if (typeof o.id === 'string') o.id = o.id.replace(/^(code|quote|fig|deco|hr|sec)\d+/, '$1' + n); };
  for (const r of pg.hrules) { if (r.line != null) r.line += delta; reId(r, r.line); } for (const r of pg.vrules) { r.from += delta; r.to += delta; reId(r, r.from); } for (const x of pg.fills) { x.from += delta; x.to += delta; reId(x, x.from); }
}
function layout(doc, opts = {}, prev = null) { const job = layoutJob(doc, opts, prev); job.run(Infinity); return job.finish(); }
FZ.layoutJob = layoutJob;
function hfGlyphs(text, y, cols, align) {
  const gs = graphemes(text).map(g => ({ ...g, w: baseWidth(g.text) })); const width = gs.reduce((t, g) => t + g.w, 0);
  let col = align === 'center' ? half((cols - width) / 2) : align === 'right' ? cols - width : 0; col = Math.max(0, col);
  return gs.map(g => { const o = { y, h: 1, col, w: g.w, text: g.text, marks: 0, hf: true, sx: 1, sy: 1 }; col += g.w; return o; });
}

/* 図表の番号と題：x0〜x1 に 1 行（太字）。入らなければ … で切る。arr に足す */
function capGlyphs(arr, text, x0, x1, y, page, props = {}) { let col = x0; const gs = graphemes(text);
  for (let k = 0; k < gs.length; k++) { const w = baseWidth(gs[k].text); const rest = k < gs.length - 1; if (col + w > x1 + 1e-6 || (rest && col + w + 1 > x1 + 1e-6 && col + w + textWidth(gs.slice(k + 1).map(x => x.text).join('')) > x1 + 1e-6)) { if (col + 1 <= x1 + 1e-6) arr.push({ text: '…', start: -1, end: -1, col, w: 1, marks: M.BOLD, y, h: 1, page, line: -1, seg: 0, off: -1, len: 0, sx: 1, sy: 1, ...props }); break; }
    arr.push({ text: gs[k].text, start: -1, end: -1, col, w, marks: M.BOLD, y, h: 1, page, line: -1, seg: 0, off: -1, len: 0, sx: 1, sy: 1, ...props }); col += w; } }
/* 1セグメントの折返し。rows:[{glyphs,carets,startCol,endCol,startOff,endOff,h,left,right,k}] */
function wrapSeg(seg, firstL, contL, R, hang, attrs, marker, cellLeft, tail, base = 0) {
  const text = seg.text, marks = seg.marks, gs = graphemes(text);
  const rows = []; let cur = [], col = firstL, left = firstL, startOff = 0;
  let speechSep = -1;
  if (attrs.style === 'speech') { const m = text.search(/[：:\t]/); if (m >= 0) speechSep = m; }
  const push = (endOff) => { rows.push({ glyphs: cur, startCol: left, endCol: col, startOff, endOff, h: cur.reduce((m, g) => Math.max(m, scaleH(g.marks)), 1), left: cellLeft, right: R, k: rows.length }); cur = []; left = contL; col = contL; startOff = endOff; };
  for (let k = 0; k < gs.length; k++) {
    const g = gs[k], mk = (marks[g.start] | 0) | base; let w;
    if (g.text.length === 2 && isRefChar(g.text)) { const lb = REFLABEL(g.text.codePointAt(0)); w = textWidth(lb) * scaleW(mk); // 図番：「図 1」を 1 つの字として組む（中で折り返さない）
      if (col + w > R + 1e-6 && cur.length) { col = cur[cur.length - 1].col + cur[cur.length - 1].w; push(cur[cur.length - 1].end); }
      cur.push({ text: lb, start: g.start, end: g.end, col, w, marks: mk, marker: false, ref: true }); col += w; continue; }
    w = gWidth(g, mk);
    if (col + w > R + 1e-6 && cur.length) {
      if (hang && HANG.has(g.text) && !(cur.length && HANG.has(cur[cur.length - 1].text))) { cur.push({ text: g.text, start: g.start, end: g.end, col, w, marks: mk, marker: false }); col += w; continue; }
      let carry = [];
      if (NO_START.has(g.text) && cur.length >= 2) carry.unshift(cur.pop());
      while (cur.length >= 2 && NO_END.has(cur[cur.length - 1].text)) carry.unshift(cur.pop());
      col = cur.length ? cur[cur.length - 1].col + cur[cur.length - 1].w : left;
      push(cur.length ? cur[cur.length - 1].end : (carry.length ? carry[0].start : g.start));
      for (const c of carry) { c.col = col; cur.push(c); col += c.w; }
    }
    cur.push({ text: g.text, start: g.start, end: g.end, col, w, marks: mk, marker: false }); col += w;
    if (speechSep >= 0 && g.start === speechSep) { col = Math.max(col, contL); }
  }
  let tailCol = null;
  if (tail) { // 囲み見出しの閉じ：本文の後ろに付く（編集できない字）。行末に入らなければ行頭禁則で前の字を連れて次の行へ
    const tw = gWidth(tail.text, tail.marks | 0);
    if (col + tw > R + 1e-6 && cur.length) { const carry = []; if (cur.length >= 2) carry.unshift(cur.pop()); while (cur.length >= 2 && NO_END.has(cur[cur.length - 1].text)) carry.unshift(cur.pop()); col = cur.length ? cur[cur.length - 1].col + cur[cur.length - 1].w : left; push(cur.length ? cur[cur.length - 1].end : carry[0].start); for (const c of carry) { c.col = col; cur.push(c); col += c.w; } }
    tailCol = col; cur.push({ text: tail.text, start: -1, end: -1, col, w: tw, marks: tail.marks | 0, marker: true, tail: true }); col += tw;
  }
  push(text.length);
  // キャレット：各字の前＋行末（囲みの閉じの前）
  for (const r of rows) { r.carets = r.glyphs.filter(g => g.start >= 0).map(g => ({ off: g.start, col: g.col })); r.carets.push({ off: r.endOff, col: tailCol != null && r === rows[rows.length - 1] ? tailCol : r.endCol }); if (!r.glyphs.some(g => g.start >= 0)) r.carets = [{ off: r.startOff, col: r.startCol }]; }
  if (marker) rows[0].glyphs.unshift(...markerGlyphs(marker));
  return rows;
}
function markerGlyphs(marker) { let col = marker.col; const mk = marker.marks | 0; return graphemes(marker.text).map(g => { const sp = /^[\s　]$/.test(g.text); const w = baseWidth(g.text) * (!sp ? scaleW(mk) : 1); const o = { text: g.text, start: -1, end: -1, col, w, marks: sp ? (mk & ~M.WIDE) : mk, marker: true }; col += w; return o; }); }
function alignRow(r, align, k, n, R) {
  if (align === 'left') return;
  const body = r.glyphs.filter(g => !g.marker); if (!body.length) return;
  const width = r.endCol - r.startCol, avail = R - r.startCol, extra = avail - width; if (extra <= 0) return;
  let shift = 0, perGap = 0;
  if (align === 'center') shift = half(extra / 2); else if (align === 'right') shift = extra;
  else if (align === 'justify') { if ((n > 1 && k < n - 1) || n === 1) { if (body.length >= 2) perGap = extra / (body.length - 1); else shift = 0; } }
  if (!shift && !perGap) return;
  body.forEach((g, idx) => { g.col += shift + perGap * idx; });
  for (const c of r.carets) { const idx = body.findIndex(g => g.start === c.off); c.col += shift + perGap * (idx >= 0 ? idx : body.length - 1 + (perGap ? 1 : 0)); }
  const last = body[body.length - 1]; r.startCol += shift; r.endCol = last.col + last.w;
  if (perGap) { const endC = r.carets[r.carets.length - 1]; endC.col = r.endCol; }
}
FZ.layout = layout;
FZ.PAGE_KEYS = ['paper', 'widthMm', 'heightMm', 'landscape', 'cols', 'rows', 'headerRows', 'footerRows', 'hfGap', 'margins', 'header', 'footer', 'bodyPct', 'divider', 'pageStart']; /* 版面（文書と資料で別に持つ）の鍵 */

/* ---------- 位置計算 ---------- */
/* 論理位置 {line,seg,off} → 物理 {page,y,h,col} */
function posToXY(lay, pos) {
  const lm = lay.lineMap[pos.line]; if (!lm) return null;
  const sl = lm.segs[pos.seg] || lm.segs[0]; if (!sl) return null;
  const rows = sl.rows; let row = rows[rows.length - 1];
  for (const r of rows) { if (pos.off >= r.startOff && pos.off < r.endOff) { row = r; break; } if (pos.off === r.endOff && r === rows[rows.length - 1]) { row = r; break; } if (pos.off === r.startOff && r.k > 0) { row = r; break; } }
  let col = row.endCol; for (const c of row.carets) if (c.off === pos.off) { col = c.col; break; }
  if (pos.vcol != null && pos.vcol > col) col = pos.vcol;
  return { page: row.page, y: row.y, h: row.h, col, row };
}
FZ.posToXY = posToXY;
/* 物理 (page,y,col) → 論理位置（なければ null）。rowEntries は同じ y の複数セル */
function xyToPos(lay, page, y, col) {
  const p = lay.pages[page]; if (!p) return null;
  let entries = p.rowmap.get(y); if (!entries || !entries.length) return null;
  if (lay.geo && lay.geo.cols2 && y >= 0) { entries = entries.filter(x => inCol(lay.geo, x, col)); if (!entries.length) return null; } /* 2 段組：押した段の行だけ */
  let e = entries.find(x => col >= x.left - 1e-6 && col < x.right - 1e-6) || entries.reduce((b, x) => Math.abs((x.left + x.right) / 2 - col) < Math.abs((b.left + b.right) / 2 - col) ? x : b);
  if (e.fig || e.block) return { line: e.line, seg: 0, off: 0, vcol: null };
  let best = null, dist = Infinity;
  for (const c of e.carets) { const d = Math.abs(c.col - col); if (d < dist) { dist = d; best = c; } }
  const pos = { line: e.line, seg: e.seg, off: best ? best.off : e.endOff, vcol: null };
  if (col > e.endCol + 1e-6 && best && best.off === e.endOff && !e.cell) pos.vcol = half(Math.min(col, e.right - .5)); // 表のセルの中は自由カーソルにしない（字の後ろの空きをクリックすると字の末尾）
  return pos;
}
FZ.xyToPos = xyToPos;
/* 2 段組：行の欄（rowmap の項目）が桁 col と同じ段か。両段にまたがる行（表紙の題）はどちらの段とも見なす */
function inCol(G, e, col) { if (e.right - e.left > G.colW + 1) return true; return (e.left >= G.colX2 - 0.5) === (col >= G.colX2 - 0.5); }
FZ.inCol = inCol;

/* ---------- 原本形式 .fzk（版 2） ----------
 * 生成 AI にそのまま読ませても意味が取れる書き方：
 *  ・先頭は「鍵: 値」の見出し（YAML 風）。--- の後が本文。1 論理行＝1 段落。
 *  ・段落の属性は行頭の [ ] に日本語の語で：[見出し] [項目2] [中央] [引用] [コード:js] [飾り:ベタ白抜き] …
 *  ・文字の修飾は HTML 風の日本語タグ：<太字>…</太字> <傍点> <網掛け> <下線> <白抜き> <取消> <横倍角> <縦倍角> <リンク URL>…</リンク> <画像 URL>…</画像>
 *  ・表は「#表 列 0,10,26,40 様式 格子 見出し淡」の 1 行の後に、| で区切った行（Markdown の表と同じ見た目）。
 *  ・囲み記事は「#囲み ×3」。図は「#箱」「#矢印」「#レーン」と [図11]。
 *  ・名前で表せない罫線・網掛けだけ「#罫 横 0-40 細」「#網 0-40 ×1 薄」で位置を書く。
 * 版 1（1.0.6 以前の短いタグ名）は 1.0.8 で読めなくした。 */
const TAGS = [['太字', M.BOLD], ['下線', M.UNDER], ['二重下線', M.UNDER2], ['波線', M.WAVE], ['傍点', M.DOT], ['網掛け', M.SHADE], ['コード', M.CODE], ['白抜き', M.OUTLINE], ['取消', M.STRIKE], ['二重取消', M.STRIKE2], ['横倍角', M.WIDE], ['縦倍角', M.TALL], ['影', M.SHADOW]];
const STYLE_NAMES = { title: '表題', speech: '発言' };
const STYLE_KEYS = Object.fromEntries(Object.entries(STYLE_NAMES).map(([k, v]) => [v, k]));
const KIND_NAMES = { thin: '細', thick: '太', double: '二重', dotted: '点線', arrow: '矢印', none: '透明' }, KIND_KEYS = { 細: 'thin', 太: 'thick', 二重: 'double', 点線: 'dotted', 矢印: 'arrow', 透明: 'none' };
const DIR_NAMES = { r: '→', l: '←', d: '↓', u: '↑' }, DIR_KEYS = { '→': 'r', '←': 'l', '↓': 'd', '↑': 'u' };
/* 網の文様：画面（二値の網点・線）・印刷・Word（w:shd）・PowerPoint（a:pattFill）の対応をここ 1 か所に。
   kind：dot（網点、被覆率 c）／solid（墨＝黒地。字は白抜き）／line（線、角度 a・間隔 p・太さ w）／cross（直交 2 方向）／pdot（縦横に並ぶ点）。
   順番は原本の名前の後方互換のため変えない（文字の網の文様は番号で持つ。0 は文字用の細かい網） */
const SHADES = [
  { id: 'text', name: '文字', label: '文字の網（細かく薄い点）', kind: 'dot', c: 0.10, p: 1.35, word: 'pct10', ppt: 'pct10' },
  { id: 'light', name: '淡', label: '淡い網（7%）', kind: 'dot', c: 0.07, word: 'pct5', ppt: 'pct5' },
  { id: 'gray', name: '薄', label: '薄い網（13%）', kind: 'dot', c: 0.13, word: 'pct12', ppt: 'pct10' },
  { id: 'mid', name: '中', label: '中くらいの網（30%）', kind: 'dot', c: 0.30, word: 'pct30', ppt: 'pct30' },
  { id: 'deep', name: '濃網', label: '濃い網（55%）', kind: 'dot', c: 0.55, word: 'pct50', ppt: 'pct50' },
  { id: 'dark', name: '濃', label: '墨（黒地に白抜き）', kind: 'solid', word: 'solid', ppt: 'solid' },
  { id: 'ink', name: '濃灰', label: '濃い灰色の網に白抜き（70%）', kind: 'solid', c: 0.70, hex: '4D4D4D', word: 'solid', ppt: 'solid' }, /* 1.0.12b フレームワークの表の見出し。字は白抜き */
  { id: 'hatch', name: '斜線', label: '斜線（右上がり）', kind: 'line', a: 45, p: 2.6, w: 0.34, word: 'thinDiagStripe', ppt: 'ltUpDiag' },
  { id: 'hatch2', name: '逆斜線', label: '斜線（右下がり）', kind: 'line', a: -45, p: 2.6, w: 0.34, word: 'thinReverseDiagStripe', ppt: 'ltDnDiag' },
  { id: 'horz', name: '横線', label: '横線', kind: 'line', a: 0, p: 2.2, w: 0.32, word: 'thinHorzStripe', ppt: 'ltHorz' },
  { id: 'vert', name: '縦線', label: '縦線', kind: 'line', a: 90, p: 2.2, w: 0.32, word: 'thinVertStripe', ppt: 'ltVert' },
  { id: 'grid', name: '格子', label: '格子（縦横）', kind: 'cross', a: 0, p: 2.6, w: 0.3, word: 'thinHorzCross', ppt: 'smGrid' },
  { id: 'check', name: '斜め格子', label: '斜め格子', kind: 'cross', a: 45, p: 2.8, w: 0.3, word: 'thinDiagCross', ppt: 'openDmnd' },
  { id: 'dots', name: '点', label: '点（縦横に並ぶ）', kind: 'pdot', p: 2.8, r: 0.42, word: 'pct10', ppt: 'dotDmnd' },
  { id: 'wide', name: '太斜線', label: '太い斜線', kind: 'line', a: 45, p: 3.2, w: 1.0, word: 'diagStripe', ppt: 'wdUpDiag' },
];
const SHADE_BY = Object.fromEntries(SHADES.map(x => [x.id, x]));
const SHADE_NAMES = Object.fromEntries(SHADES.map(x => [x.id, x.name])), SHADE_KEYS = Object.fromEntries(SHADES.map(x => [x.name, x.id]));
FZ.inkShade = id => !!id && (SHADE_BY[id] || {}).kind === 'solid'; /* 白抜きの字になる地（墨・濃灰） */
FZ.shadeHex = id => (SHADE_BY[id] || {}).hex || '000000';
FZ.SHADES = SHADES; FZ.SHADE_BY = SHADE_BY; FZ.SHADE_NAMES = SHADE_NAMES; FZ.SHADE_KEYS = SHADE_KEYS;
/* 1.0.15a 墨の五階調と朱（UI/UX 提案 A-2）：紙（本文）の濃淡は網の五段（淡 7%・薄 13%・中 30%・濃網 55%・墨）で表し、色は使わない。
   朱は手当ての層（付箋・点検の印・比べた印など、刷られない印）だけに使う。Word・PowerPoint の塗りは網の濃さから同じ灰色に（FZ.shadeHex） */
FZ.SHU = '#d2381c'; FZ.INK_STEPS = ['light', 'gray', 'mid', 'deep', 'dark'];
FZ.SHADE_HEX = { text: 'D9D9D9', light: 'F2F2F2', gray: 'D9D9D9', mid: 'BFBFBF', deep: '8C8C8C', ink: '4D4D4D', dark: '000000' }; /* Office の灰色の段（白 5%・15%・25%・45%・70%・黒）に寄せた写しの表。Word・PowerPoint・プ譜の図形が同じ表を引く */
FZ.shadeHex = id => { if (FZ.SHADE_HEX[id]) return FZ.SHADE_HEX[id]; const s = SHADE_BY[id]; if (!s) return 'D9D9D9'; if (s.hex) return s.hex; if (s.kind === 'solid' && s.c == null) return '000000'; const c = s.c != null ? s.c : 0.15; const v = Math.round(255 * (1 - c)).toString(16).padStart(2, '0').toUpperCase(); return v + v + v; };
FZ.shadeOfMarks = mk => (mk & M.SHADE) ? (SHADES[(mk & M.SHT) >>> 16] || SHADES[0]).id : null; // 文字の網の文様の id
FZ.withShadeType = (mk, id) => { const k = Math.max(0, SHADES.findIndex(x => x.id === id)); return (mk & ~M.SHT) | M.SHADE | (k << 16); };
const LIST_TOKENS = { arrow: '→', todo: '❏', done: '☑', cont: '続き', num: '番号項目' }; /* 1.0.16h 「bullet」は「項目」で書く（1.0.14〜16g は「・N」と書いて読めなかった：読みは下で受ける） */
/* 題として太字が既定の行：表題、題のレベルの数字見出し、記号見出し */
const titleLike = (a, f) => a.style === 'title' || a.style === 'sym' || (a.style === 'num' && (a.level | 0) < (f.titleLevels | 0));
/* 本文のエスケープ：\ は特別な文字（\ < > | [ ] #）の前だけ、< は常に、| は表のセルの中だけ。その他はそのまま（C:\Users\… は素で書ける） */
const ESCAPABLE = '\\<>|[]#';
function escText(t, inTable, next = '') { return t.replace(/\\/g, (c, k, str) => ESCAPABLE.includes(k + 1 < str.length ? str[k + 1] : next) ? '\\\\' : c).replace(/</g, '\\<').replace(/\|/g, inTable ? '\\|' : '|'); }
/* 制御文字（タブ以外）と孤立サロゲートを除く：XML（Word・PowerPoint）が受け付けず、画面にも出ない */
function cleanText(t) { return String(t).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, ''); }
FZ.cleanText = cleanText;
const escUrl = u => String(u).replace(/[\s<>]/g, c => encodeURIComponent(c)); // 解析側は %20 %09 %3C %3E だけ戻す（他の % は触らない）
const unescUrl = u => String(u).replace(/%(20|09|3C|3E)/gi, m => decodeURIComponent(m));
/* 原本の読み書きの間だけ、図番の字と ID の対応を引く文書（parse／serialize が設定する） */
let REFDOC = { refs: { ids: [] } };
FZ.withRefDoc = function (doc, fn) { const k = REFDOC; REFDOC = doc; try { return fn(); } finally { REFDOC = k; } };
/* 修飾の組 → タグの並び [開き, 閉じ]。網掛けの文様は <網掛け 斜線>、2 倍を超える倍角は <倍角 3x4>（横×縦） */
function tagList(mask) { const out = []; const big = (mask & (M.SZW | M.SZH)) !== 0;
  for (const [n, b] of TAGS) { if (!(mask & b)) continue; if (big && (b === M.WIDE || b === M.TALL)) continue; if (b === M.SHADE) { const t = (mask & M.SHT) >>> 16; out.push(t && SHADES[t] ? ['網掛け ' + SHADES[t].name, '網掛け'] : ['網掛け', '網掛け']); continue; } out.push([n, n]); }
  if (big) out.push(['倍角 ' + scaleW(mask) + 'x' + scaleH(mask), '倍角']); else if ((mask & M.NAR) && !(mask & M.WIDE)) out.push(['長体 ' + Math.round(NARROW[(mask & M.NAR) >>> 28] * 100), '長体']); return out; }
/* セグメント → 本文（修飾タグ・リンクタグ付き） */
function segToText(seg, dropMask = 0, inTable = false) {
  let out = '', cur = 0, curLink = null; const t = seg.text, m = seg.marks, links = seg.links || [];
  const STYLE = ~(M.LINK | dropMask); const linkAt = off => links.find(l => l.start <= off && off < l.end) || null;
  const open = mask => tagList(mask).map(([o]) => '<' + o + '>').join('');
  const close = mask => tagList(mask).reverse().map(([, c]) => '</' + c + '>').join('');
  { let plain = !REF_RE.test(t); if (plain) for (let q = 0; q < t.length; q++) if (m[q] | 0) { plain = false; break; } if (plain) return escText(t, inTable); } // 速い道：飾り・リンク・図番の無い本文は丸ごと 1 回でエスケープ
  let run = '', runEnd = 0; const flush = () => { if (run) { out += escText(run, inTable, t[runEnd] || ''); run = ''; } }; // 同じ飾りの続く字はまとめてエスケープ（字ごとの正規表現をやめる）
  for (const g of graphemes(t)) {
    const mk = (m[g.start] | 0) & STYLE; const lk = (m[g.start] & M.LINK) ? linkAt(g.start) : null;
    if (mk !== cur || lk !== curLink) {
      flush(); out += close(cur);
      if (lk !== curLink) { if (curLink) out += curLink.image ? '</画像>' : '</リンク>'; if (lk) out += (lk.image ? '<画像 ' : '<リンク ') + escUrl(lk.url) + '>'; curLink = lk; }
      out += open(mk); cur = mk;
    }
    if (g.text.length === 2 && isRefChar(g.text)) { flush(); const id = FZ.refId(REFDOC, g.text); out += '<図番 ' + (id == null ? '?' : escUrl(id)) + '>'; continue; } // 図番
    run += g.text; runEnd = g.end;
  }
  flush(); out += close(cur); if (curLink) out += curLink.image ? '</画像>' : '</リンク>'; return out;
}
function attrsToText(a, i, doc, opts = {}) {
  const t = [];
  if (a.style === 'num') t.push('番号' + ((a.level | 0) + 1)); else if (a.style === 'sym') t.push('記号' + ((a.level | 0) + 1));
  else if (a.style && STYLE_NAMES[a.style]) t.push(STYLE_NAMES[a.style] + (a.style === 'speech' && a.speakerCols ? a.speakerCols : ''));
  if (a.align === 'center') t.push('中央'); if (a.align === 'right') t.push('右'); if (a.align === 'justify') t.push('均等');
  if (!(opts.article && a.indent === 1 && a.hanging === 1)) { if (a.indent || (a.indent === 0 && nodeKind(a))) t.push('字下げ' + a.indent); if (a.hanging != null) t.push('ぶら下げ' + a.hanging); } // 見出し・箇条書きの 字下げN は「行頭の桁」（0 も明示）
  if (a.list) t.push((LIST_TOKENS[a.list.kind] || '項目') + ((a.list.level | 0) + 1)); if (a.restart) t.push('再開' + (typeof a.restart === 'number' && a.restart > 1 ? a.restart : ''));
  if (a.quote) t.push('引用' + (a.quote > 1 ? a.quote : '')); if (a.code) t.push('コード' + (typeof a.code === 'string' && a.code ? ':' + a.code.replace(/\s.*$/, '') : ''));
  if (a.gantt) { const g = a.gantt; t.push('工程表'); if ((g.labels ?? 1) !== 1) t.push('工程列' + (g.labels | 0)); if ((g.heads | 0) > 1) t.push('工程見出し' + (g.heads | 0)); if (g.base != null) t.push('基準' + g.base); } /* 工程表（表の 1 行目に持つ） */
  if (a.breakBefore) t.push('改頁'); if (a.keep === 'line') t.push('分割禁止'); if (a.keep === 'next' && !(opts.article === 'first')) t.push('次と同頁'); if (a.keep === 'free') t.push('送らない');
  if (a.crow) t.push('行続き'); /* 1.0.12b 表の同じ行の続き（セルの中の改行。上に横罫を引かない行） */
  if (a.cellAlign && a.cellAlign.some(Boolean)) t.push('列揃え' + Array.from(a.cellAlign, x => ({ left: '左', right: '右', center: '中', justify: '均' })[x] || '左').join(''));
  if (a.thin) t.push('細字'); if (a.join) t.push('改行'); if (a.panels) t.push(a.panels === 'h' ? '区画横' : a.panels === 'v' ? '区画縦' : '区画' + (a.panels | 0)); if (Array.isArray(a.panelRatio) && a.panelRatio.length > 1) t.push('区画比' + a.panelRatio.join(':')); if (a.panelWide) t.push('区画全幅'); if (a.panelHead === 'gray') t.push('区画見出し網'); if (a.panelHead === 'ink') t.push('区画見出し濃灰'); if (a.panelHead === 'line') t.push('区画見出し線'); if (a.panelLink === 'arrow') t.push('区画矢印'); if (a.panelLink === 'tri') t.push('区画三角'); if (a.hr) t.push('区切り'); if (a.noRepeat) t.push('見出し繰り返しなし');
  if (a.figure) t.push('図' + (a.figure.h | 0));
  if (a.toc) { const T = normalizeToc(a.toc); t.push('目次' + (T.num ? (T.num[0] + 1) + '-' + (T.num[1] + 1) : '')); if (T.sym) t.push('目次記号' + (T.sym[0] + 1) + '-' + (T.sym[1] + 1)); }
  if (a.deco) t.push('飾り:' + a.deco); if (a.anchor) t.push('節:' + a.anchor); if (a.tid) t.push('表:' + a.tid); if (a.sumRow) t.push('合計行'); /* 1.0.15d 合計の行（直すたびに計算し直す） */ if (a.notes && a.notes.length) for (const id of a.notes) t.push('付箋:' + id); if (a.fw) t.push('枠:' + a.fw); if (a.pufu) t.push('プ譜'); if (a.pufuForm === 'tree' || a.pufuForm === 'cols') t.push(a.pufuForm === 'tree' ? 'プ譜字下げ' : 'プ譜列'); if (a.pufuNames && Object.keys(a.pufuNames).length) t.push('プ譜名:' + Object.entries(a.pufuNames).map(([k, v]) => k + '=' + String(v).replace(/[\s\[\]|=]/g, '')).join('|')); /* 1.0.16h 見せる名前 */ if (a.pufuFrame) t.push('プ譜取組'); if (a.pufuRes) t.push('プ譜資源'); /* 1.0.14a プ譜の節・枠・資源と制約 */ /* 1.0.12 フレームワークの枠（解説を出す節の頭） */ /* 付箋：この行に付いた付箋の id（中身は末尾の #付箋） */
  if (a.cells && doc && doc.lines[i] && doc.lines[i].segs.length === 1 && !opts.inTable) t.push('セル');
  if (Array.isArray(a.unk)) for (const u of a.unk) if (typeof u === 'string' && u && !/[\s\]]/.test(u)) t.push(u); // 知らない属性（前方互換）
  return t.length ? '[' + t.join(' ') + ']' : '';
}
function serialize(doc) { return FZ.withRefDoc(doc, () => withRuleIndex(doc, () => serializeBody(doc))); }
function serializeBody(doc) {
  const f = doc.format, L = [];
  L.push('#fzk 2');
  if (doc.title) L.push('題名: ' + doc.title);
  L.push('用紙: ' + f.paper + (f.paper === 'custom' ? ' ' + f.widthMm + 'x' + f.heightMm : '') + (f.landscape ? ' 横' : ' 縦'));
  L.push('文字数: ' + f.cols); L.push('行数: ' + f.rows); if (f.targetPages) L.push('目標頁数: ' + f.targetPages); if (f.minPt) L.push('最小の字: ' + f.minPt);
  L.push('余白: ' + [f.margins.top, f.margins.right, f.margins.bottom, f.margins.left].join(' '));
  if (f.header) L.push('柱上: ' + f.header); if (f.footer) L.push('柱下: ' + f.footer);
  L.push('柱行: ' + f.headerRows + ' ' + f.footerRows); if ((f.hfGap == null ? 1 : f.hfGap) !== 1) L.push('柱空き: ' + (f.hfGap | 0));
  L.push('書体: ' + (f.font === 'gothic' ? 'ゴシック' : '明朝')); if (f.fontMincho) L.push('明朝書体: ' + f.fontMincho); if (f.fontGothic) L.push('ゴシック書体: ' + f.fontGothic); if (glyphPct(f.zenW) !== 1) L.push('全角字幅: ' + Math.round(glyphPct(f.zenW) * 100) + '%'); if (glyphPct(f.hanW) !== 1) L.push('半角字幅: ' + Math.round(glyphPct(f.hanW) * 100) + '%');
  if (!f.hang) L.push('ぶら下げ: なし');
  L.push('番号体系: ' + normalizeScheme(f.scheme).join(' ')); L.push('題: ' + (f.titleLevels | 0)); L.push('記号見出し: ' + normalizeScheme(f.symScheme, FZ.DEFAULT_SYM).join(' ')); L.push('箇条書き: ' + normalizeScheme(f.bulletScheme, FZ.DEFAULT_BULLET).join(' ')); { const ls = normalizeScheme(f.listScheme, FZ.DEFAULT_LIST); if (ls.join(' ') !== FZ.DEFAULT_LIST.join(' ')) L.push('番号箇条書き: ' + ls.join(' ')); } if (f.symResetsNum) L.push('仕切り直し: あり'); if (f.returnGap) L.push('戻り空き: ' + (f.returnGap === 'rule' ? '区切り線' : 'あり')); if (f.titleGap) L.push('題の前空き: あり'); if (f.titleAfter) L.push('表題の後空き: あり'); if (f.tableGap) L.push('表の前空き: あり'); if (f.bodyFollow) L.push('本文位置: ' + (f.bodyFollow === 'step' ? '見出しの頭から1字' : f.bodyFollow === 'mark' ? '見出しの頭' : '見出しに揃える'));
  if (f.kind === 'slide') { L.push('書式: 資料'); L.push('本文幅: ' + f.bodyPct + '%'); if (f.divider !== 'none') L.push('仕切り: ' + (f.divider === 'dotted' ? '点線' : '細')); L.push('柱の題: ' + (f.headTitle === 'doc' ? '題名' : '頁ごと')); L.push('頁番号: ' + ({ box: '四角', circle: '丸', none: 'なし' })[f.pageMark]); if (f.headRule === 'thick') L.push('柱の罫: 太'); if (f.cover) L.push('表紙: あり' + (f.coverNum ? '（頁番号も）' : '')); if (f.cover && f.coverStyle) L.push('表紙の型: ' + (f.coverStyle === 'toc' ? '目次つき' : '標準')); if (f.cover && f.coverSecret) L.push('表紙の機密: 出す'); }
  if (f.pageStart !== 1) L.push('開始番号: ' + f.pageStart);
  if (f.author) L.push('作成者: ' + f.author); if (f.dateAuto) L.push('作成日: 自動'); else if (f.date) L.push('作成日: ' + f.date); if (f.secret) L.push('機密: ' + f.secret);
  if (f.pageAlt) L.push('控えの版面: ' + JSON.stringify(f.pageAlt)); /* もう一方の種類（文書／資料）の版面 */
  for (const [k, v] of doc.extra || []) L.push(k + ': ' + v); // 知らない鍵（後の版の設定）はそのまま書き戻す
  L.push('---');
  const n = doc.lines.length; const used = new Set(); // 名前で表した罫・網の id
  // 名前で表せるもの：表（#表 … 様式）、囲み記事（#囲み）、見出し飾り（飾り:）
  const tables = new Map(), articles = new Map(), decos = new Map();
  for (let i = 0; i < n;) {
    if (inTable(doc, i)) { let b = i; while (b + 1 < n && inTable(doc, b + 1)) b++; const m = FZ.tableMatch ? FZ.tableMatch(doc, i, b) : null; const bounds = m ? m.bounds : (FZ.tableBounds ? FZ.tableBounds(doc, i) : null); tables.set(i, { b, m, bounds }); if (m) { m.ruleIds.forEach(x => used.add(x)); m.fillIds.forEach(x => used.add(x)); } i = b + 1; continue; }
    const am = FZ.articleMatch ? FZ.articleMatch(doc, i) : null;
    if (am) { articles.set(i, am); am.ruleIds.forEach(x => used.add(x)); am.fillIds.forEach(x => used.add(x)); i = am.b + 1; continue; }
    i++;
  }
  const rsig = r => r.axis === 'h' ? 'h' + r.line + ':' + r.from + ':' + r.to + ':' + r.kind : 'v' + r.col + ':' + r.from + ':' + r.to + ':' + r.kind;
  const usedSig = new Set(); if (used.size) for (const r of doc.rules) if (used.has(r.id)) usedSig.add(rsig(r)); // 名前で表した罫と同じ罫（隣り合う囲みの境の重なりなど）は書かない
  let tbl = null; // 書き出し中の表 { b, bounds }
  const rulesAt = new Map(), fillsAt = new Map(); // 行ごとの罫（横＝その行の上、縦＝その行から）と網。原本の並び（doc.rules の順）を保つ
  for (const r of doc.rules) { const k = r.axis === 'h' ? r.line : r.axis === 'v' ? r.from : null; if (k == null) continue; if (!rulesAt.has(k)) rulesAt.set(k, []); rulesAt.get(k).push(r); }
  for (const x of doc.fills) { if (!fillsAt.has(x.from)) fillsAt.set(x.from, []); fillsAt.get(x.from).push(x); }
  for (let i = 0; i <= n; i++) {
    for (const r of rulesAt.get(i) || NO_RULES) {
      if (used.has(r.id) || (usedSig.size && usedSig.has(rsig(r)))) continue;
      if (r.axis === 'h' && r.line === i) L.push('#罫 横 ' + r.from + '-' + r.to + ' ' + (KIND_NAMES[r.kind] || '細') + (r.kind === 'arrow' ? (DIR_NAMES[r.dir] || '→') : ''));
      if (r.axis === 'v' && r.from === i) L.push('#罫 縦 ' + r.col + ' ×' + (r.to - r.from + 1) + ' ' + (KIND_NAMES[r.kind] || '細') + (r.kind === 'arrow' ? (DIR_NAMES[r.dir] || '↓') : ''));
    }
    for (const x of fillsAt.get(i) || NO_RULES) if (!used.has(x.id)) L.push('#網 ' + x.col + '-' + (x.col + x.cols) + ' ×' + (x.to - x.from + 1) + ' ' + (SHADE_NAMES[x.shade] || '薄'));
    if (i === n) break;
    const ln = doc.lines[i];
    if (articles.has(i)) { const am = articles.get(i); L.push('#囲み ×' + (am.b - i + 1) + (am.titled === false ? ' 見出しなし' : '') + (am.L != null && (am.L > 1e-6 || am.R < f.cols - 1e-6) ? ' 位置 ' + am.L + '-' + am.R : '')); } /* 1.0.12c 位置と幅（左の罫の桁-右の罫の桁） */
    if (tables.has(i)) { const t = tables.get(i); tbl = { b: t.b, bounds: t.bounds }; const m = t.m; L.push('#表 列 ' + (t.bounds || []).join(',') + ' 様式 ' + (m ? (FZ.TABLE_NAMES[m.preset] || m.preset) + (m.headFill ? ' 見出し' + SHADE_NAMES[m.headFill] : '') + (m.sideFill ? ' 表側' + SHADE_NAMES[m.sideFill] : '') : '独自')); }
    if (ln.attrs.figure && FZ.figureToLines) L.push(...FZ.figureToLines(ln.attrs.figure));
    if (tbl && i <= tbl.b && tbl.bounds) { // 表の行：| で区切る。列境界が表の既定と違う行は #列 で先に示す
      const cells = cellsAt(doc, i, f.cols).filter(c => c.left >= tbl.bounds[0] && c.right <= tbl.bounds[tbl.bounds.length - 1]); const rb = [cells[0] ? cells[0].left : 0, ...cells.map(c => c.right)];
      if (rb.join(',') !== tbl.bounds.join(',')) L.push('#列 ' + rb.join(','));
      const texts = cells.map(c => { const sg = ln.segs.filter(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6); return sg.map(x => segToText(x, 0, true)).join(''); });
      L.push(attrsToText(ln.attrs, i, doc, { inTable: true }) + '| ' + texts.join(' | ') + ' |'); figLines(ln);
      if (i === tbl.b) tbl = null; continue;
    }
    if (ln.attrs.raw && Object.keys(ln.attrs).every(k => k === 'raw' || k === 'figs') && ln.segs.length === 1 && !ln.segs[0].col && /^#[^\s#]/.test(ln.segs[0].text) && ln.segs[0].marks.every(mk => !mk)) { L.push(ln.segs[0].text); figLines(ln); continue; } // 知らない指示行はそのまま
    const art = [...articles.entries()].find(([a, m]) => i >= a && i <= m.b); const prefix = attrsToText(ln.attrs, i, doc, { deco: decos.get(i), article: art ? (art[0] === i && art[1].titled !== false ? 'first' : true) : false }); let body = prefix;
    // 見出し・表題は太字が既定：全体が太字なら <太字> を書かない
    const headBold = titleLike(ln.attrs, f) && ln.segs.every(sg => sg.marks.every(mk => mk & M.BOLD)) ? M.BOLD : 0;
    ln.segs.forEach((s, k) => { if (k > 0 || s.col > 0) body += '<桁' + s.col + '>'; body += segToText(s, headBold); });
    if (!prefix && /^[#\[|]/.test(body)) body = '\\' + body; // 行頭の [ # | は指示行・表の行と紛れるので \ を付ける（インラインのエスケープとして読む）
    L.push(body); figLines(ln);
  }
  /* 付箋：「#付箋 id 作成者 日時 状態 「引用」」の後に本文の行、返信は「#返信 作成者 日時」、最後に「#付箋ここまで」 */
  L.push(...notesLines(doc));
  /* 1.0.14e プ譜の局面：「#局面 節の名札 番号 日付 題」の後に役の名前付きの Markdown、最後に「#局面ここまで」 */
  for (const ph of doc.pufuPhases || []) L.push('#局面 ' + ph.key + ' ' + (ph.no | 0) + ' ' + (String(ph.date || '').replace(/\s+/g, '_') || '-') + (ph.title ? ' ' + String(ph.title).replace(/[\r\n]+/g, ' ') : ''), ...String(ph.md || '').replace(/\n+$/, '').split('\n').map(x => /^[#\\]/.test(x) ? '\\' + x : x), '#局面ここまで');
  /* 1.0.15b 構成の型（「#型 id」）と、点検で無視した所（「#点検無視 決まりの id|字」） */
  if (doc.kata) L.push('#型 ' + doc.kata); if (doc.kind) L.push('#文書の種類 ' + doc.kind); /* 1.0.16a */ for (const k of doc.proofIgnore || []) L.push('#点検無視 ' + String(k).replace(/[\r\n]+/g, ' '));
  /* 保留の島（S4）：「#保留 id 名前」から「#保留ここまで」まで。中は本文と同じ書き方 */
  for (const p of doc.parked || []) { const sub = { ...doc, lines: p.lines, rules: [], fills: [], parked: [], images: {}, notes: [] }; const t = serialize(sub); const body = t.slice(t.indexOf('\n---\n') + 5).replace(/\n$/, ''); L.push('#保留 ' + p.id + (p.label ? ' ' + p.label : ''), ...body.split('\n'), '#保留ここまで'); }
  /* 添付（画像）：=== の後に「#添付 名前 種類」と base64（76 字ずつ）。図版が使っている画像だけ（保留の島の図版も） */
  const names = []; for (const ln of doc.lines.concat(...(doc.parked || []).map(p => p.lines))) for (const fg of ln.attrs.figs || []) if (fg.file && doc.images && doc.images[fg.file] && !names.includes(fg.file)) names.push(fg.file);
  if (names.length) { L.push('==='); for (const nm of names) { const im = doc.images[nm]; L.push('#添付 ' + escUrl(nm) + ' ' + im.mime); const d = im.data.replace(/\s+/g, ''); for (let k = 0; k < d.length; k += 76) L.push(d.slice(k, k + 76)); } }
  return L.join('\n') + '\n';
  function figLines(ln) { for (const fg of ln.attrs.figs || []) { if (fg.chart && FZ.chartLines) { L.push(...FZ.chartLines(fg)); continue; } const tt = String(fg.title || '').replace(/[\r\n]+/g, ' ').trim(); const zt = FZ.figSizeToks(fg); const wd = zt.length ? ' ' + zt.join(' ') : /(^|\s)(\d+%|1\/\d|原寸\d+%)$/.test(tt) ? ' 100%' : ''; L.push('#図版 ' + escUrl(fg.id) + ' ' + fg.kind + (tt ? ' ' + tt : '') + ' ' + (fg.file ? escUrl(fg.file) : '-') + wd); } }
}
FZ.serialize = serialize; FZ.titleLike = (a, f) => titleLike(a, f);

function parseAttrs(s) {
  const a = {}; const deco = [], unk = []; let n = 0;
  for (let tok of s.split(/[\s　]+/).filter(Boolean)) {
    let m; n++; tok = tok.normalize('NFKC'); // 全角の数字・記号も受ける
    if (STYLE_KEYS[tok]) a.style = STYLE_KEYS[tok];
    else if ((m = tok.match(/^番号(\d+)$/))) { a.style = 'num'; a.level = clamp(+m[1] - 1, 0, 7); } else if ((m = tok.match(/^記号(\d+)$/))) { a.style = 'sym'; a.level = clamp(+m[1] - 1, 0, 7); }
    else if (tok === '見出し' || tok === '見出し1') a.style = 'h1'; else if (tok === '見出し2') a.style = 'h2'; else if (tok === '見出し3') a.style = 'h3'; // 1.0.8 以前（normalize で読み替え）
    else if ((m = tok.match(/^発言(\d+)$/))) { a.style = 'speech'; a.speakerCols = +m[1]; }
    else if (tok === '中央') a.align = 'center'; else if (tok === '右') a.align = 'right'; else if (tok === '均等') a.align = 'justify'; else if (tok === '左') a.align = 'left';
    else if ((m = tok.match(/^字下げ(\d+)$/))) a.indent = +m[1]; else if ((m = tok.match(/^ぶら下げ(\d+)$/))) a.hanging = +m[1];
    else if ((m = tok.match(/^(?:項目|[・･])(\d+)$/))) a.list = { level: +m[1] - 1 }; /* 1.0.16h 「・N」（1.0.14〜16g のプ譜の型が書いた形）も箇条書きとして読む */
    else if ((m = tok.match(/^続き(\d+)$/))) a.list = { kind: 'cont', level: +m[1] - 1 };
    else if ((m = tok.match(/^番号項目(\d+)$/))) a.list = { kind: 'num', level: +m[1] - 1 };
    else if ((m = tok.match(/^→(\d+)$/))) a.list = { kind: 'arrow', level: +m[1] - 1 }; else if ((m = tok.match(/^❏(\d+)$/))) a.list = { kind: 'todo', level: +m[1] - 1 }; else if ((m = tok.match(/^☑(\d+)$/))) a.list = { kind: 'done', level: +m[1] - 1 };
    else if ((m = tok.match(/^再開(\d*)$/))) a.restart = m[1] && +m[1] > 1 ? +m[1] : true;
    else if ((m = tok.match(/^引用(\d*)$/))) a.quote = m[1] ? +m[1] : 1; else if ((m = tok.match(/^コード(?:[:：](\S*))?$/))) a.code = m[1] || true;
    else if (tok === '工程表') a.gantt = a.gantt || { labels: 1, heads: 1 }; else if ((m = tok.match(/^工程列(\d+)$/))) (a.gantt = a.gantt || { labels: 1, heads: 1 }).labels = clamp(+m[1], 0, 6); else if ((m = tok.match(/^工程見出し(\d+)$/))) (a.gantt = a.gantt || { labels: 1, heads: 1 }).heads = clamp(+m[1], 1, 3); else if ((m = tok.match(/^基準(\d+(?:\.\d+)?)$/))) (a.gantt = a.gantt || { labels: 1, heads: 1 }).base = +m[1];
    else if (tok === '改頁') a.breakBefore = true; else if (tok === '分割禁止') a.keep = 'line'; else if (tok === '次と同頁') a.keep = 'next'; else if (tok === '送らない') a.keep = 'free';
    else if (tok === '合計行') a.sumRow = true; else if (tok === 'セル') a.cells = true; else if (tok === '細字') a.thin = true; else if (tok === '改行') a.join = true; else if (/^区画[2-6]$/.test(tok)) a.panels = +tok.slice(2); else if (tok === '区画横') a.panels = 'h'; else if (tok === '区画縦') a.panels = 'v'; else if (tok === '区画見出し網') a.panelHead = 'gray'; else if (tok === '区画見出し濃灰') a.panelHead = 'ink'; else if (/^区画比\d+(\.\d+)?(:\d+(\.\d+)?)+$/.test(tok)) a.panelRatio = tok.slice(3).split(':').map(Number); else if (tok === '区画全幅') a.panelWide = true; else if (tok === '区画見出し線') a.panelHead = 'line'; else if (tok === '区画矢印') a.panelLink = 'arrow'; else if (tok === '区画三角') a.panelLink = 'tri'; else if (tok === '区切り') a.hr = true; else if (tok === 'プ譜') a.pufu = true; else if (tok === 'プ譜字下げ') a.pufuForm = 'tree'; else if (tok === 'プ譜列') a.pufuForm = 'cols'; else if (tok.startsWith('プ譜名:')) { const m = {}; for (const kv of tok.slice(4).split('|')) { const i = kv.indexOf('='); if (i > 0 && kv.slice(i + 1)) m[kv.slice(0, i)] = kv.slice(i + 1); } if (Object.keys(m).length) a.pufuNames = m; } /* 1.0.16h */ /* 1.0.14g 紙面の形（無ければ自動） */ else if (tok === 'プ譜取組' || tok === 'プ譜枠') a.pufuFrame = true; /* 1.0.14b までは「プ譜枠」 */ else if (tok === 'プ譜資源') a.pufuRes = true; else if (tok === '見出し繰り返しなし') a.noRepeat = true;
    else if (tok === '行続き') a.crow = true;
    else if ((m = tok.match(/^列揃え([左右中均]+)$/))) a.cellAlign = Array.from(m[1]).map(ch => ({ 左: 'left', 右: 'right', 中: 'center', 均: 'justify' })[ch]);
    else if ((m = tok.match(/^図(\d+)$/))) a.figure = { h: +m[1], boxes: [], arrows: [], lanes: null };
    else if ((m = tok.match(/^目次(?:(\d)(?:[-~〜]|－)?(\d)?)?$/))) { a.toc = a.toc || { num: null, sym: null }; if (m[1]) a.toc.num = [+m[1] - 1, (m[2] ? +m[2] : +m[1]) - 1]; }
    else if ((m = tok.match(/^目次記号(\d)(?:[-~〜]|－)?(\d)?$/))) { a.toc = a.toc || { num: null, sym: null }; a.toc.sym = [+m[1] - 1, (m[2] ? +m[2] : +m[1]) - 1]; }
    else if ((m = tok.match(/^飾り[:：](.+)$/))) deco.push(m[1]); else if ((m = tok.match(/^節[:：]([A-Za-z0-9_-]+)$/))) a.anchor = m[1]; else if ((m = tok.match(/^表[:：]([A-Za-z0-9_-]+)$/))) a.tid = m[1]; else if ((m = tok.match(/^付箋[:：]([A-Za-z0-9_-]+)$/))) (a.notes = a.notes || []).push(m[1]); else if ((m = tok.match(/^枠[:：]([A-Za-z0-9_-]+)$/))) a.fw = m[1];
    else { n--; unk.push(tok); } // 認識できない語：後の版の属性かもしれないので、行が属性を持つときは捨てずに持ち回る（前方互換）
  }
  Object.defineProperty(a, '_n', { value: n, enumerable: false, configurable: true, writable: true }); // 認識した語の数（0 なら属性ではない）
  if (deco.length) Object.defineProperty(a, '_deco', { value: deco, enumerable: false, configurable: true, writable: true });
  if (unk.length && n > 0) a.unk = unk;
  return a;
}
/* 本文（タグ付き）をセグメントに書き込む。<桁N> で新しいセグメントへ。戻り値：セグメント列 */
function parseInlineText(rest, seg0) {
  const segs = []; let seg = seg0 || newSeg(0, ''), mask = 0, link = null;
  let i = 0; const push = (ch) => { seg.text += ch; for (let k = 0; k < ch.length; k++) seg.marks.push(mask); };
  const endLink = () => { if (link) { link.end = seg.text.length; if (link.end > link.start) (seg.links = seg.links || []).push(link); } link = null; mask &= ~M.LINK; };
  while (i < rest.length) {
    const c = rest[i];
    if (c === '\\' && i + 1 < rest.length && ESCAPABLE.includes(rest[i + 1])) { push(rest[i + 1]); i += 2; continue; }
    if (c === '<') {
      const e = rest.indexOf('>', i); if (e > i) {
        const tag = rest.slice(i + 1, e); let m;
        if ((m = tag.match(/^桁(\d+(?:\.5)?)$/))) { endLink(); segs.push(seg); seg = newSeg(+m[1], ''); mask = 0; i = e + 1; continue; }
        if ((m = tag.match(/^(リンク|画像)\s+(\S+)$/))) { endLink(); link = { start: seg.text.length, end: 0, url: unescUrl(m[2]) }; if (m[1] === '画像') link.image = true; mask |= M.LINK; i = e + 1; continue; }
        if (tag === '/リンク' || tag === '/画像') { endLink(); i = e + 1; continue; }
        if ((m = tag.match(/^図番\s+(\S+)$/))) { push(FZ.refChar(REFDOC, unescUrl(m[1]))); i = e + 1; continue; }
        if ((m = tag.match(/^網掛け[\s　]+(\S+)$/))) { const k = SHADES.findIndex(x => x.name === m[1]); mask = (mask & ~M.SHT) | M.SHADE | (Math.max(0, k) << 16); i = e + 1; continue; } // 網掛けの文様
        if ((m = tag.match(/^倍角[\s　]+(\d)\s*[x×]\s*(\d)$/))) { mask = withScale(mask, +m[1], +m[2]); i = e + 1; continue; } // m×n 倍角
        if (tag === '/倍角') { mask &= ~SIZE_BITS; i = e + 1; continue; }
        if ((m = tag.match(/^長体[\s　]+(\d+)\s*%?$/))) { const k = NARROW.indexOf(+m[1] / 100); if (k > 0) { mask = (mask & ~M.NAR) | (k << 28); i = e + 1; continue; } } // 長体 90・75・50
        if (tag === '/長体') { mask &= ~M.NAR; i = e + 1; continue; }
        if (tag === '/網掛け') { mask &= ~(M.SHADE | M.SHT); i = e + 1; continue; }
        const closing = tag.startsWith('/'); const name = closing ? tag.slice(1) : tag; const t = TAGS.find(([n]) => n === name);
        if (t) { mask = closing ? (mask & ~t[1]) : (mask | t[1]); i = e + 1; continue; }
      }
    }
    push(c); i++;
  }
  endLink(); segs.push(seg); return segs;
}
function parseBody(body) { // "[attrs]text<桁N>text" → {attrs, segs}
  let attrs = {}, rest = body;
  const am = rest.match(/^\[([^\]]*)\]/); if (am) { const a = parseAttrs(am[1]); if (a._n > 0) { attrs = a; rest = rest.slice(am[0].length); } } // 認識できる語が無ければ [ ] ごと本文（[重要]… を消さない）
  const segs = parseInlineText(rest);
  if (segs.length > 1) attrs.cells = true;
  return { attrs, segs };
}
/* 表の行 "| a | b |" → セル文字列の列（\| はエスケープ。タグの中の | は区切らない） */
function splitRow(s) {
  s = s.trim(); if (s.startsWith('|')) s = s.slice(1); if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
  const cells = []; let cur = '', depth = 0; for (let i = 0; i < s.length; i++) { const c = s[i]; if (c === '\\' && i + 1 < s.length) { cur += c + s[i + 1]; i++; continue; } if (c === '<') depth++; else if (c === '>' && depth) depth--; if (c === '|' && !depth) { cells.push(cur); cur = ''; continue; } cur += c; }
  cells.push(cur); return cells.map(c => c.replace(/^ /, '').replace(/ $/, ''));
}
function parse(text) {
  const src = String(text).replace(/^﻿/, '').replace(/\r\n?/g, '\n');
  if (!/^#fzk\b/.test(src)) return fromPlain(src);
  const doc = newDoc(); doc.lines = []; doc.images = {}; doc.refs = { ids: [] };
  return FZ.withRefDoc(doc, () => parseBody2(doc, src));
}
function parseBody2(doc, src) {
  const f = doc.format;
  const lines = src.split('\n'); let i = 1;
  for (; i < lines.length && lines[i] !== '---'; i++) {
    const m = lines[i].match(/^([^:：]+)[:：]\s*(.*)$/); if (!m) continue; const k = m[1].trim(), v = m[2].trim();
    if (k === '題名') doc.title = v;
    else if (k === '用紙') { const parts = v.split(/\s+/); f.paper = PAPERS[parts[0]] ? parts[0] : 'custom'; if (PAPERS[parts[0]]) [f.widthMm, f.heightMm] = PAPERS[parts[0]]; else { const d = (parts[1] || '').match(/^(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)$/); if (d) { f.widthMm = +d[1]; f.heightMm = +d[2]; } } f.landscape = parts.includes('横'); if (f.landscape && f.widthMm < f.heightMm) [f.widthMm, f.heightMm] = [f.heightMm, f.widthMm]; }
    else if (k === '文字数') f.cols = +v; else if (k === '行数') f.rows = +v; else if (k === '目標頁数') f.targetPages = +v; else if (k === '最小の字') f.minPt = +v;
    else if (k === '余白') { const n = v.split(/\s+/).map(Number); if (n.length === 4) f.margins = { top: n[0], right: n[1], bottom: n[2], left: n[3] }; }
    else if (k === '柱上') f.header = v; else if (k === '柱下') f.footer = v;
    else if (k === '柱行') { const n = v.split(/\s+/).map(Number); f.headerRows = n[0] | 0; f.footerRows = n[1] | 0; } else if (k === '柱空き') f.hfGap = clamp(+v | 0, 0, 4);
    else if (k === '書体') f.font = v === 'ゴシック' ? 'gothic' : 'mincho'; else if (k === '明朝書体') f.fontMincho = v; else if (k === 'ゴシック書体') f.fontGothic = v; else if (k === '全角字幅') f.zenW = Math.round(glyphPct(parseFloat(v)) * 100); else if (k === '半角字幅') f.hanW = Math.round(glyphPct(parseFloat(v)) * 100);
    else if (k === 'ぶら下げ') f.hang = v !== 'なし';
    else if (k === '番号体系') f.scheme = normalizeScheme(v); else if (k === '題') f.titleLevels = clamp(+v | 0, 0, 8); else if (k === '記号見出し') f.symScheme = normalizeScheme(v, FZ.DEFAULT_SYM); else if (k === '箇条書き') f.bulletScheme = normalizeScheme(v, FZ.DEFAULT_BULLET); else if (k === '番号箇条書き') f.listScheme = normalizeScheme(v, FZ.DEFAULT_LIST); else if (k === '仕切り直し') f.symResetsNum = v === 'あり'; else if (k === '戻り空き') f.returnGap = /区切/.test(v) ? 'rule' : v === 'あり'; else if (k === '題の前空き') f.titleGap = v === 'あり'; else if (k === '表題の後空き') f.titleAfter = v === 'あり'; else if (k === '表の前空き') f.tableGap = v === 'あり'; else if (k === '本文位置') f.bodyFollow = /頭/.test(v) ? (/[1１一]字|\+/.test(v) ? 'step' : 'mark') : /見出し|文字/.test(v);
    else if (k === '控えの版面') { try { f.pageAlt = JSON.parse(v); } catch (e) { /* 読めなければ控え無し */ } }
    else if (k === '書式') f.kind = /資料/.test(v) ? 'slide' : 'doc'; else if (k === '本文幅') f.bodyPct = +v.replace(/[%％]/, '') || 60; else if (k === '仕切り') f.divider = v === '細' ? 'thin' : v === '点線' ? 'dotted' : 'none'; else if (k === '柱の題') f.headTitle = /通し|題名/.test(v) ? 'doc' : 'page'; else if (k === '作成者') f.author = v; else if (k === '作成日' || k === '日付') { if (/^(自動|今日)$/.test(v)) { f.dateAuto = true; f.date = ''; } else f.date = v; } else if (k === '機密') f.secret = v; else if (k === '頁番号') f.pageMark = v === '丸' ? 'circle' : v === 'なし' ? 'none' : 'box'; else if (k === '柱の罫') f.headRule = v === '太' ? 'thick' : 'thin'; else if (k === '表紙の型') f.coverStyle = /目次/.test(v) ? 'toc' : /標準/.test(v) ? 'std' : ''; else if (k === '表紙の機密') f.coverSecret = /出す|あり/.test(v); else if (k === '段組') { /* 1.0.10u で撤去：読み捨てる */ } else if (k === '表紙') { f.cover = /あり/.test(v); f.coverNum = /頁番号/.test(v); } else if (k === '開始番号') f.pageStart = clamp(parseInt(v, 10) || 0, 0, 9999);
    else if (k === '見出し番号') f.headingNumbers = v === 'あり'; else if (k === '階層') { f.scheme = normalizeScheme(v); f.headingNumbers = !!f.headingNumbers; } else if (k === '開始階層') f.levelStart = clamp((+v | 0) - 1, 0, 7); else (doc.extra || (doc.extra = [])).push([k, v]); // 1.0.8 以前（読み替え）
  }
  if (!f.header) f.header = ''; if (lines[i] === '---') i++;
  const pending = []; const parkSrc = []; let lastChart = null; let pendingFig = null, tbl = null, rowBounds = null; const decos = [], articles = [], tablesDone = [];
  const endTable = () => { if (!tbl) return; const t = tbl; tbl = null; if (t.rows === 0) return; tablesDone.push({ a: t.start, b: t.start + t.rows - 1, bounds: t.bounds, preset: t.preset, headFill: t.headFill, sideFill: t.sideFill }); };
  const kindOf = t => { const k = KIND_KEYS[t.replace(/[→←↓↑]$/, '')] || 'thin'; const d = DIR_KEYS[t.slice(-1)]; return d ? { kind: k, dir: d } : { kind: k }; };
  const C = f.cols; const span = v => Math.max(0, v | 0);
  const sortBounds = arr => { const b = [...new Set(arr.filter(Number.isFinite).map(v => clamp(v, 0, C)))].sort((x, y) => x - y); return b.length >= 2 ? b : null; }; // 列境界：整列・重複除去・範囲内。不正なら null
  for (; i < lines.length; i++) {
    let raw = cleanText(lines[i]);
    if (i === lines.length - 1 && raw === '') break;
    let m;
    if (raw === '===' && /^#添付\s/.test(lines[i + 1] || '')) { // 添付（画像）：ここで本文は終わり
      let cur = null; const flush = () => { if (cur && cur.data) doc.images[cur.name] = { mime: cur.mime, data: cur.data }; cur = null; };
      for (let k = i + 1; k < lines.length; k++) { const l = lines[k].trim(); const am = l.match(/^#添付\s+(\S+)\s+(image\/[\w.+-]+)/); if (am) { flush(); cur = { name: unescUrl(am[1]), mime: am[2], data: '' }; continue; } if (cur && /^[A-Za-z0-9+/=]+$/.test(l)) cur.data += l; }
      flush(); i = lines.length; break; }
    if ((m = raw.match(/^#付箋\s+([A-Za-z0-9_-]+)\s+(\S+)\s+(\S+)\s+(済|未)(?:\s+「(.*)」)?\s*$/))) { const un = t => t === '-' ? '' : t.replace(/_/g, ' '); const note = { id: m[1], author: un(m[2]), date: un(m[3]), done: m[4] === '済', quote: m[5] || '', text: '', replies: [] }; let cur = note, buf = []; let k = i + 1;
      const flush = () => { cur.text = buf.join('\n').replace(/^\n+|\n+$/g, ''); buf = []; };
      for (; k < lines.length; k++) { const r2 = cleanText(lines[k]); let mm; if (r2 === '#付箋ここまで') break; if ((mm = r2.match(/^#返信\s+(\S+)\s+(\S+)\s*$/))) { flush(); cur = { author: un(mm[1]), date: un(mm[2]), text: '' }; note.replies.push(cur); continue; } buf.push(lines[k].replace(/^\\#/, '#')); }
      flush(); (doc.notes = doc.notes || []).push(note); i = k; continue; } // 付箋
    if ((m = raw.match(/^#局面\s+([A-Za-z0-9_-]+)\s+(\d+)\s+(\S+)(?:\s+(.*))?$/))) { const ph = { key: m[1], no: +m[2], date: m[3] === '-' ? '' : m[3].replace(/_/g, ' '), title: (m[4] || '').trim(), md: '' }; const buf = []; let k = i + 1; for (; k < lines.length; k++) { const r2 = cleanText(lines[k]); if (r2 === '#局面ここまで') break; buf.push(lines[k].replace(/^\\/, '')); } ph.md = buf.join('\n'); (doc.pufuPhases = doc.pufuPhases || []).push(ph); i = k; continue; } // 1.0.14e プ譜の局面
    if ((m = raw.match(/^#型\s+([A-Za-z0-9_-]+)\s*$/))) { doc.kata = m[1]; continue; } /* 1.0.15b */ if ((m = raw.match(/^#文書の種類\s+([^\s#]{1,12})\s*$/))) { doc.kind = m[1]; continue; } /* 1.0.16a */
    if ((m = raw.match(/^#点検無視\s+(\S.*)$/))) { (doc.proofIgnore = doc.proofIgnore || []).push(m[1]); continue; }
    if ((m = raw.match(/^#保留\s+([A-Za-z0-9_-]+)\s*(.*)$/))) { const chunk = []; let k = i + 1; for (; k < lines.length; k++) { const r2 = cleanText(lines[k]); if (r2 === '#保留ここまで') break; chunk.push(lines[k]); } parkSrc.push({ id: m[1], label: m[2].trim(), body: chunk.join('\n') }); i = k; continue; } // 保留の島
    if (lastChart && !/^#(データ|グラフ設定)/.test(raw)) lastChart = null;
    if ((m = raw.match(/^#グラフ\s+(.+)$/)) && FZ.chartFigFromLine) { const fig = FZ.chartFigFromLine(m[1]); if (fig) { if (!doc.lines.length) doc.lines.push(newLine()); const ln = doc.lines[doc.lines.length - 1]; (ln.attrs.figs = ln.attrs.figs || []).push(fig); lastChart = fig; continue; } } // グラフ：直前の行に付く図版。続く #データ・#グラフ設定 で中身
    if (lastChart && FZ.chartDirective(raw, lastChart)) continue;
    if ((m = raw.match(/^#図版\s+(.+)$/))) { const toks = m[1].trim().split(/[ \t]+/); if (toks.length >= 3) { const id = unescUrl(toks[0]), kind = toks[1] === '表' ? '表' : '図'; let rest = toks.slice(2); const sz = {}; while (rest.length > 1 && FZ.figSizeTok(rest[rest.length - 1])) Object.assign(sz, FZ.figSizeTok(rest.pop())); const file = rest.pop(); const fig = { id, kind, title: rest.join(' '), file: file === '-' ? '' : unescUrl(file), ...figSize(sz) };
        if (!doc.lines.length) doc.lines.push(newLine()); const ln = doc.lines[doc.lines.length - 1]; (ln.attrs.figs = ln.attrs.figs || []).push(fig); } continue; } // 図版：直前の行に付く
    if ((m = raw.match(/^#罫\s+横\s+(\d+(?:\.5)?)-(\d+(?:\.5)?)\s*(\S*)/))) { const a = clamp(+m[1], 0, C), b = clamp(+m[2], 0, C); if (a !== b) pending.push({ rule: { axis: 'h', from: Math.min(a, b), to: Math.max(a, b), ...kindOf(m[3]) } }); continue; }
    if ((m = raw.match(/^#罫\s+縦\s+(\d+(?:\.5)?)\s*(?:×|x)(\d+)\s*(\S*)/))) { if (span(+m[2]) > 0) pending.push({ rule: { axis: 'v', col: clamp(+m[1], 0, C), span: span(+m[2]), ...kindOf(m[3]) } }); continue; }
    if ((m = raw.match(/^#網\s+(\d+(?:\.5)?)-(\d+(?:\.5)?)\s*(?:×|x)(\d+)\s*(\S*)/))) { const a = clamp(+m[1], 0, C), b = clamp(+m[2], 0, C); if (a !== b && span(+m[3]) > 0) pending.push({ fill: { col: Math.min(a, b), cols: Math.abs(b - a), span: span(+m[3]), shade: SHADE_KEYS[m[4]] || 'gray' } }); continue; }
    if (/^#(箱|矢印|レーン|線|字|図種)\s/.test(raw) && FZ.figureDirective) { if (!pendingFig) pendingFig = { boxes: [], arrows: [], lanes: null }; FZ.figureDirective(raw, pendingFig); continue; }
    if ((m = raw.match(/^#囲み\s+(?:×|x)(\d+)(\s+見出しなし)?(?:\s+位置\s+(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?))?/))) { articles.push({ start: doc.lines.length, n: +m[1], titled: !m[2], L: m[3] != null ? +m[3] : null, R: m[4] != null ? +m[4] : null }); continue; }
    if ((m = raw.match(/^#表(?:\s+(.*))?$/))) { endTable(); const toks = (m[1] || '').trim().split(/\s+/).filter(Boolean); const t = { start: doc.lines.length, rows: 0, bounds: null, preset: 'custom', headFill: null, sideFill: null };
      for (let k = 0; k < toks.length; k++) { const tk = toks[k]; let mm; if (tk === '列' && toks[k + 1]) { t.bounds = sortBounds(toks[++k].split(',').map(Number)); } else if (tk === '様式' && toks[k + 1]) { const nm = toks[++k]; const pid = FZ.TABLE_NAMES ? Object.keys(FZ.TABLE_NAMES).find(id => FZ.TABLE_NAMES[id] === nm) : null; t.preset = pid || (nm === '独自' ? 'custom' : 'grid'); } else if ((mm = tk.match(/^見出し(.+)$/))) t.headFill = SHADE_KEYS[mm[1]] ?? null; else if ((mm = tk.match(/^表側(.+)$/))) t.sideFill = SHADE_KEYS[mm[1]] ?? null; }
      if (!t.bounds || t.bounds.length < 2) t.bounds = [0, f.cols]; tbl = t; continue; }
    if ((m = raw.match(/^#列\s+([\d.,]+)/))) { rowBounds = sortBounds(m[1].split(',').map(Number)); continue; }
    if ((m = raw.match(/^(#{1,6})[ \t]+(\S.*)$/))) raw = '[番号' + Math.min(8, m[1].length) + ']' + m[2]; // Markdown 流の「# 見出し」は数字見出しとして受ける
    else if (/^#(?:罫|網|箱|矢印|レーン|囲み|表|列|図版|添付)(?:\s|$)/.test(raw)) continue; // 形の崩れた指示行は捨てる（上で読めなかったもの）
    // それ以外の # で始まる行は本文として残す（黙って捨てない）
    const idx = doc.lines.length;
    for (const p of pending) { if (p.rule) { const r = { id: FZ.uid(), kind: p.rule.kind, axis: p.rule.axis }; if (p.rule.dir) r.dir = p.rule.dir; if (r.axis === 'h') { r.line = idx; r.from = p.rule.from; r.to = p.rule.to; } else { r.col = p.rule.col; r.from = idx; r.to = idx + p.rule.span - 1; } doc.rules.push(r); } else { doc.fills.push({ id: FZ.uid(), col: p.fill.col, cols: p.fill.cols, from: idx, to: idx + p.fill.span - 1, shade: p.fill.shade }); } }
    pending.length = 0;
    // 表の行（#表 の後、[属性] を除いた本文が | で始まる）
    if (tbl) { const am = raw.match(/^\[([^\]]*)\]/); const aa = am ? parseAttrs(am[1]) : null; const after = aa && aa._n > 0 ? raw.slice(am[0].length) : raw;
      if (/^\|/.test(after)) { const attrs = aa && aa._n > 0 ? aa : {}; const bounds = rowBounds || tbl.bounds; rowBounds = null; const cells = splitRow(after); const nCells = bounds.length - 1; const segs = [];
        for (let c = 0; c < nCells; c++) { const txt = c < nCells - 1 ? (cells[c] || '') : cells.slice(c).join(' | '); const sg = parseInlineText(txt, newSeg(bounds[c], ''))[0]; segs.push(sg); }
        attrs.cells = true; delete attrs._deco; doc.lines.push({ segs, attrs }); tbl.rows++;
        if (bounds !== tbl.bounds && tbl.preset !== 'custom') { for (const c of bounds) if (!tbl.bounds.includes(c)) tbl.extraCols = (tbl.extraCols || []).concat({ line: idx, col: c }); }
        continue; }
      endTable(); }
    const rawDirective = /^#[^\s#]/.test(raw); const { attrs, segs } = parseBody(raw);
    if (attrs.figure) { if (pendingFig) { attrs.figure.boxes = pendingFig.boxes; attrs.figure.arrows = pendingFig.arrows; attrs.figure.lanes = pendingFig.lanes; attrs.figure.lines = pendingFig.lines || []; attrs.figure.texts = pendingFig.texts || []; if (pendingFig.tag) attrs.figure.tag = pendingFig.tag; if (pendingFig.dir) attrs.figure.dir = pendingFig.dir; if (FZ.normalizeFigure) attrs.figure = FZ.normalizeFigure(attrs.figure); } } pendingFig = null;
    if (attrs._deco) { const nm = attrs._deco.find(d => DECO_SPECS[d]); if (nm) attrs.deco = nm; const other = attrs._deco.filter(d => !DECO_SPECS[d]); if (other.length) attrs.unk = [...(attrs.unk || []), ...other.map(d => '飾り:' + d)]; delete attrs._deco; } // 飾りは行の属性（K-3）。知らない飾りの名前は持ち回る
    if (rawDirective) attrs.raw = true; // 知らない指示行（後の版の # 行）：本文として見せ、書き戻すときはそのまま
    /* 題の太字は組版が付ける（K-1）。原本の <太字> は利用者が付けた分だけ */
    doc.lines.push({ segs, attrs });
  }
  endTable();
  const idx = doc.lines.length;
  for (const p of pending) if (p.rule && p.rule.axis === 'h') doc.rules.push({ id: FZ.uid(), kind: p.rule.kind, axis: 'h', line: idx, from: p.rule.from, to: p.rule.to, ...(p.rule.dir ? { dir: p.rule.dir } : {}) });
  if (!doc.lines.length) doc.lines.push(newLine());
  // 名前で書かれた罫・網を展開
  for (const t of tablesDone) { if (t.preset !== 'custom' && FZ.applyTablePure) { FZ.applyTablePure(doc, t.a, t.b, t.bounds, t.preset, t.headFill, t.sideFill); } else if (t.preset !== 'custom') { for (const c of t.bounds) doc.rules.push({ id: FZ.uid(), axis: 'v', col: c, from: t.a, to: t.b, kind: 'thin' }); for (let r = t.a; r <= t.b + 1; r++) doc.rules.push({ id: FZ.uid(), axis: 'h', line: r, from: t.bounds[0], to: t.bounds[t.bounds.length - 1], kind: 'thin' }); }
    // 行ごとの列境界の違い（結合セル）：その行だけの縦罫を足す／余分な縦罫を透明にはできないので、行の境界の縦罫を追加する
    for (let r = t.a; r <= t.b; r++) { const ln = doc.lines[r]; for (const sg of ln.segs) if (!doc.rules.some(x => x.axis === 'v' && x.col === sg.col && x.from <= r && x.to >= r)) doc.rules.push({ id: FZ.uid(), axis: 'v', col: sg.col, from: r, to: r, kind: 'thin' }); } }
  for (const a of articles) if (FZ.applyArticlePure) FZ.applyArticlePure(doc, a.start, a.start + a.n - 1, a.titled, a.L, a.R);
  fitItems(doc, false);
  if (parkSrc.length) { const head = src.slice(0, Math.max(0, src.indexOf('\n---\n'))) || '#fzk 2'; doc.parked = parkSrc.map(p => { const sub = parse(head + '\n---\n' + p.body + '\n'); const ids = sub.refs ? sub.refs.ids : []; for (const ln of sub.lines) for (const sg of ln.segs) if (REF_RE.test(sg.text)) sg.text = sg.text.replace(REF_RE_G, ch => { const id = ids[ch.codePointAt(0) - REF_BASE]; return id != null ? FZ.refChar(doc, id) : ch; }); return { id: p.id, label: p.label, lines: sub.lines }; }); } /* 参照の字は親の文書の表に付け替える */
  return normalize(doc);
}
FZ.parse = parse;
FZ.splitRow = splitRow; FZ.parseInlineText = parseInlineText; FZ.segToText = segToText;
/* リンク範囲の保守：text の [from, to) を長さ ins に置き換えたとき */
FZ.spliceLinks = function (seg, from, to, ins) {
  if (!seg.links) return; const d = ins - (to - from); const out = [];
  for (const l of seg.links) { if (l.end <= from) { out.push(l); continue; } if (l.start >= to) { out.push({ ...l, start: l.start + d, end: l.end + d }); continue; }
    // 重なる：削除範囲を除いた残りを縮める（範囲の内側への挿入はリンクに含める）
    const start = Math.min(l.start, from), end = Math.max(from + ins, l.end + d); const keep = { ...l, start, end: Math.max(start, end) }; if (from > l.start && to < l.end) keep.end = l.end + d; else if (from <= l.start && to >= l.end) { continue; } else if (from <= l.start) { keep.start = from + ins; keep.end = l.end + d; } else { keep.start = l.start; keep.end = from; }
    if (keep.end > keep.start) out.push(keep); }
  if (out.length) seg.links = out; else delete seg.links;
};
/* LINK 印とリンク範囲の同期（範囲外の印を消し、範囲内に印を付ける） */
FZ.syncLinks = function (seg) { for (let q = 0; q < seg.marks.length; q++) seg.marks[q] &= ~M.LINK; if (!seg.links) return; seg.links = seg.links.filter(l => l.end > l.start && l.start < seg.text.length).map(l => ({ ...l, end: Math.min(l.end, seg.text.length) })); for (const l of seg.links) for (let q = l.start; q < l.end; q++) seg.marks[q] |= M.LINK; if (!seg.links.length) delete seg.links; };
FZ.linkAt = (seg, off) => seg.links ? seg.links.find(l => l.start <= off && off < l.end) || null : null;
function fromPlain(text) { const doc = newDoc(); doc.lines = String(text).replace(/\r\n?/g, '\n').split('\n').map(t => newLine(t.replace(/\t/g, '　'))); if (!doc.lines.length) doc.lines.push(newLine()); return doc; }
FZ.fromPlain = fromPlain;
function toPlain(doc) { doc = FZ.forExport(doc, { flow: true, images: false, chartRows: true }); return doc.lines.map(ln => ln.segs.map(s => s.text).join('\t')).join('\n') + '\n'; }
/* 書き出し用の写し：図番の字を「図 1」の文字に開き、図版を「番号と題」の行（＋画像のリンクの行）として本文の流れに置く。
   flow：資料書式を文書の流れにする（1.0.10a。資料の版面のままの書き出しは 1.0.10b）。表の中の行の図版は表の後に置く */
FZ.forExport = function (doc, opts = {}) {
  const N = doc.lines.length; let anyRef = false, anyFig = false; for (const ln of doc.lines) { if (ln.attrs.figs) anyFig = true; if (!anyRef) for (const s of ln.segs) if (REF_RE.test(s.text)) { anyRef = true; break; } }
  const toFlow = opts.flow && doc.format.kind === 'slide'; if (!anyRef && !anyFig && !toFlow) return doc;
  const nums = doc._nums || FZ.figureNumbers(doc); /* _nums：文書の一部を書き出す時の、文書全体の番号 */ const out = { ...doc, format: { ...doc.format, ...(toFlow ? { kind: 'doc', fromSlide: true } : {}) }, lines: [], rules: doc.rules.map(r => ({ ...r })), fills: doc.fills.map(x => ({ ...x })) };
  const at = new Array(N + 1); let pend = [];
  const flush = () => { for (const fg of pend) { const n = nums.get(fg.id); const cap = (n ? n.label : fg.kind) + (fg.title ? '　' + fg.title : ''); out.lines.push({ segs: [newSeg(0, cap, M.BOLD)], attrs: { ...((fg.file || fg.chart) && opts.images !== false ? { keep: 'next' } : {}), figCap: { id: fg.id, kind: fg.kind, ...figSize(fg) } } });
    if (fg.file && opts.images !== false) { const sg = newSeg(0, cap, M.LINK); sg.links = [{ start: 0, end: cap.length, url: fg.file, image: true, ...figSize(fg) }]; out.lines.push({ segs: [sg], attrs: {} }); }
    if (fg.chart) { if (opts.images !== false) { const sg = newSeg(0, cap, M.LINK); sg.links = [{ start: 0, end: cap.length, url: '#グラフ', image: true, chart: fg.chart, ...figSize(fg) }]; out.lines.push({ segs: [sg], attrs: { chartOut: fg.chart } }); } /* グラフ：Word・PowerPoint は編集できるグラフ、Markdown は注記＋表 */
      else if (opts.chartRows) for (const r of FZ.chartToGrid(fg.chart)) out.lines.push({ segs: [newSeg(0, r.join('\t'))], attrs: {} }); } } pend = []; };
  for (let i = 0; i < N; i++) { const ln = doc.lines[i]; if (pend.length && !inTable(doc, i)) flush(); at[i] = out.lines.length;
    const segs = ln.segs.some(s => REF_RE.test(s.text)) ? ln.segs.map(s => FZ.expandRefs(doc, s, nums, !!opts.refLinks)) : ln.segs; const attrs = { ...ln.attrs }; delete attrs.figs; out.lines.push({ ...ln, segs, attrs });
    if (ln.attrs.figs) pend.push(...ln.attrs.figs); }
  flush(); at[N] = out.lines.length;
  for (const r of out.rules) { if (r.axis === 'h') r.line = at[clamp(r.line, 0, N)]; else { r.from = at[clamp(r.from, 0, N - 1)]; r.to = at[clamp(r.to, 0, N - 1)]; } }
  for (const x of out.fills) { x.from = at[clamp(x.from, 0, N - 1)]; x.to = at[clamp(x.to, 0, N - 1)]; }
  return out;
};
FZ.toPlain = toPlain;

/* ---------- Markdown 往復 ---------- */
function textWidthPlain(t) { return textWidth(String(t).replace(/\*\*|__|~~|`/g, '')); }
/* タブ区切り（Excel のコピー）→ Markdown 表 */
/* TSV（Excel・スプレッドシートのセルのコピー）を行×セルに。引用符で囲んだセル（タブ・改行・"" を含む）を正しく読む。末尾の空行は捨てる */
FZ.parseTSV = function (text) { const s = String(text).replace(/\r\n?/g, '\n'); const rows = []; let row = [], cell = '', q = false, start = true;
  for (let i = 0; i < s.length; i++) { const c = s[i];
    if (q) { if (c === '"') { if (s[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; continue; }
    if (c === '"' && start) { q = true; start = false; continue; }
    if (c === '\t') { row.push(cell); cell = ''; start = true; continue; }
    if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; start = true; continue; }
    cell += c; start = false; }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  while (rows.length && rows[rows.length - 1].every(c => !c.trim())) rows.pop(); return rows; };
/* TSV → Markdown の表。1 行目を見出し行に。数値だけの列は右揃え（表の区切り行の ---:）。セルの中の改行は空白に */
FZ.tsvToMarkdown = function (text) { const cells = FZ.parseTSV(text).map(r => r.map(c => c.replace(/\s*\n\s*/g, ' ').trim().replace(/\|/g, '｜'))); if (!cells.length) return ''; const n = Math.max(...cells.map(r => r.length));
  const num = c => /^[-+−▲△]?[¥￥$€]?\s*\d[\d,，]*(\.\d+)?\s*(%|％|円|千円|百万円|億円|件|人|個|台)?$/.test(c);
  const right = Array.from({ length: n }, (_, k) => { const vs = cells.slice(1).map(r => r[k] || '').filter(Boolean); return vs.length > 0 && vs.every(num); });
  const line = r => '| ' + Array.from({ length: n }, (_, i) => r[i] || '').join(' | ') + ' |';
  return [line(cells[0]), '|' + right.map(x => x ? ' ---: ' : ' --- ').join('|') + '|', ...cells.slice(1).map(line)].join('\n') + '\n'; };
FZ.looksLikeTSV = s => { const ls = String(s).replace(/\r/g, '').split('\n').filter(l => l.length); return ls.length >= 2 && ls.every(l => l.includes('\t')); };
/* Markdown の読み書きは fz-gfm.js（FZ.fromGfm / FZ.toGfm）。旧名 FZ.fromMarkdown / FZ.toMarkdown も同じもの */
/* 貼り付けた文字列を Markdown とみなすか。誤爆（メール本文の「- 」1 行で全体が整形される）を避けるため、強い兆候だけで判定する：
   見出し（# ＋空白）・囲い（```）・表の区切り行（|---|）があれば Markdown。項目行は 2 行以上あり、かつ行の半数以上か空行で区切られているとき。引用行 2 行以上。
   インラインだけ（**太字** [リンク](url)）では整形しない（Ctrl+Alt+V で明示的に整形できる） */
FZ.markdownSignals = s => {
  const ls = String(s).replace(/\r/g, '').replace(/^\n+|\n+$/g, '').split('\n'); const ne = ls.filter(l => l.trim()).length; const n = { head: 0, fence: 0, table: 0, quote: 0, list: 0, inline: 0, blank: ls.some(l => !l.trim()), lines: ne };
  for (const l of ls) {
    if (/^#{1,6}[ \t]+\S/.test(l)) n.head++; else if (/^ {0,3}(```|~~~)/.test(l)) n.fence++; else if (/^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(l)) n.table++;
    else if (/^ {0,3}>\s?\S/.test(l)) n.quote++; else if (/^\s*(?:[-*+]|\d{1,9}[.)])[ \t]+\S/.test(l)) n.list++;
    if (/\*\*[^*\n]+\*\*|\[[^\]\n]+\]\((?:https?:|mailto:|#|\.)[^)\n]*\)|`[^`\n]+`|~~[^~\n]+~~/.test(l)) n.inline++;
  }
  return n;
};
FZ.looksLikeMarkdown = s => { const n = FZ.markdownSignals(s); if (n.lines < 2) return false; if (n.head || n.fence || n.table) return true; if (n.list >= 2 && (n.list * 2 >= n.lines || n.blank)) return true; if (n.quote >= 2) return true; return false; };

/* ---------- ローマ字 → かな（Rupo の「シフトミス訂正」：英字のまま打ってしまった和文を直す。IME と同じ綴り。漢字は IME の再変換に任せる） ---------- */
const ROMA = (() => { const t = { a: 'あ', i: 'い', u: 'う', e: 'え', o: 'お', '-': 'ー', ',': '、', '.': '。', nn: 'ん', "n'": 'ん', xn: 'ん', wo: 'を', wi: 'うぃ', we: 'うぇ', wu: 'う', wa: 'わ', yi: 'い', ye: 'いぇ',
    shi: 'し', chi: 'ち', tsu: 'つ', fu: 'ふ', ji: 'じ', ja: 'じゃ', ju: 'じゅ', je: 'じぇ', jo: 'じょ', jya: 'じゃ', jyu: 'じゅ', jyo: 'じょ', sha: 'しゃ', shu: 'しゅ', she: 'しぇ', sho: 'しょ', cha: 'ちゃ', chu: 'ちゅ', che: 'ちぇ', cho: 'ちょ',
    tsa: 'つぁ', tsi: 'つぃ', tse: 'つぇ', tso: 'つぉ', thi: 'てぃ', thu: 'てゅ', dhi: 'でぃ', dhu: 'でゅ', twu: 'とぅ', dwu: 'どぅ', fa: 'ふぁ', fi: 'ふぃ', fe: 'ふぇ', fo: 'ふぉ', fyu: 'ふゅ', va: 'ゔぁ', vi: 'ゔぃ', vu: 'ゔ', ve: 'ゔぇ', vo: 'ゔぉ',
    xa: 'ぁ', xi: 'ぃ', xu: 'ぅ', xe: 'ぇ', xo: 'ぉ', la: 'ぁ', li: 'ぃ', lu: 'ぅ', le: 'ぇ', lo: 'ぉ', xya: 'ゃ', xyu: 'ゅ', xyo: 'ょ', lya: 'ゃ', lyu: 'ゅ', lyo: 'ょ', xtu: 'っ', ltu: 'っ', xtsu: 'っ', ltsu: 'っ', xwa: 'ゎ', lwa: 'ゎ', xka: 'ヵ', xke: 'ヶ' };
  const rows = { k: 'かきくけこ', s: 'さしすせそ', t: 'たちつてと', n: 'なにぬねの', h: 'はひふへほ', m: 'まみむめも', y: 'や\u0000ゆ\u0000よ', r: 'らりるれろ', g: 'がぎぐげご', z: 'ざじずぜぞ', d: 'だぢづでど', b: 'ばびぶべぼ', p: 'ぱぴぷぺぽ', c: 'かしくせこ', q: 'くぁくぃくくぇくぉ', l: '' };
  const V = 'aiueo'; for (const [c, k] of Object.entries(rows)) { if (c === 'q' || c === 'l') continue; for (let j = 0; j < 5; j++) if (k[j] && k[j] !== '\u0000' && !t[c + V[j]]) t[c + V[j]] = k[j]; }
  Object.assign(t, { qa: 'くぁ', qi: 'くぃ', qu: 'く', qe: 'くぇ', qo: 'くぉ' });
  const yo = { ky: 'き', gy: 'ぎ', sy: 'し', zy: 'じ', ty: 'ち', cy: 'ち', dy: 'ぢ', ny: 'に', hy: 'ひ', by: 'び', py: 'ぴ', my: 'み', ry: 'り', jy: 'じ' }; const small = { a: 'ゃ', i: 'ぃ', u: 'ゅ', e: 'ぇ', o: 'ょ' };
  for (const [c, k] of Object.entries(yo)) for (const v of V) if (!t[c + v]) t[c + v] = k + small[v];
  return t; })();
FZ.romajiToKana = function (src) {
  const s = String(src); let out = '', i = 0;
  while (i < s.length) { const lo = s.slice(i).toLowerCase(); let hit = null;
    for (let n = 4; n >= 1 && !hit; n--) { const k = lo.slice(0, n); if (k.length === n && ROMA[k]) hit = [k, ROMA[k]]; }
    const c0 = lo[0], c1 = lo[1];
    if (c0 === 'n' && !hit) { out += 'ん'; i++; continue; } // n の後が母音・y でなければ ん（末尾の n も）
    if (c0 === 'n' && hit && hit[0] === 'n') { out += 'ん'; i++; continue; }
    if (c0 && c0 === c1 && /[bcdfghjklmpqrstvwxyz]/.test(c0) && c0 !== 'n') { out += 'っ'; i++; continue; } // 子音の重ね（kk・tt…）は っ
    if (c0 === 't' && c1 === 'c' && lo[2] === 'h') { out += 'っ'; i++; continue; } // tch → っち
    if (c0 === 'm' && (c1 === 'b' || c1 === 'p')) { out += 'ん'; i++; continue; } // ヘボン式の m（shimbun → しんぶん）
    if (hit) { out += hit[1]; i += hit[0].length; continue; }
    out += s[i]; i++; }
  return out;
};
/* ---------- 見本（原本形式 fzk 2） ---------- */
FZ.sampleText = () => [
  "#fzk 2",
  "題名: 文机の見本",
  "用紙: A4 縦",
  "文字数: 40",
  "行数: 36",
  "余白: 20 20 20 20",
  "柱上: 文机　／　見本",
  "柱下: {page} / {pages}",
  "柱行: 1 1",
  "書体: 明朝",
  "番号体系: 1. （1） ① ア （ア） a） ⅰ） A.",
  "題: 1",
  "記号見出し: ■ ◆ ● ○ ▲ △ ◇ □",
  "箇条書き: ・ ‐ ◦ ▪ ▫ ‣ ⁃ ∙",
  "---",
  "[表題 中央]文机の見本",
  "",
  "文机は、文字数×行数の版面に文章を流し込む日本語ワープロです。段落の途中に文を足せば、後ろの文章は押し下がります。行末の禁則も、句読点のぶら下げも自動です。",
  "",
  "[番号1]文字の修飾",
  "本文は明朝、強調は<太字>ゴシック太字</太字>。<下線>下線</下線>、<傍点>傍点</傍点>、<網掛け>網掛け</網掛け>、<白抜き>白抜き</白抜き>、<取消>取消線</取消>、<横倍角>横倍角</横倍角>、<縦倍角>縦倍角</縦倍角>が使えます。半角のabc123は1マスに2文字。",
  "",
  "[番号1]数字見出し・記号見出し・箇条書き",
  "見出しと箇条書きは三つの体系で決まります（F9 書式の「体系」）。数字見出しはレベル別の番号、記号見出しはレベル別の記号、箇条書きはレベル別の記号。Tab で深く、Shift+Tab で浅く。",
  "[番号2]数字見出しの二段目は括弧番号。題のレベル数より深い数字見出しは、番号で分けた本文（段落）として普通の太さで組みます。",
  "[記号1]記号見出し",
  "[項目1]箇条書きは見出しの本文開始位置に揃う",
  "[項目2]入れ子は親の本文開始位置に揃う",
  "[→2]議論の結論や展開は矢印で示す",
  "[❏2]アクションは四角で示す",
  "[番号2]同じ親のもとで数えます",
  "[番号1]体系は「標準」「報告書」「公用文」「契約書」「技術文書」「論文」のプリセットから選べ、自分の体系も保存できます。",
  "",
  "[番号1]表を作る",
  "#表 列 0,10,26,40 様式 格子 見出し淡",
  "| <太字>操作</太字> | <太字>キー</太字> | <太字>備考</太字> |",
  "| 文字の修飾 | F5 文字 | 選んだ範囲か、この後に打つ字に効く |",
  "| 表 | F8 表 | 表を作る・行と列を足す。セルの中で文章が長くなると、表の行が伸びる。 |",
  "| 保存 | Ctrl+S | 原本は読めるテキスト |",
  "",
  "[番号1]揃えと発言録",
  "[中央]中央揃えの行",
  "[右]右揃えの行",
  "[均等]均等割付の行",
  "",
  "[発言6]議長：発言録のスタイルでは、発言者名の後ろで本文の開始位置が揃い、折り返しも同じ位置に揃います。",
  "[発言6]山田：短い発言。",
  "[発言6]佐藤：長めの発言は、このように二行目以降が発言内容の開始位置に揃って読みやすくなります。",
  "",
  "[番号1]図（フローチャート）",
  "箱を並べて矢印でつなぐ。図の上で Enter を押すと編集（N 箱を足す、C 矢印でつなぐ、Tab 選ぶ、矢印キーで動かす、L レーン、Esc で戻る）。",
  "#レーン 縦 0,0,0 申請者|総務|部長",
  "#箱 1 2,2 9x3 細 無 申請書を書く",
  "#箱 2 15,2 10x3 細 薄 内容を確認",
  "#箱 3 28,2 9x3 太 濃太字 決裁",
  "#箱 4 2,7 9x3 細 無 修正して再提出",
  "#矢印 1→2 細",
  "#矢印 2→3 細 OK",
  "#矢印 2→4 点線 不備",
  "#矢印 4→1 細",
  "[図11]",
  "",
  "[番号1 改頁]改ページと柱",
  "この行は新しいページから始まります。ヘッダ・フッタも同じグリッドに乗り、{page} と {pages} でページ番号を出せます。"
].join('\n') + '\n';

})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
