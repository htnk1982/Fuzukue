/* 文机 — 資料（スライドの書式）を Word に「紙面のまま」書き出す（1.0.12f）
 * PowerPoint への書き出し（FZ.toPptx）が作るスライドの図形を、そのまま Word のページに置き直す：
 *   1 頁＝1 段落に、ページ基準で位置を決めた図形（wp:anchor）を並べる。字の箱 → テキストボックス（wps:wsp＋w:txbxContent）、
 *   線 → 線の図形、画像 → 図、グラフ → Word の編集できるグラフ（同じ chart と埋め込みの Excel）、表 → テキストボックスの中の Word の表、
 *   図形の組（Excel に無い形のグラフ）→ 図形のグループ（wpg）。頁番号は PAGE の欄。
 * DrawingML の図形の書き方（位置・枠・塗り・線）は PowerPoint と Word で共通なので写すだけ。字（a:p）は Word の段落（w:p）に訳す。 */
(function (FZ) {
  'use strict';
  /* ---------- 小さな XML の読み書き（書き出しが作る整った XML だけを読む） ---------- */
  function parseXml(s) { const root = { n: '#root', a: {}, c: [] }; const st = [root]; const re = /<\?[^>]*\?>|<!--[\s\S]*?-->|<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*"[^"]*")*)\s*(\/?)>|([^<]+)/g; let m;
    while ((m = re.exec(s))) { if (m[5] != null) { const top = st[st.length - 1]; top.c.push({ t: m[5] }); continue; } if (!m[2]) continue;
      if (m[1]) { st.pop(); continue; } const a = {}; m[3].replace(/([\w:.-]+)\s*=\s*"([^"]*)"/g, (_, k, v) => { a[k] = v; return ''; }); const el = { n: m[2], a, c: [] }; st[st.length - 1].c.push(el); if (!m[4]) st.push(el); }
    return root; }
  const kid = (el, n) => el && el.c.find(x => x.n === n); const kids = (el, n) => el ? el.c.filter(x => x.n === n) : [];
  const deep = (el, n) => { if (!el || !el.c) return null; for (const x of el.c) { if (x.n === n) return x; const r = deep(x, n); if (r) return r; } return null; };
  const ser = el => el.t != null ? el.t : '<' + el.n + Object.entries(el.a).map(([k, v]) => ` ${k}="${v}"`).join('') + (el.c.length ? '>' + el.c.map(ser).join('') + '</' + el.n + '>' : '/>');
  const textOf = el => el.t != null ? el.t : (el.c || []).map(textOf).join('');
  const num = (v, d = 0) => v == null || v === '' ? d : +v;
  const TW = emu => Math.round(emu / 635); /* EMU → twip */
  const NS = 'xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" mc:Ignorable="w14 wp14"';

  /* ---------- 字：a:p → w:p ---------- */
  const JC = { l: 'left', ctr: 'center', r: 'right', just: 'both', dist: 'distribute' };
  const UL = { sng: 'single', dbl: 'double', wavy: 'wave', dotted: 'dotted', heavy: 'thick' };
  function rPrW(rp, scale, fallbackSz) { if (!rp) rp = { a: {}, c: [] }; const out = []; const a = rp.a; const lat = kid(rp, 'a:latin'), ea = kid(rp, 'a:ea');
    if (lat || ea) { const L = lat ? lat.a.typeface : (ea && ea.a.typeface), E = ea ? ea.a.typeface : L; out.push(`<w:rFonts w:ascii="${L}" w:hAnsi="${L}" w:eastAsia="${E}" w:cs="${L}"/>`); }
    if (a.b === '1') out.push('<w:b/><w:bCs/>'); if (a.i === '1') out.push('<w:i/><w:iCs/>');
    if (a.strike === 'sngStrike') out.push('<w:strike/>'); else if (a.strike === 'dblStrike') out.push('<w:dstrike/>');
    if (kid(rp, 'a:ln') && deep(kid(rp, 'a:ln'), 'a:solidFill')) out.push('<w:outline/>'); if (deep(rp, 'a:outerShdw')) out.push('<w:shadow/>');
    out.push('<w:snapToGrid w:val="0"/>');
    const sf = kid(rp, 'a:solidFill'); const col = sf && deep(sf, 'a:srgbClr'); if (col) out.push(`<w:color w:val="${col.a.val}"/>`);
    if (a.spc) out.push(`<w:spacing w:val="${Math.round(num(a.spc) / 5)}"/>`);
    const sz = Math.max(2, Math.round(num(a.sz, fallbackSz || 1050) * (scale || 1) / 50)); out.push(`<w:kern w:val="0"/><w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/>`);
    if (a.u && a.u !== 'none') out.push(`<w:u w:val="${UL[a.u] || 'single'}"/>`);
    const hl = kid(rp, 'a:highlight'); const hc = hl && deep(hl, 'a:srgbClr'); if (hc) out.push(`<w:shd w:val="clear" w:color="auto" w:fill="${hc.a.val}"/>`);
    if (a.baseline && +a.baseline !== 0) out.push(`<w:vertAlign w:val="${+a.baseline > 0 ? 'superscript' : 'subscript'}"/>`);
    return `<w:rPr>${out.join('')}</w:rPr>`; }
  function runW(r, scale) { const rp = kid(r, 'a:rPr'); const t = kid(r, 'a:t'); const s = t ? textOf(t) : ''; const pr = rPrW(rp, scale);
    return s.split('\t').map((x, k) => (k ? `<w:r>${pr}<w:tab/></w:r>` : '') + (x ? `<w:r>${pr}<w:t xml:space="preserve">${x}</w:t></w:r>` : '')).join(''); }
  function paraW(p, scale, o = {}) { const pp = kid(p, 'a:pPr') || { a: {}, c: [] }; const a = pp.a; const pr = ['<w:snapToGrid w:val="0"/>'];
    const ls = kid(pp, 'a:lnSpc'), sb = kid(pp, 'a:spcBef'), sa = kid(pp, 'a:spcAft'); const sp = [];
    const pts = el => { const x = el && kid(el, 'a:spcPts'); return x ? Math.round(num(x.a.val) / 5) : null; };
    if (ls) { const x = kid(ls, 'a:spcPts'), y = kid(ls, 'a:spcPct'); if (x) sp.push(`w:line="${Math.max(20, Math.round(num(x.a.val) / 5 * (scale || 1)))}" w:lineRule="exact"`); else if (y) sp.push(`w:line="${Math.round(240 * num(y.a.val) / 100000)}" w:lineRule="auto"`); } else sp.push('w:line="240" w:lineRule="auto"');
    sp.push(`w:before="${pts(sb) || 0}"`, `w:after="${pts(sa) || 0}"`); pr.push(`<w:spacing ${sp.join(' ')}/>`);
    const marL = num(a.marL), ind = num(a.indent); if (marL || ind) pr.push(`<w:ind w:left="${TW(marL)}"${ind < 0 ? ` w:hanging="${TW(-ind)}"` : ind > 0 ? ` w:firstLine="${TW(ind)}"` : ''}/>`);
    const jc = JC[a.algn || o.algn]; if (jc && jc !== 'left') pr.push(`<w:jc w:val="${jc}"/>`);
    const end = kid(p, 'a:endParaRPr'); if (end) pr.push(rPrW(end, scale));
    const body = []; for (const x of p.c) { if (x.n === 'a:r') body.push(runW(x, scale)); else if (x.n === 'a:br') body.push('<w:r><w:br/></w:r>');
      else if (x.n === 'a:fld') { const rp = kid(x, 'a:rPr'); body.push(x.a.type === 'slidenum' ? `<w:fldSimple w:instr=" PAGE "><w:r>${rPrW(rp, scale)}<w:t>${textOf(kid(x, 'a:t') || { t: '1' })}</w:t></w:r></w:fldSimple>` : `<w:r>${rPrW(rp, scale)}<w:t xml:space="preserve">${textOf(kid(x, 'a:t') || { t: '' })}</w:t></w:r>`); } }
    return `<w:p><w:pPr>${pr.join('')}</w:pPr>${body.join('')}</w:p>`; }
  const parasW = (txBody, scale, o) => { const ps = kids(txBody, 'a:p'); return ps.length ? ps.map(p => paraW(p, scale, o)).join('') : '<w:p/>'; };
  const fontScale = bodyPr => { const nf = bodyPr && kid(bodyPr, 'a:normAutofit'); return nf && nf.a.fontScale ? num(nf.a.fontScale) / 100000 : 1; };

  /* ---------- 表：a:tbl → w:tbl ---------- */
  const PATT = { pct5: 'pct5', pct10: 'pct10', pct20: 'pct20', pct25: 'pct25', pct30: 'pct30', pct40: 'pct40', pct50: 'pct50', ltUpDiag: 'thinDiagStripe', ltDnDiag: 'thinReverseDiagStripe', ltHorz: 'thinHorzStripe', ltVert: 'thinVertStripe', smGrid: 'thinHorzCross', openDmnd: 'thinDiagCross', dotDmnd: 'pct10', wdUpDiag: 'diagStripe' };
  function bdrW(side, ln) { if (!ln || kid(ln, 'a:noFill')) return `<w:${side} w:val="nil"/>`; const w = num(ln.a.w, 6350); const col = deep(ln, 'a:srgbClr'); const dash = kid(ln, 'a:prstDash');
    const val = ln.a.cmpd === 'dbl' ? 'double' : dash ? 'dashed' : 'single'; return `<w:${side} w:val="${val}" w:sz="${Math.max(2, Math.min(96, Math.round(w / 12700 * 8)))}" w:space="0" w:color="${col ? col.a.val : '000000'}"/>`; }
  function shdW(tcPr) { const sf = kid(tcPr, 'a:solidFill'); if (sf) { const c = deep(sf, 'a:srgbClr'); return c ? `<w:shd w:val="clear" w:color="auto" w:fill="${c.a.val}"/>` : ''; }
    const pf = kid(tcPr, 'a:pattFill'); if (pf) return `<w:shd w:val="${PATT[pf.a.prst] || 'pct10'}" w:color="000000" w:fill="FFFFFF"/>`; return ''; }
  function tableW(tbl) { const grid = kids(kid(tbl, 'a:tblGrid'), 'a:gridCol').map(g => TW(num(g.a.w))); const total = grid.reduce((a, b) => a + b, 0);
    const rows = kids(tbl, 'a:tr').map(tr => { const cells = []; let ci = 0;
      for (const tc of kids(tr, 'a:tc')) { if (tc.a.hMerge === '1') { ci++; continue; } const span = Math.max(1, num(tc.a.gridSpan, 1)); const w = grid.slice(ci, ci + span).reduce((a, b) => a + b, 0); ci += span;
        const pr = kid(tc, 'a:tcPr') || { a: {}, c: [] }; const tp = [`<w:tcW w:w="${w}" w:type="dxa"/>`]; if (span > 1) tp.push(`<w:gridSpan w:val="${span}"/>`); if (num(tc.a.rowSpan, 1) > 1) tp.push('<w:vMerge w:val="restart"/>'); else if (tc.a.vMerge === '1') tp.push('<w:vMerge/>');
        tp.push(`<w:tcBorders>${bdrW('top', kid(pr, 'a:lnT'))}${bdrW('left', kid(pr, 'a:lnL'))}${bdrW('bottom', kid(pr, 'a:lnB'))}${bdrW('right', kid(pr, 'a:lnR'))}</w:tcBorders>`); const sh = shdW(pr); if (sh) tp.push(sh);
        tp.push(`<w:tcMar><w:top w:w="${TW(num(pr.a.marT))}" w:type="dxa"/><w:left w:w="${TW(num(pr.a.marL))}" w:type="dxa"/><w:bottom w:w="${TW(num(pr.a.marB))}" w:type="dxa"/><w:right w:w="${TW(num(pr.a.marR))}" w:type="dxa"/></w:tcMar>`);
        tp.push(`<w:vAlign w:val="${pr.a.anchor === 'ctr' ? 'center' : pr.a.anchor === 'b' ? 'bottom' : 'top'}"/>`);
        const content = tc.a.vMerge === '1' ? '<w:p/>' : parasW(kid(tc, 'a:txBody'), 1); cells.push(`<w:tc><w:tcPr>${tp.join('')}</w:tcPr>${content}</w:tc>`); }
      return `<w:tr><w:trPr><w:cantSplit/><w:trHeight w:val="${TW(num(tr.a.h))}" w:hRule="atLeast"/></w:trPr>${cells.join('')}</w:tr>`; }).join('');
    return `<w:tbl><w:tblPr><w:tblW w:w="${total}" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="0000" w:firstRow="0" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="1" w:noVBand="1"/></w:tblPr><w:tblGrid>${grid.map(g => `<w:gridCol w:w="${g}"/>`).join('')}</w:tblGrid>${rows}</w:tbl><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/></w:pPr></w:p>`; }

  /* ---------- 図形 ---------- */
  function xfrmOf(sp) { const pr = kid(sp, 'p:spPr') || kid(sp, 'p:grpSpPr'); const x = (pr && kid(pr, 'a:xfrm')) || kid(sp, 'p:xfrm'); if (!x) return null; const off = kid(x, 'a:off'), ext = kid(x, 'a:ext');
    return { x: num(off && off.a.x), y: num(off && off.a.y), cx: num(ext && ext.a.cx), cy: num(ext && ext.a.cy), fh: x.a.flipH === '1', fv: x.a.flipV === '1', rot: num(x.a.rot), node: x }; }
  /* spPr の中身（a:xfrm は置き直す） */
  function spPrW(sp, xf, keepOff) { const pr = kid(sp, 'p:spPr'); const rest = pr ? pr.c.filter(x => x.n !== 'a:xfrm').map(ser).join('') : '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>';
    const xa = (xf.fh ? ' flipH="1"' : '') + (xf.fv ? ' flipV="1"' : '') + (xf.rot ? ` rot="${xf.rot}"` : ''); return `<wps:spPr><a:xfrm${xa}><a:off x="${keepOff ? xf.x : 0}" y="${keepOff ? xf.y : 0}"/><a:ext cx="${Math.max(1, xf.cx)}" cy="${Math.max(1, xf.cy)}"/></a:xfrm>${rest}</wps:spPr>`; }
  function wspOf(sp, xf, keepOff) { /* p:sp・p:cxnSp → wps:wsp */
    if (sp.n === 'p:cxnSp') return `<wps:wsp><wps:cNvCnPr/>${spPrW(sp, xf, keepOff)}<wps:bodyPr/></wps:wsp>`;
    const tb = kid(sp, 'p:txBody'); const pr = kid(sp, 'p:spPr'); const filled = pr && (kid(pr, 'a:solidFill') || kid(pr, 'a:pattFill')); const lined = pr && kid(pr, 'a:ln') && !kid(kid(pr, 'a:ln'), 'a:noFill');
    if (!tb || !kids(tb, 'a:p').some(p => p.c.some(x => x.n === 'a:r' || x.n === 'a:fld'))) return `<wps:wsp><wps:cNvSpPr/>${spPrW(sp, xf, keepOff)}<wps:bodyPr/></wps:wsp>`;
    const bp = kid(tb, 'a:bodyPr') || { a: {}, c: [] }; const ba = bp.a; const sc = fontScale(bp); const grow = !filled && !lined && (ba.anchor || 't') === 't'; /* 枠も塗りも無い上寄せの字の箱は、Word で字があふれても切れないよう字に合わせて伸ばす */
    const ins = k => num(ba[k], k === 'lIns' || k === 'rIns' ? 91440 : 45720);
    return `<wps:wsp><wps:cNvSpPr txBox="1"/>${spPrW(sp, xf, keepOff)}<wps:txbx><w:txbxContent>${parasW(tb, sc)}</w:txbxContent></wps:txbx><wps:bodyPr rot="0" vert="horz" wrap="${ba.wrap === 'none' ? 'none' : 'square'}" lIns="${ins('lIns')}" tIns="${ins('tIns')}" rIns="${ins('rIns')}" bIns="${ins('bIns')}" anchor="${ba.anchor || 't'}" anchorCtr="0">${grow ? '<a:spAutoFit/>' : '<a:noAutofit/>'}</wps:bodyPr></wps:wsp>`; }
  function grpOf(g, top) { const xf = xfrmOf(g); const x = xf.node; const chOff = kid(x, 'a:chOff'), chExt = kid(x, 'a:chExt');
    const inner = g.c.map(ch => { const cx = xfrmOf(ch); if (!cx) return ''; if (ch.n === 'p:sp' || ch.n === 'p:cxnSp') return wspOf(ch, cx, true); if (ch.n === 'p:grpSp') return grpOf(ch, false); return ''; }).join('');
    const xa = `<a:xfrm><a:off x="${top ? 0 : xf.x}" y="${top ? 0 : xf.y}"/><a:ext cx="${Math.max(1, xf.cx)}" cy="${Math.max(1, xf.cy)}"/><a:chOff x="${num(chOff && chOff.a.x)}" y="${num(chOff && chOff.a.y)}"/><a:chExt cx="${Math.max(1, num(chExt && chExt.a.cx, xf.cx))}" cy="${Math.max(1, num(chExt && chExt.a.cy, xf.cy))}"/></a:xfrm>`;
    return top ? `<wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr>${xa}</wpg:grpSpPr>${inner}</wpg:wgp>` : `<wpg:grpSp><wpg:cNvGrpSpPr/><wpg:grpSpPr>${xa}</wpg:grpSpPr>${inner}</wpg:grpSp>`; }

  FZ.slideDocx = function (doc, opts = {}) {
    const pfiles = FZ.toPptx(doc, { files: true }); const P = new Map(pfiles.map(f => [f.name, f.data])); const str = d => typeof d === 'string' ? d : new TextDecoder().decode(d);
    const pres = parseXml(str(P.get('ppt/presentation.xml'))); const sz = deep(pres, 'p:sldSz'); const PW = num(sz && sz.a.cx, 10692000), PH = num(sz && sz.a.cy, 7560000);
    const presRels = parseXml(str(P.get('ppt/_rels/presentation.xml.rels'))); const relT = new Map(kids(deep(presRels, 'Relationships') || presRels, 'Relationship').map(r => [r.a.Id, r.a.Target]));
    const order = kids(deep(pres, 'p:sldIdLst'), 'p:sldId').map(s => 'ppt/' + relT.get(s.a['r:id']));
    const files = [], docRels = [], media = new Map(), charts = []; let rid = 10, shapeId = 1, z = 251658240;
    const addRel = (type, target) => { const id = 'rId' + (rid++); docRels.push(`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/${type}" Target="${target}"/>`); return id; };
    const anchor = (xf, graphic, name) => { const id = shapeId++; return `<w:r><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="${z++}" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="page"><wp:posOffset>${Math.round(xf.x)}</wp:posOffset></wp:positionH><wp:positionV relativeFrom="page"><wp:posOffset>${Math.round(xf.y)}</wp:posOffset></wp:positionV><wp:extent cx="${Math.max(1, Math.round(xf.cx))}" cy="${Math.max(1, Math.round(xf.cy))}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/><wp:docPr id="${id}" name="${(name || '図形').replace(/"/g, '')} ${id}"/><wp:cNvGraphicFramePr/>${graphic}</wp:anchor></w:drawing></mc:Choice><mc:Fallback/></mc:AlternateContent></w:r>`; };
    const G = (uri, inner) => `<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="${uri}">${inner}</a:graphicData></a:graphic>`;
    const WPS = 'http://schemas.microsoft.com/office/word/2010/wordprocessingShape', WPG = 'http://schemas.microsoft.com/office/word/2010/wordprocessingGroup';
    const pages = order.map((sl, pi) => { const tree = parseXml(str(P.get(sl))); const sp = deep(tree, 'p:spTree'); const relsX = P.get(sl.replace('slides/', 'slides/_rels/') + '.rels'); const rel = new Map(relsX ? kids(deep(parseXml(str(relsX)), 'Relationships'), 'Relationship').map(r => [r.a.Id, r.a.Target]) : []);
      const runs = [];
      for (const el of sp ? sp.c : []) { const xf = xfrmOf(el); if (!xf) continue; const nm = (deep(el, 'p:cNvPr') || { a: {} }).a.name || '';
        if (el.n === 'p:sp') { /* 字の入った図形が字より低い（工程表の矢羽根など）・折り返さない字の箱：Word は箱からはみ出す字を描かないので、図形と字の箱を分け、字の箱を字の高さまで広げる */
          const tb = kid(el, 'p:txBody'), pr = kid(el, 'p:spPr'); const bp = tb && kid(tb, 'a:bodyPr'); const hasT = tb && kids(tb, 'a:p').some(p => p.c.some(x => x.n === 'a:r' || x.n === 'a:fld'));
          const rp = tb && deep(tb, 'a:rPr'); const fs = (rp && num(rp.a.sz, 0) || 1050) * fontScale(bp) * 127; /* 字の大きさ（EMU） */ const nps = tb ? kids(tb, 'a:p').length : 0;
          const deco = pr && (kid(pr, 'a:solidFill') || kid(pr, 'a:pattFill') || (kid(pr, 'a:ln') && !kid(kid(pr, 'a:ln'), 'a:noFill')));
          if (hasT && nps === 1 && xf.cy < fs * 1.45) { const ty = xf.y + xf.cy / 2 - fs * 0.8; const txf = { ...xf, y: ty, cy: fs * 1.6, fh: false, fv: false, rot: 0 };
            if (deco) { const bare = { ...el, c: el.c.filter(x => x.n !== 'p:txBody') }; runs.push(anchor(xf, G(WPS, wspOf(bare, xf, false)), nm)); }
            const tsp = { n: 'p:sp', a: {}, c: [{ n: 'p:spPr', a: {}, c: [{ n: 'a:prstGeom', a: { prst: 'rect' }, c: [{ n: 'a:avLst', a: {}, c: [] }] }, { n: 'a:noFill', a: {}, c: [] }, { n: 'a:ln', a: {}, c: [{ n: 'a:noFill', a: {}, c: [] }] }] }, { ...tb, c: tb.c.map(x => x.n === 'a:bodyPr' ? { ...x, a: { ...x.a, anchor: 'ctr', tIns: '0', bIns: '0' } } : x) }] };
            runs.push(anchor(txf, G(WPS, wspOf(tsp, txf, false)), nm + '（字）')); continue; }
          if (hasT && bp && bp.a.wrap === 'none' && !deco) { const al = deep(tb, 'a:pPr'); const ctr = al && (al.a.algn === 'ctr' || al.a.algn === 'r'); const wx = { ...xf, cx: xf.cx * 1.3 }; if (ctr) wx.x = xf.x - (al.a.algn === 'r' ? xf.cx * 0.3 : xf.cx * 0.15); runs.push(anchor(wx, G(WPS, wspOf(el, wx, false)), nm)); continue; } /* 折り返さない字：書体の違いで折り返さないよう少し広く */
          runs.push(anchor(xf, G(WPS, wspOf(el, xf, false)), nm)); }
        else if (el.n === 'p:cxnSp') runs.push(anchor(xf, G(WPS, wspOf(el, xf, false)), nm));
        else if (el.n === 'p:grpSp') runs.push(anchor(xf, G(WPG, grpOf(el, true)), nm));
        else if (el.n === 'p:pic') { const bl = deep(el, 'a:blip'); const tg = bl && rel.get(bl.a['r:embed']); if (!tg) continue; const src = 'ppt/' + tg.replace(/^\.\.\//, ''); if (!media.has(src)) { const fn = 'p' + (media.size + 1) + '_' + src.split('/').pop(); media.set(src, { fn, rid: addRel('image', 'media/' + fn) }); }
          runs.push(anchor(xf, G('http://schemas.openxmlformats.org/drawingml/2006/picture', `<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="${nm.replace(/"/g, '')}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${media.get(src).rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${Math.round(xf.cx)}" cy="${Math.round(xf.cy)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>`), nm)); }
        else if (el.n === 'p:graphicFrame') { const ch = deep(el, 'c:chart'); const tbl = deep(el, 'a:tbl');
          if (ch) { const tg = rel.get(ch.a['r:id']); if (!tg) continue; const src = 'ppt/' + tg.replace(/^\.\.\//, ''); const n = charts.length + 1; charts.push({ src, n }); const id = addRel('chart', `charts/chart${n}.xml`);
            runs.push(anchor(xf, G('http://schemas.openxmlformats.org/drawingml/2006/chart', `<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" r:id="${id}"/>`), nm)); }
          else if (tbl) runs.push(anchor({ ...xf, cy: xf.cy }, G(WPS, `<wps:wsp><wps:cNvSpPr txBox="1"/><wps:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${Math.max(1, Math.round(xf.cx))}" cy="${Math.max(1, Math.round(xf.cy))}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr><wps:txbx><w:txbxContent>${tableW(tbl)}</w:txbxContent></wps:txbx><wps:bodyPr rot="0" vert="horz" wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t" anchorCtr="0"><a:spAutoFit/></wps:bodyPr></wps:wsp>`), nm || '表')); } }
      const pPr = `<w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>${pi > 0 ? '<w:pageBreakBefore/>' : ''}<w:rPr><w:sz w:val="2"/></w:rPr></w:pPr>`;
      return `<w:p>${pPr}${runs.join('')}</w:p>`; });
    /* 図版の実体：画像・グラフ（chart＋埋め込みの Excel） */
    for (const [src, m] of media) files.push({ name: 'word/media/' + m.fn, data: P.get(src) });
    const emb = new Set();
    for (const c of charts) { files.push({ name: `word/charts/chart${c.n}.xml`, data: P.get(c.src) }); const rr = P.get(c.src.replace('charts/', 'charts/_rels/') + '.rels');
      if (rr) { const x = str(rr); files.push({ name: `word/charts/_rels/chart${c.n}.xml.rels`, data: x }); for (const m of x.matchAll(/Target="\.\.\/embeddings\/([^"]+)"/g)) emb.add(m[1]); } }
    for (const e of emb) { const d = P.get('ppt/embeddings/' + e); if (d) files.push({ name: 'word/embeddings/' + e, data: d }); }
    /* 用紙：スライドの大きさ（横長なら横向き） */
    const sect = `<w:sectPr><w:pgSz w:w="${TW(PW)}" w:h="${TW(PH)}"${PW > PH ? ' w:orient="landscape"' : ''}/><w:pgMar w:top="0" w:right="0" w:bottom="0" w:left="0" w:header="0" w:footer="0" w:gutter="0"/><w:cols w:space="0"/></w:sectPr>`;
    const docXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${NS}><w:body>${pages.join('')}${sect}</w:body></w:document>`;
    const [bodyFont] = FZ.docFonts(doc.format); const of = FZ.officeFont(bodyFont);
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="${of.latin}" w:hAnsi="${of.latin}" w:eastAsia="${of.ea}" w:cs="${of.latin}"/><w:kern w:val="0"/><w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="en-US" w:eastAsia="ja-JP" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="a"><w:name w:val="Normal"/><w:qFormat/><w:pPr><w:widowControl w:val="0"/><w:snapToGrid w:val="0"/></w:pPr></w:style><w:style w:type="table" w:default="1" w:styleId="a1"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style></w:styles>`;
    const settings = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:zoom w:percent="100"/><w:defaultTabStop w:val="840"/><w:characterSpacingControl w:val="doNotCompress"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>`;
    const title = (doc.format.title || doc.fileName || '資料').replace(/[<&>"]/g, '');
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${title}</dc:title><dc:creator>文机</dc:creator></cp:coreProperties>`;
    const ext = new Set([...media.values()].map(m => m.fn.split('.').pop().toLowerCase())); const CT = { png: 'image/png', jpeg: 'image/jpeg', jpg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp' };
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="xlsx" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/>${[...ext].map(e => `<Default Extension="${e}" ContentType="${CT[e] || 'image/' + e}"/>`).join('')}<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>${charts.map(c => `<Override PartName="/word/charts/chart${c.n}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`).join('')}</Types>`;
    files.unshift({ name: '[Content_Types].xml', data: ct }, { name: '_rels/.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>` },
      { name: 'word/document.xml', data: docXml }, { name: 'word/styles.xml', data: styles }, { name: 'word/settings.xml', data: settings }, { name: 'docProps/core.xml', data: core },
      { name: 'word/_rels/document.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>${docRels.join('')}</Relationships>` });
    return opts.files ? files : FZ.zip(files); };
  FZ.slideDocxParse = parseXml; /* 試験用 */
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
