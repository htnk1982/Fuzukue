/* 文机 — 書き出し共通：文書を「段落／表／図」のブロック列に解析し、組版結果（位置・記号・網）を添える。
 * Word（fz-docx.js）と PowerPoint（fz-pptx.js）が共用する。 */
(function (FZ) {
  'use strict';
  const M = FZ.M;
  /* XML 1.0 が許さない文字（制御文字・孤立サロゲート）は落とす。残すと Word・PowerPoint が「壊れたファイル」と判定する */
  const esc = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  FZ.xmlEsc = esc;
  /* 文書の書体名 [本文, 太字]：本文は明朝かゴシックの選択、太字は常にゴシックの書体 */
  FZ.docFonts = f => { const mi = f.fontMincho || 'BIZ UDMincho', go = f.fontGothic || 'BIZ UDGothic'; return [f.font === 'gothic' ? go : mi, go]; };
  /* Office（Word・PowerPoint）は書体を GDI の正式名で探す。画面（Web）の書体名と違うものを対応させる。
     例：BIZ UD明朝は Windows 内蔵の正式名が「BIZ UDMincho Medium」（日本語名「BIZ UD明朝 Medium」）で、「BIZ UDMincho」では見つからない。
     戻り値 { latin, ea }：欧文名（ascii/hAnsi/latin）と和文名（eastAsia/ea）。どちらも同じ書体の名前 */
  const OFFICE_FONTS = {
    'biz udmincho': ['BIZ UDMincho Medium', 'BIZ UD明朝 Medium'], 'biz udmincho medium': ['BIZ UDMincho Medium', 'BIZ UD明朝 Medium'], 'biz ud明朝': ['BIZ UDMincho Medium', 'BIZ UD明朝 Medium'], 'biz ud明朝 medium': ['BIZ UDMincho Medium', 'BIZ UD明朝 Medium'],
    'biz udpmincho': ['BIZ UDPMincho Medium', 'BIZ UDP明朝 Medium'], 'biz udpmincho medium': ['BIZ UDPMincho Medium', 'BIZ UDP明朝 Medium'], 'biz udp明朝 medium': ['BIZ UDPMincho Medium', 'BIZ UDP明朝 Medium'],
    'biz udgothic': ['BIZ UDGothic', 'BIZ UDゴシック'], 'biz udゴシック': ['BIZ UDGothic', 'BIZ UDゴシック'], 'biz udpgothic': ['BIZ UDPGothic', 'BIZ UDPゴシック'], 'biz udpゴシック': ['BIZ UDPGothic', 'BIZ UDPゴシック'],
    'yu mincho': ['Yu Mincho', '游明朝'], '游明朝': ['Yu Mincho', '游明朝'], 'yu gothic': ['Yu Gothic', '游ゴシック'], '游ゴシック': ['Yu Gothic', '游ゴシック'],
    'ms mincho': ['MS Mincho', 'ＭＳ 明朝'], 'ｍｓ 明朝': ['MS Mincho', 'ＭＳ 明朝'], 'ms gothic': ['MS Gothic', 'ＭＳ ゴシック'], 'ｍｓ ゴシック': ['MS Gothic', 'ＭＳ ゴシック'],
    'ms pmincho': ['MS PMincho', 'ＭＳ Ｐ明朝'], 'ms pgothic': ['MS PGothic', 'ＭＳ Ｐゴシック'], 'meiryo': ['Meiryo', 'メイリオ'], 'メイリオ': ['Meiryo', 'メイリオ'],
    'ud digi kyokasho n-r': ['UD Digi Kyokasho N-R', 'UD デジタル 教科書体 N-R'], 'ud digi kyokasho nk-r': ['UD Digi Kyokasho NK-R', 'UD デジタル 教科書体 NK-R'],
  };
  FZ.officeFont = name => { const n = String(name || '').trim(); const hit = OFFICE_FONTS[n.toLowerCase()]; return hit ? { latin: hit[0], ea: hit[1] } : { latin: n, ea: n }; };
  /* ハイパーリンクの Target 用：URI に許されない文字（空白・和文・" < > 等）だけ % 符号化し、既にある %xx は保たない限り触らない。Word は生の空白を含む Target を拒む */
  FZ.uriForOffice = u => String(u).replace(/%(?![0-9A-Fa-f]{2})/g, '%25').replace(/[^A-Za-z0-9\-._~:\/?#\[\]@!$&'()*+,;=%]/g, c => encodeURIComponent(c));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* 番号書式 → Word / PowerPoint の自動番号。word: numFmt と lvlText（%n は自分の階層）。ppt: a:buAutoNum の type（無ければ本文に焼く） */
  FZ.NUMBER_EXPORT = {
    'Ⅰ': { word: ['upperRoman', '%n　'], ppt: 'romanUcPeriod' }, '1.': { word: ['decimal', '%n.　'], ppt: 'arabicPeriod' }, '1）': { word: ['decimal', '%n）'], ppt: null }, '（1）': { word: ['decimal', '（%n）'], ppt: null },
    '①': { word: ['decimalEnclosedCircle', '%n '], ppt: 'circleNumDbPlain' }, 'A.': { word: ['upperLetter', '%n.　'], ppt: 'alphaUcPeriod' }, 'a）': { word: ['lowerLetter', '%n）'], ppt: null }, 'ⅰ）': { word: ['lowerRoman', '%n）'], ppt: null },
    '1': { word: ['decimal', '%n　'], ppt: 'arabicPlain' }, '(1)': { word: ['decimal', '(%n)'], ppt: 'arabicParenBoth' }, '1)': { word: ['decimal', '%n) '], ppt: 'arabicParenR' }, '1.1': { word: ['decimal', '%n　'], ppt: null, compound: true },
    '第1': { word: ['decimal', '第%n　'], ppt: null }, '第1条': { word: ['decimal', '第%n条　'], ppt: null }, '一': { word: ['japaneseCounting', '%n　'], ppt: null }, 'ア': { word: ['aiueo', '%n　'], ppt: null }, '（ア）': { word: ['aiueo', '（%n）'], ppt: null },
    'a': { word: ['lowerLetter', '%n　'], ppt: 'alphaLcPlain' }, '（a）': { word: ['lowerLetter', '（%n）'], ppt: 'alphaLcParenBoth' },
  };
  /* 記号用のフォント：JIS に無い記号は Segoe UI Symbol */
  FZ.symbolFont = s => /[▪▫❏☑✓◦‣▸]/.test(s) ? 'Segoe UI Symbol' : null;

  /* 文書 → ブロック列。各ブロック：
   *  para  : { type, i, attrs, segs, left, right, firstL, contL, marker:{col,text,w}|null, rows:[{page,y,h}], shade:[Map off→shade], tall, pageFills, rules:{top,bottom,left,right} }
   *  table : { type, a, b, left, right, grid:[cols], rows:[{ i, cells:[{ left, right, span, segs, align, shade, borders:{t,b,l,r}, vm:'restart'|'cont' }], y }] }
   *  figure: { type, i, F, left, right, rows:[{page,y,h}] }
   *  toc   : { type, i, toc:{num,sym}, entries:[{line, indent, marker, text, page}], left, right, rows } */
  FZ.exportModel = function (doc) { return FZ.withRuleIndex(doc, () => exportModelBody(doc)); };
  function exportModelBody(doc) {
    const lay = FZ.layout(doc), f = doc.format, cols = f.cols; const blocks = [];
    const ruleKindAt = (axis, line, from, to, col) => { // h: 行 line の上辺で [from,to) を覆う罫 ／ v: 列 col で行 line を含む罫
      let best = null; // 索引（行ごとの罫。原本の順）から引く：段落・セルごとに罫を全部なめると「行数×罫の数」になる
      if (axis === 'h') { const mid = (from + to) / 2; for (const r of FZ.hRulesAt(doc, line)) if (r.from <= mid && r.to >= mid) best = r; }
      else for (const r of FZ.vRulesAt(doc, line)) if (r.col === col) best = r;
      return best ? (best.kind === 'arrow' ? 'thin' : best.kind) : null;
    };
    const fillAt = (page, col, y) => { const pg = lay.pages[page]; if (!pg) return null; let s = null; for (const x of pg.fills) if (!x.fig && col >= x.col - 1e-6 && col < x.col + x.cols - 1e-6 && y >= x.y1 && y < x.y2) s = x.shade; return s; };
    for (let i = 0; i < doc.lines.length;) {
      const ln = doc.lines[i], a = ln.attrs, lm = lay.lineMap[i];
      if (a.drawing) { blocks.push({ type: 'drawing', i, D: a.drawing, columns: 0 }); i++; continue; } /* 書き出し専用の図形（ツリーの Word など）：描いたままの箱と線 */
      if (a.figure) { const L2 = lm.segs[0].rows[0].left, R2 = lm.segs[0].rows[0].right, P = lm.figParts || [];
        if (P.length > 1) P.forEach((p, k) => blocks.push({ type: 'figure', i, F: FZ.figureSlice(a.figure, R2 - L2, p.f0, p.f1), left: L2, right: R2, rows: [lm.rows[k]], columns: a.columns | 0, part: k })); /* 1.0.14f 頁に分けた図は頁ごとの図（続きの頁は図の続き） */
        else blocks.push({ type: 'figure', i, F: a.figure, left: L2, right: R2, rows: lm.rows, columns: a.columns | 0 }); i++; continue; }
      if (a.toc) { blocks.push({ type: 'toc', i, toc: FZ.tocRange(a.toc, f), entries: lay.tocs[i] || [], left: lm.segs[0].rows[0].left, right: lm.segs[0].rows[0].right, rows: lm.rows }); i++; continue; }
      if (FZ.inTable(doc, i)) {
        let b = i; while (b + 1 < doc.lines.length && FZ.inTable(doc, b + 1)) b++;
        const gridSet = new Set(); for (let k = i; k <= b; k++) for (const r of FZ.vRulesAt(doc, k)) gridSet.add(r.col); const grid = [...gridSet].sort((x, y) => x - y);
        const L = grid[0], R = grid[grid.length - 1];
        const rows = [];
        for (let k = i; k <= b; k++) {
          const lk = doc.lines[k], cellsK = FZ.cellsAt(doc, k).filter(c => c.left >= L && c.right <= R); const lmk = lay.lineMap[k];
          const cells = cellsK.map((c, ci) => {
            const segs = lk.segs.filter(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6); const span = grid.indexOf(c.right) - grid.indexOf(c.left);
            const row0 = lmk.rows[0]; const shade = fillAt(row0.page, c.left + 0.01, row0.y);
            const borders = { t: ruleKindAt('h', k, c.left, c.right), b: ruleKindAt('h', k + 1, c.left, c.right), l: ruleKindAt('v', k, 0, 0, c.left), r: ruleKindAt('v', k, 0, 0, c.right) };
            return { left: c.left, right: c.right, span: Math.max(1, span), segs, align: (lk.attrs.cellAlign && lk.attrs.cellAlign[ci]) || lk.attrs.align || 'left', shade, borders };
          });
          const G = a.gantt; if (G && k - i >= (G.heads || 1) && FZ.ganttRowShapes) { /* 工程表：期間のセルは字の代わりに矢羽根（書き出しでは名前・◆ と網に置き換えられるよう、セルごとに印を付ける） */ const per = cells.slice(G.labels | 0); per.forEach(c => { c.gp = true; c.gtext = ''; c.gshade = null; });
            const sh = FZ.ganttRowShapes(per.map((c, ci) => { const sg = c.segs[0]; return { left: ci, right: ci + 1, text: c.segs.map(x => x.text).join('') }; })); for (const bar of sh.bars) { for (let q = bar.c0; q <= bar.c1; q++) if (per[q]) per[q].gshade = 'gray'; if (per[bar.c0]) per[bar.c0].gtext = bar.label; } for (const m of sh.ms) if (per[m.c]) per[m.c].gtext = '◆' + (m.label ? m.label : ''); }
          if (G && k === i && FZ.ganttBand) { const B = FZ.ganttBand(doc, i, lay.geo.bodyCols); if (B) { /* 工程表の年度の段：帯は横に結合、左の列の見出しは 2 段を縦に結合 */
              for (let q = cells.length - 1; q > 0; q--) { const c = cells[q]; if (!B.cuts.has(c.left)) continue; const pc = cells[q - 1]; pc.right = c.right; pc.span += c.span; pc.borders.r = c.borders.r; pc.align = 'center'; cells.splice(q, 1); }
              if (B.labelsRight != null) for (const c of cells) if (c.right <= B.labelsRight + 1e-6) c.vm = 'restart'; } }
          if (G && k === i + 1 && rows[0] && rows[0].cells.some(c => c.vm === 'restart')) for (const c of cells) if (rows[0].cells.some(t => t.vm === 'restart' && Math.abs(t.left - c.left) < 1e-6 && Math.abs(t.right - c.right) < 1e-6)) c.vm = 'cont';
          rows.push({ i: k, cells, rows: lmk.rows, tall: lk.segs.some(s => s.marks.some(m => FZ.scaleH(m) > 1)) });
        }
        /* 1.0.12a 縦の結合：同じ行の境に横罫のあるセルがあるのに（1.0.12b 行続きの行は罫が無くても）、そのセルだけ上辺の罫が無く、上の行に同じ幅のセルがある → 上のセルに続く（Word の vMerge、PowerPoint の rowSpan）。下の行の字は上のセルの段落として足す */
        if (!a.gantt) for (let r = 1; r < rows.length; r++) { const has = c => c.borders.t && c.borders.t !== 'none'; if (!doc.lines[rows[r].i].attrs.crow && !rows[r].cells.some(has)) continue; /* 行続き（セルの中の改行）の行は、どのセルも上のセルの続き */
          for (const c of rows[r].cells) { if (has(c)) continue; const up = rows[r - 1].cells.find(t => Math.abs(t.left - c.left) < 1e-6 && Math.abs(t.right - c.right) < 1e-6); if (!up) continue; const head = up.vm === 'cont' ? up.head : up; if (!head) continue; if (!up.vm) up.vm = 'restart'; c.vm = 'cont'; c.head = head; if (c.segs.some(x => x.text)) (head.more = head.more || []).push(c.segs); c.segs = []; } }
        if (!a.gantt && FZ.tbl && FZ.tbl.sumFields) FZ.tbl.sumFields(doc, i, b, grid, rows); /* 1.0.15d 合計の行は Word で式に */
        blocks.push({ type: 'table', a: i, b, left: L, right: R, grid, rows, columns: a.columns | 0, keepNext: false, repeatHead: b > i && !a.noRepeat, heads: a.gantt ? Math.min(a.gantt.heads || 1, b - i) : 1 }); i = b + 1; continue; // repeatHead：見出し行をページごとに繰り返す（Word の「タイトル行の繰り返し」）
      }
      // 段落
      const row0 = lm.segs[0].rows[0]; const left = row0.left, right = row0.right; const seg = ln.segs[0];
      const markerGlyphs = row0.glyphs.filter(g => g.marker && !g.tail); let marker = null; // 囲み見出しの閉じ（tail）は印ではない
      if (markerGlyphs.length) { const mc = Math.min(...markerGlyphs.map(g => g.col)); const text = markerGlyphs.map(g => g.text).join(''); marker = { col: mc - left, text, w: markerGlyphs.reduce((t, g) => t + g.w, 0), marks: markerGlyphs[0].marks | 0 }; }
      const indent = clamp(a.indent | 0, 0, right - left - 1); let firstL = indent, contL = a.hanging == null ? firstL : clamp(a.hanging | 0, 0, right - left - 1);
      if (marker) { firstL = contL = marker.col + marker.w; }
      if (a.style === 'speech') { firstL = 0; contL = clamp(a.speakerCols || 6, 1, right - left - 2); }
      /* 組版が足した字下げ（本文の位置：見出しの頭・文字に揃える）を、書き出しの段落の字下げにも載せる。左揃え・均等の行だけ（中央・右は位置が揃えで決まる） */
      if (!marker && a.style !== 'speech' && (!a.align || a.align === 'left' || a.align === 'justify')) { const sh = (row0.startCol - left) - firstL; if (Math.abs(sh) > 1e-6) { firstL += sh; contL += sh; } }
      const shade = new Map(); let dark = false;
      for (const sl of lm.segs) for (const r of sl.rows) for (const g of r.glyphs) { if (g.marker) continue; const s = fillAt(r.page, g.col, r.y); if (s) { shade.set(g.start, s); if (FZ.inkShade(s)) dark = true; } }
      // 行全体の網（段落の網として扱う）：先頭行の左端の網が行幅いっぱいか
      const pg = lay.pages[row0.page]; const lineFill = pg ? pg.fills.find(x => !x.fig && x.col <= left + 1e-6 && x.col + x.cols >= right - 1e-6 && row0.y >= x.y1 && row0.y < x.y2) : null;
      const rules = { top: ruleKindAt('h', i, left, right), bottom: ruleKindAt('h', i + 1, left, right), left: ruleKindAt('v', i, 0, 0, left), right: ruleKindAt('v', i, 0, 0, right) };
      const ds = a.deco ? FZ.decoSpec(a.deco) : null; if (ds) { if (ds.box) { rules.top = rules.bottom = rules.left = rules.right = ds.box; } if (ds.under) rules.bottom = ds.under; } if (a.hr) rules.bottom = 'thin'; // 飾り（K-3）と区切り線（K-6）は名前・種類から罫を引く
      // 上辺の罫が前の段落の下辺なら前の段落に付いたものとみなす（二重描画を避ける）
      if (rules.top && i > 0 && !doc.lines[i - 1].attrs.figure && !FZ.inTable(doc, i - 1) && !(rules.left || rules.right)) rules.top = null;
      if (rules.bottom && i + 1 < doc.lines.length && FZ.inTable(doc, i + 1)) rules.bottom = null;
      const boxed = rules.left && rules.right && !FZ.inTable(doc, i) && (left > 1e-6 || right < (lay.geo.bodyCols || lay.geo.cols) - 1e-6); /* 1.0.12c 位置と幅のある囲み */
      blocks.push({ type: 'para', i, attrs: a, segs: ln.segs, seg, left, right, boxL: boxed ? left : 0, boxR: boxed ? Math.max(0, (lay.geo.bodyCols || lay.geo.cols) - right) : 0, firstL, contL, marker, rows: lm.rows, shade, dark, lineFill: lineFill ? lineFill.shade : null, rules, tall: seg.marks.some(m => m & M.TALL), columns: a.columns | 0 });
      i++;
    }
    // 三体系の情報（Word の自動番号・スタイルに渡す）：節点の種類とレベル、題かどうか
    const gaps = FZ.headingGaps(doc); // 見出しの前の空き（Word は段落前の間隔、PowerPoint は空の段落）
    for (const b of blocks) if (b.type === 'table') b.gap = gaps[b.a] || false; // 表の前空き
    for (const b of blocks) if (b.type === 'para') { const a = b.attrs; b.node = FZ.nodeKind(a); b.gap = gaps[b.i] || false; if (a.list) { b.listIdx = clamp(a.list.level | 0, 0, 7); b.listKind = a.list.kind || 'item'; } if (a.style === 'num') { b.numLevel = clamp(a.level | 0, 0, 7); b.isTitle = b.numLevel < (f.titleLevels | 0); } b.title = FZ.titleLike(a, f); if (b.title && !a.thin) b.seg = { ...b.seg, marks: b.seg.marks.map(m => m | M.BOLD) }; /* 題の太字（組版の見た目）を書き出しの字に載せる（K-1） */ if (a.style === 'sym') { b.symLevel = clamp(a.level | 0, 0, 7); b.symClose = FZ.schemeClose(FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM), b.symLevel); } }
    return { lay, blocks, format: f, cols };
  };

  /* セグメントの文字を、修飾と網の変化ごとの run に分ける → [{ text, marks, shade }] */
  FZ.runsOf = function (seg, shadeMap, extra = {}) {
    const out = []; let cur = null; const t = seg.text, m = seg.marks;
    if (!shadeMap || !shadeMap.size) { const m0 = m[0] | 0; let same = true; for (let q = 1; q < t.length; q++) if ((m[q] | 0) !== m0) { same = false; break; } if (same) return t ? [{ text: t, marks: m0, shade: null, ...extra }] : []; } // 速い道：網も修飾の変化も無いセグメントは 1 つの run
    for (const g of FZ.graphemes(t)) {
      const mk = seg.marks[g.start] | 0, sh = shadeMap ? (shadeMap.get(g.start) || null) : null;
      if (cur && cur.marks === mk && cur.shade === sh) cur.text += g.text; else { cur = { text: g.text, marks: mk, shade: sh, ...extra }; out.push(cur); }
    }
    return out;
  };
  /* 発言録：区切り（：:タブ）の位置 */
  FZ.speechSplit = text => { const m = text.search(/[：:\t]/); return m >= 0 ? m + 1 : -1; };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
