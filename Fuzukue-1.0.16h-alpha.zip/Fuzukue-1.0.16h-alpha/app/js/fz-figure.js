/* 文机 — 図ブロック（フローチャート）
 * 1 論理行が高さ h 行の「図」を占め、その中に文字入りの箱・箱をつなぐ矢印・スイムレーンを置く。
 * 座標は図の左上を原点とするマス目（x: 列、y: 行）。描画は既存の罫線・網・文字の仕組みに乗せる。
 *   attrs.figure = { h, boxes: [{ id, x, y, w, h, text, kind, shade, bold }], arrows: [{ from, to, label, kind }], lanes: { dir: 'v'|'h', items: [{ title, size }] } | null } */
(function (FZ) {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const half = v => Math.round(v * 2) / 2;
  const M = FZ.M;

  function normalizeFigure(F) {
    const f = F && typeof F === 'object' ? F : {};
    const out = { h: clamp(f.h | 0 || 8, 1, 200), boxes: [], arrows: [], lanes: null, lines: [], texts: [] }; if (/^(flow|seq|er|mind)$/.test(f.tag || '')) out.tag = f.tag; if (f.dir === 'LR' || f.dir === 'TD') out.dir = f.dir; /* 1.0.12d 図の種類（Mermaid との往復）と向き */
    const ids = new Set();
    for (const b of Array.isArray(f.boxes) ? f.boxes : []) {
      if (!b) continue; let id = b.id | 0; if (!id || ids.has(id)) { id = 1; while (ids.has(id)) id++; } ids.add(id);
      out.boxes.push({ id, x: Math.max(0, +b.x || 0), y: Math.max(0, b.y | 0), w: clamp(+b.w || 6, 2, 200), h: clamp(b.h | 0 || 3, 1, 200), text: String(b.text ?? ''), kind: ['thin', 'thick', 'double', 'dotted', 'store'].includes(b.kind) ? b.kind : 'thin', shade: b.shade && b.shade !== 'text' && FZ.SHADE_BY && FZ.SHADE_BY[b.shade] ? b.shade : null, bold: !!b.bold });
    }
    for (const a of Array.isArray(f.arrows) ? f.arrows : []) { if (!a || !ids.has(a.from | 0) || !ids.has(a.to | 0) || (a.from | 0) === (a.to | 0)) continue; const ar = { from: a.from | 0, to: a.to | 0, label: String(a.label ?? ''), kind: ['thin', 'thick', 'dotted'].includes(a.kind) ? a.kind : 'thin' }; if (a.head === false) ar.head = false; if (a.via === 'r' || a.via === 'b') { ar.via = a.via; if (a.vp != null && Number.isFinite(+a.vp)) ar.vp = Math.max(0, half(+a.vp)); } if (a.card && /^[|o}{]{2}(--|\.\.)[|o}{]{2}$/.test(a.card)) ar.card = a.card; out.arrows.push(ar); }
    for (const l of Array.isArray(f.lines) ? f.lines : []) { if (!l || !Array.isArray(l.pts) || l.pts.length < 2) continue; const pts = l.pts.map(p => [Math.max(0, half(+p[0] || 0)), Math.max(0, half(+p[1] || 0))]); const ln = { pts, kind: ['thin', 'thick', 'dotted'].includes(l.kind) ? l.kind : 'thin', head: !!l.head, label: String(l.label ?? '') }; if (/^(life|msg|sep)$/.test(l.role || '')) ln.role = l.role; out.lines.push(ln); } /* 1.0.12d 箱につながない線（シーケンス図の生存線・伝達など） */
    for (const t of Array.isArray(f.texts) ? f.texts : []) { if (!t || !String(t.text ?? '').length) continue; out.texts.push({ x: Math.max(0, half(+t.x || 0)), y: Math.max(0, t.y | 0), text: String(t.text), bold: !!t.bold }); }
    if (f.lanes && (f.lanes.dir === 'v' || f.lanes.dir === 'h') && Array.isArray(f.lanes.items) && f.lanes.items.length) out.lanes = { dir: f.lanes.dir, items: f.lanes.items.map(it => ({ title: String((it && it.title) ?? ''), size: Math.max(0, +(it && it.size) || 0) })) };
    return out;
  }
  FZ.normalizeFigure = normalizeFigure;
  const box = (F, id) => F.boxes.find(b => b.id === id);
  FZ.figureBox = box;

  /* レーンの帯：{ dir, titleBand, bands: [{ from, to, title }] }（図の座標系） */
  function laneGeom(F, W, H) {
    const L = F.lanes; if (!L) return null;
    const total = L.dir === 'v' ? W : H; const given = L.items.reduce((t, it) => t + (it.size || 0), 0);
    let sizes = L.items.map(it => it.size || 0);
    if (!given || Math.abs(given - total) > 1e-6) { const n = L.items.length, base = Math.floor(total / n); sizes = L.items.map((_, k) => k === n - 1 ? total - base * (n - 1) : base); }
    const bands = []; let at = 0; L.items.forEach((it, k) => { bands.push({ from: at, to: at + sizes[k], title: it.title }); at += sizes[k]; });
    return { dir: L.dir, titleBand: L.dir === 'v' ? 1 : 2, bands };
  }
  FZ.laneGeom = laneGeom;

  /* 文字列を幅 w マスで貪欲に折り返す（簡易：禁則なし） */
  function wrapText(text, w) {
    const rows = []; let cur = '', cw = 0;
    for (const g of FZ.graphemes(text)) { const gw = FZ.textWidth(g.text); if (g.text === '\n') { rows.push(cur); cur = ''; cw = 0; continue; } if (cw + gw > w + 1e-6 && cur) { rows.push(cur); cur = ''; cw = 0; } cur += g.text; cw += gw; }
    rows.push(cur); return rows;
  }
  function centeredGlyphs(text, left, width, dy, marks, out, line) {
    const tw = FZ.textWidth(text); let col = half(left + (width - tw) / 2);
    for (const g of FZ.graphemes(text)) { const w = FZ.textWidth(g.text); if (!/^[\s　]$/.test(g.text)) out.push({ text: g.text, col, w, marks, dy, fig: true }); col += w; }
  }

  /* 矢印の経路：直交する 1〜3 区間。[{ kind: 'h', y, from, to, dir } | { kind: 'v', col, y1, y2, dir }]（最後の区間に矢じり） */
  function route(A, B, via, vp) { /* vp（1.0.14f）：回り道の位置。右回りは縦の線の列、下回りは横の線の行（間の箱を避ける） */
    const ax1 = A.x, ax2 = A.x + A.w, ay1 = A.y, ay2 = A.y + A.h, acx = half(A.x + A.w / 2), acy = ay1 + A.h / 2;
    const bx1 = B.x, bx2 = B.x + B.w, by1 = B.y, by2 = B.y + B.h, bcx = half(B.x + B.w / 2), bcy = by1 + B.h / 2;
    if (via === 'r') { const xr = vp != null ? vp : half(Math.max(ax2, bx2) + 2); return [{ k: 'h', y: half(acy), from: ax2, to: xr }, { k: 'v', col: xr, y1: Math.min(half(acy), half(bcy)), y2: Math.max(half(acy), half(bcy)) }, { k: 'h', y: half(bcy), from: bx2, to: xr, dir: 'l' }]; } /* 1.0.12d 戻りの矢印：右を回る */
    if (via === 'b') { const yb = vp != null ? vp : Math.max(ay2, by2) + 1; return [{ k: 'v', col: acx, y1: ay2, y2: yb }, { k: 'h', y: yb, from: Math.min(acx, bcx), to: Math.max(acx, bcx) }, { k: 'v', col: bcx, y1: by2, y2: yb, dir: 'u' }]; } /* 下を回る */
    const segs = [];
    // 横の隙間と縦の隙間のうち大きい方の向きに出る（接している箱は縦／横のもう一方で結ぶ）
    const gx = bx1 >= ax2 ? bx1 - ax2 : ax1 >= bx2 ? ax1 - bx2 : -1, gy = by1 >= ay2 ? by1 - ay2 : ay1 >= by2 ? ay1 - by2 : -1;
    const horiz = gx > gy || (gx === gy && gx > 0 && Math.abs(acy - bcy) <= Math.abs(acx - bcx));
    if (horiz && bx1 >= ax2) { // 右へ
      if (Math.abs(acy - bcy) < 1e-6) segs.push({ k: 'h', y: acy, from: ax2, to: bx1, dir: 'r' });
      else { const mx = half((ax2 + bx1) / 2); segs.push({ k: 'h', y: acy, from: ax2, to: mx }, { k: 'v', col: mx, y1: Math.min(acy, bcy), y2: Math.max(acy, bcy) }, { k: 'h', y: bcy, from: mx, to: bx1, dir: 'r' }); }
    } else if (horiz && ax1 >= bx2) { // 左へ
      if (Math.abs(acy - bcy) < 1e-6) segs.push({ k: 'h', y: acy, from: bx2, to: ax1, dir: 'l' });
      else { const mx = half((bx2 + ax1) / 2); segs.push({ k: 'h', y: acy, from: mx, to: ax1 }, { k: 'v', col: mx, y1: Math.min(acy, bcy), y2: Math.max(acy, bcy) }, { k: 'h', y: bcy, from: bx2, to: mx, dir: 'l' }); }
    } else if (gy >= 0 && by1 >= ay2) { // 下へ
      if (Math.abs(acx - bcx) < 1e-6) segs.push({ k: 'v', col: acx, y1: ay2, y2: by1, dir: 'd' });
      else { const my = half((ay2 + by1) / 2); segs.push({ k: 'v', col: acx, y1: ay2, y2: my }, { k: 'h', y: my, from: Math.min(acx, bcx), to: Math.max(acx, bcx) }, { k: 'v', col: bcx, y1: my, y2: by1, dir: 'd' }); }
    } else if (gy >= 0 && ay1 >= by2) { // 上へ
      if (Math.abs(acx - bcx) < 1e-6) segs.push({ k: 'v', col: acx, y1: by2, y2: ay1, dir: 'u' });
      else { const my = half((by2 + ay1) / 2); segs.push({ k: 'v', col: acx, y1: my, y2: ay1 }, { k: 'h', y: my, from: Math.min(acx, bcx), to: Math.max(acx, bcx) }, { k: 'v', col: bcx, y1: by2, y2: my, dir: 'u' }); }
    } else { // 重なり：中心から中心へ縦に
      if (bcy >= acy) segs.push({ k: 'v', col: bcx, y1: ay2, y2: Math.max(ay2, by1), dir: 'd' }); else segs.push({ k: 'v', col: bcx, y1: Math.min(ay1, by2), y2: ay1, dir: 'u' });
    }
    const out = segs.filter(sg => sg.k === 'h' ? sg.to > sg.from : sg.y2 > sg.y1); const last = out[out.length - 1];
    if (last && !last.dir) last.dir = last.k === 'h' ? (bcx > acx ? 'r' : 'l') : (bcy > acy ? 'd' : 'u'); // 長さ 0 の区間を省いたときも矢じりは残す
    return out;
  }
  FZ.figureRoute = route;
  /* 矢印の字を置く区間：いちばん長い区間。横の区間が字より短ければ、縦の区間の脇（1.0.12d 集まる線の字が重ならない） */
  function labelSeg(segs, text) { let best = segs[0], len = -1; for (const s of segs) { const l = s.k === 'h' ? s.to - s.from : s.y2 - s.y1; if (l > len) { len = l; best = s; } }
    if (best && best.k === 'h' && best.to - best.from < FZ.textWidth(text) + 1) { const v = segs.find(s => s.k === 'v' && s.y2 - s.y1 >= 1); if (v) return v; } return best; }
  FZ.figureLabelSeg = labelSeg;
  /* 1.0.14f 矢印の字の置き場所（図の座標）：{ x, y, tw }。横の区間なら上の行の中ほど、縦なら右脇（図の右端を越えるなら左脇） */
  function labelAt(segs, text, W) { const best = labelSeg(segs, text), tw = FZ.textWidth(text); if (!best) return null;
    if (segs.length === 3 && segs[0].k === 'h' && segs[2].k === 'h' && segs[2].dir === 'l' && segs[1].k === 'v') { const s0 = segs[0]; const row = Math.floor(s0.y) - 1 >= 0 ? Math.floor(s0.y) - 1 : Math.floor(s0.y) + 1; return { x: half(clamp(s0.from + 0.5, 0, Math.max(0, (W || 1e6) - tw))), y: row, tw }; } /* 右回り：出ていく所（箱の右上）に */
    if (best.k === 'h') { const row = Math.floor(best.y) - 1 >= 0 ? Math.floor(best.y) - 1 : Math.floor(best.y) + 1; return { x: half(clamp(best.from + (best.to - best.from - tw) / 2, 0, Math.max(0, (W || 1e6) - tw))), y: row, tw }; }
    const x = W != null && best.col + 1 + tw > W ? Math.max(0, best.col - 0.5 - tw) : best.col + 1; return { x: half(x), y: Math.floor((best.y1 + best.y2) / 2), tw }; }
  FZ.figureLabelAt = labelAt;

  /* 図の描画要素（図の座標系、dy/y は図の先頭行からの行オフセット）。left/right は図の占める列範囲 */
  function figureLayout(F, left, right) {
    const W = right - left, H = F.h; const glyphs = [], hrules = [], vrules = [], fills = []; let serial = 0;
    const X = x => left + x;
    const lanes = laneGeom(F, W, H);
    if (lanes) {
      const kind = 'thin';
      hrules.push({ id: ++serial, y: 0, from: X(0), to: X(W), kind }, { id: ++serial, y: H, from: X(0), to: X(W), kind });
      vrules.push({ id: ++serial, col: X(0), y1: 0, y2: H, kind }, { id: ++serial, col: X(W), y1: 0, y2: H, kind });
      if (lanes.dir === 'v') {
        fills.push({ id: ++serial, col: X(0), cols: W, y1: 0, y2: 1, shade: 'gray' });
        hrules.push({ id: ++serial, y: 1, from: X(0), to: X(W), kind });
        lanes.bands.forEach((b, k) => { if (k > 0) vrules.push({ id: ++serial, col: X(b.from), y1: 0, y2: H, kind }); centeredGlyphs(b.title, X(b.from), b.to - b.from, 0, M.BOLD, glyphs); });
      } else {
        fills.push({ id: ++serial, col: X(0), cols: 2, y1: 0, y2: H, shade: 'gray' });
        vrules.push({ id: ++serial, col: X(2), y1: 0, y2: H, kind });
        lanes.bands.forEach((b, k) => { if (k > 0) hrules.push({ id: ++serial, y: b.from, from: X(0), to: X(W), kind }); const chars = FZ.graphemes(b.title).map(g => g.text).filter(t => !/^[\s　]$/.test(t)); const n = Math.min(chars.length, b.to - b.from); const y0 = b.from + Math.floor((b.to - b.from - n) / 2); for (let q = 0; q < n; q++) { const w = FZ.textWidth(chars[q]); glyphs.push({ text: chars[q], col: half(X(1) - w / 2), w, marks: M.BOLD, dy: y0 + q, fig: true }); } });
      }
    }
    for (const b of F.boxes) {
      const x1 = X(b.x), x2 = X(b.x + b.w), y1 = b.y, y2 = b.y + b.h;
      if (b.shade) fills.push({ id: ++serial, col: x1, cols: b.w, y1, y2, shade: b.shade });
      const bk = b.kind === 'store' ? 'thin' : b.kind; hrules.push({ id: ++serial, y: y1, from: x1, to: x2, kind: bk }, { id: ++serial, y: y2, from: x1, to: x2, kind: bk });
      vrules.push({ id: ++serial, col: x1, y1, y2, kind: bk }); if (b.kind !== 'store') vrules.push({ id: ++serial, col: x2, y1, y2, kind: bk }); /* 1.0.12d データの置き場（DFD）：右を開けた箱 */
      const pad = 0.5, iw = b.w - 2 * pad; const rows = wrapText(b.text, Math.max(0.5, iw)).slice(0, b.h); /* 1.0.14f 字の左右の余白は半字（箱を字の大きさまで詰められる） */
      const y0 = y1 + Math.floor((b.h - rows.length) / 2);
      rows.forEach((t, k) => centeredGlyphs(t, x1 + pad, iw, y0 + k, b.bold ? M.BOLD : 0, glyphs));
    }
    F.arrows.forEach((a, idx) => {
      const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return;
      const segs = route(A, B, a.via, a.vp); const last = segs.length - 1;
      segs.forEach((s, k) => {
        const kind = k === last && a.head !== false ? 'arrow' : a.kind; // 最後の区間だけ矢じり（1.0.12d 矢じりなしの線もある）
        if (s.k === 'h') hrules.push({ id: ++serial, y: s.y, from: X(s.from), to: X(s.to), kind, dir: s.dir, arrow: idx });
        else vrules.push({ id: ++serial, col: X(s.col), y1: s.y1, y2: s.y2, kind, dir: s.dir, arrow: idx });
      });
      const albl = FZ.arrowLabel ? FZ.arrowLabel(a) : a.label; if (albl) { // 最長区間の脇に（1.0.12d 多重度も）
        const at = labelAt(segs, albl, W); if (at) { let col = X(at.x); for (const g of FZ.graphemes(albl)) { const w = FZ.textWidth(g.text); if (!/^[\s　]$/.test(g.text)) glyphs.push({ text: g.text, col, w, marks: 0, dy: at.y, fig: true }); col += w; } }
      }
    });
    for (const l of F.lines || []) { const segs = []; for (let k = 1; k < l.pts.length; k++) { const [x1, y1] = l.pts[k - 1], [x2, y2] = l.pts[k]; if (Math.abs(y1 - y2) < 1e-6) segs.push({ k: 'h', y: y1, from: Math.min(x1, x2), to: Math.max(x1, x2), dir: x2 >= x1 ? 'r' : 'l' }); else if (Math.abs(x1 - x2) < 1e-6) segs.push({ k: 'v', col: x1, y1: Math.min(y1, y2), y2: Math.max(y1, y2), dir: y2 >= y1 ? 'd' : 'u' }); }
      segs.forEach((sg, k) => { const kind = k === segs.length - 1 && l.head ? 'arrow' : l.kind; if (sg.k === 'h') hrules.push({ id: ++serial, y: sg.y, from: X(sg.from), to: X(sg.to), kind, dir: l.head && k === segs.length - 1 ? sg.dir : undefined, line2: true }); else vrules.push({ id: ++serial, col: X(sg.col), y1: sg.y1, y2: sg.y2, kind, dir: l.head && k === segs.length - 1 ? sg.dir : undefined, line2: true }); });
      if (l.label) { const hs = segs.filter(sg => sg.k === 'h'); const best = hs.sort((a, b) => (b.to - b.from) - (a.to - a.from))[0]; if (best) centeredGlyphs(l.label, X(best.from), best.to - best.from, Math.max(0, Math.round(best.y) - 1), 0, glyphs); } }
    for (const t of F.texts || []) { let col = X(t.x); for (const g of FZ.graphemes(t.text)) { const w = FZ.textWidth(g.text); if (col + w > right + 1e-6) break; glyphs.push({ text: g.text, col, w, marks: t.bold ? M.BOLD : 0, dy: t.y, fig: true }); col += w; } }
    return { glyphs, hrules, vrules, fills };
  }
  FZ.figureLayout = figureLayout;

  /* ---------- 1.0.14f 頁に入らない図：続きを次の頁に描く ----------
     FZ.figureCuts(F, W, first, rest) → [[f0, f1], …]（図の行の範囲。最初の頁に first 行、次からは rest 行）。
       切れ目は、箱をまたがない行の境のうち入るだけ下（箱の上の境＝次の頁は箱から始まる）。箱が大きすぎて切れなければ箱の途中で切る。
     FZ.figureSlice(F, W, f0, f1) → その範囲だけの図（レーンは箱と線に、矢印は切った線に）。画面・Word・PowerPoint が同じ形で描く */
  FZ.figureCuts = function (F, W, first, rest) {
    const H = Math.max(1, F.h | 0), lanes = laneGeom(F, W, H), top = lanes && lanes.dir === 'v' ? 2 : 0; const parts = []; let f0 = 0, avail = Math.max(1, first | 0); rest = Math.max(1, rest | 0);
    const ok = c => c >= top && F.boxes.every(b => !(b.y < c && c < b.y + b.h));
    while (H - f0 > avail) { let c = -1; for (let t = f0 + avail; t > f0; t--) if (ok(t)) { c = t; break; } if (c < 0 || c - f0 < Math.ceil(avail / 3)) c = f0 + avail; parts.push([f0, c]); f0 = c; avail = rest; }
    parts.push([f0, H]); return parts;
  };
  FZ.figureSlice = function (F, W, f0, f1) {
    const H = Math.max(1, F.h | 0), last = f1 >= H; const out = { h: f1 - f0, boxes: [], arrows: [], lanes: null, lines: [], texts: [] }; if (F.tag) out.tag = F.tag; if (F.dir) out.dir = F.dir;
    let nid = F.boxes.reduce((m, b) => Math.max(m, b.id), 0);
    const inRow = y => y >= f0 && y < f1; const onH = y => y >= f0 && (y < f1 || (last && y <= f1));
    const seg2line = (s, kind, head, isLast) => { /* 区間を範囲で切って線に。矢じりは終点が範囲にあるときだけ */
      if (s.k === 'h') { if (!onH(s.y)) return; const a = s.dir === 'l' ? [[s.to, s.y - f0], [s.from, s.y - f0]] : [[s.from, s.y - f0], [s.to, s.y - f0]]; out.lines.push({ pts: a, kind, head: !!(isLast && head) }); return; }
      const a = Math.max(s.y1, f0), b = Math.min(s.y2, f1); if (b - a < 1e-6) return; const up = s.dir === 'u'; const vis = up ? s.y1 >= f0 - 1e-6 : s.y2 <= f1 + 1e-6;
      out.lines.push({ pts: up ? [[s.col, b - f0], [s.col, a - f0]] : [[s.col, a - f0], [s.col, b - f0]], kind, head: !!(isLast && head && vis) }); };
    const text = (x, y, t, bold) => { if (inRow(y) && String(t).length) out.texts.push({ x: Math.max(0, x), y: y - f0, text: String(t), bold: !!bold }); };
    const lanes = laneGeom(F, W, H);
    if (lanes) { const vline = (x, y1, y2) => seg2line({ k: 'v', col: x, y1, y2 }, 'thin', false, false); const hline = (y, a, b) => seg2line({ k: 'h', y, from: a, to: b }, 'thin', false, false);
      if (lanes.dir === 'v') { if (f0 === 0) { out.boxes.push({ id: ++nid, x: 0, y: 0, w: W, h: 1, text: '', kind: 'thin', shade: 'gray', bold: false }); lanes.bands.forEach(b => text(half(b.from + (b.to - b.from - FZ.textWidth(b.title)) / 2), 0, b.title, true)); }
        vline(0, 0, H); vline(W, 0, H); lanes.bands.forEach((b, k) => { if (k > 0) vline(b.from, 0, H); }); if (last) hline(H, 0, W); }
      else { lanes.bands.forEach((b, k) => { const a = Math.max(b.from, f0), z = Math.min(b.to, f1); if (z > a) out.boxes.push({ id: ++nid, x: 0, y: a - f0, w: 2, h: z - a, text: '', kind: 'thin', shade: 'gray', bold: false });
          const chars = FZ.graphemes(b.title).map(g => g.text).filter(t => !/^[\s　]$/.test(t)); const n = Math.min(chars.length, b.to - b.from); const y0 = b.from + Math.floor((b.to - b.from - n) / 2); for (let q = 0; q < n; q++) text(half(1 - FZ.textWidth(chars[q]) / 2), y0 + q, chars[q], true);
          if (k > 0) hline(b.from, 0, W); });
        vline(W, 0, H); if (f0 === 0) hline(0, 0, W); if (last) hline(H, 0, W); } }
    for (const b of F.boxes) { if (b.y >= f0 && b.y < f1) out.boxes.push({ ...b, y: b.y - f0, h: Math.min(b.h, f1 - b.y) }); else if (b.y < f0 && b.y + b.h > f0) out.boxes.push({ ...b, id: ++nid, y: 0, h: Math.min(b.y + b.h, f1) - f0, text: '' }); } /* 箱の途中で切ったとき：続きの頁は字のない箱の続き */
    for (const a of F.arrows) { const A = box(F, a.from), B = box(F, a.to); if (!A || !B) continue; const segs = route(A, B, a.via, a.vp); const lastK = segs.length - 1; segs.forEach((s, k) => seg2line(s, a.kind, a.head !== false, k === lastK));
      const albl = FZ.arrowLabel ? FZ.arrowLabel(a) : a.label; if (albl && segs.length) { const at = labelAt(segs, albl, W); if (at) text(at.x, at.y, albl, false); } }
    for (const l of F.lines || []) { const segs = []; for (let k = 1; k < l.pts.length; k++) { const [x1, y1] = l.pts[k - 1], [x2, y2] = l.pts[k]; if (Math.abs(y1 - y2) < 1e-6) segs.push({ k: 'h', y: y1, from: Math.min(x1, x2), to: Math.max(x1, x2), dir: x2 >= x1 ? 'r' : 'l' }); else if (Math.abs(x1 - x2) < 1e-6) segs.push({ k: 'v', col: x1, y1: Math.min(y1, y2), y2: Math.max(y1, y2), dir: y2 >= y1 ? 'd' : 'u' }); }
      segs.forEach((s, k) => seg2line(s, l.kind, l.head, k === segs.length - 1));
      if (l.label) { const best = segs.filter(s => s.k === 'h').sort((a, b) => (b.to - b.from) - (a.to - a.from))[0]; if (best) text(half(best.from + (best.to - best.from - FZ.textWidth(l.label)) / 2), Math.max(0, Math.round(best.y) - 1), l.label, false); } }
    for (const t of F.texts || []) text(t.x, t.y, t.text, t.bold);
    return normalizeFigure(out);
  };

  /* 当たり判定：図の座標 (x, y) にある箱（後から描いたものを優先） */
  FZ.figureHit = function (F, x, y) { for (let k = F.boxes.length - 1; k >= 0; k--) { const b = F.boxes[k]; if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) return b; } return null; };
  /* 新しい箱の置き場所：選択中の箱の右（入らなければ下）、無ければ左上 */
  FZ.figureFreeSpot = function (F, W, sel, w = 8, h = 3) {
    const lanes = laneGeom(F, W, F.h); const minX = lanes && lanes.dir === 'h' ? 3 : 0, minY = lanes && lanes.dir === 'v' ? 2 : 0;
    const free = (x, y) => F.boxes.every(b => x + w <= b.x || x >= b.x + b.w || y + h <= b.y || y >= b.y + b.h);
    if (sel) { const cands = [[sel.x + sel.w + 3, sel.y], [sel.x, sel.y + sel.h + 2], [sel.x - w - 3, sel.y], [sel.x, sel.y - h - 2]]; for (const [x, y] of cands) if (x >= minX && y >= minY && x + w <= W && y + h <= F.h && free(x, y)) return { x, y }; }
    for (let y = minY; y + h <= F.h; y++) for (let x = minX; x + w <= W; x++) if (free(x, y)) return { x, y };
    return { x: minX, y: Math.max(minY, F.h - h) };
  };

  /* ---------- 画面で直接いじるための当たり判定と操作 ---------- */
  /* 矢印の当たり：点 (x, y) から各区間までの距離が tol 以内の矢印の番号（近いもの）。無ければ -1 */
  FZ.figureArrowHit = function (F, x, y, tol = 0.45) {
    let best = -1, bd = tol;
    F.arrows.forEach((a, k) => { const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return;
      for (const sg of route(A, B, a.via, a.vp)) { let d; if (sg.k === 'h') { const cx = clamp(x, sg.from, sg.to); d = Math.hypot(x - cx, (y - sg.y) * 0.9); } else { const cy = clamp(y, sg.y1, sg.y2); d = Math.hypot(x - sg.col, (y - cy) * 0.9); } if (d <= bd) { bd = d; best = k; } } });
    return best;
  };
  /* 矢印のラベルの置き場所（図の座標）：最長区間の中ほど */
  FZ.figureArrowMid = function (F, k) { const a = F.arrows[k]; if (!a) return null; const A = box(F, a.from), B = box(F, a.to); if (!A || !B) return null; let best = null, len = -1; for (const s of route(A, B, a.via, a.vp)) { const l = s.k === 'h' ? s.to - s.from : s.y2 - s.y1; if (l > len) { len = l; best = s; } } if (!best) return null; return best.k === 'h' ? { x: (best.from + best.to) / 2, y: best.y, horiz: true } : { x: best.col, y: (best.y1 + best.y2) / 2, horiz: false }; };
  /* 大きさを変えるつまみ（四隅と辺の中ほど）と、矢印を引き出す点（辺の中ほどの外側） */
  FZ.figureHandles = b => [['nw', b.x, b.y], ['n', b.x + b.w / 2, b.y], ['ne', b.x + b.w, b.y], ['e', b.x + b.w, b.y + b.h / 2], ['se', b.x + b.w, b.y + b.h], ['s', b.x + b.w / 2, b.y + b.h], ['sw', b.x, b.y + b.h], ['w', b.x, b.y + b.h / 2]].map(([id, x, y]) => ({ id, x, y }));
  FZ.figurePorts = b => [['n', b.x + b.w / 2, b.y - 0.55], ['e', b.x + b.w + 0.7, b.y + b.h / 2], ['s', b.x + b.w / 2, b.y + b.h + 0.55], ['w', b.x - 0.7, b.y + b.h / 2]].map(([id, x, y]) => ({ id, x, y }));
  /* つまみ id でドラッグしたときの新しい箱（元の箱 o、つまみの移動 dx, dy）。幅は 0.5 刻み・2 以上、高さは 1 刻み・1 以上、図の中に収める */
  FZ.figureResize = function (o, id, dx, dy, W, H) {
    let x1 = o.x, y1 = o.y, x2 = o.x + o.w, y2 = o.y + o.h;
    if (id.includes('w')) x1 = clamp(half(o.x + dx), 0, x2 - 2); if (id.includes('e')) x2 = clamp(half(x2 + dx), x1 + 2, W);
    if (id.includes('n')) y1 = clamp(Math.round(o.y + dy), 0, y2 - 1); if (id.includes('s')) y2 = clamp(Math.round(y2 + dy), y1 + 1, H);
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  };
  /* 揃える・等間隔：ids の箱を mode（left|center|right|top|middle|bottom|dh|dv）で */
  FZ.figureAlign = function (F, ids, mode) {
    const bs = ids.map(id => box(F, id)).filter(Boolean); if (bs.length < 2) return false;
    const L = Math.min(...bs.map(b => b.x)), R = Math.max(...bs.map(b => b.x + b.w)), T = Math.min(...bs.map(b => b.y)), Bt = Math.max(...bs.map(b => b.y + b.h));
    if (mode === 'left') for (const b of bs) b.x = L; else if (mode === 'right') for (const b of bs) b.x = half(R - b.w); else if (mode === 'center') { const c = (L + R) / 2; for (const b of bs) b.x = Math.max(0, half(c - b.w / 2)); }
    else if (mode === 'top') for (const b of bs) b.y = T; else if (mode === 'bottom') for (const b of bs) b.y = Math.max(0, Bt - b.h); else if (mode === 'middle') { const c = (T + Bt) / 2; for (const b of bs) b.y = Math.max(0, Math.round(c - b.h / 2)); }
    else if (mode === 'dh' || mode === 'dv') { if (bs.length < 3) return false; const h = mode === 'dh'; const s = bs.slice().sort((p, q) => h ? p.x - q.x : p.y - q.y); const total = s.reduce((t, b) => t + (h ? b.w : b.h), 0); const span = h ? R - L : Bt - T; const gap = (span - total) / (s.length - 1); let at = h ? L : T; for (const b of s) { if (h) { b.x = half(at); at += b.w + gap; } else { b.y = Math.round(at); at += b.h + gap; } } }
    else return false;
    return true;
  };
  /* 複製：ids の箱を写して右下へずらす（写した箱の間の矢印も写す）。新しい id の配列を返す */
  FZ.figureDuplicate = function (F, ids, W) {
    const src = ids.map(id => box(F, id)).filter(Boolean); if (!src.length) return []; let next = F.boxes.reduce((m, b) => Math.max(m, b.id), 0); const map = new Map(); const out = [];
    for (const b of src) { const nb = { ...b, id: ++next, x: clamp(b.x + 2, 0, Math.max(0, W - b.w)), y: b.y + 1 }; map.set(b.id, nb.id); F.boxes.push(nb); out.push(nb.id); if (nb.y + nb.h > F.h) F.h = nb.y + nb.h; }
    for (const a of F.arrows.slice()) if (map.has(a.from) && map.has(a.to)) F.arrows.push({ ...a, from: map.get(a.from), to: map.get(a.to) });
    return out;
  };
  /* ---------- Mermaid flowchart との往復（生成 AI との受け渡し） ---------- */
  FZ.figureToMermaid = function (F, W) {
    const lanes = laneGeom(F, W, F.h); const spreadX = Math.max(0, ...F.boxes.map(b => b.x + b.w)), spreadY = Math.max(0, ...F.boxes.map(b => b.y + b.h));
    const dir = lanes ? (lanes.dir === 'v' ? 'LR' : 'TD') : (spreadX >= spreadY * 2.5 ? 'LR' : 'TD');
    const L = ['flowchart ' + dir]; const q = t => '"' + String(t).replace(/"/g, '#quot;').replace(/\n/g, ' ') + '"';
    const node = b => 'b' + b.id + '[' + q(b.text || ' ') + ']';
    if (lanes) {
      lanes.bands.forEach((band, k) => { L.push('  subgraph L' + (k + 1) + '[' + q(band.title || ('レーン' + (k + 1))) + ']'); for (const b of F.boxes) { const c = lanes.dir === 'v' ? b.x + b.w / 2 : b.y + b.h / 2; if (c >= band.from && c < band.to) L.push('    ' + node(b)); } L.push('  end'); });
      for (const b of F.boxes) { const inAny = lanes.bands.some(band => { const c = lanes.dir === 'v' ? b.x + b.w / 2 : b.y + b.h / 2; return c >= band.from && c < band.to; }); if (!inAny) L.push('  ' + node(b)); }
    } else for (const b of F.boxes) L.push('  ' + node(b));
    for (const a of F.arrows) L.push('  b' + a.from + (a.kind === 'dotted' ? ' -.->' : a.kind === 'thick' ? ' ==>' : ' -->') + (a.label ? '|' + q(a.label) + '|' : '') + ' b' + a.to);
    return L;
  };
  FZ.figureFromMermaid = function (text, W) {
    const lines = String(text).split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('%%'));
    if (!lines.length || !/^(flowchart|graph)\b/i.test(lines[0])) return null;
    const dirTok = (lines[0].match(/^(?:flowchart|graph)\s+(\w+)/i) || [])[1] || 'TD'; const LR = /^(LR|RL)$/i.test(dirTok);
    const nodes = new Map(), order = [], edges = [], groups = []; let cur = null;
    const unq = t => t.replace(/^"|"$/g, '').replace(/#quot;/g, '"').replace(/<br\s*\/?>/gi, '\n');
    const NODE = /^([A-Za-z0-9_\u3040-\u30ff\u4e00-\u9fff]+)\s*(?:\[\[([^\]]*)\]\]|\[\(([^)]*)\)\]|\(\(([^)]*)\)\)|\[([^\]]*)\]|\(([^)]*)\)|\{\{([^}]*)\}\}|\{([^}]*)\}|>([^\]]*)\]|\[\/([^\]]*)\/\])?$/;
    const touch = (tok) => { const m = tok.trim().match(NODE); if (!m) return null; const id = m[1]; const label = m.slice(2).find(x => x != null); if (!nodes.has(id)) { nodes.set(id, { id, text: label != null ? unq(label) : id, shape: /\{/.test(tok) ? 'decision' : /\(\(/.test(tok) ? 'round' : 'rect' }); order.push(id); if (cur) cur.push(id); } else if (label != null) nodes.get(id).text = unq(label); return id; };
    for (let k = 1; k < lines.length; k++) {
      let l = lines[k];
      if (/^subgraph\b/i.test(l)) { const m = l.match(/^subgraph\s+(?:([^\[\s]+)\s*)?(?:\[([^\]]*)\])?\s*(.*)$/i); const title = unq((m && (m[2] || m[3] || m[1])) || ''); cur = []; cur.title = title; groups.push(cur); continue; }
      if (/^end$/i.test(l)) { cur = null; continue; }
      if (/^(classDef|class|style|linkStyle|click|direction)\b/i.test(l)) continue;
      l = l.replace(/--\s*([^-|>]+?)\s*-->/g, '-->|$1|').replace(/-\.\s*([^-.|>]+?)\s*\.->/g, '-.->|$1|').replace(/==\s*([^=|>]+?)\s*==>/g, '==>|$1|');
      const parts = l.split(/\s*(-{2,}>|<-{2,}|-{3,}|-\.+->|\.-+>|={2,}>|={3,})\s*(?:\|([^|]*)\|)?\s*/);
      if (parts.length === 1) { for (const t of l.split(/\s*&\s*/)) touch(t); continue; }
      let prev = parts[0].split(/\s*&\s*/).map(touch).filter(Boolean);
      for (let p = 1; p < parts.length; p += 3) { const op = parts[p], label = parts[p + 1] != null ? unq(parts[p + 1]) : '', right = (parts[p + 2] || '').split(/\s*&\s*/).map(touch).filter(Boolean); const kind = /\./.test(op) ? 'dotted' : /=/.test(op) ? 'thick' : 'thin'; const headed = />/.test(op); for (const a of prev) for (const b of right) if (a !== b) edges.push(/^</.test(op) ? { from: b, to: a, label, kind } : { from: a, to: b, label, kind, headed }); prev = right; }
    }
    if (!order.length) return null;
    const idOf = new Map(order.map((id, k) => [id, k + 1]));
    const tw = id => Math.max(2, FZ.textWidth(nodes.get(id).text.split('\n').reduce((a, b) => FZ.textWidth(b) > FZ.textWidth(a) ? b : a, '')));
    const boxes = []; let h = 1;
    const mk = (id, x, y, w, bh) => { const n = nodes.get(id); boxes.push({ id: idOf.get(id), x, y, w, h: bh, text: n.text, kind: n.shape === 'decision' ? 'double' : 'thin', shade: n.shape === 'round' ? 'gray' : null, bold: false }); };
    let lanes = null;
    if (groups.length) { // サブグラフ → 縦レーン。各レーンの中で上から並べる
      const n = groups.length, lw = Math.floor(W / n); const inGroup = new Set(groups.flat());
      groups.forEach((g, k) => { const x0 = k * lw + 1, w = Math.max(4, lw - 2); g.forEach((id, j) => { const bh = Math.max(3, Math.ceil(tw(id) / Math.max(1, w - 2)) + 2); mk(id, x0, 2 + j * 5, w, bh); h = Math.max(h, 2 + j * 5 + bh + 1); }); });
      let extra = 0; for (const id of order) if (!inGroup.has(id)) { mk(id, 1, h + extra * 5, Math.max(6, Math.min(W - 2, tw(id) + 2)), 3); extra++; } if (extra) h += extra * 5;
      lanes = { dir: 'v', items: groups.map(g => ({ title: g.title || '', size: 0 })) };
    } else {
      const w = Math.max(6, Math.min(14, Math.max(...order.map(tw)) + 2)), gap = LR ? 4 : 3, perRow = Math.max(1, Math.floor((W + gap) / (w + gap)));
      order.forEach((id, k) => { const col = LR ? k % perRow : 0, row = LR ? Math.floor(k / perRow) : k; const bh = Math.max(3, Math.ceil(tw(id) / Math.max(1, w - 2)) + 2); const x = LR ? col * (w + gap) : Math.max(0, Math.floor((W - w) / 2)); const y = LR ? 1 + row * 6 : 1 + row * (3 + 2); mk(id, x, y, w, bh); h = Math.max(h, y + bh + 1); });
    }
    const arrows = edges.map(e => ({ from: idOf.get(e.from), to: idOf.get(e.to), label: e.label || '', kind: e.kind })).filter(a => a.from && a.to);
    return normalizeFigure({ h, boxes, arrows, lanes });
  };
  /* ---------- 原本形式（指示行） ---------- */
  const KN = { thin: '細', thick: '太', double: '二重', dotted: '点線', store: '置場' }, KK = { 細: 'thin', 太: 'thick', 二重: 'double', 点線: 'dotted', 置場: 'store' };
  const SN = FZ.SHADE_NAMES || { gray: '薄', dark: '濃', hatch: '斜線', dots: '点' }, SK = Object.assign({ 無: null }, FZ.SHADE_KEYS || { 薄: 'gray', 濃: 'dark', 斜線: 'hatch', 点: 'dots' });
  const escT = t => String(t).replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
  const unescT = t => String(t).replace(/\\n/g, '\n').replace(/\\\\/g, '\\');
  FZ.figureToLines = function (F) {
    const L = [];
    if (F.lanes) L.push('#レーン ' + (F.lanes.dir === 'v' ? '縦' : '横') + ' ' + F.lanes.items.map(it => it.size || 0).join(',') + ' ' + F.lanes.items.map(it => it.title.replace(/\|/g, '｜')).join('|'));
    for (const b of F.boxes) L.push('#箱 ' + b.id + ' ' + b.x + ',' + b.y + ' ' + b.w + 'x' + b.h + ' ' + (KN[b.kind] || '細') + ' ' + (SN[b.shade] || '無') + (b.bold ? '太字' : '') + ' ' + escT(b.text));
    for (const a of F.arrows) L.push('#矢印 ' + a.from + (a.head === false ? '─' : '→') + a.to + ' ' + (KN[a.kind] || '細') + (a.card ? ' ' + a.card : '') + (a.via ? ' ' + (a.via === 'r' ? '右回り' : '下回り') + (a.vp != null ? ':' + a.vp : '') : '') + (a.label ? ' ' + escT(a.label) : ''));
    for (const l of F.lines || []) L.push('#線 ' + l.pts.map(p => p[0] + ',' + p[1]).join(' ') + ' ' + (KN[l.kind] || '細') + (l.head ? '→' : '') + (l.role ? ' 役:' + l.role : '') + (l.label ? ' ' + escT(l.label) : ''));
    for (const t of F.texts || []) L.push('#字 ' + t.x + ',' + t.y + (t.bold ? ' 太字' : '') + ' ' + escT(t.text));
    if (F.tag || F.dir) L.unshift('#図種 ' + ({ flow: '流れ図', seq: 'シーケンス', er: 'ER', mind: 'マインド' }[F.tag] || '流れ図') + (F.dir ? ' ' + F.dir : '')); /* 1.0.12d */
    return L;
  };
  /* 指示行 1 本を解釈して pending の図に加える。該当しなければ false */
  FZ.figureDirective = function (raw, fig) {
    let m;
    if ((m = raw.match(/^#箱\s+(\d+)\s+(\d+(?:\.5)?),(\d+)\s+(\d+(?:\.5)?)x(\d+)\s+(\S+)\s+(\S+)(?:\s(.*))?$/))) { const shadeTok = m[7].replace(/太字$/, ''); fig.boxes.push({ id: +m[1], x: +m[2], y: +m[3], w: +m[4], h: +m[5], kind: KK[m[6]] || 'thin', shade: SK[shadeTok] ?? null, bold: /太字$/.test(m[7]), text: unescT(m[8] || '') }); return true; }
    if ((m = raw.match(/^#矢印\s+(\d+)([→─])(\d+)(?:\s+(\S+))?(?:\s+([|o}{]{2}(?:--|\.\.)[|o}{]{2}))?(?:\s+(右回り|下回り)(?::(\d+(?:\.5)?))?)?(?:\s(.*))?$/))) { const a = { from: +m[1], to: +m[3], kind: KK[m[4]] || 'thin', label: unescT(m[8] || '') }; if (m[2] === '─') a.head = false; if (m[5]) a.card = m[5]; if (m[6]) { a.via = m[6] === '右回り' ? 'r' : 'b'; if (m[7] != null) a.vp = +m[7]; } fig.arrows.push(a); return true; }
    if ((m = raw.match(/^#線\s+((?:\d+(?:\.5)?,\d+(?:\.5)?\s+)+)(細|太|点線)(→)?(?:\s+役:(\w+))?(?:\s(.*))?$/))) { (fig.lines = fig.lines || []).push({ pts: m[1].trim().split(/\s+/).map(p => p.split(',').map(Number)), kind: KK[m[2]] || 'thin', head: !!m[3], role: m[4] || undefined, label: unescT(m[5] || '') }); return true; }
    if ((m = raw.match(/^#字\s+(\d+(?:\.5)?),(\d+)(\s+太字)?\s(.*)$/))) { (fig.texts = fig.texts || []).push({ x: +m[1], y: +m[2], bold: !!m[3], text: unescT(m[4]) }); return true; }
    if ((m = raw.match(/^#図種\s+(\S+)(?:\s+(LR|TD))?$/))) { fig.tag = { 流れ図: 'flow', シーケンス: 'seq', ER: 'er', マインド: 'mind' }[m[1]] || 'flow'; if (m[2]) fig.dir = m[2]; return true; }
    if ((m = raw.match(/^#レーン\s+(縦|横)\s+(\S*)\s*(.*)$/))) { const sizes = m[2].split(',').map(Number); const titles = m[3].split('|'); fig.lanes = { dir: m[1] === '縦' ? 'v' : 'h', items: titles.map((t, k) => ({ title: t, size: sizes[k] || 0 })) }; return true; }
    return false;
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
