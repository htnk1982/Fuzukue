/* 文机 ファイル入出力：Tauri → File System Access API → 旧来（input/download）の順に対応 */
(function (FZ) {
'use strict';
const FILTERS = [{ name: '文机の原本', extensions: ['fzk', 'txt', 'md', 'json'] }];
const ACCEPT = { description: '文机の原本', accept: { 'text/plain': ['.fzk', '.txt', '.md', '.json'] } };
const tauri = () => globalThis.__TAURI__ || null;
const host = () => (globalThis.fzHost && typeof globalThis.fzOpenFile === 'function') ? globalThis : null; // Go + WebView2 の単一 exe 版
const hasFSA = typeof window !== 'undefined' && 'showOpenFilePicker' in window;

const files = {
  kind: host() ? 'host' : tauri() ? 'tauri' : hasFSA ? 'fsa' : 'basic',
  async open() {
    if (host()) { const r = await globalThis.fzOpenFile(); if (!r) return null; return { name: r.name, path: r.path, text: r.text }; }
    if (tauri()) { const T = tauri(); const path = await T.dialog.open({ multiple: false, filters: FILTERS }); if (!path) return null; const text = await T.fs.readTextFile(path); return { name: baseName(path), path, text }; }
    if (hasFSA) { try { const [h] = await window.showOpenFilePicker({ types: [ACCEPT], multiple: false }); const f = await h.getFile(); return { name: f.name, handle: h, text: await f.text() }; } catch (e) { if (e.name === 'AbortError') return null; throw e; } }
    return new Promise(res => { const inp = document.getElementById('fileInput'); inp.value = ''; inp.onchange = async () => { const f = inp.files[0]; if (!f) return res(null); res({ name: f.name, text: await f.text() }); }; inp.click(); });
  },
  async save(text, ref, suggested, opts = {}) { // ref: {handle|path} 既存参照。無ければ saveAs。opts.auto：自動保存（保存先を聞かない）
    if (ref && ref.handle && !ref.path && (host() || tauri())) { try { const w = await ref.handle.createWritable(); await w.write(text); await w.close(); return { name: ref.handle.name, handle: ref.handle }; } catch (e) { if (opts.auto) throw e; ref = null; } } // ドロップで開いたファイル：参照に書けなければ保存先を聞く
    if (host()) { let path = ref && ref.path; if (!path) { path = await globalThis.fzSaveFile(suggested || '文書.fzk'); if (!path) return null; } await globalThis.fzWriteFile(path, text); return { name: baseName(path), path }; }
    if (tauri()) { const T = tauri(); let path = ref && ref.path; if (!path) { path = await T.dialog.save({ defaultPath: suggested, filters: FILTERS }); if (!path) return null; } await T.fs.writeTextFile(path, text); return { name: baseName(path), path }; }
    if (hasFSA) { let h = ref && ref.handle; if (!h) { try { h = await window.showSaveFilePicker({ suggestedName: suggested, types: [ACCEPT] }); } catch (e) { if (e.name === 'AbortError') return null; throw e; } } const w = await h.createWritable(); await w.write(text); await w.close(); return { name: h.name, handle: h }; }
    download(text, suggested); return { name: suggested };
  },
  async saveAs(text, suggested) { return this.save(text, null, suggested); },
  /* ファイルの更新日時（ミリ秒）と大きさ。分からなければ { mtime: 0 }、消えた・動いた・読めないなら { mtime: -1 }。外での書き換えを見つけるのに使う */
  async info(ref) {
    try { if (!ref) return { mtime: 0 };
      if (ref.handle && typeof ref.handle.getFile === 'function') { const f = await ref.handle.getFile(); return { mtime: f.lastModified || 0, size: f.size }; }
      if (ref.path && host() && typeof globalThis.fzStat === 'function') { const r = await globalThis.fzStat(ref.path); return { mtime: (r && r.mtime) || 0, size: r && r.size }; }
    } catch (e) { return { mtime: -1 }; }
    return { mtime: 0 };
  },
  async stamp(ref) { return (await this.info(ref)).mtime; },
  /* 中身の指紋（FNV-1a 32 ビット＋長さ）。更新日時だけでは見分けられない書き換え（1 秒以内の書き換え・日時の粗いファイルシステム・日時を保つ同期ソフト）を中身で確かめる */
  hash(s) { s = String(s); let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return (h >>> 0).toString(36) + ':' + s.length; },
  async read(ref) { try { if (!ref) return null; if (ref.handle && typeof ref.handle.getFile === 'function') return await (await ref.handle.getFile()).text(); if (ref.path && host() && typeof globalThis.fzReadFile === 'function') return await globalThis.fzReadFile(ref.path); if (ref.path && tauri()) return await tauri().fs.readTextFile(ref.path); } catch { } return null; },
  /* 開いた（保存した）あとに文机の外で書き換えられたか。{ changed, mtime, gone }。
     更新日時か大きさがずれたら中身の指紋で確かめる（同じ中身の書き直しは変更としない）。ずれていなくても、2MB までのファイルは中身を確かめる（日時の粗いファイルシステムで 1〜2 秒以内に書き換えられた時のため） */
  async outside(ref) { if (!ref || !ref.mtime) return { changed: false }; const st = await this.info(ref); const t = st.mtime; if (t === -1) return { changed: true, gone: true }; if (!t) return { changed: false };
    const moved = t !== ref.mtime || (ref.size != null && st.size != null && st.size !== ref.size);
    if (!moved && !(ref.hash && (st.size == null || st.size <= 2e6))) return { changed: false, mtime: t };
    if (ref.hash) { const s = await this.read(ref); if (s != null) { const same = this.hash(s) === ref.hash; if (same) { ref.mtime = t; if (st.size != null) ref.size = st.size; } return { changed: !same, mtime: t }; } }
    return { changed: moved, mtime: t }; },
  /* 書き出し（P18）：保存先を先に決め（ブラウザの「名前を付けて保存」・exe のダイアログ）、それから中身を作って書く。書き終わってから結果を返す。
     戻り値 { ok, name, how: 'file' } ／ { cancelled: true }。書けなければ throw。保存の口の無いブラウザは { ok, how: 'download' }（保存先と完了はブラウザ任せ） */
  async exportFile(name, produce) {
    const ext = ((String(name).match(/\.(\w+)$/) || [])[1] || '').toLowerCase(); const mime = MIME[ext] || 'application/octet-stream';
    if (host()) { const path = await globalThis.fzSaveFile(name); if (!path) return { cancelled: true }; const data = await produce();
      if (data instanceof Uint8Array) { if (typeof globalThis.fzWriteBinary !== 'function') throw new Error('このホストはバイナリ保存に未対応です（host を再ビルドしてください）'); await globalThis.fzWriteBinary(path, toB64(data)); } else await globalThis.fzWriteFile(path, data);
      return { ok: true, name: baseName(path), how: 'file' }; }
    if (tauri()) { const T = tauri(); const path = await T.dialog.save({ defaultPath: name }); if (!path) return { cancelled: true }; const data = await produce(); if (data instanceof Uint8Array) await (T.fs.writeBinaryFile || T.fs.writeFile)(path, data); else await T.fs.writeTextFile(path, data); return { ok: true, name: baseName(path), how: 'file' }; }
    if (typeof window.showSaveFilePicker === 'function') { let h;
      try { h = await window.showSaveFilePicker({ suggestedName: name, types: ext ? [{ description: (MIME_NAME[ext] || ext.toUpperCase()) + ' ファイル', accept: { [mime]: ['.' + ext] } }] : undefined }); }
      catch (e) { if (e.name === 'AbortError') return { cancelled: true }; if (e.name !== 'SecurityError' && e.name !== 'NotAllowedError') throw e; h = null; } /* 操作から時間が経って保存の窓を開けない：ダウンロードに */
      if (h) { const data = await produce(); const w = await h.createWritable(); try { await w.write(data); await w.close(); } catch (e) { try { await w.abort(); } catch { } throw e; } return { ok: true, name: h.name, how: 'file' }; } }
    const data = await produce(); this.download(data, name); return { ok: true, name, how: 'download' };
  },
  download,
};
const MIME = { docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', md: 'text/markdown', txt: 'text/plain', json: 'application/json', fzk: 'text/plain', html: 'text/html' };
const MIME_NAME = { docx: 'Word', pptx: 'PowerPoint', md: 'Markdown', txt: 'テキスト', json: '設定', fzk: '文机', html: 'HTML' };
/* text は文字列か Uint8Array（docx/pptx などのバイナリ） */
function download(text, name) {
  const bin = text instanceof Uint8Array;
  if (host()) { globalThis.fzSaveFile(name).then(p => { if (!p) return; if (bin) { if (typeof globalThis.fzWriteBinary === 'function') return globalThis.fzWriteBinary(p, toB64(text)); throw new Error('このホストはバイナリ保存に未対応です（host を再ビルドしてください）'); } return globalThis.fzWriteFile(p, text); }).catch(e => alert('保存できませんでした：' + e)); return; }
  const type = bin ? (/\.docx$/i.test(name) ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : /\.pptx$/i.test(name) ? 'application/vnd.openxmlformats-officedocument.presentationml.presentation' : 'application/octet-stream') : 'text/plain;charset=utf-8';
  const blob = new Blob([text], { type }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 20000); }
function toB64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function baseName(p) { return String(p).split(/[\\/]/).pop(); }
FZ.files = files;
})(window.FZ = window.FZ || {});
