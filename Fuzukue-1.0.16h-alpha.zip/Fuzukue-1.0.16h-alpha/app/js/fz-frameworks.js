/* 文机 — フレームワーク（1.0.12）：考えるための型を、紙面の表・区画・見出しの枠として入れ、各枠に何を書くかを画面の下に出す。
 * ワープロ専用機の「文例集」の代わりに、ビジネスの考え方の型を引き出す。
 * 出典：2 冊（P＝プロジェクトマネジメントのフレームワーク集、B＝ビジネスフレームワーク集）に載る型を種類ごとに分けた。説明はこの道具のために書き起こしたもの（本文の引用ではない）。
 * 1 件 = { id, name, cat, src: 'P'|'B'|'PB', form, when（使いどころ一言）, axes, cols, rows, arrow, grid, parts: [{ n: 枠の名前, g: 書くこと, d: 深さ }] }
 * form：
 *   m2     … 2 軸 4 象限の表（axes = [左, 右, 上, 下]、parts は 左上・右上・左下・右下）
 *   panels … 区画（parts が子の節。arrow で区画矢印、grid=N で N 列）
 *   sheet  … 2 列の表（項目｜記入）。parts が行
 *   ledger … 台帳の表（parts が列、rows 行の空欄）
 *   grid   … 行×列の表（cols が列の見出し、parts が行）
 *   list   … 見出しの並び（parts が見出し、下に空の行）。文書の組み立て向け
 *   tree   … 箇条書きの木（parts の d が深さ）
 *   story  … 空・雨・傘の 3 列の表（parts が列の見出し。見出しは淡網・中央、下に「・」の行）。1.0.13e 定番ストーリー
 * 入れた枠は、先頭の見出しの行に「枠:ID」が付き（原本に残る）、その節の中にカーソルがある間、画面の下に解説が出る。 */
(function (FZ) {
  'use strict';
  const CATS = [
    ['prob', '問題を見つける・掘り下げる'], ['env', '環境・市場を分析する'], ['cust', '顧客と価値を考える'], ['idea', 'アイデアを出す・磨く'],
    ['strat', '戦略を立てる・選ぶ'], ['plan', '構想と計画を立てる'], ['dev', '開発の進め方・情報システム'], ['ctrl', '進行・品質・リスクを管理する'],
    ['ops', '業務を改善する'], ['rev', '振り返る・学ぶ'], ['team', 'チームと人を動かす'], ['deal', '契約と交渉'], ['comm', '伝える・文書にする'], ['story', 'ストーリー（空・雨・傘）']];
  const LIST = [];
  /* f(id, 名前, 種類, 出典, 形, 使いどころ, 本文)。本文は 1 行 1 項目：「軸=左|右/上|下」「列=a|b|c」「行数=3」「矢印」「段=3」、ほかは「名前=書くこと」（頭の > の数が tree の深さ） */
  function f(id, name, cat, src, form, when, body) {
    const e = { id, name, cat, src, form, when, parts: [] };
    for (const raw of String(body).split('\n')) { const s = raw.trim(); if (!s) continue; let m;
      if ((m = s.match(/^軸=(.*)$/))) { const [x, y] = m[1].split('/'); e.axes = [...x.split('|'), ...y.split('|')]; continue; }
      if ((m = s.match(/^列=(.*)$/))) { e.cols = m[1].split('|'); continue; }
      if ((m = s.match(/^行数=(\d+)$/))) { e.rows = +m[1]; continue; }
      if (s === '矢印') { e.arrow = true; continue; }
      if ((m = s.match(/^段=(\d)$/))) { e.grid = +m[1]; continue; }
      if ((m = s.match(/^手順=(.*)$/))) { e.how = m[1]; continue; }
      const d = (s.match(/^>+/) || [''])[0].length; const t = s.slice(d); const q = t.indexOf('='); e.parts.push({ n: (q < 0 ? t : t.slice(0, q)).trim(), g: q < 0 ? '' : t.slice(q + 1).trim(), d }); }
    LIST.push(e); }
  FZ.FW_CATS = CATS; FZ.FW = LIST; FZ.fwDef = f;
  FZ.fwById = id => LIST.find(e => e.id === id) || null;

  /* ---------- 紙面の枠を作る（文机の原本の行） ---------- */
  const esc = t => String(t).replace(/</g, '\\<');
  const cell = t => esc(String(t).replace(/\|/g, '｜'));
  /* 表の列の境界：W 字の幅を、見出しの字数に合わせて配る（最小 4 字） */
  function bounds(heads, W, first) { const n = heads.length; const want = heads.map((h, k) => Math.max(4, Math.min(16, FZ.textWidth ? Math.ceil(FZ.textWidth(String(h))) + 2 : String(h).length + 2))); if (first) want[0] = Math.max(want[0], first);
    let tot = want.reduce((a, b) => a + b, 0); const k = W / tot; const b = [0]; let acc = 0; for (let i = 0; i < n; i++) { acc += want[i] * k; b.push(i === n - 1 ? W : Math.max(b[i] + 3, Math.round(acc * 2) / 2)); } return b; }
  /* lv：先頭の見出しの深さ（1〜6）。W：使える字数。theme：題に添える語 */
  /* 1.0.12b 表の見出しは濃灰（濃い網に白抜き）の太字、表側は淡網の太字。書くますは「・」（セルの中の箇条書き。Enter で次の「・」が同じますに続く） */
  const B_ = t => t ? '<太字>' + cell(t) + '</太字>' : ' ';
  const BUL = '・';
  FZ.fwBuild = function (e, o = {}) {
    const lv = Math.max(1, Math.min(6, o.lv || 1)), W = Math.max(20, o.cols || 40); const L = []; const H = (d, t, extra = '') => `[番号${Math.min(8, lv + d)}${extra}]${esc(t)}`;
    const title = e.name + (o.theme ? '：' + o.theme : '');
    const head = (extra = '') => L.push(H(0, title, ' 枠:' + e.id + extra));
    if (e.form === 'panels') { const n = e.parts.length; const per = Math.max(1, Math.floor((W + 2) / 16)); /* 区画 1 つに 14 字は欲しい */ let g = e.grid || (n <= Math.min(5, per) ? 0 : Math.min(per, n <= 4 ? 2 : 3)); if (g && n <= g) g = 0; const lay = g ? '区画' + Math.max(2, g) : '区画横'; head(` ${lay} 区画見出し濃灰${e.arrow ? ' 区画矢印' : ''}`); for (const p of e.parts) { L.push(H(1, p.n)); L.push('[項目1]'); } return L; }
    if (e.form === 'list') { head(); for (const p of e.parts) { L.push(H(1, p.n)); L.push(''); } return L; }
    if (e.form === 'tree') { head(); for (const p of e.parts) L.push(`[項目${Math.min(8, (p.d || 0) + 1)}]${esc(p.n)}`); return L; }
    head();
    const row = cs => '| ' + cs.join(' | ') + ' |';
    if (e.form === 'm2') { const [xl, xr, yt, yb] = e.axes || ['', '', '', '']; const [a, b, c, d] = e.parts; const B = [0, Math.min(10, Math.round(W * 0.2)), 0, W]; B[2] = B[1] + Math.round((W - B[1]) / 2);
      L.push(`#表 列 ${B.join(',')} 様式 格子 見出し濃灰 表側淡`); L.push(row([' ', B_(xl), B_(xr)]));
      L.push(row([B_(yt), B_(a ? a.n : ''), B_(b ? b.n : '')])); L.push('[行続き]' + row([' ', BUL, BUL]));
      L.push(row([B_(yb), B_(c ? c.n : ''), B_(d ? d.n : '')])); L.push('[行続き]' + row([' ', BUL, BUL])); L.push(''); return L; }
    if (e.form === 'sheet') { const B = bounds(['項目', '記入'], W, Math.min(16, Math.max(6, Math.max(...e.parts.map(p => FZ.textWidth ? Math.ceil(FZ.textWidth(p.n)) + 2 : p.n.length + 2))))); B[1] = Math.min(B[1], Math.round(W * 0.4)); L.push(`#表 列 ${B.join(',')} 様式 格子 見出し濃灰 表側淡`); L.push(row([B_('項目'), B_('記入')])); for (const p of e.parts) L.push(row([B_(p.n), BUL])); L.push(''); return L; }
    if (e.form === 'story') { const heads = e.parts.map(p => p.n), n = heads.length; const B = [0]; for (let k = 1; k <= n; k++) B.push(k === n ? W : Math.round(W * k / n * 2) / 2); L.push(`#表 列 ${B.join(',')} 様式 格子 見出し淡`); L.push('[列揃え' + '中'.repeat(n) + ']' + row(heads.map(cell))); L.push(row(heads.map(() => BUL))); L.push(''); return L; } /* 1.0.13e 空・雨・傘：見出しは淡網・中央、書くますは「・」 */
    if (e.form === 'ledger') { const heads = e.parts.map(p => p.n); L.push(`#表 列 ${bounds(heads, W).join(',')} 様式 格子 見出し濃灰`); L.push(row(heads.map(B_))); for (let r = 0; r < (e.rows || 3); r++) L.push(row(heads.map(() => ' '))); L.push(''); return L; } /* 台帳は 1 行 1 件（印は付けない） */
    if (e.form === 'grid') { const cols = e.cols || ['']; const heads = ['', ...cols]; const first = Math.max(6, ...e.parts.map(p => FZ.textWidth ? Math.ceil(FZ.textWidth(p.n)) + 2 : p.n.length + 2)); L.push(`#表 列 ${bounds(heads, W, Math.min(14, first)).join(',')} 様式 格子 見出し濃灰 表側淡`); L.push(row(heads.map(B_))); for (const p of e.parts) L.push(row([B_(p.n), ...cols.map(() => BUL)])); L.push(''); return L; }
    return L;
  };
  /* 解説の当たり：カーソルのある所の字（セル・見出し・表の見出し）から、いちばん合う枠の番号 */
  const norm = t => String(t || '').replace(/[（(][^）)]*[）)]/g, '').replace(/[\s　・：:]/g, '').toLowerCase();
  /* texts：候補を順に（文字列、または { t, loose }）。候補ごとに、同じ名前 → （loose なら）頭が合う名前。1.0.12d 打った字（loose: false）は頭合わせに使わない */
  FZ.fwMatch = function (e, texts) { const ps = e.parts.map(p => norm(p.n));
    for (const c of texts) { const raw = typeof c === 'string' ? c : c && c.t; const loose = typeof c === 'string' || (c && c.loose !== false); const t = norm(raw); if (!t) continue;
      let k = ps.indexOf(t); if (k >= 0) return k;
      if (loose) { k = ps.findIndex(n => n.length >= 2 && (t.startsWith(n) || (n.startsWith(t) && t.length >= 2))); if (k >= 0) return k; } }
    return -1; };
  FZ.fwSearch = function (q) { q = norm(q); if (!q) return LIST.slice(); return LIST.filter(e => norm(e.name).includes(q) || norm(e.when).includes(q) || e.parts.some(p => norm(p.n).includes(q))); };
})(typeof window !== 'undefined' ? (window.FZ = window.FZ || {}) : (globalThis.FZ = globalThis.FZ || {}));
