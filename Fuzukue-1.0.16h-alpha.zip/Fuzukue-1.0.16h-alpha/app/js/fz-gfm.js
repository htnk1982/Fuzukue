/* 文机 — GFM と文机の往復（意味の写像）
 * fromGfm：GFM（fz-md.js で解析）→ 文机の文書。ブロック構造（見出し・段落・引用・リスト・コード・表・区切り）と
 *          文字の修飾（強調・打消し・コード・リンク・画像）を、文机の世界の相当物に写す。
 * toGfm  ：文机の文書 → GFM。階層体系の番号は実際の番号で、記号は -、→／❏／☑ は項目の中に。表は | の表、図は Mermaid。
 * 対応表は はじめに.md「Markdown との対応」。 */
(function (FZ) {
  'use strict';
  const M = FZ.M;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const isCJK = ch => !!ch && /[　-ヿ㐀-鿿豈-﫿＀-￯]/.test(ch);

  let OPTS = {}; // fromGfm の選択肢：hardBreaks（改行をそのまま行に）、fragment（貼付：表題にしない）
  /* ---------- 読み込み ---------- */
  function frontMatter(text) { // YAML 風の前付け（title: → 題名）。GFM ではないが生成 AI の出力に多い
    const m = String(text).match(/^---[ \t]*\n([\s\S]*?)\n---[ \t]*(?:\n|$)/); if (!m || m[1].split('\n').length > 60 || !/^[\w\-぀-鿿]+\s*:/m.test(m[1])) return { text, meta: {} };
    const meta = {}; for (const l of m[1].split('\n')) { const mm = l.match(/^([\w\-぀-鿿]+)\s*:\s*(.*)$/); if (mm) meta[mm[1].toLowerCase()] = mm[2].trim().replace(/^["']|["']$/g, ''); }
    return { text: text.slice(m[0].length), meta };
  }
  const HTML_MARK = { u: M.UNDER, ins: M.UNDER, mark: M.SHADE, kbd: M.CODE, code: M.CODE, s: M.STRIKE, del: M.STRIKE, strike: M.STRIKE, b: M.BOLD, strong: M.BOLD, i: M.DOT, em: M.DOT };
  let GFM_NOTES = []; /* 読み込み中：今の行の付箋の id（行内の <!-- 付箋 id -->） */
  /* インライン節 → セグメント列（ハード改行で分割） */
  function inlinesToSegs(node) {
    const segs = []; let seg = FZ.newSeg(0, ''); const open = {}; // 生 HTML タグ（<u> <mark> <s> …）の入れ子
    const extraMask = () => { let e = 0; for (const [tag, bit] of Object.entries(HTML_MARK)) if (open[tag]) e |= bit; return e; };
    const push = (t, mk) => { mk |= extraMask(); for (const ch of FZ.cleanText(t)) { seg.text += ch; for (let k = 0; k < ch.length; k++) seg.marks.push(mk); } };
    const link = (start, url, image, title) => { if (!url) { for (let k = start; k < seg.marks.length; k++) seg.marks[k] &= ~M.LINK; return; } const l = { start, end: seg.text.length, url }; if (image) l.image = true; if (title) l.title = title; if (l.end > l.start) (seg.links = seg.links || []).push(l); }; // URL が空ならリンクにしない
    const brk = () => { segs.push(seg); seg = FZ.newSeg(0, ''); };
    const walk = (n, mk) => {
      switch (n.type) {
        case 'text': push(n.literal.replace(/\t/g, '　'), mk); break;
        case 'softbreak': { if (OPTS.hardBreaks) { brk(); break; } const prev = seg.text.slice(-1), nextNode = n.next; const nx = nextNode && nextNode.type === 'text' ? nextNode.literal.charAt(0) : ''; if (!(isCJK(prev) || isCJK(nx))) push(' ', mk); break; } // 和文どうしの行継ぎは空白なし
        case 'linebreak': brk(); break;
        case 'code': push(n.literal, mk | M.CODE); break; // ` はコード（K-5）。網掛けは <mark>
        case 'emph': for (const c of n.children) walk(c, mk | M.DOT); break;
        case 'strong': for (const c of n.children) walk(c, mk | M.BOLD); break;
        case 'strikethrough': for (const c of n.children) walk(c, mk | M.STRIKE); break;
        case 'link': { const s0 = seg.text.length; for (const c of n.children) walk(c, mk | M.LINK); link(s0, n.destination, false, n.title); break; }
        case 'image': { const s0 = seg.text.length; const alt = n.children.map(textOf).join(''); push(alt || '画像', mk | M.LINK); link(s0, n.destination, true, n.title); break; }
        case 'html_inline': { const t = n.literal; let m; if (/^<br\s*\/?>$/i.test(t)) { brk(); break; } if ((m = t.match(/^<!--\s*付箋\s+([A-Za-z0-9_-]+)\s*-->$/))) { GFM_NOTES.push(m[1]); (seg.fzNotes = seg.fzNotes || []).push(m[1]); break; } /* 文机 Markdown：この行に付いた付箋 */ if ((m = t.match(/^<\/?([a-zA-Z][a-zA-Z0-9]*)/))) { const tag = m[1].toLowerCase(); if (HTML_MARK[tag]) { if (t[1] === '/') open[tag] = Math.max(0, (open[tag] || 0) - 1); else open[tag] = (open[tag] || 0) + 1; } } break; }
        default: if (n.children) for (const c of n.children) walk(c, mk);
      }
    };
    const textOf = n => n.type === 'text' || n.type === 'code' ? n.literal : (n.children || []).map(textOf).join('');
    for (const c of node.children) walk(c, 0);
    segs.push(seg); return segs;
  }
  function tableWidths(rows, cols) {
    const nCols = Math.max(...rows.map(r => r.length));
    let widths = Array.from({ length: nCols }, (_, c) => Math.max(3, Math.ceil(Math.max(0, ...rows.map(r => FZ.textWidth(r[c] ? r[c].text : '')))) + 1));
    let sum = widths.reduce((a, b) => a + b, 0); if (sum > cols) { widths = widths.map(w => Math.max(2, Math.floor(w * cols / sum))); sum = widths.reduce((a, b) => a + b, 0); while (sum > cols) { const k = widths.indexOf(Math.max(...widths)); widths[k]--; sum--; } }
    const bounds = [0]; for (let c = 0; c < nCols; c++) bounds.push(bounds[c] + widths[c]); return bounds;
  }
  FZ.fromGfm = function (md, base, opts) {
    OPTS = opts || {};
    const fm = frontMatter(String(md).replace(/\r\n?/g, '\n')); const ast = FZ.md.parse(fm.text, { cjk: true, stripStars: true }); // 和文向けの強調の緩和と、余った ** の除去
    const doc = base || FZ.newDoc(); doc.lines = []; doc.rules = []; doc.fills = []; const cols = doc.format.cols;
    if (fm.meta.title || fm.meta['題名']) doc.title = fm.meta.title || fm.meta['題名'];
    const lines = doc.lines;
    // 表題：# が 1 つだけで先頭にあるとき
    const tops = ast.children; const h1s = tops.filter(n => n.type === 'heading' && n.level === 1); const titleNote = h1s.length && tops.some(n => n.type === 'html_block' && /^\s*<!--\s*表題\s*-->\s*$/.test(n.literal || '')); /* 文机 Markdown：# はすべて表題 */
    const noTitle = tops.some(n => n.type === 'html_block' && /^\s*<!--\s*表題なし\s*-->\s*$/.test(n.literal || ''));
    const titleMode = !OPTS.fragment && !noTitle && (titleNote || (h1s.length === 1 && tops[0] === h1s[0]));
    const f = doc.format, TL = clamp(f.titleLevels | 0, 0, 8), SY = FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM);
    const symChars = SY.map(t => { const sp = FZ.levelSpec(t); return sp.type === 'sym' ? sp.s : null; }); const wrapPairs = SY.map(t => { const sp = FZ.levelSpec(t); return sp.type === 'wrap' ? sp : null; });
    const state = { curNum: -1, counters: [] }; GFM_NOTES = [];
    const emit = (segs, attrs) => { for (const sg of segs) if (sg) delete sg.fzNotes; const ln = { segs, attrs }; if (GFM_NOTES.length) { attrs.notes = [...(attrs.notes || []), ...GFM_NOTES]; GFM_NOTES = []; const ls = segs[segs.length - 1]; if (ls) { const t = ls.text.replace(/[ \t　]+$/, ''); if (t !== ls.text) { ls.marks = ls.marks.slice(0, t.length); ls.text = t; } } } if (state.pendBreak && !(segs.length === 1 && segs[0].text === '' && !attrs.figure && !attrs.hr)) { attrs.breakBefore = true; state.pendBreak = false; } if (state.pendAnchor && (attrs.style === 'title' || attrs.style === 'num' || attrs.style === 'sym')) { attrs.anchor = state.pendAnchor; state.pendAnchor = null; } if (state.pendPanels && (attrs.style === 'title' || attrs.style === 'num' || attrs.style === 'sym')) { attrs.panels = state.pendPanels.n; if (state.pendPanels.head) attrs.panelHead = state.pendPanels.head; if (state.pendPanels.link) attrs.panelLink = state.pendPanels.link; state.pendPanels = null; } lines.push(ln); return ln; };
    const blank = (ctx) => { const last = lines[lines.length - 1]; if (lines.length && !(last.segs.length === 1 && last.segs[0].text === '' && !last.attrs.list)) emit([FZ.newSeg(0, '')], ctx && ctx.quote ? { quote: ctx.quote } : {}); };
    /* ctx：quote（引用の深さ）、bullet（箇条書きの中：{level, kind}）、ordDepth（番号付きリストの入れ子の深さ）、curNum（直前の数字見出しのレベル、無ければ -1） */
    const ctxAttrs = (ctx, extra = {}) => { const a = { ...extra }; if (ctx.quote) a.quote = ctx.quote; if (ctx.bullet) a.list = { ...ctx.bullet }; return a; };
    const paraLines = (node, ctx, attrs) => { const segs = inlinesToSegs(node); const per = segs.length > 1 && segs.some(x => x.fzNotes); if (per) GFM_NOTES = []; /* 改行で分かれる段落：付箋はその印のある行に */ segs.forEach((sg, k) => { if (per) GFM_NOTES = sg.fzNotes || []; delete sg.fzNotes; const a = { ...attrs }; const wasNum = a.style === 'num'; if (k > 0 && a.list && a.list.kind !== 'cont') a.list = { kind: 'cont', level: a.list.level }; if (k > 0 && wasNum) { delete a.style; delete a.level; delete a.restart; a.indent = ctx.numIndent || 0; } if (k > 0 && !wasNum && !OPTS.brSplit) a.join = true; /* 改行（\・空白 2 つ）は段落・項目の中の改行 */ emit([sg], a); }); };
    const BOXY = t => t === 'table' || t === 'code_block' || t === 'html_block';
    const blockGap = (prev, n, parent, ctx) => {
      if (prev.type === 'heading' || prev._chart || (prev.type === 'html_block' && /^\s*<!--\s*(改頁|節[:：]|図版|表題|飾り|囲み|区画|工程表)/.test(prev.literal || ''))) return false; /* グラフにした表の後：図版は前の行に付いたので空けない */
      if (state.chartNote && prev === state.chartNode) return false;
      if (n.type === 'heading') return true;
      if (BOXY(prev.type)) return !ctx.quote;
      if (n.type === 'list' || BOXY(n.type) || prev.type === 'list') return false;
      if (prev.type === 'paragraph' && parent.type === 'block_quote') return false;
      return !!(n.pos && prev.pos && n.pos[0][0] > prev.pos[1][0] + 1);
    };
    const walkBlocks = (parent, ctx) => {
      const kids = parent.children; let prev = null;
      for (const n of kids) {
        /* ブロック間の空行：Markdown の空行は文法（区切り）であって見た目の空きではない。文机では次の所だけ 1 行空ける。
           見出しの後は空けない（見出し→本文・表・箇条書き）／本文・表・箇条書きの後の見出しの前は空ける／表・コードの後は空ける／本文→箇条書き・表は空けない／
           本文→本文は元に空行があれば空ける（段落の区切りが見えなくなるため） */
        if (prev && !ctx.inItem && blockGap(prev, n, parent, ctx)) blank(ctx);
        block(n, ctx, prev); prev = n;
      }
    };
    /* 見出し文字の先頭の番号（1. ／ 1.2 ／ （1） ／ 第1章）を外し、番号の値を返す */
    const stripNumber = segs => { const sg = segs[0]; if (!sg) return null; const m = sg.text.match(/^\s*(?:第(\d+)[章節条項]?|（(\d+)）|\((\d+)\)|(\d+(?:\.\d+)*)[.．)）]?)(?:[\s　]+|$)/); if (!m) return null; const num = m[1] || m[2] || m[3] || (m[4] ? m[4].split('.').pop() : null); const cut = m[0].length; sg.text = sg.text.slice(cut); sg.marks = sg.marks.slice(cut); if (sg.links) FZ.spliceLinks(sg, 0, cut, 0); return +num; };
    const numHeading = (segs, lv, ctx, extra, isHeading) => { // 数字見出し：レベル lv（0 始まり）。番号を数え、文字の先頭の番号と違えば再開。isHeading：# の見出し（番号付きリストの項目ではない）
      lv = clamp(lv, 0, 7); const c = state.counters; c.length = lv + 1; c[lv] = (c[lv] || 0) + 1; const a = ctxAttrs(ctx, { style: 'num', level: lv, ...extra }); delete a.list;
      let n = stripNumber(segs); if (n == null && segs[0]) { /* 数字以外の番号（Ⅰ・ア・① など）：体系のその段の形と合えば外す */ const S0 = FZ.normalizeScheme(f.scheme), t0 = segs[0].text; for (let k = 1; k <= 99; k++) { const mk = FZ.schemeMarker(S0, lv, k, c.slice(0, lv)).replace(/[ 　]+$/, ''); if (!mk || /^\d/.test(mk)) break; if (t0.startsWith(mk) && (t0.length === mk.length || /[\s　]/.test(t0[mk.length]))) { const cut = mk.length + (t0.slice(mk.length).match(/^[\s　]*/)[0].length); segs[0].text = t0.slice(cut); segs[0].marks = segs[0].marks.slice(cut); if (segs[0].links) FZ.spliceLinks(segs[0], 0, cut, 0); n = k; break; } } }
      if (n != null && n !== c[lv]) { a.restart = n > 1 ? n : true; c[lv] = n; }
      if (isHeading) state.curNum = lv; /* 題の太字は組版が付ける（K-1） */
      segs.forEach((sg, k) => emit([sg], k === 0 ? a : { ...ctxAttrs(ctx), indent: lv + 1 })); };
    const block = (n, ctx, prev) => {
      switch (n.type) {
        case 'heading': { const segs = inlinesToSegs(n); const text = segs.map(s => s.text).join('');
          if (state.pendDeco) { const dn = state.pendDeco; state.pendDeco = null; segs.forEach(sg => emit([sg], { ...ctxAttrs(ctx), deco: dn })); break; } /* 文機 Markdown：見出し飾りの行 */
          if (titleMode && n.level === 1) { const a = ctxAttrs(ctx, { style: 'title', align: 'center' }); delete a.list; if (!doc.title) doc.title = text; segs.forEach(sg => emit([sg], { ...a })); state.counters.length = 0; state.curNum = -1; break; }
          // 記号見出しの記号で始まる見出し → 記号見出し（レベルは記号の体系の位置）
          const first = [...text][0]; let si = first ? symChars.indexOf(first) : -1;
          // 囲み見出し：【題】 のように体系の対で囲まれていれば、その記号見出し（両端を外す）
          const wi = first ? wrapPairs.findIndex(w => w && w.open === first && text.endsWith(w.close) && [...text].length >= 2) : -1;
          if (wi >= 0) { const sg0 = segs[0], sgN = segs[segs.length - 1]; const cl = wrapPairs[wi].close; sgN.text = sgN.text.slice(0, sgN.text.length - cl.length); sgN.marks = sgN.marks.slice(0, sgN.text.length); if (sgN.links) FZ.syncLinks(sgN); sg0.text = sg0.text.slice(first.length); sg0.marks = sg0.marks.slice(first.length); if (sg0.links) FZ.spliceLinks(sg0, 0, first.length, 0); const a = ctxAttrs(ctx, { style: 'sym', level: wi }); delete a.list; segs.forEach(g => emit([g], { ...a })); break; }
          if (si >= 0) { const sg = segs[0]; const cut = text.match(/^.[\s　]*/)[0].length; sg.text = sg.text.slice(cut); sg.marks = sg.marks.slice(cut); if (sg.links) FZ.spliceLinks(sg, 0, cut, 0); const a = ctxAttrs(ctx, { style: 'sym', level: si }); delete a.list; segs.forEach(g => emit([g], { ...a })); break; }
          numHeading(segs, n.level - (titleMode ? 2 : 1), ctx, {}, true); break; }
        case 'paragraph': {
          { const only = n.firstChild && n.firstChild === n.lastChild && n.firstChild.type === 'image' ? n.firstChild : null; const alt = only ? (only.children || []).map(c => c.literal || '').join('') : ''; const am = alt.match(/^(図|表)\s*\d*[\s　]*(.*)$/);
            if (only && !ctx.inItem && (am || state.pendFig)) { /* 図版：画像だけの段落（直前の「図 1　題」の行は題に） */
              const isBlank = l => l && l.segs.length === 1 && l.segs[0].text === '' && Object.keys(l.attrs).every(k => k === 'quote'); while (isBlank(lines[lines.length - 1])) lines.pop();
              const last = lines[lines.length - 1]; const lt = last ? last.segs.map(sg => sg.text).join('') : ''; let title = am ? am[2].trim() : alt.trim(); const kind = (state.pendFig && state.pendFig.kind) || (am ? am[1] : '図');
              if (last && !last.attrs.style && !last.attrs.list && !last.attrs.cells && /^(図|表)\s*\d*[\s　]*/.test(lt) && lt.replace(/^(図|表)\s*\d*[\s　]*/, '').trim() === title) { lines.pop(); while (isBlank(lines[lines.length - 1])) lines.pop(); }
              if (!lines.length) emit([FZ.newSeg(0, '')], {}); const host = lines[lines.length - 1]; const pf = state.pendFig || {}; state.pendFig = null;
              (host.attrs.figs = host.attrs.figs || []).push({ id: pf.id || 'im' + (state.gn = (state.gn | 0) + 1), kind, title, file: String(only.destination || ''), ...FZ.figSize(pf) }); n._chart = true; break; } }
          if (ctx.ordered && !ctx.itemUsed) { const segs = inlinesToSegs(n); numHeading(segs, ctx.ordered.level, ctx, ctx.ordered.first && ctx.ordered.start != null ? {} : {}); if (ctx.ordered.first && ctx.ordered.start != null) { const ln = lines[lines.length - segs.length]; if (ln && ln.attrs.style === 'num') { ln.attrs.restart = ctx.ordered.start > 1 ? ctx.ordered.start : true; state.counters[ctx.ordered.level] = ctx.ordered.start; } } ctx.itemUsed = true; break; }
          const a = ctxAttrs(ctx); if (ctx.bullet && ctx.itemUsed) a.list = { kind: 'cont', level: ctx.bullet.level }; if (ctx.ordered && ctx.itemUsed) a.indent = ctx.ordered.level + 1; paraLines(n, ctx, a); if (ctx.inItem) ctx.itemUsed = true; break; }
        case 'code_block': { const info = (n.info || '').split(/\s+/)[0];
          /* Mermaid の流れ図 → 図ブロック */ if (/^mermaid$/i.test(info) && FZ.figureFromMermaid && !ctx.inItem) { const fig = FZ.figureFromMermaid(n.literal, FZ.geometry ? FZ.geometry(doc.format).bodyCols : cols); /* 1.0.14f 図は本文欄の幅で組む（資料の書式では図表欄を除く） */ if (fig) { emit([FZ.newSeg(0, '')], { figure: fig }); break; } }
          const body = n.literal.replace(/\n$/, '').split('\n'); for (const l of body) { const a = ctxAttrs(ctx, { code: info || true }); if (a.list) a.list = { kind: 'cont', level: a.list.level }; if (ctx.ordered) a.indent = ctx.ordered.level + 1; emit([FZ.newSeg(0, l.replace(/\t/g, '    '))], a); } if (ctx.inItem) ctx.itemUsed = true; break; }
        case 'html_block': { if (/^\s*<!--\s*グラフ[:：][\s\S]*-->\s*$/.test(n.literal) && FZ.chartFromNote) { state.chartNote = n.literal.trim(); state.chartNode = n; break; }
          { let mm; const lit = n.literal.trim(); if (/^<!--\s*改頁\s*-->$/.test(lit)) { state.pendBreak = true; break; } if ((mm = lit.match(/^<!--\s*節[:：]([A-Za-z0-9_-]+)\s*-->$/))) { state.pendAnchor = mm[1]; break; } if ((mm = lit.match(/^<!--\s*図版\s+(\S+)\s+(図|表)((?:\s+\S+)*?)\s*-->$/))) { const sz = {}; for (const t of mm[3].trim().split(/\s+/)) { const z = FZ.figSizeTok(/^\d+$/.test(t) ? t + '%' : t); if (z) Object.assign(sz, z); } state.pendFig = { id: mm[1], kind: mm[2], ...sz }; break; }
            if ((mm = lit.match(/^<!--\s*目次\s*(\{.*\})?\s*-->$/))) { let t = true; try { if (mm[1]) t = JSON.parse(mm[1]); } catch (e) { /* 既定の目次 */ } emit([FZ.newSeg(0, '')], ctx.quote ? { toc: t, quote: ctx.quote } : { toc: t }); break; }
            if ((mm = lit.match(/^<!--\s*飾り\s+(\S+)\s*-->$/))) { if (FZ.decoSpec && FZ.decoSpec(mm[1])) state.pendDeco = mm[1]; break; }
            if ((mm = lit.match(/^<!--\s*囲み(\s+題なし)?\s*-->$/))) { state.pendBox = { titled: !mm[1] }; break; }
            if ((mm = lit.match(/^<!--\s*付箋の中身\s*\n([\s\S]*?)\n?-->$/))) { try { const d2 = FZ.parse('#fzk 2\n---\n' + mm[1] + '\n'); state.notes = (state.notes || []).concat(d2.notes || []); } catch (e) { } break; }
            if ((mm = lit.match(/^<!--\s*工程表((?:\s+\S+)*)\s*-->$/))) { const g = { labels: 1, heads: 1 }; for (const tk of (mm[1] || '').trim().split(/\s+/).filter(Boolean)) { let q; if ((q = tk.match(/^列(\d+)$/))) g.labels = +q[1]; else if ((q = tk.match(/^見出し(\d+)$/))) g.heads = +q[1]; else if ((q = tk.match(/^基準(\d+(?:\.\d+)?)$/))) g.base = +q[1]; } state.pendGantt = g; break; }
            if ((mm = lit.match(/^<!--\s*区画\s+([2-6]|横|縦)(?:\s+(網|線|濃灰))?(?:\s+(矢印|三角))?\s*-->$/))) { state.pendPanels = { n: mm[1] === '横' ? 'h' : mm[1] === '縦' ? 'v' : +mm[1], head: mm[2] === '網' ? 'gray' : mm[2] === '線' ? 'line' : mm[2] === '濃灰' ? 'ink' : null, link: mm[3] === '矢印' ? 'arrow' : mm[3] === '三角' ? 'tri' : null }; break; } } /* 文机 Markdown の注記 */
          if (/^\s*<!--[\s\S]*-->\s*$/.test(n.literal)) break; for (const l of n.literal.split('\n')) { const a = ctxAttrs(ctx, { code: 'html' }); if (a.list) a.list = { kind: 'cont', level: a.list.level }; emit([FZ.newSeg(0, l)], a); } break; }
        case 'thematic_break': { emit([FZ.newSeg(0, '')], ctx.quote ? { hr: true, quote: ctx.quote } : { hr: true }); break; } // 区切り線は行の種類（K-6）
        case 'block_quote': { const box = state.pendBox && !ctx.quote && !ctx.inItem ? state.pendBox : null; state.pendBox = null; const s0 = lines.length;
          walkBlocks(n, { ...ctx, quote: (ctx.quote | 0) + 1 });
          if (box && lines.length > s0 && FZ.applyArticlePure) { for (let k = s0; k < lines.length; k++) delete lines[k].attrs.quote; if (box.titled) { const t0 = lines[s0]; for (const sg of t0.segs) sg.marks = sg.marks.map(m => m & ~M.BOLD); } FZ.applyArticlePure(doc, s0, lines.length - 1, box.titled); } /* 文机 Markdown：囲み記事に戻す */
          break; }
        case 'list': {
          const ordered = n.listData.type === 'ordered';
          /* 番号付きリスト → 番号付き箇条書き（1.0.10a.3。以前は数字見出しの段落レベルにしていた）。記号リストと同じ入れ子（レベル＝リストの深さ）。開始番号が 1 以外なら「再開N」 */
          const lv = ctx.bullet ? ctx.bullet.level + 1 : 0; let first = true;
          for (const it of n.children) { const item = { level: clamp(lv, 0, 7) }; if (ordered) item.kind = 'num'; else if (it.task) item.kind = it.checked ? 'done' : 'todo';
            const p0 = it.firstChild; if (!ordered && p0 && p0.type === 'paragraph' && p0.firstChild && p0.firstChild.type === 'text' && /^(?:→|⇒|->|=>)\s*/.test(p0.firstChild.literal)) { p0.firstChild.literal = p0.firstChild.literal.replace(/^(?:→|⇒|->|=>)\s*/, ''); item.kind = 'arrow'; }
            const ictx = { ...ctx, inItem: true, itemUsed: false, bullet: item, ordered: null }; const before = lines.length; walkBlocks(it, ictx); if (lines.length === before) emit([FZ.newSeg(0, '')], ctxAttrs(ictx));
            if (ordered && first && n.listData.start != null && n.listData.start !== 1 && lines[before]) lines[before].attrs.restart = n.listData.start; first = false; }
          break; }
        case 'table': {
          if (state.chartNote && prev === state.chartNode && !ctx.inItem) { /* グラフの注記の直後の表 → グラフ（直前の「図 1　題」の行は図版の題に） */
            const rows = n.children.map(r => r.children.map(c => inlinesToSegs(c).map(sg => sg.text).join(''))); const chart = FZ.chartFromNote(state.chartNote, rows); state.chartNote = null; state.chartNode = null;
            const isBlank = l => l && l.segs.length === 1 && l.segs[0].text === '' && Object.keys(l.attrs).every(k => k === 'quote');
            while (isBlank(lines[lines.length - 1])) lines.pop();
            let kind = '図', title = ''; const last = lines[lines.length - 1]; const lt = last ? last.segs.map(sg => sg.text).join('') : ''; const cm = last && !last.attrs.style && !last.attrs.list && !last.attrs.cells && lt.match(/^(図|表)\s*\d*[\s　]*(.*)$/);
            if (cm) { kind = cm[1]; title = cm[2].trim(); lines.pop(); while (isBlank(lines[lines.length - 1])) lines.pop(); }
            if (!lines.length) emit([FZ.newSeg(0, '')], {}); const host = lines[lines.length - 1]; const pf = state.pendFig || {}; state.pendFig = null; (host.attrs.figs = host.attrs.figs || []).push({ id: pf.id || 'gr' + (state.gn = (state.gn | 0) + 1), kind: pf.kind || kind, title, file: '', ...FZ.figSize(pf), chart });
            n._chart = true; break; }
          const maxC = Math.max(1, cols | 0); // 版面の字数より列が多い表：はみ出す列は最後の列に「／」でつないで入れる（黙って隣の列にくっつけない）
          const joinSegs = list => { const out = FZ.newSeg(0, ''); let text = ''; const marks = [], links = []; for (const sg of list) { if (!sg) continue; if (text) { text += '／'; marks.push(0); } const off = text.length; text += sg.text; for (let q = 0; q < sg.text.length; q++) marks.push(sg.marks[q] | 0); if (sg.links) for (const l of sg.links) links.push({ ...l, start: l.start + off, end: l.end + off }); } out.text = text; out.marks = marks; if (links.length) out.links = links; return out; };
          /* 1.0.12b セルの中の <br> は、同じ表の行の続き（行続き）の行に分ける */
          const rows = []; n.children.forEach((r, ri) => { const parts = r.children.map(c => inlinesToSegs(c).filter((sg, k) => k === 0 || sg.text)); const h = Math.max(1, ...parts.map(p => p.length)); for (let k = 0; k < h; k++) { const cs = parts.map(p => p[k] || FZ.newSeg(0, '')); const row = cs.length > maxC ? [...cs.slice(0, maxC - 1), joinSegs(cs.slice(maxC - 1))] : cs; row.crow = k > 0; row.head = ri === 0; rows.push(row); } }); const bounds = tableWidths(rows, cols); const nCols = bounds.length - 1; const start = lines.length;
          rows.forEach((r, ri) => { const segs = []; for (let c = 0; c < nCols; c++) { const sg = r[c] || FZ.newSeg(0, ''); sg.col = bounds[c]; if (r.head) for (let q = 0; q < sg.marks.length; q++) sg.marks[q] |= M.BOLD; segs.push(sg); } const a = { cells: true }; if (r.crow) a.crow = true; if (ri === 0 && state.pendGantt) { a.gantt = state.pendGantt; state.pendGantt = null; } const al = n.align.map(x => x || null); if (al.some(Boolean)) a.cellAlign = al.slice(0, nCols); emit(segs, a); });
          const end = lines.length - 1; FZ.applyTablePure ? FZ.applyTablePure(doc, start, end, bounds, 'grid', 'light', null) : null; break; }
        default: if (n.children) walkBlocks(n, ctx);
      }
    };
    walkBlocks(ast, { quote: 0, bullet: null, ordered: null, inItem: false });
    if (!lines.length || doc.rules.some(r => r.axis === 'h' && r.line >= lines.length)) lines.push(FZ.newLine());
    FZ.fitItems(doc);
    { const anchors = new Set(lines.map(l => l.attrs.anchor).filter(Boolean)); const figIds = new Set(lines.flatMap(l => (l.attrs.figs || []).map(fg => fg.id)));
      if (OPTS.refTargets) { for (const x of OPTS.refTargets.anchors || []) anchors.add(x); for (const x of OPTS.refTargets.figs || []) figIds.add(x); } /* 節だけ写して戻す時：範囲の外の節・図への参照も参照に戻す */ /* 文書の中へのリンク（#節-名札・#図-id）→ 参照の字 */
      const dec = u => { try { return decodeURIComponent(u); } catch (e) { return u; } };
      for (const ln of lines) for (const sg of ln.segs) { if (!sg.links || !sg.links.some(l => /^#(節|図)-/.test(dec(l.url)))) continue;
        const conv = []; for (const l of sg.links) { const mm = dec(l.url).match(/^#(節|図)-(.+)$/); const id = mm ? (mm[1] === '節' ? (anchors.has(mm[2]) ? '§' + mm[2] : null) : (figIds.has(mm[2]) ? mm[2] : null)) : null; if (id) conv.push({ l, id }); } if (!conv.length) continue; conv.sort((a, b) => a.l.start - b.l.start);
        const map = new Array(sg.text.length + 1); let text = '', marks = [], q = 0;
        for (const c of conv) { if (c.l.start < q) continue; for (; q < c.l.start; q++) { map[q] = text.length; text += sg.text[q]; marks.push(sg.marks[q] | 0); } const ch = FZ.refChar(doc, c.id); for (let k = c.l.start; k < c.l.end; k++) map[k] = text.length; text += ch; for (let k = 0; k < ch.length; k++) marks.push((sg.marks[c.l.start] | 0) & ~M.LINK); q = c.l.end; }
        for (; q < sg.text.length; q++) { map[q] = text.length; text += sg.text[q]; marks.push(sg.marks[q] | 0); } map[sg.text.length] = text.length;
        const rest = sg.links.filter(l => !conv.some(c => c.l === l)).map(l => ({ ...l, start: map[l.start], end: map[l.end] })).filter(l => l.end > l.start);
        sg.text = text; sg.marks = marks; if (rest.length) sg.links = rest; else delete sg.links; } }
    if (state.notes && state.notes.length) doc.notes = state.notes;
    return FZ.normalize(doc);
  };

  /* ---------- 書き出し ---------- */
  const isPunct = ch => !!ch && /[\p{P}\p{S}]/u.test(ch), isWs = ch => !ch || /\s/u.test(ch);
  /* 区切り記号で包んでよいか（左右の flanking 規則）：だめなら HTML タグに逃がす */
  function canDelim(before, first, last, after) { const leftOk = !isWs(first) && (!isPunct(first) || isWs(before) || isPunct(before)); const rightOk = !isWs(last) && (!isPunct(last) || isWs(after) || isPunct(after)); return leftOk && rightOk; }
  function escInline(t) { // 誤読される記号だけ最小限にエスケープ
    return t.replace(/[\\`*\[\]<&_~]/g, (c, k, s) => { if (c === '\\') return /[!-\/:-@\[-`{-~]/.test(s[k + 1] || '') ? '\\\\' : c; if (c === '_') { const b = s[k - 1] || '', a = s[k + 1] || ''; return /[A-Za-z0-9]/.test(b) && /[A-Za-z0-9]/.test(a) ? c : '\\_'; } if (c === '[') return s.indexOf(']', k) >= 0 ? '\\[' : c; if (c === ']') return c; if (c === '<') return /[A-Za-z\/!?]/.test(s[k + 1] || '') ? '\\<' : c; if (c === '&') return /^&#?\w+;/.test(s.slice(k)) ? '\\&' : c; if (c === '~') return s[k + 1] === '~' || s[k - 1] === '~' ? '\\~' : c; return '\\' + c; });
  }
  function codeSpan(t) { const runs = t.match(/`+/g) || []; const n = runs.reduce((m, r) => Math.max(m, r.length), 0) + 1; const f = '`'.repeat(n); const pad = /^`|`$/.test(t) || /^ .* $/.test(t) ? ' ' : ''; return f + pad + t + pad + f; }
  /* セグメント → インライン GFM */
  function segToGfm(seg, opts = {}) {
    const runs = FZ.runsOf(seg, null); let out = ''; const full = seg.text;
    runs.forEach((r, k) => {
      const mk = r.marks, start = runs.slice(0, k).reduce((t, x) => t + x.text.length, 0); const before = full[start - 1] || '', after = full[start + r.text.length] || '';
      let core = r.text; const lead = core.match(/^\s*/)[0], trail = core.match(/\s*$/)[0]; core = core.slice(lead.length, core.length - trail.length);
      if (!core) { out += r.text; return; }
      let s;
      if (mk & M.CODE) s = codeSpan(core); else s = escInline(core);
      const first = core[0], last = core[core.length - 1];
      const wrap = (d, tag) => { s = canDelim(before || lead, first, last, trail || after) ? d + s + d : `<${tag}>${s}</${tag}>`; };
      if ((mk & M.BOLD) && (mk & M.DOT)) { if (canDelim(before || lead, first, last, trail || after)) s = '***' + s + '***'; else s = `<strong><em>${s}</em></strong>`; } else if (mk & M.BOLD) wrap('**', 'strong'); else if (mk & M.DOT) wrap('*', 'em');
      if (mk & M.ANY_STRIKE) wrap('~~', 'del'); if (mk & M.ANY_UNDER) s = `<u>${s}</u>`; if (mk & M.SHADE) s = `<mark>${s}</mark>`; // 網掛け（見た目）は <mark>（K-5）
      if (mk & M.LINK) { const l = FZ.linkAt(seg, start); if (l) { const title = l.title ? ` "${l.title.replace(/"/g, '\\"')}"` : ''; const bare = core === l.url || core === l.url.replace(/^mailto:/, '') || l.url === 'http://' + core || l.url === 'https://' + core; s = l.image ? `![${core}](${l.url}${title})` : (bare ? (/^(?:https?:\/\/|mailto:)/.test(core) ? `<${core}>` : core) : `[${s}](${l.url}${title})`); } }
      out += lead + s + trail;
    });
    return out;
  }
  const BLOCK_TAGS = /^<\/?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul|script|pre|style|textarea)(?:\s|\/?>|$)/i;
  function escBlockStart(t) { return /^(?:[#>|]|[-+*]\s|[-+*]$|\d{1,9}[.)](?:\s|$)|```|~~~|[=-]+\s*$|<!|<\?)/.test(t) || BLOCK_TAGS.test(t) || /^<\/?[A-Za-z][A-Za-z0-9-]*(?:\s[^<>]*)?\/?>\s*$/.test(t) ? '\\' + t : t; }
  FZ.toGfm = function (doc, o = {}) { const fz = !!o.fz; doc = FZ.forExport(doc, { flow: true, refLinks: fz }); return FZ.withRuleIndex(doc, () => toGfmBody(doc, fz)); }; // o.fz：文机 Markdown（節の名札・参照のリンク・図版の注記。GFM としても読める） // 縦罫の索引の中で（表の判定を行ごとに速く）
  function toGfmBody(doc, fz) {
    const LN = FZ.listNumbering(doc).ord; const lastAt = []; // 番号付き箇条書きの番号、レベルごとの直前の項目の種類
    const f = doc.format, S = FZ.normalizeScheme(f.scheme), SY = FZ.normalizeScheme(f.symScheme, FZ.DEFAULT_SYM), TL = clamp(f.titleLevels | 0, 0, 8); const hasTitle = doc.lines.some(l => l.attrs.style === 'title');
    const hashes = depth => '#'.repeat(clamp(depth, 1, 6));
    const out = []; const counters = [], ordAt = []; let lastTitleDepth = hasTitle ? 1 : 0; let lastNumLevel = -1; const open = []; const olStack = []; // 箇条書きの入れ子：{ lv, ind }。olStack：番号付きリストの入れ子（段落レベルの数字見出し）
    const ancOf = lv => { const r = []; for (let k = 0; k < lv; k++) if (ordAt[k] != null) r.push(ordAt[k]); return r; };
    const stripBold = t => t.replace(/\*\*/g, '').replace(/^<strong>|<\/strong>$/g, '');
    const pushBlank = () => { if (out.length && out[out.length - 1] !== '') out.push(''); };
    const prefixOf = (a) => '> '.repeat(a.quote | 0);
    let i = 0; const n = doc.lines.length; let prevKind = null, prevQuote = 0; let tocLay = null, lastOuter = 0;
    /* 文机 Markdown：表題が 2 つ以上か、先頭に無い時は「# は表題」の注記を付ける（無いと # 1 つの見出しが数字見出しに読まれる） */
    const titleNote = fz && (() => { const ts = doc.lines.filter(l => l.attrs.style === 'title').length; if (!ts) return false; const first = doc.lines.find(l => l.segs.some(sg => sg.text.trim()) || l.attrs.toc || l.attrs.figure); return ts > 1 || !first || first.attrs.style !== 'title'; })();
    while (i < n) {
      const ln = doc.lines[i], a = ln.attrs; const q = prefixOf(a); const pq = prevQuote; prevQuote = a.quote | 0;
      const sep = () => { if ((a.quote | 0) && pq === (a.quote | 0)) { if (out[out.length - 1] !== q.trimEnd()) out.push(q.trimEnd()); } else pushBlank(); }; // 引用の中では > だけの行で区切る
      if ((a.style === 'title' || a.style === 'num' || a.style === 'sym') && (a.breakBefore || (fz && (a.anchor || a.panels)))) { sep(); if (a.breakBefore) out.push(q + '<!-- 改頁 -->'); if (fz && a.anchor) out.push(q + '<!-- 節:' + a.anchor + ' -->'); if (fz && a.panels) out.push(q + '<!-- 区画 ' + (a.panels === 'h' ? '横' : a.panels === 'v' ? '縦' : (a.panels | 0)) + (a.panelHead === 'gray' ? ' 網' : a.panelHead === 'line' ? ' 線' : a.panelHead === 'ink' ? ' 濃灰' : '') + (a.panelLink === 'arrow' ? ' 矢印' : a.panelLink === 'tri' ? ' 三角' : '') + ' -->'); prevKind = 'meta'; } /* 区画：子の節を横に並べる（文机 Markdown の注記） */ /* 見出しの前の改頁と節の名札（注記なので GFM の見た目は変わらない） */
      if (fz && a.figCap) { sep(); out.push(q + `<!-- 図版 ${a.figCap.id} ${a.figCap.kind} ${FZ.figSizeToks(a.figCap).join(' ') || '100%'} -->`); prevKind = 'meta'; }
      // 図
      if (a.figure) { sep(); out.push(q + '```mermaid', ...FZ.figureToMermaid(a.figure, f.cols).map(l => q + l), q + '```'); i++; prevKind = 'fig'; continue; }
      // グラフ → 種類の注記（HTML の注記）＋表。読み込むと注記と表からグラフに戻る
      if (a.chartOut && FZ.chartNote) { sep(); out.push(q + FZ.chartNote(a.chartOut)); FZ.chartToGrid(a.chartOut).forEach((r, k) => { out.push(q + '| ' + r.map(x => String(x).replace(/\|/g, '\\|')).join(' | ') + ' |'); if (k === 0) out.push(q + '|' + r.map((_, c) => c ? ' ---: ' : ' --- ').join('|') + '|'); }); i++; prevKind = 'table'; continue; }
      // 目次 → 入れ子の箇条書き（見出しの文字だけ。頁番号は Markdown に無い）
      if (a.toc && fz) { sep(); out.push(q + '<!-- 目次 ' + JSON.stringify(a.toc) + ' -->'); i++; prevKind = 'meta'; continue; } /* 文机 Markdown：目次は注記だけ（中身は見出しから組み直す） */
      if (a.toc) { sep(); if (!tocLay) tocLay = FZ.layout(doc); const es = (tocLay.tocs && tocLay.tocs[i]) || []; if (!es.length) out.push(q + '- （目次）'); for (const e of es) { const t = e.close ? e.marker + e.text + e.close : (e.marker ? e.marker + ' ' : '') + e.text; out.push(q + '  '.repeat(e.indent | 0) + '- ' + stripBold(segToGfm({ text: t, marks: new Array(t.length).fill(0) })).replace(/^(\d{1,9})([.)])/, '$1\\$2')); } /* 「1.」は項目の中の番号付きリストに読まれないよう . を逃がす */ i++; prevKind = 'list'; continue; }
      // 表
      if (FZ.inTable(doc, i)) { let b = i; while (b + 1 < n && FZ.inTable(doc, b + 1)) b++; sep(); { const G = doc.lines[i].attrs.gantt; if (G && fz) out.push(q + '<!-- 工程表 列' + (G.labels | 0) + ((G.heads | 0) > 1 ? ' 見出し' + G.heads : '') + (G.base != null ? ' 基準' + G.base : '') + ' -->'); } /* 文机 Markdown：工程表の印 */
        const rows = []; for (let k = i; k <= b; k++) { const cells = FZ.cellsAt(doc, k, f.cols); const texts = cells.map(c => doc.lines[k].segs.filter(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6).map(s => segToGfm(k === i ? { ...s, marks: s.marks.map(m => m & ~M.BOLD) } : s).replace(/\|/g, '\\|')).join('')).map(t => /^[ \t]*$/.test(t) ? '' : t); /* 1.0.15c 空白だけのセルは空に（読み戻して書いても同じ） */ if (texts.length && texts[texts.length - 1] === '' && cells[cells.length - 1].right === f.cols && cells.length > 1) texts.pop();
          const pr = rows[rows.length - 1]; if (doc.lines[k].attrs.crow && pr) { texts.forEach((t, c) => { if (t) pr.texts[c] = (pr.texts[c] || '') + (pr.texts[c] ? '<br>' : '') + t; }); continue; } /* 1.0.12b 行続きの行は、上の行のセルに <br> でつなぐ */ rows.push({ texts, align: doc.lines[k].attrs.cellAlign || [] }); }
        const nc = Math.max(...rows.map(r => r.texts.length)); const al = Array.from({ length: nc }, (_, c) => (rows.find(r => r.align[c]) || { align: [] }).align[c] || null);
        rows.forEach((r, k) => { const cells = Array.from({ length: nc }, (_, c) => r.texts[c] || ''); out.push(q + '| ' + cells.join(' | ') + ' |'); if (k === 0) out.push(q + '|' + al.map(x => x === 'center' ? ':---:' : x === 'right' ? '---:' : x === 'left' ? ':---' : '---').map(x => ' ' + x + ' ').join('|') + '|'); });
        i = b + 1; prevKind = 'table'; continue; }
      // 囲み記事 → 引用（題は太字）
      const am = FZ.articleMatch ? FZ.articleMatch(doc, i) : null;
      if (am && fz) { sep(); out.push(q + (am.titled ? '<!-- 囲み -->' : '<!-- 囲み 題なし -->')); let nn = 0, prevL = false; /* 文机 Markdown：行ごとに段落（行がつながらない）、箇条書きは箇条書きのまま、題なしの囲みも往復 */
        for (let k = i; k <= am.b; k++) { const L2 = doc.lines[k], la = L2.attrs.list; const t = L2.segs.map(s => segToGfm(s)).join('');
          if (k === i && am.titled) { out.push(q + '> ' + `**${t.replace(/\*\*/g, '')}**`); prevL = false; continue; }
          if (la && la.kind !== 'cont') { const kd = la.kind || 'item'; nn = kd === 'num' ? nn + 1 : 0; if (!prevL && k > i) out.push(q + '>'); out.push(q + '> ' + '  '.repeat(la.level | 0) + (kd === 'arrow' ? '- → ' : kd === 'todo' ? '- [ ] ' : kd === 'done' ? '- [x] ' : kd === 'num' ? nn + '. ' : '- ') + escBlockStart(t)); prevL = true; continue; }
          if (k > i) out.push(q + '>'); out.push(q + '> ' + escBlockStart(t)); prevL = false; nn = 0; }
        i = am.b + 1; prevKind = 'quote'; continue; }
      if (am) { sep(); for (let k = i; k <= am.b; k++) { const t = doc.lines[k].segs.map(s => segToGfm(s)).join(''); out.push(q + '> ' + (k === i ? `**${t.replace(/\*\*/g, '')}**` : escBlockStart(t))); } i = am.b + 1; prevKind = 'quote'; continue; }
      // コード：連続する行をまとめる
      if (a.code && !a.list) { let b = i; while (b + 1 < n && doc.lines[b + 1].attrs.code && !doc.lines[b + 1].attrs.list && (doc.lines[b + 1].attrs.quote | 0) === (a.quote | 0)) b++; sep(); const info = typeof a.code === 'string' && a.code !== 'html' ? a.code : (a.code === 'html' ? '' : ''); const body = doc.lines.slice(i, b + 1).map(l => l.segs.map(s => s.text).join(''));
        if (a.code === 'html') { out.push(...body.map(l => q + l)); } else { const fence = '`'.repeat(Math.max(3, ...body.map(l => ((l.match(/`+/g) || []).reduce((m, r) => Math.max(m, r.length), 0)) + 1))); out.push(q + fence + info, ...body.map(l => q + l), q + fence); }
        i = b + 1; prevKind = 'code'; continue; }
      // 区切り線（K-6）：行の種類としての区切り線だけを --- にする。手で引いた罫は Markdown に出さない
      if (a.hr) { sep(); out.push(q + '---'); i++; prevKind = 'hr'; continue; }
      const text = ln.segs.map(s => segToGfm(s)).join('') + (fz && a.notes && a.notes.length ? a.notes.map(id => ' <!-- 付箋 ' + id + ' -->').join('') : ''); /* 文机 Markdown：付箋の印（中身は末尾の注記） */
      // 表題
      if (a.style === 'title') { sep(); if (titleNote) out.push(q + '<!-- 表題 -->'); out.push(q + '# ' + stripBold(text).replace(/(\s)(#+)$/, '$1\\$2')); open.length = 0; counters.length = 0; ordAt.length = 0; lastNumLevel = -1; lastTitleDepth = 1; i++; prevKind = 'heading'; continue; }
      // 数字見出し：題のレベルは # ＋ 番号を焼く、段落レベルは番号付きリスト（入れ子はレベル差）
      if (a.style === 'num') { const lv = clamp(a.level | 0, 0, 7); if (a.restart) counters[lv] = (typeof a.restart === 'number' ? a.restart : 1) - 1; counters.length = lv + 1; counters[lv] = (counters[lv] || 0) + 1; ordAt.length = lv; const mk = FZ.schemeMarker(S, lv, counters[lv], ancOf(lv)).replace(/[ 　]+$/, ''); ordAt[lv] = counters[lv]; lastNumLevel = lv; open.length = 0;
        /* 数字見出しはどのレベルも # の見出し（番号を焼く）。段落レベルも見出しのまま往復する（1.0.10a.3：Markdown の番号付きリストは番号付き箇条書きと往復） */
        sep(); const depth = Math.min(6, (hasTitle ? 1 : 0) + lv + 1); if (lv < TL) lastTitleDepth = depth; out.push(q + hashes(depth) + ' ' + (mk ? mk + ' ' : '') + (lv < TL ? stripBold(text) : text).replace(/(\s)(#+)$/, '$1\\$2')); i++; prevKind = 'heading'; continue; }
      // 記号見出し：# の深さは直前の数字見出しの題の深さ ＋ レベル ＋ 1。記号を焼く
      if (a.style === 'sym') { const lv = clamp(a.level | 0, 0, 7); sep(); const mk = FZ.schemeMarker(SY, lv, 0).replace(/[ 　]+$/, ''); const cl = FZ.schemeClose(SY, lv); out.push(q + hashes(lastTitleDepth + lv + 1) + ' ' + (cl ? mk + stripBold(text) + cl : (mk ? mk + ' ' : '') + stripBold(text).replace(/(\s)(#+)$/, '$1\\$2'))); open.length = 0; i++; prevKind = 'heading'; continue; }
      // 項目：接頭辞は「外側の引用（項目を開いた時の引用の深さ） → 項目の字下げ → 内側の引用」の順（A-5）。項目の中の引用は項目の字下げの内側に出す
      if (a.list) {
        const lv = a.list.level | 0; const kind = a.list.kind || 'item'; const Q = a.quote | 0;
        const pre = (outer, ind) => '> '.repeat(outer) + ' '.repeat(ind) + '> '.repeat(Math.max(0, Q - outer)); const between = outer => ('> '.repeat(outer)).trimEnd(); // 項目の中の段落の区切り：外側の引用の > だけ（無ければ空行）
        if (kind === 'cont') { const e = [...open].reverse().find(o => o.lv === lv) || open[open.length - 1]; const ind = e ? e.ind : 0, outer = e ? Math.min(e.qd, Q) : Q; const qq = pre(outer, ind); lastOuter = outer;
          if (a.code) { let b = i; while (b + 1 < n && doc.lines[b + 1].attrs.code && doc.lines[b + 1].attrs.list && doc.lines[b + 1].attrs.list.kind === 'cont' && (doc.lines[b + 1].attrs.quote | 0) === Q) b++; const body = doc.lines.slice(i, b + 1).map(l => l.segs.map(s => s.text).join('')); out.push(between(outer), qq + '```' + (typeof a.code === 'string' ? a.code : ''), ...body.map(l => qq + l), qq + '```'); i = b + 1; prevKind = 'list'; continue; }
          if (a.join && prevKind === 'list' && out.length && out[out.length - 1].trim()) { out[out.length - 1] += '\\'; out.push(qq + escBlockStart(text)); i++; continue; } /* 項目の中の改行 → 改行（\） */
          out.push(between(outer), qq + escBlockStart(text)); i++; prevKind = 'list'; continue; }
        while (open.length && open[open.length - 1].lv >= lv) open.pop(); const parent = open[open.length - 1]; const ind = parent ? parent.ind : 0; const outer = parent ? Math.min(parent.qd, Q) : Q;
        if (prevKind !== 'list' && prevKind !== null) sep(); else if (prevKind === 'list' && !parent && lastOuter !== outer) pushBlank(); // 外側の引用の深さが変わる最上位の項目は空行で切る
        lastOuter = outer;
        const mk = kind === 'arrow' ? '- → ' : kind === 'todo' ? '- [ ] ' : kind === 'done' ? '- [x] ' : kind === 'num' ? LN[i] + '. ' : '- ';
        if (kind === 'num' && LN[i] !== 1 && !(lastAt[lv] === 'num') && out.length && out[out.length - 1] !== '') pushBlank(); // 1 以外で始まる番号付きリストは段落を割り込めない（GFM）ので前に空行
        lastAt.length = lv; lastAt[lv] = kind === 'num' ? 'num' : 'b';
        open.push({ lv, ind: ind + (kind === 'num' ? mk.length : 2) + 2 * Math.max(0, Q - outer), qd: Q }); out.push(pre(outer, ind) + mk + escBlockStart(text)); i++; prevKind = 'list'; continue;
      }
      // 見出し飾りの名前を持つ行（新聞風の見出し）→ 記号見出しと同じ深さの # 見出し（A-13／K-3）。飾り・太字・倍角は落とす
      if (!a.style && !a.list && !a.cells && text !== '' && a.deco && FZ.decoSpec(a.deco) && FZ.decoSpec(a.deco).heading) { // 見出し飾りの名前を持つ行だけ（K-3：見た目から推測しない）
        sep(); const plain = ln.segs.map(sg => segToGfm({ ...sg, marks: sg.marks.map(m => m & ~(M.BOLD | FZ.SIZE_BITS | M.OUTLINE | M.SHADE | M.SHT | M.SHADOW)) })).join('');
        if (fz) out.push(q + '<!-- 飾り ' + a.deco + ' -->'); /* 文机 Markdown：読み戻すと見出し飾りの行に（数字見出しにしない） */
        out.push(q + hashes(lastTitleDepth + 1) + ' ' + stripBold(plain).replace(/(\s)(#+)$/, '$1\\$2')); open.length = 0; i++; prevKind = 'heading'; continue; }
      // 空行（引用の中の空行は > だけの行）
      if (text === '' && ln.segs.length === 1) { if (a.quote) { if (out[out.length - 1] !== q.trimEnd()) out.push(q.trimEnd()); } else pushBlank(); i++; if (prevKind !== 'list') prevKind = 'blank'; continue; } // 空行は空きだけ：箇条書きの入れ子を切らない（K-2）。リストの中の空行はゆるいリストになるだけ
      // 段落
      if (a.join && prevKind === 'para' && out.length && out[out.length - 1].trim()) { out[out.length - 1] += '\\'; out.push(q + escBlockStart(text)); i++; continue; } /* 段落の中の改行（Shift+Enter）→ 改行（\） */
      if (prevKind !== null && prevKind !== 'blank') sep();
      if (a.breakBefore) { out.push(q + '<!-- 改頁 -->'); sep(); }
      out.push(q + escBlockStart(text)); i++; prevKind = 'para';
    }
    while (out.length && out[out.length - 1] === '') out.pop(); while (out.length && out[0] === '') out.shift();
    if (fz) { const nl = FZ.notesLines(doc); if (nl.length) out.push('', '<!-- 付箋の中身', ...nl.map(l => l.replace(/--/g, '－－')), '-->'); } /* 文机 Markdown：付箋の中身（AI に渡す写しにも。指示として読める） */
    if (fz && !hasTitle && out.some(l => /^(> )*# /.test(l))) out.unshift('<!-- 表題なし -->', ''); /* 文机 Markdown：題の無い文書（節だけ写した時など）の # は表題ではない */
    return out.join('\n') + '\n';
  };
  // 旧名
  FZ.fromMarkdown = FZ.fromGfm; FZ.toMarkdown = FZ.toGfm;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
