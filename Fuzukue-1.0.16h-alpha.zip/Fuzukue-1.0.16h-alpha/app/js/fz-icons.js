/* 文机 メニューのピクトグラム（16×16、線画。白黒の画面で読める太さ。色は currentColor）
 * 文字の修飾は「あ」に飾りを付けた見本、段落・配置は行の形、挿入はものの形で描く。
 * クラス：f＝塗り、g＝薄い塗り、tb＝太字の文字、to＝白抜きの文字、mi／go＝明朝／ゴシック */
(function (FZ) {
'use strict';
const A = (extra = '', size = 13, y = 12.6, x = 8, cls = '') => `<text x="${x}" y="${y}" font-size="${size}" text-anchor="middle"${cls ? ` class="${cls}"` : ''}>あ</text>${extra}`;
const T = (s, x, y, size, cls = '', anchor = 'middle') => `<text x="${x}" y="${y}" font-size="${size}" text-anchor="${anchor}"${cls ? ` class="${cls}"` : ''}>${s}</text>`;
const LINES4 = (xs) => `<path d="M${xs[0]} 3h${xs[1]}M${xs[2]} 6.3h${xs[3]}M${xs[4]} 9.6h${xs[5]}M${xs[6]} 13h${xs[7]}"/>`;
const PAGE = '<path d="M3 1.5h7l3 3v10H3z"/><path d="M10 1.5v3h3"/>';
const MAG = '<circle cx="6.8" cy="6.8" r="4.3"/><path d="M10 10l4.5 4.5"/>';
const TRAY = '<path d="M2 10.5v3.5h12v-3.5"/>';
const I = {
  // ---- ファイル ----
  new: PAGE + '<path d="M8 7.5v5M5.5 10h5"/>',
  open: '<path d="M1.5 13V3.5h4l1.5 1.5h6v2"/><path d="M1.5 13l2.2-6h11l-2.2 6z"/>',
  save: '<path d="M2 2h9.5L14 4.5V14H2z"/><path d="M5 2v4h6V2M4.5 14V9.5h7V14"/>',
  saveAs: '<path d="M7 14H2V2h8.5L12.5 4v3"/><path d="M4.5 2v3.5h5V2"/><path d="M9 14.5l.5-2.2 4-4 1.7 1.7-4 4z"/>',
  print: '<path d="M4 6V1.5h8V6"/><rect x="1.5" y="6" width="13" height="5.5" rx="1"/><path d="M4 9.5h8v5H4z"/>',
  word: '<path d="M3 1.5h7l3 3v10H3z"/>' + T('W', 8, 12.6, 7.5, 'tb'),
  pptx: '<rect x="1.5" y="3" width="13" height="10" rx=".8"/>' + T('P', 8, 11, 7.5, 'tb'),
  md: '<rect x="1" y="3.5" width="14" height="9" rx="1.2"/><path d="M3.5 10.5v-5l2 2.5 2-2.5v5M11.5 5.5v5M9.8 8.8l1.7 1.7 1.7-1.7"/>',
  txt: PAGE + '<path d="M5.5 7.5h5M5.5 10h5M5.5 12.5h3"/>',
  pufu: '<path d="M9.5 1.5h5v3.5h-5zM5 6h5v3.5H5zM1.5 10.5h5V14h-5z"/><path d="M10 7.75h2.25V5M6.5 12.25h2V9.5"/>', /* プ譜：右上ほど上位、段ごとに左下へ */
  pufuMark: '<path d="M1.5 3h13M4.5 6.5h8.5M7.5 10h4M1.5 13.5h13"/><path d="M14.5 3v3.5h-1.5M13 6.5v3.5h-1.5"/>', /* この節をプ譜に：右端の段差 */
  pfWin: '<path d="M4 14.5V2"/><path d="M4 2.5h8l-2 3 2 3H4"/>', /* 1.0.16g 勝利条件：旗 */
  pfMid: '<rect x="2" y="4.5" width="12" height="7"/><path d="M5 8h6"/>', /* 中間目的：状態の箱 */
  pfAct: '<path d="M1.5 8h10"/><path d="M8.5 4.5L12 8l-3.5 3.5"/><path d="M14.5 3v10"/>', /* 施策：行動の矢 */
  pfStep: '<path d="M2 4.5h3M2 8h3M2 11.5h3"/><path d="M7 4.5h7M7 8h7M7 11.5h7"/>', /* 段取り：手順の並び */
  pfOut: '<path d="M3.5 1.5h6l3 3v10h-9z"/><path d="M9.5 1.5v3h3M5.5 8h5M5.5 10.5h5"/>', /* 成果物：書類 */
  pufuFrame: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M1.5 5.5h13"/><path d="M4 8.5h7M4 11h5"/>', /* 枠：帯の付いた囲み */
  pufuRes: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M1.5 5.5h13M8 5.5v8M1.5 9.5h13"/>', /* 資源と制約：2 列の表 */
  pufuPhase: '<path d="M4 3.5h8v11H4z"/><path d="M6.5 1.5h7.5v11"/><path d="M6 7h4M6 9.5h4M6 12h2.5"/>', /* 局面を記録：重ねた紙 */
  pufuCmp: '<path d="M1.5 2.5h5.5v11H1.5zM9 2.5h5.5v11H9z"/><path d="M3 5.5h2.5M3 8h2.5M10.5 5.5h2.5M10.5 8h2.5" /><path d="M10 10.5h3.5" stroke-width="2.2"/>', /* 局面と比べる：左右の紙と太い印 */
  pufuNote: '<path d="M2 2.5h12v8H7l-3 3v-3H2z" stroke-dasharray="2 1.2"/><path d="M4.5 5.5h7M4.5 8h5"/>', /* 気づき：点線の吹き出し */
  html: '<rect x="1" y="2.5" width="14" height="11" rx="1.2"/><path d="M1 5.5h14M5.5 8l-2 2 2 2M10.5 8l2 2-2 2"/>',
  pdf: PAGE + '<path d="M5 8.5h1.6a1.1 1.1 0 0 1 0 2.2H5V8.5v4.5M9 8.5v4.5h.8a1.6 1.6 0 0 0 1.6-1.6v-1.3A1.6 1.6 0 0 0 9.8 8.5z"/>',
  newWin: '<rect x="1.5" y="4" width="10" height="9.5" rx=".8"/><path d="M1.5 6.5h10"/><path d="M13 1v4.5M10.8 3.2h4.5"/>',
  tpl: '<path d="M3 1.5h10v13H3z"/><path d="M5 4h6v3H5z" class="g"/><path d="M5 9.5h6M5 12h4"/>',
  cfgOut: TRAY + '<path d="M8 10V2M5 5l3-3 3 3"/>',
  cfgIn: TRAY + '<path d="M8 2v8M5 7l3 3 3-3"/>',
  // ---- 編集 ----
  undo: '<path d="M5 3 2 6l3 3"/><path d="M2.5 6H10a4 4 0 0 1 0 8H6"/>',
  redo: '<path d="M11 3l3 3-3 3"/><path d="M13.5 6H6a4 4 0 0 0 0 8h4"/>',
  find: MAG,
  selAll: '<rect x="2" y="2" width="12" height="12" stroke-dasharray="2 1.5"/><path d="M5 6h6M5 8.5h6M5 11h4"/>',
  pasteMd: '<path d="M5 2.5H3v12h10v-12h-2"/><rect x="5" y="1.5" width="6" height="2.5" rx=".6"/><path d="M5 12V7.5l1.5 1.8L8 7.5V12M10.8 7.5V12M9.6 10.8l1.2 1.2 1.2-1.2"/>',
  stars: T('**', 5.5, 13, 10) + '<path d="M9 6.5h2.5M10.5 5l1.5 1.5L10.5 8"/>' + T('B', 12.5, 15, 6.5, 'tb'),
  jaLift: T('１', 4.5, 12.5, 9.5) + '<circle cx="8.6" cy="11.8" r=".8" class="f"/><path d="M10.5 6.5h4M10.5 10h4"/>',
  // ---- 文字 ----
  bold: A('', 13, 12.6, 8, 'tb'),
  under: A('<path d="M2 15h12"/>', 12, 11.6),
  dot: A('<circle cx="8" cy="2" r="1.1" class="f"/>', 11.5, 14),
  shade: '<rect x="1.5" y="2" width="13" height="12.5" class="g"/>' + A(),
  outline: A('', 13.5, 12.8, 8, 'to'),
  strike: A('<path d="M1.5 8.3h13"/>'),
  under2: A('<path d="M2 13.3h12M2 15.3h12"/>', 11, 10.8),
  wave: A('<path d="M1.5 14.5q1.6-1.8 3.2 0t3.2 0 3.2 0 3.2 0"/>', 11.5, 11.4),
  strike2: A('<path d="M1.5 7.2h13M1.5 9.6h13"/>'),
  codeSpan: '<path d="M5.5 4 2 8l3.5 4M10.5 4 14 8l-3.5 4"/>',
  wide: '<text font-size="9.5" text-anchor="middle" transform="translate(8 11.8) scale(1.6 1)">あ</text>',
  tall: '<text font-size="9.5" text-anchor="middle" transform="translate(8 14.2) scale(.72 1.45)">あ</text>',
  quad: A('', 15.5, 14.6, 8, 'tb'),
  clearMarks: A('<path d="M10.5 10.5l4 4M14.5 10.5l-4 4"/>', 11, 10.5, 6.5),
  link: '<path d="M6.5 9.5l3-3M5.3 7.6 3.9 9a2.4 2.4 0 0 0 3.4 3.4l1.4-1.4M10.7 8.4l1.4-1.4a2.4 2.4 0 0 0-3.4-3.4L7.3 5"/>',
  figRef: '<rect x="1" y="3" width="14" height="10" rx="1.5"/>' + T('図1', 8, 10.8, 7.5),
  // ---- 段落 ----
  body: '<path d="M2 3.5h12M2 6.5h12M2 9.5h12M2 12.5h8"/>',
  title: '<path d="M3.5 4.5h9" stroke-width="2.8"/><path d="M2 9h12M2 12.5h12"/>',
  numHead: T('1', 4, 11.8, 11, 'tb') + '<path d="M8.5 7.8h6" stroke-width="2.6"/>',
  symHead: '<rect x="1.5" y="5" width="5" height="5" class="f"/><path d="M9 7.5h5.5" stroke-width="2.6"/>',
  bullet: '<circle cx="3" cy="4.5" r="1.3" class="f"/><circle cx="3" cy="11.5" r="1.3" class="f"/><path d="M6.5 4.5h7.5M6.5 11.5h7.5"/>',
  numItem: T('1', 3, 7.2, 7.5) + T('2', 3, 14.2, 7.5) + '<path d="M6.5 4.5h7.5M6.5 11.5h7.5"/>',
  arrow: '<path d="M2 8h10.5M8.5 4 12.5 8l-4 4"/>',
  todo: '<rect x="1.5" y="2" width="5" height="5"/><path d="M1.8 11.3l1.8 1.8 3.2-3.4"/><path d="M9 4.5h5.5M9 11.5h5.5"/>',
  indent: '<path d="M6.5 3h7.5M6.5 8h7.5M6.5 13h7.5M1.5 5.5 4 8l-2.5 2.5"/>',
  outdent: '<path d="M6.5 3h7.5M6.5 8h7.5M6.5 13h7.5M4 5.5 1.5 8 4 10.5"/>',
  child: '<path d="M3 2v9h3.5M3 6h3.5"/><path d="M9 6h5.5M9 11h5.5"/>',
  restart: '<path d="M12.6 9a4.8 4.8 0 1 1-1.4-4.6M11.6 1.6v3h-3"/>' + T('1', 7.6, 11.3, 7),
  quote: '<path d="M3 2.5v11" stroke-width="2.4"/><path d="M6.5 4.5h7.5M6.5 8h7.5M6.5 11.5h5"/>',
  codeBlock: '<rect x="1.5" y="2.5" width="13" height="11" rx="1" class="g"/><path d="M6 5.5 4 8l2 2.5M10 5.5 12 8l-2 2.5"/>',
  speech: '<path d="M1.5 2.5h7v5H5L3 9.5v-2H1.5z"/><path d="M10.5 4h4M10.5 7h4M1.5 12.5h13"/>',
  // ---- 配置 ----
  alignL: LINES4([2, 12, 2, 8, 2, 12, 2, 8]),
  alignC: LINES4([2, 12, 4, 8, 2, 12, 4, 8]),
  alignR: LINES4([2, 12, 6, 8, 2, 12, 6, 8]),
  alignJ: LINES4([2, 12, 2, 12, 2, 12, 2, 12]),
  posLeft: '<path d="M2 2.5v11"/><path d="M13.5 8H5.5M8.5 5 5.5 8l3 3"/>',
  posRight: '<path d="M2 2.5v11" opacity=".45"/><path d="M3.5 8h8M8.5 5l3 3-3 3"/><path d="M14 2.5v11"/>',
  posAuto: T('A', 4, 12.3, 10.5, 'tb') + '<path d="M9 4h5.5M9 8h5.5M9 12h5.5"/>',
  pageBreak: '<path d="M3 1.5v4.3h10V1.5M3 14.5v-4.3h10v4.3"/><path d="M1.5 8h13" stroke-dasharray="2 1.6"/>',
  keepLine: '<path d="M3.5 2.5H2v11h1.5M12.5 2.5H14v11h-1.5"/><path d="M4.5 5h7M4.5 8h7M4.5 11h7"/>',
  keepNext: '<rect x="2" y="1.5" width="12" height="4.5" rx=".8"/><rect x="2" y="10" width="12" height="4.5" rx=".8"/><path d="M6.5 6v4M9.5 6v4"/>',
  // ---- 挿入 ----
  image: '<rect x="1.5" y="2.5" width="13" height="11" rx="1"/><path d="M2 12.5l3.8-4.2 3 3 2-2 3.7 3.7"/><circle cx="11" cy="5.8" r="1.3"/>',
  chart: '<path d="M1.5 14.5h13"/><rect x="2.6" y="8.5" width="2.6" height="6"/><rect x="6.7" y="4.5" width="2.6" height="10"/><rect x="10.8" y="2" width="2.6" height="12.5"/>',
  figEdit: '<rect x="2" y="1.5" width="12" height="8" rx="1"/><path d="M2.5 8.5l3-3 2.5 2.5 2-2 3.5 3.5"/><path d="M3.5 12.5h9M5.5 15h5"/>',
  flow: '<rect x="1.5" y="1.5" width="6" height="4.5" rx=".8"/><rect x="8.5" y="10" width="6" height="4.5" rx=".8"/><path d="M4.5 6v6.2h3.8"/><path d="M6.8 10.5l1.7 1.7-1.7 1.7"/>',
  table: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M1.5 6.2h13M1.5 9.8h13M6 2.5v11M10.5 2.5v11"/>',
  noteAdd: '<path d="M2.5 2.5h9l2 2v9h-11z"/><path d="M5 6.5h6M5 9h4"/><path class="f" d="M11.5 2.5v2h2z"/>',
  noteList: '<path d="M2.5 3.5h11M2.5 8h11M2.5 12.5h11"/><path class="f" d="M12 2h2.5v3H12zM12 6.5h2.5v3H12z"/>',
  gantt: '<path d="M1.5 2v12" stroke-width=".9"/><path class="f" d="M3 3.2h5l1.4 1.3L8 5.8H3z"/><path class="f" d="M6 7.2h6l1.4 1.3L12 9.8H6z"/><path class="f" d="M11.5 11l1.6 1.6-1.6 1.6-1.6-1.6z"/>',
  hr: '<path d="M1.5 8h13" stroke-width="1.9"/><path d="M3.5 3.5h9M3.5 12.5h9" opacity=".45"/>',
  sepDia: '<path d="M8 4.5 11.5 8 8 11.5 4.5 8z"/><path d="M1 8h2M13 8h2"/>',
  treeView: '<rect x="1" y="6" width="4" height="4"/><rect x="11" y="1.5" width="4" height="3.5"/><rect x="11" y="6.25" width="4" height="3.5"/><rect x="11" y="11" width="4" height="3.5"/><path d="M5 8h3M8 3.25V12.75M8 3.25h3M8 8h3M8 12.75h3"/>',
  sxOut: '<path d="M7 3h7M7 8h7M7 13h7"/><path d="M5 8H1.5M3.2 6 1.2 8l2 2"/>',
  sxIn: '<path d="M7 3h7M7 8h7M7 13h7"/><path d="M1.2 8h3.6M3 6l2 2-2 2"/>',
  reSplit: '<rect x="1.5" y="1.5" width="13" height="13" rx=".8" stroke-dasharray="1.6 1.4"/><path d="M4 5h8M4 8h8M4 11h6"/>',
  reList: '<circle cx="3" cy="4" r=".9"/><circle cx="3" cy="8" r=".9"/><circle cx="3" cy="12" r=".9"/><path d="M6 4h8M6 8h8M6 12h8"/>',
  reTree: '<path d="M2 3h7M5 8h9M5 13h9M3 4v9h2M3 8h2"/>',
  reMerge: '<rect x="1.5" y="1.5" width="13" height="13" rx=".8"/><path d="M4 5h8M4 8h8M4 11h6"/>',
  sentSel: '<path d="M1.5 8h13" stroke-width="3" stroke-opacity=".35"/><path d="M2 5.5v5M14 5.5v5"/>',
  aiSec: '<rect x="4" y="1.5" width="10" height="12" rx="1"/><path d="M2 4v10.5h9"/><path d="M6.5 5h5M6.5 8h5M6.5 11h3"/>',
  panels: '<rect x="1" y="3" width="4" height="10"/><rect x="6" y="3" width="4" height="10"/><rect x="11" y="3" width="4" height="10"/><path class="f" d="M1 3h4v2.5H1zM6 3h4v2.5H6zM11 3h4v2.5h-4z"/>',
  aiBack: '<rect x="6.5" y="1.5" width="8" height="12" rx="1"/><path d="M1 8h7.5M5.5 5l3 3-3 3"/><path d="M9 4.5h3.5M10.5 11h2"/>',
  aiDoc: '<rect x="4" y="1.5" width="10" height="12" rx="1"/><path d="M2 4v10.5h9"/><path d="M6.5 4.5h5M6.5 6.8h5M6.5 9.1h5M6.5 11.4h5"/>',
  tShapeI: '<path d="M2 2.5h6M4.5 6h6M4.5 9.5h6M7 13h6M3 3v10h4M3 6h1.5M3 9.5h1.5"/>',
  tShapeH: '<rect x="1" y="6.5" width="4" height="3"/><rect x="11" y="2" width="4" height="3"/><rect x="11" y="11" width="4" height="3"/><path d="M5 8h3v-4.5h3M8 8v4.5h3"/>',
  tShapeV: '<rect x="6" y="1" width="4" height="3"/><rect x="1.5" y="11" width="4" height="3"/><rect x="10.5" y="11" width="4" height="3"/><path d="M8 4v3.5H3.5V11M8 7.5h4.5V11"/>',
  grpMore: '<circle cx="3.5" cy="8" r="1.2"/><circle cx="8" cy="8" r="1.2"/><circle cx="12.5" cy="8" r="1.2"/>',
  moveTo: '<rect x="1.5" y="2" width="6" height="4" rx=".6"/><path d="M4.5 6v5.5H11"/><path d="M9.5 9.8l1.8 1.7-1.8 1.7"/><rect x="11.5" y="9.5" width="3" height="4" rx=".6" stroke-dasharray="1.2 1"/>',
  check: '<path d="M2 8.5l3 3 6.5-7"/><path d="M12 11v3M12 9v.5" stroke-width="1.6"/>',
  secRef: '<path d="M2 3.5h5M2 7h3.5"/><path d="M8.5 10.5h-6"/><rect x="9" y="2" width="5.5" height="5" rx=".6"/><path d="M11.7 7v4.5H8.5" /><path d="M10 10l-1.5 1.5L10 13"/>',
  skeleton: '<rect x="1.5" y="1.5" width="13" height="13" rx="1"/><path d="M4 4.5h6M5.5 7h6M5.5 9.5h6M4 12h6" stroke-dasharray="1.6 1.2"/>',
  park: '<path d="M2 12.5c2-1.5 4-1.5 6 0s4 1.5 6 0"/><rect x="5" y="2" width="6" height="5" rx=".7"/><path d="M8 7v3M6.5 8.7 8 10.2l1.5-1.5"/>',
  parkList: '<path d="M2 13c2-1.5 4-1.5 6 0s4 1.5 6 0"/><path d="M4 3h8M4 6h8M4 9h5"/>',
  tSib: '<rect x="3" y="1.5" width="10" height="5"/><rect x="3" y="9.5" width="10" height="5" class="g"/><path d="M8 7v2"/>',
  tChild: '<rect x="1" y="5.5" width="6" height="5"/><rect x="10" y="5.5" width="5" height="5" class="g"/><path d="M7 8h3"/>',
  tUp: '<rect x="3" y="8" width="10" height="6"/><path d="M8 7V1.5M5.5 4L8 1.5 10.5 4"/>',
  tDown: '<rect x="3" y="2" width="10" height="6"/><path d="M8 9v5.5M5.5 12L8 14.5 10.5 12"/>',
  tDepth1: '<path d="M2 4h12M2 10h12"/><path d="M2 14h12" stroke-dasharray="1 2"/>',
  tDepth2: '<path d="M2 3h12M5 7h9M2 11h12M5 15h9"/>',
  tDepth3: '<path d="M2 3h12M5 7h9M8 11h6M8 15h6"/>',
  tDepth4: '<path d="M1 2h13M4 6h10M7 10h7M10 14h4"/>',
  tDepthA: '<path d="M1 2h14M3 5h12M5 8h10M7 11h8M9 14h6"/>',
  tDepthB: '<path d="M1 3h14"/><path d="M3 7h11M3 10h11M3 13h7" stroke-dasharray="1.2 1.2"/>',
  tDepthS: '<path d="M1 3h14"/><path d="M3 7h4M9 7h5M3 10h3M8 10h6M3 13h6"/><circle cx="7.5" cy="7" r=".6"/><circle cx="6.6" cy="10" r=".6"/>',
  tFold: '<rect x="2" y="4" width="8" height="8"/><path d="M4.5 8h3M12 6v4M10 8h4"/>',
  slideNew: '<rect x="1.5" y="3" width="13" height="9.5"/><path d="M1.5 5.5h13M4 8h5M4 10h3M8 12.5v2M5.5 14.5h5"/>',
  done: '<rect x="2" y="2.5" width="11" height="11" rx="1"/><path d="M4.5 8l2.5 2.5 5.5-6"/>',
  rowAbove: '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="2" y="2" width="12" height="4" class="g"/><path d="M1.5 6h13M1.5 10.25h13M8 2.7v2.6M6.7 4h2.6"/>',
  rowBelow: '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="2" y="10" width="12" height="4" class="g"/><path d="M1.5 5.75h13M1.5 10h13M8 10.7v2.6M6.7 12h2.6"/>',
  rowDel: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M1.5 5.5h13M1.5 10.5h13M5.5 6.6l5 2.8M10.5 6.6l-5 2.8"/>',
  colLeft: '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="2" y="2" width="4" height="12" class="g"/><path d="M6 1.5v13M10.25 1.5v13M4 6.7v2.6M2.7 8h2.6"/>',
  colRight: '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="10" y="2" width="4" height="12" class="g"/><path d="M5.75 1.5v13M10 1.5v13M12 6.7v2.6M10.7 8h2.6"/>',
  colDel: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M5.5 1.5v13M10.5 1.5v13M6.6 5.5l2.8 5M9.4 5.5l-2.8 5"/>',
  cellMerge: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M1.5 8h13M8 1.5v3M8 11.5v3M3.5 5.5h9" class="d"/><rect x="2" y="2" width="12" height="5.5" class="g"/><path d="M4.5 4.75h7M10 3.3l1.5 1.45L10 6.2M6 3.3L4.5 4.75 6 6.2"/>',
  cellSplit: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M1.5 8h13M8 1.5v13"/><path d="M3 4.75h3.5M13 4.75H9.5M5 3.3L3 4.75l2 1.45M11 3.3l2 1.45-2 1.45"/>',
  colEqual: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M5.83 1.5v13M10.17 1.5v13M2.6 11.5h2.2M7 11.5h2M11.2 11.5h2.2"/>',
  colFit: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M7 1.5v13M3 6h2.6M3 8h1.8M8.5 6h4M8.5 8h3M5.4 11l1.4 1.2L5.4 13.4M9.4 11L8 12.2l1.4 1.2"/>',
  moveL: '<rect x="6.5" y="3.5" width="8" height="9"/><path d="M1.5 8h4M3.5 6l-2 2 2 2"/>',
  moveR: '<rect x="1.5" y="3.5" width="8" height="9"/><path d="M14.5 8h-4M12.5 6l2 2-2 2"/>',
  moveU: '<rect x="3.5" y="6.5" width="9" height="8"/><path d="M8 1.5v4M6 3.5l2-2 2 2"/>',
  moveD: '<rect x="3.5" y="1.5" width="9" height="8"/><path d="M8 14.5v-4M6 12.5l2 2 2-2"/>',
  clearCell: '<rect x="1.5" y="3.5" width="13" height="9"/><path d="M5.5 6l5 4M10.5 6l-5 4"/>',
  tableDel: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M1.5 6.5h13M6 2.5v11M8.5 8l4 4M12.5 8l-4 4"/>',
  figAdd: '<rect x="1.5" y="5.5" width="9" height="7"/><path d="M13 1.5v5M10.5 4h5"/>',
  figConnect: '<rect x="1" y="2" width="5.5" height="4"/><rect x="9.5" y="10" width="5.5" height="4"/><path d="M3.75 6v6h4.5M7 10.5l1.5 1.5L7 13.5"/>',
  figDup: '<rect x="1.5" y="1.5" width="8.5" height="6.5"/><path d="M5.5 8v6.5h9V5.5H10"/>',
  tools: '<path d="M2 6h12v8H2z"/><path d="M6 6V4h4v2"/><path d="M2 9.5h12"/><path d="M7 9.5v1.5h2V9.5"/>', /* 1.0.15f 道具箱 */
  focus: '<rect x="2" y="1.5" width="12" height="13"/><path d="M4 4h8M4 6h8" stroke-opacity=".35"/><path d="M4 8.5h8M4 10.5h8" stroke-width="1.6"/><path d="M4 13h8" stroke-opacity=".35"/>', /* 1.0.15e 集中の表示 */
  pageMap: '<rect x="3" y="1.5" width="8" height="13"/><rect class="f" x="12" y="1.5" width="2" height="13"/><path d="M3 6h8M3 10.5h8"/>', /* 頁の地図 */
  compare: '<path d="M1.5 2.5h5.5v11H1.5zM9 2.5h5.5v11H9z"/><path d="M3 5.5h2.5M3 8h2.5M10.5 5.5h2.5M10.5 8h2.5M7 9.5h2M8.2 8.3l1 1.2-1 1.2"/>', /* 文書と比べる */
  tblSum: '<rect x="1.5" y="2" width="13" height="12"/><path d="M1.5 5.5h13M1.5 9h13M1.5 10.5h13M6 2v12"/>' + T('Σ', 10.3, 13.6, 4.6, 'tb'), /* 1.0.15d 合計の行：二重線の下 */
  numRight: '<rect x="1.5" y="2" width="13" height="12"/><path d="M8 2v12M9.5 5h3.5M10.5 8h2.5M9 11h4"/>', /* 数の列を右揃え */
  symbols: T('※', 5, 8, 7.5) + T('○', 11.5, 8, 6.5) + T('→', 5, 14.5, 6.5) + T('◆', 11.5, 14.5, 6), /* 記号の引出 */
  drawer: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M1.5 8h13M6.5 5.3h3M6.5 10.8h3"/>', /* 引き出し欄 */
  snippet: '<path d="M3 2h7l3 3v9H3z"/><path d="M5.5 7h5M5.5 9.5h5M5.5 12h3"/><path d="M10 2v3h3"/>',
  ask: '<path d="M2.5 3h9v6.5H6.5L4 12V9.5H2.5z"/><path d="M10.5 7.5l3.5 3.5M14 8.5v2.5h-2.5"/>', /* 1.0.16b AI に頼む */
  review: '<path d="M2.5 2.5h7.5v11H2.5z"/><path d="M4.5 5h3.5M4.5 7.5h2"/><circle cx="10.8" cy="10.2" r="2.5"/><path d="M12.6 12l1.9 1.9"/>', /* 1.0.16a 下読み */
  health: '<path d="M3 2.5h10v11H3z"/><path d="M5.5 6l1.5 1.5L10.5 4M5.5 10.5h5"/><circle class="f" cx="12.5" cy="12.5" r="2.3"/>', /* 1.0.15b 健康診断 */
  care: '<path d="M2.5 2.5h9l2 2v9h-11z"/><path d="M5 6.5h6M5 9h4"/><circle class="f" cx="12.5" cy="12.5" r="2.5"/>', /* 1.0.15a 手当て（刷られない印） */
  convLog: '<rect x="1.5" y="2.5" width="5" height="11"/><rect x="9.5" y="2.5" width="5" height="11"/><path d="M6.5 6h3M8 4.5L9.5 6 8 7.5M6.5 10.5h3"/>', /* 1.0.15a 写しの見通し */
  figCompact: '<rect x="4.5" y="1.5" width="7" height="3"/><rect x="4.5" y="11.5" width="7" height="3"/><path d="M8 4.5v7M1.5 8h3M11.5 8h3M3 6.5l1.5 1.5L3 9.5M13 6.5L11.5 8 13 9.5"/>', /* 1.0.14f 図を詰める */
  figText: '<rect x="1.5" y="2.5" width="13" height="11"/><path d="M5 5.5h6M8 5.5v6"/>',
  figDel: '<rect x="2.5" y="3.5" width="11" height="9"/><path d="M5.5 6l5 4M10.5 6l-5 4"/>',
  lanes: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M1.5 6h13M1.5 10.25h13M4.5 1.5v13"/>',
  taller: '<rect x="3.5" y="5" width="9" height="6"/><path d="M8 .8v3M6.5 2.3L8 .8l1.5 1.5M8 15.2v-3M6.5 13.7L8 15.2l1.5-1.5"/>',
  shorter: '<rect x="3.5" y="5" width="9" height="6"/><path d="M8 .8v3M6.5 2.3L8 3.8l1.5-1.5M8 15.2v-3M6.5 13.7L8 12.2l1.5 1.5"/>',
  ln_thin: '<path d="M1.5 8h13"/>',
  ln_thick: '<path d="M1.5 8h13" stroke-width="3.2"/>',
  ln_double: '<path d="M1.5 6h13M1.5 10h13"/>',
  ln_dotted: '<path d="M1.5 8h13" stroke-dasharray="1.5 1.8"/>',
  al_left: '<path d="M2 1.5v13"/><rect x="2" y="3.5" width="9" height="3"/><rect x="2" y="9.5" width="6" height="3"/>',
  al_center: '<path d="M8 1.5v13"/><rect x="3.5" y="3.5" width="9" height="3"/><rect x="5" y="9.5" width="6" height="3"/>',
  al_right: '<path d="M14 1.5v13"/><rect x="5" y="3.5" width="9" height="3"/><rect x="8" y="9.5" width="6" height="3"/>',
  al_top: '<path d="M1.5 2h13"/><rect x="3.5" y="2" width="3" height="9"/><rect x="9.5" y="2" width="3" height="6"/>',
  al_middle: '<path d="M1.5 8h13"/><rect x="3.5" y="3.5" width="3" height="9"/><rect x="9.5" y="5" width="3" height="6"/>',
  al_bottom: '<path d="M1.5 14h13"/><rect x="3.5" y="5" width="3" height="9"/><rect x="9.5" y="8" width="3" height="6"/>',
  al_dh: '<rect x="1" y="5" width="3" height="6"/><rect x="6.5" y="5" width="3" height="6"/><rect x="12" y="5" width="3" height="6"/><path d="M4 2.5h2.5M9.5 2.5H12"/>',
  al_dv: '<rect x="5" y="1" width="6" height="3"/><rect x="5" y="6.5" width="6" height="3"/><rect x="5" y="12" width="6" height="3"/><path d="M2.5 4v2.5M2.5 9.5V12"/>',
  articleN: '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M4 5.5h8M4 8.5h8M4 11.5h6"/>',
  article: '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="1.5" y="1.5" width="13" height="4" class="f"/><path d="M4 8.5h8M4 11.5h8"/>',
  toc: '<path d="M2 3.5h5M2 8h4M2 12.5h5"/><path d="M8.5 3.5h3M7.5 8h4M8.5 12.5h3" stroke-dasharray=".2 1.6"/><path d="M13.8 2.5v2M13.8 7v2M13.8 11.5v2"/>',
  // ---- 罫線・飾り ----
  ruleDraw: '<path d="M1.5 14.5h7"/><path d="M10.5 2l3 3L7 11.5H4v-3z"/>',
  fill: '<rect x="2" y="2" width="12" height="12"/><path d="M2 8l6-6M2 14 14 2M8 14l6-6"/>',
  rect: '<rect x="2.5" y="3" width="11" height="10"/><circle cx="2.5" cy="3" r="1.4" class="f"/><circle cx="13.5" cy="13" r="1.4" class="f"/>',
  headDeco: '<rect x="1.5" y="2.5" width="13" height="6" class="f"/><path d="M1.5 11.5h13M1.5 14h13"/>',
  tableStyle: '<path d="M1.5 3h13M1.5 13h13" stroke-width="2.2"/><path d="M1.5 6.5h13M1.5 9.8h13M6 3v10M10.5 3v10" stroke-width=".9"/>',
  // ---- 書式 ----
  page: '<rect x="3" y="1.5" width="10" height="13" rx=".8"/><path d="M5.5 4.5h5M5.5 7h5M5.5 9.5h5M5.5 12h3"/><path d="M1.5 1.5v13" stroke-dasharray="1 1.3" opacity=".6"/>',
  landscape: '<rect x="1.5" y="5.5" width="10.5" height="8" rx=".8"/><path d="M8.5 2.5a5 5 0 0 1 5.5 4.5"/><path d="M12.2 5.6 14 7l1-2"/>',
  mincho: T('明', 8, 13, 13, 'mi'),
  gothic: T('ゴ', 8, 13, 13, 'go'),
  scheme: '<path d="M1.5 3.5h2.5M4 8h2.5M6.5 12.5H9" stroke-width="2.4"/><path d="M5.5 3.5h9M8 8h6.5M10.5 12.5h4"/>',
  slideHead: '<rect x="1.5" y="3" width="13" height="10" rx=".8"/><path d="M1.5 6.2h13"/><path d="M3.5 4.6h4.5" stroke-width="1.6"/><path d="M8 9h4.5M8 11h3" opacity=".6"/><rect x="3.5" y="8.2" width="3" height="3" class="g"/>',
  date: '<rect x="2" y="3" width="12" height="11" rx="1"/><path d="M2 6.5h12M5 1.5v3M11 1.5v3"/><path d="M4.8 9.5h1.5M8 9.5h1.5M11 9.5h.5M4.8 12h1.5"/>',
  // ---- 表示 ----
  zoomIn: MAG + '<path d="M4.8 6.8h4M6.8 4.8v4"/>',
  zoomOut: MAG + '<path d="M4.8 6.8h4"/>',
  zoomFit: '<path d="M1.5 3v10M14.5 3v10"/><path d="M4 8h8M6 6 4 8l2 2M10 6l2 2-2 2"/>',
  zoomPage: '<path d="M3 1.5h10M3 14.5h10"/><path d="M8 4v8M6 6l2-2 2 2M6 10l2 2 2-2"/>',
  zoomPct: T('%', 8, 12.5, 11),
  grid: '<path d="M2 2h12v12H2zM6 2v12M10 2v12M2 6h12M2 10h12" stroke-dasharray="1 1.3"/>',
  outlineView: '<path d="M2 3h7M4.5 8h7M7 13h7"/><path d="M2.6 4.5v3.5h1M5.1 9.5v3.5h1" opacity=".6"/>',
  palette: '<rect x="1.5" y="2" width="13" height="12" rx="1"/><path d="M4 5.5l2.2 2.2L4 9.9M7.8 10.5h4"/>',
  history: '<circle cx="8.5" cy="8.5" r="5.8"/><path d="M8.5 5.4v3.3l2.2 1.4M1.6 4.2l1.5 2.4 2.5-1.3"/>',
  split: '<path d="M3 8.2V1.8h7l3 3v3.4"/><path d="M3 12v2.2h10V12"/><path d="M1.5 10.2h13" stroke-dasharray="1.6 1.2"/>',
  romaji: '<text x="0.6" y="11.6" font-size="8.2">a</text><path d="M6.3 8.5h3.4M8.4 6.8l1.6 1.7-1.6 1.7"/><text x="9.6" y="12.6" font-size="7.4">あ</text>',
  count: '<rect x="1.8" y="2" width="12.4" height="12" rx="1"/><path d="M4.4 5.6h1.6v5.2M4.4 10.8h3.2M9 6.2a1.4 1.4 0 0 1 2.6.6c0 1.4-2.6 2.4-2.6 4h2.8"/>',
  insertFile: '<path d="M4 1.8h5.4l3 3v9.4H4z"/><path d="M9.4 1.8v3h3"/><path d="M6.2 9.6h4M8.2 7.6v4"/>',
  shadeType: '<rect x="1.8" y="1.8" width="12.4" height="12.4" rx="1"/><path d="M1.8 7.6l5.8-5.8M1.8 12.4l10.6-10.6M5.4 14.2l8.8-8.8M10.2 14.2l4-4"/>',
  shadow: '<text x="3.2" y="13.2" font-size="11" class="tb" style="fill:currentColor">影</text><text x="1.8" y="11.8" font-size="11" class="to">影</text>',
  scale: '<path d="M2 14h5.2V8.8H2zM8.8 7.2H14V2"/><path d="M8.8 2H14v5.2" /><path d="M7.6 8.4L13.6 2.4"/><path d="M2 6V2h4"/>',
  manual: '<path d="M8 4.2C6.6 3.1 4.4 2.8 1.8 3.2v9.6c2.6-.4 4.8-.1 6.2 1 1.4-1.1 3.6-1.4 6.2-1V3.2c-2.6-.4-4.8-.1-6.2 1zM8 4.2v9.6"/><path d="M3.8 6h2.4M3.8 8.2h2.4M9.8 6h2.4M9.8 8.2h2.4"/>',
  help: '<circle cx="8" cy="8" r="6.5"/><path d="M6 6.2a2 2 0 1 1 2.8 1.8c-.6.3-.8.7-.8 1.3v.5"/><circle cx="8" cy="11.8" r=".8" class="f"/>',
  back: '<path d="M10 3 5 8l5 5"/>',
  // ---- 見出し飾り（見出しの見本） ----
  'hd:sub': '<path d="M2 6h9" stroke-width="2.6"/><path d="M2 10.5h12M2 13.5h12" opacity=".5"/>',
  'hd:h': '<path d="M1.5 7h13" stroke-width="3.2"/><path d="M1.5 12h13" opacity=".5"/>',
  'hd:big': '<path d="M1.5 6.5h13" stroke-width="5.5"/><path d="M1.5 13h13" opacity=".5"/>',
  'hd:beta': '<rect x="1" y="3" width="14" height="7" class="f"/><path d="M1.5 13h13" opacity=".5"/>',
  'hd:beta2': '<rect x="1" y="1.5" width="14" height="10" class="f"/><path d="M1.5 14h13" opacity=".5"/>',
  'hd:shade': '<rect x="1" y="3" width="14" height="7" class="g"/><path d="M3 6.5h8" stroke-width="2.4"/>',
  'hd:hatch': '<rect x="1" y="3" width="14" height="7"/><path d="M1 7l4-4M4 10l7-7M9 10l6-6M13 10l2-2"/>',
  'hd:dots': '<rect x="1" y="3" width="14" height="7"/><path d="M3 5h.1M6 5h.1M9 5h.1M12 5h.1M4.5 8h.1M7.5 8h.1M10.5 8h.1M13.5 8h.1" stroke-width="1.6"/>',
  'hd:box': '<rect x="1.5" y="3" width="13" height="7"/><path d="M4 6.5h8" stroke-width="2"/>',
  'hd:clear': '<path d="M2 6.5h8" stroke-width="2.4"/><path d="M10.5 10.5l4 4M14.5 10.5l-4 4"/>',
  'hd:under': '<path d="M2 5.5h12" stroke-width="2.2"/><path d="M1 9h14" stroke-width="2.4"/>',
  'hd:under2': '<path d="M2 5h12" stroke-width="2.2"/><path d="M1 9h14M1 11.5h14"/>',
  'hd:outline': '<text x="8" y="12.6" font-size="13" text-anchor="middle" class="to">見</text>',
  'hd:chidori': '<path d="M1.5 3h7M3 7.5h11.5M7 12h7.5" stroke-width="2"/>',
  'hd:lead': '<path d="M3.5 3.5h10.5M3.5 6.5h10.5M3.5 9.5h10.5" stroke-width="1.8"/><path d="M1.5 13h12.5" opacity=".5"/>',
  'hd:sep': '<path d="M8 4.5 11.5 8 8 11.5 4.5 8z"/>',
  'hd:articleN': '<rect x="1.5" y="1.5" width="13" height="13"/><path d="M4 5.5h8M4 8.5h8M4 11.5h6"/>',
  'hd:article': '<rect x="1.5" y="1.5" width="13" height="13"/><rect x="1.5" y="1.5" width="13" height="4" class="f"/><path d="M4 8.5h8M4 11.5h8"/>',
  // ---- 表の様式 ----
  'tb:grid': '<rect x="1.5" y="2.5" width="13" height="11"/><rect x="1.5" y="2.5" width="13" height="3.5" class="g"/><path d="M1.5 6h13M1.5 9.8h13M6 2.5v11M10.5 2.5v11"/>',
  'tb:news': '<rect x="1.5" y="2.5" width="13" height="3.5" class="f"/><path d="M1.5 13.5h13" stroke-width="2"/><path d="M1.5 9.8h13"/>',
  'tb:stat': '<path d="M1.5 2.5h13M1.5 13.5h13" stroke-width="2"/><path d="M1.5 5.8h13M1.5 10.8h13"/>',
  'tb:fin': '<rect x="1.5" y="2.5" width="13" height="3.5" class="f"/><path d="M1.5 13.5h13" stroke-width="2"/><path d="M1.5 9.8h13" stroke-dasharray="1 1.2"/>',
  'tb:compare': '<rect x="1.5" y="2.5" width="13" height="11" stroke-width="2"/><rect x="1.5" y="2.5" width="4.5" height="11" class="g"/><path d="M1.5 6h13M1.5 9.8h13M6 2.5v11M10.5 2.5v11" stroke-width=".9"/>',
  'tb:box': '<rect x="1.5" y="2.5" width="13" height="11" stroke-width="2"/><path d="M1.5 6.2h13M1.5 9.8h13" stroke-width=".9"/>',
  'tb:bare': '<path d="M1.5 5.5h13"/><path d="M3 3h3M10 3h3M3 8.5h3M10 8.5h3M3 11.5h3M10 11.5h3" opacity=".6"/>',
  'to:numRight': '<path d="M2 3.5h12M2 12.5h12" opacity=".5"/>' + T('123', 14.5, 10.5, 7, '', 'end'),
  'to:alignL': '<path d="M2 3.5h12M2 12.5h12" opacity=".5"/><path d="M2.5 8h6"/><path d="M11 6l3 4M14 6l-3 4"/>',
  'to:headFill': '<rect x="1.5" y="2.5" width="13" height="4" class="f"/><path d="M1.5 9.5h13M1.5 13h13"/>',
  'to:unit': T('単位', 14.5, 8.5, 6.5, '', 'end') + '<path d="M1.5 11h13M1.5 14h13"/>',
  'to:note': '<path d="M1.5 2.5h13M1.5 6h13"/>' + T('注', 4, 14, 7.5),
  'to:tri': T('▲', 8, 11.5, 9),
  'to:repeat': '<rect x="1.5" y="1.5" width="8" height="2.5" class="f"/><rect x="1.5" y="9.5" width="8" height="2.5" class="f"/><path d="M1.5 6h8M1.5 14.5h8"/><path d="M12.5 3v8.5M10.8 9.8l1.7 1.7 1.7-1.7"/>',
  'to:headBold': '<path d="M1.5 4.5h13" stroke-width="2.8"/><path d="M1.5 9h13M1.5 12.5h13"/>',
};
/* <svg class="ic"> を返す。名前が無ければ空（文字だけのタイル） */
FZ.icon = name => I[name] ? `<svg class="ic" viewBox="0 0 16 16" aria-hidden="true">${I[name]}</svg>` : '';
FZ.ICON_NAMES = Object.keys(I);
})(window.FZ = window.FZ || {});
