/* 文机 — 戻ってきた文書との差分（X3：AI からの戻し、C1：版の比較の土台）
 * 行の署名（行の種類＋段＋文字。参照の字は参照先の名札に開いて比べる）で最長共通部分列を取り、食い違う所を「塊（hunk）」にする。
 * 空行は見た目の空きなので比べない（Markdown を通ると空行は揃わない）。
 * 塊 = { rem: [今の文書で消す行の番号…], at: 入れる位置, b: [b0, b1)（戻ってきた文書の行）, kind: 'add'|'del'|'chg', key }。取り込みは塊ごと（行の入れ替え） */
(function (FZ) {
  'use strict';
  const REF_G = /[\u{F0000}-\u{FFFFD}]/gu;
  const kindKey = a => a.style === 'title' ? 'T' : a.style === 'num' ? 'N' + (a.level | 0) : a.style === 'sym' ? 'S' + (a.level | 0) : a.list ? 'L' + (a.list.level | 0) + (a.list.kind || '') : a.cells ? 'C' : a.figure ? 'F' : a.hr ? 'H' : a.toc ? 'O' : '';
  const refIds = (doc, t) => t.replace(REF_G, ch => '⟦' + (FZ.refId(doc, ch) ?? '?') + '⟧'); /* 番号は範囲で変わる（節だけ写すと図 3 が図 1 に）ので、参照先で比べる */
  FZ.lineSig = function (doc, ln) { const t = ln.segs.map(sg => refIds(doc, sg.text)).join('\t').replace(/[ 　]+/g, ' ').trim(); const figs = (ln.attrs.figs || []).map(fg => fg.kind + (fg.title || '') + (fg.chart ? JSON.stringify([fg.chart.type, fg.chart.cats, fg.chart.series.map(s => [s.name, s.values])]) : fg.file)).join('|'); return kindKey(ln.attrs) + '|' + t + (figs ? '|' + figs : ''); };
  /* 署名の列 A・B → 塊の列（A・B の位置で） */
  FZ.diffSigs = function (A, B) { const n = A.length, m = B.length;
    let p = 0; while (p < n && p < m && A[p] === B[p]) p++; let q = 0; while (q < n - p && q < m - p && A[n - 1 - q] === B[m - 1 - q]) q++; /* 頭と尻の同じ所は先に除く */
    const a = A.slice(p, n - q), b = B.slice(p, m - q); const N = a.length, Mx = b.length; const pairs = [];
    if (N && Mx && N * Mx <= 2e7) { const W = Mx + 1; const L = Math.min(N, Mx) < 65535 ? new Uint16Array((N + 1) * W) : new Uint32Array((N + 1) * W); /* 大きすぎる時は真ん中を塊 1 つに */
      for (let i = N - 1; i >= 0; i--) for (let j = Mx - 1; j >= 0; j--) L[i * W + j] = a[i] === b[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
      let i = 0, j = 0; while (i < N && j < Mx) { if (a[i] === b[j]) { pairs.push([i, j]); i++; j++; } else if (L[(i + 1) * W + j] >= L[i * W + j + 1]) i++; else j++; } }
    const hunks = []; let ai = 0, bj = 0; const push = (a0, a1, b0, b1) => { if (a1 > a0 || b1 > b0) hunks.push({ a: [p + a0, p + a1], b: [p + b0, p + b1], kind: a1 === a0 ? 'add' : b1 === b0 ? 'del' : 'chg' }); };
    for (const [i, j] of pairs) { push(ai, i, bj, j); ai = i + 1; bj = j + 1; } push(ai, N, bj, Mx);
    return hunks; };
  /* P04：見えにくい違い。行の署名（種類＋字）が同じでも、リンク先と強調（太字・傍点・下線・取消線・網掛け・コード）が違えば違いとして出す。
     見出し・飾りのある行・表の太字は組版が付ける（Markdown にも出ない）ので比べない。比べないもの：FZ.DIFF_SKIP */
  const MM0 = FZ.M || {}; const EMPH = ((MM0.BOLD | MM0.DOT | MM0.ANY_UNDER | MM0.ANY_STRIKE | MM0.SHADE | MM0.CODE) >>> 0);
  const emphNorm = (m, noBold) => { let v = ((m | 0) & EMPH) >>> 0; if (v & MM0.ANY_UNDER) v = (v & ~MM0.ANY_UNDER) | MM0.UNDER; if (v & MM0.ANY_STRIKE) v = (v & ~MM0.ANY_STRIKE) | MM0.STRIKE; if (noBold) v &= ~MM0.BOLD; return v >>> 0; };
  FZ.DIFF_SKIP = '字の大きさ・倍角・白抜き・影・網の文様・行の位置と揃え・罫・図の中の細部';
  FZ.lineDetail = function (doc, ln) { const noBold = !!(ln.attrs.style || ln.attrs.deco || ln.attrs.cells); const links = [], emph = [];
    for (const sg of ln.segs) { for (const l of (sg.links || []).slice().sort((x, y) => x.start - y.start)) links.push(sg.text.slice(l.start, l.end).trim() + '>' + l.url);
      const t = sg.text; let v0 = 0, s0 = 0; for (let i = 0; i <= t.length; i++) { const v = i < t.length ? emphNorm(sg.marks[i], noBold) : 0; if (v !== v0) { if (v0) { const w = t.slice(s0, i).replace(/[ 　]+/g, ' ').trim(); if (w) emph.push(v0 + ':' + w); } v0 = v; s0 = i; } } }
    /* 行全体の太字は組版が付けるもの（囲みの題・表の見出しの行・見出し）が多く、Markdown を通ると落ちる：ゆるい比べ（emphLoose）では行全体の太字を見ない */
    const full = ln.segs.map(sg => sg.text).join(' ').replace(/[ 　]+/g, ' ').trim(); const loose = emph.map(x => { const k = x.indexOf(':'); let v = +x.slice(0, k); const w = x.slice(k + 1); if (w === full) v &= ~MM0.BOLD; return v ? v + ':' + w : ''; }).filter(Boolean);
    return { link: links.join('\u0002'), emph: emph.join('\u0002'), emphLoose: loose.join('\u0002') }; };
  const kindOf = s => s.slice(0, s.indexOf('|')), textOf = s => s.slice(s.indexOf('|') + 1), stripRefs = t => t.replace(/⟦[^⟧]*⟧/g, '⟦⟧');
  const headish = s => /^[TNS]/.test(kindOf(s));
  /* 塊の分類：本文（字）・構造（種類・段・見出しの出入り）・リンク・参照（リンク先・参照先） */
  FZ.hunkCats = function (SA, SB) { const c = new Set();
    for (const op of FZ.alignLines(SA, SB)) { if (op.t !== 'p') { const s = op.t === 'd' ? SA[op.i] : SB[op.j]; c.add(headish(s) ? 'struct' : 'body'); if (headish(s) && textOf(s).trim()) c.add('body'); continue; }
      const a = SA[op.i], b = SB[op.j]; if (kindOf(a) !== kindOf(b)) c.add('struct'); if (textOf(a) !== textOf(b)) c.add(stripRefs(textOf(a)) === stripRefs(textOf(b)) ? 'link' : 'body'); }
    if (!c.size) c.add('body'); return [...c]; };
  /* 文書 A の行（番号の列 idx。範囲の外の行は見ない）と文書 B 全体を比べる。sigA・sigB は前もって作った署名（無ければ作る）。
     塊には分類 cats（body・struct・link・emph）。字が同じでリンク先・強調だけ違う行も、1 行の塊（kind 'chg'、detail）として出す。
     opts.exact：行全体の太字も比べる（版の履歴など、Markdown を通らない比べ） */
  FZ.diffDocs = function (A, idx, B, sigA, sigB, opts = {}) { sigA = sigA || A.lines.map(l => FZ.lineSig(A, l)); sigB = sigB || B.lines.map(l => FZ.lineSig(B, l));
    const SA = [], PA = []; idx.forEach((li, pos) => { const s = sigA[li]; if (s !== '|') { SA.push(s); PA.push(pos); } });
    const SB = [], PB = []; sigB.forEach((s, k) => { if (s !== '|') { SB.push(s); PB.push(k); } });
    const raw = FZ.diffSigs(SA, SB);
    const out = raw.map(h => { let rem, at;
      if (h.a[1] > h.a[0]) { rem = idx.slice(PA[h.a[0]], PA[h.a[1] - 1] + 1); at = rem[0]; } /* 中の空行も一緒に（範囲の外の行は含めない） */
      else { rem = []; at = h.a[0] > 0 ? idx[PA[h.a[0] - 1]] + 1 : (idx.length ? idx[0] : 0); }
      const b = h.b[1] > h.b[0] ? [PB[h.b[0]], PB[h.b[1] - 1] + 1] : [0, 0];
      return { rem, at, b, kind: h.kind, cats: FZ.hunkCats(SA.slice(h.a[0], h.a[1]), SB.slice(h.b[0], h.b[1])), size: (h.a[1] - h.a[0]) + (h.b[1] - h.b[0]), key: SA.slice(h.a[0], h.a[1]).join('\n') + '\u0001' + SB.slice(h.b[0], h.b[1]).join('\n') }; });
    if (opts.detail === false) return out;
    /* 同じと見た行の対（塊の間）で、リンク先・強調を比べる */
    const det = []; let ai = 0, bj = 0; const pairAt = (i, j) => { const la = A.lines[idx[PA[i]]], lb = B.lines[PB[j]]; const da = FZ.lineDetail(A, la), db = FZ.lineDetail(B, lb); const cats = []; if (da.link !== db.link) cats.push('link'); if (opts.exact ? da.emph !== db.emph : da.emphLoose !== db.emphLoose) cats.push('emph');
      if (cats.length) { const L = idx[PA[i]]; det.push({ rem: [L], at: L, b: [PB[j], PB[j] + 1], kind: 'chg', cats, detail: { a: da, b: db }, size: 1, key: 'D' + SA[i] + '\u0001' + da.link + '\u0001' + da.emph + '\u0001' + db.link + '\u0001' + db.emph }); } };
    for (const h of raw) { while (ai < h.a[0] && bj < h.b[0]) pairAt(ai++, bj++); ai = h.a[1]; bj = h.b[1]; } while (ai < SA.length && bj < SB.length) pairAt(ai++, bj++);
    if (!det.length) return out; return [...out, ...det].sort((x, y) => (x.rem.length ? x.rem[0] : x.at - 0.5) - (y.rem.length ? y.rem[0] : y.at - 0.5)); };
  /* 範囲（行の番号の列）を文書の変化に合わせて付け替える：前の署名 old と今の署名 now の行の対応から（他の操作や Ctrl+Z の後でも） */
  FZ.remapIdx = function (idx, old, now) { if (old.length === now.length && old.every((x, k) => x === now[k])) return idx.slice(); const S = new Set(idx), out = []; let oi = 0, nj = 0;
    const keep = o1 => { while (oi < o1) { if (S.has(oi)) out.push(nj); oi++; nj++; } }; /* 変わらない行はそのまま写す */
    for (const h of FZ.diffSigs(old, now)) { keep(h.a[0]); nj = h.b[0]; const touch = h.a[1] > h.a[0] ? idx.some(i => i >= h.a[0] && i < h.a[1]) : (S.has(h.a[0] - 1) && S.has(h.a[0])); /* 変わった所が範囲に掛かる（範囲の中への挿入も） */
      if (touch) for (let j = h.b[0]; j < h.b[1]; j++) out.push(j); oi = h.a[1]; nj = h.b[1]; }
    keep(old.length); return out; };
  /* B の行 [b0, b1) を A に入れられる形に写す：参照の字を A の表に、図版の名札が A の他の所と重なれば付け替え。罫と網も一緒に（位置は b0 から） */
  FZ.adoptLines = function (A, B, b0, b1, opts = {}) { const used = new Set(opts.used || []), keep = new Set(opts.keep || []); const fresh = () => { let k = 1; while (used.has('f' + k)) k++; used.add('f' + k); return 'f' + k; };
    const lines = B.lines.slice(b0, b1).map(l => JSON.parse(JSON.stringify(l)));
    for (const ln of lines) { for (const sg of ln.segs) sg.text = sg.text.replace(REF_G, ch => { const id = FZ.refId(B, ch); return id != null ? FZ.refChar(A, id) : ''; });
      for (const fg of ln.attrs.figs || []) { if (used.has(fg.id) && !keep.has(fg.id)) fg.id = fresh(); else { used.add(fg.id); keep.delete(fg.id); } } }
    const R = B.rules || [], rules = [], fills = [];
    for (const r of R) { if (r.axis === 'v') { if (r.from >= b0 && r.to < b1) rules.push({ ...r, from: r.from - b0, to: r.to - b0 }); } else if (r.line > b0 && r.line < b1) rules.push({ ...r, line: r.line - b0 }); else if ((r.line === b0 || r.line === b1) && R.some(v => v.axis === 'v' && v.from >= b0 && v.to < b1 && (v.from === r.line || v.to === r.line - 1))) rules.push({ ...r, line: r.line - b0 }); } /* 表の上下の罫は、その表の縦罫が範囲にある時だけ */
    for (const f of B.fills || []) if (f.from >= b0 && f.to < b1) fills.push({ ...f, from: f.from - b0, to: f.to - b0 }); return { lines, rules, fills }; };
  /* 節や箇条書きの一部だけ写した時、Markdown では箇条書きの段が 0 から始まる：範囲の最初の行に合わせて B の段を戻す */
  FZ.alignLevels = function (A, idx, B) { const first = (doc, ids) => { for (const i of ids) { const l = doc.lines[i]; if (l && (l.segs.some(sg => sg.text.trim()) || (l.attrs.figs || []).length)) return l; } return null; };
    const fa = first(A, idx), fb = first(B, B.lines.map((_, i) => i)); if (!fa || !fb || !fa.attrs.list || !fb.attrs.list) return 0; const d = (fa.attrs.list.level | 0) - (fb.attrs.list.level | 0); if (d <= 0) return 0;
    for (const l of B.lines) if (l.attrs.list) l.attrs.list.level = Math.min(7, (l.attrs.list.level | 0) + d); return d; };
  /* 塊の中の行の対応：似た行（頭と尻が合う）を対にする。対の行はその場で直す（飾り・揃え・罫・傍点など Markdown に無いものが残る） */
  const parts = s => { const k = s.indexOf('|'); return [s.slice(0, k), s.slice(k + 1)]; };
  const simOf = (x, y) => { if (x === y) return 1; const n = Math.min(x.length, y.length); let p = 0; while (p < n && x[p] === y[p]) p++; let q = 0; while (q < n - p && x[x.length - 1 - q] === y[y.length - 1 - q]) q++; return (p + q) / Math.max(x.length, y.length, 1); };
  FZ.alignLines = function (SA, SB) { const n = SA.length, m = SB.length, ops = [];
    if (!n || !m) return [...SA.map((_, i) => ({ t: 'd', i })), ...SB.map((_, j) => ({ t: 'i', j }))];
    const PA = SA.map(parts), PB = SB.map(parts); const sc = (i, j) => { const s = simOf(PA[i][1], PB[j][1]); return s >= 0.34 ? s + (PA[i][0] === PB[j][0] ? 0.1 : 0) : -1; };
    if (n * m > 4000) { for (let k = 0; k < Math.max(n, m); k++) { if (k < n && k < m) ops.push({ t: 'p', i: k, j: k }); else if (k < n) ops.push({ t: 'd', i: k }); else ops.push({ t: 'i', j: k }); } return ops; }
    const W = m + 1, D = new Float64Array((n + 1) * W); for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) { let b = Math.max(D[(i + 1) * W + j], D[i * W + j + 1]); const s = sc(i, j); if (s > 0) b = Math.max(b, s + D[(i + 1) * W + j + 1]); D[i * W + j] = b; }
    let i = 0, j = 0; while (i < n && j < m) { const s = sc(i, j); if (s > 0 && Math.abs(D[i * W + j] - (s + D[(i + 1) * W + j + 1])) < 1e-9) { ops.push({ t: 'p', i, j }); i++; j++; } else if (D[(i + 1) * W + j] >= D[i * W + j + 1]) ops.push({ t: 'd', i: i++ }); else ops.push({ t: 'i', j: j++ }); }
    while (i < n) ops.push({ t: 'd', i: i++ }); while (j < m) ops.push({ t: 'i', j: j++ }); return ops; };
  /* 字の入れ替え：頭と尻の同じ所は今の字の飾り・リンクを残し、間だけ B のものに */
  const MM = FZ.M || {}; const INEXP = (MM.OUTLINE | MM.WIDE | MM.TALL | MM.SHADOW | MM.SHT | MM.SZW | MM.SZH) >>> 0; /* Markdown に出ない飾り：直した字は前後の字から受け継ぐ */
  const markFor = (bm, inh, boldLost) => { let m = (bm | 0) | (inh & INEXP); if (boldLost) m |= inh & MM.BOLD; if ((m & MM.UNDER) && (inh & (MM.UNDER2 | MM.WAVE))) m = (m & ~MM.UNDER) | (inh & (MM.UNDER2 | MM.WAVE)); if ((m & MM.STRIKE) && (inh & MM.STRIKE2)) m = (m & ~MM.STRIKE) | MM.STRIKE2; return m; };
  const ADOPT = ((MM.BOLD | MM.DOT | MM.ANY_UNDER | MM.ANY_STRIKE | MM.SHADE | MM.CODE | MM.LINK) >>> 0); /* 字が同じ時に B から受け取る：強調とリンク（ほかの飾りは今のまま） */
  const sameText = (a, b, boldLost) => { const la = JSON.stringify((a.links || []).map(l => [l.start, l.end, l.url])), lb = JSON.stringify((b.links || []).map(l => [l.start, l.end, l.url])); let ch = la !== lb;
    const marks = a.marks.map((m, i) => { const bm = (b.marks || [])[i] | 0; const v = ((m & ~ADOPT) | (markFor(bm, m, boldLost) & ADOPT)) >>> 0; if (v !== (m >>> 0)) ch = true; return v; });
    if (!ch) return a; const out = { ...a, marks }; if ((b.links || []).length) out.links = b.links.map(l => ({ ...l })); else delete out.links; return out; };
  const mergeSeg = (a, b, boldLost) => { const ta = a.text, tb = b.text; if (ta === tb) return sameText(a, b, boldLost); const n = Math.min(ta.length, tb.length); let p = 0; while (p < n && ta[p] === tb[p]) p++; let q = 0; while (q < n - p && ta[ta.length - 1 - q] === tb[tb.length - 1 - q]) q++;
    const inh = (p < ta.length - q ? a.marks[p] : p > 0 ? a.marks[p - 1] : a.marks[p]) | 0;
    const out = { ...a, text: tb, marks: [...a.marks.slice(0, p), ...(b.marks || []).slice(p, tb.length - q).map(m => markFor(m, inh, boldLost)), ...a.marks.slice(ta.length - q)] };
    while (out.marks.length < tb.length) out.marks.push(markFor(0, inh, boldLost)); const dl = tb.length - ta.length, me = tb.length - q;
    const bl = (b.links || []).filter(l => l.end > p && l.start < me); const links = [...(a.links || []).filter(l => l.end <= p), ...bl, ...(a.links || []).filter(l => l.start >= ta.length - q).map(l => ({ ...l, start: l.start + dl, end: l.end + dl }))].filter((l, k, arr) => !arr.some((x, k2) => k2 < k && x.start < l.end && l.start < x.end));
    if (links.length) out.links = links.map(l => ({ ...l })); else delete out.links; return out; };
  const mergeInto = (aLn, bLn) => { const same = kindKey(aLn.attrs) === kindKey(bLn.attrs);
    const bl = !!(aLn.attrs.style || aLn.attrs.deco || aLn.attrs.cells); /* 見出し・飾り・表の太字は Markdown で落ちる */
    aLn.segs = aLn.segs.length === bLn.segs.length ? aLn.segs.map((sg, k) => mergeSeg(sg, bLn.segs[k], bl)) : bLn.segs; /* 表の行：枡の数が同じなら枡ごと（枡の位置は今のまま） */
    if (!same) { const anchor = aLn.attrs.anchor; aLn.attrs = bLn.attrs; if (anchor && /^(title|num|sym)$/.test(bLn.attrs.style || '')) aLn.attrs.anchor = anchor; return; }
    if (bLn.attrs.join) aLn.attrs.join = true; else delete aLn.attrs.join; /* 段落の中の改行の有無は戻した側に */
    const af = aLn.attrs.figs || [], bf = bLn.attrs.figs || []; const figs = bf.map(f => ({ ...(af.find(x => x.id === f.id) || {}), ...f })); if (figs.length) aLn.attrs.figs = figs; else delete aLn.attrs.figs; };
  const blankLn = l => l && l.segs.length === 1 && l.segs[0].text === '' && !(l.attrs.figs || []).length && !l.attrs.figure && !l.attrs.toc && !l.attrs.hr;
  /* 塊を取り込む（ed.mutate の中で呼ぶ）：消す・直す・足すを上から順に。直す行はその場で。戻り値：直した・足した行の最初の番号 */
  FZ.applyHunk = function (ed, B, h, o = {}) { const A = ed.doc; const sigA = o.sigA || A.lines.map(l => FZ.lineSig(A, l)), sigB = o.sigB || B.lines.map(l => FZ.lineSig(B, l));
    const remSet = new Set(h.rem), aC = h.rem.filter(i => sigA[i] !== '|'), bC = []; for (let j = h.b[0]; j < h.b[1]; j++) if (sigB[j] !== '|') bC.push(j);
    const ops = FZ.alignLines(aC.map(i => sigA[i]), bC.map(j => sigB[j]));
    const used = A.lines.flatMap(l => (l.attrs.figs || []).map(f => f.id)), keep = h.rem.flatMap(i => (A.lines[i].attrs.figs || []).map(f => f.id));
    const ad = FZ.adoptLines(A, B, h.b[0], h.b[1], { used, keep }); const bl = j => ad.lines[j - h.b[0]];
    const delC = new Set(ops.filter(x => x.t === 'd').map(x => aC[x.i])); const del = new Set(delC); /* 消す行の間の空行も消す（範囲の中だけ） */
    for (let k = 0; k + 1 < aC.length; k++) if (delC.has(aC[k]) && delC.has(aC[k + 1])) for (let x = aC[k] + 1; x < aC[k + 1]; x++) if (remSet.has(x)) del.add(x);
    let delta = 0, pos = h.at, first = null, lastA = h.rem.length ? h.rem[0] - 1 : h.at - 1, prevIns = null, cut = null; const bmap = new Map();
    const rmRun = (x0, x1) => { const a0 = x0 + delta, a1 = x1 + delta; if (FZ.tree && FZ.tree.removeRange) FZ.tree.removeRange(ed, a0, a1); else for (let x = a1; x >= a0; x--) ed.removeLine(x); delta -= x1 - x0 + 1; pos = a0; cut = a0; };
    const ins = (ln, j) => { const within = !!ln.attrs.cells && pos > 0 && FZ.inTable && FZ.inTable(A, pos - 1); ed.insertLine(pos, ln, within); if (j != null) bmap.set(j, pos); if (first == null) first = pos; pos++; delta++; };
    const endRun = () => { if (prevIns == null) return; const nx = prevIns + 1; if (nx < sigB.length && sigB[nx] === '|' && pos < A.lines.length && !blankLn(A.lines[pos])) ins(FZ.newLine(), null); prevIns = null; }; /* 足した所の後ろの空き（B にあれば） */
    const dels = []; const flushDel = () => { if (!dels.length) return; let s0 = dels[0], e0 = dels[0]; for (let k = 1; k < dels.length; k++) { if (dels[k] === e0 + 1) e0 = dels[k]; else { rmRun(s0, e0); s0 = e0 = dels[k]; } } rmRun(s0, e0); dels.length = 0; };
    for (const op of ops) {
      if (op.t === 'i') { flushDel(); const j = bC[op.j];
        if (prevIns != null) { for (let x = prevIns + 1; x < j; x++) ins(bl(x), x); } /* 足す行の間の空行は B のまま */
        else if (j > 0 && sigB[j - 1] === '|' && pos > 0 && !blankLn(A.lines[pos - 1])) ins(FZ.newLine(), null); /* 前の空き（B にあれば） */
        ins(bl(j), j); prevIns = j; continue; }
      endRun(); const i = aC[op.i]; for (let x = lastA + 1; x < i; x++) if (del.has(x)) dels.push(x); lastA = i;
      if (op.t === 'd') { dels.push(i); continue; }
      flushDel(); const L = i + delta; mergeInto(A.lines[L], bl(bC[op.j])); if (first == null) first = L; pos = L + 1; }
    endRun(); flushDel();
    if (cut != null && !ops.some(x => x.t !== 'd') && cut > 0 && blankLn(A.lines[cut - 1]) && blankLn(A.lines[cut]) && A.lines.length > 1) ed.removeLine(cut); /* 節を消して空行が 2 つ並んだら 1 つに */
    /* 足した表・囲みの罫と網（B の縦罫の行がすべて続けて入った時だけ） */
    const R = B.rules || [], spans = []; for (const r of R) if (r.axis === 'v' && bmap.has(r.from) && bmap.has(r.to) && bmap.get(r.to) - bmap.get(r.from) === r.to - r.from) { let ok = true; for (let x = r.from; x <= r.to; x++) if (!bmap.has(x)) ok = false; if (ok) { A.rules.push({ ...r, id: FZ.uid(), from: bmap.get(r.from), to: bmap.get(r.to) }); spans.push(r); } }
    const hs = new Set(); for (const sp of spans) for (const r of R) if (r.axis === 'h' && !hs.has(r) && r.line >= sp.from && r.line <= sp.to + 1) { hs.add(r); A.rules.push({ ...r, id: FZ.uid(), line: r.line <= sp.to ? bmap.get(r.line) : bmap.get(sp.to) + 1 }); }
    for (const f of B.fills || []) { let ok = true; for (let x = f.from; x <= f.to; x++) if (!bmap.has(x)) ok = false; if (ok && bmap.get(f.to) - bmap.get(f.from) === f.to - f.from) A.fills.push({ ...f, id: FZ.uid(), from: bmap.get(f.from), to: bmap.get(f.to) }); }
    if (ed.dedupeRules && hs.size) ed.dedupeRules();
    return first == null ? Math.min(pos, A.lines.length - 1) : first; };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
