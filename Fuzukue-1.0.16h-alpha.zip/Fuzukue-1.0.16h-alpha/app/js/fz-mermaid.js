/* 文机 — Mermaid との往復（1.0.12d）
 * 読む：flowchart／graph（流れ図・概念図・DFD）・sequenceDiagram・erDiagram・mindmap を、文机の図（箱・矢印・線・字・レーン）に組む。
 *   流れ図は層に分けて並べる（輪を切る → いちばん長い道で層 → 重心で並べ替え → 層ごとに中央に寄せる）。サブグラフはレーン。
 *   シーケンス図は上に参加者、点線の生存線、上から順に伝達の線（字は線の上）、注は網の箱、loop／alt などは点線の枠。
 *   ER 図は実体を箱（1 行目が名前、下に属性）、関係を矢じりなしの線（多重度は「1:0..多」の形で字に添える）。
 *   マインドマップは左に中心、右へ枝を広げる木。
 * 書く：図の種類（F.tag）ごとに Mermaid の記法へ戻す。種類の無い図は流れ図として、箱の形・線の種類・レーンを写す。 */
(function (FZ) {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v)); const half = v => Math.round(v * 2) / 2;
  const tw = t => FZ.textWidth(String(t));
  const longest = t => Math.max(1, ...String(t).split('\n').map(tw));
  const rowsOf = (t, w) => String(t).split('\n').reduce((n, p) => n + Math.max(1, Math.ceil(tw(p) / Math.max(1, w))), 0);
  const unq = t => String(t == null ? '' : t).trim().replace(/^"([\s\S]*)"$/, '$1').replace(/#quot;/g, '"').replace(/<br\s*\/?>/gi, '\n');
  const q = t => '"' + String(t).replace(/"/g, '#quot;').replace(/\n/g, '<br>') + '"';
  const srcLines = text => String(text).replace(/\r/g, '').split('\n').filter(l => l.trim() && !/^\s*%%/.test(l));

  /* ---------- 層に分けて並べる ---------- */
  function layered(n, edges) {
    const E = edges.filter(e => e.a !== e.b); const adj = Array.from({ length: n }, () => []); E.forEach((e, k) => adj[e.a].push(k));
    const st = new Uint8Array(n), rev = new Set();
    const dfs = v => { st[v] = 1; for (const k of adj[v]) { const w = E[k].b; if (st[w] === 1) rev.add(k); else if (!st[w]) dfs(w); } st[v] = 2; };
    for (let v = 0; v < n; v++) if (!st[v]) dfs(v);
    const D = E.map((e, k) => rev.has(k) ? { a: e.b, b: e.a } : e);
    const out = Array.from({ length: n }, () => []), pre = Array.from({ length: n }, () => []); for (const e of D) { out[e.a].push(e.b); pre[e.b].push(e.a); }
    const indeg = pre.map(p => p.length), layer = new Array(n).fill(0), qu = []; for (let v = 0; v < n; v++) if (!indeg[v]) qu.push(v);
    while (qu.length) { const v = qu.shift(); for (const w of out[v]) { layer[w] = Math.max(layer[w], layer[v] + 1); if (--indeg[w] === 0) qu.push(w); } }
    for (let v = 0; v < n; v++) if (!pre[v].length && out[v].length) layer[v] = Math.max(0, Math.min(...out[v].map(w => layer[w])) - 1); /* 始まりの箱は最初の行き先のすぐ上へ */
    const L = Math.max(0, ...layer) + 1, order = Array.from({ length: L }, () => []); for (let v = 0; v < n; v++) order[layer[v]].push(v);
    const pos = new Array(n); const norm = () => order.forEach(row => row.forEach((v, k) => { pos[v] = (k + 0.5) / row.length; })); norm();
    for (let it = 0; it < 10; it++) { const down = it % 2 === 0; const ls = order.map((_, l) => l); for (const l of down ? ls.slice(1) : ls.reverse().slice(1)) { const nb = v => (down ? pre[v] : out[v]); const bc = v => { const ns = nb(v); return ns.length ? ns.reduce((t, w) => t + pos[w], 0) / ns.length : pos[v]; }; const m = new Map(order[l].map(v => [v, bc(v)])); order[l].sort((x, y) => m.get(x) - m.get(y)); order[l].forEach((v, k) => { pos[v] = (k + 0.5) / order[l].length; }); } }
    return { layer, order };
  }
  /* 1.0.14f 箱は字が収まる最小の大きさ：左右の余白は半字ずつ、上下の余白なし（1 行の字なら高さ 1 行。罫は行の境に引く） */
  const BOX_MAX = 18;
  const boxW = (text, max) => { max = Math.max(3, max); const L = longest(text); if (L + 1 <= max) return Math.max(3, L + 1); const n = Math.ceil(L / (max - 1)); return clamp(Math.ceil(L / n) + 1, 3, max); }; /* 収まらない字は行の長さをそろえて折り返す（最後の行に 1 字だけ残さない） */
  const boxH = (text, w) => Math.max(1, rowsOf(text, Math.max(1, w - 1)));
  /* 上から下へ：層が行。行の中は左右の中央に寄せる */
  function placeTD(nodes, G, W, o = {}) { const gx = o.gx || 2, x0 = o.x0 || 0, WW = o.W || W; const gyOf = typeof o.gy === 'function' ? o.gy : () => o.gy || 1; const pos = new Array(nodes.length); let y = o.y0 || 0, gy = 0; /* 1.0.14f 層の間は 1 行（矢印の字がある層の下は 2 行）。図の上下に空きを作らない */
    const placeRow = row => { const k = row.length; let g = gx; const ws = row.map(v => boxW(nodes[v].text, Math.min(BOX_MAX, Math.floor((WW - gx * (k - 1)) / k)))); let tot = ws.reduce((a, b) => a + b, 0) + g * (k - 1);
      if (tot > WW) { g = 1; tot = ws.reduce((a, b) => a + b, 0) + (k - 1); if (tot > WW) { const f = (WW - (k - 1)) / ws.reduce((a, b) => a + b, 0); for (let i = 0; i < k; i++) ws[i] = Math.max(3, Math.floor(ws[i] * f)); tot = ws.reduce((a, b) => a + b, 0) + (k - 1); } }
      let x = x0 + Math.max(0, half((WW - tot) / 2)), rh = 1; row.forEach((v, i) => { const h = boxH(nodes[v].text, ws[i]); pos[v] = { x, y, w: ws[i], h }; x += ws[i] + g; rh = Math.max(rh, h); });
      row.forEach(v => { pos[v].y = y + Math.floor((rh - pos[v].h) / 2); }); return rh; };
    G.order.forEach((row, l) => { if (!row.length) return; const per = Math.max(1, Math.floor((WW + 1) / 4)); /* 1.0.14f 幅 3 字でも横に入らない層は、段に分けて積む（図が紙の右へはみ出さない） */
      const n = Math.ceil(row.length / per), m = Math.ceil(row.length / n); for (let c = 0; c < n; c++) { const rh = placeRow(row.slice(c * m, (c + 1) * m)); y += rh + (c < n - 1 ? 1 : 0); }
      gy = gyOf(l); y += gy; });
    return { pos, h: Math.max(1, y - gy) }; }
  /* 左から右へ：層が列。列の中は上下に積み、列ごとに上下の中央に寄せる。収まらなければ null */
  function placeLR(nodes, G, W, o = {}) { const L = G.order.length, gx = o.gx || 3, gy = o.gyc || 1; const colMax = Math.floor((W - gx * (L - 1)) / L); if (colMax < 3) return null; /* 1.0.14f 列の間 3 字（矢印の字があれば字の幅に合わせる）・縦の箱の間 1 行 */
    const cw = G.order.map(row => Math.min(colMax, Math.max(3, ...row.map(v => Math.min(BOX_MAX, longest(nodes[v].text) + 1))))); const tot = cw.reduce((a, b) => a + b, 0) + gx * (L - 1); let x = Math.max(0, half((W - tot) / 2));
    const pos = new Array(nodes.length); const colH = G.order.map((row, l) => row.reduce((t, v) => t + boxH(nodes[v].text, cw[l]) + gy, -gy)); const H = Math.max(1, ...colH);
    G.order.forEach((row, l) => { let y = Math.floor((H - colH[l]) / 2); row.forEach(v => { const h = boxH(nodes[v].text, cw[l]); pos[v] = { x, y, w: cw[l], h }; y += h + gy; }); x += cw[l] + gx; });
    return { pos, h: H }; }

  /* ---------- 流れ図・概念図・DFD ---------- */
  const SHAPES = [ /* [正規表現（id の後ろ）, 形] */
    [/^\(\(\(([\s\S]*)\)\)\)$/, 'circle'], [/^\(\(([\s\S]*)\)\)$/, 'circle'], [/^\(\[([\s\S]*)\]\)$/, 'stadium'], [/^\[\[([\s\S]*)\]\]$/, 'sub'], [/^\[\(([\s\S]*)\)\]$/, 'db'],
    [/^\[\/([\s\S]*)\/\]$/, 'para'], [/^\[\\([\s\S]*)\\\]$/, 'para'], [/^\[\/([\s\S]*)\\\]$/, 'para'], [/^\[\\([\s\S]*)\/\]$/, 'para'], [/^\{\{([\s\S]*)\}\}$/, 'hex'], [/^\{([\s\S]*)\}$/, 'diamond'],
    [/^\(([\s\S]*)\)$/, 'round'], [/^\[([\s\S]*)\]$/, 'rect'], [/^>([\s\S]*)\]$/, 'rect']];
  const LOOK = { rect: { kind: 'thin' }, round: { kind: 'thin', shade: 'light' }, stadium: { kind: 'thin', shade: 'light' }, circle: { kind: 'thick', shade: 'light' }, sub: { kind: 'thick' }, db: { kind: 'store' }, para: { kind: 'dotted' }, hex: { kind: 'double', shade: 'light' }, diamond: { kind: 'double' } };
  const shapeOf = b => b.kind === 'store' ? ['[(', ')]'] : b.kind === 'double' ? (b.shade ? ['{{', '}}'] : ['{', '}']) : b.kind === 'thick' ? (b.shade ? ['((', '))'] : ['[[', ']]']) : b.kind === 'dotted' ? ['[/', '/]'] : b.shade ? ['([', '])'] : ['[', ']'];
  function splitEdges(l) { const parts = []; let cur = '', depth = 0, inq = false;
    for (let i = 0; i < l.length;) { const ch = l[i]; if (ch === '"') { inq = !inq; cur += ch; i++; continue; } if (!inq) { if ('[({'.includes(ch)) depth++; else if (')]}'.includes(ch)) depth = Math.max(0, depth - 1); }
      if (!inq && depth === 0) { const m = /^\s*(<?(?:-\.+-|-{2,}|={2,})[>ox]?)(?:\|([^|]*)\|)?\s*/.exec(l.slice(i)); if (m && cur.trim()) { parts.push(cur, { op: m[1], label: m[2] }); cur = ''; i += m[0].length; continue; } }
      cur += ch; i++; }
    parts.push(cur); return parts; }
  function flowFrom(L, W) {
    const dirTok = (L[0].match(/^\s*(?:flowchart|graph)\s+(\w+)/i) || [])[1] || 'TD'; const LR = /^(LR|RL)$/i.test(dirTok);
    const nodes = [], byId = new Map(), edges = [], groups = []; const stack = [];
    const touch = tok => { const t = tok.trim().replace(/:::[\w-]+$/, ''); const m = t.match(/^([A-Za-z0-9_぀-ヿ㐀-鿿豈-﫿\-.]+?)\s*((?:\(|\[|\{|>)[\s\S]*)?$/); if (!m) return null; const id = m[1]; let text = null, shape = 'rect';
      if (m[2]) { for (const [re, sh] of SHAPES) { const mm = m[2].match(re); if (mm) { text = unq(mm[1]); shape = sh; break; } } }
      let n = byId.get(id); if (!n) { n = { id, text: text != null ? text : id, shape }; byId.set(id, n); nodes.push(n); if (stack.length) stack[stack.length - 1].push(n); } else if (text != null) { n.text = text; n.shape = shape; } return n; };
    for (const raw of L.slice(1)) for (let l of raw.split(';')) { l = l.trim(); if (!l) continue;
      if (/^subgraph\b/i.test(l)) { const m = l.match(/^subgraph\s+(?:([^\[\s"]+)\s*)?(?:\[([^\]]*)\])?\s*(.*)$/i); const g = []; g.title = unq((m && (m[2] || m[3] || m[1])) || ''); groups.push(g); stack.push(g); continue; }
      if (/^end$/i.test(l)) { stack.pop(); continue; }
      if (/^(classDef|class|style|linkStyle|click|direction|accTitle|accDescr)\b/i.test(l)) continue;
      l = l.replace(/--\s*([^-|>]+?)\s*-->/g, '-->|$1|').replace(/-\.\s*([^-.|>]+?)\s*\.->/g, '-.->|$1|').replace(/==\s*([^=|>]+?)\s*==>/g, '==>|$1|');
      const parts = splitEdges(l); let prev = parts[0].split(/\s*&\s*/).map(touch).filter(Boolean);
      for (let p = 1; p + 1 < parts.length; p += 2) { const { op, label } = parts[p]; const right = parts[p + 1].split(/\s*&\s*/).map(touch).filter(Boolean); const kind = /\./.test(op) ? 'dotted' : /=/.test(op) ? 'thick' : 'thin'; const head = /[>ox]$/.test(op);
        for (const a of prev) for (const b of right) if (a !== b) edges.push(/^</.test(op) && !/>$/.test(op) ? { from: b, to: a, label: unq(label || ''), kind, head: true } : { from: a, to: b, label: unq(label || ''), kind, head }); prev = right; } }
    if (!nodes.length) return null;
    const idx = new Map(nodes.map((n, k) => [n, k])); const G = layered(nodes.length, edges.map(e => ({ a: idx.get(e.from), b: idx.get(e.to) })));
    const labeled = edges.some(e => e.label); let pos, h, lanes = null, dir = LR ? 'LR' : 'TD';
    const labLayer = new Set(edges.filter(e => e.label).map(e => G.layer[idx.get(e.from)])); const gyOf = l => labLayer.has(l) ? 2 : 1; /* 1.0.14f 矢印に字のある層の下だけ 2 行（字の行と線の行） */
    const lrGx = labeled ? clamp(Math.max(...edges.filter(e => e.label).map(e => tw(e.label))) + 2, 3, 10) : 3;
    if (groups.length) { /* サブグラフ → レーン（上下なら縦のレーン、左右なら横のレーン） */
      const inG = new Set(groups.flat()); const rest = nodes.filter(n => !inG.has(n)); const gs = rest.length ? [...groups, Object.assign(rest.slice(), { title: '' })] : groups; const laneOf = new Map(); gs.forEach((g, k) => g.forEach(n => laneOf.set(n, k)));
      pos = new Array(nodes.length);
      if (!LR) { const lw = W / gs.length; let y = 2, gy = 1; G.order.forEach((row, l) => { let rh = 1; gs.forEach((g, k) => { const here = row.filter(v => laneOf.get(nodes[v]) === k); if (!here.length) return; const m = here.length, bx0 = half(k * lw) + 1, bw = Math.floor(lw) - 2; const wm = Math.max(3, Math.min(BOX_MAX, Math.floor((bw - 2 * (m - 1)) / m))); const ws = here.map(v => boxW(nodes[v].text, wm)); const tot = ws.reduce((a, b) => a + b, 0) + 2 * (m - 1); let x = bx0 + Math.max(0, half((bw - tot) / 2)); here.forEach((v, j) => { const bh = boxH(nodes[v].text, ws[j]); pos[v] = { x, y, w: ws[j], h: bh }; x += ws[j] + 2; rh = Math.max(rh, bh); }); }); if (row.length) { gy = gyOf(l); y += rh + gy; } }); h = y - gy + 1; lanes = { dir: 'v', items: gs.map(g => ({ title: g.title || '', size: 0 })) }; } /* 1.0.14f 箱は字の幅、層の間は 1 行（字のある層は 2 行）、レーンの下に 1 行 */
      else { const Lc = G.order.length, colW = Math.max(3, Math.min(BOX_MAX, Math.floor((W - 3 - 3 * (Lc - 1)) / Lc))); let y = 0; const sizes = []; gs.forEach((g, k) => { let bandH = 2; G.order.forEach((row, l) => { const here = row.filter(v => laneOf.get(nodes[v]) === k); let yy = y + 1; here.forEach(v => { const bh = boxH(nodes[v].text, colW); pos[v] = { x: 3 + l * (colW + 3), y: yy, w: colW, h: bh }; yy += bh + 1; }); bandH = Math.max(bandH, yy - y); }); sizes.push(bandH); y += bandH; }); h = y; lanes = { dir: 'h', items: gs.map((g, k) => ({ title: g.title || '', size: sizes[k] })) }; } }
    else { let r = LR ? placeLR(nodes, G, W, { gx: lrGx }) : null; if (!r) { r = placeTD(nodes, G, W, { gy: gyOf }); dir = 'TD'; } pos = r.pos; h = r.h; }
    const nums = nodes.map(n => { const m = /^n(\d+)$/.exec(n.id); return m ? +m[1] : null; }); const useNum = nums.every(v => v != null && v > 0) && new Set(nums).size === nums.length; const bid = k => useNum ? nums[k] : k + 1; /* 1.0.15c 文机が書いた n番号 はその番号のまま（往復で箱の番号が変わらない） */
    const boxes = nodes.map((n, k) => ({ id: bid(k), ...pos[k], text: n.text, kind: LOOK[n.shape].kind, shade: LOOK[n.shape].shade || null, bold: false }));
    const LY = G.layer, usedR = [], usedB = []; let hh = h;
    const arrows = edges.map(e => { const ia = idx.get(e.from), ib = idx.get(e.to); const a = { from: bid(ia), to: bid(ib), label: e.label, kind: e.kind }; if (!e.head) a.head = false; const A = pos[ia], B = pos[ib];
      if (A && B && !lanes) { /* 戻りの矢印と、層を 2 つ以上飛ぶ矢印（1.0.14f）は、間の箱を避けて右（左右の図は下）を回る。回り道どうしは 1 字（1 行）ずらす */
        if (dir === 'TD' && (B.y + B.h <= A.y || LY[ib] - LY[ia] >= 2)) { a.via = 'r'; const y0 = Math.min(A.y, B.y), y1 = Math.max(A.y + A.h, B.y + B.h); let vx = half(Math.max(...pos.filter(p => p && p.y < y1 && p.y + p.h > y0).map(p => p.x + p.w)) + 1.5); while (usedR.some(u => u.x === vx && u.y0 < y1 && u.y1 > y0)) vx += 1; usedR.push({ x: vx, y0, y1 }); a.vp = Math.min(vx, W - 0.5); }
        else if (dir === 'LR' && (B.x + B.w <= A.x || LY[ib] - LY[ia] >= 2)) { a.via = 'b'; const x0 = Math.min(A.x, B.x), x1 = Math.max(A.x + A.w, B.x + B.w); let vy = Math.max(...pos.filter(p => p && p.x < x1 && p.x + p.w > x0).map(p => p.y + p.h)) + 1; while (usedB.some(u => u.y === vy && u.x0 < x1 && u.x1 > x0)) vy += 1; usedB.push({ y: vy, x0, x1 }); a.vp = vy; hh = Math.max(hh, vy + 1); } }
      return a; });
    return { tag: 'flow', dir: LR ? 'LR' : 'TD', h: hh, boxes, arrows, lanes, lines: [], texts: [] }; }
  function flowTo(F, W) {
    const lanes = FZ.laneGeom(F, W, F.h); const sx = Math.max(0, ...F.boxes.map(b => b.x + b.w)), sy = Math.max(0, ...F.boxes.map(b => b.y + b.h));
    const dir = lanes ? (lanes.dir === 'v' ? 'TD' : 'LR') : F.dir || (sx >= sy * 2.5 ? 'LR' : 'TD'); const out = ['flowchart ' + dir];
    const node = b => { const [o, c] = shapeOf(b); return 'n' + b.id + o + q(b.text || ' ') + c; };
    if (lanes) { const inBand = (b, band) => { const c = lanes.dir === 'v' ? b.x + b.w / 2 : b.y + b.h / 2; return c >= band.from && c < band.to; };
      lanes.bands.forEach((band, k) => { out.push('  subgraph L' + (k + 1) + '[' + q(band.title || ' ') + ']'); for (const b of F.boxes) if (inBand(b, band)) out.push('    ' + node(b)); out.push('  end'); });
      for (const b of F.boxes) if (!lanes.bands.some(band => inBand(b, band))) out.push('  ' + node(b)); }
    else for (const b of F.boxes) out.push('  ' + node(b));
    for (const a of F.arrows) { const op = a.kind === 'dotted' ? (a.head === false ? '-.-' : '-.->') : a.kind === 'thick' ? (a.head === false ? '===' : '==>') : (a.head === false ? '---' : '-->'); out.push('  n' + a.from + ' ' + op + (a.label ? '|' + q(a.label) + '|' : '') + ' n' + a.to); }
    return out; }

  /* ---------- シーケンス図 ---------- */
  function seqFrom(L, W) {
    const parts = [], byId = new Map(); const add = (id, label) => { id = id.trim(); let p = byId.get(id); if (!p) { p = { id, text: label || id }; byId.set(id, p); parts.push(p); } else if (label) p.text = label; return p; };
    const ev = [], open = []; let auto = false, num = 0;
    for (const raw of L.slice(1)) { const l = raw.trim(); let m;
      if ((m = l.match(/^(participant|actor)\s+(.+?)(?:\s+as\s+(.+))?$/i))) { add(m[2], m[3] ? unq(m[3]) : null); continue; }
      if (/^autonumber\b/i.test(l)) { auto = true; continue; }
      if (/^box\b/i.test(l)) { open.push('box'); continue; }
      if (/^(activate|deactivate|title|accTitle|accDescr|link|links|create|destroy)\b/i.test(l)) continue;
      if ((m = l.match(/^note\s+(left of|right of|over)\s+([^:]+):\s*(.*)$/i))) { const who = m[2].split(',').map(s => add(s)); ev.push({ t: 'note', where: m[1].toLowerCase(), who, text: unq(m[3]) }); continue; }
      if ((m = l.match(/^(loop|alt|opt|par|critical|break|rect)\b\s*(.*)$/i))) { open.push('f'); ev.push({ t: 'open', kind: m[1].toLowerCase(), text: m[1].toLowerCase() === 'rect' ? '' : unq(m[2] || '') }); continue; }
      if ((m = l.match(/^(else|and|option)\b\s*(.*)$/i))) { ev.push({ t: 'sep', kind: m[1].toLowerCase(), text: unq(m[2] || '') }); continue; }
      if (/^end$/i.test(l)) { if (open.pop() === 'f') ev.push({ t: 'close' }); continue; }
      if ((m = l.match(/^(.+?)\s*(-{1,2}(?:>>|>|x|\)))\s*[+-]?\s*(.+?)\s*:\s*(.*)$/))) { const a = add(m[1]), b = add(m[3]); num++; ev.push({ t: 'msg', a, b, dotted: m[2].startsWith('--'), head: />>$|x$|\)$/.test(m[2]), text: (auto ? num + '. ' : '') + unq(m[4]) }); continue; } }
    const n = parts.length; if (!n) return null;
    const colW = W / n, bw = Math.max(4, Math.min(16, Math.floor(colW - 2))); const boxes = [], lines = [], texts = []; const cx = new Map();
    let top = 1; parts.forEach((p, k) => { const w = Math.min(bw, boxW(p.text, bw)), hh = boxH(p.text, w); top = Math.max(top, hh); const c = half(colW * (k + 0.5)); cx.set(p, c); boxes.push({ id: k + 1, x: Math.max(0, half(c - w / 2)), y: 0, w, h: hh, text: p.text, kind: 'thin', shade: null, bold: true }); });
    let y = top; const frames = []; let depth = 0; /* 1.0.14f 参加者の箱のすぐ下から伝達を並べる */
    for (const e of ev) {
      if (e.t === 'msg') { const xa = cx.get(e.a), xb = cx.get(e.b);
        if (e.a === e.b) { lines.push({ pts: [[xa, y + 1], [xa + 3, y + 1], [xa + 3, y + 2], [xa, y + 2]], kind: e.dotted ? 'dotted' : 'thin', head: e.head, label: e.text, role: 'msg' }); y += 3; }
        else { lines.push({ pts: [[xa, y + 1], [xb, y + 1]], kind: e.dotted ? 'dotted' : 'thin', head: e.head, label: e.text, role: 'msg' }); y += 2; } }
      else if (e.t === 'note') { const xs = e.who.map(p => cx.get(p)); let x0, w; const nw = Math.min(W - 1, longest(e.text) + 2);
        if (e.where === 'over') { const lo = Math.min(...xs), hi = Math.max(...xs); w = Math.max(nw, hi - lo + 4); x0 = clamp(half((lo + hi) / 2 - w / 2), 0, Math.max(0, W - w)); } else if (e.where === 'left of') { w = nw; x0 = Math.max(0, half(xs[0] - 1 - w)); } else { w = nw; x0 = Math.min(Math.max(0, W - w), half(xs[0] + 1)); }
        const hh = boxH(e.text, w); boxes.push({ id: boxes.length + 1, x: x0, y, w: Math.min(w, W - x0), h: hh, text: e.text, kind: 'thin', shade: 'light', bold: false }); y += hh; }
      else if (e.t === 'open') { frames.push({ kind: e.kind, text: e.text, y0: y, d: depth++ }); texts.push({ x: depth - 0.5, y, text: e.kind + (e.text ? '：' + e.text : ''), bold: true }); y += 1; }
      else if (e.t === 'sep') { const f = frames[frames.length - 1]; const x0 = f ? f.d + 0.5 : 0.5; lines.push({ pts: [[x0, y], [W - x0, y]], kind: 'dotted', head: false, label: '', role: 'sep' }); texts.push({ x: x0 + 0.5, y, text: e.kind + (e.text ? '：' + e.text : ''), bold: true }); y += 1; }
      else if (e.t === 'close') { const f = frames.pop(); if (!f) continue; depth--; boxes.push({ id: boxes.length + 1, x: f.d + 0.5, y: f.y0, w: W - 1 - 2 * f.d, h: Math.max(1, y - f.y0), text: '', kind: 'dotted', shade: null, bold: false }); y += 1; } }
    for (const p of parts) lines.unshift({ pts: [[cx.get(p), top], [cx.get(p), y]], kind: 'dotted', head: false, label: '', role: 'life' });
    return { tag: 'seq', h: Math.max(1, y), boxes, arrows: [], lanes: null, lines, texts }; }
  function seqTo(F) {
    const P = F.boxes.filter(b => b.y === 0).sort((a, b) => a.x - b.x); if (!P.length) return null; const cx = b => b.x + b.w / 2; const near = x => P.reduce((best, b) => Math.abs(cx(b) - x) < Math.abs(cx(best) - x) ? b : best, P[0]); const id = b => 'P' + (P.indexOf(b) + 1);
    const out = ['sequenceDiagram']; for (const b of P) out.push('  participant ' + id(b) + ' as ' + (b.text || ' ').replace(/\n/g, ' '));
    const label = y => { const t = (F.texts || []).find(x => x.y === y); return t ? t.text : ''; }; const ev = [];
    for (const l of F.lines || []) { if (l.role === 'msg') { const a = near(l.pts[0][0]), b = near(l.pts[l.pts.length - 1][0]); ev.push({ y: l.pts[0][1], o: 1, s: '  ' + id(a) + (l.kind === 'dotted' ? '--' : '-') + (l.head ? '>>' : '>') + id(b) + ': ' + (l.label || ' ').replace(/\n/g, ' ') }); }
      else if (l.role === 'sep') { const m = label(l.pts[0][1]).match(/^(else|and|option)(?:：(.*))?$/); ev.push({ y: l.pts[0][1], o: 1, s: '  ' + (m ? m[1] + (m[2] ? ' ' + m[2] : '') : 'else') }); } }
    for (const b of F.boxes) { if (b.y === 0) continue;
      if (b.kind === 'dotted' && !b.text) { const m = label(b.y).match(/^(loop|alt|opt|par|critical|break|rect)(?:：(.*))?$/); ev.push({ y: b.y, o: 0, s: '  ' + (m ? m[1] + (m[2] ? ' ' + m[2] : '') : 'rect') }, { y: b.y + b.h, o: 2, s: '  end' }); }
      else { const over = P.filter(p => cx(p) >= b.x && cx(p) <= b.x + b.w); const s = over.length ? 'over ' + over.map(id).join(',') : (b.x + b.w / 2 < cx(near(b.x + b.w / 2)) ? 'left of ' : 'right of ') + id(near(b.x + b.w / 2)); ev.push({ y: b.y, o: 1, s: '  Note ' + s + ': ' + (b.text || ' ').replace(/\n/g, ' ') }); } }
    ev.sort((a, b) => a.y - b.y || a.o - b.o); for (const e of ev) out.push(e.s); return out; }

  /* ---------- ER 図 ---------- */
  const CARD = { '||': '1', '|o': '0..1', 'o|': '0..1', '}|': '1..多', '|{': '1..多', '}o': '0..多', 'o{': '0..多' };
  FZ.arrowLabel = a => a.card ? (a.label ? a.label + '（' : '') + (CARD[a.card.slice(0, 2)] || '?') + ':' + (CARD[a.card.slice(-2)] || '?') + (a.label ? '）' : '') : a.label;
  function erFrom(L, W) {
    const ents = [], byName = new Map(), rels = []; let cur = null; const ent = name => { name = unq(name); let e = byName.get(name); if (!e) { e = { name, attrs: [] }; byName.set(name, e); ents.push(e); } return e; };
    for (const raw of L.slice(1)) { const l = raw.trim(); let m;
      if (cur) { if (l === '}') { cur = null; continue; } const a = l.replace(/\s+/g, ' ').trim(); if (a) cur.attrs.push(a); continue; }
      if ((m = l.match(/^("[^"]+"|[^\s{]+)\s*\{\s*$/))) { cur = ent(m[1]); continue; }
      if ((m = l.match(/^("[^"]+"|\S+)\s+([|o}{]{2}(?:--|\.\.)[|o}{]{2})\s+("[^"]+"|\S+)\s*(?::\s*(.*))?$/))) { rels.push({ a: ent(m[1]), b: ent(m[3]), card: m[2], label: unq(m[4] || '') }); continue; }
      if ((m = l.match(/^("[^"]+"|[\w぀-鿿]+)$/))) ent(m[1]); }
    if (!ents.length) return null; const nodes = ents.map(e => ({ text: [e.name, ...e.attrs].join('\n') }));
    const idx = new Map(ents.map((e, k) => [e, k])); const G = layered(ents.length, rels.map(r => ({ a: idx.get(r.a), b: idx.get(r.b) })));
    const needW = Math.max(...nodes.map(n => longest(n.text) + 2)); let r = G.order.length * (needW + 8) - 8 <= W ? placeLR(nodes, G, W, { gx: 8 }) : null; let dir = 'LR'; if (!r) { r = placeTD(nodes, G, W, { gy: 2, gx: 4 }); dir = 'TD'; } /* 属性が折り返すなら上下に */
    const boxes = ents.map((e, k) => ({ id: k + 1, ...r.pos[k], text: nodes[k].text, kind: 'thin', shade: null, bold: false }));
    const arrows = rels.map(x => ({ from: idx.get(x.a) + 1, to: idx.get(x.b) + 1, label: x.label, kind: x.card.includes('..') ? 'dotted' : 'thin', head: false, card: x.card }));
    return { tag: 'er', dir, h: r.h, boxes, arrows, lanes: null, lines: [], texts: [] }; }
  function erTo(F) { const nm = t => { const s = String(t).split('\n')[0].trim() || 'E'; return /^[A-Za-z0-9_぀-鿿-]+$/.test(s) ? s : q(s); }; const by = new Map(F.boxes.map(b => [b.id, b])); const out = ['erDiagram'];
    for (const b of F.boxes) { const at = String(b.text).split('\n').slice(1).filter(x => x.trim()); if (at.length) { out.push('  ' + nm(b.text) + ' {'); for (const a of at) out.push('    ' + a.trim()); out.push('  }'); } else out.push('  ' + nm(b.text)); }
    for (const a of F.arrows) { const A = by.get(a.from), B = by.get(a.to); if (!A || !B) continue; out.push('  ' + nm(A.text) + ' ' + (a.card || '||--||') + ' ' + nm(B.text) + ' : ' + q(a.label || ' ')); }
    return out; }

  /* ---------- マインドマップ ---------- */
  function mindFrom(L, W) {
    const items = []; for (const raw of L.slice(1)) { const ind = raw.match(/^\s*/)[0].replace(/\t/g, '  ').length; let t = raw.trim().replace(/^::icon\(.*\)$/, ''); if (!t) continue; t = t.replace(/^[\w-]*\s*(\(\(|\(-|\)\)|\(|\[|\{\{|\))([\s\S]*?)(\)\)|-\)|\(\(|\)|\]|\}\}|\()$/, '$2'); items.push({ ind, text: unq(t), kids: [] }); }
    if (!items.length) return null; const root = items[0]; const st = [root]; for (const it of items.slice(1)) { while (st.length > 1 && st[st.length - 1].ind >= it.ind) st.pop(); st[st.length - 1].kids.push(it); st.push(it); }
    const all = []; const depthOf = new Map(); const walk = (n, d) => { n.k = all.length; all.push(n); depthOf.set(n, d); n.kids.forEach(c => walk(c, d + 1)); }; walk(root, 0);
    const D = Math.max(...all.map(n => depthOf.get(n))) + 1, gx = 3, colW = Math.max(4, Math.min(14, Math.floor((W - gx * (D - 1)) / D))); const pos = []; let slot = 0, lastPar = null;
    const place = (n, par) => { const d = depthOf.get(n); const w = Math.min(colW, boxW(n.text, colW)), hh = boxH(n.text, w); const x = d * (colW + gx);
      if (!n.kids.length) { if (lastPar && lastPar !== par) slot += 1; pos[n.k] = { x, y: slot, w, h: hh }; slot += hh; lastPar = par; return; } /* 1.0.14f 同じ親の葉は詰めて積み、親が替わる所だけ 1 行空ける */ n.kids.forEach(c => place(c, n)); const ys = n.kids.map(c => pos[c.k].y + pos[c.k].h / 2); const c = (Math.min(...ys) + Math.max(...ys)) / 2; pos[n.k] = { x, y: Math.max(0, Math.round(c - hh / 2)), w, h: hh }; };
    place(root, null);
    const boxes = all.map(n => ({ id: n.k + 1, ...pos[n.k], text: n.text, kind: n === root ? 'thick' : 'thin', shade: n === root ? 'light' : null, bold: n === root }));
    const arrows = []; all.forEach(n => n.kids.forEach(c => arrows.push({ from: n.k + 1, to: c.k + 1, label: '', kind: 'thin', head: false })));
    return { tag: 'mind', dir: 'LR', h: Math.max(slot, ...boxes.map(b => b.y + b.h)), boxes, arrows, lanes: null, lines: [], texts: [] }; }
  function mindTo(F) { const inc = new Set(F.arrows.map(a => a.to)); const root = F.boxes.find(b => !inc.has(b.id)) || F.boxes[0]; if (!root) return null; const kids = id => F.arrows.filter(a => a.from === id).map(a => F.boxes.find(b => b.id === a.to)).filter(Boolean).sort((a, b) => a.y - b.y);
    const out = ['mindmap', '  root((' + String(root.text).replace(/[()\n]/g, ' ') + '))']; const seen = new Set([root.id]); const walk = (b, d) => { for (const c of kids(b.id)) { if (seen.has(c.id)) continue; seen.add(c.id); out.push('  '.repeat(d + 1) + String(c.text).replace(/\n/g, ' ')); walk(c, d + 1); } }; walk(root, 1); return out; }

  /* ---------- 入口 ---------- */
  FZ.figureFromMermaid = function (text, W) { W = Math.max(20, W || 40); const L = srcLines(text); if (!L.length) return null; const head = L[0].trim(); let F = null;
    try { if (/^(flowchart|graph)\b/i.test(head)) F = flowFrom(L, W); else if (/^sequenceDiagram\b/i.test(head)) F = seqFrom(L, W); else if (/^erDiagram\b/i.test(head)) F = erFrom(L, W); else if (/^mindmap\b/i.test(head)) F = mindFrom(L, W); } catch (e) { F = null; }
    return F ? FZ.normalizeFigure(F) : null; };
  FZ.figureToMermaid = function (F, W) { const r = F.tag === 'seq' ? seqTo(F) : F.tag === 'er' ? erTo(F) : F.tag === 'mind' ? mindTo(F) : null; return r || flowTo(F, W || 40); };
  FZ.mermaidKinds = ['flowchart', 'graph', 'sequenceDiagram', 'erDiagram', 'mindmap'];
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
