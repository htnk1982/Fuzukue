/* 文机 — PowerPoint（.pptx）書き出し
 * 方針：1 ページ＝1 スライド（用紙寸法のまま）。本文は版面の位置に置いた本物のテキストボックス、表は表、図は図形、罫線・網はそのまま線と四角。
 * 番号・記号は PowerPoint の自動番号に写さず本文に焼く（体系の階層を PowerPoint は持てないため）。
 * 資料書式（1.0.10a）：柱の題はスライドのタイトル（プレースホルダー）、機密表示・作成日と作成者・頁番号（スライド番号）・柱の罫は図形、
 * 図版はネイティブの画像（元の色のまま。網点は印刷イメージだけ）と番号・題の箱。文中の図番は「図 1」の文字。 */
(function (FZ) {
  'use strict';
  const M = FZ.M, esc = FZ.xmlEsc;
  const EMU = pt => Math.round(pt * 12700), HP = pt => Math.round(pt * 100);
  const LNW = { thin: 6350, thick: 19050, double: 6350, dotted: 6350, arrow: 9525, none: 0 };
  const GUID = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16).toUpperCase(); });

  const b64u8 = b64 => { if (typeof atob === 'function') { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; } return new Uint8Array(Buffer.from(b64, 'base64')); };
  const MEDIA_EXT = { 'image/png': 'png', 'image/jpeg': 'jpeg', 'image/gif': 'gif' }; // PowerPoint がそのまま開ける画像
  FZ.toPptx = function (doc, opts = {}) {
    const nums = FZ.figureNumbers(doc); const exp = t => FZ.expandRefsText(doc, t, nums); // 図番の字 → 「図 1」
    const model = FZ.exportModel(doc), lay = model.lay, f = model.format, geo = lay.geo, cw = geo.cw, ch = geo.ch; const slideKind = !!geo.slide, HI = lay.headInfo;
    const [bodyFont, boldFont] = FZ.docFonts(f); const SZ = HP(cw);
    const X = col => EMU(geo.left + col * cw), Y = row => EMU(geo.top + (geo.bodyTop + row) * ch), W = cols => EMU(cols * cw), H = rows => EMU(rows * ch);
    const lnXml = (kind, arrow) => kind === 'none' ? '<a:ln><a:noFill/></a:ln>' : `<a:ln w="${LNW[kind] || 6350}"${kind === 'double' ? ' cmpd="dbl"' : ''}><a:solidFill><a:srgbClr val="000000"/></a:solidFill>${kind === 'dotted' ? '<a:prstDash val="sysDash"/>' : ''}${arrow ? '<a:tailEnd type="triangle" w="med" len="med"/>' : ''}</a:ln>`;
    /* 網の文様 → PowerPoint の塗り。網点は灰色、墨は黒、線・格子・点はパターン塗り（a:pattFill） */
    const GRAY = new Proxy({}, { get: (_, id) => FZ.shadeHex ? FZ.shadeHex(id) : 'D9D9D9' }); /* 1.0.15a 網の濃さから同じ灰色に（五階調。Word と同じ） */
    const fillXml = shade => { if (!shade) return '<a:noFill/>'; const sh = FZ.SHADE_BY[shade] || FZ.SHADE_BY.gray; if (sh.kind === 'solid') return `<a:solidFill><a:srgbClr val="${sh.hex || '000000'}"/></a:solidFill>`; if (sh.kind === 'dot') return `<a:solidFill><a:srgbClr val="${GRAY[sh.id] || 'D9D9D9'}"/></a:solidFill>`; return `<a:pattFill prst="${sh.ppt}"><a:fgClr><a:srgbClr val="000000"/></a:fgClr><a:bgClr><a:srgbClr val="FFFFFF"/></a:bgClr></a:pattFill>`; };
    FZ.pptxFill = fillXml; // 試験用
    /* run */
    function rPr(marks, o = {}) {
      const bold = marks & M.BOLD; const font = bold ? boldFont : bodyFont; const sx = FZ.scaleW(marks), sy = FZ.scaleH(marks); // PowerPoint は字幅の比率を持てないので、横長の倍角は縦と横の間の大きさ
      const base = o.sz || SZ; const sz = Math.round(base * Math.max(sy, (sx + sy) / 2));
      const attrs = `lang="ja-JP" altLang="en-US" sz="${sz}"${bold ? ' b="1"' : ''}${marks & M.UNDER2 ? ' u="dbl"' : marks & M.WAVE ? ' u="wavy"' : marks & M.UNDER ? ' u="sng"' : ''}${marks & M.STRIKE2 ? ' strike="dblStrike"' : marks & M.STRIKE ? ' strike="sngStrike"' : ''}`;
      const csh = FZ.shadeOfMarks(marks); const cdark = FZ.inkShade(csh); const hlc = csh ? (cdark ? '000000' : GRAY[csh] || 'D9D9D9') : (o.shade && !FZ.inkShade(o.shade)) ? 'D9D9D9' : null; // 字の網は蛍光ペンの色（文様は持てないので灰色の濃さで）
      const shadow = (marks & M.SHADOW) ? '<a:effectLst><a:outerShdw blurRad="0" dist="38100" dir="2700000" algn="tl" rotWithShape="0"><a:srgbClr val="000000"/></a:outerShdw></a:effectLst>' : ''; // 影文字
      const inner = (marks & M.OUTLINE ? '<a:ln w="6350"><a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:ln><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>' : `<a:solidFill><a:srgbClr val="${o.dark || cdark ? 'FFFFFF' : '000000'}"/></a:solidFill>`) + shadow + (hlc && !(marks & M.OUTLINE) ? `<a:highlight><a:srgbClr val="${hlc}"/></a:highlight>` : '') + `<a:latin typeface="${esc(FZ.officeFont(font).latin)}"/><a:ea typeface="${esc(FZ.officeFont(font).ea)}"/>`;
      const hl = o.url && linkRel(o.url) ? `<a:hlinkClick r:id="${linkRel(o.url)}"/>` : ''; return `<a:rPr ${attrs}>${inner}${hl}</a:rPr>`;
    }
    let slideLinks = null; const linkRel = url => { if (!slideLinks || !FZ.safeUrl(url)) return null; if (!slideLinks.has(url)) slideLinks.set(url, 'rIdL' + (slideLinks.size + 1)); return slideLinks.get(url); };
    const run = (text, marks, o) => exp(text).split('\t').map((t, k) => (k ? `<a:r>${rPr(marks, o)}<a:t>\t</a:t></a:r>` : '') + (t ? `<a:r>${rPr(marks, o)}<a:t>${esc(t)}</a:t></a:r>` : '')).join('');
    /* 段落 → a:p。o.from／o.to：ページをまたぐ段落の、このページの分の文字の範囲。o.cont：前のページからの続き（印なし、続きの行の字下げ）。o.dx：箱の左端からのずれ（引用など） */
    function paraXml(b0, o = {}) {
      let b = b0; const from = o.from || 0, to = o.to == null ? b0.seg.text.length : o.to;
      if (from > 0 || to < b0.seg.text.length) { const sg = b0.seg; const seg = { ...sg, text: sg.text.slice(from, to), marks: sg.marks.slice(from, to) }; if (sg.links) seg.links = sg.links.filter(l => l.end > from && l.start < to).map(l => ({ ...l, start: Math.max(0, l.start - from), end: Math.min(to, l.end) - from })); else delete seg.links;
        const shade = new Map(); for (const [k, v] of b0.shade) if (k >= from && k < to) shade.set(k - from, v); b = { ...b0, seg, shade }; }
      if (o.cont) b = { ...b, marker: null, firstL: b.contL, attrs: { ...b.attrs, style: b.attrs.style === 'speech' ? undefined : b.attrs.style } };
      const a = b.attrs; const pr = []; const dx = o.dx || 0;
      const marL = (b.marker || a.list ? b.firstL : (a.style === 'speech' ? b.contL : b.contL)) + dx; const ind = b.marker ? -(b.firstL - b.marker.col) : (a.style === 'speech' ? -b.contL : b.firstL - b.contL);
      let attrs = ` marL="${W(Math.max(0, marL))}" indent="${W(ind)}" eaLnBrk="1" hangingPunct="${f.hang ? 1 : 0}"`; /* 禁則と句読点のぶら下げは文机の書式どおり */ const algn = { center: 'ctr', right: 'r', justify: 'dist' }[a.align]; if (algn) attrs += ` algn="${algn}"`;
      pr.push(`<a:lnSpc><a:spcPts val="${HP(ch * (b.tall ? 2 : 1))}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:buNone/>`);
      const dark = o.dark; let body = b.marker ? run(b.marker.text, b.marker.marks | 0, { dark: dark || FZ.inkShade(b.shade.get(0)) }) : '';
      const k = a.style === 'speech' ? FZ.speechSplit(b.seg.text) : -1;
      if (k > 0) body += run(b.seg.text.slice(0, k), b.seg.marks[0] | 0, { dark }) + run('\t', 0, { dark }) + FZ.runsOf({ text: b.seg.text.slice(k), marks: b.seg.marks.slice(k) }, null).map(r => run(r.text, r.marks, { dark })).join('');
      else { let off = 0; body += FZ.runsOf(b.seg, b.shade).map(r => { const lk = (r.marks & M.LINK) ? FZ.linkAt(b.seg, off) : null; off += r.text.length; return run(r.text, r.marks, { dark: dark || FZ.inkShade(r.shade), shade: r.shade, url: lk && !lk.image ? lk.url : null }); }).join(''); }
      if (b.node === 'sym' && b.symClose) body += run(b.symClose, b.marker ? b.marker.marks | 0 : 0, { dark }); // 囲み見出しの閉じ
      return `<a:p><a:pPr${attrs}>${pr.join('')}</a:pPr>${body}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`;
    }
    /* 図形 */
    let sid = 2; const nv = (name) => `<p:nvSpPr><p:cNvPr id="${sid++}" name="${esc(name)}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>`;
    const bodyPr = (anchor = 't', ins = 0, grow = false) => `<a:bodyPr wrap="square" lIns="${ins}" tIns="0" rIns="${ins}" bIns="0" anchor="${anchor}">${grow ? '<a:spAutoFit/>' : '<a:noAutofit/>'}</a:bodyPr>`; // grow：文を足すと箱が下へ伸びる（PowerPoint での仕上げ用）
    /* 資料の柱・図表の箱：o = { name, ln, anchor, algn, sz（pt×100）, wrap, scale（0〜1：PowerPoint の自動縮小の倍率）, geom, ph（'title'） } */
    const fitScale = (text, cols, factor) => { const w = FZ.textWidth(text) * factor; return w > cols && w > 0 ? Math.max(0.25, cols / w) : 1; };
    const shapeBox = (x, y, w, h, paras, o = {}) => { const fit = o.scale && o.scale < 1 ? `<a:normAutofit fontScale="${Math.floor(o.scale * 100) * 1000}"/>` : '<a:noAutofit/>';
      const nvx = o.ph ? `<p:nvSpPr><p:cNvPr id="${sid++}" name="${esc(o.name || 'タイトル')}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="${o.ph}"/></p:nvPr></p:nvSpPr>` : nv(o.name || 'テキスト');
      return `<p:sp>${nvx}<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${Math.max(1, w)}" cy="${Math.max(1, h)}"/></a:xfrm><a:prstGeom prst="${o.geom || 'rect'}"><a:avLst/></a:prstGeom>${fillXml(o.fill || null)}${lnXml(o.ln || 'none')}</p:spPr><p:txBody><a:bodyPr wrap="${o.wrap || 'square'}" lIns="0" tIns="0" rIns="0" bIns="0" anchor="${o.anchor || 'ctr'}">${fit}</a:bodyPr><a:lstStyle/>${paras || '<a:p><a:endParaRPr lang="ja-JP"/></a:p>'}</p:txBody></p:sp>`; };
    const simplePara = (body, o = {}) => `<a:p><a:pPr algn="${o.algn || 'l'}" marL="0" indent="0"><a:lnSpc><a:spcPct val="100000"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:buNone/></a:pPr>${body}<a:endParaRPr lang="ja-JP" sz="${o.sz || SZ}"/></a:p>`;
    const txBox = (x, y, w, h, paras, name = 'テキスト', fill = null, ln = 'none', anchor = 't', ins = 0, grow = false) => `<p:sp>${nv(name)}<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${Math.max(1, w)}" cy="${Math.max(1, h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fillXml(fill)}${lnXml(ln)}</p:spPr><p:txBody>${bodyPr(anchor, ins, grow)}<a:lstStyle/>${paras || '<a:p><a:endParaRPr lang="ja-JP"/></a:p>'}</p:txBody></p:sp>`;
    const rectXml = (x, y, w, h, fill, ln) => `<p:sp>${nv('四角')}<p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${Math.max(1, w)}" cy="${Math.max(1, h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fillXml(fill)}${lnXml(ln || 'none')}</p:spPr></p:sp>`;
    /* 1.0.14a プ譜：紙面の組版（FZ.pufuShapes）から、役の札・字の箱（テキストボックス）・取組の囲み・線を頁ごとに 1 つのグループに。紙面の罫・網・段落の箱の代わり */
    const PUFU = FZ.pufuShapes ? FZ.pufuShapes(doc, lay) : []; const pufuLines = new Set(); for (const S of PUFU) for (let q = S.start; q < S.end; q++) pufuLines.add(q);
    const pufuPara = (body, algn) => `<a:p><a:pPr algn="${algn}" marL="0" indent="0" eaLnBrk="1" hangingPunct="${f.hang ? 1 : 0}"><a:lnSpc><a:spcPts val="${HP(ch)}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:buNone/></a:pPr>${body}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`;
    const pufuGroupXml = P => { const items = [];
      for (const r of P.rects) { const paras = (r.paras.length ? r.paras : [{ text: '' }]).map(pa => { let body = ''; if (pa.line != null) { const ln = doc.lines[pa.line]; if (ln) body = (pa.pre ? run(pa.pre, 0, { dark: r.dark }) : '') + ln.segs.map(sg => FZ.runsOf(sg, null).map(x => run(x.text, (x.marks | 0) | (r.bold ? M.BOLD : 0), { dark: r.dark })).join('')).join(''); } else if (pa.text) body = run(pa.text, r.bold ? M.BOLD : 0, { dark: r.dark }); return pufuPara(body, r.align === 'c' ? 'ctr' : 'l'); }).join('');
        const lI = EMU(r.pad * cw), rI = EMU(Math.min(r.pad, 0.15) * cw); /* 右の余白は狭く：Office の字の幅の差を吸う */
        items.push(`<p:sp>${nv(r.name)}<p:spPr><a:xfrm><a:off x="${X(r.x)}" y="${Y(r.y)}"/><a:ext cx="${Math.max(1, W(r.w))}" cy="${Math.max(1, H(r.h))}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fillXml(r.fill)}${lnXml(r.stroke)}</p:spPr><p:txBody><a:bodyPr wrap="square" lIns="${lI}" tIns="0" rIns="${rI}" bIns="0" anchor="t">${r.role === 'tag' ? '<a:noAutofit/>' : '<a:normAutofit/>'}</a:bodyPr><a:lstStyle/>${paras}</p:txBody></p:sp>`); } /* 字の箱は、字を足して溢れたら字を縮める（箱の位置は動かさない） */
      for (const fr of P.frames) items.push(rectXml(X(fr.x), Y(fr.y), W(fr.w), H(fr.h), null, 'thick'));
      for (const l of P.lines) items.push(lineXml(X(l.x1), Y(l.y1), X(l.x2), Y(l.y2), l.head ? 'arrow' : l.kind, !!l.head));
      const x0 = X(P.left), y0 = Y(P.top), cx = W(P.right - P.left), cy = H(P.bottom - P.top);
      return `<p:grpSp><p:nvGrpSpPr><p:cNvPr id="${sid++}" name="プ譜"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="${x0}" y="${y0}"/><a:ext cx="${cx}" cy="${cy}"/><a:chOff x="${x0}" y="${y0}"/><a:chExt cx="${cx}" cy="${cy}"/></a:xfrm></p:grpSpPr>${items.join('')}</p:grpSp>`; };
    const lineXml = (x1, y1, x2, y2, kind, arrow) => { const fh = x2 < x1, fv = y2 < y1; return `<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="${sid++}" name="線"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr><p:spPr><a:xfrm${fh ? ' flipH="1"' : ''}${fv ? ' flipV="1"' : ''}><a:off x="${Math.min(x1, x2)}" y="${Math.min(y1, y2)}"/><a:ext cx="${Math.abs(x2 - x1)}" cy="${Math.abs(y2 - y1)}"/></a:xfrm><a:prstGeom prst="straightConnector1"><a:avLst/></a:prstGeom>${lnXml(kind, arrow)}</p:spPr></p:cxnSp>`; };
    /* 表 */
    function tableXml(b, page, cx = 0) { const on = r => r.page === page && (r.x0 | 0) === cx; /* 2 段組：cx＝段の左端（表の桁は段の中の桁） */
      const own = b.rows.filter(r => on(r.rows[0])); if (!own.length) return '';
      const hs = b.repeatHead && !on(b.rows[0].rows[0]) && own[0].rows[0].y > 0 ? b.rows.slice(0, Math.max(1, Math.min(b.heads || 1, b.rows.length))).filter(r => !own.includes(r)) : []; const head = hs.length ? hs : null; // ページをまたいだ表：見出し行を写す（組版で写した位置に。工程表は見出しの段数ぶん）
      const rows = head ? [...head, ...own] : own;
      const y0 = head ? own[0].rows[0].y - head.reduce((t, hr) => t + hr.rows.reduce((t2, x) => t2 + x.h, 0), 0) : rows[0].rows[0].y, yEnd = rows[rows.length - 1].rows.slice(-1)[0].y + rows[rows.length - 1].rows.slice(-1)[0].h;
      const grid = b.grid; const cols = grid.slice(1).map((c, k) => `<a:gridCol w="${W(c - grid[k])}"/>`).join('');
      const same = (a, c) => Math.abs(a.left - c.left) < 1e-6 && Math.abs(a.right - c.right) < 1e-6; /* 工程表の左の列の見出し：次の行が続きのセルのときだけ縦に結合 */
      const trs = rows.map((r, ri) => {
        const rh = r.rows.reduce((t, x) => t + x.h, 0); const tcs = [];
        for (const c of r.cells) {
          let span = 1; if (c.vm === 'restart') while (rows[ri + span] && rows[ri + span].cells.some(t => t.vm === 'cont' && same(t, c))) span++; /* 縦に結合したセル：続く行の数だけ */
          const vm = span > 1 ? ` rowSpan="${span}"` : c.vm === 'cont' && ri > 0 && rows[ri - 1].cells.some(t => (t.vm === 'restart' || t.vm === 'cont') && same(t, c)) ? ' vMerge="1"' : '';
          const allSegs = c.more ? c.segs.concat(...c.more) : c.segs;
          const paras = (allSegs.length && !c.gp && vm !== ' vMerge="1"') ? allSegs.map(s => `<a:p><a:pPr${c.align !== 'left' ? ` algn="${{ center: 'ctr', right: 'r', justify: 'dist' }[c.align]}"` : ''}${FZ.CELL_BUL.test(s.text) ? ` marL="${W(FZ.textWidth(s.text[0]))}" indent="-${W(FZ.textWidth(s.text[0]))}"` : ''}><a:lnSpc><a:spcPts val="${HP(ch * (r.tall ? 2 : 1))}"/></a:lnSpc></a:pPr>${FZ.runsOf(s, null).map(x => run(x.text, x.marks, { dark: FZ.inkShade(c.shade) })).join('')}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`).join('') : `<a:p><a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`;
          const bd = (tag, k) => k && k !== 'none' ? `<a:${tag} w="${LNW[k] || 6350}"${k === 'double' ? ' cmpd="dbl"' : ''}><a:solidFill><a:srgbClr val="000000"/></a:solidFill>${k === 'dotted' ? '<a:prstDash val="sysDash"/>' : ''}</a:${tag}>` : `<a:${tag}><a:noFill/></a:${tag}>`;
          tcs.push(`<a:tc${vm.startsWith(' rowSpan') ? vm : ''}${c.span > 1 ? ` gridSpan="${c.span}"` : ''}${vm.startsWith(' vMerge') ? vm : ''}><a:txBody><a:bodyPr/><a:lstStyle/>${paras}</a:txBody><a:tcPr marL="0" marR="0" marT="0" marB="0" anchor="t">${bd('lnL', c.borders.l)}${bd('lnR', c.borders.r)}${bd('lnT', c.borders.t)}${bd('lnB', c.borders.b)}${c.shade ? fillXml(c.shade) : '<a:noFill/>'}</a:tcPr></a:tc>`);
          for (let k = 1; k < c.span; k++) tcs.push(`<a:tc hMerge="1"><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="ja-JP"/></a:p></a:txBody><a:tcPr/></a:tc>`);
        }
        return `<a:tr h="${H(rh)}">${tcs.join('')}</a:tr>`;
      }).join('');
      return `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${sid++}" name="表"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="${X(b.left + cx)}" y="${Y(y0)}"/><a:ext cx="${W(b.right - b.left)}" cy="${H(yEnd - y0)}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr/><a:tblGrid>${cols}</a:tblGrid>${trs}</a:tbl></a:graphicData></a:graphic></p:graphicFrame>`;
    }
    /* 図 */
    function figureXml(b) {
      const F = b.F, Wc = b.right - b.left, Hr = F.h, Y0 = b.rows[0].y; const out = [];
      const fx = x => X(b.left + x), fy = y => Y(Y0 + y);
      const box = (x, y, w, h, kind, shade, text, marks, anchor = 'ctr', algn = 'ctr') => { const lines = String(text == null ? '' : text).split('\n'); const paras = lines.map(t => `<a:p><a:pPr algn="${algn}"><a:lnSpc><a:spcPts val="${HP(ch)}"/></a:lnSpc></a:pPr>${t ? run(t, marks, { dark: shade === 'dark' }) : ''}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`).join(''); out.push(txBox(fx(x), fy(y), W(w), H(h), text == null ? '' : paras, '箱', shade, kind || 'none', anchor, Math.round(W(0.25)))); };
      const lanes = FZ.laneGeom(F, Wc, Hr);
      if (lanes) {
        out.push(rectXml(fx(0), fy(0), W(Wc), H(Hr), null, 'thin'));
        if (lanes.dir === 'v') { out.push(rectXml(fx(0), fy(0), W(Wc), H(1), 'gray', 'none')); out.push(lineXml(fx(0), fy(1), fx(Wc), fy(1), 'thin')); lanes.bands.forEach((bd, k) => { if (k > 0) out.push(lineXml(fx(bd.from), fy(0), fx(bd.from), fy(Hr), 'thin')); box(bd.from, 0, bd.to - bd.from, 1, null, null, bd.title, M.BOLD); }); }
        else { out.push(rectXml(fx(0), fy(0), W(2), H(Hr), 'gray', 'none')); out.push(lineXml(fx(2), fy(0), fx(2), fy(Hr), 'thin')); lanes.bands.forEach((bd, k) => { if (k > 0) out.push(lineXml(fx(0), fy(bd.from), fx(Wc), fy(bd.from), 'thin')); box(0, bd.from, 2, bd.to - bd.from, null, null, [...bd.title].join('\n'), M.BOLD); }); }
      }
      for (const bx of F.boxes) box(bx.x, bx.y, bx.w, bx.h, bx.kind === 'store' ? 'thin' : bx.kind, bx.shade, bx.text, bx.bold ? M.BOLD : 0);
      for (const a of F.arrows) { const A = FZ.figureBox(F, a.from), B = FZ.figureBox(F, a.to); if (!A || !B) continue; const segs = FZ.figureRoute(A, B, a.via, a.vp);
        segs.forEach((s, k) => { const last = k === segs.length - 1 && a.head !== false, kind = last ? 'arrow' : a.kind; if (s.k === 'h') out.push(lineXml(fx(s.dir === 'l' ? s.to : s.from), fy(s.y), fx(s.dir === 'l' ? s.from : s.to), fy(s.y), kind, last)); else out.push(lineXml(fx(s.col), fy(s.dir === 'u' ? s.y2 : s.y1), fx(s.col), fy(s.dir === 'u' ? s.y1 : s.y2), kind, last)); });
        const albl = FZ.arrowLabel ? FZ.arrowLabel(a) : a.label; if (albl) { const at = FZ.figureLabelAt(segs, albl, Wc); if (at) box(at.x - 0.5, at.y, at.tw + 1, 1, null, null, albl, 0); } /* 1.0.14f 画面と同じ置き場所 */
      }
      for (const l of F.lines || []) { for (let k = 1; k < l.pts.length; k++) { const last = k === l.pts.length - 1 && l.head; out.push(lineXml(fx(l.pts[k - 1][0]), fy(l.pts[k - 1][1]), fx(l.pts[k][0]), fy(l.pts[k][1]), last ? 'arrow' : l.kind, last)); } if (l.label) { let best = null; for (let k = 1; k < l.pts.length; k++) if (l.pts[k][1] === l.pts[k - 1][1] && (!best || Math.abs(l.pts[k][0] - l.pts[k - 1][0]) > best.w)) best = { x: Math.min(l.pts[k][0], l.pts[k - 1][0]), w: Math.abs(l.pts[k][0] - l.pts[k - 1][0]), y: l.pts[k][1] }; if (best) { const tw = FZ.textWidth(l.label) + 1; box(best.x + best.w / 2 - tw / 2, Math.max(0, Math.round(best.y) - 1), tw, 1, null, null, l.label, 0); } } } /* 1.0.12d */
      for (const t of F.texts || []) box(t.x, t.y, FZ.textWidth(t.text) + 1, 1, null, null, t.text, t.bold ? M.BOLD : 0, 'ctr', 'l');
      const gx = fx(0), gy = fy(0), gw = W(Wc), gh = H(Hr); /* 1.0.15c 流れ図は 1 つのまとまり（箱・線・字は中で直せる） */
      return `<p:grpSp><p:nvGrpSpPr><p:cNvPr id="${sid++}" name="図（流れ図）"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="${gx}" y="${gy}"/><a:ext cx="${gw}" cy="${gh}"/><a:chOff x="${gx}" y="${gy}"/><a:chExt cx="${gw}" cy="${gh}"/></a:xfrm></p:grpSpPr>${out.join('')}</p:grpSp>`;
    }
    /* ページ → スライド */
    const tableLines = new Set(), tableEdges = new Set(); for (const b of model.blocks) if (b.type === 'table') { for (let k = b.a; k <= b.b; k++) tableLines.add(k); tableEdges.add(b.b + 1); }
    const PS = lay.pageStart == null ? 1 : lay.pageStart; const lifted = b => lay.headY != null && b.type === 'para' && b.attrs.style === 'title' && b.i !== lay.coverTitle; /* 柱に引き上げた表題（表紙の題は本文のまま） */
    const units = FZ.structUnits(doc); const slideRelsExtra = [], slideImgs = [], media = new Map(), pptCharts = []; // media：画像の名前 → { file, ext, data }
    const mediaOf = name => { const img = doc.images && doc.images[name]; const ext = img && MEDIA_EXT[img.mime]; if (!ext) return null; if (!media.has(name)) { let data; try { data = b64u8(img.data); } catch { return null; } const k = media.size + 1; let svg = null; if (img.svg) { try { svg = { file: `image${k}.svg`, data: b64u8(img.svg) }; } catch { svg = null; } } media.set(name, { file: `image${k}.${ext}`, ext, data, svg }); } return media.get(name); }; /* 1.0.15c SVG は線画のまま（svgBlip）も */
    /* 柱の題の文字：頁ごと＝そのページの表題の行（無ければ前のページの題）、通し＝題名（無ければ最初の表題の行） */
    const lineText = i => doc.lines[i].segs.map(s => exp(s.text)).join('　');
    const firstTitle = doc.lines.findIndex(l => l.attrs.style === 'title'); const docTitle = (doc.title || (firstTitle >= 0 ? lineText(firstTitle) : '')).trim(); let curTitle = null;
    function headXml(pg, p) {
      const out = []; const HY = HI.HY, HH = HI.HH, S = HI.S;
      if (pg.cover) { if (NUM_PH && lay.cover && f.coverNum) out.push(numPh('slide', p + PS)); /* 表紙：柱なし（頁番号だけ出すこともできる） */
        if (pg.head && (f.coverStyle || f.coverSecret)) { /* 表紙の型・機密表示：組版の柱の字を行ごとの箱に、枠（機密・目次）は線の四角に */
          for (const b of pg.head.boxes) if (b !== HI.pageBox) out.push(shapeBox(X(b.col), Y(b.y), W(b.w), H(b.h), '', { name: b.coverToc ? '目次の枠' : '機密表示の枠', ln: 'thin' }));
          const rows = new Map(); for (const g of pg.head.glyphs) { if (HI.pageBox && g.col >= HI.pageBox.col - 1e-6 && g.y >= HI.pageBox.y - 1e-6 && g.y < HI.pageBox.y + HI.pageBox.h) continue; const k = g.y.toFixed(2); if (!rows.has(k)) rows.set(k, []); rows.get(k).push(g); }
          for (const gs of rows.values()) { gs.sort((a, b) => a.col - b.col); let t = '', c0 = gs[0].col, end = c0; for (const g of gs) { if (g.col - end > 0.25) t += ' '; t += g.text; end = g.col + g.w; } const g0 = gs[0]; const sz = Math.round(SZ * (g0.sx || 1));
            out.push(shapeBox(X(c0), Y(g0.y), W(end - c0 + 0.5), H(g0.h || 1), simplePara(run(t, g0.marks | 0, { sz }), { sz }), { name: g0.cover ? '表紙' : '機密表示', anchor: 'ctr', wrap: 'none' })); } }
        return out.join(''); }
      let tl = null; if (lay.headY != null && pg.titleLine != null) { tl = pg.titleLine; curTitle = tl; } else if (lay.headY != null && curTitle != null) tl = curTitle;
      const tsz = Math.round(SZ * S); let paras, text;
      if (tl != null) { const ln = doc.lines[tl]; const thin = !!ln.attrs.thin; text = lineText(tl); paras = simplePara(ln.segs.map(s => FZ.runsOf(s, null).map(r => run(r.text, thin ? r.marks : (r.marks | M.BOLD), { sz: tsz })).join('')).join(run('　', 0, { sz: tsz })), { sz: tsz }); }
      else { text = docTitle; paras = simplePara(text ? run(text, M.BOLD, { sz: tsz }) : '', { sz: tsz }); }
      out.push(shapeBox(X(0), Y(HY), W(HI.titleMax), H(HH), paras, { ph: 'title', name: 'タイトル 1', anchor: 'ctr', wrap: 'square', scale: fitScale(text, HI.titleMax, S) }));
      const ssz = Math.round(SZ * HI.S2);
      if (HI.secretBox) { const b = HI.secretBox; out.push(shapeBox(X(b.col), Y(b.y), W(b.w), H(b.h), simplePara(run(b.text, 0, { sz: ssz }), { algn: 'ctr', sz: ssz }), { name: '機密表示', ln: 'thin', anchor: 'ctr', wrap: 'none' })); }
      for (const l of HI.lines) out.push(shapeBox(X(l.col), Y(l.y), W(l.w + 0.5), H(l.h), simplePara(run(l.text, 0, { sz: ssz }), { sz: ssz }), { name: '作成日・作成者', anchor: 'ctr', wrap: 'none' }));
      if (NUM_PH) out.push(numPh('slide', p + PS)); // 頁番号：PowerPoint のスライド番号（自動採番）
      out.push(lineXml(X(0), Y(HY + HH), X(geo.cols), Y(HY + HH), f.headRule === 'thick' ? 'thick' : 'thin'));
      return out.join('');
    }
    /* 図版：番号と題の箱＋画像（欄の中で縦横比を保って中央）。画像が書き出せない種類（SVG 等）は破線の枠と名前 */
    function figsXml(pg, p) {
      const out = []; const ims = (pg.images || []).concat(pg.side ? pg.side.images : []); const rel = slideImgs[p] = new Map();
      for (const im of ims) { const n = nums.get(im.id); const cap = (n ? n.label : (im.kind || '図')) + (im.title ? '　' + im.title : '');
        out.push(shapeBox(X(im.col), Y(im.y - 1), W(im.w), H(1), simplePara(run(cap, M.BOLD), {}), { name: n ? n.label : '図表', anchor: 'ctr', wrap: 'none', scale: fitScale(cap, im.w, 1) }));
        if (im.chart && FZ.chartDml && !FZ.chartNative(im.chart)) { const Wp = im.w * cw, Hp = im.h * ch; const kids = FZ.chartDml(im.chart, Wp, Hp, geo.fs, { host: 'p', id: () => sid++, font: FZ.officeFont(boldFont) }); /* 1.0.11f Excel に無い形（滝・段々・左右・階段・矢印）は図形の組 */
          out.push(`<p:grpSp><p:nvGrpSpPr><p:cNvPr id="${sid++}" name="${esc(n ? n.label : 'グラフ')}" descr="${esc(cap)}"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="${X(im.col)}" y="${Y(im.y)}"/><a:ext cx="${W(im.w)}" cy="${H(im.h)}"/><a:chOff x="0" y="0"/><a:chExt cx="${EMU(Wp)}" cy="${EMU(Hp)}"/></a:xfrm></p:grpSpPr>${kids}</p:grpSp>`); continue; }
        if (im.chart && FZ.chartXml) { const cn = pptCharts.length + 1; const rid = 'rIdC' + cn; const of = FZ.officeFont(boldFont); pptCharts.push({ n: cn, slide: p, rid, xml: FZ.chartXml(im.chart, { latin: of.latin, ea: of.ea, sz: Math.max(700, Math.round(SZ * 0.82)), ext: 'rId1' }), xlsx: FZ.chartXlsx(im.chart) }); /* グラフ：編集できるグラフ（データは埋め込みの Excel） */
          out.push(`<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${sid++}" name="${esc(n ? n.label : 'グラフ')}" descr="${esc(cap)}"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="${X(im.col)}" y="${Y(im.y)}"/><a:ext cx="${W(im.w)}" cy="${H(im.h)}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="${rid}"/></a:graphicData></a:graphic></p:graphicFrame>`); continue; }
        const img = doc.images && doc.images[im.file]; const md = img ? mediaOf(im.file) : null; const bw = im.w * cw, bh = im.h * ch;
        if (md) { const sz = FZ.imageSize(img); const sc = Math.min(bw / sz.w, bh / sz.h); const w = sz.w * sc, h = sz.h * sc; const x = geo.left + im.col * cw + (bw - w) / 2, y = geo.top + (geo.bodyTop + im.y) * ch + (bh - h) / 2;
          if (!rel.has(im.file)) rel.set(im.file, 'rIdI' + (rel.size + 1));
          out.push(`<p:pic><p:nvPicPr><p:cNvPr id="${sid++}" name="${esc(n ? n.label : '画像')}" descr="${esc(cap)}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${rel.get(im.file)}">${md.svg ? `<a:extLst><a:ext uri="{96DAC541-7B7A-43D3-8B79-37D633B846F1}"><asvg:svgBlip xmlns:asvg="http://schemas.microsoft.com/office/drawing/2016/SVG/main" r:embed="${rel.get(im.file) + 'S'}"/></a:ext></a:extLst>` : ''}</a:blip><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${EMU(x)}" y="${EMU(y)}"/><a:ext cx="${EMU(w)}" cy="${EMU(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`); }
        else out.push(shapeBox(X(im.col), Y(im.y), W(im.w), H(im.h), simplePara(run(img ? '（' + im.file + '：この形式の画像は書き出せません）' : '（画像なし）', 0, { sz: Math.round(SZ * 0.8) }), { algn: 'ctr', sz: Math.round(SZ * 0.8) }), { name: '画像なし', ln: 'dotted', anchor: 'ctr' })); }
      if (pg.side) for (const r of pg.side.rules) out.push(lineXml(X(r.col), Y(r.y1), X(r.col), Y(r.y2), r.kind));
      return out.join('');
    }
    /* スライド番号のプレースホルダーの置き場所（全スライド共通） */
    const NUM_FLD = GUID(); const NUM_PH = (() => {
      const pb = slideKind && HI ? HI.pageBox : null;
      if (pb) { const circle = pb.shape === 'circle'; let bx = pb.col, by = pb.y, bw = pb.w, bh = pb.h; if (circle) { const d = Math.min(pb.w * cw, pb.h * ch); bw = d / cw; bh = d / ch; bx = pb.col + (pb.w - bw) / 2; by = pb.y + (pb.h - bh) / 2; }
        return { x: X(bx), y: Y(by), w: W(bw), h: H(bh), geom: circle ? 'ellipse' : 'rect', ln: 'thin', footer: false }; }
      if (!slideKind && geo.footerRows > 0 && /\{page\}/.test(f.footer || '')) return { x: EMU(geo.left), y: EMU(geo.top + geo.footerTop * ch), w: W(geo.cols), h: H(1), geom: 'rect', ln: 'none', footer: true };
      return null; })();
    /* ページごとに全部の段落をなめると「頁数×段落数」になる（6 万行・1667 頁で 14 秒）。段落は文書の順にページが進むので、
     * 各段落の最初と最後のページを先に求め、ページごとに「そのページにかかる段落」だけを見る。前のページで終わった段落は、節の名前の引き継ぎだけ当てる */
    const BL = model.blocks; const blkPg = BL.map(b => { let fp = -1, lp = -1;
      if (b.type === 'para') { const rs = lay.lineMap[b.i] ? (lifted(b) ? lay.lineMap[b.i].rows : lay.lineMap[b.i].segs[0].rows) : []; if (rs.length) { fp = rs[0].page; lp = rs[rs.length - 1].page; } }
      else if (b.type === 'table') { for (const r of b.rows) for (const x of r.rows) { if (fp < 0 || x.page < fp) fp = x.page; if (x.page > lp) lp = x.page; } }
      else for (const r of b.rows || []) { if (fp < 0 || r.page < fp) fp = r.page; if (r.page > lp) lp = r.page; }
      return [fp, lp]; });
    for (let k = 0, last = 0; k < BL.length; k++) { if (blkPg[k][0] < 0) blkPg[k] = [last, last]; else last = blkPg[k][1]; } // 置かれていない段落は前の段落のページに
    let bStart = 0, carrySec = null; 
    const carry = b => { if (lifted(b)) carrySec = null; else if (b.type === 'para' && units[b.i] === 1) carrySec = (((b.marker ? b.marker.text : '') + exp(b.seg.text) + (b.symClose || '')).replace(/\s+/g, ' ').trim().slice(0, 40)) || '見出し'; };
    const slides = lay.pages.map((pg, p) => {
      while (bStart < BL.length && blkPg[bStart][1] < p) carry(BL[bStart++]);
      sid = 2; const sh = []; slideLinks = new Map(); slideRelsExtra[p] = slideLinks;
      if (slideKind && HI) sh.push(headXml(pg, p)); // 資料の柱（タイトルを最初の図形に：読み上げ順・アウトライン）
      // 網（表・図以外）
      const pufuDone = new Set(); /* この頁で出したプ譜（節ごと） */
      for (const x of pg.fills) if (!x.fig && !tableLines.has(x.from) && !(x.deco && pufuLines.has(x.from))) sh.push(rectXml(X(x.col), Y(x.y1), W(x.cols), H(x.y2 - x.y1), x.shade, 'none'));
      // 柱
      if (geo.headerRows > 0 && f.header && !slideKind) sh.push(txBox(EMU(geo.left), EMU(geo.top), W(geo.cols), H(1), hfPara(f.header, 'l', p + PS), '柱上'));
      if (geo.footerRows > 0 && f.footer) sh.push(NUM_PH && NUM_PH.footer ? numPh('slide', p + PS) : txBox(EMU(geo.left), EMU(geo.top + geo.footerTop * ch), W(geo.cols), H(1), hfPara(f.footer, 'ctr', p + PS), '柱下')); // {page} を含む柱下はスライド番号のプレースホルダーに
      // 本文：連続する段落をひとつのテキストボックスに（同じページ・同じ段）
      /* 本文の箱：文章の構造の単位（見出し 1 つ＋その本文・箇条書き）を 1 つのテキストボックスに。見出し（表題・数字見出し・記号見出し。レベルを問わない）で新しい箱。
         空行は空きなので箱を切らない（箱の末尾の空行は捨てる）。表・図・目次・本文の流れの画像で途切れたら、その後は同じ節の「続き」の箱。ページをまたぐ段落はページごとに分ける。
         箱の名前は見出しの文字（PowerPoint の選択ウィンドウで節が分かる） */
      const C2 = !!geo.cols2; let curSec = carrySec; let group = null; let cx = 0; const onPC = r => r.page === p && (!C2 || (r.x0 | 0) === cx), before = r => r.page < p || (C2 && r.page === p && (r.x0 | 0) < cx); /* 2 段組：左の段・右の段の順に、段ごとに箱を作る */ const flushG = () => { if (!group) return; sh.push(txBox(X(group.left), Y(group.y0), W(group.right - group.left + 0.25), H(group.y1 - group.y0), group.paras.map(q => q.xml(group.left)).join(''), group.name, null, 'none', 't', 0, true)); group = null; }; /* 幅に 1/4 マスの余裕：丸めで行末の 1 字が次の行へ落ちないように（半角 1 字は入らない幅） */
      const isSection = b => units[b.i] === 1; // 文章の構造の単位の頭（FZ.structUnits）
      const secName = b => (((b.marker ? b.marker.text : '') + exp(b.seg.text) + (b.symClose || '')).replace(/\s+/g, ' ').trim().slice(0, 40)) || '見出し';
      for (const cx0 of C2 ? [0, geo.colX2] : [0]) { cx = cx0; flushG(); if (cx) curSec = carrySec;
      for (let bk = bStart; bk < BL.length; bk++) { const b = BL[bk]; if (blkPg[bk][0] > p) break;
        if (lifted(b)) { if (lay.lineMap[b.i].rows[0].page <= p) curSec = null; continue; } // 柱に引き上げた表題は柱のタイトルで出した（節の名前はそこで切る）
        if (lay.cover && f.coverStyle && b.type === 'para' && b.i === lay.coverTitle) { flushG(); const rr = lay.lineMap[b.i].rows.filter(onPC); if (rr.length) { const y0 = rr[0].y, y1 = Math.max(...rr.map(r => r.y + r.h)); const big = !b.seg.marks.some(m => (m & FZ.SIZE_BITS)); const tsz = big ? SZ * 2 : SZ; /* 表紙の型の題：全幅の中央、四倍角相当の大きさ */
          sh.push(shapeBox(X(0), Y(y0), W(geo.cols), H(y1 - y0), simplePara(FZ.runsOf(b.seg, null).map(r => run(r.text, r.marks | M.BOLD, { sz: big ? tsz : undefined })).join(''), { algn: 'ctr', sz: tsz }), { name: '表紙の題', anchor: 'ctr', wrap: 'square' })); } continue; }
        if (b.type === 'para' && pufuLines.has(b.i)) { const S = PUFU.find(x => b.i >= x.start && b.i < x.end); const P = S && S.pages.find(x => x.page === p); if (P && !pufuDone.has(S.start)) { flushG(); pufuDone.add(S.start); sh.push(pufuGroupXml(P)); } continue; } /* プ譜：図形のグループ */
        if (b.type === 'para') { // 段落：このページにある行の分
          const segRows = lay.lineMap[b.i].segs[0].rows; if (isSection(b) && segRows.length && before(segRows[0])) curSec = secName(b); /* 前のページ（前の段）から続く節の名前 */ const here = segRows.filter(onPC); if (!here.length) continue;
          const bdx = C2 ? (here[0].x0 | 0) - (segRows[0].x0 | 0) : 0, bL = b.left + bdx, bR = b.right + bdx;
          const first = here[0].k === 0, y0 = here[0].y, y1 = Math.max(...here.map(r => r.y + r.h)); const opts = { from: here[0].startOff, to: here[here.length - 1].endOff, cont: !first, dark: FZ.inkShade(b.lineFill) };
          const empty = b.seg.text === '' && !b.marker && !b.lineFill && !b.rules.top && !b.rules.bottom; const sec = isSection(b) && first;
          if (sec) curSec = secName(b);
          if (empty) { if (group) group.pend.push({ y1 }); continue; } // 空行：次に文が来たら箱に入れる
          if (group && (sec || (group.pend.length ? group.pend[group.pend.length - 1].y1 : group.y1) !== y0)) flushG();
          if (!group) group = { left: bL, right: bR, y0, y1: y0, paras: [], pend: [], name: sec ? curSec : (curSec ? curSec + '（続き）' : '本文') };
          for (const q of group.pend) group.paras.push({ xml: () => `<a:p><a:pPr marL="0" indent="0"><a:lnSpc><a:spcPts val="${HP(ch)}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:buNone/></a:pPr><a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>` });
          if (group.pend.length) group.y1 = group.pend[group.pend.length - 1].y1; group.pend = [];
          group.left = Math.min(group.left, bL); group.right = Math.max(group.right, bR); group.paras.push({ xml: L0 => paraXml(b, { ...opts, dx: bL - L0 }) }); group.y1 = Math.max(group.y1, y1); continue; }
        const r0 = b.rows[0]; if (!r0 || !onPC(b.type === 'table' ? r0.rows[0] : r0)) { if (b.type === 'table' && b.rows.some(r => onPC(r.rows[0]))) { flushG(); sh.push(tableXml(b, p, cx)); } continue; }
        const rowsHere = b.rows.filter(r => onPC(b.type === 'table' ? r.rows[0] : r)); const yEnd = Math.max(...rowsHere.map(r => r.y + r.h));
        if (b.type === 'table') { flushG(); sh.push(tableXml(b, p, cx)); continue; }
        if (b.type === 'figure') { flushG(); sh.push(figureXml(b)); continue; }
        if (b.type === 'toc') { flushG(); const rh = b.rows.find(onPC); if (!rh) continue; // 目次：このページにある分の行。見出しの箱と頁番号の箱（右寄せ）を同じ行送りで並べる
          const per = b.rows.filter(before).reduce((t, r) => t + r.h, 0); const es = b.entries.slice(per, per + rh.h); const list = es.length ? es : [{ indent: 0, marker: '', text: '（目次：載せる見出しがありません）', page: '' }];
          const pPr = (e, algn) => `<a:pPr marL="${W(e.indent | 0)}" indent="0"${algn ? ` algn="${algn}"` : ''}><a:lnSpc><a:spcPts val="${HP(ch)}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:buNone/></a:pPr>`;
          const left = list.map(e => `<a:p>${pPr(e)}${run(e.close ? e.marker + e.text + e.close : (e.marker ? e.marker + ' ' : '') + e.text, 0, {})}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`).join('');
          const right = list.map(e => `<a:p>${pPr({ indent: 0 }, 'r')}${e.page ? run(String(e.page), 0, {}) : ''}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`).join('');
          const tdx = C2 ? (rh.x0 | 0) - (b.rows[0].x0 | 0) : 0; const wN = Math.min(3, b.right - b.left); sh.push(txBox(X(b.left + tdx), Y(rh.y), W(b.right - b.left - wN), H(rh.h), left, '目次')); sh.push(txBox(X(b.right + tdx - wN), Y(rh.y), W(wN), H(rh.h), right, '目次頁')); continue; }
      } }
      flushG();
      for (const g of pg.glyphs) if (g.deco && g.off === -1 && /^[→↓▶▼]$/.test(g.text)) sh.push(shapeBox(X(g.col), Y(g.y), W(g.w || 1), H(g.h || 1), simplePara(run(g.text, 0, {}), { algn: 'ctr' }), { name: '区画のつなぎ', anchor: 'ctr', wrap: 'none' })); /* 1.0.12f 区画の間の矢印・三角 */
      sh.push(figsXml(pg, p));
      /* 工程表：矢羽根は五角形（網・名前入り）、◆ はひし形と名前の箱、基準は点線（どれも図形で動かせる・直せる） */
      for (const g of pg.shapes || []) { const ya = g.y + g.h * 0.18, yb = g.y + g.h * 0.82;
        if (g.kind === 'bar') sh.push(shapeBox(X(g.x0), Y(ya), W(g.x1 - g.x0), H(yb - ya), simplePara(g.label ? run(g.label, M.BOLD, {}) : ''), { name: '矢羽根' + (g.label ? ' ' + g.label : ''), geom: 'homePlate', fill: 'gray', ln: 'thin', anchor: 'ctr', wrap: 'none' }));
        else if (g.kind === 'ms') { const r = Math.min(g.h * 0.34, 0.5); sh.push(shapeBox(X(g.x - r * ch / cw), Y(g.y + g.h / 2 - r), W(2 * r * ch / cw), H(2 * r), '', { name: 'マイルストーン' + (g.label ? ' ' + g.label : ''), geom: 'diamond', fill: 'dark', ln: 'none' })); if (g.label) { const tw = Math.max(2, FZ.textWidth(g.label) + 0.5), dx = r * ch / cw + 0.15, lft = g.xr != null && g.x + dx + tw > g.xr && g.x - dx - tw >= 0; sh.push(txBox(X(lft ? g.x - dx - tw : g.x + dx), Y(g.y), W(tw), H(g.h), simplePara(run(g.label, M.BOLD, {}), lft ? { algn: 'r' } : {}), 'マイルストーンの名前', null, 'none', 'ctr')); } }
        else if (g.kind === 'base') sh.push(lineXml(X(g.x), Y(g.y), X(g.x), Y(g.y + g.h), 'dotted')); }
      // 罫線（表・図以外。見出しの下線・囲み・手描きの線）
      for (const r of pg.hrules) if (!r.fig && !(r.deco && pufuLines.has(r.line)) && (r.sec || (!tableLines.has(r.line) && !tableEdges.has(r.line)))) sh.push(r.kind === 'arrow' && r.dir === 'l' ? lineXml(X(r.to), Y(r.y), X(r.from), Y(r.y), 'arrow', true) : lineXml(X(r.from), Y(r.y), X(r.to), Y(r.y), r.kind, r.kind === 'arrow'));
      for (const r of pg.vrules) if (!r.fig && !(r.deco && pufuLines.has(r.from)) && !tableLines.has(r.from)) sh.push(lineXml(X(r.col), Y(r.dir === 'u' ? r.y2 : r.y1), X(r.col), Y(r.dir === 'u' ? r.y1 : r.y2), r.kind === 'arrow' ? 'arrow' : r.kind, r.kind === 'arrow'));
      return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${sh.join('')}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
    });
    /* スライド番号のプレースホルダー（PowerPoint の「ヘッダーとフッター」のスライド番号）。マスターとレイアウトに置き場所・形・文字の大きさを持ち、各スライドは同じ置き場所の
     * プレースホルダーに番号の欄（a:fld slidenum）を入れる。スライドを足す・消す・並べ替えると PowerPoint が番号を振り直し、新しいスライドにも番号が付く。
     * 資料書式＝柱の頁番号の箱（四角・丸）、文書＝{page} を含む柱下（{pages} の総数は PowerPoint に欄が無いので書き出したときの数） */
    function numPh(where, pageNo) {
      const P = NUM_PH; const idx = where === 'master' ? 4 : 12; const num = where === 'slide' ? String(pageNo) : '‹#›';
      const fld = `<a:fld id="{${NUM_FLD}}" type="slidenum">${rPr(0)}<a:t>${num}</a:t></a:fld>`;
      const para = P.footer ? hfPara(f.footer, 'ctr', num, fld) : `<a:p><a:pPr algn="ctr"/>${fld}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`;
      return `<p:sp><p:nvSpPr><p:cNvPr id="${where === 'slide' ? sid++ : 3}" name="スライド番号プレースホルダー ${idx}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldNum" sz="quarter" idx="${idx}"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${P.x}" y="${P.y}"/><a:ext cx="${Math.max(1, P.w)}" cy="${Math.max(1, P.h)}"/></a:xfrm><a:prstGeom prst="${P.geom}"><a:avLst/></a:prstGeom><a:noFill/>${lnXml(P.ln)}</p:spPr><p:txBody><a:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></a:bodyPr><a:lstStyle><a:lvl1pPr algn="ctr"><a:defRPr sz="${SZ}"/></a:lvl1pPr></a:lstStyle>${para}</p:txBody></p:sp>`;
    }
    /* PowerPoint には総スライド数の欄が無いので、{pages}（総数）は前後の区切り（／・-・of など）ごと省いて番号だけにする（足し引きで古い数が残らない）。{file} はファイル名 */
    function noPages(t) { return String(t).replace(/\s*(?:[\/／|｜\-‐–—]|of)\s*\{pages\}/g, '').replace(/\{pages\}\s*(?:[\/／|｜\-‐–—]|中|of)?\s*/g, '').replace(/\{file\}/g, doc.fileName || ''); }
    function hfPara(text, algn, pageNo, fld) { const parts = noPages(text).split(/(\{page\}|\{pages\})/); const rs = parts.map(t => t === '{page}' ? (fld || `<a:fld id="{${GUID()}}" type="slidenum">${rPr(0)}<a:t>${pageNo}</a:t></a:fld>`) : t === '{pages}' ? run(String(lay.pages.length), 0) : t ? run(t, 0) : '').join(''); return `<a:p><a:pPr algn="${algn}"><a:lnSpc><a:spcPts val="${HP(ch)}"/></a:lnSpc></a:pPr>${rs}<a:endParaRPr lang="ja-JP" sz="${SZ}"/></a:p>`; }
    /* パッケージ */
    const CX = EMU(geo.W), CY = EMU(geo.H);
    const theme = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="文机"><a:themeElements><a:clrScheme name="文机"><a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F1F1F"/></a:dk2><a:lt2><a:srgbClr val="E4E4E4"/></a:lt2><a:accent1><a:srgbClr val="1A56C4"/></a:accent1><a:accent2><a:srgbClr val="C81E1E"/></a:accent2><a:accent3><a:srgbClr val="444444"/></a:accent3><a:accent4><a:srgbClr val="888888"/></a:accent4><a:accent5><a:srgbClr val="AAAAAA"/></a:accent5><a:accent6><a:srgbClr val="CCCCCC"/></a:accent6><a:hlink><a:srgbClr val="1A56C4"/></a:hlink><a:folHlink><a:srgbClr val="888888"/></a:folHlink></a:clrScheme><a:fontScheme name="文机"><a:majorFont><a:latin typeface="${esc(FZ.officeFont(boldFont).latin)}"/><a:ea typeface="${esc(FZ.officeFont(boldFont).ea)}"/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="${esc(FZ.officeFont(bodyFont).latin)}"/><a:ea typeface="${esc(FZ.officeFont(bodyFont).ea)}"/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="文机"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>`;
    /* 資料書式：マスターとレイアウトにタイトルのプレースホルダー（柱の題の位置）。スライドの題が PowerPoint のアウトライン・読み上げに出る */
    const titlePh = slideKind && HI ? `<p:sp><p:nvSpPr><p:cNvPr id="2" name="タイトル プレースホルダー 1"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${X(0)}" y="${Y(HI.HY)}"/><a:ext cx="${W(HI.titleMax)}" cy="${H(HI.HH)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:normAutofit/></a:bodyPr><a:lstStyle/><a:p><a:r><a:rPr lang="ja-JP"/><a:t>タイトル</a:t></a:r></a:p></p:txBody></p:sp>` : '';
    const master = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${titlePh}${NUM_PH ? numPh('master') : ''}</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:hf hdr="0" ftr="0" dt="0"${NUM_PH ? '' : ' sldNum="0"'}/><p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="${slideKind && HI ? Math.round(SZ * HI.S) : SZ}" b="${slideKind ? 1 : 0}"><a:latin typeface="${esc(FZ.officeFont(boldFont).latin)}"/><a:ea typeface="${esc(FZ.officeFont(boldFont).ea)}"/></a:defRPr></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="${SZ}"/></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:lvl1pPr><a:defRPr sz="${SZ}"><a:latin typeface="${esc(FZ.officeFont(bodyFont).latin)}"/><a:ea typeface="${esc(FZ.officeFont(bodyFont).ea)}"/></a:defRPr></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>`;
    const layout = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="${titlePh ? 'titleOnly' : 'blank'}" preserve="1"><p:cSld name="${titlePh ? 'タイトルのみ' : '白紙'}"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${titlePh}${NUM_PH ? numPh('layout') : ''}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr><p:hf hdr="0" ftr="0" dt="0"${NUM_PH ? '' : ' sldNum="0"'}/></p:sldLayout>`;
    const n = slides.length;
    /* 付箋 → PowerPoint のコメント（旧形式：commentAuthors.xml と comments/commentN.xml。位置は行の右端（1/576 インチ）、返信は本文の段落、解決は頭に［解決済み］） */
    const cmAuthors = new Map(), slideCm = new Map(); { const NL = new Map(); doc.lines.forEach((l, i) => { for (const id of l.attrs.notes || []) if (!NL.has(id)) NL.set(id, i); });
      const dtOf = t => { const m = String(t || '').match(/^(\d{4}-\d{2}-\d{2})(?:T(\d{2}:\d{2}))?/); return m ? m[1] + 'T' + (m[2] || '00:00') + ':00.000' : new Date().toISOString().slice(0, 23); };
      for (const nt of doc.notes || []) { const i = NL.get(nt.id); const m = i != null && lay.lineMap[i]; const r = m && ((m.rows && m.rows[0]) || (m.segs && m.segs[0] && m.segs[0].rows && m.segs[0].rows[0])); if (!r || r.page == null || r.page >= slides.length) continue;
        const who = nt.author || '文机'; if (!cmAuthors.has(who)) cmAuthors.set(who, { id: cmAuthors.size, last: 0 }); const au = cmAuthors.get(who); au.last++;
        const body = [(nt.done ? '［解決済み］' : '') + (nt.quote ? '「' + nt.quote + '」' : '')].filter(Boolean).concat(String(nt.text || '').split('\n'), (nt.replies || []).map(rp => '→ ' + (rp.author || '') + '（' + String(rp.date || '').replace('T', ' ') + '）：' + (rp.text || '')));
        const pos = v => Math.round(v / 1587.5); if (!slideCm.has(r.page)) slideCm.set(r.page, []);
        slideCm.get(r.page).push(`<p:cm authorId="${au.id}" dt="${dtOf(nt.date)}" idx="${au.last}"><p:pos x="${pos(X(Math.max(0, geo.cols - 1)))}" y="${pos(Y(r.y))}"/><p:text>${esc(body.join('\n'))}</p:text></p:cm>`); } }
    const PNS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
    const presentation = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" saveSubsetFonts="1"${PS !== 1 ? ` firstSlideNum="${PS}"` : ''}><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rIdM"/></p:sldMasterIdLst><p:sldIdLst>${slides.map((_, k) => `<p:sldId id="${256 + k}" r:id="rIdS${k + 1}"/>`).join('')}</p:sldIdLst><p:sldSz cx="${CX}" cy="${CY}"/><p:notesSz cx="6858000" cy="9144000"/><p:defaultTextStyle><a:defPPr><a:defRPr lang="ja-JP"/></a:defPPr></p:defaultTextStyle></p:presentation>`;
    const presRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdM" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>${slides.map((_, k) => `<Relationship Id="rIdS${k + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${k + 1}.xml"/>`).join('')}<Relationship Id="rIdT" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/><Relationship Id="rIdP" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps" Target="presProps.xml"/><Relationship Id="rIdB" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles" Target="tableStyles.xml"/>${cmAuthors.size ? '<Relationship Id="rIdCA" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/commentAuthors" Target="commentAuthors.xml"/>' : ''}</Relationships>`;
    const ct = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${[...new Set([...media.values()].map(m => m.ext))].map(e => `<Default Extension="${e}" ContentType="image/${e}"/>`).join('')}${[...media.values()].some(m => m.svg) ? '<Default Extension="svg" ContentType="image/svg+xml"/>' : ''}<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/presProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presProps+xml"/><Override PartName="/ppt/tableStyles.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>${slides.map((_, k) => `<Override PartName="/ppt/slides/slide${k + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`).join('')}${cmAuthors.size ? '<Override PartName="/ppt/commentAuthors.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.commentAuthors+xml"/>' : ''}${[...slideCm.keys()].map(k => `<Override PartName="/ppt/comments/comment${k + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.comments+xml"/>`).join('')}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>${pptCharts.length ? '<Default Extension="xlsx" ContentType="' + FZ.XLSX_CT + '"/>' : ''}${pptCharts.map(x => `<Override PartName="/ppt/charts/chart${x.n}.xml" ContentType="${FZ.CHART_CT}"/>`).join('')}</Types>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${esc(doc.title || '')}</dc:title><dc:creator>文机</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</dcterms:created></cp:coreProperties>`;
    const slideRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>`;
    const files = [
      { name: '[Content_Types].xml', data: ct }, { name: '_rels/.rels', data: rels }, { name: 'docProps/core.xml', data: core },
      { name: 'ppt/presentation.xml', data: presentation }, { name: 'ppt/_rels/presentation.xml.rels', data: presRels },
      { name: 'ppt/presProps.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentationPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>` },
      { name: 'ppt/tableStyles.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>` },
      { name: 'ppt/slideMasters/slideMaster1.xml', data: master }, { name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>` },
      { name: 'ppt/slideLayouts/slideLayout1.xml', data: layout }, { name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>` },
      { name: 'ppt/theme/theme1.xml', data: theme },
    ];
    if (cmAuthors.size) files.push({ name: 'ppt/commentAuthors.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:cmAuthorLst ${PNS}>` + [...cmAuthors.entries()].map(([nm, au]) => `<p:cmAuthor id="${au.id}" name="${esc(nm)}" initials="${esc(nm.slice(0, 1))}" lastIdx="${au.last}" clrIdx="${au.id % 8}"/>`).join('') + '</p:cmAuthorLst>' });
    for (const [k, list] of slideCm) files.push({ name: `ppt/comments/comment${k + 1}.xml`, data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:cmLst ${PNS}>${list.join('')}</p:cmLst>` });
    for (const m of media.values()) { files.push({ name: 'ppt/media/' + m.file, data: m.data }); if (m.svg) files.push({ name: 'ppt/media/' + m.svg.file, data: m.svg.data }); }
    for (const x of pptCharts) files.push({ name: `ppt/charts/chart${x.n}.xml`, data: x.xml }, { name: `ppt/charts/_rels/chart${x.n}.xml.rels`, data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/package" Target="../embeddings/Microsoft_Excel_Worksheet${x.n}.xlsx"/></Relationships>` }, { name: `ppt/embeddings/Microsoft_Excel_Worksheet${x.n}.xlsx`, data: x.xlsx });
    slides.forEach((x, k) => { const extra = [...(slideRelsExtra[k] || new Map()).entries()].map(([url, id]) => `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${esc(FZ.uriForOffice(url))}" TargetMode="External"/>`).join('') + [...(slideImgs[k] || new Map()).entries()].map(([name, id]) => `<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${media.get(name).file}"/>` + (media.get(name).svg ? `<Relationship Id="${id}S" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${media.get(name).svg.file}"/>` : '')).join('') + pptCharts.filter(c => c.slide === k).map(c => `<Relationship Id="${c.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart${c.n}.xml"/>`).join('') + (slideCm.has(k) ? `<Relationship Id="rIdCm" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments" Target="../comments/comment${k + 1}.xml"/>` : ''); files.push({ name: `ppt/slides/slide${k + 1}.xml`, data: x }, { name: `ppt/slides/_rels/slide${k + 1}.xml.rels`, data: slideRels.replace('</Relationships>', extra + '</Relationships>') }); });
    return opts.files ? files : FZ.zip(files); // opts.files：中身の一覧を返す（画面は圧縮つきの FZ.zipAsync で包む）
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
