/* 文机 — PowerPoint（.pptx）の取り込み（1.0.11g：霞が関の区画で近似する）
 * 目的：スライドを生成 AI に渡せる構造（文机の原本）にし、文机で組み直す入口にする。見た目の再現ではなく、構造の近似。
 *   スライド → 資料の頁（スライドの題 → [表題]）。題の無いスライドは「（スライド N）」。
 *   中身の図形を上から「段」に分け（縦に重なる図形は同じ段）、段の中を左右の「列」に分ける（横に重なる図形は同じ列）。
 *   2 列以上の段 → 区画（[番号1 区画横] の子の節が列。列の見出しは先頭の短い字、段のすぐ上の横長の短い字は区画の見出し）。列の間に矢印の図形があれば区画矢印、山形・五角形の矢印の箱なら区画三角。
 *   1 列の段 → そのまま流す（先頭の短い太字は [番号1] の見出し）。
 *   テキストの段落：レベル・行頭記号 → 箇条書き [項目N]／[番号項目N]、記号の無い段落 → 本文。表 → 表（区画の中の表は区画の後ろへ）。画像 → 図版。グラフ → 文机のグラフ（データはグラフの中の値から）。
 *   ノート → 付箋（スライドの題の行に付く。作成者「ノート」）。配置の図形・空の図形・頁番号・フッタ・日付は捨てる。 */
(function (FZ) {
  'use strict';
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }; const unent = s => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] ?? m));
  function xml(text) { const root = { name: '#root', attrs: {}, kids: [] }; const st = [root]; const re = /<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|<\?[\s\S]*?\?>|<!--[\s\S]*?-->|<!\[CDATA\[([\s\S]*?)\]\]>|([^<]+)/g; let m;
    while ((m = re.exec(text))) { if (m[6] != null) { if (st.length > 1) st[st.length - 1].kids.push({ text: unent(m[6]) }); continue; } if (m[5] != null) { st[st.length - 1].kids.push({ text: m[5] }); continue; } if (!m[2]) continue;
      if (m[1]) { while (st.length > 1 && st.pop().name !== m[2]); continue; } const attrs = {}; m[3].replace(/([\w:.-]+)\s*=\s*("([^"]*)"|'([^']*)')/g, (_, k, __, a, b2) => { attrs[k] = unent(a ?? b2); }); const el = { name: m[2], attrs, kids: [] }; st[st.length - 1].kids.push(el); if (!m[4]) st.push(el); }
    return root; }
  const kid = (el, n) => (el && el.kids || []).find(k => k.name === n), kids = (el, n) => (el && el.kids || []).filter(k => k.name === n);
  const all = (el, n, out = []) => { for (const k of el && el.kids || []) { if (k.name === n) out.push(k); if (k.kids) all(k, n, out); } return out; };
  const path = (el, ...ns) => { let e = el; for (const n of ns) { e = kid(e, n); if (!e) return null; } return e; };
  const textOf = el => { let s = ''; for (const k of el && el.kids || []) s += k.text != null ? k.text : textOf(k); return s; };
  const toB64 = u => { if (typeof btoa === 'function') { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); } return Buffer.from(u).toString('base64'); };
  const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp', bmp: 'image/bmp' };
  const dirOf = p => p.replace(/[^/]*$/, ''), resolve = (base, t) => { if (t.startsWith('/')) return t.slice(1); const parts = (dirOf(base) + t).split('/'); const out = []; for (const x of parts) { if (x === '..') out.pop(); else if (x !== '.') out.push(x); } return out.join('/'); };
  const relsPath = p => dirOf(p) + '_rels/' + p.replace(/^.*\//, '') + '.rels';
  const esc1 = t => String(t).replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
  const escLine = t => { t = esc1(t).replace(/</g, '\\<'); return /^[\[#|]/.test(t) ? '\\' + t : t; }; /* 文机の原本で特別な頭（[ # |）は逃がす */
  /* 見出しの手書きの番号・記号は外す（文机が振る）。行頭の ・ ● などは箇条書きの印として外す */
  const HEADNUM = /^\s*(?:第[0-9０-９一二三四五六七八九十百]+[章節条項部]?|[0-9０-９]+(?:[.．][0-9０-９]+)*[.．)）]|[（(][0-9０-９a-zA-Zア-ン]+[）)]|[①-⑳]|[ア-ン][.．)）]|[■◆●○▲△◇□▶▷◎]|【)[\s　]*/;
  const stripHead = t => { const u = String(t).replace(HEADNUM, ''); return (u.startsWith('】') ? u.slice(1) : u.replace(/^(.*?)】/, '$1')).trim() || String(t).trim(); };
  const isBul = p => p.bu === 'char' || p.bu === 'num'; /* buNone は記号なし */
  const BULLET = /^[・●○■□◆◇▪▫•‐\-–—※✓✔]\s*/;
  const cellEsc = t => esc1(t).replace(/\|/g, '｜').replace(/</g, '\\<');

  FZ.fromPptx = async function (buf, base = {}) {
    const z = FZ.unzip(buf); const txt = async n => z.has(n) ? new TextDecoder().decode(await z.get(n)()) : ''; const bin = async n => z.has(n) ? z.get(n)() : null;
    const rels = async p => { const x = xml(await txt(relsPath(p))); const m = new Map(); for (const r of all(x, 'Relationship')) m.set(r.attrs.Id, { target: r.attrs.TargetMode === 'External' ? null : resolve(p, r.attrs.Target), type: String(r.attrs.Type || '').replace(/^.*\//, '') }); return m; };
    const pres = xml(await txt('ppt/presentation.xml')); const sz = all(pres, 'p:sldSz')[0]; const SW = +(sz && sz.attrs.cx) || 9144000, SH = +(sz && sz.attrs.cy) || 6858000;
    const prel = await rels('ppt/presentation.xml'); const slidePaths = all(pres, 'p:sldId').map(s => prel.get(s.attrs['r:id'])).filter(r => r && r.target).map(r => r.target);
    if (!slidePaths.length) throw new Error('スライドが見つかりません');
    const images = {}; let imgN = 0, figN = 0, noteN = 0; const notes = []; const stat = { slides: slidePaths.length, panels: 0, tables: 0, images: 0, charts: 0, notes: 0 }; const conv = []; let CUR_SI = -1; /* P18 変換の記録：{ si: スライドの番号（-1 は全体）, what } */
    const layoutCache = new Map(); const dts = all(pres, 'p:defaultTextStyle')[0]; const dl1 = dts && kid(dts, 'a:lvl1pPr'); const ddr = dl1 && kid(dl1, 'a:defRPr'); const DEF_SZ = ddr && ddr.attrs.sz ? +ddr.attrs.sz / 100 : 18; let MASTER_SZ = null; const slides = [];
    async function phSource(p) { if (layoutCache.has(p)) return layoutCache.get(p); const x = xml(await txt(p)); const r = await rels(p); const list = []; for (const sp of all(x, 'p:sp')) { const ph = all(sp, 'p:ph')[0]; const xf = path(sp, 'p:spPr', 'a:xfrm'); if (ph && xf) list.push({ type: ph.attrs.type || 'body', idx: ph.attrs.idx, xf }); } const bs = all(x, 'p:bodyStyle')[0]; const bodySz = bs ? [1, 2, 3, 4, 5, 6, 7, 8, 9].map(k => { const l = kid(bs, 'a:lvl' + k + 'pPr'); const d = l && kid(l, 'a:defRPr'); return d && d.attrs.sz ? +d.attrs.sz / 100 : 0; }) : null; const o = { list, rels: r, bodySz }; /* 1.0.12f 本文の字の大きさ（段ごと） */ layoutCache.set(p, o); return o; }
    const box = xf => { const off = kid(xf, 'a:off'), ext = kid(xf, 'a:ext'); return off && ext ? { x: +off.attrs.x || 0, y: +off.attrs.y || 0, w: +ext.attrs.cx || 0, h: +ext.attrs.cy || 0 } : null; };
    const lines = []; const out = s => lines.push(s); let COLS = SW / 36000 >= 380 ? 90 : (base.format && base.format.cols) || 60; let SIDE = false, BODY_PCT = 100, UR = 267 / 297;
    let first = true, docTitle = '', cover = false; const meta = {};
    for (let si = 0; si < slidePaths.length; si++) {
      const sp = slidePaths[si]; const sx = xml(await txt(sp)); const srel = await rels(sp);
      const layoutP = [...srel.values()].find(r => r.type === 'slideLayout'); const lay = layoutP ? await phSource(layoutP.target) : { list: [], rels: new Map() };
      const masterP = layoutP ? [...lay.rels.values()].find(r => r.type === 'slideMaster') : null; const mas = masterP ? await phSource(masterP.target) : { list: [] }; if (!MASTER_SZ && mas.bodySz) MASTER_SZ = mas.bodySz;
      const phBox = ph => { const t = ph.attrs.type || 'body', idx = ph.attrs.idx; for (const L of [lay.list, mas.list]) { const f = L.find(q => idx != null && q.idx === idx) || L.find(q => q.type === t) || (t === 'ctrTitle' ? L.find(q => q.type === 'title') : null) || (t === 'subTitle' || t === 'obj' ? L.find(q => q.type === 'body') : null); if (f) return box(f.xf); } return null; };
      /* 図形を集める（グループは座標を変換して開く） */
      const items = []; let title = null, subtitle = null;
      const walk = async (tree, T) => { for (const el of tree.kids || []) {
        if (el.name === 'p:grpSp') { const xf = path(el, 'p:grpSpPr', 'a:xfrm'); let T2 = T; if (xf) { const b = box(xf), co = kid(xf, 'a:chOff'), ce = kid(xf, 'a:chExt'); if (b && co && ce) { const cx = +co.attrs.x || 0, cy = +co.attrs.y || 0, kx = (+ce.attrs.cx || 1) ? b.w / (+ce.attrs.cx || 1) : 1, ky = (+ce.attrs.cy || 1) ? b.h / (+ce.attrs.cy || 1) : 1; T2 = q => T({ x: b.x + (q.x - cx) * kx, y: b.y + (q.y - cy) * ky, w: q.w * kx, h: q.h * ky }); } } await walk(el, T2); continue; }
        if (el.name === 'p:sp' || el.name === 'p:cxnSp') { const ph = all(el, 'p:ph')[0]; const pt = ph ? (ph.attrs.type || 'body') : null; if (pt && /^(sldNum|ftr|dt|hdr)$/.test(pt)) continue;
          const xf = path(el, 'p:spPr', 'a:xfrm'); let b = xf ? box(xf) : null; if (!b && ph) b = phBox(ph); if (!b) continue; b = T(b);
          const geom = path(el, 'p:spPr', 'a:prstGeom'); const prst = geom ? geom.attrs.prst : ''; const tb = kid(el, 'p:txBody');
          const paras = tb ? kids(tb, 'a:p').map(p => { const pPr = kid(p, 'a:pPr'); const runs = [...kids(p, 'a:r'), ...kids(p, 'a:fld')]; const t = kids(p, 'a:r').concat(kids(p, 'a:fld')).length ? (p.kids || []).map(k => k.name === 'a:r' || k.name === 'a:fld' ? textOf(kid(k, 'a:t')) : k.name === 'a:br' ? ' ' : '').join('') : '';
            const bold = runs.length > 0 && runs.every(r => { const rp = kid(r, 'a:rPr'); return rp && (rp.attrs.b === '1' || rp.attrs.b === 'true'); }); const szs = runs.map(r => +((kid(r, 'a:rPr') || { attrs: {} }).attrs.sz || 0)).filter(Boolean);
            return { t: esc1(t), lvl: +(pPr && pPr.attrs.lvl) || 0, bu: pPr && kid(pPr, 'a:buNone') ? 'none' : pPr && kid(pPr, 'a:buAutoNum') ? 'num' : pPr && (kid(pPr, 'a:buChar') || kid(pPr, 'a:buBlip')) ? 'char' : null, bold, sz: szs.length ? Math.max(...szs) / 100 : 0 }; }).filter(p => p.t) : [];
          const arrowish = /Arrow$|^(chevron|homePlate|notchedRightArrow|stripedRightArrow)$/.test(prst) && !/Callout/.test(prst);
          const spPr = kid(el, 'p:spPr'), sty = kid(el, 'p:style'); const fill = (() => { if (spPr && kid(spPr, 'a:noFill')) return null; const sf = spPr && kid(spPr, 'a:solidFill'); if (sf) { const c = kid(sf, 'a:srgbClr'); return c ? c.attrs.val : 'scheme'; } if (spPr && kid(spPr, 'a:gradFill')) return 'grad'; const fr = sty && kid(sty, 'a:fillRef'); return fr && +fr.attrs.idx > 0 ? 'scheme' : null; })(); /* 1.0.12f 塗り（区画の見出しの形に）。図形の既定の塗り（p:style）も */
          const fo = sty && kid(sty, 'a:fontRef'), foc = fo && kid(fo, 'a:schemeClr'); const white = (!!tb && all(tb, 'a:rPr').some(rp => { const sf = kid(rp, 'a:solidFill'); const c = sf && kid(sf, 'a:srgbClr'); return c && /^f{6}$/i.test(c.attrs.val); })) || (!!foc && /^(lt1|bg1)$/.test(foc.attrs.val));
          if (paras.length === 1 && /^[→⇒➡▶▷►↓▼]$/.test(paras[0].t.trim())) { items.push({ kind: 'arrow', b, prst: 'glyph' }); continue; } /* 字の矢印（区画のつなぎ） */
          if (pt === 'title' || pt === 'ctrTitle') { if (paras.length) title = { text: paras.map(p => p.t).join(' '), b, ctr: pt === 'ctrTitle' }; continue; }
          if (pt === 'subTitle') { if (paras.length) subtitle = { paras, b }; continue; }
          if (!paras.length) { if (prst === 'diamond') items.push({ kind: 'ms', b }); else if (arrowish || el.name === 'p:cxnSp' && all(el, 'a:tailEnd').some(t => t.attrs.type && t.attrs.type !== 'none')) items.push({ kind: 'arrow', b, prst }); else if (fill && el.name === 'p:sp') items.push({ kind: 'rect', b, fill }); continue; } /* ひし形（工程表の ◆）・塗った四角（見出しの帯）も拾う */
          items.push({ kind: 'text', b, paras, body: pt === 'body' || pt === 'obj' || (pt != null && pt !== 'title'), prst, chevron: /^(chevron|homePlate)$/.test(prst), fill, white }); continue; }
        if (el.name === 'p:pic') { const bl = all(el, 'a:blip')[0]; const xf = path(el, 'p:spPr', 'a:xfrm'); let b = xf ? box(xf) : null; const ph = all(el, 'p:ph')[0]; if (!b && ph) b = phBox(ph); if (!b || !bl) continue; const r = srel.get(bl.attrs['r:embed']); if (!r || !r.target) continue;
          const ext = (r.target.match(/\.(\w+)$/) || [])[1]; const mime = MIME[(ext || '').toLowerCase()]; if (!mime) continue; const data = await bin(r.target); if (!data) continue; const name = '画像' + (++imgN) + '.' + ext.toLowerCase(); images[name] = { mime, data: toB64(data) };
          let descr = (all(el, 'p:cNvPr')[0] || { attrs: {} }).attrs.descr || ''; descr = descr.trim().replace(/^(?:図|表)\s*[0-9０-９]+[\s　]*/, ''); if (/\.\w{2,4}$/.test(descr) || /^(図|画像|Picture|image)\s*\d*$/i.test(descr)) descr = ''; /* ファイル名・既定の名前は題にしない */ items.push({ kind: 'pic', b: T(b), name, title: esc1(descr).slice(0, 40) }); continue; }
        if (el.name === 'p:graphicFrame') { const xf = kid(el, 'p:xfrm'); let b = xf ? box(xf) : null; if (!b) continue; b = T(b); const tbl = all(el, 'a:tbl')[0]; const ch = all(el, 'c:chart')[0];
          if (tbl) { const grid = all(tbl, 'a:gridCol').map(g => +g.attrs.w || 1); const rows = kids(tbl, 'a:tr').map(tr => kids(tr, 'a:tc').map(tc => (tc.attrs.hMerge || tc.attrs.vMerge) ? '' : kids(kid(tc, 'a:txBody'), 'a:p').map(p => textOf(p)).filter(s => s.trim()).join(' ')));
            items.push({ kind: 'table', b, grid, rows, rowH: kids(tbl, 'a:tr').map(tr => +tr.attrs.h || 1) }); continue; }
          if (ch) { const r = srel.get(ch.attrs['r:id']); if (r && r.target) { const cx = xml(await txt(r.target)); const chart = chartFrom(cx); if (chart) { const ct = path(cx, 'c:chartSpace', 'c:chart', 'c:title'); const ttl = ct ? all(ct, 'a:t').map(textOf).join('') : ''; const ax = all(cx, 'c:valAx').map(a => kid(a, 'c:title')).find(Boolean); const ut = ax ? all(ax, 'a:t').map(textOf).join('').trim() : ''; if (ut && !chart.unit) chart.unit = ut.replace(/^[（(]|[）)]$/g, ''); items.push({ kind: 'chart', b, chart, title: esc1(ttl).slice(0, 40) }); } } continue; }
          conv.push({ si, what: all(el, 'dgm:relIds').length ? 'SmartArt は入らない（字も）' : all(el, 'p:oleObj').length ? '埋め込みオブジェクトは入らない' : 'この種類の図（動画・3D など）は入らない' }); }
        if (el.name === 'mc:AlternateContent') conv.push({ si, what: '代わりの形で入った図形（数式・インクなど）は入らない' }); } };
      await walk(path(sx, 'p:sld', 'p:cSld', 'p:spTree') || { kids: [] }, q => q);
      /* 題：プレースホルダが無ければ上の方のいちばん大きな字の短い 1 行 */
      if (!title) { const cand = items.filter(it => it.kind === 'text' && it.b.y < SH * 0.25 && it.paras.length === 1 && it.paras[0].t.length <= 60).sort((a, b) => (b.paras[0].sz - a.paras[0].sz) || (a.b.y - b.b.y))[0]; if (cand) { title = { text: cand.paras[0].t, b: cand.b }; items.splice(items.indexOf(cand), 1); } }
      if (first) { if (title && title.ctr) { docTitle = title.text; cover = true; } first = false; } /* 最初が表紙のスライドなら題名と表紙 */
      /* 柱の字（題と同じ高さの短い字：機密・日付・作成者・頁番号）は本文に入れず、書式に拾う */
      if (title) { const ty0 = title.b.y, ty1 = title.b.y + title.b.h; for (let q = items.length - 1; q >= 0; q--) { const it = items[q]; if (it.kind !== 'text') continue; const cy = it.b.y + it.b.h / 2; const t = it.paras.map(p => p.t).join(' ');
          if ((cy >= ty0 && cy <= ty1 || it.b.y + it.b.h <= ty1) && t.length <= 30) { if (/^\d+(\s*\/\s*\d+)?$/.test(t)) {} else if (/(社外秘|部外秘|秘|機密|取扱注意|Confidential|CONFIDENTIAL)/.test(t) && !meta.secret) meta.secret = t; else if (/^(\d{4}|令和|平成)[年./\-]?.*\d+[日]?$/.test(t) && !meta.date) meta.date = t; else if (!meta.author) meta.author = t; items.splice(q, 1); } } }
      items.forEach(it => { if (it.kind === 'text' && it.paras.length === 1 && /^\d{1,3}$/.test(it.paras[0].t) && it.b.w < SW * 0.08) items.splice(items.indexOf(it), 1); }); /* 頁番号の箱 */
      /* ノート */
      let noteId = null; const nr = [...srel.values()].find(r => r.type === 'notesSlide'); if (nr && nr.target) { const nx = xml(await txt(nr.target)); const body = all(nx, 'p:sp').find(s => { const ph = all(s, 'p:ph')[0]; return ph && (ph.attrs.type === 'body' || (!ph.attrs.type && ph.attrs.idx === '1')); }); const ps = body ? kids(kid(body, 'p:txBody'), 'a:p').map(p => esc1(textOf(p))).filter(Boolean) : []; if (ps.length) { noteId = 'n' + (++noteN); notes.push({ id: noteId, ps }); stat.notes++; } }
      slides.push({ si, title, subtitle, items, noteId });
    }
    /* 1.0.12f 文書全体の見立て：本文の字の大きさ → 字数・行数（字の大きさの比を保つ）。図が字の横に並ぶスライドが多ければ、資料の図表欄を使う */
    const sizes = []; for (const S of slides) for (const it of S.items) if (it.kind === 'text') for (const p of it.paras) { const z = p.sz || (it.body ? ((MASTER_SZ && (MASTER_SZ[p.lvl] || MASTER_SZ[0])) || 24) : DEF_SZ); sizes.push([z, Math.max(1, p.t.length)]); }
    let BODY_SZ = 0; if (sizes.length) { sizes.sort((a, b) => a[0] - b[0]); const tot = sizes.reduce((t, x) => t + x[1], 0); let acc = 0; for (const [z, w] of sizes) { acc += w; if (acc >= tot / 2) { BODY_SZ = z; break; } } }
    const A3S = SW / 36000 >= 380; UR = A3S ? 390 / 420 : 267 / 297; const FIT = BODY_SZ > 0 ? Math.max(24, Math.min(A3S ? 120 : 90, Math.round(SW / 12700 * UR / BODY_SZ))) : 0; /* 版面の幅（余白を除く）÷ 本文の字の大きさ＝1 行の字数 */
    COLS = FIT || COLS; const ROWS_EST = Math.round((A3S ? 44 * 90 : ((base.format && base.format.rows) || 26) * ((base.format && base.format.cols) || 60)) / COLS);
    let visSlides = 0; const shares = []; for (const S of slides) { const vis = S.items.filter(it => it.kind === 'chart' || it.kind === 'pic'); if (!vis.length) continue; visSlides++; let hit = false;
      const capT = t => t.kind === 'text' && t.paras.length === 1 && /^(図|表)\s*[0-9０-９]+/.test(t.paras[0].t);
      for (const v of vis) { if (S.items.some(t => t.kind === 'text' && !capT(t) && Math.min(v.b.x + v.b.w, t.b.x + t.b.w) - Math.max(v.b.x, t.b.x) > Math.min(v.b.w, t.b.w) * 0.3 && t.b.y + t.b.h / 2 > v.b.y - v.b.h * 0.6 && t.b.y + t.b.h / 2 < v.b.y + v.b.h * 1.2)) continue; /* 図の列に字があれば（区画の中の図）図表欄にはしない */ for (const t of S.items) { if (t.kind !== 'text' || t.paras.length < 1 || capT(t)) continue; const ov = Math.min(v.b.y + v.b.h, t.b.y + t.b.h) - Math.max(v.b.y, t.b.y); const hx = Math.min(v.b.x + v.b.w, t.b.x + t.b.w) - Math.max(v.b.x, t.b.x); if (ov > Math.min(v.b.h, t.b.h) * 0.4 && hx <= 0) { hit = true; (S.sv = S.sv || []).push(v); (S.st = S.st || []).push(t); } } }
      if (hit) { S.side = true; const L0 = Math.min(...S.st.map(t => t.b.x)), split = Math.min(...S.sv.map(v => v.b.x)), R1 = Math.max(...S.sv.map(v => v.b.x + v.b.w)); const RR = Math.max(R1, SW - L0); if (RR > L0 && split > L0) shares.push((split - L0) / (RR - L0)); } /* 図表欄は右の余白まで（左右の余白は同じと見る） */ } /* 本文の左端から図の左端まで ÷ 図の右端まで＝本文幅 */
    const sideN = slides.filter(S => S.side).length, bodyN = slides.filter((S, k) => !(k === 0 && cover) && S.items.some(it => it.kind !== 'arrow')).length; SIDE = sideN > 0 && sideN * 2 > bodyN; /* 図が字の横に並ぶスライドが過半なら図表欄（本文幅は全部の頁に効くので） */ if (SIDE) { shares.sort((a, b) => a - b); BODY_PCT = Math.max(50, Math.min(70, Math.round(shares[(shares.length - 1) >> 1] * 20) * 5)); }
    for (const S of slides) { CUR_SI = S.si;
      if (S.si === 0 && cover && S.title) { /* 1.0.12f 表紙：題を頁の中ほどに大きく中央、副題はその下に中央（スライドの表紙の見た目） */ const big = FZ.textWidth(S.title.text) * 2 <= COLS - 2; for (let k = 0; k < Math.round(ROWS_EST * 0.3); k++) out('');
        out(`[表題 中央${S.noteId ? ' 付箋:' + S.noteId : ''}]${big ? '<横倍角><縦倍角>' + escLine(S.title.text) + '</縦倍角></横倍角>' : escLine(S.title.text)}`); if (S.subtitle) { out(''); for (const p of S.subtitle.paras) out(`[中央]${escLine(p.t)}`); } continue; }
      out(`[表題${S.noteId ? ' 付箋:' + S.noteId : ''}]${escLine(S.title ? S.title.text : `（スライド ${S.si + 1}）`)}`);
      if (S.subtitle) for (const p of S.subtitle.paras) out(escLine(p.t));
      emitSlide(S.items);
    }
    /* グラフの XML → 文機のグラフ */
    function chartFrom(cx) { const pa = all(cx, 'c:plotArea')[0]; if (!pa) return null; const kinds = (pa.kids || []).filter(k => /Chart$/.test(k.name || ''));
      if (!kinds.length) return null; const sers = []; let cats = null; const typeOf = k => { const n = k.name; if (n === 'c:barChart' || n === 'c:bar3DChart') { const dir = (kid(k, 'c:barDir') || { attrs: {} }).attrs.val; const g = (kid(k, 'c:grouping') || { attrs: {} }).attrs.val; return g === 'percentStacked' ? 'band' : g === 'stacked' ? 'stack' : dir === 'bar' ? 'barh' : 'bar'; } if (/line/i.test(n)) return 'line'; if (n === 'c:doughnutChart') return 'donut'; if (/pie/i.test(n)) return 'pie'; if (/area/i.test(n)) return 'area'; return 'bar'; };
      const pts = el => { const cache = el && (all(el, 'c:strCache')[0] || all(el, 'c:numCache')[0]); if (!cache) return []; const n = +((kid(cache, 'c:ptCount') || { attrs: {} }).attrs.val || 0); const a = Array(n).fill(''); for (const p of kids(cache, 'c:pt')) a[+p.attrs.idx] = textOf(kid(p, 'c:v')); return a; };
      const types = kinds.map(typeOf); for (const k of kinds) for (const s of kids(k, 'c:ser')) { const name = pts(kid(s, 'c:tx')).join(''); const vals = pts(kid(s, 'c:val')).map(v => v === '' ? null : +v); if (!cats) cats = pts(kid(s, 'c:cat')); sers.push({ name, values: vals }); }
      if (!sers.length) return null; let type = types[0]; if (kinds.length > 1 && types.includes('line') && types.some(t => t === 'bar')) type = 'combo';
      return FZ.normalizeChart({ type, cats: cats && cats.length ? cats : sers[0].values.map((_, j) => String(j + 1)), series: sers }); }
    /* 段と列に分けて書く */
    function emitSlide(items) {
      const vis0 = items.filter(it => it.kind === 'table' || it.kind === 'chart' || it.kind === 'pic'); const inside = it => it.kind === 'text' && vis0.some(v => { const cx = it.b.x + it.b.w / 2, cy = it.b.y + it.b.h / 2; return cx > v.b.x && cx < v.b.x + v.b.w && cy > v.b.y && cy < v.b.y + v.b.h; }); /* 表・図の上に重ねた字（工程表の矢羽根の名前など）は捨てる */
      /* 1.0.12f 表に重ねた矢羽根（五角形）と ◆ → 工程表（セルの字：名前・→・◆、途中の位置は［1/4］など） */
      for (const T of vis0.filter(v => v.kind === 'table' && v.rowH)) { const inT = it => { const cx = it.b.x + it.b.w / 2, cy = it.b.y + it.b.h / 2; return cx > T.b.x && cx < T.b.x + T.b.w && cy > T.b.y && cy < T.b.y + T.b.h; };
        const bars = items.filter(it => inT(it) && ((it.kind === 'text' && it.chevron) || (it.kind === 'arrow' && /^(homePlate|chevron)$/.test(it.prst)))), mss = items.filter(it => it.kind === 'ms' && inT(it)); if (bars.length + mss.length < 2) continue;
        const gs = T.grid.reduce((a, b) => a + b, 0) || 1, hs = T.rowH.reduce((a, b) => a + b, 0) || 1; const X = [T.b.x]; T.grid.forEach(w => X.push(X[X.length - 1] + w / gs * T.b.w)); const Y = [T.b.y]; T.rowH.forEach(h => Y.push(Y[Y.length - 1] + h / hs * T.b.h));
        const colAt = x => { for (let q = 0; q < X.length - 2; q++) if (x < X[q + 1]) return q; return X.length - 2; }, rowAt = y => { for (let q = 0; q < Y.length - 2; q++) if (y < Y[q + 1]) return q; return Y.length - 2; };
        const fr = v => { const q = Math.round(v * 4) / 4; return q <= 0 || q >= 1 ? '' : '［' + (q === 0.5 ? '1/2' : q === 0.25 ? '1/4' : '3/4') + '］'; };
        const put = (r, c, t) => { while (T.rows.length <= r) T.rows.push([]); const row = T.rows[r]; while (row.length <= c) row.push(''); row[c] = t; }; let minC = 1e9, minR = 1e9;
        for (const bar of bars) { const r = rowAt(bar.b.y + bar.b.h / 2), c0 = colAt(bar.b.x + bar.b.w * 0.02), c1 = colAt(bar.b.x + bar.b.w * 0.98); const w0 = X[c0 + 1] - X[c0], w1 = X[c1 + 1] - X[c1]; const label = bar.kind === 'text' ? bar.paras.map(p => p.t).join(' ') : '';
          put(r, c0, fr((bar.b.x - X[c0]) / w0) + (label || '工程')); for (let c = c0 + 1; c <= c1; c++) put(r, c, '→' + (c === c1 ? fr((bar.b.x + bar.b.w - X[c1]) / w1) : '')); minC = Math.min(minC, c0); minR = Math.min(minR, r); }
        for (const m of mss) { const my = m.b.y + m.b.h / 2, mx = m.b.x + m.b.w / 2, r = rowAt(my), c = colAt(mx); const cw = X[c + 1] - X[c];
          const lab = items.find(t => t.kind === 'text' && !t.chevron && !t.msUsed && inT(t) && rowAt(t.b.y + t.b.h / 2) === r && Math.min(Math.abs(t.b.x - (m.b.x + m.b.w)), Math.abs(m.b.x - (t.b.x + t.b.w))) < Math.max(m.b.w * 2, cw * 0.6)); if (lab) lab.msUsed = true;
          const f = fr((mx - X[c]) / cw); put(r, c, '◆' + (f === '［1/2］' ? '' : f) + (lab ? lab.paras.map(p => p.t).join(' ') : '')); minC = Math.min(minC, c); minR = Math.min(minR, r); }
        T.gantt = { labels: Math.max(1, Math.min(6, minC)), heads: Math.max(1, Math.min(2, minR)) }; conv.push({ si: CUR_SI, what: '工程表は、表に重ねた図形（矢羽根・◆）の位置から推定' }); }
      const CAP0 = /^(図|表)\s*[0-9０-９]+[\s　]*(.*)$/; for (const it of items.slice()) { if (it.kind !== 'text' || it.paras.length !== 1) continue; const m = it.paras[0].t.match(CAP0); if (!m) continue; /* 図の番号と題の行は、すぐ下の図版の題に */
        const v = vis0.filter(v => v.kind !== 'table' && v.b.y >= it.b.y + it.b.h * 0.5 && v.b.y - (it.b.y + it.b.h) < Math.max(it.b.h * 2.5, SH * 0.05) && Math.min(v.b.x + v.b.w, it.b.x + it.b.w) - Math.max(v.b.x, it.b.x) > 0).sort((a, b) => a.b.y - b.b.y)[0]; if (v && !v.title) { v.title = m[2].trim(); items.splice(items.indexOf(it), 1); } }
      const content = items.filter(it => it.kind !== 'arrow' && it.kind !== 'rect' && it.kind !== 'ms' && !inside(it)), arrows = items.filter(it => it.kind === 'arrow'); /* 塗った四角・ひし形は飾り（見出しの形・工程表に使った） */ if (!content.length) return;
      content.sort((a, b) => a.b.y - b.b.y || a.b.x - b.b.x); const bands = [];
      for (const it of content) { const B = bands[bands.length - 1]; const ov = B ? Math.min(B.y1, it.b.y + it.b.h) - Math.max(B.y0, it.b.y) : -1; if (B && ov > Math.min(B.y1 - B.y0, it.b.h) * 0.4) { B.items.push(it); B.y1 = Math.max(B.y1, it.b.y + it.b.h); } else bands.push({ y0: it.b.y, y1: it.b.y + it.b.h, items: [it] }); }
      /* 段の中の列：横に重なる図形は同じ列（列の中は上から） */
      for (const B of bands) { const cols = []; for (const it of B.items.slice().sort((a, b) => a.b.x - b.b.x)) { const C = cols.find(c => Math.min(c.x1, it.b.x + it.b.w) - Math.max(c.x0, it.b.x) > Math.min(c.x1 - c.x0, it.b.w) * 0.5); if (C) { C.items.push(it); C.x0 = Math.min(C.x0, it.b.x); C.x1 = Math.max(C.x1, it.b.x + it.b.w); } else cols.push({ x0: it.b.x, x1: it.b.x + it.b.w, items: [it] }); } cols.sort((a, b) => a.x0 - b.x0); cols.forEach(c => c.items.sort((a, b) => a.b.y - b.b.y)); B.cols = cols; }
      const isHead = it => it.kind === 'text' && it.paras.length === 1 && it.paras[0].t.length <= 30 && !isBul(it.paras[0]);
      /* 区画の見出し：2 列以上の段のすぐ上が横長の短い 1 行（その段の幅の 6 割以上）なら、それを区画の見出しにする */
      const headOf = new Map(); for (let k = 1; k < bands.length; k++) { const P = bands[k - 1], B = bands[k]; if (B.cols.length < 2 || P.cols.length !== 1) continue; { const L = P.cols[0].items[P.cols[0].items.length - 1]; const lp = L && L.kind === 'text' && L.paras.length > 1 ? L.paras[L.paras.length - 1] : null; if (lp && lp.t.length <= 30 && !isBul(lp) && !/[。．.]$/.test(lp.t)) { headOf.set(B, lp.t); L.paras = L.paras.slice(0, -1); continue; } } /* 前の箱の最後の短い段落が区画の見出し */ if (P.cols[0].items.length !== 1) continue; const h = P.cols[0].items[0]; const span = B.cols[B.cols.length - 1].x1 - B.cols[0].x0; if (isHead(h) && (h.b.w >= span * 0.6 || (h.b.x >= B.cols[0].x0 - span * 0.05 && h.b.x <= B.cols[0].x0 + span * 0.3 && B.y0 - (h.b.y + h.b.h) < Math.max(h.b.h * 2, SH * 0.08)))) { headOf.set(B, h.paras[0].t); P.skip = true; } }
      for (let k = 0; k < bands.length; k++) { const B = bands[k]; if (B.skip) continue;
        if (B.cols.length < 2) { for (const it of B.cols[0].items) emitItem(it, 0, true); continue; }
        /* 図だけの列：字の列が 1 つなら字を流してから図（区画にしない）。図だけの段は図を 1/n で横に並べる（同じ行に付く図版は並ぶ） */
        const CAP = /^(図|表)\s*[0-9０-９]+/; const visCol = c => c.items.every(it => it.kind === 'chart' || it.kind === 'pic' || (it.kind === 'text' && it.paras.length === 1 && CAP.test(it.paras[0].t)));
        const textCols = B.cols.filter(c => !visCol(c)); if (textCols.length <= 1 && B.cols.some(visCol)) { const vc = B.cols.filter(visCol); for (const c of textCols) for (const it of c.items) emitItem(it, 0, true); const nv = textCols.length ? 0 : Math.min(4, vc.length);
          for (const c of vc) for (const it of c.items) emitItem(it, 0, false, nv > 1 ? nv : 0); continue; }
        const head = headOf.get(B) || null;
        const sec = B.cols.map(c => { const its = c.items.slice(); let h = null; if (its[0] && isHead(its[0]) && its.length > 1) h = its.shift().paras[0].t; else if (its[0] && its[0].kind === 'text') { const p0 = its[0].paras[0]; if (its[0].paras.length > 1 && (p0.bold || p0.t.length <= 20) && !isBul(p0)) { h = p0.t; its[0] = { ...its[0], paras: its[0].paras.slice(1) }; } else if (its[0].paras.length > 1) { h = p0.t; its[0] = { ...its[0], paras: its[0].paras.slice(1) }; } else { h = p0.t; its.shift(); } } if (!h && its[0] && (its[0].kind === 'chart' || its[0].kind === 'pic')) h = its[0].title || (its[0].kind === 'chart' ? 'グラフ' : '図'); return { h: h || '（無題）', its }; });
        const gaps = B.cols.slice(1).map((c, q) => ({ x0: B.cols[q].x1, x1: c.x0 })); const hasArrow = arrows.some(a => gaps.some(g => a.b.x + a.b.w / 2 >= g.x0 - a.b.w && a.b.x + a.b.w / 2 <= g.x1 + a.b.w && a.b.y < B.y1 && a.b.y + a.b.h > B.y0)); const chev = B.cols.every(c => c.items.some(it => it.chevron));
        const n = sec.length; const lay = n <= 5 ? '区画横' : '区画' + Math.ceil(n / 2); stat.panels++; conv.push({ si: CUR_SI, what: '区画は、横に並んだ図形の位置から推定' });
        const hs = (() => { const votes = []; for (const c of B.cols) { const h = c.items[0]; if (!h || h.kind !== 'text') continue; let col = h.fill ? (/^[0-9a-f]{6}$/i.test(h.fill) ? h.fill : h.white ? '404040' : 'D9D9D9') : null; /* 1.0.12f 区画の見出しの形：箱や帯の塗りの濃さから */
            if (!col) { const r = items.find(x => x.kind === 'rect' && Math.min(x.b.x + x.b.w, h.b.x + h.b.w) - Math.max(x.b.x, h.b.x) > h.b.w * 0.5 && x.b.y <= h.b.y + h.b.h * 0.5 && x.b.y + x.b.h >= h.b.y + Math.min(h.b.h, x.b.h) * 0.5); if (r) col = /^[0-9a-f]{6}$/i.test(r.fill) ? r.fill : 'D9D9D9'; } votes.push(col); }
          if (!votes.length) return ''; const lum = c => { if (!c) return 999; const v = parseInt(c, 16); return 0.299 * (v >> 16 & 255) + 0.587 * (v >> 8 & 255) + 0.114 * (v & 255); }; const L = votes.map(lum).sort((a, b) => a - b)[votes.length >> 1];
          return L >= 999 ? ' 区画見出し線' : L < 50 ? '' : L < 150 ? ' 区画見出し濃灰' : L < 248 ? ' 区画見出し網' : ' 区画見出し線'; })();
        out(`[番号1 ${lay}${hs}${chev ? ' 区画三角' : hasArrow ? ' 区画矢印' : ''}]${escLine(stripHead(head || sec.map(s => stripHead(s.h)).join('・').slice(0, 40)))}`);
        const after = []; sec.forEach((s, q) => { out(`[番号2]${escLine(stripHead(s.h))}`); for (const it of s.its) { if (it.kind === 'table') after.push(it); else emitItem(it, 2, false, 0, B.cols[q].x1 - B.cols[q].x0); } });
        for (const it of after) emitItem(it, 0, false); }
    }
    /* 1 つの図形を書く（lv：見出しの深さ、top：段の頭なら先頭の短い太字を見出しに） */
    function emitItem(it, lv, top, div = 0, colW = 0) {
      if (it.kind === 'text') { let ps = it.paras;
        if (top && lv === 0 && ps.length > 1 && !isBul(ps[0]) && (ps[0].bold || (ps[0].sz && ps[0].sz > Math.max(...ps.slice(1).map(p => p.sz || 0)))) && ps[0].t.length <= 40) { out(`[番号1]${escLine(stripHead(ps[0].t))}`); ps = ps.slice(1); }
        else if (top && lv === 0 && ps.length === 1 && ps[0].t.length <= 30 && !isBul(ps[0])) { if (/^(図|表)\s*[0-9０-９]+/.test(ps[0].t)) { out(escLine(ps[0].t)); return; } out(`[番号1]${escLine(stripHead(ps[0].t))}`); return; } /* 段の頭の短い 1 行は見出し（図の番号の行は除く） */
        const bullet = p => p.bu === 'char' || p.bu === 'num' || (it.body && p.bu !== 'none');
        for (const p of ps) { const L = Math.min(8, p.lvl + 1); if (!bullet(p) && !isBul(p) && HEADNUM.test(p.t) && !BULLET.test(p.t) && p.t.length <= 30 && !/[。．]$/.test(p.t)) { out(`[番号${lv + 1}]${escLine(stripHead(p.t))}`); continue; } /* 箱の中の「2. 構成」などは見出し */ if (!bullet(p) && BULLET.test(p.t)) { out(`[項目${L}]${escLine(p.t.replace(BULLET, ''))}`); continue; } out(bullet(p) ? `[${p.bu === 'num' ? '番号項目' : '項目'}${L}]${escLine(p.t)}` : escLine(p.t)); } return; }
      if (it.kind === 'table') { stat.tables++; const rows = it.rows.filter(r => r.some(c => c.trim())); if (!rows.length) return; const nC = Math.max(...rows.map(r => r.length)); const LIM = SIDE ? Math.round(COLS * BODY_PCT / 100) : COLS; const W = Math.max(nC * 3, Math.min(LIM, Math.round(it.b.w / (SW * UR) * COLS))); /* 1.0.12f 版面の幅に対する比（図表欄があれば本文欄まで） */ const tot = it.grid.slice(0, nC).reduce((a, b) => a + b, 0) || nC;
        let acc = 0; const bounds = [0]; for (let q = 0; q < nC; q++) { acc += (it.grid[q] || tot / nC); bounds.push(Math.round(acc / tot * W * 2) / 2); } for (let q = 1; q < bounds.length; q++) if (bounds[q] - bounds[q - 1] < 2) bounds[q] = bounds[q - 1] + 2; if (bounds[bounds.length - 1] > LIM) { const k = LIM / bounds[bounds.length - 1]; for (let q = 1; q < bounds.length; q++) bounds[q] = Math.round(bounds[q] * k * 2) / 2; }
        if (lines.length && /^\|/.test(lines[lines.length - 1])) out(''); out(`#表 列 ${bounds.join(',')} 様式 格子 見出し淡`); rows.forEach((r, k) => out((k === 0 && it.gantt ? `[工程表 工程列${it.gantt.labels}${it.gantt.heads > 1 ? ' 工程見出し' + it.gantt.heads : ''}]` : '') + '| ' + Array.from({ length: nC }, (_, q) => cellEsc(r[q] || '')).join(' | ') + ' |')); out(''); return; }
      if (it.kind === 'pic' || it.kind === 'chart') { const cap = (lines[lines.length - 1] || '').match(/^(?:図|表)\s*[0-9０-９]+[\s　]*(.*)$/); if (cap) { lines.pop(); if (!it.title) it.title = cap[1].trim(); } if (/^(\||#表)/.test(lines[lines.length - 1] || '')) out(''); /* 「図 1 題」の行は図版の題に */ /* 図版は直前の行に付く（表の直後は空行に） */ const id = (it.kind === 'chart' ? 'g' : 'p') + (++figN); const basis = lv ? (colW || SW * UR) : SIDE ? SW * UR * ((100 - BODY_PCT) / 100 - 1 / COLS) : SW * UR; /* 図表欄＝本文欄の右 1 マスの後ろ */ const pc = Math.max(30, Math.min(100, Math.round(it.b.w / basis * 100 / 5) * 5)); /* 1.0.12f 置く欄（区画・図表欄・本文）の幅に対する比 */ const sz = div ? ' 1/' + div : pc === 100 ? '' : ' ' + pc + '%';
        if (it.kind === 'pic') { stat.images++; out(`#図版 ${id} 図${it.title ? ' ' + it.title : ''} ${it.name}${sz}`); return; }
        stat.charts++; const c = it.chart; const TN = FZ.CHART_NAMES || {}; out(`#グラフ ${id} 図 ${TN[c.type] || '棒'}${sz || ' 100%'}${it.title ? ' ' + it.title : ''}`); for (const row of FZ.chartToGrid(c)) out('#データ | ' + row.map(x => String(x).replace(/\|/g, '｜')).join(' | ') + ' |'); return; }
    }
    /* 付箋（ノート） */
    if (notes.length) { out(''); for (const n of notes) { out(`#付箋 ${n.id} ノート - 未`); for (const p of n.ps) out(/^#/.test(p) ? '\\' + p : p); out('#付箋ここまで'); } }
    const A3 = SW / 36000 >= 380; const f = base.format || {}; const C0 = A3 ? 90 : f.cols || 60, R0 = A3 ? 44 : f.rows || 26; const ROWS = Math.max(10, Math.round(R0 * C0 / COLS)); /* 1.0.12f 字数に合わせて行数（字と行送りの比を保つ） */ const head = ['#fzk 2', '題名: ' + (base.title || ''), '用紙: ' + (A3 ? 'A3' : f.paper || 'A4') + ' 横', '文字数: ' + COLS, '行数: ' + ROWS, '余白: 12 15 12 15', '柱下: {page} / {pages}', '柱行: 2 0', '書式: 資料', '本文幅: ' + (SIDE ? BODY_PCT : 100) + '%', '柱の題: 頁ごと', '頁番号: 四角', '---'];
    const doc = FZ.parse(head.join('\n') + '\n' + lines.join('\n') + '\n'); doc.images = Object.assign(doc.images || {}, images); doc.title = docTitle || base.title || '';
    if (base.format) doc.format = FZ.normalize({ ...doc, format: { ...JSON.parse(JSON.stringify(base.format)), kind: 'slide', bodyPct: SIDE ? BODY_PCT : 100, headTitle: 'page', ...(A3 ? { paper: 'A3', widthMm: 420, heightMm: 297, landscape: true } : {}), cols: COLS, rows: ROWS } }).format; /* スライドが A3 の大きさなら A3 横 90×44 */
    if (cover) doc.format.cover = true; if (meta.secret) doc.format.secret = meta.secret; if (meta.date) doc.format.date = meta.date; if (meta.author) doc.format.author = meta.author; /* 資料の書式（既定）に、本文幅 100%（区画と図表を本文の中に） */
    if (SIDE) conv.push({ si: -1, what: `図表欄（本文幅 ${BODY_PCT}%）は、スライドの図の位置から推定` });
    return { doc, stats: stat, text: lines.join('\n'), conv };
  };
})(typeof window !== 'undefined' ? (window.FZ = window.FZ || {}) : (globalThis.FZ = globalThis.FZ || {}));
