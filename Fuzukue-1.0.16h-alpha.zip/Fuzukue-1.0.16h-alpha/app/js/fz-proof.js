/* 文机 — 文書の点検（1.0.15b：健康診断・表記の決まり）
 * 表記の決まりはデータ（FZ.PROOF_RULES）で持ち、組（set）ごとに入り切りする：
 *   common＝どの文書にも（全角英数字・半角カナ・句読点の重なり・ら抜き・表記の揺れ・単位の揺れ・同じ語の繰り返し）
 *   kobun＝公用文の表記（文化庁「公用文作成の考え方」2022・「公用文における漢字使用等について」2010 に沿った代表的なもの）
 *   num＝数字の書き方（5 桁以上の桁区切り）
 *   user＝自分の決まり（誤→正の対。この機械に覚える）
 * FZ.proofIssues(doc, opts) → [{ line, seg, a, b, id, set, name, text, fix, msg }]。fix があれば直せる（直すは 1 回の Ctrl+Z で戻る）。
 * 無視した所は doc.proofIgnore（「規則の id|字」）に覚え、原本に「#点検無視」で残す */
(function (FZ) {
  'use strict';
  const R = [];
  const add = (set, id, name, re, to, msg) => R.push({ set, id, name, re, to, msg });
  /* ---- どの文書にも ---- */
  add('common', 'zenEisu', '全角の英数字', /[Ａ-Ｚａ-ｚ０-９]+/g, m => m.replace(/[Ａ-Ｚａ-ｚ０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0)), '英数字は半角に（文机は 1 マスに 2 字で組む）');
  add('common', 'hanKana', '半角のカタカナ', /[ｦ-ﾟ]+/g, m => m.normalize('NFKC'), 'カタカナは全角に');
  add('common', 'dupPunct', '句読点の重なり', /([。、，．])\1+/g, m => m[0], '同じ句読点が続いている');
  const RANUKI = ['見', '来', '寝', '着', '居', '出', '似', '煮', '食べ', '考え', '決め', '調べ', '変え', '答え', '教え', '覚え', '起き', '生き', '信じ', '感じ', '借り', '降り', '浴び', '伸び', '投げ', '受け', '続け', '止め', '始め', '見せ', '任せ'];
  add('common', 'ranuki', 'ら抜き言葉', new RegExp('(' + RANUKI.join('|') + ')れ(る|ない|ます|ません|た|て)', 'g'), (m, a, b) => a + 'られ' + b, '「られる」に（ら抜き言葉の候補）');
  /* 表記の揺れ：同じ文書の中で両方の書き方が出たら、少ない方を多い方に（数が同じなら最初に出た方に） */
  FZ.PROOF_VARIANTS = [['サーバー', 'サーバ'], ['ユーザー', 'ユーザ'], ['コンピューター', 'コンピュータ'], ['メモリー', 'メモリ'], ['プリンター', 'プリンタ'], ['フォルダー', 'フォルダ'], ['データベース', 'データーベース'], ['インターフェース', 'インタフェース', 'インターフェイス'],
    ['問い合わせ', '問合せ', '問合わせ'], ['申し込み', '申込み', '申込'], ['打ち合わせ', '打合せ', '打合わせ'], ['取り組み', '取組み'], ['取り扱い', '取扱い'], ['引き継ぎ', '引継ぎ'], ['見積もり', '見積り'], ['売り上げ', '売上げ'], ['受け付け', '受付け'], ['締め切り', '締切り'], ['割り当て', '割当て'], ['組み合わせ', '組合せ'], ['分かる', 'わかる']];
  /* ---- 公用文の表記 ---- */
  add('kobun', 'k_koto', '形式名詞「こと」', /(?<=[るたいだうくすつぬむぶぐの])事(?=[がはをにもでとの])/g, () => 'こと', '形式名詞はひらがなで「こと」');
  add('kobun', 'k_toki', '形式名詞「とき」', /(?<=[るたいだう])時(?=[はにのもで、])/g, () => 'とき', '条件を表す「とき」はひらがな（時点を表すなら「時」のまま）');
  add('kobun', 'k_youni', '「ように」', /(?<=[のるたこそあど])様(?=[にな])/g, () => 'よう', '「ように」「ような」はひらがな');
  add('kobun', 'k_dekiru', '「できる」', /出来(?=[るたなまずれ])/g, () => 'でき', '「できる」はひらがな');
  add('kobun', 'k_kudasai', '補助動詞「ください」', /(?<=[てで])下さ(?=[いる])/g, () => 'くださ', '補助動詞はひらがなで「ください」');
  add('kobun', 'k_itasu', '補助動詞「いたす」', /(?<=[ぁ-ゖ])致(?=[しさす])/g, () => 'いた', '補助動詞・謙譲の「いたす」はひらがな');
  add('kobun', 'k_itadaku', '補助動詞「いただく」', /(?<=[てで])頂(?=[いきくけこ])/g, () => 'いただ', '補助動詞はひらがなで「いただく」');
  add('kobun', 'k_okonau', '「行う」の送り仮名', /行な(?=[うわいえっ])/g, () => '行', '「行う」（送り仮名は「う」だけ）');
  add('kobun', 'k_tadashi', '接続詞「ただし」', /但し/g, () => 'ただし', '接続詞はひらがなで「ただし」');
  add('kobun', 'k_nao', '接続詞「なお」', /(?<=^|[。、　\s])尚(?=、)/g, () => 'なお', '接続詞はひらがなで「なお」');
  add('kobun', 'k_oyobi', '「及び」', /および/g, () => '及び', '公用文では「及び」「並びに」「又は」「若しくは」は漢字');
  add('kobun', 'k_narabini', '「並びに」', /ならびに/g, () => '並びに', '公用文では漢字で「並びに」');
  add('kobun', 'k_mataha', '「又は」', /または/g, () => '又は', '公用文では漢字で「又は」');
  add('kobun', 'k_moshikuha', '「若しくは」', /もしくは/g, () => '若しくは', '公用文では漢字で「若しくは」');
  add('kobun', 'k_made', '「まで」', /迄/g, () => 'まで', '「まで」はひらがな');
  /* ---- 数字 ---- */
  add('num', 'n_comma', '桁の区切り', /(?<![\d,.．，\w-])\d{5,}(?![\d,.．，\w])/g, m => m.replace(/\B(?=(\d{3})+$)/g, ','), '5 桁以上の数は 3 桁ごとに「,」で区切る');
  FZ.PROOF_RULES = R;
  FZ.PROOF_SETS = [['common', 'どの文書にも'], ['kobun', '公用文の表記'], ['num', '数字の書き方'], ['user', '自分の決まり']];

  const textOf = seg => seg.text;
  const skipLine = ln => !!(ln.attrs.code || ln.attrs.figure || ln.attrs.toc);
  /* 字の中の位置：参照の字（図番）や記号は字としてそのまま扱う。一致は seg ごと */
  function scan(doc, re, fn) { doc.lines.forEach((ln, i) => { if (skipLine(ln)) return; ln.segs.forEach((sg, s) => { const t = textOf(sg); re.lastIndex = 0; let m; while ((m = re.exec(t))) { if (!m[0].length) { re.lastIndex++; continue; } fn(i, s, m.index, m.index + m[0].length, m); } }); }); }
  FZ.proofIssues = function (doc, opts = {}) {
    const sets = new Set(opts.sets || ['common', 'kobun', 'num', 'user']); const ign = new Set(doc.proofIgnore || []); const out = [];
    const push = (r, i, s, a, b, m, fix, msg) => { const text = m[0]; if (ign.has(r.id + '|' + text)) return; out.push({ line: i, seg: s, a, b, id: r.id, set: r.set, name: r.name, text, fix: fix != null && fix !== text ? fix : null, msg: msg || r.msg }); };
    for (const r of R) { if (!sets.has(r.set)) continue; scan(doc, r.re, (i, s, a, b, m) => push(r, i, s, a, b, m, r.to ? r.to(...m) : null)); }
    if (sets.has('user')) for (const [k, u] of (opts.user || []).entries()) { if (!u || !u.from) continue; const r = { set: 'user', id: 'u_' + u.from, name: '自分の決まり：' + u.from + '→' + (u.to || ''), msg: `「${u.to}」に（自分の決まり）` }; const re = new RegExp(u.from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'); scan(doc, re, (i, s, a, b, m) => push(r, i, s, a, b, m, u.to)); }
    if (sets.has('common')) {
      /* 表記の揺れ：両方出たら少ない方を */
      for (const grp of FZ.PROOF_VARIANTS) { const esc = v => v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); const hits = grp.map(v => { const tails = grp.filter(w => w !== v && w.startsWith(v)).map(w => w[v.length]); const re = new RegExp(esc(v) + (tails.length ? '(?![' + tails.join('') + '])' : ''), 'g'); const h = []; scan(doc, re, (i, s, a, b, m) => h.push({ i, s, a, b, m })); return h; }); const used = hits.map((h, k) => [k, h.length]).filter(x => x[1]); if (used.length < 2) continue;
        const first = Math.min(...used.map(([k]) => hits[k][0].i * 1e6 + hits[k][0].a)); const main = used.slice().sort((x, y) => y[1] - x[1] || (hits[x[0]][0].i * 1e6 + hits[x[0]][0].a) - (hits[y[0]][0].i * 1e6 + hits[y[0]][0].a))[0][0];
        const r = { set: 'common', id: 'v_' + grp[0], name: '表記の揺れ：' + grp.join('／'), msg: `この文書では「${grp[main]}」が多い（${used.map(([k, n]) => grp[k] + ' ' + n).join('・')}）` }; void first;
        for (const [k] of used) if (k !== main) for (const h of hits[k]) push(r, h.i, h.s, h.a, h.b, h.m, grp[main]); }
      /* 単位の揺れ（金額）：億円・百万円・千円・万円が混ざる */
      { const U = ['億円', '百万円', '千円', '万円']; const hits = U.map(u => { const h = []; scan(doc, new RegExp('(?<=[\\d０-９,，．.])' + u, 'g'), (i, s, a, b, m) => h.push({ i, s, a, b, m })); return h; }); const used = hits.map((h, k) => [k, h.length]).filter(x => x[1]);
        if (used.length >= 2) { const main = used.slice().sort((x, y) => y[1] - x[1])[0][0]; const r = { set: 'common', id: 'unitYen', name: '金額の単位の揺れ', msg: `金額の単位が混ざっている（${used.map(([k, n]) => U[k] + ' ' + n).join('・')}）。表や比べる数は単位をそろえる` }; for (const [k] of used) if (k !== main) for (const h of hits[k]) push(r, h.i, h.s, h.a, h.b, h.m, null); } }
      /* 同じ語の繰り返し：1 文に同じ 2 字以上の漢字語・カタカナ語が 3 回以上 */
      { const r = { set: 'common', id: 'repeat', name: '同じ語の繰り返し', msg: '1 つの文に同じ語が 3 回以上（言い換えるか、文を分ける）' };
        doc.lines.forEach((ln, i) => { if (skipLine(ln)) return; ln.segs.forEach((sg, s) => { const t = sg.text; let st = 0; for (const sen of t.split(/(?<=[。！？])/)) { const cnt = new Map(); const re = /[一-鿿々]{2,}|[ァ-ヶー]{3,}/g; let m; while ((m = re.exec(sen))) { const e = cnt.get(m[0]) || []; e.push(m.index); cnt.set(m[0], e); } for (const [w, at] of cnt) if (at.length >= 3) push(r, i, s, st + at[2], st + at[2] + w.length, [w], null, `「${w}」が 1 つの文に ${at.length} 回`); st += sen.length; } }); }); }
    }
    out.sort((p, q) => p.line - q.line || p.seg - q.seg || p.a - q.a); return out; };
  /* 直す：issues の fix を後ろから当てる（同じ行の位置がずれないように）。ed.mutate の中で呼ぶ */
  FZ.proofApply = function (doc, list) { const by = list.filter(x => x.fix != null).slice().sort((p, q) => q.line - p.line || q.seg - p.seg || q.a - p.a); let n = 0;
    for (const it of by) { const ln = doc.lines[it.line]; const sg = ln && ln.segs[it.seg]; if (!sg || sg.text.slice(it.a, it.b) !== it.text) continue; const mk = sg.marks[it.a] | 0; sg.text = sg.text.slice(0, it.a) + it.fix + sg.text.slice(it.b); sg.marks = [...sg.marks.slice(0, it.a), ...Array.from({ length: it.fix.length }, () => mk), ...sg.marks.slice(it.b)]; if (sg.links) { const d = it.fix.length - (it.b - it.a); for (const l of sg.links) { if (l.start >= it.b) { l.start += d; l.end += d; } else if (l.end > it.a) l.end = Math.max(l.start, l.end + d); } } n++; }
    return n; };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
