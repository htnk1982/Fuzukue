/* 文机 — プ譜（1.0.14a）
 * プ譜は、ゴールから逆算して道筋を描く図（前田考歩・後藤洋平）。「プ譜」の印を付けた節（見出し・項目）の子の木を、紙面で右から左へ枝分かれする形に組む。
 * 書くのはふだんのアウトライン（左から右の木）。紙面では「字下げの木を左右逆転」した記法：段差（深さ）は右端に出し、字の書き出しは左で揃える。行の順番はアウトラインと同じ。
 * 役は深さで決まる（「プ譜取組」の節は深さに数えない）：0 獲得目標・1 勝利条件・2 中間目的・3 施策・4 以上 段取り。
 * 取組は、同じ上位の要求のもとにある中間目的のまとまり（1.0.14b までの「枠」）。紙面では太罫で囲み、札は「取組1」「取組2」…と番号。
 *   「成果物：」で始まる項目（中間目的のすぐ下）と、項目のすぐ後の段落は、親の箱の続き。
 *   「プ譜資源」の節（資源と制約＝廟算八要素）は木の外で、下に 2 列の表に。
 *   行末の〔推測〕は AI が本文に無いものを補った印：箱を点線で描く（確かめたら消す）。
 * FZ.pufuBlocks(doc)：プ譜の節ごとの木。FZ.pufuLayoutMap(doc, opt)：組版の前処理（行ごとの欄・箱・札・枠・線）。FZ.pufuLint(doc)：点検。
 * FZ.pufuFromMd(text)：AI の答え（役の名前付きの箇条書き）を読む。FZ.PUFU_PROMPT：文章からプ譜を起こす指示文。 */
(function (FZ) {
  'use strict';
  const ROLES = ['獲得目標', '勝利条件', '中間目的', '施策'];
  const roleName = d => d < 0 ? '' : d < ROLES.length ? ROLES[d] : '段取り'; /* 施策の子：施策を進める具体的な手順・作業 */
  FZ.PUFU_ROLES = ROLES;
  FZ.pufuRoleName = roleName;
  const lvOf = a => a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : (a.list && a.list.kind !== 'cont') ? 17 + (a.list.level | 0) : 99;
  const textOf = ln => ln.segs.map(s => s.text).join('');
  const blank = ln => !textOf(ln).trim() && !ln.attrs.list && !ln.attrs.style && !(ln.attrs.figs || []).length;
  const stop = a => !!(a.cells || a.figure || a.toc || (a.figs && a.figs.length) || a.breakBefore || a.pufu || a.panels || a.style === 'title' || a.gantt);
  const OUT_RE = /^[\s　]*成果物[\s　]*[：:]/;
  const GUESS_RE = /〔推測〕[\s　]*$/;
  const INSIGHT_RE = /^[\s　]*気づき[\s　]*[：:]/; /* 1.0.14e 気づき（やってみてわかったこと）：項目の後の段落で「気づき：」で始まるもの。紙面では点線の吹き出し */
  FZ.PUFU_GUESS = '〔推測〕';
  const RES_KEYS = ['ひと', 'お金', '時間', 'クオリティ', '商流・座組', '環境', 'ライバル', '外敵'];
  FZ.PUFU_RES_KEYS = RES_KEYS;

  /* ---------- 木 ----------
     block = { head, start, end, map: Map(line → 項), roots: [行], res: { line, lv, items: [項] } | null, frames: [項] }
     項 = { line, kind: 'node'|'frame'|'cont'|'res'|'resItem'|'resCont', depth, parent, kids, conts, lv, guess, frame（囲む枠の行）, owner（続きの持ち主）, out（成果物） } */
  function blocks(doc) {
    const L = doc.lines, N = L.length, out = [];
    for (let g = 0; g < N; g++) {
      const ga = L[g].attrs; if (!ga.pufu) continue; const G = lvOf(ga); if (G >= 99) continue;
      let e = g + 1; while (e < N && lvOf(L[e].attrs) > G && !blank(L[e]) && !stop(L[e].attrs)) e++;
      const B = { head: g, start: g + 1, end: e, map: new Map(), roots: [], res: null, frames: [], names: ga.pufuNames || null }; /* 1.0.16h 表示の名前（構造の名前 → 見せる名前） */
      const stack = [{ lv: G, node: null }]; let last = null, inRes = null;
      for (let q = g + 1; q < e; q++) {
        const ln = L[q], a = ln.attrs, lv = lvOf(a);
        if (inRes && lv > inRes.lv) {
          if (lv === 99 && inRes.items.length) { const own = inRes.items[inRes.items.length - 1]; B.map.set(q, { line: q, kind: 'resCont', owner: own.line }); own.conts.push(q); continue; }
          const it = { line: q, kind: 'resItem', k: inRes.items.length, conts: [] }; inRes.items.push(it); B.map.set(q, it); continue; }
        inRes = null;
        if (lv === 99) { if (last) { B.map.set(q, { line: q, kind: 'cont', owner: last.line, insight: INSIGHT_RE.test(textOf(ln)) }); last.conts.push(q); } continue; } /* 段落：直前の箱の続き（最初の項目より前の段落は前書きとしてふつうに組む） */
        while (stack.length > 1 && stack[stack.length - 1].lv >= lv) stack.pop();
        const par = stack[stack.length - 1].node;
        if (a.pufuRes && !par) { inRes = { line: q, lv, items: [], kind: 'res' }; B.res = inRes; B.map.set(q, inRes); last = null; stack.push({ lv, node: null, res: true }); continue; }
        if (par && par.kind === 'node' && last === par && OUT_RE.test(textOf(ln))) { B.map.set(q, { line: q, kind: 'cont', owner: par.line, out: true }); par.conts.push(q); continue; } /* 成果物：中間目的の箱の続き */
        const isFrame = !!a.pufuFrame && !!par;
        const depth = !par ? 0 : par.kind === 'frame' ? par.depth : par.depth + 1;
        const nd = { line: q, kind: isFrame ? 'frame' : 'node', depth, parent: par ? par.line : null, kids: [], conts: [], lv, guess: GUESS_RE.test(textOf(ln)), frame: par ? (par.kind === 'frame' ? par.line : par.frame) : null };
        if (isFrame) { B.frames.push(nd); nd.no = B.frames.length; } /* 取組の番号（プ譜の中の順） */
        if (par) par.kids.push(q); else B.roots.push(q);
        B.map.set(q, nd); stack.push({ lv, node: nd }); last = nd;
      }
      for (const f of B.frames) { let z = f.line + 1; while (z < e && lvOf(L[z].attrs) > f.lv) z++; f.endLine = z - 1; }
      out.push(B);
    }
    return out;
  }
  FZ.pufuBlocks = blocks;
  /* カーソルの行が入っているプ譜：{ B, it（その行の項。見出しの行なら null） } */
  FZ.pufuAt = function (doc, line) { for (const B of blocks(doc)) { if (line === B.head) return { B, it: null }; if (line > B.head && line < B.end) return { B, it: B.map.get(line) || null }; } return null; };
  /* 行の役の名前（続きは持ち主の役。取組は「取組」、資源は「資源と制約」）。札の字は pufuTagOf（取組は番号付き） */
  /* 1.0.16h 構造の名前（獲得目標・勝利条件…）と、見せる名前（プ譜の題の行の pufuNames。無ければ構造の名前）を分ける。札・列の名前・書き出し・ツリーは見せる名前、点検・AI の指示文は構造の名前 */
  const NAME_KEYS = ['獲得目標', '勝利条件', '取組', '中間目的', '施策', '段取り', '成果物'];
  FZ.PUFU_NAME_KEYS = NAME_KEYS;
  FZ.PUFU_NAME_PRESETS = [['std', 'プ譜の言葉（既定）', {}], ['plain', 'ふつうの言葉', { 獲得目標: '目指すこと', 勝利条件: '成功の基準', 取組: '取り組み', 中間目的: '達成すべき状態', 施策: '打ち手', 段取り: '手順', 成果物: '成果物' }], ['proj', '計画書の言葉', { 獲得目標: '目的', 勝利条件: 'ゴール', 取組: '施策群', 中間目的: '中間目標', 施策: '実施事項', 段取り: '作業', 成果物: '成果物' }]];
  const showName = (B, k) => (B && B.names && B.names[k] && String(B.names[k]).trim()) || k;
  FZ.pufuShowName = showName;
  FZ.pufuTagOf = function (B, it) { return it && it.kind === 'frame' ? showName(B, '取組') + (it.no || '') : showName(B, FZ.pufuRoleOf(B, it)); };
  FZ.pufuRoleOf = function (B, it) { if (!it) return ''; if (it.kind === 'frame') return '取組'; if (it.kind === 'res' || it.kind === 'resItem' || it.kind === 'resCont') return '資源と制約'; if (it.kind === 'cont') { const o = B.map.get(it.owner); return it.out ? '成果物' : it.insight ? '気づき' : FZ.pufuRoleOf(B, o); } return roleName(it.depth); };

  /* ---------- 組版の前処理 ----------
     行ごとに pf = { kind, role, L, R（字の欄）, bx0, bx1（箱の左右）, tag（役の札）, tagShade, fill（帯の網）, bold, box, top, end（箱の上下を引くか）,
       topKind, sideKind, bottomKind, frames: [{ x0, x1, end }], spines: [{ x, half, head }], tick: { x0, x1 } | null, pair（資源の 2 列：0 左・1 右）, keepNext,
       gapAbove（上に空ける行：獲得目標と勝利条件の間・勝利条件と取組の間・取組と取組の間・中間目的のまとまりの間。背骨と取組の囲みは空きを通す）, tagBold, sig } */
  const TW = 4.5, D = 3, MIN_TEXT = 6;
  FZ.PUFU_GEOM = { TW, D };
  function layoutMap(doc, opt = {}) {
    const L0 = opt.L0 || 0, R0 = opt.R0 || 40, skip = opt.skip || (() => false); const map = new Map();
    const R = d => Math.max(L0 + TW + 0.5 + MIN_TEXT, R0 - D * d);
    for (const B of blocks(doc)) {
      if (skip(B.head)) continue;
      const tagShade = d => d <= 1 ? 'ink' : d === 2 ? 'gray' : d === 3 ? 'light' : null; /* 札の濃さで段を拾えるように：獲得目標・勝利条件＝濃灰、中間目的＝薄、施策＝淡、段取り＝無地 */
      const put = (q, pf) => { pf.frames = pf.frames || []; pf.spines = pf.spines || []; map.set(q, pf); return pf; };
      let afterTree = false;
      for (const [q, it] of B.map) {
        if (it.kind === 'node') { const r = R(it.depth); afterTree = true;
          put(q, { kind: 'node', role: roleName(it.depth), depth: it.depth, bx0: L0, bx1: r, L: L0 + TW + 0.5, R: r - 0.5, tag: showName(B, roleName(it.depth)), tagShade: tagShade(it.depth), tagBold: it.depth <= 2, bold: it.depth <= 1, gapAbove: it.depth === 1 ? 1 : it.depth === 2 && !(it.parent != null && B.map.get(it.parent).kind === 'frame' && B.map.get(it.parent).kids[0] === q) ? 1 : 0, /* 勝利条件の上と、中間目的のまとまりの間（取組の中の最初の中間目的は帯のすぐ下）を 1 行空ける */ box: true, top: true, end: !it.conts.length, topKind: it.guess ? 'dotted' : 'thin', sideKind: it.guess ? 'dotted' : 'thin', bottomKind: it.guess ? 'dotted' : 'thin', keepNext: it.conts.length > 0 }); }
        else if (it.kind === 'frame') { const rf = R(it.depth) + 0.75; afterTree = true;
          put(q, { kind: 'frame', role: '取組', depth: it.depth, bx0: L0, bx1: rf, L: L0 + TW + 0.5, R: rf - 0.5, tag: showName(B, '取組') + (it.no || ''), tagShade: null, tagBold: true, gapAbove: 1, fill: 'gray', bold: true, box: true, top: true, end: !it.conts.length, topKind: 'thick', sideKind: 'thick', bottomKind: 'thin', keepNext: true }); }
        else if (it.kind === 'res') { put(q, { kind: 'res', role: '資源と制約', bx0: L0, bx1: R0, L: L0 + 0.5, R: R0 - 0.5, fill: 'gray', bold: true, box: true, top: true, end: true, topKind: 'thin', sideKind: 'thin', bottomKind: 'thin', keepNext: true, gapAbove: afterTree ? 1 : 0 }); }
      }
      /* 続き（成果物・段落）：持ち主の箱を続ける */
      for (const [q, it] of B.map) {
        if (it.kind !== 'cont') continue; const o = map.get(it.owner); if (!o) continue; const own = B.map.get(it.owner); const lastC = own.conts[own.conts.length - 1] === q;
        put(q, { kind: 'cont', role: it.out ? '成果物' : o.role, depth: o.depth, bx0: o.bx0, bx1: o.bx1, L: o.L, R: o.R, tag: null, tagShade: o.tagShade, fill: o.fill, bold: false, box: true, top: false, end: lastC, topKind: o.topKind, sideKind: o.sideKind, bottomKind: o.kind === 'frame' ? 'thin' : o.bottomKind, keepNext: !lastC, out: !!it.out, insight: !!it.insight }); }
      /* 資源と制約：2 列（続きの段落があれば 1 列） */
      if (B.res) { const items = B.res.items; const two = items.length > 1 && items.every(x => !x.conts.length) && R0 - L0 >= 24; const mid = L0 + Math.round((R0 - L0)) / 2;
        for (const x of items) { const k = x.k; const x0 = two && k % 2 ? mid : L0, x1 = two && k % 2 === 0 ? mid : R0;
          put(x.line, { kind: 'resItem', role: '資源と制約', bx0: x0, bx1: x1, L: x0 + 0.5, R: x1 - 0.5, box: true, top: true, end: !x.conts.length, topKind: 'thin', sideKind: 'thin', bottomKind: 'thin', pair: two ? k % 2 : null, keepNext: two && k % 2 === 0 && k + 1 < items.length });
          x.conts.forEach((c, j) => put(c, { kind: 'resCont', role: '資源と制約', bx0: x0, bx1: x1, L: x0 + 0.5, R: x1 - 0.5, box: true, top: false, end: j === x.conts.length - 1, topKind: 'thin', sideKind: 'thin', bottomKind: 'thin' })); } }
      /* 取組：囲む行の左右（太罫）と、最後の行の下。取組の後ろの項目とは 1 行空ける */
      for (const f of B.frames) { const fp = map.get(f.line); if (!fp) continue; { const nx = map.get(f.endLine + 1); if (nx && (nx.kind === 'node' || nx.kind === 'frame')) nx.gapAbove = 1; } for (let q = f.line + 1; q <= f.endLine; q++) { const p = map.get(q); if (p) p.frames.push({ x0: fp.bx0, x1: fp.bx1, end: q === f.endLine }); }
        if (f.endLine === f.line) fp.frameEnd = true; }
      /* 線：子の右端から親の背骨へ枝、背骨は親の箱の下へ（矢印は親へ＝施策 → 中間目的 → 勝利条件） */
      for (const [, it] of B.map) {
        if (it.kind !== 'node' || !it.kids.length) continue; const pp = map.get(it.line); if (!pp) continue;
        const sx = Math.min(pp.bx1 - 0.75, R(it.depth + 1) + 1.5); const c0 = it.kids[0], cL = it.kids[it.kids.length - 1];
        for (let q = c0; q <= cL; q++) { const p = map.get(q); if (!p) continue; p.spines.push({ x: sx, half: q === cL, head: q === c0 }); }
        for (const c of it.kids) { const p = map.get(c); if (p) p.tick = { x0: p.bx1, x1: sx }; } }
      /* 1.0.14g 横長の紙面（または「列」を選んだプ譜）：列の図に置き換える（入らなければ字下げのまま） */
      if (colsWanted(doc, B, opt)) { const C = layoutCols(doc, B, { ...opt, L0, R0 }); if (C && C.figQs.every(q => C.P.has(q))) { for (const [q, e] of C.P) { const first = q === C.figQs[0];
        map.set(q, { kind: e.kind, role: e.role, depth: e.depth, bx0: e.bx0, bx1: e.bx1, L: e.L, R: e.R, tag: e.tag != null ? e.tag : null, tagShade: null, tagBold: !!e.tagBold, fill: e.fill || null, bold: !!e.bold, box: true, top: !!e.top, end: !!e.end, topKind: e.topKind || 'thin', sideKind: e.sideKind || 'thin', bottomKind: e.bottomKind || 'thin', frames: [], spines: [], tick: null, keepNext: false, gapAbove: 0, insight: !!e.insight, bullet: e.bullet != null ? e.bullet : null, fig: { id: B.head, dy: e.dy, H: C.H, first, deco: first ? C.D : null } }); } } }
      for (const [, p] of map) if (!p.sig) p.sig = JSON.stringify([p.kind, p.bx0, p.bx1, p.L, p.R, p.tag, p.tagShade, p.fill, p.bold, p.top, p.end, p.topKind, p.sideKind, p.bottomKind, p.frames, p.spines, p.tick, p.pair, p.keepNext, p.gapAbove, p.frameEnd, p.tagBold, p.insight, p.bullet, p.fig]);
    }
    return map;
  }
  FZ.pufuLayoutMap = layoutMap;
  /* ---------- 1.0.14g 列の図（横長の紙面）----------
     本来のプ譜の形：右に 勝利条件（上）と 獲得目標（下）、その左に 中間目的、その左に 施策（段取りは施策の箱の中に「・」で）、紙面が広ければ左端に 資源と制約。
     上に列の名前の帯（墨に白抜き）。施策 → 中間目的 → 勝利条件 → 獲得目標 へ矢印。取組は中間目的と施策をまとめて太罫で囲み、上に帯（取組N と名前）。
     行の位置は図の頭からの相対（fig.dy）。組版が図の頭（pfTop）を決め、行を y = pfTop + dy に置く。図は 1 頁に収める（入らなければ字下げの形）。
     opt.measure(q, L, R, bold) → 行数（組版の折り返しと同じ）、opt.rows（頁の行数）、opt.landscape */
  FZ.PUFU_COLS_MIN = 56;
  const half2 = v => Math.round(v * 2) / 2;
  function colsWanted(doc, B, opt) { const f = doc.lines[B.head].attrs.pufuForm, W = (opt.R0 || 40) - (opt.L0 || 0); if (f === 'tree' || !opt.measure || !opt.rows) return false; if (f === 'cols') return W >= 40; return W >= FZ.PUFU_COLS_MIN || (!!opt.landscape && W >= 40); }
  function layoutCols(doc, B, opt) {
    const L0 = opt.L0 || 0, R0 = opt.R0, W = R0 - L0, ROWS = opt.rows, ms = (q, L, R, bold) => Math.max(1, opt.measure(q, L, R, bold) | 0);
    if (B.roots.length !== 1) return null; const root = B.map.get(B.roots[0]); if (!root || root.kind !== 'node') return null;
    if (root.kids.some(c => B.map.get(c).kind !== 'node')) return null; /* 勝利条件をまとめる取組は字下げの形で */
    if (B.frames.some(f => f.depth !== 2)) return null; /* 取組は中間目的をまとめるものだけ（施策・段取りをまとめる取組は字下げの形で） */
    const isTree = it => it.kind === 'node' || it.kind === 'frame' || it.kind === 'cont';
    const treeQs = [...B.map.keys()].filter(q => isTree(B.map.get(q))).sort((a, b) => a - b);
    const resQs = B.res ? [...B.map.keys()].filter(q => !isTree(B.map.get(q))).sort((a, b) => a - b) : [];
    const resLeft = !!B.res && W >= 72; const figQs = (resLeft ? [...treeQs, ...resQs] : treeQs).sort((a, b) => a - b);
    for (let k = 1; k < figQs.length; k++) if (figQs[k] !== figQs[k - 1] + 1) return null; /* 図の行は続いていること（途中に前書きの段落などがあれば字下げの形） */
    const nW = root.kids.length, RM = nW > 1 ? 1.5 : 0; let x = L0, avail = W - 4 - RM - (resLeft ? 1 : 0); let res = null;
    if (resLeft) { const rw = half2(avail * 0.19); res = [x, x + rw]; x += rw + 1; avail -= rw; }
    const mw = half2(avail * 0.37), dw = half2(avail * 0.34), gw = avail - mw - dw; const meas = [x, x + mw]; x += mw + 2; const mid = [x, x + dw]; x += dw + 2; const goal = [x, x + gw];
    if (gw < 6 || dw < 6 || mw < 6) return null;
    const P = new Map(); const D = { fills: [], hrules: [], vrules: [], glyphs: [], heads: [] };
    const put = (q, y, o) => { const it = B.map.get(q); const h = ms(q, o.L, o.R, !!o.bold); P.set(q, { ...o, dy: y, h, it }); return y + h; };
    const boxSeq = (qs, y, o, extra) => { const y0 = y; qs.forEach((q, k) => { const e = extra ? extra(q) : {}; y = put(q, y, { ...o, ...e, top: k === 0, end: k === qs.length - 1 }); }); return y; };
    const col = c => ({ bx0: c[0], bx1: c[1], L: c[0] + 0.5, R: c[1] - 0.5 });
    const guess = it => it && it.guess ? 'dotted' : 'thin';
    /* 施策の箱：施策・その続き・段取り（と続き）を字の順に */
    const subtree = it => { const out = [it.line, ...(it.conts || [])]; for (const c of it.kids || []) out.push(...subtree(B.map.get(c))); return out.sort((a, b) => a - b); };
    const placeS = (s, y) => { const qs = subtree(s); const k0 = col(meas); return boxSeq(qs, y, { ...k0, kind: 'node', depth: 3, role: '施策', box: true, sideKind: guess(s), topKind: guess(s), bottomKind: guess(s) }, q => { const it = B.map.get(q); if (it.kind === 'node' && it.depth >= 4) { const L = k0.L + (it.depth - 4) + 1; return { L, bullet: L - 1, kind: 'node', depth: it.depth, role: '段取り' }; } if (it.kind === 'cont') { const o = B.map.get(it.owner); if (o && o.depth >= 4) { const L = k0.L + (o.depth - 4) + 1; return { L, kind: 'cont', role: '段取り', insight: !!it.insight }; } return { kind: 'cont', insight: !!it.insight, role: it.out ? '成果物' : '施策' }; } return {}; }); };
    const Ms = []; const Fs = [];
    const placeM = (m, y) => { const qs = [m.line, ...m.conts].sort((a, b) => a - b); const yEnd = boxSeq(qs, y, { ...col(mid), kind: 'node', depth: 2, role: '中間目的', box: true, sideKind: guess(m), topKind: guess(m), bottomKind: guess(m) }, q => q === m.line ? {} : { kind: 'cont', insight: !!B.map.get(q).insight, role: B.map.get(q).out ? '成果物' : '中間目的' });
      let ys = y; const S = []; for (const c of m.kids) { const s = B.map.get(c); if (s.kind !== 'node') return null; S.push({ q: c, y: ys }); ys = placeS(s, ys); }
      Ms.push({ m, y, S }); return Math.max(yEnd, ys); };
    /* 列の名前の帯 */
    const Hh = resLeft ? ms(B.res.line, res[0] + 0.5, res[1] - 0.5, true) : 1;
    if (resLeft) boxSeq([B.res.line], 0, { ...col(res), kind: 'res', role: '資源と制約', fill: 'ink', bold: true, box: true, sideKind: 'thin', topKind: 'thin', bottomKind: 'thin' });
    for (const [c, t] of [[meas, showName(B, '施策')], [mid, showName(B, '中間目的')], [goal, showName(B, '勝利条件')]]) D.heads.push({ x0: c[0], x1: c[1], y0: 0, y1: Hh, text: t });
    /* 勝利条件ごとに：子（取組・中間目的）を上から。勝利条件の箱は最初の子の高さに */
    let y = Hh; const Wg = [];
    for (let j = 0; j < root.kids.length; j++) { if (j) y += 1; const w = B.map.get(root.kids[j]); const y0 = y; let yy = y, first = true; const myMs = [];
      for (const c of w.kids) { const it = B.map.get(c); if (!first) yy += 1; first = false;
        if (it.kind === 'frame') { const x0 = meas[0], x1 = mid[1] + 0.5, fy0 = yy; yy = boxSeq([it.line, ...it.conts].sort((a, b) => a - b), yy, { kind: 'frame', role: '取組', bx0: x0, bx1: x1, L: x0 + TW + 0.5, R: x1 - 0.5, tag: showName(B, '取組') + (it.no || ''), tagBold: true, fill: 'gray', bold: true, box: true, topKind: 'thick', sideKind: 'thick', bottomKind: 'thin' });
          it.kids.forEach((mq, k) => { if (k) yy += 1; const n0 = Ms.length; const r = placeM(B.map.get(mq), yy); if (r == null) yy = NaN; else { yy = r; myMs.push(...Ms.slice(n0)); } }); Fs.push({ x0, x1, y0: fy0, y1: yy }); }
        else if (it.kind === 'node') { const n0 = Ms.length; const r = placeM(it, yy); if (r == null) return null; yy = r; myMs.push(...Ms.slice(n0)); } }
      if (!Number.isFinite(yy)) return null;
      const wEnd = boxSeq([w.line, ...w.conts].sort((a, b) => a - b), y0, { ...col(goal), kind: 'node', depth: 1, role: '勝利条件', bold: true, box: true, sideKind: guess(w), topKind: guess(w), bottomKind: guess(w) }, q => q === w.line ? {} : { kind: 'cont', bold: false, insight: !!B.map.get(q).insight });
      Wg.push({ w, y0, wEnd, Ms: myMs }); y = Math.max(yy, wEnd); }
    const contentBottom = y; const gq = [root.line, ...root.conts].sort((a, b) => a - b);
    const hG = gq.reduce((t, q) => t + ms(q, goal[0] + 0.5, goal[1] - 0.5, q === root.line), 0); const lastW = Wg.length ? Math.max(...Wg.map(g => g.wEnd)) : Hh;
    const gy = Math.max(lastW + 1, contentBottom - (1 + hG)); D.heads.push({ x0: goal[0], x1: goal[1], y0: gy, y1: gy + 1, text: showName(B, '獲得目標') });
    const gEnd = boxSeq(gq, gy + 1, { ...col(goal), kind: 'node', depth: 0, role: '獲得目標', bold: true, box: true, sideKind: guess(root), topKind: guess(root), bottomKind: guess(root) }, q => q === root.line ? {} : { kind: 'cont', bold: false, insight: !!B.map.get(q).insight });
    let resEnd = 0; if (resLeft) { let yy = Hh; for (const it of B.res.items) yy = boxSeq([it.line, ...it.conts], yy, { ...col(res), kind: 'resItem', role: '資源と制約', box: true, sideKind: 'thin', topKind: 'thin', bottomKind: 'thin' }, q => q === it.line ? {} : { kind: 'resCont' }); resEnd = yy; }
    const H = Math.max(contentBottom, gEnd, resEnd); if (H > ROWS - 2) return null;
    /* 線（図の頭からの相対。矢印は親へ） */
    const mid1 = (q) => P.get(q).dy + 0.5;
    const HR = (yy, a, b, kind, dir) => D.hrules.push({ y: yy, from: a, to: b, kind, dir }), VR = (xx, a, b, kind, dir) => D.vrules.push({ col: xx, y1: a, y2: b, kind, dir });
    for (const M of Ms) { if (!M.S.length) continue; const ym = mid1(M.m.line), sx = meas[1] + 1; const ys = M.S.map(s => mid1(s.q));
      HR(ym, ys[0] === ym ? meas[1] : sx, mid[0], 'arrow', 'r'); for (let k = 0; k < ys.length; k++) if (!(k === 0 && ys[0] === ym)) HR(ys[k], meas[1], sx, 'thin'); const lo = Math.min(ym, ...ys), hi = Math.max(ym, ...ys); if (hi > lo) VR(sx, lo, hi, 'thin'); }
    for (const g of Wg) { if (!g.Ms.length) continue; const yw = mid1(g.w.line), sx = mid[1] + 1.25; const ys = g.Ms.map(M => mid1(M.m.line));
      HR(yw, ys.includes(yw) ? mid[1] : sx, goal[0], 'arrow', 'r'); for (const yy of ys) if (yy !== yw) HR(yy, mid[1], sx, 'thin'); const lo = Math.min(yw, ...ys), hi = Math.max(yw, ...ys); if (hi > lo) VR(sx, lo, hi, 'thin'); }
    if (Wg.length === 1) { const cx = half2((goal[0] + goal[1]) / 2); if (gy > Wg[0].wEnd) VR(cx, Wg[0].wEnd, gy, 'arrow', 'd'); }
    else if (Wg.length > 1) { const sx = goal[1] + 0.75, yg = mid1(root.line); const ys = Wg.map(g => mid1(g.w.line)); for (const yy of ys) HR(yy, goal[1], sx, 'thin'); HR(yg, goal[1], sx, 'arrow', 'l'); VR(sx, Math.min(...ys), yg, 'thin'); }
    for (const f of Fs) { HR(f.y0, f.x0, f.x1, 'thick'); HR(f.y1, f.x0, f.x1, 'thick'); VR(f.x0, f.y0, f.y1, 'thick'); VR(f.x1, f.y0, f.y1, 'thick'); }
    return { P, D, H, figQs, resLeft, cols: { meas, mid, goal, res } };
  }
  /* 組版と書き出しで同じ欄（資料の書式は図表欄まで使う全幅） */
  FZ.pufuRegion = geo => ({ L0: 0, R0: geo.side ? geo.cols : geo.bodyCols });

  /* ---------- 書き出し：プ譜を図形に（Word・PowerPoint 共通の形。単位は字と行。紙面の組版の結果から作るので、見た目は紙面と同じ） ----------
     FZ.pufuShapes(doc, lay) → [{ start, end, pages: [{ page, left, right, top, bottom, rects, frames, lines }] }]
       rect  = { role, x, y, w, h, fill（網の id か null）, stroke（'thin'|'thick'|'dotted'）, paras: [{ line, text }], bold, align: 'l'|'c', dark（白抜きの字）, pad（字の左右の余白）, name }
       frame = { x, y, w, h }（太罫の囲み。塗らない）
       line  = { x1, y1, x2, y2, kind, head（終点に矢印＝親を指す） }
     箱は「役の札」と「字の箱」の 2 つ（字は箱の中で直せる）。頁をまたぐ枠・背骨は頁ごとに切る */
  FZ.pufuShapes = function (doc, lay) {
    const map = lay.pufuAt || layoutMap(doc, FZ.pufuRegion(lay.geo)); const out = []; const L = doc.lines; /* 1.0.14g 組版が使った前処理（列の図の位置も）をそのまま */
    const rowsOf = q => (lay.lineMap[q] && lay.lineMap[q].rows) || [];
    for (const B of blocks(doc)) {
      if (!map.has(B.start) && ![...B.map.keys()].some(q => map.has(q))) continue;
      const P = new Map(); const pg = p => { if (!P.has(p)) P.set(p, { page: p, rects: [], frames: [], lines: [], spines: new Map(), left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity }); return P.get(p); };
      const grow = (o, x0, x1, y0, y1) => { o.left = Math.min(o.left, x0); o.right = Math.max(o.right, x1); o.top = Math.min(o.top, y0); o.bottom = Math.max(o.bottom, y1); };
      const subtree = it => { const o = [it.line, ...(it.conts || [])]; for (const c of it.kids || []) o.push(...subtree(B.map.get(c))); return o.sort((a, b) => a - b); };
      for (const [q, it] of B.map) {
        if (!/^(node|frame|res|resItem)$/.test(it.kind)) continue; const pf = map.get(q); if (!pf) continue;
        if (pf.fig && it.kind === 'node' && it.depth >= 4) continue; /* 1.0.14g 列の図の段取りは施策の箱の中 */
        const group = pf.fig && it.kind === 'node' && it.depth === 3 ? subtree(it) : [q, ...(it.conts || [])]; const byPage = new Map();
        for (const g of group) for (const r of rowsOf(g)) { if (!byPage.has(r.page)) byPage.set(r.page, { y0: r.y, y1: r.y + r.h, lines: [] }); const sg = byPage.get(r.page); sg.y0 = Math.min(sg.y0, r.y); sg.y1 = Math.max(sg.y1, r.y + r.h); if (!sg.lines.includes(g)) sg.lines.push(g); }
        for (const [p, sg] of byPage) { const o = pg(p); grow(o, pf.bx0, pf.bx1, sg.y0, sg.y1); const hasTag = pf.tag != null || !!pf.tagShade; const tx = hasTag ? pf.bx0 + TW : pf.bx0; const stroke = pf.kind === 'frame' ? 'thin' : (pf.sideKind || 'thin');
          const role = pf.kind === 'node' ? pf.role : pf.kind === 'frame' ? pf.tag : '資源と制約';
          if (hasTag) o.rects.push({ role: 'tag', x: pf.bx0, y: sg.y0, w: TW, h: sg.y1 - sg.y0, fill: pf.tagShade || pf.fill || null, stroke, paras: sg.lines.includes(q) && pf.tag ? [{ text: pf.tag }] : [], bold: !!pf.tagBold, align: 'c', dark: !!(pf.tagShade && FZ.inkShade && FZ.inkShade(pf.tagShade)), pad: 0, name: (pf.tag || role) + 'の札' });
          const paras = []; for (const g of sg.lines) { const gi = B.map.get(g); if (gi && gi.insight) { const rr = rowsOf(g).filter(r => r.page === p); const n = rr.reduce((t, r) => t + r.h, 0); for (let k = 0; k < n; k++) paras.push({ text: '' }); if (rr.length) { const gp = map.get(g); o.rects.push({ role: '気づき', x: gp.L - 0.25, y: rr[0].y + 0.12, w: gp.R - gp.L + 0.5, h: rr[rr.length - 1].y + rr[rr.length - 1].h - rr[0].y - 0.24, fill: 'text', stroke: 'dotted', paras: [{ line: g, text: textOf(L[g]) }], bold: false, align: 'l', dark: false, pad: 0.25, name: '気づき：' + textOf(L[g]).slice(0, 24), late: true }); } } else { const gp = map.get(g), gi = B.map.get(g); const pre = gp && gp.bullet != null && gi ? '　'.repeat(Math.max(0, (gi.depth | 0) - 4)) + '・' : ''; paras.push(pre ? { line: g, text: pre + textOf(L[g]), pre } : { line: g, text: textOf(L[g]) }); } }
          o.rects.push({ role, x: tx, y: sg.y0, w: pf.bx1 - tx, h: sg.y1 - sg.y0, fill: pf.fill || null, stroke, paras, bold: !!pf.bold, align: 'l', dark: !!(pf.fill && FZ.inkShade && FZ.inkShade(pf.fill)), pad: 0.5, name: role + '：' + textOf(L[q]).slice(0, 24) }); }
      }
      for (const f of B.frames) { const fp = map.get(f.line); if (!fp) continue; const byPage = new Map(); for (let q = f.line; q <= f.endLine; q++) for (const r of rowsOf(q)) { if (!byPage.has(r.page)) byPage.set(r.page, [r.y, r.y + r.h]); const v = byPage.get(r.page); v[0] = Math.min(v[0], r.y); v[1] = Math.max(v[1], r.y + r.h); }
        for (const [p, [y0, y1]] of byPage) { const o = pg(p); o.frames.push({ x: fp.bx0, y: y0, w: fp.bx1 - fp.bx0, h: y1 - y0, name: (fp.tag || '取組') + '：' + textOf(L[f.line]).slice(0, 24) }); grow(o, fp.bx0, fp.bx1, y0, y1); } }
      for (const [q, it] of B.map) { const pf = map.get(q); if (!pf) continue; const rs = rowsOf(q); if (!rs.length) continue;
        const gapUp = pf.gapAbove && rs[0].y - pf.gapAbove >= 0 ? pf.gapAbove : 0; /* 上の空きを背骨が通る（空きを入れた時だけ：頁の頭では空けない） */
        for (const sp of pf.spines) { const segs = sp.half ? [[rs[0], rs[0].y, rs[0].y + Math.min(rs[0].h, 1) / 2]] : rs.map(r => [r, r.y, r.y + r.h]); if (gapUp) segs.unshift([rs[0], rs[0].y - gapUp, rs[0].y]);
          for (const [r, y0, y1] of segs) { const o = pg(r.page); if (!o.spines.has(sp.x)) o.spines.set(sp.x, []); o.spines.get(sp.x).push({ y0, y1, head: sp.head && r === rs[0] }); grow(o, sp.x, sp.x, y0, y1); } }
        if (pf.tick) { const r = rs[0], y = r.y + Math.min(r.h, 1) / 2; const o = pg(r.page); o.lines.push({ x1: pf.tick.x0, y1: y, x2: pf.tick.x1, y2: y, kind: 'thin' }); grow(o, pf.tick.x0, pf.tick.x1, y, y); } }
      for (const [q] of B.map) { const pf = map.get(q); if (!pf || !pf.fig || !pf.fig.first || !pf.fig.deco) continue; const rs = rowsOf(q); if (!rs.length) continue; /* 1.0.14g 列の図：列の名前の帯と矢印 */
        const top = rs[0].y - pf.fig.dy, o = pg(rs[0].page), D = pf.fig.deco;
        for (const h of D.heads) { o.rects.push({ role: 'head', x: h.x0, y: top + h.y0, w: h.x1 - h.x0, h: h.y1 - h.y0, fill: 'ink', stroke: 'thin', paras: [{ text: h.text }], bold: true, align: 'c', dark: true, pad: 0, name: '列の名前：' + h.text }); grow(o, h.x0, h.x1, top + h.y0, top + h.y1); }
        for (const r of D.hrules) if (r.kind !== 'thick') { const yy = top + r.y; const [x1, x2] = r.dir === 'l' ? [r.to, r.from] : [r.from, r.to]; o.lines.push({ x1, y1: yy, x2, y2: yy, kind: r.kind, head: r.kind === 'arrow' }); grow(o, Math.min(x1, x2), Math.max(x1, x2), yy, yy); }
        for (const r of D.vrules) if (r.kind !== 'thick') { const [a, b] = r.dir === 'u' ? [r.y2, r.y1] : [r.y1, r.y2]; o.lines.push({ x1: r.col, y1: top + a, x2: r.col, y2: top + b, kind: r.kind, head: r.kind === 'arrow' }); grow(o, r.col, r.col, top + Math.min(a, b), top + Math.max(a, b)); } }
      for (const o of P.values()) { o.rects.sort((a, b) => (a.late ? 1 : 0) - (b.late ? 1 : 0)); /* 気づきの箱は持ち主の箱の上に */ for (const [x, segs] of o.spines) { segs.sort((a, b) => a.y0 - b.y0); let cur = null; const flush = () => { if (cur) o.lines.push({ x1: x, y1: cur.y1, x2: x, y2: cur.y0, kind: cur.head ? 'arrow' : 'thin', head: cur.head }); };
          for (const sgm of segs) { if (cur && sgm.y0 <= cur.y1 + 1e-6) { cur.y1 = Math.max(cur.y1, sgm.y1); continue; } flush(); cur = { y0: sgm.y0, y1: sgm.y1, head: sgm.head }; } flush(); }
        delete o.spines; }
      out.push({ start: B.start, end: B.end, head: B.head, pages: [...P.values()].sort((a, b) => a.page - b.page) });
    }
    return out;
  };

  /* ---------- 点検 ----------
     [{ line, msg, level: 'warn'|'info' }]。考案者の記法（3 階層・中間目的は状態・2〜3 個・目的と手段のつじつま）と、文机の受け渡しの決まりから */
  const strip = t => String(t).replace(/〔推測〕/g, '').replace(/[\s　。．.]+$/, '').replace(/[（(][^（）()]*[）)]$/, '').replace(/[\s　。．.]+$/, '');
  const TASK_RE = /(する|します|しよう|行う|おこなう|実施|作成|作る|つくる|検討|進める|決める|整備|導入|対応|構築|策定|開催|設定|準備|調査|確認)$/;
  const THING_RE = /(書|表|資料|一覧|計画書|報告書|マニュアル|手順書|仕様)$/;
  const NOUN_END = /[一-鿿゠-ヿA-Za-z0-9ー々〆]$/;
  FZ.pufuLint = function (doc) {
    const L = doc.lines, out = []; const W = (line, msg) => out.push({ line, msg, level: 'warn' }), I = (line, msg) => out.push({ line, msg, level: 'info' });
    for (const B of blocks(doc)) {
      const txt = q => textOf(L[q]);
      if (!B.roots.length) W(B.head, 'プ譜：獲得目標がありません（この節の下に、与えられた使命を 1 項目で書く）');
      if (B.roots.length > 1) W(B.roots[1], '獲得目標は 1 つ（2 つ目からは別のプ譜に分ける）');
      const nodeKids = it => { const r = []; for (const c of it.kids) { const k = B.map.get(c); if (!k) continue; if (k.kind === 'frame') r.push(...nodeKids(k)); else if (k.kind === 'node') r.push(k); } return r; };
      const seen = new Map();
      for (const [q, it] of B.map) {
        if (it.kind === 'frame') { const t = strip(txt(q)); const n = nodeKids(it).length;
          if (!t) W(q, '取組の名前がありません（まとめる目的を「〜を〜にする」で）');
          else if (NOUN_END.test(t)) W(q, '取組の名前は目的の言い方に（「〜を〜にする」「〜を確かにする」）。作業の分類名だと、左から読んだ時に工程の話になる');
          if (n < 2) I(q, '取組は、同じ上位の要求のもとにある 2 つ以上の中間目的をまとめる時に使う');
          if (it.frame != null) W(q, '取組の中の取組：入れ子は紙面で重なる（1 段にする）');
          if (it.depth !== 2) I(q, '取組は中間目的をまとめるもの（勝利条件のすぐ下に置く）');
          continue; }
        if (it.kind !== 'node') continue; const t = strip(txt(q));
        if (it.guess) I(q, '〔推測〕：本文に無かったものを補った所。確かめたら〔推測〕を消す');
        if (OUT_RE.test(txt(q))) W(q, '成果物は、その中間目的のすぐ下（最初の子）に書く（離れていると箱の続きにならない）');
        if (!t) { W(q, `${roleName(it.depth)}が空です`); continue; }
        if (it.depth === 0) { const ws = nodeKids(it); if (!ws.length) W(q, '勝利条件がありません（どうなっていたら成功と言えるか）'); if (ws.length > 3) W(ws[3].line, '勝利条件は 1 つ、多くても 3 つ'); }
        if (it.depth === 1) { const ps = nodeKids(it); if (!ps.length) W(q, '中間目的がありません（勝利条件が成り立つために満たしているべき状態）'); else if (ps.length === 1) W(q, '中間目的が 1 つだけ：それ自体が勝利条件になっている。2〜3 の状態に分ける'); else if (ps.length > 4) W(ps[4].line, '中間目的が多すぎる（1 つの勝利条件に 2〜3。同じ要求のものは枠でまとめて 3 程度に）'); }
        if (it.depth === 2) { if (TASK_RE.test(t)) W(q, '中間目的は状態で書く（〜している・〜できている・〜になっている）。作業の言い方は施策へ');
          else if (THING_RE.test(t)) W(q, '中間目的が成果物の名前に見える：その成果物で何が整った状態かを書き、物は「成果物：」に');
          const ms = nodeKids(it); if (!ms.length) W(q, '施策がありません（この状態をつくる具体的な行動）'); else if (ms.length > 3) I(ms[3].line, '施策が 4 つ以上：細かいものは一段深く（段取り）へ'); }
        if (it.depth === 3) { if (!/[（(][^（）()]+[）)][\s　]*(〔推測〕)?[\s　]*$/.test(txt(q))) I(q, '施策の担当・期日が書かれていない（「（担当・期日）」を添える）');
          const k = t.replace(/[\s　]/g, ''); if (seen.has(k)) W(q, '同じ施策が 2 か所（多対多）：中間目的の言い方を見直して 1 つに寄せる'); else seen.set(k, q); }
      }
      if (!B.res) I(B.head, '資源と制約（廟算八要素）がありません（いまの状況：ひと・お金・時間・…）');
      else { for (const x of B.res.items) { const t = txt(x.line); const v = t.replace(/^[^：:]*[：:]/, '').trim(); if (!v || /^記載なし$/.test(v)) I(x.line, `資源と制約の「${t.replace(/[：:].*$/, '')}」が空`); } }
    }
    return out;
  };

  /* ---------- 入れる型 ----------
     lv：プ譜の節の番号見出しの段（1 から）。行は { text, attrs }。手引きは（ ）で書き、書き換える */
  FZ.pufuSkeleton = function (lv) {
    const H = { style: 'num', level: Math.max(0, Math.min(7, (lv | 0) - 1)), pufu: true }; const I = (k, x = {}) => ({ list: { kind: 'bullet', level: k }, ...x });
    return [
      { text: 'プ譜：', attrs: H }, /* 1.0.16h 手引きは字にしない（空の箱に薄く出る） */
      { text: '', attrs: I(0) },
      { text: '', attrs: I(1) },
      { text: '', attrs: I(2, { pufuFrame: true }) },
      { text: '', attrs: I(3) },
      { text: '', attrs: I(4) },
      { text: '', attrs: I(3) },
      { text: '', attrs: I(4) },
      { text: '資源と制約（廟算八要素）', attrs: I(0, { pufuRes: true }) },
      ...RES_KEYS.map(k => ({ text: k + '：', attrs: I(1) })),
    ];
  };

  /* ---------- AI の答えを読む ----------
     「# プ譜：題」「- 役：本文」（字下げで親子）「## 資源と制約」「## 読み取れなかったこと」「## 注」。役の名前は外し（成果物は残す）、枠は印に。
     → { title, items: [{ level, text, frame }], res: [text], questions: [text], notes: [text], warn: [text] } */
  const ROLE_PREFIX = /^(獲得目標|勝利条件|中間目的|施策|段取り|明細|取組[0-9０-９]*|枠|成果物|補足)[\s　]*[：:][\s　]*/; /* 1.0.14b までの「枠」「明細」も読む */
  FZ.pufuFromMd = function (text) {
    let s = String(text || '').replace(/\r\n?/g, '\n'); const fence = s.match(/```[a-zA-Z]*\n([\s\S]*?)```/); if (fence && /^\s*[-*#]/m.test(fence[1])) s = fence[1];
    const r = { title: '', items: [], res: [], questions: [], notes: [], changes: [], warn: [] }; let sec = 'tree'; const ind = []; /* 開いている字下げの幅 */
    for (const raw of s.split('\n')) {
      const line = raw.replace(/\t/g, '    '); if (!line.trim()) continue;
      let m;
      if ((m = line.match(/^#\s+(.+)$/))) { if (!r.title) r.title = m[1].trim(); sec = 'tree'; continue; }
      if ((m = line.match(/^#{2,6}\s+(.+)$/))) { const h = m[1].trim(); sec = /資源|制約|廟算|八要素/.test(h) ? 'res' : /読み取れ|問い|質問|確かめ/.test(h) ? 'q' : /直した|変えた|変更/.test(h) ? 'chg' : /^注|注記|メモ/.test(h) ? 'note' : 'other'; continue; }
      if ((m = line.match(/^(\s*)(?:[-*+・]|\d+[.)．])\s+(.*)$/))) { const w = m[1].length; let t = m[2].trim();
        if (sec === 'tree') { while (ind.length && ind[ind.length - 1] > w) ind.pop(); if (!ind.length || ind[ind.length - 1] < w) ind.push(w); const level = ind.length - 1;
          const rm = t.match(ROLE_PREFIX); const role = rm ? rm[1] : ''; if (rm && role !== '成果物') t = t.slice(rm[0].length);
          if (rm && role === '成果物') t = '成果物：' + t.slice(rm[0].length);
          const fr = role === '枠' || /^取組/.test(role); r.items.push({ level, text: t, frame: fr, para: role === '補足', role: fr ? '取組' : role === '明細' ? '段取り' : role }); }
        else if (sec === 'res') r.res.push(t); else if (sec === 'q') r.questions.push(t); else if (sec === 'note') r.notes.push(t); else if (sec === 'chg') r.changes.push(t);
        continue; }
      if (sec === 'q') r.questions.push(line.trim()); else if (sec === 'note') r.notes.push(line.trim()); else if (sec === 'chg') r.changes.push(line.trim());
    }
    /* 役と深さの食い違い（取組を数えない深さ）を記録：役の名前が深さと合わなければ知らせる */
    { const st = []; for (const it of r.items) { if (it.para) continue; while (st.length && st[st.length - 1].level >= it.level) st.pop(); const d = st.reduce((n, x) => n + (x.frame ? 0 : 1), 0); it.depth = it.frame ? d : d;
        if (it.role && !it.frame && it.role !== '成果物' && ROLES.indexOf(it.role) >= 0 && ROLES.indexOf(it.role) !== d) r.warn.push(`「${it.role}：${it.text.slice(0, 16)}」の深さが役と合わない（${roleName(d)}の段にある）`); st.push(it); } }
    if (r.items.length && r.items[0].level !== 0) for (const it of r.items) it.level -= r.items[0].level;
    return r;
  };
  /* 読んだ答えを文書の行に：プ譜の節（番号見出し lv）・項目・資源と制約。返すのは { lines: [{ text, attrs }], note } */
  FZ.pufuLinesFromMd = function (P, lv) {
    const H = { style: 'num', level: Math.max(0, Math.min(7, (lv | 0) - 1)), pufu: true }; const I = (k, x = {}) => ({ list: { kind: 'bullet', level: Math.max(0, Math.min(7, k)) }, ...x });
    const title = P.title ? (/^プ譜/.test(P.title) ? P.title : 'プ譜：' + P.title) : 'プ譜';
    const lines = [{ text: title, attrs: H }];
    for (const it of P.items) lines.push(it.para ? { text: it.text, attrs: {} } : { text: it.text, attrs: I(it.level, it.frame ? { pufuFrame: true } : {}) }); /* 補足は段落（直前の箱の続き） */
    if (P.res.length) { lines.push({ text: '資源と制約（廟算八要素）', attrs: I(0, { pufuRes: true }) }); for (const t of P.res) lines.push({ text: t, attrs: I(1) }); }
    const note = [P.questions.length ? '読み取れなかったこと\n' + P.questions.map((q, k) => `${k + 1}. ${q.replace(/^\d+[.)．]\s*/, '')}`).join('\n') : '', P.notes.length ? '注\n' + P.notes.map(t => '・' + t).join('\n') : '', P.warn.length ? '取り込みの注意\n' + P.warn.map(t => '・' + t).join('\n') : ''].filter(Boolean).join('\n\n');
    return { lines, note };
  };

  /* ---------- 解説（画面の下） ---------- */
  FZ.PUFU_GUIDE = { id: 'pufu', name: 'プ譜', when: 'ゴールから逆算して道筋を描く。右（ありたい姿）から左（いまの姿）へ枝分かれし、左から読むと「行動 → 状態 → 成功」の筋になる', parts: [
    { n: '獲得目標', g: '与えられた使命。1 文で。後から変えない前提のもの（変わるなら別のプ譜にする）' },
    { n: '勝利条件', g: 'どうなっていたら成功と言えるか。関係者が判定できる状態と基準。1 つ、多くても 3 つ。局面ごとに見直してよい' },
    { n: '取組', g: '同じ上位の要求のもとにある中間目的のまとまり。紙面では太罫で囲み、取組1・取組2…と番号が付く。名前は目的の言い方（〜を〜にする・〜を確かにする）。作業の分類名（「要件定義」など）にしない' },
    { n: '中間目的', g: '勝利条件が成り立つために満たしているべき状態。〜している・〜できている・〜になっている。1 つの勝利条件に 2〜3' },
    { n: '成果物', g: 'その状態に達したと判断する証拠になる物。中間目的のすぐ下に「成果物：」で書く（箱の中に入る）' },
    { n: '施策', g: '状態をつくる具体的な行動。誰が・何を・いつまでに。1 つの中間目的に 1〜3' },
    { n: '段取り', g: '施策を進める具体的な手順・作業（誰が・何を）。多すぎる・細かすぎる施策はここへ回す' },
    { n: '気づき', g: 'やってみてわかったこと・思いもよらない結果。項目のすぐ後に「気づき：」で書くと、その箱の中の点線の吹き出しになる。次の局面で中間目的・施策に反映する' },
    { n: '資源と制約', g: 'いまの状況（廟算八要素）：ひと・お金・時間・クオリティ・商流／座組・環境・ライバル・外敵。施策が無理なく回るかをここで確かめる' },
  ] };
  FZ.pufuGuidePart = function (role) { return FZ.PUFU_GUIDE.parts.findIndex(p => p.n === role); };

  /* ---------- 文章からプ譜を起こす指示文（docs/プロンプト_文章からプ譜を起こす.md の本体。tools/build-prompts.js がこれから書き出す） ---------- */
  FZ.PUFU_PROMPT = `あなたはプロジェクトの「プ譜」を組み立てる編集者です。下の〈本文〉（議事録・発言録・個人の書いた文章・企画書など）を読み、プ譜の下書きに変換してください。プ譜は、ゴールから逆算して道筋を描く図です。右（ありたい姿）から左（いまの姿）へ枝分かれします。

## プ譜の要素

- **獲得目標**：プロジェクトに与えられた使命。1 つ。後から変えない前提のもの。本文の言葉で 1 文に。
- **勝利条件**：獲得目標を達成したと判断できる状態と基準。原則 1 つ、多くても 3 つ。「どうなっていたら成功と言えるか」を、関係者が判定できる形で書く。
- **中間目的**：勝利条件が成り立つために、チーム・人・中間成果物などが満たしているべき局所的な**状態**。
  - 1 つの勝利条件につき 2〜3 個（多くても 4 個）。
  - 必ず状態の言い方で書く（〜している／〜できている／〜になっている／〜が見えている）。
  - 作業（〜する）や、成果物の名前（〜書・〜表）で書かない。
- **成果物**：その中間目的に達したと判断する証拠になる物。中間目的に添える。無ければ書かない。
- **施策**：中間目的の状態をつくるための具体的な行動。1 つの中間目的につき 1〜3 個。誰が・何を・いつまでに、を本文から分かる範囲で括弧に添える。
- **段取り**：施策を進める具体的な手順・作業。施策が 3 個を超えるときや、細かすぎるときはここへ回す。
- **取組**：同じ上位の要求のもとにある中間目的のまとまり（文机では取組1・取組2…と番号が付く）。
  - 名前は目的の言い方にする（「〜を〜にする」「〜を確かにする」「〜の不安を消す」）。
  - 作業の分類名（「要件定義」「データ整備」など）にしない。
  - 2 つ以上の中間目的が同じ要求を共有するときだけ使う。1 つの勝利条件の下に多くても 3 つ。
- **資源と制約（廟算八要素）**：いまの状況。ひと／お金／時間／クオリティ／商流・座組／環境／ライバル／外敵 の 8 つ。

## 手順（この順に考える）

1. 本文から獲得目標を特定する。はっきり書かれていなければ、最も近い表現を候補にし、〔推測〕を付ける。
2. 勝利条件を決める。本文に判定の基準が無いことは多い。その場合は候補を〔推測〕で出し、「読み取れなかったこと」に問いとして挙げる。
3. 勝利条件から逆算して中間目的を出す。本文の「やること」の記述は、「それは何の状態をつくるためか」を問い、状態に言い換えてから中間目的にする。
4. 施策を、それがつくる状態（中間目的）の下に 1 つずつ置く。
   - 1 つの施策が複数の中間目的に効くように見えるときは、中間目的の言い方を見直して 1 つに寄せる。
   - 寄せられなければ主な方に置き、「注」に書く。
5. 中間目的を取組にまとめるかを判断する（取組の条件を満たすときだけ）。
6. 資源と制約を 8 つに分けて書く。本文に無いものは「記載なし」とする。
7. 下の点検表で確かめ、直してから出力する。

## 元の文章の読み方

最初に〈本文〉の種類を見分け、その種類に合った読み方をする。

- **議事録**：決定事項・宿題（担当・期限）・論点・懸念を分けて読む。決定事項と宿題は施策の候補（担当・期限は宿題の書き方のまま）。決まっていない論点は「読み取れなかったこと」へ。懸念は資源と制約（環境・外敵など）か、問いへ。「〜とする」「〜と確認した」は決定、「〜という意見があった」は決定ではない。
- **発言録**：発言者ごとの主張を混ぜない。複数の発言者が同じ方向を述べたことだけを中間目的・施策にする。一人だけの発言、意見が分かれた所は「読み取れなかったこと」に、誰と誰の意見が分かれているかを添えて書く。発言を決定として扱わない。発言者の名前は担当として使ってよい。
- **個人の書いた文章**（メモ・考え・下書き）：書き手の考えや仮説が多い。言い切っていない所には〔推測〕を付け、書き手が確かめるべき問いを多めに挙げる。担当が書かれていなければ「本人」としてよい。
- **企画書・報告書**：目的は獲得目標、目標・成功の基準は勝利条件、計画の項目は施策の候補として読む。章立てに引きずられず、状態（中間目的）を逆算で補う。

## 守ること

- 本文に無い事実（数字・日付・人名・部署・金額）を作らない。担当や期日が分からなければ書かない。
- 本文に書かれていない（推して補った）要素には、行末に〔推測〕を付ける。本文にある内容を、形に合わせて言い換えただけの所には付けない。
- 本文の言葉をなるべく使う。
- 1 つの行には 1 つのことだけを書く。「〜し、〜する」のように 2 つをまとめない。
- 字数の目安：獲得目標・勝利条件は 50 字以内、中間目的・施策は 40 字以内、取組の名前は 20 字以内。
- 本文がプロジェクトでない（ゴールも期限も無い単なる報告など）ときは、その旨を「注」に書き、プ譜にできる部分だけを出す。

## 出力の形

この形だけを出す。前置きや説明は書かない。字下げは半角の空白 2 つ。役の名前（獲得目標・勝利条件・取組・中間目的・成果物・施策・段取り）を、行の頭に必ず付ける。

\`\`\`markdown
# プ譜：〈題〉（局面 1・〈日付〉）
- 獲得目標：…
  - 勝利条件：…
    - 取組：…
      - 中間目的：…
        - 成果物：…
        - 施策：…（担当・期日）
          - 段取り：…
## 資源と制約
- ひと：…
- お金：…
- 時間：…
- クオリティ：…
- 商流・座組：…
- 環境：…
- ライバル：…
- 外敵：…
## 読み取れなかったこと
1. 〈問い〉（どの要素を決めるために要るか）
## 注
- 〈施策の置き場を迷った所、本文を状態に言い換えた所など〉
\`\`\`

- 取組を使わないときは、勝利条件の下に中間目的を直接置く。
- 成果物は、中間目的のいちばん初めの子に置く。
- 「読み取れなかったこと」と「注」は、無ければ見出しごと省く。

## 書き方の例（形の見本。中身は使わない）

\`\`\`markdown
- 獲得目標：社内勉強会を 4 月から毎月開く
  - 勝利条件：参加者が、自分の仕事で使った例を持ち寄っている〔推測〕
    - 取組：学んだことを仕事で使える形にする
      - 中間目的：毎回の題が、参加者の困りごとから選ばれている
        - 施策：困りごとの聞き取りを各課で行う（幹事・3 月）
      - 中間目的：使った例を共有する場が、毎回の後半に用意されている
        - 成果物：共有用の 1 枚の様式
        - 施策：後半 20 分を例の発表にあてる進行に変える（幹事）
\`\`\`

悪い例：「中間目的：勉強会の資料を作る」は作業であり、状態ではない。「その資料で何が整った状態になるか」に言い換える。

## 点検表（出力の前に確かめる）

- 中間目的は、すべて状態の言い方か。「〜する」で終わっていないか。
- 中間目的が 1 つしか無い勝利条件は無いか。1 つなら、それは勝利条件そのものになっている。
- 施策の無い中間目的は無いか。
- 施策はすべて、置いた中間目的の状態をつくる行動か（目的と手段のつじつま）。
- 取組の名前は目的の言い方か。
- 〔推測〕の要素は、「読み取れなかったこと」の問いで確かめられるようになっているか。
- 本文に無い数字・日付・名前を書いていないか。

〈題〉{{題}}
〈日付〉{{日付}}
〈本文〉
{{本文}}`;
  /* ---------- 文机のプ譜 → 役の名前付きの Markdown（AI に写す・指示文の〈プ譜〉）。取組は「取組：」、成果物は「成果物：」、項目の後の段落は「補足：」 ---------- */
  FZ.pufuToMd = function (doc, B) { return ['# ' + mdLines(doc, B, true)[0].text, ...mdLines(doc, B).map(x => x.text)].join('\n') + '\n'; };
  /* 役の名前付きの行と、文書の行の対応 [{ line, text }]（題の行は head=true の時だけ先頭に） */
  function mdLines(doc, B, headOnly) {
    const L = doc.lines; const T = q => (FZ.expandRefsText ? FZ.expandRefsText(doc, textOf(L[q])) : textOf(L[q])).replace(/\s+$/, ''); if (headOnly) return [{ line: B.head, text: T(B.head).trim() }]; const out = [];
    const ind = new Map(); const indOf = it => { if (!it) return -1; if (ind.has(it.line)) return ind.get(it.line); const v = it.parent == null ? 0 : indOf(B.map.get(it.parent)) + 1; ind.set(it.line, v); return v; };
    for (const [q, it] of B.map) {
      const P = t => out.push({ line: q, text: t });
      if (it.kind === 'node') P('  '.repeat(indOf(it)) + '- ' + roleName(it.depth) + '：' + T(q));
      else if (it.kind === 'frame') P('  '.repeat(indOf(it)) + '- 取組：' + T(q));
      else if (it.kind === 'cont') { const o = B.map.get(it.owner); P('  '.repeat(indOf(o) + 1) + '- ' + (it.out ? T(q).replace(/^[\s　]*成果物[\s　]*[：:][\s　]*/, '成果物：') : '補足：' + T(q))); }
      else if (it.kind === 'res') P('## 資源と制約');
      else if (it.kind === 'resItem') P('- ' + T(q));
      else if (it.kind === 'resCont') P('  - 補足：' + T(q)); }
    return out; }
  FZ.pufuMdLines = (doc, B) => mdLines(doc, B);
  /* 1.0.14e 局面の比較：記録した局面（役の名前付きの Markdown）と今のプ譜を行で比べる。→ { status: Map(文書の行 → 'add'|'chg'), was: Map(行 → 前の字), removed: [前にあって今は無い行] }。題の行（局面の番号）は比べない */
  FZ.pufuPhaseDiff = function (doc, B, md) {
    const cur = mdLines(doc, B), old = String(md || '').split('\n').filter(t => t.trim() && !/^#\s/.test(t));
    const sig = t => { const m = t.match(/^(\s*)-\s+([^：:]{1,8})[：:](.*)$/); return m ? m[1].length + m[2] + '|' + m[3].trim() : '|' + t.trim(); };
    const SA = cur.map(x => sig(x.text)), SB = old.map(sig); const status = new Map(), was = new Map(), removed = [];
    for (const h of FZ.diffSigs(SA, SB)) { const A = SA.slice(h.a[0], h.a[1]), Bv = SB.slice(h.b[0], h.b[1]);
      for (const op of FZ.alignLines(A, Bv)) { if (op.t === 'p') { const x = cur[h.a[0] + op.i]; status.set(x.line, 'chg'); was.set(x.line, old[h.b[0] + op.j].trim()); } else if (op.t === 'd') status.set(cur[h.a[0] + op.i].line, 'add'); else removed.push(old[h.b[0] + op.j].trim()); } }
    return { status, was, removed }; };
  /* 役の名前付きの箇条書きか（AI の答えをプ譜として読むか） */
  FZ.pufuIsMd = md => /^\s*[-*+]\s+(獲得目標|勝利条件|中間目的)[\s　]*[：:]/m.test(String(md || ''));
  /* 〈プ譜の要素〉は文章から起こす指示文と同じものを使う */
  const promptSec = name => { const P = FZ.PUFU_PROMPT, i = P.indexOf('## ' + name); const j = P.indexOf('\n## ', i + 3); return P.slice(i, j < 0 ? undefined : j).trim(); };
  const OUT_TREE = "```markdown\n# プ譜：〈題〉\n- 獲得目標：…\n  - 勝利条件：…\n    - 取組：…\n      - 中間目的：…\n        - 成果物：…\n        - 施策：…（担当・期日）\n          - 段取り：…\n## 資源と制約\n- ひと：…\n（8 つとも）\n";
  /* 点検して直す：直す必要の無い行は字を変えない（行ごとに比べて取り込むため） */
  FZ.PUFU_PROMPT_REVIEW = () => `あなたはプロジェクトの「プ譜」を点検して直す編集者です。下の〈プ譜〉を、プ譜の決まりに照らして点検し、直したプ譜を同じ形で返してください。プ譜は、ゴールから逆算して道筋を描く図です。

${promptSec('プ譜の要素')}

## 点検すること（この順に）

1. 中間目的は、すべて状態の言い方か。作業（〜する）や成果物の名前（〜書・〜表）になっていれば、「その作業で何が整った状態になるか」に言い換える。
2. 目的と手段のつじつま：各施策は、置かれた中間目的の状態をつくる行動か。各中間目的は、勝利条件が成り立つのに要る状態か。つながらないものは置き場を直すか、理由を添えて消す。
3. 逆算の穴：勝利条件が成り立つのに、まだ無い中間目的は無いか。あれば足し、行末に〔推測〕を付ける。
4. 勝利条件は、関係者が判定できる形か（何を見れば成功と言えるか）。
5. 数：勝利条件は 1〜3、中間目的は 1 つの勝利条件に 2〜3（多くても 4）、施策は 1 つの中間目的に 1〜3。多すぎる施策は段取りへ回す。
6. 取組：同じ上位の要求のもとにある中間目的がまとまっているか。名前は目的の言い方か。
7. 資源と制約から見て、無理な施策（人・時間・お金が足りない）は無いか。あれば施策を直すか「注」に書く。
8. 施策に担当・期日が無ければ、作らずに「読み取れなかったこと」に問いとして挙げる。

## 守ること

- 直す必要の無い行は、字を一字も変えずにそのまま返す（返した答えは、元のプ譜と行ごとに比べて取り込むため）。
- 獲得目標は変えない。変えるべきだと考えるなら「注」に書く。
- 元に無い事実（数字・日付・人名・部署・金額）を作らない。補った所には行末に〔推測〕を付ける。
- 行を消したときは、その行と理由を「直した所」に書く。
- 「補足：」の行は、その上の項目の説明。消さずにそのまま返す（直すときは理由を「直した所」に）。

## 出力の形

この形だけを出す。前置きや説明は書かない。字下げは半角の空白 2 つ。役の名前を行の頭に必ず付ける（元のプ譜と同じ書き方）。題は元のまま。

${OUT_TREE}## 直した所
- 〈どの行〉：〈何を、なぜ〉
## 読み取れなかったこと
1. 〈問い〉（どの要素を決めるために要るか）
## 注
- 〈獲得目標について気づいたことなど〉
\`\`\`

- 直した所が無ければ「直した所」に「なし」と書く。「読み取れなかったこと」と「注」は、無ければ見出しごと省く。

〈プ譜〉
{{プ譜}}`;
  /* 次の局面：新しい情報（会議の記録・進捗・やってみてわかったこと）を反映。関係しない行は字を変えない */
  FZ.PUFU_PROMPT_NEXT = () => `あなたはプロジェクトの「プ譜」の局面を進める編集者です。〈いまのプ譜〉に〈新しい情報〉（会議の記録・進捗・やってみてわかったこと）を反映し、次の局面のプ譜を同じ形で返してください。プ譜は、局面ごとにその時点の認識を描き直すものです。

${promptSec('プ譜の要素')}

## 進め方（この順に）

1. 〈新しい情報〉から事実（決まったこと・終わったこと・起きたこと・やってみてわかったこと）を拾う。
2. 終わった施策・段取りは消さずに、行末に「（済）」を付ける。「補足：気づき：」の行は、やってみてわかったこと。中間目的・施策に反映し、反映した気づきは消してよい（変えた所に書く）。
3. わかったことで、中間目的・施策を足す・言い換える・消す。新しい情報から推して足した所には、行末に〔推測〕を付ける。
4. 勝利条件は、新しい情報がそれを求めるときだけ見直す。獲得目標は変えない。
5. 資源と制約に変化があれば直す。

## 守ること

- 新しい情報に関係しない行は、字を一字も変えずにそのまま返す（返した答えは、いまのプ譜と行ごとに比べて取り込むため）。
- いまのプ譜にも新しい情報にも無い事実（数字・日付・人名・部署・金額）を作らない。
- 題に局面の番号があれば 1 つ進め、日付を〈日付〉にする。
- 変えた行・足した行・消した行は、理由（新しい情報のどこからか）を「変えた所」に書く。
- 中間目的は状態の言い方、施策は行動の言い方を守る。

## 出力の形

この形だけを出す。前置きや説明は書かない。字下げは半角の空白 2 つ。役の名前を行の頭に必ず付ける（いまのプ譜と同じ書き方）。

${OUT_TREE}## 変えた所
- 〈どの行〉：〈何を、なぜ（新しい情報のどこから）〉
## 読み取れなかったこと
1. 〈問い〉
\`\`\`

- 「読み取れなかったこと」は、無ければ見出しごと省く。

〈日付〉{{日付}}
〈いまのプ譜〉
{{プ譜}}
〈新しい情報〉
{{新しい情報}}`;
  FZ.pufuPromptReview = function (pufuMd) { return FZ.PUFU_PROMPT_REVIEW().replace('{{プ譜}}', String(pufuMd || '').trim()); };
  FZ.pufuPromptNext = function (pufuMd, info, date) { return FZ.PUFU_PROMPT_NEXT().replace('{{日付}}', date || '').replace('{{プ譜}}', String(pufuMd || '').trim()).replace('{{新しい情報}}', String(info || '').trim()); };
  /* 元の文章の種類：auto（見分けさせる）・minutes 議事録・speech 発言録・personal 個人の書いた文章・plan 企画書・報告書。指定すれば、その読み方だけを残す */
  FZ.PUFU_SOURCES = [['auto', '自動（AI に見分けさせる）'], ['minutes', '議事録'], ['speech', '発言録'], ['personal', '個人の書いた文章（メモ・考え）'], ['plan', '企画書・報告書']];
  const SRC_LABEL = { minutes: '**議事録**', speech: '**発言録**', personal: '**個人の書いた文章**', plan: '**企画書・報告書**' };
  FZ.pufuPrompt = function (body, title, date, kind) { let P = FZ.PUFU_PROMPT;
    if (kind && SRC_LABEL[kind]) { const i = P.indexOf('## 元の文章の読み方'), j = P.indexOf('\n## ', i + 3); const sec = P.slice(i, j); const line = sec.split('\n').find(l => l.startsWith('- ' + SRC_LABEL[kind])); if (line) P = P.slice(0, i) + '## 元の文章の読み方\n\n〈本文〉は' + SRC_LABEL[kind].replace(/\*/g, '') + 'である。次の読み方をする。\n\n' + line + '\n' + P.slice(j); }
    return P.replace('{{題}}', title || '').replace('{{日付}}', date || '').replace('{{本文}}', String(body || '').trim()); };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
