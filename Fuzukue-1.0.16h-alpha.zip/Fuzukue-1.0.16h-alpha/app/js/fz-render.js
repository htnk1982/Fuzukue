/* 文机 描画：組版結果 → SVG（文字は <text>、書体はCSS）。印刷にもそのまま使う。 */
(function (FZ) {
'use strict';
const M = FZ.M;
const num = v => String(Math.round(v * 100) / 100);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ASC = 0.88; // em box の上端から基線まで（BIZ UD / Noto CJK 共通）
const RULE = { thin: 0.5, thick: 1.6, double: 0.45, dotted: 0.6, arrow: 0.7, none: 0 };

/* 書体に無い行頭記号は図形で描く（どの環境でも同じ見た目） */
const MARKER_SHAPES = {
  '▪': (x, y, cw, ch, fs) => { const s = fs * 0.34, cx = x + cw / 2, cy = y + ch / 2; return `<rect x="${num(cx - s / 2)}" y="${num(cy - s / 2)}" width="${num(s)}" height="${num(s)}" fill="#111"/>`; },
  '▫': (x, y, cw, ch, fs) => { const s = fs * 0.34, cx = x + cw / 2, cy = y + ch / 2; return `<rect x="${num(cx - s / 2)}" y="${num(cy - s / 2)}" width="${num(s)}" height="${num(s)}" fill="none" stroke="#111" stroke-width="${num(fs * .06)}"/>`; },
  '❏': (x, y, cw, ch, fs) => { const s = fs * 0.66, cx = x + cw / 2, cy = y + ch / 2, x0 = cx - s / 2, y0 = cy - s / 2, o = fs * .07; return `<rect x="${num(x0 + o)}" y="${num(y0 + o)}" width="${num(s)}" height="${num(s)}" fill="#111"/><rect x="${num(x0)}" y="${num(y0)}" width="${num(s)}" height="${num(s)}" fill="#fff" stroke="#111" stroke-width="${num(fs * .07)}"/>`; },
  '☑': (x, y, cw, ch, fs) => { const s = fs * 0.66, cx = x + cw / 2, cy = y + ch / 2, x0 = cx - s / 2, y0 = cy - s / 2; return `<rect x="${num(x0)}" y="${num(y0)}" width="${num(s)}" height="${num(s)}" fill="#fff" stroke="#111" stroke-width="${num(fs * .07)}"/><path d="M${num(x0 + s * .2)} ${num(y0 + s * .5)}L${num(x0 + s * .45)} ${num(y0 + s * .78)}L${num(x0 + s * .85)} ${num(y0 + s * .2)}" fill="none" stroke="#111" stroke-width="${num(fs * .09)}"/>`; },
};
/* 二値の網（ページ単位の pattern 定義）。被覆率 c → 点の半径 r = pitch·√(c/π)。
   淡 7%・薄 13% は黒い点、文字の網は細かく薄い点（10%、ピッチ 1.35pt。字の形を邪魔しない）、濃は黒地に白い点（白抜き文字の読みやすさのため 90%）。地紋は斜線（細）と点（直交）で別物と分かる形に */
const SCREEN_PITCH = 1.9;
function halftone(id, c, invert, pitch) { const pch = pitch || SCREEN_PITCH, r = pch * Math.sqrt((invert ? 1 - c : c) / Math.PI); const h = pch / 2;
  return `<pattern id="${id}" patternUnits="userSpaceOnUse" width="${num(pch)}" height="${num(pch)}" patternTransform="rotate(45)">${invert ? `<rect width="${num(pch)}" height="${num(pch)}" fill="#000"/>` : ''}<circle cx="${num(h)}" cy="${num(h)}" r="${num(r)}" fill="${invert ? '#fff' : '#000'}"/></pattern>`; }
/* 網の文様（FZ.SHADES）→ ページの pattern 定義。id は s_<文様>_<頁> */
function patternDef(sh, id) {
  if (sh.kind === 'dot') return halftone(id, sh.c, false, sh.p);
  if (sh.kind === 'solid' && sh.hex) return `<pattern id="${id}" patternUnits="userSpaceOnUse" width="4" height="4"><rect width="4" height="4" fill="#${sh.hex}"/></pattern>`; /* 濃灰：網点にすると白抜きの字が読みにくいので平らな灰色 */
  if (sh.kind === 'solid') return halftone(id, sh.c || 0.90, true);
  if (sh.kind === 'line' || sh.kind === 'cross') { const p = sh.p, h = p / 2; const ln = `<line x1="0" y1="${num(h)}" x2="${num(p)}" y2="${num(h)}" stroke="#000" stroke-width="${num(sh.w)}"/>` + (sh.kind === 'cross' ? `<line x1="${num(h)}" y1="0" x2="${num(h)}" y2="${num(p)}" stroke="#000" stroke-width="${num(sh.w)}"/>` : '');
    return `<pattern id="${id}" patternUnits="userSpaceOnUse" width="${num(p)}" height="${num(p)}" patternTransform="rotate(${-sh.a})">${ln}</pattern>`; }
  if (sh.kind === 'pdot') return `<pattern id="${id}" patternUnits="userSpaceOnUse" width="${num(sh.p)}" height="${num(sh.p)}"><circle cx="${num(sh.p / 2)}" cy="${num(sh.p / 2)}" r="${num(sh.r)}" fill="#000"/></pattern>`;
  return '';
}
FZ.patternDefFor = patternDef; // 帯の見本の絵にも使う
function monoScreens(p) { return FZ.SHADES.map(sh => patternDef(sh, `s_${sh.id}_${p}`)).join(''); }
/* 印刷用：網（pattern）で塗った矩形を、同じ網点を描いた画像に置き換える。
   Chromium の PDF 出力は pattern の塗りを 1 つずつ展開するので重く（17 頁で 2 秒超、プレビューはさらに遅い）、画像の方が速くて小さい。
   網点の位置は版面の座標に揃えたまま（隣の矩形と継ぎ目が出ない）。S は 1pt あたりの画素（4 ≒ 288dpi） */
function drawScreen(ctx, kind, x, y, w, h) {
  const sh = FZ.SHADE_BY[kind]; if (!sh) return; const R = Math.SQRT1_2; // 45°
  const lattice = (pch, fn) => { // 45° 回した格子（u,v）の点を、矩形を覆う範囲だけ。page = R·(u,v)
    const cs = [[x, y], [x + w, y], [x, y + h], [x + w, y + h]].map(([px, py]) => [R * (px + py), R * (-px + py)]); // 逆回転
    const u0 = Math.floor(Math.min(...cs.map(c => c[0])) / pch) - 1, u1 = Math.ceil(Math.max(...cs.map(c => c[0])) / pch) + 1, v0 = Math.floor(Math.min(...cs.map(c => c[1])) / pch) - 1, v1 = Math.ceil(Math.max(...cs.map(c => c[1])) / pch) + 1;
    for (let i = u0; i <= u1; i++) for (let j = v0; j <= v1; j++) fn(i, j); };
  if (sh.kind === 'solid' && sh.hex) { ctx.fillStyle = '#' + sh.hex; ctx.fillRect(x, y, w, h); return; }
  if (sh.kind === 'dot' || sh.kind === 'solid') { const inv = sh.kind === 'solid', c = inv ? (sh.c || 0.90) : sh.c, pch = (inv ? 0 : sh.p) || SCREEN_PITCH, r = pch * Math.sqrt((inv ? 1 - c : c) / Math.PI), hh = pch / 2;
    if (inv) { ctx.fillStyle = '#000'; ctx.fillRect(x, y, w, h); } ctx.fillStyle = inv ? '#fff' : '#000'; ctx.beginPath();
    lattice(pch, (i, j) => { const u = i * pch + hh, v = j * pch + hh; const px = R * (u - v), py = R * (u + v); if (px < x - r || px > x + w + r || py < y - r || py > y + h + r) return; ctx.moveTo(px + r, py); ctx.arc(px, py, r, 0, Math.PI * 2); }); ctx.fill(); return; }
  if (sh.kind === 'line' || sh.kind === 'cross') { /* pattern と同じ：横線（間隔 p、線は p/2 の位置）を −a 回したもの。原点の位置も pattern に揃える */
    ctx.strokeStyle = '#000'; ctx.lineWidth = sh.w; ctx.beginPath(); const fam = sh.kind === 'cross' ? [0, 90] : [0];
    for (const off of fam) { const t = -(sh.a + off) * Math.PI / 180; const dx = Math.cos(t), dy = Math.sin(t), nx = -dy, ny = dx; // 線の向き (dx,dy)、法線 (nx,ny)
      const ds = [[x, y], [x + w, y], [x, y + h], [x + w, y + h]].map(([px, py]) => px * nx + py * ny); const k0 = Math.floor((Math.min(...ds) - sh.p / 2) / sh.p) - 1, k1 = Math.ceil((Math.max(...ds) - sh.p / 2) / sh.p) + 1, L = 2 * (w + h) + 10;
      const cx = x + w / 2, cy = y + h / 2, cd = cx * nx + cy * ny;
      for (let k = k0; k <= k1; k++) { const d = k * sh.p + sh.p / 2; const px = cx + (d - cd) * nx, py = cy + (d - cd) * ny; ctx.moveTo(px - dx * L, py - dy * L); ctx.lineTo(px + dx * L, py + dy * L); } }
    ctx.stroke(); return; }
  if (sh.kind === 'pdot') { const pch = sh.p, r = sh.r; ctx.fillStyle = '#000'; ctx.beginPath(); for (let i = Math.floor(x / pch); i <= Math.ceil((x + w) / pch); i++) for (let j = Math.floor(y / pch); j <= Math.ceil((y + h) / pch); j++) { const px = i * pch + pch / 2, py = j * pch + pch / 2; ctx.moveTo(px + r, py); ctx.arc(px, py, r, 0, Math.PI * 2); } ctx.fill(); }
}
FZ.rasterizeFills = function (svg, S = 4) {
  if (typeof document === 'undefined') return 0; let n = 0;
  for (const el of svg.querySelectorAll('rect[fill^="url(#"]')) {
    const m = el.getAttribute('fill').match(/^url\(#s_([a-z0-9]+)_\d+\)$/); if (!m) continue;
    const x = +el.getAttribute('x'), y = +el.getAttribute('y'), w = +el.getAttribute('width'), h = +el.getAttribute('height'); if (!(w > 0 && h > 0)) continue;
    const cv = document.createElement('canvas'); cv.width = Math.max(1, Math.ceil(w * S)); cv.height = Math.max(1, Math.ceil(h * S)); const ctx = cv.getContext('2d');
    ctx.setTransform(cv.width / w, 0, 0, cv.height / h, -x * cv.width / w, -y * cv.height / h); ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); drawScreen(ctx, m[1], x, y, w, h); ctx.restore();
    const img = document.createElementNS('http://www.w3.org/2000/svg', 'image'); for (const [k, v] of [['x', x], ['y', y], ['width', w], ['height', h], ['preserveAspectRatio', 'none']]) img.setAttribute(k, v); img.setAttribute('href', cv.toDataURL('image/png'));
    if (el.getAttribute('class')) img.setAttribute('class', el.getAttribute('class')); if (el.getAttribute('clip-path')) img.setAttribute('clip-path', el.getAttribute('clip-path')); el.replaceWith(img); n++;
  }
  svg.querySelectorAll('defs pattern').forEach(p => { if (/^s_[a-z0-9]+_\d+$/.test(p.id)) p.remove(); });
  return n;
};
const FIT_OPEN = /^[（「『【〔［｛〈《“‘｟]$/, FIT_CLOSE = /^[、。，．）」』】〕］｝〉》”’｠]$/; /* 基準の字幅で縮めた全角の括弧・句読点の寄せ */
function fontClass(marks, font) { return (marks & M.BOLD) ? 'fg' : ((font === 'gothic' || (marks & M.CODE)) ? 'fgr' : 'fm'); } // 文中のコードはゴシック

/* ページを描く。opts.grid：補助グリッド、opts.cls：追加クラス */
function renderPage(lay, p, opts = {}) {
  const geo = lay.geo, pg = lay.pages[p]; if (!pg) return '';
  const cw = geo.cw, ch = geo.ch, fs = geo.fs, L = geo.left, T = geo.top;
  const bodyTop = T + geo.bodyTop * ch;
  const H = geo.H, W = geo.W;
  const x = col => L + col * cw, yTop = row => bodyTop + row * ch, hfY = row => T + row * ch;
  const out = [];
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" class="pg ${opts.cls || ''}" data-page="${p}" viewBox="0 0 ${num(W)} ${num(H)}" width="${num(W)}" height="${num(H)}" font-size="${num(fs)}">`);
  const mono = !!opts.mono, ink = mono ? '#000' : '#444';
  out.push(`<defs>${monoScreens(p)}<pattern id="gdot${p}" patternUnits="userSpaceOnUse" x="${num(L)}" y="${num(bodyTop)}" width="${num(cw)}" height="${num(ch)}"><circle cx="0" cy="0" r="0.3" fill="#000"/><circle cx="${num(cw)}" cy="0" r="0.3" fill="#000"/><circle cx="0" cy="${num(ch)}" r="0.3" fill="#000"/><circle cx="${num(cw)}" cy="${num(ch)}" r="0.3" fill="#000"/></pattern></defs>`);
  /* 二値：濃さは網点（45°、ピッチ 1.9pt）の点の大きさで出す。印刷の網の考え方そのまま */
  const F = Object.fromEntries(FZ.SHADES.map(sh => [sh.id, `url(#s_${sh.id}_${p})`])); // 文様の id → 塗り
  out.push(`<rect class="paper" x="0" y="0" width="${num(W)}" height="${num(H)}" fill="#fff"/>`);
  const gm = opts.grid === true ? 'dots' : opts.grid; /* 1.0.13d A-4 方眼：dots＝字の目、frame＝版面（版面の枠・柱の欄・字と行の目盛・余白の mm）、all＝両方 */
  if (gm && mono && (gm === 'dots' || gm === 'all')) out.push(`<rect class="grid" x="${num(x(0))}" y="${num(yTop(0))}" width="${num(geo.cols * cw)}" height="${num(geo.rows * ch)}" fill="url(#gdot${p})"/>`);
  if (gm && mono && (gm === 'frame' || gm === 'all')) { const X0 = x(0), X1 = x(geo.cols), Y0 = yTop(0), Y1 = yTop(geo.rows), mm = v => (v * 25.4 / 72).toFixed(1), t6 = Math.max(4.5, Math.min(7, fs * 0.55));
    out.push(`<g class="grid" font-size="${num(t6)}" fill="#000" stroke="none">`);
    out.push(`<rect x="${num(X0)}" y="${num(Y0)}" width="${num(X1 - X0)}" height="${num(Y1 - Y0)}" fill="none" stroke="#000" stroke-width="0.45"/>`);
    if (geo.headerRows) out.push(`<rect x="${num(X0)}" y="${num(hfY(0))}" width="${num(X1 - X0)}" height="${num(geo.headerRows * ch)}" fill="none" stroke="#000" stroke-width="0.3" stroke-dasharray="2 2"/>`);
    if (geo.footerRows) out.push(`<rect x="${num(X0)}" y="${num(hfY(geo.footerTop))}" width="${num(X1 - X0)}" height="${num(geo.footerRows * ch)}" fill="none" stroke="#000" stroke-width="0.3" stroke-dasharray="2 2"/>`);
    const tk = []; for (let c = 0; c <= geo.cols; c++) { const L5 = c % 10 === 0 ? 3 : c % 5 === 0 ? 2 : 1; tk.push(`M${num(x(c))} ${num(Y0)}v${num(-L5)}`); } for (let r = 0; r <= geo.rows; r++) { const L5 = r % 10 === 0 ? 3 : r % 5 === 0 ? 2 : 1; tk.push(`M${num(X0)} ${num(yTop(r))}h${num(-L5)}`); }
    out.push(`<path d="${tk.join('')}" fill="none" stroke="#000" stroke-width="0.35"/>`);
    for (let c = 10; c <= geo.cols; c += 10) out.push(`<text x="${num(x(c))}" y="${num(Y0 - 3.6)}" text-anchor="middle">${c}</text>`);
    for (let r = 10; r <= geo.rows; r += 10) out.push(`<text x="${num(X0 - 4)}" y="${num(yTop(r) + t6 * 0.35)}" text-anchor="end">${r}</text>`);
    const top = hfY(0), bot = geo.footerRows ? hfY(geo.footerTop + geo.footerRows) : Y1;
    out.push(`<text x="${num(W / 2)}" y="${num(Math.max(t6, top / 2 + t6 * 0.35))}" text-anchor="middle">上 ${mm(top)} mm</text><text x="${num(W / 2)}" y="${num(Math.min(H - 2, bot + (H - bot) / 2 + t6 * 0.35))}" text-anchor="middle">下 ${mm(H - bot)} mm　${geo.cols} 字 × ${geo.rows} 行・字 ${num(fs)} pt</text>`);
    out.push(`<text x="${num(X0 / 2)}" y="${num((Y0 + Y1) / 2)}" text-anchor="middle">左 ${mm(X0)}</text><text x="${num(X1 + (W - X1) / 2)}" y="${num((Y0 + Y1) / 2)}" text-anchor="middle">右 ${mm(W - X1)}</text></g>`); }
  if (gm && !mono) {
    const d = []; const rows = geo.rows;
    for (let c = 0; c <= geo.cols; c++) d.push(`M${num(x(c))} ${num(yTop(0))}V${num(yTop(rows))}`);
    for (let r = 0; r <= rows; r++) d.push(`M${num(x(0))} ${num(yTop(r))}H${num(x(geo.cols))}`);
    out.push(`<path class="grid" d="${d.join('')}" fill="none" stroke="#d7d7d7" stroke-width="0.3"/>`);
    if (geo.headerRows) out.push(`<rect class="grid" x="${num(L)}" y="${num(hfY(0))}" width="${num(geo.cols * cw)}" height="${num(geo.headerRows * ch)}" fill="none" stroke="#e4e4e4" stroke-width="0.3" stroke-dasharray="2 2"/>`);
    if (geo.footerRows) out.push(`<rect class="grid" x="${num(L)}" y="${num(hfY(geo.footerTop))}" width="${num(geo.cols * cw)}" height="${num(geo.footerRows * ch)}" fill="none" stroke="#e4e4e4" stroke-width="0.3" stroke-dasharray="2 2"/>`);
  }
  // 網掛け（範囲）
  for (const f of pg.fills) {
    const fill = F[f.shade] || F.gray;
    out.push(`<rect class="fill" data-id="${f.id}" x="${num(x(f.col))}" y="${num(yTop(f.y1))}" width="${num(f.cols * cw)}" height="${num((f.y2 - f.y1) * ch)}" fill="${fill}"/>`);
  }
  // 濃い網掛け（反転）の範囲：中の文字は白
  const darks = pg.fills.filter(f => FZ.inkShade(f.shade));
  const inDark = (col, y) => darks.some(f => col >= f.col - 1e-6 && col < f.col + f.cols - 1e-6 && y >= f.y1 && y < f.y2);
  // 文字
  const glyphs = pg.glyphs; const parts = [];
  const shadeRects = [], decoLines = [], dots = [];
  // 行・書体・修飾の連続でまとめる
  // 同じ行・同じ書体の連続は 1 つの <text> に x 座標列で並べる（DOM 要素数を抑える）
  let run = null; const flush = () => { if (run) { parts.push(`<text class="${run.cls}"${run.k !== 1 ? ` transform="scale(${run.k} 1)"` : ''} y="${run.y}" x="${run.xs.join(' ')}" data-l="${run.line}" data-s="${run.seg}" data-o="${run.off}">${run.txt}</text>`); run = null; } };
  const font = opts.font || 'mincho';
  /* 1.0.11d 基準の字幅：全角・半角ごとに元の書体の何％で描くか。100％ どうし（既定）なら従来どおりマスの頭から描く。
     どちらかを変えたら、字を測って（FZ.glyphAdv：画面が書体で測る）その％で縮め、それでもマスからはみ出す字（W・M など）はマスに収まるまで縮め、
     マスの中ほどに置く（全角の始め括弧はマスの右、句読点と終わり括弧はマスの左に寄せる） */
  const ZW = geo.zw || 1, HW = geo.hw || 1, FIT = ZW !== 1 || HW !== 1;
  const fitOf = (t, cls, cellW, sx) => { const half = FZ.isHalf(t.codePointAt(0)); let k = half ? HW : ZW; const adv = (FZ.glyphAdv ? FZ.glyphAdv(t, cls) : (half ? 0.5 : 1)) * fs * sx; if (!(adv > 0)) return [k, 0];
    if (adv * k > cellW) k = Math.floor(cellW / adv * 1000) / 1000; const gw = adv * k; return [k, half ? (cellW - gw) / 2 : FIT_OPEN.test(t) ? cellW - gw : FIT_CLOSE.test(t) ? 0 : (cellW - gw) / 2]; };
  /* 図番（「図 1」を 1 字として組んだもの）は 1 字ずつマスに並べて描く */
  const expand = list => { if (!list.some(g => g.ref)) return list; const out = []; for (const g of list) { if (!g.ref) { out.push(g); continue; } const k = FZ.scaleW(g.marks); let col = g.col; let first = true; for (const ch of Array.from(g.text)) { const w = (FZ.isHalf(ch.codePointAt(0)) ? 0.5 : 1) * k; out.push({ ...g, text: ch, col, w, ref: false, off: first ? g.off : -1 }); col += w; first = false; } } return out; };
  const all = expand(glyphs).concat(pg.side ? pg.side.glyphs : [], pg.head ? pg.head.glyphs : []);
  const rv = opts.revealText ? opts.reveal : null, revealed = []; /* 工程表の期間のセルの字は隠す（矢羽根で見せる）。1.0.11a：カーソルのあるセルも字（［3/4］など）は出さない（セルの枠は画面の重ね描きで示す） */
  for (const g of all) {
    if (g.gh) { if (rv && g.line === rv.line && g.seg === rv.seg) revealed.push(g); continue; }
    const mk = g.marks | 0, sx = g.sx, sy = g.sy, w = g.w, h = g.h;
    const gx = x(g.col), top = yTop(g.y);
    const base = top + (h * ch - fs * sy) / 2 + ASC * fs * sy; // 行の中で em box を上下中央に
    const csh = FZ.shadeOfMarks(mk); const dark = (darks.length > 0 && inDark(g.col, g.y)) || FZ.inkShade(csh); const inkc = dark ? '#fff' : '#000';
    if ((mk & (M.SHADE | M.CODE)) && !(darks.length > 0 && inDark(g.col, g.y))) { const fl = csh ? F[csh] : F.light; const last = shadeRects[shadeRects.length - 1]; const cont = last && last.y === top && last.h === h && last.fl === fl && g.line != null && g.line >= 0 && last.line === g.line && last.seg === g.seg && g.off >= 0 && last.end === g.off && gx >= last.x; /* 続きの字（均等割付で離れていても）：間も網で埋める */
      if (last && !cont && last.y === top && last.h === h && last.fl === fl && Math.abs(last.x + last.w - gx) < 0.01) { last.w += w * cw; last.end = g.off >= 0 ? g.off + (g.len || 1) : -1; last.line = g.line; last.seg = g.seg; } else if (cont) { last.w = gx + w * cw - last.x; last.end = g.off + (g.len || 1); } else shadeRects.push({ x: gx, y: top, w: w * cw, h, fl, line: g.line, seg: g.seg, end: g.off >= 0 ? g.off + (g.len || 1) : -1 }); } // 文中のコードは淡い網 // 文字の網：続く字は 1 つの矩形にまとめる（継ぎ目の白い筋を出さない）
    if ((mk & M.LINK) && !(mk & M.ANY_UNDER)) decoLines.push(`<line x1="${num(gx)}" y1="${num(base + fs * sy * 0.09)}" x2="${num(gx + w * cw)}" y2="${num(base + fs * sy * 0.09)}" stroke="${inkc}" stroke-width="${num(Math.max(.4, fs * .04))}" stroke-dasharray="${num(fs * .12)} ${num(fs * .1)}"/>`); // リンク：点線の下線
    const uw = Math.max(.45, fs * .045), uy = base + fs * sy * 0.09, hl = (yy, ww) => `<line x1="${num(gx)}" y1="${num(yy)}" x2="${num(gx + w * cw)}" y2="${num(yy)}" stroke="${inkc}" stroke-width="${num(ww)}"/>`;
    if (mk & M.UNDER) decoLines.push(hl(uy, uw));
    if (mk & M.UNDER2) decoLines.push(hl(uy - uw * 1.1, uw * .9) + hl(uy + uw * 1.1, uw * .9)); // 二重下線
    if (mk & M.WAVE) { const amp = fs * .05, per = fs * .22; let d = `M${num(gx)} ${num(uy)}`; for (let xx = 0; xx < w * cw - 1e-6; xx += per) { const x0 = gx + xx, x1 = Math.min(gx + w * cw, x0 + per); d += ` Q${num(x0 + per / 4)} ${num(uy - amp)} ${num(Math.min(x1, x0 + per / 2))} ${num(uy)}`; if (x1 > x0 + per / 2) d += ` Q${num(x0 + per * 3 / 4)} ${num(uy + amp)} ${num(x1)} ${num(uy)}`; } decoLines.push(`<path d="${d}" fill="none" stroke="${inkc}" stroke-width="${num(uw * .9)}"/>`); } // 波線
    const sy0 = base - fs * sy * 0.33, sw = Math.max(.45, fs * .05);
    if (mk & M.STRIKE) decoLines.push(hl(sy0, sw));
    if (mk & M.STRIKE2) decoLines.push(hl(sy0 - sw * 1.2, sw * .9) + hl(sy0 + sw * 1.2, sw * .9)); // 二重取消線
    if (mk & M.DOT) dots.push(`<circle cx="${num(gx + w * cw / 2)}" cy="${num(top + fs * .075)}" r="${num(fs * .07)}" fill="${inkc}"/>`);
    if (/^[\s　]+$/.test(g.text)) continue;
    if (g.marker && MARKER_SHAPES[g.text]) { let shp = (sx !== 1 || sy !== 1) ? `<g transform="translate(${num(gx)} ${num(top)}) scale(${sx} ${sy})">${MARKER_SHAPES[g.text](0, 0, cw, ch * h / sy, fs)}</g>` : MARKER_SHAPES[g.text](gx, top, cw, ch * h, fs); /* 倍角の印は文字と同じく拡大 */ if (dark) shp = shp.replace(/fill="#111"/g, 'fill="#fff"').replace(/stroke="#111"/g, 'stroke="#fff"').replace(/fill="#fff" stroke="#fff"/g, 'fill="#000" stroke="#fff"'); parts.push(shp); continue; }
    const cls = fontClass(mk, font) + (mk & M.OUTLINE ? (dark ? ' olw' : ' ol') : '') + (g.marker ? ' mk' : '') + (dark && !(mk & M.OUTLINE) ? ' wh' : '');
    let fk = 1, fx = 0; if (FIT && Array.from(g.text).length === 1) [fk, fx] = fitOf(g.text, fontClass(mk, font), w * cw, sx); const sxk = String(Math.round(sx * fk * 1000) / 1000);
    if (mk & M.SHADOW) { flush(); const d = fs * 0.09 * Math.max(1, Math.min(sx, sy) * 0.7); const shCls = fontClass(mk, font) + (dark ? ' wh' : ''); parts.push(`<text class="${shCls}" transform="translate(${num(gx + fx + d)} ${num(base + d)}) scale(${sxk} ${sy})">${esc(g.text)}</text>`); } // 影文字：右下にずらした黒い写しを先に描く（白抜きと組むと新聞の影付き白抜き）
    if (sx !== 1 || sy !== 1 || (mk & M.SHADOW)) { flush(); parts.push(`<text class="${cls}" transform="translate(${num(gx + fx)} ${num(base)}) scale(${sxk} ${sy})" data-l="${g.line}" data-s="${g.seg}" data-o="${g.off}">${esc(g.text)}</text>`); continue; }
    if (g.text.length !== 1) { flush(); parts.push(`<text class="${cls}"${fk !== 1 ? ` transform="scale(${fk} 1)"` : ''} x="${num((gx + fx) / fk)}" y="${num(base)}">${esc(g.text)}</text>`); continue; }
    const key = `${g.y}|${h}|${cls}|${g.line}|${g.seg}|${fk}`; /* 横の倍率が同じ字だけを 1 つの <text> にまとめる（scale(k 1) をかけ、x は k で割っておく） */
    if (!run || run.key !== key) { flush(); run = { key, cls, k: fk, y: num(base), xs: [], txt: '', line: g.line, seg: g.seg, off: g.off }; }
    run.xs.push(num((gx + fx) / fk)); run.txt += esc(g.text);
  }
  flush();
  // 図版の画像（図表欄・本文の流れ）。画像が無ければ破線の枠
  const ims = (pg.images || []).concat(pg.side ? pg.side.images : []);
  if (ims.length) { const ip = []; for (const im of ims) { const img = lay.images && lay.images[im.file]; const X = x(im.col), Y = yTop(im.y), Wd = im.w * cw, Ht = im.h * ch;
      if (im.chart && FZ.chartSvg) { ip.push(`<g class="figimg figchart" data-fig="${esc(im.id)}"><rect x="${num(X)}" y="${num(Y)}" width="${num(Wd)}" height="${num(Ht)}" fill="#fff"/>${FZ.chartSvg(im.chart, X, Y, Wd, Ht, { F, fs, cls: 'fgr', bcls: 'fg', uid: 'c' + p + '_' + String(im.id).replace(/[^\w-]/g, '') })}</g>`); continue; } // グラフ：白黒の図形（網の文様と線種）
      const href = img ? (opts.imageHref ? opts.imageHref(im.file, img, Wd, Ht, mono) : `data:${img.mime};base64,${img.data}`) : null;
      if (href) ip.push(`<image class="figimg" data-fig="${esc(im.id)}" x="${num(X)}" y="${num(Y)}" width="${num(Wd)}" height="${num(Ht)}" preserveAspectRatio="xMidYMid meet" href="${esc(href)}"/>`);
      else ip.push(`<rect class="figimg" data-fig="${esc(im.id)}" x="${num(X + 0.5)}" y="${num(Y + 0.5)}" width="${num(Wd - 1)}" height="${num(Ht - 1)}" fill="none" stroke="#000" stroke-width="0.5" stroke-dasharray="2 1.5"/><text class="${fontClass(0, font)}" x="${num(X + Wd / 2)}" y="${num(Y + Ht / 2 + fs * 0.3)}" text-anchor="middle" font-size="${num(fs * 0.8)}">（画像なし）</text>`); }
    out.push(`<g class="figs">${ip.join('')}</g>`); }
  out.push(shadeRects.map(r => `<rect x="${num(r.x)}" y="${num(r.y)}" width="${num(r.w)}" height="${num(r.h * ch)}" fill="${r.fl}"/>`).join(''));
  out.push(`<g class="txt">${parts.join('')}</g>`);
  out.push(decoLines.join('') + dots.join(''));
  // 柱
  if (pg.hf.length) { const hp = []; for (const g of pg.hf) { if (/^[\s　]+$/.test(g.text)) continue; const base = hfY(g.y) + (ch - fs) / 2 + ASC * fs; let fk = 1, fx = 0; if (FIT && Array.from(g.text).length === 1) [fk, fx] = fitOf(g.text, fontClass(0, font), (g.w || (FZ.isHalf(g.text.codePointAt(0)) ? 0.5 : 1)) * cw, 1); hp.push(`<text class="${fontClass(0, font)} hf"${fk !== 1 ? ` transform="scale(${fk} 1)"` : ''} x="${num((x(g.col) + fx) / fk)}" y="${num(base)}">${esc(g.text)}</text>`); } out.push(`<g class="hfg">${hp.join('')}</g>`); }
  // 罫線
  const rl = [];
  const line = (x1, y1, x2, y2, kind, id, extra = '') => {
    if (kind === 'none') return; // 透明罫：セル境界としてだけ働く（横罫だけの表）
    const wdt = RULE[kind] || RULE.thin;
    if (kind === 'double') { const o = 0.7; if (y1 === y2) rl.push(`<line data-id="${id}" x1="${num(x1)}" y1="${num(y1 - o)}" x2="${num(x2)}" y2="${num(y2 - o)}" stroke="#000" stroke-width="${wdt}"${extra}/><line data-id="${id}" x1="${num(x1)}" y1="${num(y1 + o)}" x2="${num(x2)}" y2="${num(y2 + o)}" stroke="#000" stroke-width="${wdt}"${extra}/>`); else rl.push(`<line data-id="${id}" x1="${num(x1 - o)}" y1="${num(y1)}" x2="${num(x2 - o)}" y2="${num(y2)}" stroke="#000" stroke-width="${wdt}"${extra}/><line data-id="${id}" x1="${num(x1 + o)}" y1="${num(y1)}" x2="${num(x2 + o)}" y2="${num(y2)}" stroke="#000" stroke-width="${wdt}"${extra}/>`); return; }
    rl.push(`<line data-id="${id}" x1="${num(x1)}" y1="${num(y1)}" x2="${num(x2)}" y2="${num(y2)}" stroke="#000" stroke-width="${wdt}" stroke-linecap="${kind === 'arrow' ? 'butt' : 'square'}"${kind === 'dotted' ? ' stroke-dasharray="1.4 1.4" stroke-linecap="butt"' : ''}${extra}/>`);
  };
  const head = (px, py, dir) => { const a = Math.min(cw, ch) * 0.42, b = a * 0.5; const pts = dir === 'r' ? [[px, py], [px - a, py - b], [px - a, py + b]] : dir === 'l' ? [[px, py], [px + a, py - b], [px + a, py + b]] : dir === 'd' ? [[px, py], [px - b, py - a], [px + b, py - a]] : [[px, py], [px - b, py + a], [px + b, py + a]]; rl.push(`<polygon points="${pts.map(q => num(q[0]) + ',' + num(q[1])).join(' ')}" fill="#000"/>`); };
  for (const r of pg.hrules) { line(x(r.from), yTop(r.y), x(r.to), yTop(r.y), r.kind, r.id); if (r.kind === 'arrow') head(r.dir === 'l' ? x(r.from) : x(r.to), yTop(r.y), r.dir === 'l' ? 'l' : 'r'); }
  if (pg.side) for (const r of pg.side.rules) line(x(r.col), yTop(r.y1), x(r.col), yTop(r.y2), r.kind, r.id);
  if (pg.head) { for (const r of pg.head.rules) line(x(r.from), yTop(r.y), x(r.to), yTop(r.y), r.kind, r.id);
    for (const b of pg.head.boxes) { if (b.shape === 'circle') { const rr = Math.min(b.w * cw, b.h * ch) / 2; rl.push(`<circle cx="${num(x(b.col + b.w / 2))}" cy="${num(yTop(b.y + b.h / 2))}" r="${num(rr)}" fill="none" stroke="#000" stroke-width="0.6"/>`); } else rl.push(`<rect x="${num(x(b.col))}" y="${num(yTop(b.y))}" width="${num(b.w * cw)}" height="${num(b.h * ch)}" fill="none" stroke="#000" stroke-width="0.6"/>`); } }
  for (const r of pg.vrules) { line(x(r.col), yTop(r.y1), x(r.col), yTop(r.y2), r.kind, r.id); if (r.kind === 'arrow') { if (r.dir === 'u' && r.headTop) head(x(r.col), yTop(r.y1), 'u'); else if (r.dir !== 'u' && r.headBottom) head(x(r.col), yTop(r.y2), 'd'); } }
  out.push(`<g class="rules">${rl.join('')}</g>`);
  if (pg.shapes && pg.shapes.length) { /* 工程表：矢羽根（五角形・網）と名前、◆と名前、基準の縦線 */ const sp = [], lw = num(Math.max(.5, fs * .05)), lfs = fs * 0.85;
    for (const sh of pg.shapes) { const y0 = yTop(sh.y), hh = sh.h * ch;
      if (sh.kind === 'bar') { const X0 = x(sh.x0), X1 = x(sh.x1), ya = y0 + hh * 0.18, yb = y0 + hh * 0.82, ym = (ya + yb) / 2, tip = Math.max(0, Math.min((yb - ya) * 0.55, (X1 - X0) * 0.45));
        sp.push(`<polygon class="gbar" points="${num(X0)},${num(ya)} ${num(X1 - tip)},${num(ya)} ${num(X1)},${num(ym)} ${num(X1 - tip)},${num(yb)} ${num(X0)},${num(yb)}" fill="${F.gray}" stroke="#000" stroke-width="${lw}"/>`);
        if (sh.label) sp.push(`<text class="fg gl" x="${num(X0 + fs * 0.45)}" y="${num(ym + lfs * 0.36)}" font-size="${num(lfs)}" stroke="#fff" stroke-width="${num(lfs * 0.18)}" stroke-linejoin="round" paint-order="stroke">${esc(sh.label)}</text>`); }
      else if (sh.kind === 'ms') { const X = x(sh.x), ym = y0 + hh / 2, r = Math.min(hh * 0.34, fs * 0.5); sp.push(`<polygon class="gms" points="${num(X)},${num(ym - r)} ${num(X + r)},${num(ym)} ${num(X)},${num(ym + r)} ${num(X - r)},${num(ym)}" fill="#000"/>`);
        const lw = FZ.textWidth ? FZ.textWidth(sh.label || '') * lfs : 0, left = sh.xr != null && X + r + fs * 0.15 + lw > x(sh.xr) && X - r - fs * 0.15 - lw >= x(0); /* 表の右端からはみ出す名前は ◆ の左に */
        if (sh.label) sp.push(`<text class="fg gl" x="${num(left ? X - r - fs * 0.15 : X + r + fs * 0.15)}"${left ? ' text-anchor="end"' : ''} y="${num(ym + lfs * 0.36)}" font-size="${num(lfs)}" stroke="#fff" stroke-width="${num(lfs * 0.22)}" stroke-linejoin="round" paint-order="stroke">${esc(sh.label)}</text>`); }
      else if (sh.kind === 'base') { const X = x(sh.x); sp.push(`<line class="gbase" x1="${num(X)}" y1="${num(y0)}" x2="${num(X)}" y2="${num(y0 + hh)}" stroke="#000" stroke-width="${num(Math.max(.8, fs * .09))}" stroke-dasharray="${num(fs * .3)} ${num(fs * .18)}"/>`);
        if (sh.first) { const t = fs * 0.35; sp.push(`<polygon points="${num(X - t)},${num(y0)} ${num(X + t)},${num(y0)} ${num(X)},${num(y0 + t * 1.2)}" fill="#000"/>`); } } }
    out.push(`<g class="gantt">${sp.join('')}</g>`); }
  if (revealed.length) { /* 直しているセル：白地に字 */ const g0 = revealed[0], top = yTop(g0.y), hh = g0.h * ch; let x0 = Infinity, x1 = -Infinity; for (const g of revealed) { x0 = Math.min(x0, x(g.col)); x1 = Math.max(x1, x(g.col + g.w)); }
    const rp = [`<rect x="${num(x0 - fs * 0.15)}" y="${num(top + hh * 0.08)}" width="${num(x1 - x0 + fs * 0.3)}" height="${num(hh * 0.84)}" fill="#fff" stroke="#000" stroke-width="${num(Math.max(.4, fs * .04))}" stroke-dasharray="${num(fs * .15)} ${num(fs * .1)}"/>`];
    for (const g of revealed) { const base = top + (g.h * ch - fs) / 2 + ASC * fs; rp.push(`<text class="${fontClass(g.marks | 0, font)}" x="${num(x(g.col))}" y="${num(base)}">${esc(g.text)}</text>`); }
    out.push(`<g class="greveal">${rp.join('')}</g>`); }
  out.push(`<g class="ov"></g>`);
  out.push('</svg>');
  return out.join('');
}
FZ.renderPage = renderPage;

/* カーソル・選択・モード図形のオーバーレイ（ページ単位） */
function renderOverlay(lay, p, st) {
  const geo = lay.geo, cw = geo.cw, ch = geo.ch, L = geo.left, bodyTop = geo.top + geo.bodyTop * ch;
  const x = col => L + col * cw, yTop = row => bodyTop + row * ch; const o = [];
  for (const r of st.dims || []) if (r.page === p) { const t = r.y1 == null ? -9999 : yTop(r.y1); const b = r.y2 == null ? 99999 : yTop(r.y2); if (b > t) o.push(`<rect class="dim" x="-9999" y="${num(t)}" width="29999" height="${num(b - t)}" fill="#fff" fill-opacity="0.66"/>`); } /* 1.0.15e 集中の表示：節のほかを白い薄紙で覆う */
  for (const r of st.selRects || []) if (r.page === p) o.push(st.mono ? `<rect x="${num(x(r.col))}" y="${num(yTop(r.y))}" width="${num(r.w * cw)}" height="${num(r.h * ch)}" fill="#fff" style="mix-blend-mode:difference"/>` : `<rect x="${num(x(r.col))}" y="${num(yTop(r.y))}" width="${num(r.w * cw)}" height="${num(r.h * ch)}" fill="#1a56c4" fill-opacity="0.22"/>`);
  for (const r of st.rects || []) if (r.page === p) o.push(`<rect x="${num(x(r.col))}" y="${num(yTop(r.y))}" width="${num(r.w * cw)}" height="${num(r.h * ch)}" fill="${r.fill === 'none' ? 'none' : st.mono ? '#000' : (r.fill || '#1a56c4')}" fill-opacity="${r.opacity ?? 0.18}" stroke="${r.stroke === 'none' ? 'none' : st.mono ? '#000' : (r.stroke || '#1a56c4')}" stroke-width="${num(r.sw || 0.6)}"${r.solid ? '' : ' stroke-dasharray="2 1.5"'}/>`);
  for (const l of st.lines || []) if (l.page === p) o.push(`<line x1="${num(x(l.c1))}" y1="${num(yTop(l.r1))}" x2="${num(x(l.c2))}" y2="${num(yTop(l.r2))}" stroke="${st.mono ? '#000' : '#c81e1e'}" stroke-width="${num(l.w || 1.2)}" stroke-dasharray="${l.w > 2 ? '3 2' : '2 1.5'}"/>`);
  /* 図のつまみ（白地に黒枠の四角。図の下端は横長の棒）と、矢印を引き出す点（白地に黒枠の丸に十字） */
  const hs = Math.min(cw, ch) * 0.42;
  for (const h of st.handles || []) if (h.page === p) { const w = h.bar ? cw * 2.4 : hs, hh = h.bar ? hs * 0.7 : hs; o.push(`<rect x="${num(x(h.col) - w / 2)}" y="${num(yTop(h.y) - hh / 2)}" width="${num(w)}" height="${num(hh)}" fill="#fff" stroke="#000" stroke-width="0.9"/>`); }
  for (const q of st.ports || []) if (q.page === p) { const cx = x(q.col), cy = yTop(q.y), r = hs * 0.62; o.push(`<circle cx="${num(cx)}" cy="${num(cy)}" r="${num(r)}" fill="#fff" stroke="#000" stroke-width="0.8"/><path d="M${num(cx - r * 0.55)} ${num(cy)}h${num(r * 1.1)}M${num(cx)} ${num(cy - r * 0.55)}v${num(r * 1.1)}" stroke="#000" stroke-width="0.7"/>`); }
  for (const h of st.hits || []) if (h.page === p) o.push(`<rect x="${num(x(h.col))}" y="${num(yTop(h.y))}" width="${num(h.w * cw)}" height="${num(h.h * ch)}" fill="none" stroke="${FZ.SHU}" stroke-width="0.8"/>`);
  for (const t of st.tags || []) if (t.page === p) { const fz = t.size || Math.max(5, ch * 0.42); const w = [...String(t.text)].reduce((n, c) => n + (c.charCodeAt(0) < 256 ? 0.56 : 1), 0) * fz + 4; const X = t.anchor === 'end' ? x(t.col) - w : x(t.col), Y = yTop(t.y); /* 1.0.13d 紙幅の札（白地に黒の枠と字。印刷には出ない） */
    const tc = t.ink ? '#000' : FZ.SHU; o.push(`<rect x="${num(X)}" y="${num(Y)}" width="${num(w)}" height="${num(fz + 3)}" fill="#fff" stroke="${tc}" stroke-width="0.5"/><text x="${num(X + 2)}" y="${num(Y + fz)}" font-size="${num(fz)}" fill="${tc}">${esc(t.text)}</text>`); } /* 1.0.15a 札は手当ての層：朱 */
  for (const l of st.labels || []) if (l.page === p) o.push(`<rect x="${num(x(l.col))}" y="${num(yTop(l.y))}" width="${num(cw * 0.9)}" height="${num(ch * 0.55)}" fill="${st.mono ? '#000' : '#1a56c4'}"/><text x="${num(x(l.col) + cw * 0.45)}" y="${num(yTop(l.y) + ch * 0.44)}" font-size="${num(ch * 0.45)}" font-family="sans-serif" font-weight="700" fill="#fff" text-anchor="middle">${esc(l.text)}</text>`);
  for (const g of st.ghosts || []) if (g.page === p) { const fs = geo.fs, base = yTop(g.y) + ((g.h || 1) * ch - fs) / 2 + ASC * fs; let t = '', w = 0; for (const c of g.text) { const cw1 = c.charCodeAt(0) < 256 ? 0.5 : 1; if (w + cw1 > g.max) { t += '…'; break; } t += c; w += cw1; } /* 1.0.16h 空の箱の薄い手引き（打ち始めると消える。印刷・書き出しには出ない） */
    o.push(`<text class="ghost ${st.font === 'gothic' ? 'fgr' : 'fm'}" x="${num(x(g.col))}" y="${num(base)}" font-size="${num(fs)}" fill="#9c9c9c" stroke="#fff" stroke-width="${num(fs * 0.22)}" stroke-linejoin="round" paint-order="stroke">${esc(t)}</text>`); } /* 1.0.16h 網の上でも読めるよう白の縁 */
  const c = st.caret;
  if (c && c.page === p && !c.hidden) {
    if (st.block) o.push(`<rect class="caret" x="${num(x(c.col))}" y="${num(yTop(c.y))}" width="${num((c.w || 1) * cw)}" height="${num(c.h * ch)}" fill="${st.mono ? '#000' : '#1a56c4'}" fill-opacity="0.35" stroke="${st.mono ? '#000' : '#1a56c4'}" stroke-width="0.8"/>`);
    else o.push(`<line class="caret${st.composing ? ' comp' : ''}" x1="${num(x(c.col))}" y1="${num(yTop(c.y) + 0.5)}" x2="${num(x(c.col))}" y2="${num(yTop(c.y) + c.h * ch - 0.5)}" stroke="${st.caretColor || '#111'}" stroke-width="${num(Math.max(0.9, 1.1 / (st.scale || 1)))}"/>`);
    if (st.overwrite) o.push(`<rect x="${num(x(c.col))}" y="${num(yTop(c.y) + c.h * ch - 1.2)}" width="${num((c.w || 1) * cw)}" height="1.2" fill="#111"/>`);
  }
  return o.join('');
}
FZ.renderOverlay = renderOverlay;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
