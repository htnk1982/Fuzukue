/* 文机 — 下読み（機械）と照合（1.0.16a）
 * 下読み：提出の前に、上位者の判断に耐えるかを先に読む。通信なし・打つそばから（健康診断の欄の「下読み」）。
 *   規則はデータ（FZ.REVIEW_RULES）。重さは「直」（直さないと差し戻される）と「整」（整える）。各規則に、読み手が必ず問う「問い」。
 *   基準（FZ.STD_DEFAULT。利用者は基準ファイルで足す）：一文の上限・箇条書き既定・空語・誤読を招く語。基準は人名を持たない。
 *   文書の種類（doc.kind、原本は「#文書の種類 報告」）で効く規則を絞る。種類が無ければ、どの文書にも効く規則だけ。
 * 照合：FZ.collate(a, b) → 2 つの文の数・否定・敬称・日付の違い。版・ほかの文書・AI の稿を取り込む前に、違いの横に出す。
 * FZ.reviewIssues(doc, { std, kind }) → [{ line, seg, a, b, id, name, sev, q, msg, fix? }] */
(function (FZ) {
  'use strict';
  const KINDS = ['報告', '会議資料', '評価', '企画・要件', '議事録', 'メール', 'その他'];
  const JUDGE = ['報告', '会議資料', '評価', '企画・要件']; /* 判断を仰ぐ文書 */
  const STD_DEFAULT = { name: '既定（判断に耐える文書）', maxSent: 60, bullets: true, empty: ['寄与', '推進', '強化', '高度化', '最適化', '連携', '徹底'], misread: ['必要な*だけ', '以降*順調', '養っている', '今後*強化'], kinds: [] };
  const R = [];
  const rule = (id, name, sev, q, kinds, desc) => R.push({ id, name, sev, q, kinds, desc });
  rule('cmpBase', '比較起点のない増減', '直', '何と比べて？', null, '増・減・上回るなど（「販売減」「在庫増」も）があり、同じ文に前年比・予算比・前回比などの起点が無い。報告・評価などでは数が無くても、ほかの文書では数がある文だけ');
  rule('vagueRef', '参照先が曖昧', '直', 'どの表のどこ？', null, '「上表」「下図」「表参照」で指し、図表の番号も参照の字も無い');
  rule('tableRead', '表に読み方がない', '直', 'この表で何を言いたい？', JUDGE, '数のある表の前後 2 行に、数と比べた結果を書いた文が無い');
  rule('emptyEnd', '空語で終わる', '直', 'それで何が変わった？', null, '推進・強化・寄与などの空語で文が終わり、数も無い（基準の「空語」も見る）');
  rule('activity', '活動で終わる', '直', 'それは通常業務では？', ['報告', '評価'], '会議した・調整した・周知した・対応したなど、活動だけで文が終わる');
  rule('misread', '反対解釈を招く語', '直', '今はできていないという意味？', null, '「必要な〜だけ」「以降順調」「養っている」「今後強化」など（基準の「誤読を招く語」も見る）');
  rule('noDue', '担い手と期限のない予定', '直', '誰がいつ？', ['報告', '会議資料', '企画・要件', '議事録'], '「今後」「引き続き」「検討する」「対応します」の文に期限（と担い手）が無い');
  rule('late', '結論が遅い', '直', 'で、結論は？', JUDGE, '文書・節の最初の 2 文に、結論・判断・依頼・数が無い（3 文以上の節）');
  rule('dateDow', '日付と曜日の食い違い', '直', 'この日は何曜日？', null, '「11月9日（火）」のように、日付と曜日が合わない・無い日付');
  rule('nameHead', '見出しが名札', '整', 'この頁で何を言いたい？', ['会議資料'], '大見出しが、動詞も数字も無い名詞だけ');
  rule('long', '長い文・長い段落', '整', null, null, '一文が基準の上限を超える。箇条書き既定の基準で、3 文以上の段落');
  rule('ambig', '係りの曖昧さ', '整', 'どれのこと？', null, '「の」の 3 連続、「が、」でつないだ長い文、段落の頭の「これ・それ」');
  rule('honor', '敬称の揺れ', '整', null, null, '同じ姓に「さん・様・部長・氏」などが混ざる（直さず、要確認）');
  FZ.REVIEW_RULES = R; FZ.REVIEW_KINDS = KINDS; FZ.STD_DEFAULT = STD_DEFAULT;
  const RULE = Object.fromEntries(R.map(r => [r.id, r]));

  const nfk = s => String(s || '').normalize('NFKC');
  const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const NUM = /[0-9０-９]/;
  const BASE = /比|対(?!応|策|象|処|話|面|立|抗)|前年|前期|前月|前週|前日|前回|昨年|同期|予算|計画|見通し|目標|当初|(?<!こと)から|(?<!に)より|に比べ|と比べ|vs/i;
  const INC_CORE = /増加|減少|増え|減っ|減り|減ら|増収|減収|増益|減益|上回|下回|(?<=[一-鿿ァ-ヶー])[増減](?=[にでと、。がのを]|$)/; /* 数が無くても起点を問う（報告・評価など） */
  const INC = /増加|減少|増え|減っ|減り|減ら|増収|減収|増益|減益|上回|下回|伸び|伸長|改善|悪化|上昇|低下|下落|拡大|縮小|[△▲]\s*[0-9０-９]|(?<=[一-鿿ァ-ヶー])[増減](?=[にでと、。がのを]|$)/;
  const NUMCELL = /^[\s　]*[△▲+\-−]?[0-9０-９][0-9０-９,，.．]*\s*(?:%|％|pt|ポイント|億円|百万円|千円|万円|円|億|万|千|件|人|名|社|台|個|本|回|日|時間|倍|割|kg|t)?[\s　]*$/;
  const REFCH = /[\u{F0000}-\u{FFFFD}]/u;
  const VREF = /上表|下表|上図|下図|前表|次表|前図|次図|上記の[表図]|下記の[表図]|以下の[表図]|表参照|図参照/g;
  const TAIL = /(?:を|に)?(?:図(?:る|った|ります|りました|っていく|っていきます|ってまいります|ってきた)|努め(?:る|た|ます|ました|てまいります|ていく)|取り組(?:む|んだ|みます|みました|んでいく|んでまいります)|行(?:う|った|います|いました)|実施(?:する|した|します|しました)?|し(?:た|ます|ました|ていく|ていきます|てまいります|ている|ています|たい)|する|です|である|だ|が必要|を目指す|を目指します|が求められる)$/;
  const ACT = /(?:会議(?:を)?(?:した|行った|実施した|開催した|開いた)|開催した|調整した|周知した|対応した|フォロー(?:アップ)?した|議事進行(?:を)?(?:した|務めた|担当した)?|説明した|共有した|参加した|出席した|打ち?合わ?せ(?:を)?(?:した|行った)|ヒアリング(?:を)?(?:した|行った|実施した)|連絡した|依頼した|報告した|確認した)$/;
  const RESULT = /結果|により|ことで|ため|削減|増加|減少|達成|完了|決定|合意|改善|解消|短縮|獲得|受注/;
  const FUT = /今後|引き続き|検討(?:する|します|していく|してまいります|中)|対応(?:します|していく|してまいります|予定)|進め(?:ます|ていく|てまいります)|見直(?:す|します)|実施(?:する|します)予定|予定(?:です|である|だ)?$/;
  const DUE = /[0-9０-９]+\s*(?:月|日|年|週|\/|／)|年度|上期|下期|上半期|下半期|四半期|Q[1-4１-４]|今期|来期|今月|来月|翌月|今週|来週|年内|月内|週内|月末|期末|年度末|上旬|中旬|下旬|まで|期限/;
  const OWNER = /部|課|室|局|センター|チーム|グループ|班|担当|責任者|さん|様|氏|私|当方|弊社|当社|事務局|委員会|本部|[A-Z]{2,}/;
  const CONC = /結論|決定|決め|判断|提案|お願い|ください|承認|依頼|求め|べき|方針|見込|要する|つまり|結果|達成|未達|上回|下回|遅れ|完了|中止|延期|採用|見送|増|減|[0-9０-９]/;
  const HON = /(?<![一-鿿々ァ-ヶー])([一-鿿々]{1,3}?)(本部長|部長|課長|室長|係長|主任|社長|所長|局長|次長|先生|さん|さま|様|氏|君|殿)/g;
  const NOTNAME = /[部課室局所店社会院校署庁省府県市町村団隊]$|^(?:営業|総務|人事|経理|財務|企画|開発|技術|製造|購買|調達|物流|品質|管理|事業|本|支|全|各|貴|御|客|皆|同|前|元|新|現|副|代表|担当|社|神|王|奥|お)$/;
  const DOW = '日月火水木金土';
  const DATE_RE = /(?:(\d{4}|[０-９]{4}|令和\s*(?:[0-9０-９]{1,2}|元)|平成\s*[0-9０-９]{1,2})\s*年\s*)?([0-9０-９]{1,2})\s*月\s*([0-9０-９]{1,2})\s*日\s*[（(]\s*([日月火水木金土])(?:曜日?)?\s*[）)]|(?:(\d{4})[\/／])?(\d{1,2})[\/／](\d{1,2})\s*[（(]\s*([日月火水木金土])(?:曜日?)?\s*[）)]/g;

  const sentOf = t => FZ.tree && FZ.tree.sentences ? FZ.tree.sentences(t) : t.split(/(?<=[。！？])/).reduce((o, x) => { const s = o.length ? o[o.length - 1].end : 0; o.push({ start: s, end: s + x.length, text: x }); return o; }, []);
  const strip = t => t.replace(/[\u{F0000}-\u{FFFFD}]/gu, '図').replace(/[\s　]+$/, '').replace(/[」』）)]+$/, '').replace(/[。．！!？?]+$/, '');
  const isHead = ln => ln.attrs.style === 'title' || ln.attrs.style === 'num' || ln.attrs.style === 'sym';
  const skip = (doc, i) => { const ln = doc.lines[i]; const a = ln.attrs; return !!(a.code || a.figure || a.toc || a.gantt) || (FZ.inTable && FZ.inTable(doc, i)); };
  const textOf = ln => ln.segs.map(s => s.text).join('');
  function yearOf(doc) { for (const ln of doc.lines) { const m = nfk(textOf(ln)).match(/(20\d\d|19\d\d)\s*年(?!度)/); if (m) return +m[1]; const r = nfk(textOf(ln)).match(/令和\s*(\d{1,2}|元)\s*年/); if (r) return 2018 + (r[1] === '元' ? 1 : +r[1]); } return new Date().getFullYear(); }
  const yearFrom = (s, dflt) => { if (!s) return dflt; s = nfk(s).replace(/\s/g, ''); let m; if ((m = s.match(/^令和(\d+|元)$/))) return 2018 + (m[1] === '元' ? 1 : +m[1]); if ((m = s.match(/^平成(\d+)$/))) return 1988 + +m[1]; return +s; };

  /* 基準ファイル（部品棚の「基準」）：頭の --- から --- までの「名前: 値, 値」。空語・誤読を招く語は既定に足す */
  FZ.parseStd = function (text) { const s = String(text || '').replace(/^﻿/, ''); const m = s.match(/^---\s*\n([\s\S]*?)\n---\s*(?:\n|$)/); if (!m) return null; const kv = {};
    for (const raw of m[1].split('\n')) { const p = raw.match(/^\s*([^:：#][^:：]*?)\s*[:：]\s*(.*)$/); if (p) kv[p[1].trim()] = p[2].trim(); }
    const list = v => String(v || '').split(/[,、，]/).map(x => x.trim()).filter(Boolean); const known = ['種類', '名前', '既定の文書', '一文の上限', '箇条書き既定', '空語', '嫌う表現', '誤読を招く語'];
    if (!known.some(k => k in kv) || (kv.種類 && kv.種類 !== '基準')) return null;
    const out = { name: kv.名前 || '基準', maxSent: Math.max(20, Math.min(200, parseInt(nfk(kv.一文の上限 || ''), 10) || STD_DEFAULT.maxSent)), bullets: kv.箇条書き既定 ? /^(はい|yes|true|1|既定|する)$/i.test(kv.箇条書き既定) : STD_DEFAULT.bullets,
      empty: [...new Set([...STD_DEFAULT.empty, ...list(kv.空語), ...list(kv.嫌う表現)])], misread: [...new Set([...STD_DEFAULT.misread, ...list(kv.誤読を招く語)])], kinds: list(kv.既定の文書).filter(k => KINDS.includes(k)), body: s.slice(m[0].length) };
    return out; };
  FZ.stdTemplate = () => `---
種類: 基準
名前: 上位者の判断に耐える文書
既定の文書: 報告, 会議資料, 評価, 企画・要件
一文の上限: 60
箇条書き既定: はい
空語: ${STD_DEFAULT.empty.join(', ')}
誤読を招く語: ${STD_DEFAULT.misread.join(', ')}
---
## 必ず問われること
（上位者が必ず問う問いを 1 行ずつ。例：何と比べて？・誰がいつ？・で、結論は？）

## 重視すること
（判断の目。例：数字で示す・結論から・今月の判断に要る事実だけ）

## ゲート
（提出の前に必ず満たすこと。例：表の直後に読み方を 1 文）

## 実例（人名なし）
（実際に入った朱と、直した後の文を対で）

## 記録（文機が追記）
`;

  /* ---- 下読み ---- */
  FZ.reviewIssues = function (doc, opts = {}) { const std = { ...STD_DEFAULT, ...(opts.std || {}) }; const kind = opts.kind || doc.kind || ''; const ign = new Set(doc.proofIgnore || []); const out = [];
    const on = id => { const r = RULE[id]; return !r.kinds || r.kinds.includes(kind); };
    const push = (id, i, seg, a, b, msg, fix, text) => { const r = RULE[id]; const tx = text != null ? text : (doc.lines[i] && doc.lines[i].segs[seg] ? doc.lines[i].segs[seg].text.slice(a, b) : ''); if (ign.has('r_' + id + '|' + tx)) return; out.push({ line: i, seg, a, b, id: 'r_' + id, rule: id, set: 'review', name: r.name, sev: r.sev, q: r.q, text: tx, msg: (r.q ? r.q + '　' : '') + msg, fix: fix != null && fix !== tx ? fix : null }); };
    const emptyRe = std.empty.length ? new RegExp('(' + std.empty.map(escRe).join('|') + ')$') : null;
    const misRe = std.misread.length ? new RegExp(std.misread.map(w => w === '必要な*だけ' ? '必要な(?!時|とき|場合|所|ところ|分)[^。]{0,10}?だけ' : w.split('*').map(escRe).join('[^。]{0,10}?')).join('|'), 'g') : null; /* 「*」は 10 字までの何か。「必要な時だけ」のような条件は除く */
    /* 文の単位：本文・箇条書きの行（表・図・コードは見ない） */
    const sents = []; doc.lines.forEach((ln, i) => { if (skip(doc, i) || isHead(ln)) return; ln.segs.forEach((sg, s) => { if (!sg.text.trim()) return; sentOf(sg.text).forEach((x, k) => sents.push({ i, s, k, a: x.start, b: x.start + x.text.replace(/[\s　]+$/, '').length, t: x.text, list: !!ln.attrs.list, n: 0 })); }); });
    for (let q = 0; q < sents.length; q++) { const e = sents[q]; if (e.k > 0 && q > 0) e.prevBase = BASE.test(nfk(sents[q - 1].t)); const t = strip(e.t), tn = nfk(t), m0 = (re) => { const m = e.t.match(re); return m ? [e.a + m.index, e.a + m.index + m[0].length] : [e.a, e.b]; };
      const based = BASE.test(tn); if (on('cmpBase') && !based && !(e.k > 0 && e.prevBase) && (NUM.test(t) ? INC.test(t) : JUDGE.includes(kind) && INC_CORE.test(t))) { const [a, b] = m0(INC); push('cmpBase', e.i, e.s, a, b, '増減の比べる起点が無い（前年比・予算比・前回比など）'); }
      if (on('vagueRef') && !/[表図]\s*[0-9０-９]/.test(e.t) && !REFCH.test(e.t)) { VREF.lastIndex = 0; const m = VREF.exec(e.t); if (m) push('vagueRef', e.i, e.s, e.a + m.index, e.a + m.index + m[0].length, `「${m[0]}」ではなく図表の番号で指す（参照の字なら番号が自動で合う）`); }
      if (on('emptyEnd') && emptyRe && !NUM.test(t)) { let u = t; for (let k = 0; k < 3; k++) { const v = u.replace(TAIL, ''); if (v === u) break; u = v; } const m = u.match(emptyRe); if (m) { const a = e.a + u.length - m[1].length; push('emptyEnd', e.i, e.s, a, a + m[1].length, `「${m[1]}」で終わっている（何がどう変わったか、数で）`); } }
      if (on('activity') && !NUM.test(t) && !RESULT.test(t)) { const u = t.replace(/ました$/, 'た').replace(/いた$/, 'った'); const m = u.match(ACT); if (m) push('activity', e.i, e.s, e.a, e.b, `「${m[0]}」で終わっている（活動ではなく、結果・変わったことを）`); }
      if (on('misread') && misRe) { misRe.lastIndex = 0; let m; while ((m = misRe.exec(e.t))) { if (!m[0].length) { misRe.lastIndex++; continue; } push('misread', e.i, e.s, e.a + m.index, e.a + m.index + m[0].length, `「${m[0]}」は反対の意味にも読める（今はできていない、とも取れる）`); } }
      if (on('noDue') && FUT.test(t) && !DUE.test(tn)) { const [a, b] = m0(FUT); push('noDue', e.i, e.s, a, b, OWNER.test(t) ? '期限が無い（いつまでに）' : '担い手と期限が無い（誰が、いつまでに）'); }
      const len = [...t].length; if (on('long') && len > std.maxSent) push('long', e.i, e.s, e.a, e.b, `一文 ${len} 字（基準の上限 ${std.maxSent} 字）。分ける`);
      if (on('ambig')) { const no = e.t.match(/(?:[^\s、。の「」（）]{2,8}(?<![そこあど])の){3}[^\s、。の]/); if (no) push('ambig', e.i, e.s, e.a + no.index, e.a + no.index + no[0].length, '「の」が 3 つ続く（どれに係るか曖昧）');
        else if (len >= 50 && /[^でにはもと]が、/.test(e.t)) { const g = e.t.search(/[^でにはもと]が、/) + 1; push('ambig', e.i, e.s, e.a + g, e.a + g + 2, '「が、」でつないだ長い文（逆接でなければ文を分ける）'); }
        else if (e.k === 0 && e.a === 0 && !e.list && /^(?:これ|それ|あれ)[はがをにでもら]/.test(e.t)) push('ambig', e.i, e.s, 0, 2, `段落の頭の「${e.t.slice(0, 2)}」（前の段落のどれを指すか）`); } }
    /* 長い段落（箇条書き既定の基準）：本文の行に 3 文以上 */
    if (on('long') && std.bullets && JUDGE.includes(kind)) { const by = new Map(); for (const e of sents) if (!e.list) by.set(e.i + ':' + e.s, (by.get(e.i + ':' + e.s) || 0) + 1); for (const [k, n] of by) if (n >= 3) { const [i, s] = k.split(':').map(Number); push('long', i, s, 0, doc.lines[i].segs[s].text.length, `${n} 文の段落（基準は箇条書き既定。分けるか箇条書きに）`, null, '段落'); } }
    /* 表に読み方がない */
    if (on('tableRead') && FZ.inTable) { let i = 0; const N = doc.lines.length; const readable = k => { const ln = doc.lines[k]; if (!ln || skip(doc, k) || isHead(ln)) return false; const t = textOf(ln); return NUM.test(t) && (BASE.test(nfk(t)) || INC.test(t) || /多い|少ない|高い|低い|最も|最大|最小|上位|下位|割|倍|半分|占め|伸び|落ち/.test(t)); };
      while (i < N) { if (!FZ.inTable(doc, i)) { i++; continue; } const s0 = i; while (i < N && FZ.inTable(doc, i)) i++; const e0 = i - 1; if (doc.lines[s0].attrs.gantt) continue; let nNum = 0; for (let k = s0 + 1; k <= e0; k++) for (const g of doc.lines[k].segs) if (NUMCELL.test(g.text)) nNum++;
        if (nNum < 2) continue; /* 数の表（数だけのセルが 2 つ以上）だけ */ const near = []; for (let k = s0 - 1, c = 0; k >= 0 && c < 2; k--) { if (!textOf(doc.lines[k]).trim()) continue; if (isHead(doc.lines[k]) || FZ.inTable(doc, k)) break; near.push(k); c++; } for (let k = e0 + 1, c = 0; k < N && c < 2; k++) { if (!textOf(doc.lines[k]).trim()) continue; if (isHead(doc.lines[k]) || FZ.inTable(doc, k)) break; near.push(k); c++; }
        if (!near.some(readable)) push('tableRead', s0, 0, 0, 0, '表の前後 2 行に、この表の読み方（数と、比べた結果）が無い', null, '表'); } }
    /* 結論が遅い：文書の頭と大見出しの節。最初の 2 文に結論・判断・依頼・数が無い（3 文以上の節） */
    if (on('late')) { const secs = []; let cur = { at: -1, ss: [] }; secs.push(cur); const byLine = new Map(); for (const e of sents) { if (!byLine.has(e.i)) byLine.set(e.i, []); byLine.get(e.i).push(e); }
      doc.lines.forEach((ln, i) => { if ((ln.attrs.style === 'num' || ln.attrs.style === 'sym') && (ln.attrs.level | 0) === 0) { cur = { at: i, ss: [] }; secs.push(cur); } else if (byLine.has(i)) cur.ss.push(...byLine.get(i)); });
      for (const sc of secs) { if (sc.ss.length < 3) continue; const two = sc.ss.slice(0, 2); if (two.some(e => CONC.test(e.t))) continue; const f = two[0]; push('late', f.i, f.s, f.a, f.b, sc.at < 0 ? '文書の最初の 2 文に結論・依頼が無い（結論から書く）' : `「${textOf(doc.lines[sc.at]).slice(0, 12)}」の最初の 2 文に結論・依頼が無い`); } }
    /* 見出しが名札（会議資料の大見出し） */
    if (on('nameHead')) doc.lines.forEach((ln, i) => { const a = ln.attrs; if ((a.style !== 'num' && a.style !== 'sym') || (a.level | 0) !== 0) return; const t = textOf(ln).replace(/^[\s　]*([0-9０-９]+[.．、)]|[（(][0-9０-９]+[）)]|[一二三四五六七八九十]+[、.．]|第[0-9０-９一二三四五六七八九十]+)?[\s　]*/, '').trim(); if (!t || NUM.test(t)) return; if (/[るたいすだぬうくずかよね！？!?]$/.test(t)) return; push('nameHead', i, 0, 0, ln.segs[0].text.length, `「${t.slice(0, 16)}」は名札（言いたいことを、動詞か数で）`); });
    /* 日付と曜日 */
    if (on('dateDow')) { const Y = yearOf(doc); doc.lines.forEach((ln, i) => { if (ln.attrs.code) return; ln.segs.forEach((sg, s) => { DATE_RE.lastIndex = 0; let m; while ((m = DATE_RE.exec(sg.text))) { const y = m[2] || m[3] ? yearFrom(m[1], Y) : (m[5] ? +m[5] : Y); const mo = +nfk(m[2] || m[6]), d = +nfk(m[3] || m[7]), w = m[4] || m[8]; const dt = new Date(Date.UTC(y, mo - 1, d));
      if (dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) { push('dateDow', i, s, m.index, m.index + m[0].length, `${y} 年 ${mo} 月 ${d} 日は無い日付`); continue; } const ok = DOW[dt.getUTCDay()]; if (ok !== w) { const k = m[0].lastIndexOf(w); push('dateDow', i, s, m.index, m.index + m[0].length, `${y} 年 ${mo} 月 ${d} 日は${ok}曜日（${w}ではない）`, m[0].slice(0, k) + ok + m[0].slice(k + 1)); } } }); }); }
    /* 敬称の揺れ：同じ姓に違う敬称（少ない方を「要確認」に。直さない） */
    if (on('honor')) { const by = new Map(); doc.lines.forEach((ln, i) => { if (skip(doc, i) && !(FZ.inTable && FZ.inTable(doc, i))) return; ln.segs.forEach((sg, s) => { HON.lastIndex = 0; let m; while ((m = HON.exec(sg.text))) { const nm = m[1]; if (NOTNAME.test(nm)) continue; if (!by.has(nm)) by.set(nm, []); by.get(nm).push({ i, s, a: m.index, b: m.index + m[0].length, h: m[2] }); } }); });
      for (const [nm, L] of by) { const cnt = new Map(); for (const x of L) cnt.set(x.h, (cnt.get(x.h) || 0) + 1); if (cnt.size < 2) continue; const main = [...cnt].sort((p, q) => q[1] - p[1])[0][0]; const sum = [...cnt].map(([h, n]) => h + ' ' + n).join('・'); for (const x of L) if (x.h !== main) push('honor', x.i, x.s, x.a, x.b, `「${nm}」の敬称が混ざる（${sum}）。要確認`); } }
    const order = new Map(R.map((r, k) => [r.id, k])); out.sort((p, q) => order.get(p.rule) - order.get(q.rule) || p.line - q.line || p.a - q.a); return out; };

  /* ---- 照合：数・否定・敬称・日付（a が今、b が案） ---- */
  const DATE_TOK = /(?:(?:\d{4}|令和\s*(?:\d+|元)|平成\s*\d+)\s*年\s*)?\d{1,2}\s*月\s*\d{1,2}\s*日(?:\s*[（(][日月火水木金土](?:曜日?)?[）)])?|\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}|\d{1,2}\/\d{1,2}(?:\s*[（(][日月火水木金土][）)])?/g;
  const NUM_TOK = /(?:[+\-−△▲]\s*)?\d[\d,]*(?:\.\d+)?\s*(?:%|ポイント|pt|億円|百万円|千円|万円|円|億|万|千|件|人|名|社|台|個|本|回|時間|分|日|週|か月|ヶ月|カ月|月|年度|年|倍|割|歳|位|点|行|頁|ページ|kg|km)?/g;
  const NEG = /(?<![少危切幼])な(?:い|かっ|く)|ません|(?<![ま必わ])ず(?=[、。にとも]|$)|ぬ(?=[。、]|$)|不(?=[一-鿿])|非(?=[一-鿿])|未(?![来明])(?=[一-鿿])|無(?=[一-鿿])/g;
  const toks = (s, re, norm) => { const o = []; re.lastIndex = 0; let m; while ((m = re.exec(s))) if (m[0].trim()) o.push(norm(m[0])); return o; };
  const diffBag = (A, B) => { const cnt = new Map(); for (const x of A) cnt.set(x, (cnt.get(x) || 0) + 1); const added = []; for (const x of B) { const n = cnt.get(x) || 0; if (n) cnt.set(x, n - 1); else added.push(x); } const lost = []; for (const [x, n] of cnt) for (let k = 0; k < n; k++) lost.push(x); return { lost, added }; };
  const normNum = t => t.replace(/[\s,]/g, '').replace(/^[−△▲]/, '-').replace(/^\+/, '');
  const normDate = t => t.replace(/\s/g, '').replace(/曜日?/, '');
  FZ.collate = function (a, b) { const A = nfk(a), B = nfk(b); const items = [];
    const da = toks(A, DATE_TOK, normDate), db = toks(B, DATE_TOK, normDate); const D = diffBag(da, db); if (D.lost.length || D.added.length) items.push({ kind: '日付', ...D });
    const ra = A.replace(DATE_TOK, ' '), rb = B.replace(DATE_TOK, ' '); const N = diffBag(toks(ra, NUM_TOK, normNum), toks(rb, NUM_TOK, normNum)); if (N.lost.length || N.added.length) items.push({ kind: '数', ...N });
    const na = (A.match(NEG) || []).length, nb = (B.match(NEG) || []).length; if (na !== nb) items.push({ kind: '否定', lost: nb < na ? [String(na - nb)] : [], added: nb > na ? [String(nb - na)] : [] });
    const hon = s => { const o = new Map(); HON.lastIndex = 0; let m; while ((m = HON.exec(s))) { if (NOTNAME.test(m[1])) continue; if (!o.has(m[1])) o.set(m[1], []); o.get(m[1]).push(m[2]); } return o; }; const ha = hon(A), hb = hon(B); const H = { lost: [], added: [] };
    for (const [nm, L] of ha) if (hb.has(nm)) { const d = diffBag(L, hb.get(nm)); for (const x of d.lost) H.lost.push(nm + x); for (const x of d.added) H.added.push(nm + x); } if (H.lost.length || H.added.length) items.push({ kind: '敬称', ...H });
    const cut = L => L.slice(0, 3).join('・') + (L.length > 3 ? ' ほか' : ''); const text = items.map(x => x.kind === '否定' ? (x.lost.length ? '否定が消える' : '否定が増える') : x.lost.length && x.added.length ? `${x.kind} ${cut(x.lost)}→${cut(x.added)}` : x.lost.length ? `${x.kind}が消える ${cut(x.lost)}` : `${x.kind}が増える ${cut(x.added)}`).join('　');
    return { items, text, n: items.length }; };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
