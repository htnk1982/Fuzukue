/* 文机 — 書式プリセット
 * 新聞の見出し・表組の表現を文机の道具（網・罫・倍角・字下げ）に写した「見出し飾り」と「表スタイル」。
 * すべて 1 行（または選択範囲／カーソル位置の表）に対する一打鍵の操作で、取り消し可能。 */
(function (FZ) {
  'use strict';
  const M = FZ.M, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const COLS = ed => ed.doc.format.cols;
  const lineText = ln => ln.segs.map(s => s.text).join('');
  const setMarks = (ln, fn) => { for (const s of ln.segs) for (let q = 0; q < s.marks.length; q++) s.marks[q] = fn(s.marks[q] | 0); };
  const SIZE = FZ.SIZE_BITS || (M.WIDE | M.TALL);
  /* 行 b の直後に行を挿入（b の下辺の横罫は b に付いたまま） */
  function insertAfter(ed, b, ln) { const bottom = ed.doc.rules.filter(r => r.axis === 'h' && r.line === b + 1); ed.insertLine(b + 1, ln); for (const r of bottom) r.line = b + 1; }

  /* ---------- 見出し飾り ---------- */
  /* その行の全幅の網と、上辺・下辺の全幅罫、左右端の縦罫を外す（隣が表ならその罫は残す） */
  function clearDecor(ed, i) {
    const cols = COLS(ed), doc = ed.doc;
    ed.removeFillRect(i, i, 0, cols);
    const tableAbove = i > 0 && FZ.inTable(doc, i - 1), tableBelow = i + 1 < doc.lines.length && FZ.inTable(doc, i + 1);
    // 上辺の罫は前の行の下線でもあるので、この行が罫囲み（左右に縦罫がある）のときだけ外す
    const boxed = doc.rules.some(r => r.axis === 'v' && r.from === i && r.to === i && (r.col === 0 || r.col === cols));
    doc.rules = doc.rules.filter(r => {
      if (r.axis === 'h' && r.from <= 0 && r.to >= cols) { if (r.line === i && boxed && !tableAbove) return false; if (r.line === i + 1 && !tableBelow) return false; }
      if (r.axis === 'v' && r.from === i && r.to === i && (r.col === 0 || r.col === cols)) return false;
      return true;
    });
  }
  /* 飾りを付ける（K-3／K-10）：行の属性に名前を置き、罫・網は組版が引く。太字は足す。倍角・袋文字は名前に含まれるものだけ付け替え、含まないものは触らない。位置には触らない */
  function deco(ed, i, name) { const ln = ed.doc.lines[i]; const sp = name ? FZ.decoSpec(name) : null; if (name) ln.attrs.deco = name; else delete ln.attrs.deco;
    setMarks(ln, m => { m |= M.BOLD; if (sp && sp.size != null) m = (m & ~(SIZE | M.OUTLINE)) | sp.size; return m; }); }
  function base(ed, i) { const ln = ed.doc.lines[i]; delete ln.attrs.deco; setMarks(ln, m => m | M.BOLD); } // 太字だけ（肩見出し・リード）
  const fill = (ed, i, shade) => { ed.doc.fills.push({ id: FZ.uid(), from: i, to: i, col: 0, cols: COLS(ed), shade }); };
  const size = (ed, i, bits) => setMarks(ed.doc.lines[i], m => m | bits);
  /* 重要度の段階（新聞の 1〜5 段＋横見出し白抜き＋2段ぶち抜き に対応） */
  FZ.HEADINGS = [
    { id: 'sub', key: '1', label: '中見出し', short: '中見出', desc: 'ゴシック太字（本文の大きさ）。記事中の小見出し・◇の代わり', fn: (ed, i) => deco(ed, i, '中見出し') },
    { id: 'h', key: '2', label: '横倍角', desc: '太字＋横倍角。1段見出し相当', fn: (ed, i) => deco(ed, i, '横倍角') },
    { id: 'big', key: '3', label: '四倍角', desc: '太字＋四倍角（2行分）。大見出し', fn: (ed, i) => deco(ed, i, '四倍角') },
    { id: 'beta', key: '4', label: 'ベタ白抜き', short: 'ベタ白抜', desc: '黒地に白抜き（横見出し）。大ニュース級', fn: (ed, i) => deco(ed, i, 'ベタ白抜き') },
    { id: 'beta2', key: '5', label: 'ベタ2行ぶち抜き', short: 'ベタ2行', desc: '黒地白抜き＋四倍角。超弩級', fn: (ed, i) => deco(ed, i, 'ベタ2行') },
    { id: 'shade', key: '6', label: '薄網', desc: '薄い網に太字。特集・連載の見出し', fn: (ed, i) => deco(ed, i, '薄網') },
    { id: 'hatch', key: '7', label: '地紋（斜線）', short: '地紋斜', desc: '斜線の地紋に太字（地紋見出し）', fn: (ed, i) => deco(ed, i, '地紋斜線') },
    { id: 'dots', key: '8', label: '地紋（点）', short: '地紋点', desc: '点の地紋に太字', fn: (ed, i) => deco(ed, i, '地紋点') },
    { id: 'box', key: '9', label: '罫囲み', desc: '細罫で囲む（カット見出し）', fn: (ed, i) => deco(ed, i, '罫囲み') },
    { id: 'clear', key: '0', label: '飾り解除', short: '解除', desc: '網・罫・倍角・袋文字を外す（太字・位置は残す）', fn: (ed, i) => { const ln = ed.doc.lines[i]; delete ln.attrs.deco; setMarks(ln, m => m & ~(SIZE | M.OUTLINE)); } },
    { id: 'under', key: 'Q', label: '太罫下線', short: '太罫下', desc: '見出しの下に太罫', fn: (ed, i) => deco(ed, i, '太罫下線') },
    { id: 'under2', key: 'W', label: '二重罫下線', short: '二重罫下', desc: '見出しの下に二重罫', fn: (ed, i) => deco(ed, i, '二重罫下線') },
    { id: 'outline', key: 'E', label: '袋文字', desc: '白抜き文字に黒の縁取り（袋文字）', fn: (ed, i) => deco(ed, i, '袋文字') },
    { id: 'chidori', key: 'R', label: '肩・主・袖（千鳥）', short: '千鳥', desc: '選択した 2〜3 行を 肩見出し／主見出し（横倍角）／袖見出し（字下げ）に', range: true, fn: chidori },
    { id: 'lead', key: 'T', label: 'リード（前文）', short: 'リード', desc: '太字・1 字下げ・折返しも揃える（前文）', fn: (ed, i) => { base(ed, i); const a = ed.doc.lines[i].attrs; a.indent = 1; a.hanging = 1; } },
    { id: 'sep', key: 'Y', label: '◇ 区切り', short: '◇', desc: '記事の切れ目に中央の ◇ を 1 行入れる', fn: (ed, i) => { insertAfter(ed, i, { segs: [FZ.newSeg(0, '◇')], attrs: { align: 'center' } }); } },
    { id: 'article', key: 'U', label: '囲み記事（題＋箱）', short: '囲み', desc: '選択範囲を箱で囲み、先頭行を黒地白抜きの題に。本文は記号の箇条書き（囲み記事の中なら題を付ける）', range: true, fn: (ed, a, b, hadSel) => article(ed, a, b, true, hadSel) },
    { id: 'articleN', key: 'I', label: '囲み記事（題なし）', short: '囲み題なし', desc: '選択範囲を箱で囲む（題なし）。本文は記号の箇条書き（囲み記事の中なら題を外す）', range: true, fn: (ed, a, b, hadSel) => article(ed, a, b, false, hadSel) },
  ];
  function chidori(ed, a, b) {
    const n = b - a + 1; if (n < 2) { b = Math.min(ed.doc.lines.length - 1, a + 1); if (b === a) return false; }
    const lines = ed.doc.lines; const idx = []; for (let i = a; i <= b && idx.length < 3; i++) idx.push(i);
    const [kata, main, sode] = idx.length === 3 ? idx : [null, idx[0], idx[1]];
    if (kata != null) { base(ed, kata); }
    deco(ed, main, '横倍角');
    base(ed, sode); const at = lines[sode].attrs; at.indent = Math.min(6, Math.max(2, Math.round(FZ.textWidth(lineText(lines[main])) * 2 / 3))); at.hanging = at.indent;
    return true;
  }
  /* 囲み記事の本文の行を記号の箇条書きに（空の行・見出し・既に箇条書きの行はそのまま。行頭に打った「・」などは印に置き換える） */
  const BULLET_RE = /^[・●○■□◆◇▪▫•\-\*][\s　]*/;
  function toBullet(ln) {
    if (ln.segs.length !== 1 || ln.attrs.list || ln.attrs.style || ln.attrs.figure || ln.attrs.toc || ln.attrs.hr) return; const sg = ln.segs[0]; if (!sg.text.trim()) return;
    const m = sg.text.match(BULLET_RE); if (m && m[0].length < sg.text.length) { sg.text = sg.text.slice(m[0].length); sg.marks = sg.marks.slice(m[0].length); }
    ln.attrs.list = { level: 0 };
  }
  function article(ed, a, b, titled, hadSel) {
    const doc = ed.doc, c = COLS(ed);
    const cur = FZ.articleAround(doc, a);
    if (cur && b <= cur.b) { // 囲み記事の中：題の有無を切り替える
      const s = cur.a, ln = doc.lines[s];
      if (titled && !cur.titled) { delete ln.attrs.list; fill(ed, s, 'dark'); setMarks(ln, m => (m & ~(SIZE | M.OUTLINE)) | M.BOLD); ln.attrs.keep = 'next';
        if (cur.b === s) { insertAfter(ed, s, { segs: [FZ.newSeg(0, '')], attrs: { indent: 1, hanging: 1, list: { level: 0 } } }); for (const r of doc.rules) if (r.axis === 'v' && r.from === s && r.to === s && (r.col === 0 || r.col === c)) r.to = s + 1; const bt = doc.rules.find(r => r.axis === 'h' && r.line === s + 1 && r.from <= 0 && r.to >= c); if (bt) bt.line = s + 2; } }
      else if (!titled && cur.titled) { ed.removeFillRect(s, s, 0, c); delete ln.attrs.keep; setMarks(ln, m => m & ~M.BOLD); }
      return true;
    }
    let caretTo = null;
    if (hadSel === false && b === a && !FZ.inTable(doc, a)) { // 範囲を選んでいない：表と同じく、まず空の枠を作ってから中に書く（字のある行の下に新しく。空の行ならその行を枠に）
      const empty = !doc.lines[a].segs.some(g => g.text.trim()); if (!empty) { insertAfter(ed, a, { segs: [FZ.newSeg(0, '')], attrs: {} }); a++; } else doc.lines[a].attrs = {};
      b = a; if (titled) { insertAfter(ed, a, { segs: [FZ.newSeg(0, '')], attrs: {} }); b = a + 1; } caretTo = a; }
    else if (titled && b === a) { insertAfter(ed, a, { segs: [FZ.newSeg(0, '')], attrs: {} }); b = a + 1; caretTo = b; } // 1 行だけ選んで：題にして、下に本文の行を足す
    for (let i = a; i <= b; i++) { clearDecor(ed, i); const at = doc.lines[i].attrs; at.indent = 1; at.hanging = 1; if (!titled || i > a) toBullet(doc.lines[i]); }
    if (caretTo != null && !(titled && caretTo === a)) doc.lines[caretTo].attrs.list = { level: 0 }; if (titled && caretTo === a && b > a && !doc.lines[b].segs.some(g => g.text.trim())) doc.lines[b].attrs.list = { level: 0 }; /* 空で作った囲み：本文の行は記号の箇条書き */
    ed.addHRule(a, 0, c, 'thin'); ed.addHRule(b + 1, 0, c, 'thin'); ed.addVRule(a, b, 0, 'thin'); ed.addVRule(a, b, c, 'thin');
    if (titled) { const ln = doc.lines[a]; delete ln.attrs.list; fill(ed, a, 'dark'); setMarks(ln, m => (m & ~(SIZE | M.OUTLINE)) | M.BOLD); ln.attrs.keep = 'next'; }
    if (caretTo != null) { ed.caret.line = caretTo; ed.caret.seg = 0; ed.caret.off = 0; ed.caret.vcol = null; }
    return true;
  }
  FZ.applyHeading = function (ed, id) {
    const h = FZ.HEADINGS.find(x => x.id === id); if (!h) return;
    const [a, b] = ed.selectedLines(); const hadSel = !!ed.sel();
    ed.mutate('', () => {
      ed.anchor = null;
      if (h.range) { if (!h.fn(ed, a, b, hadSel)) return; }
      else for (let i = a; i <= b; i++) { if (FZ.inTable(ed.doc, i)) continue; h.fn(ed, i); }
      ed.normalizeSegs();
    });
  };

  /* ---------- 表スタイル ---------- */
  const NUM = /^[\s　]*[-−－▲△+＋]?[\d０-９][\d０-９,，.．]*[\s　]*[%％]?[\s　]*$/;
  const TOTAL = /^[\s　]*(合計|総計|小計|計|総数|全体)/;
  /* 表の列境界：その行にかかる縦罫の位置（表の右端は最後の縦罫。版面右端の仮のセルは含めない） */
  function tableBounds(d, a) { const cols = [...new Set(FZ.vRulesAt(d, a).map(r => r.col))].sort((x, y) => x - y); if (cols.length < 2) { const cs = FZ.cellsAt(d, a); return [cs[0].left, ...cs.map(c => c.right)]; } return cols; }
  FZ.tableBounds = tableBounds;
  FZ.tableRange = function (ed, i = ed.caret.line) { const d = ed.doc; if (!FZ.inTable(d, i)) return null; let a = i, b = i; while (a > 0 && FZ.inTable(d, a - 1)) a--; while (b + 1 < d.lines.length && FZ.inTable(d, b + 1)) b++; return [a, b]; };
  /* outer: 上下の罫／inner: 行間／header: 見出し行の下／vert: 縦罫（none＝透明）／outerV: 左右端の縦罫 */
  FZ.TABLES = [
    { id: 'grid', key: '1', label: '格子（標準）', short: '格子', desc: '全て細罫、見出し行は淡網', outer: 'thin', inner: 'thin', header: 'thin', vert: 'thin', headerFill: 'light' },
    { id: 'news', key: '2', label: '新聞', desc: '横罫だけ。上下太罫、見出し行は黒地白抜き、数値は右揃え', outer: 'thick', inner: 'thin', header: 'thick', vert: 'none', headerFill: 'dark', numRight: true },
    { id: 'stat', key: '3', label: '統計表', desc: '上下太罫・見出し行の下に細罫、行間は罫なし、合計行の上に細罫、数値は右揃え', outer: 'thick', inner: 'none', header: 'thin', vert: 'none', headerFill: null, totalRule: 'thin', numRight: true },
    { id: 'fin', key: '4', label: '決算表', desc: '経済面の表。見出し行は黒地白抜き、行間は点線、数値右揃え、マイナスは ▲', outer: 'thick', inner: 'dotted', header: 'thin', vert: 'none', headerFill: 'dark', numRight: true, triangle: true },
    { id: 'compare', key: '5', label: '対比表', desc: '格子に外枠太罫。見出し行は黒地白抜き、表側（左列）は淡網', outer: 'thick', inner: 'thin', header: 'thin', vert: 'thin', outerV: 'thick', headerFill: 'dark', sideFill: 'light' },
    { id: 'box', key: '6', label: '箱', desc: '外枠を太罫で囲み、中は横の細罫だけ', outer: 'thick', inner: 'thin', header: 'thin', vert: 'none', outerV: 'thick', headerFill: null },
    { id: 'bare', key: '7', label: '罫なし', desc: '見出し行の下の細罫だけ。本文に溶け込む表', outer: 'none', inner: 'none', header: 'thin', vert: 'none', headerFill: null },
  ];
  function numericCols(lines, a, b, bounds) {
    const n = bounds.length - 1, out = [];
    for (let c = 0; c < n; c++) { let any = false, ok = true; for (let i = a + 1; i <= b; i++) { const s = lines[i].segs.find(sg => sg.col === bounds[c]); const t = s ? s.text : ''; if (!t.trim()) continue; any = true; if (!NUM.test(t)) { ok = false; break; } } out[c] = any && ok; }
    return out;
  }
  FZ.applyTable = function (ed, id) {
    const p = FZ.TABLES.find(x => x.id === id); if (!p) return false;
    const rg = FZ.tableRange(ed); if (!rg) return false; const [a, b] = rg;
    ed.mutate('', () => {
      const d = ed.doc, lines = d.lines; const bounds = tableBounds(d, a); const L = bounds[0], R = bounds[bounds.length - 1];
      for (let i = a; i <= b + 1; i++) ed.eraseH(i, L, R);
      // 縦罫は一括で差し替える（途中で normalizeSegs が走るとセルが結合されてしまう）
      d.rules = d.rules.filter(r => !(r.axis === 'v' && bounds.includes(r.col) && r.from >= a && r.to <= b));
      for (const c of bounds) { const edge = c === L || c === R; d.rules.push({ id: FZ.uid(), axis: 'v', from: a, to: b, col: c, kind: edge ? (p.outerV || p.vert) : p.vert }); }
      ed.removeFillRect(a, b, L, R - L);
      for (let i = a; i <= b + 1; i++) { if (i > a && i <= b && lines[i].attrs.crow) continue; /* 行続き（セルの中の改行）の上には罫を引かない */ let k = i === a || i === b + 1 ? p.outer : i === a + 1 ? p.header : p.inner; if (p.totalRule && i === b && b > a + 1 && TOTAL.test(lineText(lines[b]))) k = p.totalRule; if (k && k !== 'none') ed.addHRule(i, L, R, k); }
      ed.coalesce();
      if (p.headerFill) d.fills.push({ id: FZ.uid(), from: a, to: a, col: L, cols: R - L, shade: p.headerFill });
      if (p.sideFill && b > a) d.fills.push({ id: FZ.uid(), from: a + 1, to: b, col: L, cols: bounds[1] - L, shade: p.sideFill });
      setMarks(lines[a], m => m | M.BOLD);
      if (p.numRight) alignNumeric(lines, a, b, bounds);
      if (p.triangle) triangle(lines, a, b, bounds);
      ed.normalizeSegs();
    });
    return true;
  };
  function alignNumeric(lines, a, b, bounds) { const nc = numericCols(lines, a, b, bounds); for (let i = a; i <= b; i++) { const at = lines[i].attrs; const ca = Array.from({ length: nc.length }, (_, c) => (at.cellAlign && at.cellAlign[c]) || null); for (let c = 0; c < nc.length; c++) if (nc[c]) ca[c] = 'right'; if (ca.some(Boolean)) at.cellAlign = ca; } }
  function triangle(lines, a, b, bounds) { for (let i = a + 1; i <= b; i++) for (const s of lines[i].segs) { if (!NUM.test(s.text)) continue; const t = s.text.replace(/^([\s　]*)[-−－]/, '$1▲'); if (t !== s.text) { s.text = t; s.marks = s.marks.slice(0, t.length); while (s.marks.length < t.length) s.marks.push(0); } } }
  /* 単発の表操作 */
  FZ.TABLE_OPS = [
    { id: 'numRight', key: 'Q', label: '数値列を右揃え', short: '数値右揃え', desc: '数値だけの列を右揃えにする（見出し行も）', fn: (ed, a, b, bounds) => alignNumeric(ed.doc.lines, a, b, bounds) },
    { id: 'alignL', key: 'A', label: '列揃え解除', short: '揃え解除', desc: 'セルごとの揃えを外す', fn: (ed, a, b) => { for (let i = a; i <= b; i++) delete ed.doc.lines[i].attrs.cellAlign; } },
    { id: 'headFill', key: 'W', label: '見出し行の網…', short: '見出し網…', desc: '見出し行の網を選ぶ（淡網・薄網・濃網・濃灰・墨・斜線・なし）', fn: (ed, a, b, bounds) => { const L = bounds[0], R = bounds[bounds.length - 1]; const cur = ed.doc.fills.find(f => f.from === a && f.to === a && f.col <= L && f.col + f.cols >= R); const next = !cur ? 'light' : cur.shade === 'light' ? 'gray' : cur.shade === 'gray' ? 'dark' : cur.shade === 'dark' ? null : 'light'; ed.removeFillRect(a, a, L, R - L); if (next) ed.doc.fills.push({ id: FZ.uid(), from: a, to: a, col: L, cols: R - L, shade: next }); } },
    { id: 'unit', key: 'E', label: '単位行', short: '単位行', desc: '表の右上に「（単位：　）」の行を置く', fn: (ed, a, b, bounds) => { const prev = a > 0 ? ed.doc.lines[a - 1] : null; const R = bounds[bounds.length - 1]; const text = '（単位：　）'; const cols = ed.doc.format.cols; const ln = { segs: [FZ.newSeg(0, text)], attrs: R < cols ? { indent: Math.max(0, R - FZ.textWidth(text)), keep: 'next' } : { align: 'right', keep: 'next' } }; if (prev && prev.segs.length === 1 && prev.segs[0].text === '' && !FZ.inTable(ed.doc, a - 1)) { prev.segs = ln.segs; prev.attrs = { ...prev.attrs, ...ln.attrs }; ed.caret.line = a - 1; } else { ed.insertLine(a, ln); ed.caret.line = a; } ed.caret.seg = 0; ed.caret.off = 4; ed.caret.vcol = null; } },
    { id: 'note', key: 'R', label: '注の行', short: '注の行', desc: '表の下に「（注）」の行を置く（折返しは注の本文に揃う）', fn: (ed, a, b) => { const ln = { segs: [FZ.newSeg(0, '（注）')], attrs: { hanging: 3 } }; insertAfter(ed, b, ln); ed.caret.line = b + 1; ed.caret.seg = 0; ed.caret.off = 3; ed.caret.vcol = null; } },
    { id: 'tri', key: 'T', label: 'マイナスを ▲ に', short: '▲化', desc: '数値セルの先頭の − を ▲ に（新聞の慣例）', fn: (ed, a, b, bounds) => triangle(ed.doc.lines, a, b, bounds) },
    { id: 'headBold', key: 'Y', label: '見出し行を太字', short: '見出し太字', desc: '先頭行をゴシック太字に', fn: (ed, a) => setMarks(ed.doc.lines[a], m => m | M.BOLD) },
    { id: 'repeat', key: 'U', label: '見出し行の繰り返し 切替', short: '見出し繰返', desc: 'ページをまたぐ表で、次のページの頭に見出し行（1 行目）を繰り返す（既定）／繰り返さない', fn: (ed, a) => { const at = ed.doc.lines[a].attrs; if (at.noRepeat) delete at.noRepeat; else at.noRepeat = true; } },
  ];
  FZ.applyTableOp = function (ed, id) {
    const op = FZ.TABLE_OPS.find(x => x.id === id); if (!op) return false;
    const rg = FZ.tableRange(ed); if (!rg) return false; const [a, b] = rg;
    ed.mutate('', () => { const bounds = tableBounds(ed.doc, a); op.fn(ed, a, b, bounds); ed.normalizeSegs(); });
    return true;
  };

  /* ---------- 原本形式（fzk 2）のための純粋関数：名前 ⇄ 罫・網 ----------
   * 見出し飾り・表スタイル・囲み記事を、原本では名前（[飾り:ベタ白抜き]／#表 … 様式 格子／#囲み ×3）で書けるようにする。
   * 書き出し側は「実際の罫・網が名前どおりか」を照合してから名前を使い、違えば位置を明示する。 */
  function removeFillRectDoc(doc, from, to, col, cols) { const keep = []; for (const f of doc.fills) { const ov = !(f.to < from || f.from > to || f.col + f.cols <= col || f.col >= col + cols); if (!ov) { keep.push(f); continue; } if (f.from < from) keep.push({ ...f, id: FZ.uid(), to: from - 1 }); if (f.to > to) keep.push({ ...f, id: FZ.uid(), from: to + 1 }); const y1 = Math.max(f.from, from), y2 = Math.min(f.to, to); if (f.col < col) keep.push({ ...f, id: FZ.uid(), from: y1, to: y2, cols: col - f.col }); if (f.col + f.cols > col + cols) keep.push({ ...f, id: FZ.uid(), from: y1, to: y2, col: col + cols, cols: f.col + f.cols - col - cols }); } doc.fills = keep; }
  const shim = doc => ({ doc, addHRule: (line, from, to, kind) => { if (!doc.rules.some(r => r.axis === 'h' && r.line === line && r.from === from && r.to === to && r.kind === kind)) doc.rules.push({ id: FZ.uid(), axis: 'h', line, from, to, kind }); }, addVRule: (from, to, col, kind) => { doc.rules.push({ id: FZ.uid(), axis: 'v', from, to, col, kind }); }, removeFillRect: (f, t, c, n) => removeFillRectDoc(doc, f, t, c, n), insertLine: () => { }, normalizeSegs: () => { } });
  /* 名前で表せる飾り：罫・網の部分だけ（文字の修飾は本文のタグが持つ） */
  const DECOS = { 'ベタ白抜き': { fill: 'dark' }, '薄網': { fill: 'gray' }, '地紋斜線': { fill: 'hatch' }, '地紋点': { fill: 'dots' }, '罫囲み': { box: 'thin' }, '太罫下線': { under: 'thick' }, '二重罫下線': { under: 'double' }, '細罫下線': { under: 'thin' } };
  FZ.DECO_NAMES = Object.keys(FZ.DECO_SPECS);
  const hid = (p) => p.id;
  function decoSig(d) { const out = []; if (d.fill) out.push('f:' + d.fill); if (d.box) out.push('h0:' + d.box, 'h1:' + d.box, 'v0:' + d.box, 'v1:' + d.box); if (d.under) out.push('h1:' + d.under); return out.sort().join(' '); }
  /* 行 i の飾り（全幅の網・上下の全幅罫・左右端の縦罫）を集める。上辺の罫は箱のときだけ数える */
  function lineDeco(doc, i) {
    const cols = doc.format.cols; const rules = [], fills = [];
    const vs = doc.rules.filter(r => r.axis === 'v' && r.from === i && r.to === i && (r.col === 0 || r.col === cols)); const boxed = vs.length === 2;
    const tableBelow = i + 1 < doc.lines.length && FZ.inTable(doc, i + 1), tableAbove = i > 0 && FZ.inTable(doc, i - 1);
    const boxBelow = doc.rules.some(r => r.axis === 'v' && r.from === i + 1 && (r.col === 0 || r.col === cols)); // 次の行が箱・囲みなら、その上辺はこの行の下線ではない
    for (const r of doc.rules) { if (r.axis === 'h' && r.from <= 0 && r.to >= cols && ((r.line === i + 1 && !tableBelow && !boxBelow) || (boxed && r.line === i && !tableAbove))) rules.push(r); }
    rules.push(...vs);
    for (const f of doc.fills) if (f.from === i && f.to === i && f.col <= 0 && f.col + f.cols >= cols) fills.push(f);
    const sig = [...fills.map(f => 'f:' + f.shade), ...rules.map(r => (r.axis === 'h' ? (r.line === i ? 'h0:' : 'h1:') : (r.col === 0 ? 'v0:' : 'v1:')) + r.kind)].sort().join(' ');
    return { sig, rules, fills };
  }
  /* 1.0.9f から見出し飾りは行の属性（attrs.deco）。罫の形から名前を推測する decoMatch／名前から罫を作る applyDecoByName は廃止（K-3） */
  /* 囲み記事：a 行目から b 行目までの箱＋題（濃網）。一致すれば { b, ruleIds, fillIds } */
  FZ.articleMatch = function (doc, a) { /* 1.0.12c 左右の縦罫は任意の桁（L-R）。全幅なら 0-版面の字数 */
    const ln0 = doc.lines[a]; if (!ln0 || ln0.attrs.cells) return null; const va = FZ.vRulesAt(doc, a).filter(r => r.from === a && r.kind === 'thin'); if (va.length < 2) return null; /* 索引があれば O(1)（原本の書き出しは行ごとに呼ぶ） */
    let v0 = va[0], v1 = va[0]; for (const r of va) { if (r.col < v0.col) v0 = r; if (r.col > v1.col) v1 = r; }
    if (v0 === v1 || v0.to !== v1.to) return null; const b = v0.to, L = v0.col, R = v1.col; if (R - L < 4) return null;
    const top = doc.rules.find(r => r.axis === 'h' && r.line === a && r.from <= L + 1e-6 && r.to >= R - 1e-6 && r.kind === 'thin'), bottom = doc.rules.find(r => r.axis === 'h' && r.line === b + 1 && r.from <= L + 1e-6 && r.to >= R - 1e-6 && r.kind === 'thin'); if (!top || !bottom) return null;
    const fill = doc.fills.find(f => f.from === a && f.to === a && f.col <= L + 1e-6 && f.col + f.cols >= R - 1e-6 && f.shade === 'dark') || null; // 題（黒地）が無ければ題なしの囲み
    for (let i = a; i <= b; i++) { const at = doc.lines[i].attrs; if (at.indent !== 1 || at.hanging !== 1 || at.cells) return null; if (doc.fills.some(f => f !== fill && f.from <= i && f.to >= i)) return null; if (FZ.vRulesAt(doc, i).some(r => r.col > L + 1e-6 && r.col < R - 1e-6)) return null; }
    for (let i = a + 1; i <= b; i++) if (doc.rules.some(r => r.axis === 'h' && r.line === i && r.from <= L + 1e-6 && r.to >= R - 1e-6)) return null;
    return { b, L, R, titled: !!fill, ruleIds: new Set([v0.id, v1.id, top.id, bottom.id]), fillIds: new Set(fill ? [fill.id] : []), rules: { v0, v1, top, bottom }, fill };
  };
  /* 行 i を含む囲み記事：{ a, b, L, R, titled, … } | null */
  FZ.articleAround = function (doc, i) { for (const v of FZ.vRulesAt(doc, i).slice().sort((x, y) => x.col - y.col)) { const m = FZ.articleMatch(doc, v.from); if (m && m.b >= i) return { a: v.from, ...m }; } return null; };
  FZ.applyArticlePure = function (doc, a, b, titled = true, L = null, R = null) { const c = doc.format.cols, ed = shim(doc); b = Math.min(b, doc.lines.length - 1); if (b < a) return false; const l0 = L == null ? 0 : L, r0 = R == null ? c : R; ed.addHRule(a, l0, r0, 'thin'); ed.addHRule(b + 1, l0, r0, 'thin'); ed.addVRule(a, b, l0, 'thin'); ed.addVRule(a, b, r0, 'thin'); if (titled) doc.fills.push({ id: FZ.uid(), from: a, to: a, col: l0, cols: r0 - l0, shade: 'dark' }); for (let i = a; i <= b; i++) { const at = doc.lines[i].attrs; at.indent = 1; at.hanging = 1; } if (titled) doc.lines[a].attrs.keep = 'next'; return true; };
  /* 1.0.12c 囲みの幅と位置：左右の罫を動かす（題の網・上下の罫も合わせる）。W は動かせる右端 */
  FZ.boxSet = function (ed, A, L, R) { L = Math.round(L * 2) / 2; R = Math.round(R * 2) / 2; if (R - L < 6 || L < 0) return false; if (Math.abs(L - A.L) < 1e-6 && Math.abs(R - A.R) < 1e-6) return false;
    ed.mutate('', () => { const d = ed.doc; const by = id => d.rules.find(r => r.id === id); const { v0, v1, top, bottom } = A.rules; const rv0 = by(v0.id), rv1 = by(v1.id), rt = by(top.id), rb = by(bottom.id); if (rv0) rv0.col = L; if (rv1) rv1.col = R;
      for (const h of [rt, rb]) if (h) { if (Math.abs(h.from - A.L) < 1e-6 && Math.abs(h.to - A.R) < 1e-6) { h.from = L; h.to = R; } else { d.rules.push({ id: FZ.uid(), axis: 'h', line: h.line, from: L, to: R, kind: 'thin' }); } }
      if (A.fill) { const f = d.fills.find(x => x.id === A.fill.id); if (f) { f.col = L; f.cols = R - L; } } }); return true; };
  /* 表スタイル：罫の期待集合 */
  function tableRuleSet(doc, a, b, bounds, p) {
    const lines = doc.lines, L = bounds[0], R = bounds[bounds.length - 1], set = [];
    for (const c of bounds) { const edge = c === L || c === R; set.push(`v:${c}:${a}:${b}:${edge ? (p.outerV || p.vert) : p.vert}`); }
    for (let i = a; i <= b + 1; i++) { if (i > a && i <= b && lines[i].attrs.crow) continue; let k = i === a || i === b + 1 ? p.outer : i === a + 1 ? p.header : p.inner; if (p.totalRule && i === b && b > a + 1 && TOTAL.test(lineText(lines[b]))) k = p.totalRule; if (k && k !== 'none') set.push(`h:${i}:${L}:${R}:${k}`); }
    return set.sort();
  }
  const SH = { gray: '薄', dark: '濃', hatch: '斜線', dots: '点' }, SHK = { 薄: 'gray', 濃: 'dark', 斜線: 'hatch', 点: 'dots', なし: null };
  FZ.TABLE_NAMES = Object.fromEntries(FZ.TABLES.map(t => [t.id, t.label.replace(/（.*$/, '')]));
  FZ.tableMatch = function (doc, a, b) {
    const bounds = tableBounds(doc, a); const L = bounds[0], R = bounds[bounds.length - 1];
    let actual; if (FZ.hasRuleIndex(doc)) { const seen = new Set(); actual = []; const add = r => { if (!seen.has(r)) { seen.add(r); actual.push(r); } }; // 索引があれば表の行だけを見る（順は原本の罫の順）
      for (let q = a; q <= b; q++) for (const r of FZ.vRulesAt(doc, q)) if (bounds.includes(r.col)) add(r); for (let q = a; q <= b + 1; q++) for (const r of FZ.hRulesAt(doc, q)) if (r.from < R && r.to > L) add(r); }
    else actual = doc.rules.filter(r => (r.axis === 'v' && bounds.includes(r.col) && r.from <= b && r.to >= a) || (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from < R && r.to > L));
    const sig = actual.map(r => r.axis === 'v' ? `v:${r.col}:${r.from}:${r.to}:${r.kind}` : `h:${r.line}:${r.from}:${r.to}:${r.kind}`).sort();
    const fills = doc.fills.filter(f => f.from <= b && f.to >= a && f.col < R && f.col + f.cols > L);
    const head = fills.find(f => f.from === a && f.to === a && f.col === L && f.cols === R - L), side = fills.find(f => f.from === a + 1 && f.to === b && f.col === L && f.cols === bounds[1] - L && b > a);
    // ほかの網（セルの網）は様式の外。名前は保ったまま、原本では #網 として別に書く
    for (const p of FZ.TABLES) { const exp = tableRuleSet(doc, a, b, bounds, p); if (exp.length === sig.length && exp.every((x, k) => x === sig[k])) return { preset: p.id, bounds, headFill: head ? head.shade : null, sideFill: side ? side.shade : null, ruleIds: new Set(actual.map(r => r.id)), fillIds: new Set([head, side].filter(Boolean).map(f => f.id)) }; }
    return null;
  };
  FZ.applyTablePure = function (doc, a, b, bounds, presetId, headFill, sideFill) {
    const p = FZ.TABLES.find(x => x.id === presetId); if (!p) return false; const L = bounds[0], R = bounds[bounds.length - 1];
    for (const sig of tableRuleSet(doc, a, b, bounds, p)) { const [ax, x, f, t, kind] = sig.split(':'); if (ax === 'v') doc.rules.push({ id: FZ.uid(), axis: 'v', col: +x, from: +f, to: +t, kind }); else doc.rules.push({ id: FZ.uid(), axis: 'h', line: +x, from: +f, to: +t, kind }); }
    if (headFill) doc.fills.push({ id: FZ.uid(), from: a, to: a, col: L, cols: R - L, shade: headFill }); if (sideFill && b > a) doc.fills.push({ id: FZ.uid(), from: a + 1, to: b, col: L, cols: bounds[1] - L, shade: sideFill });
    return true;
  };
  FZ.SHADE_NAME = SH; FZ.SHADE_KEY = SHK;
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
