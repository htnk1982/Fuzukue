/* 文机 — 表の編集：行・列の挿入と削除、列の幅（境の罫を動かす）、セルの範囲（網・揃え・中身・太字）
 * 表は「attrs.cells の続く行」＋「縦罫（セルの境）」＋「横罫（行の境）」＋「網」。ここでは罫・網・セルの段（seg）をまとめて付け替える。
 * 様式どおりの表（FZ.tableMatch が名前を返す表）は、形を変えたあと同じ様式で罫・網を引き直す（見出し行・合計行の罫も正しく付く）。 */
(function (FZ) {
  'use strict';
  const M = FZ.M;
  const EPS = 1e-6;
  const T = FZ.tbl = {};

  /* 表の範囲・列の境（全行の縦罫の位置の和。結合して一部の行に無い境も含む）・様式 */
  function info(ed, i = ed.caret.line) {
    const rg = FZ.tableRange(ed, i); if (!rg) return null; const [a, b] = rg; const d = ed.doc;
    const set = new Set(); for (const r of d.rules) if (r.axis === 'v' && r.from <= b && r.to >= a) set.add(r.col);
    const B = [...set].sort((x, y) => x - y); if (B.length < 2) return null;
    return { a, b, B, L: B[0], R: B[B.length - 1], n: B.length - 1, match: FZ.tableMatch ? FZ.tableMatch(d, a, b) : null };
  }
  T.info = info;
  const present = (d, i, col) => d.rules.some(r => r.axis === 'v' && Math.abs(r.col - col) < EPS && r.from <= i && r.to >= i);
  /* 行 i で列 j を含むセルの段（seg）の番号。無ければ -1 */
  function segAt(d, i, B, j) { const ln = d.lines[i]; let best = -1; ln.segs.forEach((s, k) => { if (s.col <= B[j] + EPS && (best < 0 || s.col > ln.segs[best].col)) best = k; }); return best; }
  T.segAt = segAt;
  /* カーソルのある列（境の番号） */
  T.colOf = (ed, I = info(ed)) => { if (!I) return -1; const s = ed.seg(); let j = I.B.findIndex(c => Math.abs(c - s.col) < EPS); if (j < 0) j = I.B.filter(c => c <= s.col).length - 1; return Math.max(0, Math.min(I.n - 1, j)); };

  /* 様式どおりの表なら、範囲 [a,b] の罫・網を消して同じ様式で引き直す */
  function reapply(ed, a, b, m) {
    if (!m) return; const d = ed.doc; const set = new Set(); for (const r of d.rules) if (r.axis === 'v' && r.from <= b && r.to >= a) set.add(r.col); const B = [...set].sort((x, y) => x - y); if (B.length < 2) return; const L = B[0], R = B[B.length - 1];
    d.rules = d.rules.filter(r => !((r.axis === 'v' && B.includes(r.col) && r.from >= a && r.to <= b) || (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= R + EPS)));
    ed.removeFillRect(a, b, L, R - L);
    FZ.applyTablePure(d, a, b, B, m.preset, m.headFill, m.sideFill);
  }
  /* 表の中の行の区切りの線種（見出し行の下・外枠を除いた中の罫のうち多いもの。無ければ null＝引かない） */
  function innerKind(d, a, b, L, R) { const cnt = new Map(); for (const r of d.rules) if (r.axis === 'h' && r.line > a + 1 && r.line <= b && r.from <= L + EPS && r.to >= R - EPS) cnt.set(r.kind, (cnt.get(r.kind) || 0) + 1); let best = null, n = 0; for (const [k, c] of cnt) if (c > n) { best = k; n = c; } if (best) return best; if (b > a + 1) return null; /* 本文の行の間に罫が無い表 */ const hs = d.rules.find(r => r.axis === 'h' && r.line === a + 1 && r.from <= L + EPS && r.to >= R - EPS); return hs ? hs.kind : null; }

  /* ---------- 行 ---------- */
  T.insertRow = function (ed, below, opt) {
    const I = info(ed); if (!I) return false; const d = ed.doc, c = ed.caret, i = c.line; const { a, b, L, R, match } = I;
    (opt && opt.inMutate ? f => f() : f => ed.mutate('', f))(() => { /* 1.0.15d 合計の行・流し込みから：外の取消の単位の中で */
      const src = d.lines[i]; const nl = { segs: src.segs.map(s => FZ.newSeg(s.col, '')), attrs: { cells: true } }; if (src.attrs.cellAlign) nl.attrs.cellAlign = src.attrs.cellAlign.slice();
      const kind = innerKind(d, a, b, L, R); const k = below ? i + 1 : i;
      const starting = below ? [] : d.rules.filter(r => r.axis === 'v' && r.from === i && r.col >= L - EPS && r.col <= R + EPS);
      const topRules = d.rules.filter(r => r.axis === 'h' && r.line === k && r.from >= L - EPS && r.to <= R + EPS);
      ed.insertLine(k, nl, below);
      for (const r of starting) r.from = i; // 上に足すとき：この行から始まる縦罫を新しい行まで伸ばす
      if (below && i === a && b > a) { for (const r of topRules) r.line = a + 1; if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: a + 2, from: L, to: R, kind }); } // 見出し行の下に足す：見出しの下の罫は見出しに付けたまま
      else if (!below && i === a) { for (const r of topRules) r.line = a; if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: a + 1, from: L, to: R, kind }); } // 先頭の上に足す：外枠の上辺は表の上に
      else if (kind) d.rules.push({ id: FZ.uid(), axis: 'h', line: k, from: L, to: R, kind });
      ed.dedupeRules(); reapply(ed, a, b + 1, match);
      ed.normalizeSegs(); c.line = k; c.seg = 0; c.off = 0; c.vcol = null; ed.anchor = null; // 足した行の先頭のセルへ（行の見出しから打てる）
    });
    return true;
  };
  T.deleteRow = function (ed) {
    const I = info(ed); if (!I) return false; const d = ed.doc, c = ed.caret, i = c.line; const { a, b, L, R, match } = I;
    if (a === b) return T.deleteTable(ed);
    ed.mutate('', () => {
      const atTop = d.rules.filter(r => r.axis === 'h' && r.line === i && r.from >= L - EPS && r.to <= R + EPS), below = d.rules.filter(r => r.axis === 'h' && r.line === i + 1 && r.from >= L - EPS && r.to <= R + EPS);
      const drop = new Set((i === a ? below : atTop).map(r => r.id)); // 先頭の行を消す：外枠の上辺を残す。ほかの行：その行の下の罫を残す
      d.rules = d.rules.filter(r => !drop.has(r.id));
      ed.removeLine(i); reapply(ed, a, b - 1, match);
      c.line = Math.min(i, b - 1); const ln = d.lines[c.line]; c.seg = Math.min(c.seg, ln.segs.length - 1); c.off = 0; c.vcol = null; ed.anchor = null;
      ed.normalizeSegs();
    });
    return true;
  };
  T.deleteTable = function (ed) {
    const I = info(ed); if (!I) return false; const d = ed.doc; const { a, b, B, L, R } = I;
    ed.mutate('', () => {
      d.rules = d.rules.filter(r => !((r.axis === 'v' && B.includes(r.col) && r.from >= a && r.to <= b) || (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= R + EPS)));
      ed.removeFillRect(a, b, L, R - L);
      for (let i = b; i > a; i--) ed.removeLine(i);
      d.lines[a] = FZ.newLine(); ed.caret = { line: a, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; // 表のあった所は空の行 1 つに
    });
    return true;
  };

  /* ---------- 列：組み替え（cols＝新しい列 [{src: 元の列 | null, w, splitOf?}]） ---------- */
  function regrid(ed, I, cols, newKind) {
    const d = ed.doc; const { a, b, B, L, n } = I; const m = cols.length;
    const NB = [L]; for (const c of cols) NB.push(NB[NB.length - 1] + c.w);
    /* 新しい境 c（1..m-1）の素性：元の境 q か、全行に引く新しい境 'all' */
    const ident = [{ old: 0 }]; for (let c = 1; c < m; c++) { const x = cols[c - 1], y = cols[c];
      if (x.src != null && y.src != null) ident.push({ old: y.src });
      else if (x.src != null) ident.push(y.splitOf === x.src ? { all: true } : { old: x.src + 1 });
      else ident.push(x.splitOf === y.src && y.src != null ? { all: true } : { old: y.src != null ? y.src : n }); }
    ident.push({ old: n });
    const oldToNew = q => { const c = ident.findIndex(t => t.old === q); if (c >= 0) return NB[c]; let best = NB[0]; for (const x of NB) if (Math.abs(x - B[q]) < Math.abs(best - B[q])) best = x; return best; };
    // 元の縦罫の線種（行×境）
    const kindAt = []; for (let i = a; i <= b; i++) kindAt.push(new Array(n + 1).fill(null));
    const keep = []; for (const r of d.rules) { if (r.axis !== 'v') { keep.push(r); continue; } const q = B.findIndex(x => Math.abs(x - r.col) < EPS); if (q < 0 || r.to < a || r.from > b) { keep.push(r); continue; }
      for (let i = Math.max(a, r.from); i <= Math.min(b, r.to); i++) kindAt[i - a][q] = r.kind; if (r.from < a) keep.push({ ...r, id: FZ.uid(), to: a - 1 }); if (r.to > b) keep.push({ ...r, id: FZ.uid(), from: b + 1 }); }
    d.rules = keep;
    const has = (i, c) => { const t = ident[c]; if (t.all) return true; return kindAt[i - a][t.old] != null; };
    const kindOf = (i, c) => { const t = ident[c]; return t.all ? newKind : kindAt[i - a][t.old]; };
    for (let c = 0; c <= m; c++) { let run = null; for (let i = a; i <= b + 1; i++) { const k = i <= b && has(i, c) ? kindOf(i, c) : null; if (run && run.kind === k) { run.to = i; continue; } if (run && run.kind != null) d.rules.push({ id: FZ.uid(), axis: 'v', col: NB[c], from: run.from, to: run.to, kind: run.kind }); run = { from: i, to: i, kind: k }; } }
    // セルの段：元の列ごとに中身を新しい列へ（消える列の中身は捨てる。結合セルは残る列の先頭へ）
    for (let i = a; i <= b; i++) {
      const ln = d.lines[i]; const ca = ln.attrs.cellAlign; ln.segs.forEach((s, k) => { s._al = ca ? ca[k] || null : null; });
      const presOld = q => kindAt[i - a][q] != null; const out = [];
      for (const s of ln.segs) { const q = B.findIndex(x => Math.abs(x - s.col) < EPS); if (q < 0 || q >= n) { if (s.col >= B[n] - EPS || s.col < L - EPS) out.push(s); continue; }
        let qe = q + 1; while (qe < n && !presOld(qe)) qe++; let target = -1; for (let src = q; src < qe && target < 0; src++) { const c = cols.findIndex(x => x.src === src); if (c >= 0) target = c; }
        if (target < 0) continue; s.col = NB[target]; out.push(s); }
      for (let c = 0; c < m; c++) if ((c === 0 || has(i, c)) && !out.some(s => Math.abs(s.col - NB[c]) < EPS)) { const s = FZ.newSeg(NB[c], ''); s._al = null; out.push(s); }
      out.sort((x, y) => x.col - y.col); ln.segs = out; if (ca || out.some(s => s._al)) { ln.attrs.cellAlign = out.map(s => s._al || null); if (!ln.attrs.cellAlign.some(Boolean)) delete ln.attrs.cellAlign; } for (const s of out) delete s._al;
    }
    // 横罫・網の端
    const mapX = x => { const q = B.findIndex(y => Math.abs(y - x) < EPS); return q < 0 ? x : oldToNew(q); };
    for (const r of d.rules) if (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= L - EPS && r.to <= B[n] + EPS) { r.from = mapX(r.from); r.to = mapX(r.to); }
    d.rules = d.rules.filter(r => r.axis !== 'h' || r.to > r.from);
    for (const f of d.fills) if (f.from <= b && f.to >= a && f.col >= L - EPS && f.col + f.cols <= B[n] + EPS) { const x1 = mapX(f.col), x2 = mapX(f.col + f.cols); f.col = x1; f.cols = x2 - x1; }
    d.fills = d.fills.filter(f => f.cols > 0);
    return NB;
  }
  const widths = I => I.B.slice(1).map((x, k) => x - I.B[k]);
  function commonKind(d, I) { const cnt = new Map(); for (const r of d.rules) if (r.axis === 'v' && r.from <= I.b && r.to >= I.a && r.col > I.L + EPS && r.col < I.R - EPS) cnt.set(r.kind, (cnt.get(r.kind) || 0) + 1); let best = 'thin', c = 0; for (const [k, v] of cnt) if (v > c) { best = k; c = v; } return best; }
  T.insertCol = function (ed, right) {
    const I = info(ed); if (!I) return false; const j = T.colOf(ed, I); const W = widths(I); const d = ed.doc;
    let cols = W.map((w, k) => ({ src: k, w })); let at;
    if (W[j] >= 4) { const nw = Math.floor(W[j] / 2); cols[j].w = W[j] - nw; at = right ? j + 1 : j; cols.splice(at, 0, { src: null, w: nw, splitOf: j }); }
    else { let q = -1; W.forEach((w, k) => { if (w >= 4 && (q < 0 || w > W[q])) q = k; }); if (q < 0) return 'narrow'; const nw = Math.floor(W[q] / 2); cols[q].w -= nw; at = right ? j + 1 : j; cols.splice(at, 0, { src: null, w: nw }); }
    ed.mutate('', () => { const kind = commonKind(d, I); const NB = regrid(ed, I, cols, kind); reapply(ed, I.a, I.b, I.match); ed.normalizeSegs(); const ln = ed.line(); const k = ln.segs.findIndex(s => Math.abs(s.col - NB[at]) < EPS); ed.caret.seg = k >= 0 ? k : 0; ed.caret.off = 0; ed.caret.vcol = null; ed.anchor = null; });
    return true;
  };
  T.deleteCol = function (ed) {
    const I = info(ed); if (!I) return false; if (I.n <= 1) return T.deleteTable(ed); const j = T.colOf(ed, I); const W = widths(I); const d = ed.doc;
    const cols = W.map((w, k) => ({ src: k, w })); const nb = j > 0 ? j - 1 : j + 1; cols[nb].w += W[j]; cols.splice(j, 1);
    ed.mutate('', () => { const NB = regrid(ed, I, cols, commonKind(d, I)); reapply(ed, I.a, I.b, I.match); ed.normalizeSegs(); const at = Math.min(j, cols.length - 1); const ln = ed.line(); const k = ln.segs.findIndex(s => Math.abs(s.col - NB[at]) < EPS); ed.caret.seg = k >= 0 ? k : 0; ed.caret.off = 0; ed.caret.vcol = null; ed.anchor = null; });
    return true;
  };
  /* 列の幅：境 k（0..n）を x へ。隣の境と 2 マス以上あける。右端は版面の右端まで */
  T.boundaryRange = function (ed, I, k) { const cols = ed.doc.format.cols; const lo = k === 0 ? 0 : I.B[k - 1] + 2, hi = k === I.n ? cols : I.B[k + 1] - 2; return [lo, hi]; };
  T.moveBoundary = function (ed, I, k, x) {
    const d = ed.doc; const { a, b, B } = I; const [lo, hi] = T.boundaryRange(ed, I, k); x = Math.max(lo, Math.min(hi, Math.round(x * 2) / 2)); const old = B[k]; if (Math.abs(x - old) < EPS) return false;
    ed.mutate('', () => {
      const add = []; for (const r of d.rules) { if (r.axis === 'v' && Math.abs(r.col - old) < EPS && r.from <= b && r.to >= a) { if (r.from < a) add.push({ ...r, id: FZ.uid(), to: a - 1 }); if (r.to > b) add.push({ ...r, id: FZ.uid(), from: b + 1 }); r.from = Math.max(r.from, a); r.to = Math.min(r.to, b); r.col = x; }
        else if (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= I.L - EPS && r.to <= I.R + EPS) { if (Math.abs(r.from - old) < EPS) r.from = x; if (Math.abs(r.to - old) < EPS) r.to = x; } }
      d.rules.push(...add);
      for (let i = a; i <= b; i++) for (const s of d.lines[i].segs) if (Math.abs(s.col - old) < EPS) s.col = x;
      for (const f of d.fills) if (f.from <= b && f.to >= a) { const r2 = f.col + f.cols; if (Math.abs(f.col - old) < EPS) { f.col = x; f.cols = r2 - x; } else if (Math.abs(r2 - old) < EPS) f.cols = x - f.col; }
      d.fills = d.fills.filter(f => f.cols > 0); ed.normalizeSegs();
    });
    return true;
  };

  /* 表の列の境をまとめて付け替える（境の数は同じ。NB[q] は元の B[q] の新しい位置）。縦罫・横罫の端・セルの段・網を一緒に */
  T.remap = function (d, I, NB) { const { a, b, B } = I; const map = x => { const q = B.findIndex(y => Math.abs(y - x) < EPS); if (q >= 0) return NB[q]; for (let k = 0; k + 1 < B.length; k++) if (x > B[k] && x < B[k + 1]) return Math.round((NB[k] + (x - B[k]) * (NB[k + 1] - NB[k]) / (B[k + 1] - B[k])) * 2) / 2; return x; };
    const add = []; for (const r of d.rules) { if (r.axis === 'v' && r.from <= b && r.to >= a && r.col >= I.L - EPS && r.col <= I.R + EPS) { if (r.from < a) add.push({ ...r, id: FZ.uid(), to: a - 1 }); if (r.to > b) add.push({ ...r, id: FZ.uid(), from: b + 1 }); r.from = Math.max(r.from, a); r.to = Math.min(r.to, b); r.col = map(r.col); }
      else if (r.axis === 'h' && r.line >= a && r.line <= b + 1 && r.from >= I.L - EPS && r.to <= I.R + EPS) { r.from = map(r.from); r.to = map(r.to); } }
    d.rules.push(...add);
    for (let i = a; i <= b; i++) for (const sg of d.lines[i].segs) if (sg.col >= I.L - EPS && sg.col < I.R - EPS) sg.col = map(sg.col);
    for (const f of d.fills) if (f.from <= b && f.to >= a && f.col >= I.L - EPS && f.col + f.cols <= I.R + EPS) { const x1 = map(f.col), x2 = map(f.col + f.cols); f.col = x1; f.cols = x2 - x1; } };
  /* 表の左端を、直前の文の左端（行頭の字・印の桁）に揃える（Markdown を開いた・貼ったとき）。右端はそのまま、列の幅は比で縮める。lay は文書の組版 */
  T.alignToText = function (d, lay) { let n = 0; const ed = { doc: d };
    for (let i = 0; i < d.lines.length; i++) { if (!FZ.inTable(d, i) || (i > 0 && FZ.inTable(d, i - 1))) continue; const I = info(ed, i); if (!I) continue;
      let j = i - 1; while (j >= 0 && !d.lines[j].segs.some(g => g.text.trim())) j--; if (j < 0 || FZ.inTable(d, j)) continue; const a0 = d.lines[j].attrs; if (a0.figure || a0.toc || a0.hr || a0.style === 'title') continue;
      const lm = lay.lineMap[j]; const row = lm && lm.segs[0] && lm.segs[0].rows[0]; if (!row || !row.glyphs || !row.glyphs.length) continue;
      const x = Math.round(Math.min(...row.glyphs.map(g => g.col)) * 2) / 2 - (row.left || 0) + I.L; if (!(x > I.L + 0.25) || x > ((lay.geo && (lay.geo.bodyCols || lay.geo.cols)) || d.format.cols) * 0.5) continue;
      const W = (lay.geo && (lay.geo.bodyCols || lay.geo.cols)) || d.format.cols; const dx = x - I.L; let NB;
      if (I.R + dx <= W + EPS) NB = I.B.map(c => c + dx); /* 入るならそのまま右へずらす */
      else { const k = (W - x) / (I.R - I.L); NB = I.B.map(c => Math.round((x + (c - I.L) * k) * 2) / 2); NB[NB.length - 1] = W; } /* はみ出すなら幅を比で縮める */ let ok = true; for (let q = 1; q < NB.length; q++) if (NB[q] - NB[q - 1] < 1) ok = false; if (!ok) continue;
      T.remap(d, I, NB); n++; i = I.b; }
    return n; };

  /* ---------- セルの範囲 { la, lb, ca, cb }（行・列の番号） ---------- */
  T.rectOf = function (ed, p, q) { const I = info(ed, p.line); if (!I || q.line < I.a || q.line > I.b) return null; return { la: Math.min(p.line, q.line), lb: Math.max(p.line, q.line), ca: Math.min(p.col, q.col), cb: Math.max(p.col, q.col), I }; };
  /* 範囲の段（seg）を順に */
  function eachSeg(ed, R, fn) { const d = ed.doc, B = R.I.B; for (let i = R.la; i <= R.lb; i++) { const ln = d.lines[i]; ln.segs.forEach((s, k) => { if (s.col >= B[R.ca] - EPS && s.col < B[R.cb + 1] - EPS) fn(s, k, ln, i); }); } }
  T.eachSeg = eachSeg;
  T.fillCells = (ed, R, shade) => { const B = R.I.B; ed.addFill(R.la, R.lb, B[R.ca], B[R.cb + 1] - B[R.ca], shade); };
  T.alignCells = (ed, R, al) => ed.mutate('', () => eachSeg(ed, R, (s, k, ln) => { const ca = ln.attrs.cellAlign ? ln.attrs.cellAlign.slice() : ln.segs.map(() => null); while (ca.length < ln.segs.length) ca.push(null); ca[k] = al === 'left' ? null : al; ln.attrs.cellAlign = ca; if (!ca.some(Boolean)) delete ln.attrs.cellAlign; }));
  T.clearCells = (ed, R) => ed.mutate('', () => eachSeg(ed, R, s => { s.text = ''; s.marks = []; delete s.links; }));
  T.boldCells = (ed, R) => { let all = true; eachSeg(ed, R, s => { for (const m of s.marks) if (!((m | 0) & M.BOLD)) all = false; }); ed.mutate('', () => eachSeg(ed, R, s => { s.marks = s.marks.map(m => all ? (m & ~M.BOLD) : (m | M.BOLD)); })); return !all; };
  T.cellsText = (ed, R) => { const d = ed.doc, B = R.I.B, out = []; for (let i = R.la; i <= R.lb; i++) { const row = []; for (let j = R.ca; j <= R.cb; j++) { const k = segAt(d, i, B, j); const s = k >= 0 ? d.lines[i].segs[k] : null; row.push(s && Math.abs(s.col - B[j]) < EPS ? s.text : ''); } out.push(row.join('\t')); } return out.join('\n'); };

  /* ---------- 1.0.12a セルの結合・解除 ---------- */
  /* 縦罫 col の行 [i0, i1] の部分を抜く（罫は前後に分かれる） */
  function cutV(d, col, i0, i1) { const add = []; d.rules = d.rules.filter(r => { if (r.axis !== 'v' || Math.abs(r.col - col) > EPS || r.to < i0 || r.from > i1) return true; if (r.from < i0) add.push({ ...r, id: FZ.uid(), to: i0 - 1 }); if (r.to > i1) add.push({ ...r, id: FZ.uid(), from: i1 + 1 }); return false; }); d.rules.push(...add); }
  /* 横罫 line の [x0, x1] の部分を抜く */
  function cutH(d, line, x0, x1) { const add = []; d.rules = d.rules.filter(r => { if (r.axis !== 'h' || r.line !== line || r.to <= x0 + EPS || r.from >= x1 - EPS) return true; if (r.from < x0 - EPS) add.push({ ...r, id: FZ.uid(), to: x0 }); if (r.to > x1 + EPS) add.push({ ...r, id: FZ.uid(), from: x1 }); return false; }); d.rules.push(...add); }
  const vKind = (d, I) => { for (const r of d.rules) if (r.axis === 'v' && r.from <= I.b && r.to >= I.a && r.col > I.L + EPS && r.col < I.R - EPS) return r.kind; return 'thin'; };
  /* 範囲が結合を含むか（中の境の縦罫・横罫が欠けている） */
  T.hasMerge = function (ed, R) { const d = ed.doc, B = R.I.B; for (let i = R.la; i <= R.lb; i++) for (let j = R.ca + 1; j <= R.cb; j++) if (!present(d, i, B[j])) return true;
    for (let i = R.la + 1; i <= R.lb; i++) { const x0 = B[R.ca], x1 = B[R.cb + 1]; const cov = d.rules.filter(r => r.axis === 'h' && r.line === i && r.from < x1 - EPS && r.to > x0 + EPS); let c = x0; cov.sort((a, b) => a.from - b.from); for (const r of cov) { if (r.from > c + EPS) return true; c = Math.max(c, r.to); } if (c < x1 - EPS) return true; } return false; };
  /* 範囲を、かかっている結合セルの全体まで広げる（結合したセルの途中で切らない） */
  function hClosed(d, i, x0, x1) { const cov = d.rules.filter(r => r.axis === 'h' && r.line === i && r.from < x1 - EPS && r.to > x0 + EPS).sort((a, b) => a.from - b.from); let c = x0; for (const r of cov) { if (r.from > c + EPS) return false; c = Math.max(c, r.to); } return c >= x1 - EPS; }
  T.spanOf = function (ed, R) { const d = ed.doc, I = R.I, B = I.B; let { la, lb, ca, cb } = R; for (let guard = 0; guard < 200; guard++) { const k0 = [la, lb, ca, cb].join();
      for (let i = la; i <= lb; i++) { while (ca > 0 && !present(d, i, B[ca])) ca--; while (cb < I.n - 1 && !present(d, i, B[cb + 1])) cb++; }
      while (la > I.a && !hClosed(d, la, B[ca], B[cb + 1])) la--; while (lb < I.b && !hClosed(d, lb + 1, B[ca], B[cb + 1])) lb++;
      if ([la, lb, ca, cb].join() === k0) break; }
    return { ...R, la, lb, ca, cb }; };
  /* 結合：範囲の中の縦罫・横罫を抜き、行ごとにセルの字を左のセルへまとめる（縦に結合した行は、セルの中の行になる） */
  T.merge = function (ed, R) { const d = ed.doc, B = R.I.B; if (R.ca === R.cb && R.la === R.lb) return false; const x0 = B[R.ca], x1 = B[R.cb + 1];
    ed.mutate('', () => {
      for (let j = R.ca + 1; j <= R.cb; j++) cutV(d, B[j], R.la, R.lb);
      for (let i = R.la + 1; i <= R.lb; i++) cutH(d, i, x0, x1);
      for (let i = R.la; i <= R.lb; i++) { const ln = d.lines[i]; const inR = ln.segs.map((sg, k) => [sg, k]).filter(([sg]) => sg.col >= x0 - EPS && sg.col < x1 - EPS); if (inR.length < 2) continue; const [first] = inR[0];
        for (const [sg] of inR.slice(1)) { if (!sg.text) continue; if (first.text && !/\s$/.test(first.text)) { first.text += ' '; first.marks.push(first.marks.length ? first.marks[first.marks.length - 1] : 0); } first.text += sg.text; first.marks.push(...sg.marks); }
        const drop = new Set(inR.slice(1).map(([, k]) => k)); if (ln.attrs.cellAlign) ln.attrs.cellAlign = ln.attrs.cellAlign.filter((_, k) => !drop.has(k)); ln.segs = ln.segs.filter((_, k) => !drop.has(k)); }
      ed.normalizeSegs(); });
    return true; };
  /* 解除：範囲の中の境に縦罫・横罫を引き直し、欠けたセルの段を足す */
  T.unmerge = function (ed, R) { const d = ed.doc, B = R.I.B, I = R.I; const vk = vKind(d, I), hk = innerKind(d, I.a, I.b, I.L, I.R) || 'thin'; const x0 = B[R.ca], x1 = B[R.cb + 1];
    ed.mutate('', () => {
      for (let i = R.la; i <= R.lb; i++) for (let j = R.ca + 1; j <= R.cb; j++) if (!present(d, i, B[j])) d.rules.push({ id: FZ.uid(), axis: 'v', from: i, to: i, col: B[j], kind: vk });
      for (let i = R.la + 1; i <= R.lb; i++) { cutH(d, i, x0, x1); d.rules.push({ id: FZ.uid(), axis: 'h', line: i, from: x0, to: x1, kind: hk }); }
      for (let i = R.la; i <= R.lb; i++) { const ln = d.lines[i]; for (let j = R.ca; j <= R.cb; j++) if (!ln.segs.some(sg => Math.abs(sg.col - B[j]) < EPS)) { ln.segs.push(FZ.newSeg(B[j], '')); } ln.segs.sort((a, b) => a.col - b.col); if (ln.attrs.cellAlign) ln.attrs.cellAlign = null; }
      ed.coalesce(); ed.normalizeSegs(); });
    return true; };

  /* ---------- 1.0.12a 列の幅：そろえる・字に合わせる、表を動かす ---------- */
  /* 列 j の字の幅（その列だけのセルの、いちばん長い字。結合したセルは数えない） */
  function colNeed(d, I, j) { let mx = 0; for (let i = I.a; i <= I.b; i++) { const ln = d.lines[i]; const k = segAt(d, i, I.B, j); if (k < 0) continue; const sg = ln.segs[k]; if (Math.abs(sg.col - I.B[j]) > EPS) continue; if (!present(d, i, I.B[j + 1])) continue; const w = FZ.textWidth(sg.text.trim()); if (w > mx) mx = w; }
    return Math.max(2, Math.ceil((mx + 1) * 2) / 2); } /* 左右に半字ずつの空き */
  T.colNeed = colNeed;
  /* 列 [ca, cb] の幅を同じに（合計の幅は変えない） */
  T.equalize = function (ed, I, ca, cb) { if (cb <= ca) return false; const d = ed.doc, B = I.B; const tot = B[cb + 1] - B[ca], w = tot / (cb - ca + 1); const NB = B.slice(); for (let j = ca + 1; j <= cb; j++) NB[j] = Math.round((B[ca] + (j - ca) * w) * 2) / 2;
    if (NB.every((x, q) => Math.abs(x - B[q]) < EPS)) return false; ed.mutate('', () => { T.remap(d, I, NB); ed.normalizeSegs(); }); return true; };
  /* 列 [ca, cb] を字に合わせた幅に（右の列はそのまま詰める。版面からはみ出すなら比で縮める） */
  T.fit = function (ed, I, ca, cb, W) { const d = ed.doc, B = I.B; const need = []; for (let j = ca; j <= cb; j++) need.push(colNeed(d, I, j));
    const NB = B.slice(); for (let j = ca; j <= cb; j++) NB[j + 1] = NB[j] + need[j - ca]; const dx = NB[cb + 1] - B[cb + 1]; for (let q = cb + 2; q < B.length; q++) NB[q] = B[q] + dx;
    const over = NB[NB.length - 1] - W; if (over > EPS) { const span = NB[cb + 1] - NB[ca]; const k = Math.max(0.2, (span - over) / span); for (let j = ca + 1; j <= cb + 1; j++) NB[j] = Math.round((NB[ca] + (NB[j] - NB[ca] + 0) * k) * 2) / 2; const dx2 = NB[cb + 1] - B[cb + 1]; for (let q = cb + 2; q < B.length; q++) NB[q] = B[q] + dx2; }
    for (let q = 1; q < NB.length; q++) if (NB[q] - NB[q - 1] < 1) NB[q] = NB[q - 1] + 1; if (NB.every((x, q) => Math.abs(x - B[q]) < EPS)) return false;
    ed.mutate('', () => { T.remap(d, I, NB); ed.normalizeSegs(); }); return true; };
  /* 表を左右に dx 字動かす（版面 [0, W] の中で） */
  T.shift = function (ed, I, dx, W) { dx = Math.max(-I.L, Math.min(W - I.R, Math.round(dx * 2) / 2)); if (Math.abs(dx) < EPS) return false; const d = ed.doc;
    ed.mutate('', () => { T.remap(d, I, I.B.map(c => c + dx)); ed.normalizeSegs(); }); return true; };
  /* 表を上下に動かす：上に空の行を足す（dy>0）・上の空の行を詰める（dy<0） */
  T.shiftV = function (ed, I, dy) { const d = ed.doc; const blank = i => i >= 0 && !FZ.inTable(d, i) && d.lines[i].segs.every(g => !g.text) && !d.lines[i].attrs.style && !d.lines[i].attrs.list && !(d.lines[i].attrs.figs || []).length && !d.rules.some(r => (r.axis === 'h' && r.line === i) || (r.axis === 'v' && r.from <= i && r.to >= i));
    if (dy > 0) { ed.mutate('', () => { for (let k = 0; k < dy; k++) ed.insertLine(I.a, FZ.newLine()); ed.caret.line += dy; }); return true; }
    let n = 0; ed.mutate('', () => { for (let k = 0; k < -dy && blank(I.a - 1 - n * 0); k++) { ed.removeLine(I.a - 1); I = { ...I, a: I.a - 1, b: I.b - 1 }; ed.caret.line--; n++; } }); return n > 0; };

  /* ---------- 1.0.15d（B-8）数の列・合計の行・表へ流し込む ----------
     数：「1,234」「１２３」「12.5」「△300」「▲300」「-300」「45%」「1,200千円」「3件」「¥500」など。「－」「—」だけのセルは空とみなす。
     数の列：見出しの行（1 行目に数でない字があれば見出し）と合計の行を除き、字のあるセルがどれも数の列。合計は左端の列（名前の列）と「番号・年度」などの列を除く。
     合計の行（attrs.sumRow、原本は [合計行]）：上の行の数を足した値を、表を直すたびに同じ取消の単位の中で書き直す（ed.onMutate）。単位・桁区切り・小数の桁・全角・△ は列に合わせる。 */
  const z2h = s => s.replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0)).replace(/，/g, ',').replace(/．/g, '.').replace(/[－−‐]/g, '-').replace(/％/g, '%').replace(/＄/g, '$').replace(/￥/g, '¥');
  const UNITS = new Set(['', '%', '円', '千円', '万円', '百万円', '億円', '兆円', 'ドル', '人', '名', '件', '個', '本', '台', '回', '時間', '分', '日', 'か月', 'ヶ月', 'カ月', '箇所', 'か所', '倍', '点', '社', '校', '戸', '世帯', '団体', '施設', '機関', 't', 'kg', 'g', 'km', 'm', '㎡', 'ha', '人日', '人月', '頁', 'ページ', '枚', '冊', '部', '字', '件数']);
  const DASH = /^[-－—―‐–ー…]$/, NOSUM = /^(No\.?|NO\.?|№|番号|項番|通番|整理番号|順位|順番|#|年|年度|月|日|コード|ID)$/i;
  function parseNum(t) { const raw = String(t).trim(); if (!raw) return null; let s = z2h(raw).replace(/[\s　]/g, ''); let neg = '';
    if (/^[△▲-]/.test(s)) { neg = s[0]; s = s.slice(1); } const m = s.match(/^([¥$]?)((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)(.*)$/); if (!m || !UNITS.has(m[3])) return null;
    const v = +m[2].replace(/,/g, ''); if (!Number.isFinite(v)) return null;
    return { v: neg ? -v : v, dec: (m[2].split('.')[1] || '').length, comma: m[2].includes(','), pre: m[1], unit: m[3], full: /[０-９]/.test(raw), neg, plain: /^-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$/.test(raw) }; }
  function fmtNum(v, F) { const neg = v < -1e-12; let s = Math.abs(v).toFixed(F.dec | 0); if (F.comma) { const [i, d] = s.split('.'); s = i.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (d ? '.' + d : ''); }
    let sg = neg ? (F.neg || '△') : ''; if (F.full) { s = s.replace(/[0-9]/g, c => String.fromCharCode(c.charCodeAt(0) + 0xFEE0)).replace(/,/g, '，').replace(/\./g, '．'); if (sg === '-') sg = '－'; } return sg + (F.pre || '') + s + (F.unit || ''); }
  T.parseNum = parseNum; T.fmtNum = fmtNum;
  /* 列 j のセル（無い・結合で隠れたなら null） */
  function cellAt(d, i, B, j) { const k = segAt(d, i, B, j); const s = k >= 0 ? d.lines[i].segs[k] : null; return s && Math.abs(s.col - B[j]) < EPS ? { s, k, t: s.text } : null; }
  /* 表 [a,b] の数の列。all：右揃え用（左端・番号の列も） */
  function numCols(d, a, b, B, all) { const n = B.length - 1; const rows = []; for (let i = a; i <= b; i++) if (!d.lines[i].attrs.sumRow) rows.push(i);
    const kind = (i, j) => { const c = cellAt(d, i, B, j); if (!c) return 'none'; const t = c.t.trim(); if (!t || DASH.test(t)) return 'blank'; return parseNum(t) ? 'num' : 'text'; };
    const head = rows.length > 1 && [...Array(n).keys()].some(j => kind(rows[0], j) === 'text') ? 1 : 0; const body = rows.slice(head); const cols = [];
    for (let j = all ? 0 : 1; j < n; j++) { const hc = head ? cellAt(d, rows[0], B, j) : null; if (!all && hc && NOSUM.test(hc.t.trim())) continue;
      const ps = []; let ok = true; for (const i of body) { const k = kind(i, j); if (k === 'text') { ok = false; break; } if (k === 'num') ps.push(parseNum(cellAt(d, i, B, j).t)); }
      if (!ok || !ps.length) continue; const units = new Set(ps.map(p => p.unit)), pres = new Set(ps.map(p => p.pre));
      const F = { dec: Math.max(...ps.map(p => p.dec)), comma: ps.some(p => p.comma), unit: units.size === 1 ? ps[0].unit : '', pre: pres.size === 1 ? ps[0].pre : '', full: ps.filter(p => p.full).length * 2 > ps.length, neg: (ps.find(p => p.neg) || {}).neg || '' };
      const pct = ps.some(p => p.unit === '%'), share = hc && /構成比|割合|シェア|内訳/.test(hc.t); /* 率（%）は足さない（合計の行の率は手で。構成比・割合は足す） */
      cols.push({ j, F, mixed: units.size > 1 || pres.size > 1, rate: pct && !share, plain: ps.every(p => p.plain) && body.every(i => kind(i, j) === 'num') }); }
    return { cols, head, rows, body }; }
  T.numCols = numCols;
  /* 合計の行を書き直す。変えたセルの数を返す（caret：変えたセルの中なら字の数に収める） */
  function syncTable(d, a, b, caret) { const I = info({ doc: d }, a); if (!I) return 0; const B = I.B; const P = numCols(d, a, b, B); let n = 0;
    for (let i = a; i <= b; i++) { const ln = d.lines[i]; if (!ln.attrs.sumRow) continue; const above = P.body.filter(r => r < i);
      for (const C of P.cols) { if (C.rate) continue; let sum = 0, any = false; if (C.mixed) { const c0 = cellAt(d, i, B, C.j); if (c0 && c0.t && parseNum(c0.t)) { c0.s.text = ''; c0.s.marks = []; n++; } continue; } /* 単位がまちまち：足せない（前の値を残さない） */ for (const r of above) { const c = cellAt(d, r, B, C.j); const p = c && parseNum(c.t); if (p) { sum += p.v; any = true; } }
        const val = any ? fmtNum(sum, C.F) : ''; let c = cellAt(d, i, B, C.j);
        if (!c) { if (!present(d, i, B[C.j])) continue; /* 結合したセル */ const cs = caret && caret.line === i ? ln.segs[caret.seg] : null; const s = FZ.newSeg(B[C.j], ''); ln.segs.push(s); ln.segs.sort((x, y) => x.col - y.col); if (cs) caret.seg = ln.segs.indexOf(cs); if (ln.attrs.cellAlign) { const ca = ln.attrs.cellAlign; ca.splice(ln.segs.indexOf(s), 0, null); } c = { s, k: ln.segs.indexOf(s), t: '' }; }
        if (c.t === val) continue; const m0 = c.s.marks && c.s.marks.length ? c.s.marks[0] | 0 : 0; c.s.text = val; c.s.marks = FZ.marksFor(val, m0); delete c.s.links; n++;
        if (caret && caret.line === i && caret.seg === c.k && caret.off > val.length) caret.off = val.length; } }
    return n; }
  T.sumSync = function (d, caret) { let n = 0; const seen = new Set();
    for (let i = 0; i < d.lines.length; i++) { if (!d.lines[i].attrs.sumRow) continue; if (!FZ.inTable(d, i)) { delete d.lines[i].attrs.sumRow; continue; }
      const rg = FZ.tableRange({ doc: d }, i); if (seen.has(rg[0])) continue; seen.add(rg[0]); n += syncTable(d, rg[0], rg[1], caret); }
    return n; };
  T.sumRowOf = (d, I) => { for (let i = I.b; i >= I.a; i--) if (d.lines[i].attrs.sumRow) return i; return -1; };
  /* 合計の行を足す（あれば外す：字は残してただの行に）。'add' | 'del' | 'none'（足せる数の列が無い）| false（表の外） */
  T.toggleSum = function (ed) { const I = info(ed); if (!I) return false; const d = ed.doc; const { a, b } = I;
    if (T.sumRowOf(d, I) >= 0) { ed.mutate('', () => { for (let i = a; i <= b; i++) delete d.lines[i].attrs.sumRow; }); return 'del'; }
    const P = numCols(d, a, b, I.B); if (!P.cols.some(c => !c.mixed && !c.rate)) return 'none';
    ed.mutate('', () => { const c = ed.caret; c.line = b; c.seg = 0; c.off = 0; ed.anchor = null; T.insertRow(ed, true, { inMutate: true }); const nl = d.lines[c.line]; nl.attrs.sumRow = true;
      const I2 = info(ed); const s0 = I2 && cellAt(d, c.line, I2.B, 0); if (s0) { s0.s.text = '合計'; s0.s.marks = FZ.marksFor('合計', 0); } /* 罫は表の様式のまま（二重線にすると様式が「独自」になる） */
      T.sumSync(d, c); c.off = 0; });
    return 'add'; };
  /* 数の列を右揃えに（もう右揃えなら左に戻す）。見出しの行は変えない。戻り値：揃えた列の数（戻したら負、無ければ 0） */
  T.numRight = function (ed) { const I = info(ed); if (!I) return false; const d = ed.doc, { a, b, B } = I; const P = numCols(d, a, b, B, true); if (!P.cols.length) return 0;
    const cells = []; for (const C of P.cols) for (let i = a; i <= b; i++) { if (P.head && i === P.rows[0]) continue; const c = cellAt(d, i, B, C.j); if (c) cells.push([i, c.k]); }
    const al = (i, k) => (d.lines[i].attrs.cellAlign || [])[k] || null; const allR = cells.every(([i, k]) => al(i, k) === 'right');
    ed.mutate('', () => { for (const [i, k] of cells) { const ln = d.lines[i]; const ca = ln.attrs.cellAlign ? ln.attrs.cellAlign.slice() : ln.segs.map(() => null); while (ca.length < ln.segs.length) ca.push(null); ca[k] = allR ? null : 'right'; ln.attrs.cellAlign = ca; if (!ca.some(Boolean)) delete ln.attrs.cellAlign; } });
    return allR ? -P.cols.length : P.cols.length; };
  /* 表へ流し込む：セル（at = { line, j }、無ければカーソルのセル）を左上に、rows（文字の 2 次元）をセルへ。行が足りなければ足す（合計の行の上に）。列ははみ出た分を捨てる */
  T.pasteInto = function (ed, rows, at) { const I0 = info(ed); if (!I0) return null; const d = ed.doc; const i0 = at ? at.line : ed.caret.line, j0 = at ? at.j : T.colOf(ed, I0); const res = { rows: rows.length, cols: 0, cut: 0, added: 0 };
    ed.mutate('', () => { const c = ed.caret; const targets = []; let i = i0;
      while (targets.length < rows.length) { const I = info(ed, i0); if (!I) break;
        if (i <= I.b && !d.lines[i].attrs.sumRow) { targets.push(i++); continue; }
        if (i <= I.b) { c.line = i; c.seg = 0; c.off = 0; T.insertRow(ed, false, { inMutate: true }); } else { c.line = I.b; c.seg = 0; c.off = 0; T.insertRow(ed, true, { inMutate: true }); i = I.b + 1; }
        targets.push(i++); res.added++; }
      const I = info(ed, i0);
      rows.forEach((r, ri) => { const li = targets[ri]; if (li == null) return; const ln = d.lines[li]; r.forEach((v, ci) => { const j = j0 + ci; if (j >= I.n) { res.cut++; return; } let cc = cellAt(d, li, I.B, j);
          if (!cc) { if (j > 0 && !present(d, li, I.B[j])) { res.cut++; return; } const s = FZ.newSeg(I.B[j], ''); ln.segs.push(s); ln.segs.sort((x, y) => x.col - y.col); if (ln.attrs.cellAlign) ln.attrs.cellAlign.splice(ln.segs.indexOf(s), 0, null); cc = { s }; }
          const t = String(v).replace(/[\r\n]+/g, ' '); cc.s.text = t; cc.s.marks = FZ.marksFor(t, 0); delete cc.s.links; res.cols = Math.max(res.cols, ci + 1); }); });
      const k = segAt(d, i0, I.B, j0); c.line = i0; c.seg = Math.max(0, k); c.off = 0; c.vcol = null; ed.anchor = null; });
    return res; };
  /* Word の写し：合計の行の数の列を =SUM(C2:C9) の式に（結合の無い表で、上のセルがどれも素の数のときだけ。Word で F9 を押すと Word が計算し直す） */
  T.sumFields = function (d, a, b, grid, rows) { if (rows.some(r => r.cells.length !== grid.length - 1 || r.cells.some(c => c.vm))) return; if (!rows.some(r => d.lines[r.i].attrs.sumRow)) return;
    const P = numCols(d, a, b, grid); for (let r = 0; r < rows.length; r++) { if (!d.lines[rows[r].i].attrs.sumRow) continue; const i = rows[r].i; const above = P.body.filter(x => x < i); if (!above.length) continue;
      const r0 = above[0] - a + 1, r1 = above[above.length - 1] - a + 1; if (r1 - r0 + 1 !== above.length) continue; /* 間に合計の行がある（小計）なら式にしない */
      for (const C of P.cols) { if (C.mixed || C.rate || !C.plain || C.j > 25) continue; const L = String.fromCharCode(65 + C.j); const cell = rows[r].cells[C.j]; if (!cell || Math.abs(cell.left - grid[C.j]) > EPS) continue;
        cell.field = `=SUM(${L}${r0}:${L}${r1}) \\# "${C.F.comma ? '#,##0' : '0'}${C.F.dec ? '.' + '0'.repeat(C.F.dec) : ''}"`; } } };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
