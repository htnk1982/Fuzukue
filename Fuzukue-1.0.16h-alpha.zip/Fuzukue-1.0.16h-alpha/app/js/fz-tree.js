/* 文机 — ツリー：文書の構造（表題・見出し・箇条書き、深さ「本文まで」で本文・表・図・囲み）を節として扱う。
 * データは文書そのもの。ツリーの操作はすべて文書の行の操作（Editor.mutate の中）で、取り消しは紙面と共通。
 *   節 = { line, end, kind: 'root'|'title'|'num'|'sym'|'list'|'body'|'block', level, lv, depth, parent, children, text, block?, obj（行のオブジェクト） }
 *   lv：アウトラインの深さ（表題 0、数字見出し 1〜8、記号見出し 9〜16、箇条書き 17〜24、本文 99）。親子は lv で決まる */
(function (FZ) {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lvOf = a => a.style === 'title' ? 0 : a.style === 'num' ? 1 + (a.level | 0) : a.style === 'sym' ? 9 + (a.level | 0) : a.list ? 17 + (a.list.level | 0) : 99;
  const famOf = a => a.style === 'title' ? 'title' : a.style === 'num' ? 'num' : a.style === 'sym' ? 'sym' : a.list ? 'list' : 'body';
  const levelOf = a => a.style === 'num' || a.style === 'sym' ? (a.level | 0) : a.list ? (a.list.level | 0) : 0;
  const T = FZ.tree = {};
  /* 文（「。」「！」「？」で終わる単位。閉じ括弧と後ろの空白は前の文に付く）。[{ start, end, text }] */
  /* 文の分け方（S7）：period＝「．」も文末に、lists＝箇条書きの項目の中の文も分ける。アプリの設定（FZ.tree.sentOpts）が既定 */
  T.sentOpts = { period: false, lists: true }; /* 箇条書きの中の文も既定で分ける（文まで表示） */
  T.sentences = function (text, o = T.sentOpts) { // 括弧の中の「。」「？」では切らない（「本当か？」と問う。 は 1 文）
    const OPEN = '「『（(【〈《“‘［[', CLOSE = '」』）)】〉》”’］]', END = '。！？!?' + (o && o.period ? '．' : ''); const out = []; let st = 0, depth = 0;
    const push = e => { let e2 = e; while (e2 < text.length && (text[e2] === ' ' || text[e2] === '　')) e2++; const t = text.slice(st, e).trim(); if (t) out.push({ start: st, end: e2, text: text.slice(st, e) }); st = e2; };
    for (let i = 0; i < text.length; i++) { const c = text[i]; if (OPEN.includes(c)) depth++; else if (CLOSE.includes(c)) depth = Math.max(0, depth - 1); else if (depth === 0 && END.includes(c)) { let e = i + 1; while (e < text.length && END.includes(text[e])) e++; i = e - 1; push(e); } }
    if (st < text.length && text.slice(st).trim()) out.push({ start: st, end: text.length, text: text.slice(st).replace(/[ 　]+$/, '') });
    return out; };
  const SKEY = new WeakMap(); const skey = (ln, k) => { let a = SKEY.get(ln); if (!a) SKEY.set(ln, a = []); return a[k] || (a[k] = { sent: k }); }; // 文の節の名札（行と番号で決まる。描き直しても同じ）
  T.sentKey = skey;
  const lineText = (doc, ln) => ln.segs.map(s => s.text).join(' ').replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕').replace(/\s+$/, '');

  /* 文書 → ツリー。opts.body：本文・表・図・囲みも節に。opts.figs：図表（図版・表・流れ図）は本文を出さなくても節に（名前だけ。図版は kind 'fig'、行の節とは別に figs に）。opts.title：根の名前 */
  T.build = function (doc, opts = {}) {
    const lines = doc.lines, N = lines.length; const withBody = !!opts.body;
    const root = { root: true, kind: 'root', line: -1, end: N - 1, lv: -1, level: 0, depth: 0, parent: null, children: [], text: opts.title || '文書', obj: null };
    const nodes = [], figs = [], sents = [], open = [root]; const withSent = !!opts.sentences; const art = new Map(); const withFigs = !!opts.figs;
    const figLabel = opts.figLabel || (fg => fg.kind + (fg.title ? '　' + fg.title : ''));
    const addFigs = (a0, b0) => { if (!withFigs) return; for (let k = a0; k <= b0; k++) for (const fg of lines[k].attrs.figs || []) { const parent = open[open.length - 1]; const n = { kind: 'fig', fig: fg, line: k, end: k, lv: 99, level: 0, depth: parent.depth + 1, parent, children: [], text: figLabel(fg), obj: lines[k] }; parent.children.push(n); figs.push(n); } };
    if (FZ.articleMatch) for (let i = 0; i < N;) { const m = FZ.articleMatch(doc, i); if (m) { art.set(i, m.b); i = m.b + 1; } else i++; }
    const close = (n, at) => { n.end = at - 1; };
    let lastN = null, lastL = -9; /* 段落・項目の中の改行（attrs.join）：直前の行の節に含める（節にしない） */
    for (let i = 0; i < N; i++) {
      const ln = lines[i], a = ln.attrs; let block = null, bEnd = i;
      if (a.join && lastN && lastL === i - 1 && !a.style && !FZ.inTable(doc, i) && !a.figure && !a.toc && !a.hr) { (lastN.joins = lastN.joins || []).push(ln); if (lastN.kind === 'body') lastN.end = i; const t = lineText(doc, ln); if (t) lastN.text += ' ' + t; lastL = i; addFigs(i, i); continue; }
      if (art.has(i)) { block = 'box'; bEnd = art.get(i); } else if (FZ.inTable(doc, i)) { block = 'table'; while (bEnd + 1 < N && FZ.inTable(doc, bEnd + 1)) bEnd++; } else if (a.figure) block = 'figure'; else if (a.toc) block = 'toc'; else if (a.hr) block = 'hr'; /* 区切り線は見た目（構造ではない）：ツリーに出さない */
      const lv = block ? 99 : lvOf(a);
      if (lv < 99) {
        while (open.length > 1 && open[open.length - 1].lv >= lv) close(open.pop(), i);
        const parent = open[open.length - 1]; const n = { kind: famOf(a), line: i, end: N - 1, lv, level: levelOf(a), depth: parent.depth + 1, parent, children: [], text: lineText(doc, ln), obj: ln };
        parent.children.push(n); nodes.push(n); open.push(n);
        lastN = n.kind === 'list' ? n : null; lastL = i;
        addFigs(i, i);
      } else {
        const blank = (!block && ln.segs.every(s => !s.text.trim())) || block === 'hr';
        if (!blank) while (open.length > 1 && open[open.length - 1].kind === 'list') close(open.pop(), i); // 箇条書きの節は箇条書きでない行で終わる
        if (!blank && (withBody || (withFigs && (block === 'table' || block === 'figure')))) { const parent = open[open.length - 1];
          const text = block === 'table' ? '［表］' + lines[i].segs.map(s => s.text.trim()).filter(Boolean).join('・') : block === 'box' ? '［囲み］' + lineText(doc, lines[i]) : block === 'figure' ? '［流れ図］' + ((a.figure.boxes || []).slice(0, 3).map(b => b.text).filter(Boolean).join('・')) : block === 'toc' ? '［目次］' : block === 'hr' ? '［区切り線］' : lineText(doc, ln);
          const n = { kind: block ? 'block' : 'body', block, line: i, end: bEnd, lv: 99, level: 0, depth: parent.depth + 1, parent, children: [], text, obj: ln }; parent.children.push(n); nodes.push(n);
          lastN = block ? null : n; lastL = i; }
        else if (!blank) lastN = null;
        addFigs(i, bEnd); i = bEnd;
      }
    }
    for (const n of open.slice(1)) n.end = N - 1;
    /* 文の節：段落（本文）と、設定で箇条書きの項目も。改行（join）の行の文も同じ枠に。文が 2 つ以上なら枠（para） */
    if (withSent) for (const n of nodes) { if (n.kind !== 'body' && !(n.kind === 'list' && T.sentOpts.lists)) continue; const ls = [n.obj, ...(n.joins || [])]; if (ls.some(l => l.segs.length !== 1)) continue;
      const out = []; ls.forEach((l, q) => { const li = n.line + q; T.sentences(l.segs[0].text).forEach((x, k) => out.push({ kind: 'sent', si: k, sStart: x.start, sEnd: x.end, key: skey(l, k), line: li, end: li, lv: 100, level: 0, depth: n.depth + 1, parent: n, children: [], text: x.text.replace(/[\u{F0000}-\u{FFFFD}]/gu, '〔図〕'), raw: x.text, obj: l })); });
      if (out.length >= 2) { n.para = true; n.children = [...out, ...n.children]; sents.push(...out); } }
    /* 子の項目を持つ項目も文に分ける：文は項目の枠の中、子の項目は枠の下（ツリーの描き方で分ける） */
    // 箇条書きの節が空行で終わっていても、次の行の前までを範囲とする（空行は前の節に付く）
    const byObj = new Map(); for (const n of nodes) { byObj.set(n.obj, n); for (const j of n.joins || []) byObj.set(j, n); }
    return { root, nodes, figs, sents, byObj, byFig: new Map(figs.map(n => [n.fig, n])) };
  };
  /* 行 i を含むいちばん深い節（無ければ根） */
  T.nodeAt = function (tree, i) { let best = tree.root; for (const n of tree.nodes) if (n.line <= i && n.end >= i && n.depth >= best.depth) best = n; return best; };
  T.isAncestor = (a, b) => { for (let p = b.parent; p; p = p.parent) if (p === a) return true; return false; };

  /* 子の種類：子があれば最後の子と同じ、無ければ 表題・根→数字見出し 1、数字見出し n→n+1、記号見出し→箇条書き、箇条書き n→n+1 */
  T.childType = function (n) {
    if (n.kind === 'fig' || n.kind === 'block' || n.kind === 'body') return null;
    const kids = n.children.filter(c => c.kind !== 'body' && c.kind !== 'block' && c.kind !== 'fig' && c.kind !== 'sent'); if (kids.length) { const c = kids[kids.length - 1]; return { kind: c.kind, level: c.level }; }
    if (n.kind === 'root' || n.kind === 'title') return { kind: 'num', level: 0 };
    if (n.kind === 'num') return n.level < 7 ? { kind: 'num', level: n.level + 1 } : { kind: 'list', level: 0 };
    if (n.kind === 'sym') return { kind: 'list', level: 0 };
    if (n.kind === 'list') return { kind: 'list', level: Math.min(7, n.level + 1) };
    return null;
  };
  T.siblingType = n => n.kind === 'block' || n.kind === 'root' || n.kind === 'fig' ? { kind: 'body', level: 0 } : { kind: n.kind, level: n.level };
  const attrsFor = (base, t) => { const a = { ...base }; delete a.style; delete a.level; delete a.list; delete a.indent; delete a.hanging; delete a.deco; delete a.restart;
    if (t.kind === 'title') a.style = 'title'; else if (t.kind === 'num' || t.kind === 'sym') { a.style = t.kind; a.level = clamp(t.level, 0, 7); } else if (t.kind === 'list') a.list = { level: clamp(t.level, 0, 7) }; return a; };
  /* 種類を変える：行 [a,b]（節の範囲）の先頭を to に。範囲の中の同じ系統の行はレベルの差を保って、違う系統は決まりに合わせて付け替える */
  T.retype = function (ed, a, b, to) {
    const L = ed.doc.lines; const head = L[a].attrs; const from = { kind: famOf(head), level: levelOf(head) }; if (from.kind === to.kind && from.level === to.level) return;
    L[a].attrs = { ...attrsFor(head, to), ...(head.list && head.list.kind && to.kind === 'list' ? { list: { level: clamp(to.level, 0, 7), kind: head.list.kind } } : {}) };
    let minList = Infinity; for (let i = a + 1; i <= b; i++) { const x = L[i].attrs; if (x.list) minList = Math.min(minList, x.list.level | 0); }
    const keepKind = (x, nx) => { if (x.list && x.list.kind && nx.list) nx.list.kind = x.list.kind; return nx; };
    for (let i = a + 1; i <= b; i++) { const x = L[i].attrs, f = famOf(x); if (f === 'body' || f === 'title') continue; const lvx = levelOf(x);
      if (from.kind === 'list' && f === 'list' && to.kind !== 'list') { L[i].attrs = keepKind(x, attrsFor(x, { kind: 'list', level: lvx - (minList === Infinity ? 0 : minList) })); continue; } // 箇条書きを見出しにしたら、下の箇条書きは箇条書きのまま 0 から
      if (f === from.kind && (to.kind === 'num' || to.kind === 'sym' || to.kind === 'list')) { L[i].attrs = keepKind(x, attrsFor(x, { kind: to.kind, level: to.level + (lvx - from.level) })); continue; }
      if (to.kind === 'list' && (f === 'num' || f === 'sym')) { L[i].attrs = attrsFor(x, { kind: 'list', level: to.level + 1 + lvx }); continue; } // 箇条書きの下に見出しは置けない
    }
  };
  /* 行 k に行を足す（その位置で終わる表・囲みの下辺の罫は、上の塊に付けたまま） */
  T.insertAt = function (ed, k, line) {
    const d = ed.doc; const bottoms = d.rules.filter(r => r.axis === 'h' && r.line === k && k > 0 && d.rules.some(v => v.axis === 'v' && v.to === k - 1 && v.col >= r.from - 1e-6 && v.col <= r.to + 1e-6));
    ed.insertLine(k, line); for (const r of bottoms) r.line = k;
  };
  /* 行 [a,b] を消す（その範囲の表・囲みの罫と網も一緒に） */
  T.removeRange = function (ed, a, b) {
    const d = ed.doc; const inV = d.rules.filter(r => r.axis === 'v' && r.from >= a && r.to <= b);
    const owned = new Set(d.rules.filter(r => r.axis === 'h' && ((r.line > a && r.line <= b) || (r.line === a && inV.some(v => v.from === a && v.col >= r.from - 1e-6 && v.col <= r.to + 1e-6)) || (r.line === b + 1 && inV.some(v => v.to === b && v.col >= r.from - 1e-6 && v.col <= r.to + 1e-6)))).map(r => r.id));
    d.rules = d.rules.filter(r => !owned.has(r.id));
    if (b - a + 1 >= d.lines.length) { d.lines = [FZ.newLine()]; d.rules = []; d.fills = []; return; }
    for (let i = b; i >= a; i--) ed.removeLine(i);
  };

  /* ---------- 操作（ed.mutate の中で呼ぶ。新しく選ぶ行のオブジェクトを返す） ---------- */
  /* 足す：rel = 'after'（弟）| 'before'（兄）| 'child'（末の子） */
  T.add = function (ed, n, rel) {
    let t, at; if (rel === 'child') { t = T.childType(n); if (!t) return null; at = n.root ? ed.doc.lines.length : n.end + 1; } else { if (n.root) return null; t = T.siblingType(n); at = rel === 'before' ? n.line : n.end + 1; }
    const ln = FZ.newLine(''); ln.attrs = attrsFor({}, t);
    if (n.root && ed.doc.lines.length === 1 && !ed.doc.lines[0].segs[0].text && !Object.keys(ed.doc.lines[0].attrs).length) { ed.doc.lines[0].attrs = ln.attrs; return ed.doc.lines[0]; } // 白紙：最初の行を使う
    T.insertAt(ed, at, ln); return ln;
  };
  /* 消す：節（子と本文ごと） */
  T.remove = function (ed, list) { const rs = list.filter(n => !n.root && !list.some(m => m !== n && T.isAncestor(m, n))).sort((p, q) => q.line - p.line); for (const n of rs) T.removeRange(ed, n.line, n.end); };
  /* 動かす：list の節を target の rel（'before'|'after'|'child'）へ。種類は落ちた位置に合わせる */
  T.move = function (ed, tree, list, target, rel) {
    const movers = list.filter(n => !n.root && n !== target && !T.isAncestor(n, target) && !list.some(m => m !== n && T.isAncestor(m, n))).sort((p, q) => p.line - q.line); if (!movers.length) return false;
    if (target.root && rel !== 'child') return false;
    if (movers.some(n => n.kind === 'fig') || target.kind === 'fig') return false; // 図表は付いている行と動く
    const kids = target.children.filter(c => c.kind !== 'body' && c.kind !== 'block' && c.kind !== 'fig' && c.kind !== 'sent');
    const typeFor = n => { if (rel !== 'child') return T.siblingType(target);
      if ((n.kind === 'num' || n.kind === 'sym') && target.kind !== 'list') { const hk = kids.filter(c => c.kind === 'num' || c.kind === 'sym'); if (hk.length) { const c = hk[hk.length - 1]; return { kind: c.kind, level: c.level }; } if (target.kind === 'num') return { kind: 'num', level: Math.min(7, target.level + 1) }; if (target.kind === 'sym') return { kind: 'sym', level: Math.min(7, target.level + 1) }; return { kind: n.kind, level: 0 }; } /* 見出しは見出しのまま 1 段下へ（子が箇条書きでも） */
      if (kids.length) return T.childType(target); if (n.kind === 'list') return target.kind === 'list' ? { kind: 'list', level: Math.min(7, target.level + 1) } : { kind: 'list', level: 0 }; return T.childType(target); }; // 子の無い節へ落とす箇条書きは箇条書きのまま
    if (rel === 'child' && !T.childType(target)) return false;
    const L = () => ed.doc.lines; const objs = movers.map(n => n.obj); const tObj = target.obj; const tEndObj = target.root ? null : L()[target.end];
    let anchorObj = rel === 'before' ? tObj : null; // この行の前に入れる（null＝after/child の位置を毎回求める）
    for (let k = 0; k < objs.length; k++) {
      const type = typeFor(movers[k]); const cur = L().indexOf(objs[k]); const tr = T.build(ed.doc, { body: true }); const node = tr.byObj.get(objs[k]) || { line: cur, end: cur }; const a = node.line, b = node.end;
      let at; if (anchorObj) at = L().indexOf(anchorObj); else if (target.root) at = L().length; else { const tn = tr.byObj.get(tObj); at = (tn ? tn.end : L().indexOf(tEndObj)) + 1; }
      if (k > 0) { const prev = tr.byObj.get(objs[k - 1]); at = prev ? prev.end + 1 : at; } // 2 つ目以降は前に動かした節の後ろへ（順を保つ）
      const na = ed.moveBlock(a, b, at); const tr2 = T.build(ed.doc, { body: true }); const moved = tr2.byObj.get(objs[k]); const mb = moved ? moved.end : na + (b - a);
      if (moved && moved.kind !== 'body' && moved.kind !== 'block') T.retype(ed, na, mb, type);
    }
    return true;
  };
  /* 兄弟の中で上・下へ */
  T.shift = function (ed, tree, n, dir) { if (n.root) return false; const sib = n.parent.children; const k = sib.indexOf(n); let j = k + dir; while (sib[j] && sib[j].kind === 'fig') j += dir; const o = sib[j]; if (!o) return false; return T.move(ed, tree, [n], o, dir < 0 ? 'before' : 'after'); };
  /* 浅く：親の弟に／深く：兄の末の子に */
  T.promote = function (ed, tree, n) { if (n.root || n.parent.root) return false; return T.move(ed, tree, [n], n.parent, 'after'); };
  T.demote = function (ed, tree, n) { if (n.root) return false; const sib = n.parent.children; const k = sib.indexOf(n); for (let j = k - 1; j >= 0; j--) { const s = sib[j]; if (s.kind !== 'body' && s.kind !== 'block' && s.kind !== 'fig' && T.childType(s)) return T.move(ed, tree, [n], s, 'child'); } return false; };
  /* 段だけを上下する（兄がいなくて「深く」で入れる先が無い、Markdown の見出しのように段が飛ぶ等）。節と、その中の同じ種類の子孫の段を delta ずつ。木の位置は変えない */
  T.levelShift = function (ed, n, delta) { const a0 = n.obj && n.obj.attrs; if (!a0) return false; const heading = a0.style === 'num' || a0.style === 'sym'; const list = !!a0.list && !heading; if (!heading && !list) return false;
    const cur = heading ? (a0.level | 0) : (a0.list.level | 0); if (cur + delta < 0 || cur + delta > 7) return false; const i0 = ed.doc.lines.indexOf(n.obj); if (i0 < 0) return false; const end = Math.max(i0, n.end != null ? n.end : i0); let any = false;
    for (let i = i0; i <= end; i++) { const a = ed.doc.lines[i].attrs; if (heading && a.style === a0.style) { a.level = Math.max(0, Math.min(7, (a.level | 0) + delta)); any = true; } else if (list && a.list && !a.style) { a.list = { ...a.list, level: Math.max(0, Math.min(7, (a.list.level | 0) + delta)) }; any = true; } }
    return any; };
  /* 段が木の位置より深いか（段を飛ばして深くしてある）：同じ種類の先祖の数より段が大きい */
  T.levelExcess = function (n) { const a0 = n.obj && n.obj.attrs; if (!a0) return 0; const heading = a0.style === 'num' || a0.style === 'sym'; if (!heading && !a0.list) return 0; let cnt = 0;
    for (let p = n.parent; p && !p.root; p = p.parent) { const a = p.obj && p.obj.attrs; if (!a) continue; if (heading ? a.style === a0.style : (!!a.list && !a.style)) cnt++; }
    return (heading ? (a0.level | 0) : (a0.list.level | 0)) - cnt; };
  /* 文字を直す：節の行の文字を置き換える（字の飾りは、行全体に共通する飾りだけ残す） */
  T.setText = function (ed, n, text) { const ln = n.obj; if (!ln || ln.segs.length !== 1) return false; const s = ln.segs[0]; if (s.text === text) return false; let m = -1; for (const x of s.marks) m &= (x | 0); if (!s.marks.length) m = 0; s.text = text; s.marks = FZ.marksFor(text, m & ~FZ.M.LINK); delete s.links; return true; };

  /* ---------- 配置：左→右（dir 'h'）・上→下（'v'）。visible(n) は描く子の配列。size(n) → { w, h } ---------- */
  T.layout = function (root, opts) {
    if (opts.dir === 'i') { // 字下げ：1 節 1 行で上から下へ。子は親の下に字下げして並ぶ（狭い幅でも読める）
      const ind = opts.indent ?? 28, gap = opts.gapSib ?? 6, vis = opts.visible, pos = new Map(); let y = 0, W = 0, prev = null, prevKids = 0, prevPar = null;
      /* tight：同じ親の続く兄弟は隙間なく辺で接し（線が 1 本になる）、親から最初の子は少し、親の違う節に移る所は gap 空ける（視覚の雑音を減らす） */
      const gapOf = (n, par) => !opts.tight ? gap : !prev ? 0 : prev === par ? Math.min(2, gap) : (prevKids === 0 && prevPar === par) ? 0 : gap;
      const walk = (n, d, par) => { if (prev) y += gapOf(n, par); const s = opts.size(n, d); pos.set(n, { w: s.w, h: s.h, depth: d, x: d * ind, y }); y += s.h; W = Math.max(W, d * ind + s.w); const kids = vis(n); prev = n; prevKids = kids.length; prevPar = par; for (const c of kids) walk(c, d + 1, n); }; walk(root, 0, null);
      return { pos, W, H: Math.max(0, y) }; }
    const dir = opts.dir === 'v' ? 'v' : 'h'; const gapD = opts.gapDepth ?? 36, gapS = opts.gapSib ?? 8; const vis = opts.visible; const pos = new Map();
    const levels = []; const walk = (n, d) => { const s = opts.size(n); pos.set(n, { w: s.w, h: s.h, depth: d, x: 0, y: 0 }); levels[d] = Math.max(levels[d] || 0, dir === 'h' ? s.w : s.h); for (const c of vis(n)) walk(c, d + 1); }; walk(root, 0);
    const off = [0]; for (let d = 1; d < levels.length; d++) off[d] = off[d - 1] + levels[d - 1] + gapD;
    const br = n => dir === 'h' ? pos.get(n).h : pos.get(n).w; const span = new Map();
    const gapBetween = (a, b) => opts.tight && span.get(a) <= br(a) + 0.5 && span.get(b) <= br(b) + 0.5 ? 0 : gapS; /* tight：子の広がりが自分の箱の幅（高さ）に収まる兄弟どうしは辺で接する */
    const measure = n => { const kids = vis(n); let t = 0; kids.forEach((c, i) => { t += measure(c) + (i ? gapBetween(kids[i - 1], c) : 0); }); const s = Math.max(br(n), t); span.set(n, s); return s; };
    measure(root);
    const place = (n, start) => { const p = pos.get(n); const s = span.get(n); const b = br(n); const kids = vis(n); let t = 0; kids.forEach((c, i) => { t += span.get(c) + (i ? gapBetween(kids[i - 1], c) : 0); });
      if (dir === 'h') { p.x = off[p.depth]; p.y = start + (s - b) / 2; } else { p.y = off[p.depth]; p.x = start + (s - b) / 2; }
      let at = start + (s - t) / 2; kids.forEach((c, i) => { if (i) at += gapBetween(kids[i - 1], c); place(c, at); at += span.get(c); }); };
    place(root, 0);
    let W = 0, H = 0; for (const p of pos.values()) { W = Math.max(W, p.x + p.w); H = Math.max(H, p.y + p.h); }
    return { pos, W, H };
  };
})(typeof globalThis !== 'undefined' ? (globalThis.FZ = globalThis.FZ || {}) : (window.FZ = window.FZ || {}));
