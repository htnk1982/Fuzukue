# Mermaid の図の見本

文机で開くと、図の種類ごとに組んだ図になる（F2→開く、または貼り付け）。Markdown に書き出すと同じ種類の Mermaid に戻る。

## 流れ図（分かれ道・戻り・端・置き場）

```mermaid
flowchart TD
  A[受付] --> B{書類はそろっている？}
  B -->|はい| C[審査]
  B -->|いいえ| D[差し戻し]
  D --> A
  C --> E([決裁])
  C --> F[(台帳)]
```

## シーケンス図

```mermaid
sequenceDiagram
  participant U as 利用者
  participant S as 窓口システム
  participant DB as データベース
  U->>S: 申請を送る
  S->>DB: 照会
  DB-->>S: 結果
  alt 不備あり
    S-->>U: 差し戻し
  else 不備なし
    S->>S: 受付番号を振る
    S-->>U: 受付完了
  end
  Note over S,DB: 夜間は一括処理
```

## ER 図

```mermaid
erDiagram
  顧客 ||--o{ 注文 : 行う
  注文 ||--|{ 明細 : 含む
  商品 ||--o{ 明細 : 載る
  顧客 {
    string 顧客ID PK
    string 氏名
  }
  注文 {
    string 注文ID PK
    date 注文日
  }
```

## マインドマップ

```mermaid
mindmap
  root((新規事業))
    市場
      規模
      成長
    顧客
      法人
      個人
    体制
```

## データフロー図（DFD）

```mermaid
graph LR
  利用者 -->|申請| P1((受付処理))
  P1 -->|記録| D1[(申請台帳)]
  P1 -->|通知| 担当課
  D1 -.-> P2((集計))
  P2 --> 管理者
```
