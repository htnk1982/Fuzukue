/* はじめに.md を作る（P19：説明・画面・試験手順をいまの仕様に揃える）。
 * 元は tools/hajime.src.md。本文のキーの書き方はメニューの表（コマンドの定義）から引くので、割り当てや帯の名前を変えても説明がずれない。
 *   {{id}}      道筋と近道（例「F5「太字」（Ctrl+B）」）
 *   {{P:id}}    道筋だけ（{{P:id|F7}} で F7 からの道筋を選ぶ）
 *   {{S:id}}    近道だけ
 *   {{A:id}}    すべての道筋と近道
 *   {{VERSION}} 版。{{FKEYS}} F キーの表（帯のタイルの名前と近道を、メニューの表から）
 * 使い方：require('./build-hajime')(info) → { text, missing }。info は build-kaisetsu が画面から集めたもの（cmds・groups・fk・msel・version） */
const fs = require('fs'); const path = require('path');
const SRC = path.resolve(__dirname, 'hajime.src.md'), OUT = path.resolve(__dirname, '../はじめに.md');
const HEAD = '<!-- 生成物：tools/hajime.src.md から tools/build-kaisetsu.js（build-hajime.js）が作る。直すときは hajime.src.md を直して作り直す -->\n';

function build(info) {
  const cmd = new Map(); for (const c of info.cmds) if (!cmd.has(c.id)) cmd.set(c.id, c);
  const missing = new Set();
  const paths = c => String(c.path || '').split(' / ').filter(Boolean);
  const ref = (kind, spec) => { const [id, fk] = spec.split('|'); const c = cmd.get(id); if (!c) { missing.add(id); return '（？' + id + '）'; }
    const P = paths(c); const p = fk ? (P.find(x => x.startsWith(fk + '「')) || P[0]) : P[0];
    if (kind === 'S') return c.keys || p || '（コマンド一覧から）';
    if (kind === 'P') return p || c.keys || '（コマンド一覧から）';
    if (kind === 'A') return [...P, c.keys].filter(Boolean).join(' / ') || '（コマンド一覧から）';
    return p ? p + (c.keys ? '（' + c.keys + '）' : '') : (c.keys || '（コマンド一覧から）'); };
  const tile = it => { if (it.msel) return (info.msel[it.msel] || it.msel) + '▾'; const c = cmd.get(it.cmd); const nm = String(it.short || it.label || '').replace(/（.*$/, '').replace(/([*_|\\])/g, '\\$1'); return nm + (c && c.keys ? '（' + c.keys.split(' / ')[0].replace(/（.*$/, '') + '）' : ''); }; /* Markdown の記号は字のまま */
  const groupCell = g => { const G = info.groups[g]; if (!G) return ''; const out = []; let cur = null;
    for (const it of G.items) { if (it.cl !== undefined && !it.cmd && !it.msel) { cur = { name: it.cl, items: [] }; out.push(cur); continue; } if (!it.cmd && !it.msel) continue; if (!cur) { cur = { name: '', items: [] }; out.push(cur); } cur.items.push(tile(it)); }
    return out.filter(x => x.items.length).map(x => (x.name ? '**' + x.name + '** ' : '') + x.items.join('・')).join('｜'); };
  const fkeys = info.fk.map(([k, label, g, id]) => { const c = cmd.get(id); return `| **${k}** | ${label} | ${g ? groupCell(g) : (c ? String(c.label).replace(/（.*$/, '') + '（右の欄）' : '')} |`; }).join('\n');
  let src = fs.readFileSync(SRC, 'utf8');
  src = src.replace(/\{\{VERSION\}\}/g, info.version).replace(/\{\{FKEYS\}\}/g, fkeys)
    .replace(/\{\{(?:([PSA]):)?([^{}]+)\}\}/g, (m, kind, spec) => ref(kind || 'K', spec));
  return { text: HEAD + src, missing: [...missing] };
}
build.write = info => { const r = build(info); fs.writeFileSync(OUT, r.text); return r; };
build.OUT = OUT; build.SRC = SRC;
/* 画面から集める（試験からも使う） */
build.collect = page => page.evaluate(() => { const M = FZ.app._menu(); const G = FZ.app.GROUPS; const groups = {}; for (const [k, g] of Object.entries(G)) groups[k] = { title: g.title, items: g.items.map(i => ({ cl: i.cl, label: i.label, short: i.short, cmd: i.cmd, msel: i.msel })) };
  const msel = {}; for (const [k, v] of Object.entries(M.MSEL)) msel[k] = v.label; return { cmds: FZ.app.cmds(), version: FZ.VERSION, groups, msel, fk: M.FK.text.map(([k, l, id]) => [k, l, M.GROUP_OF[id] || null, id]) }; });
module.exports = build;
