/* 取扱説明書.fzk を作る：tools/kaisetsu/ の各章を原本（fzk 2）に組み立て、samples/取扱説明書.fzk と app/js/fz-manual.js（画面の「取説」が開く中身）に置く。
 * 本文の {{id}} はコマンドの最初の道筋（F キーと帯の名前。例 F5「太字」。無ければ近道）、{{A:id}} はすべての道筋と近道、{{S:id}} は近道だけ。
 * キーはいまのメニューの表から引くので、割り当てを変えたら走らせ直す。付録の「全コマンド一覧」も表から作る。
 * 作った原本は画面に読み込み、読み直して同じになること・引けないキーが無いこと・すべてのコマンドが本文か付録に載ることを確かめる */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');

/* ---------- 原本の書き方 ---------- */
const escPlain = (t, cell) => { let s = String(t).replace(/\\(?=[\\<>|\[\]#])/g, '\\\\').replace(/</g, '\\<'); if (cell) s = s.replace(/\|/g, '\\|'); return s; };
const leadEsc = s => s.replace(/^([\[#|])/, '\\$1');
function makeDoc(ctx, refs) {
  const L = []; const missing = new Set(); const mentioned = new Set(); const heads = []; const cnt = [0, 0, 0]; let chap = '', sect = '';
  const badRefs = new Set();
  const head = (lv, t) => { cnt[lv - 1]++; for (let k = lv; k < 3; k++) cnt[k] = 0; const num = cnt.slice(0, lv).join('.'); if (lv === 1) { chap = t; sect = ''; } if (lv === 2) sect = t; heads.push({ lv, t, num, path: lv === 1 ? t : lv === 2 ? chap + '>' + t : chap + '>' + sect + '>' + t }); };
  /* 見出しへの参照 {{§題}}（章なら「N 章」、節なら「N.M」）。同じ題が複数あるときは「章>節」で */
  const ref = t => { if (!refs) return '§'; const hit = refs.filter(x => x.t === t || x.path === t || x.path.endsWith('>' + t) && t.includes('>')); if (hit.length !== 1) { badRefs.add(t + (hit.length ? '（' + hit.length + ' 件）' : '')); return '（？' + t + '）'; } return hit[0].lv === 1 ? hit[0].num + ' 章' : hit[0].num; };
  const key = (kind, id) => { const c = ctx.cmd.get(id); if (!c) { missing.add(id); return '（？' + id + '）'; } mentioned.add(id);
    if (kind === 'S') return c.keys || c.path.split(' / ')[0]; if (kind === 'A') return [c.path, c.keys].filter(Boolean).join(' / ') || '（メニューに無し）';
    return c.path ? c.path.split(' / ')[0] : (c.keys || '（コマンド一覧から）'); };
  /* 行内の書き方：**太字**・{{id}}・{{A:id}}・{{S:id}}・⟪原本のまま⟫。ほかは文字のまま（エスケープ） */
  const inl = (t, cell) => { const parts = String(t).split(/(⟪[^⟫]*⟫|\*\*[^*]+\*\*|\{\{§[^}]+\}\}|\{\{(?:[AS]:)?[^}]+\}\})/); let out = '';
    for (const p of parts) { if (!p) continue;
      if (p.startsWith('{{§')) { out += escPlain(ref(p.slice(3, -2)), cell); continue; }
      if (p[0] === '⟪') { out += p.slice(1, -1); continue; } // 原本の書き方をそのまま（見本の修飾）
      let m = /^\*\*([^*]+)\*\*$/.exec(p); if (m) { out += '<太字>' + inl(m[1], cell) + '</太字>'; continue; }
      m = /^\{\{(?:([AS]):)?([^}]+)\}\}$/.exec(p); if (m) { out += escPlain(key(m[1] || 'K', m[2]), cell); continue; }
      out += escPlain(p, cell); }
    return out; };
  const line = (attrs, t) => { const body = inl(t); L.push(attrs ? '[' + attrs + ']' + body : leadEsc(body)); };
  const h = {
    K: id => key('K', id),
    blank() { L.push(''); },
    raw(...ls) { if (ls.some(l => /^#(箱|レーン)/.test(l)) && L.length && L[L.length - 1] !== '') L.push(''); L.push(...ls); }, /* 図の前は 1 行空ける */
    title(t) { L.push('[表題 中央]' + t); },
    h1(t) { head(1, t); line('番号1 改頁', t); }, h1n(t) { head(1, t); line('番号1', t); }, h2(t) { head(2, t); line('番号2', t); }, h3(t) { head(3, t); line('番号3', t); },
    app(t) { line('記号1 字下げ0 改頁', t); }, app2(t) { line('記号2 字下げ1', t); }, /* 付録：位置は左端から（章の番号の位置に引きずられない） */
    s1(t) { line('記号1', t); }, s2(t) { line('記号2', t); },
    p(...ts) { for (const t of ts) line('', t); },
    center(t) { line('中央', t); }, right(t) { line('右', t); },
    ul(items, lv = 1) { for (const it of items) { if (Array.isArray(it)) h.ul(it, lv + 1); else line('項目' + lv, it); } },
    ol(items, lv = 1) { for (const it of items) { if (Array.isArray(it)) h.ol(it, lv + 1); else line('番号項目' + lv, it); } },
    arrow(t) { line('→1', t); },
    /* 表：列の境界（40 字のうち）、見出し行、行。様式は格子・見出し淡が既定 */
    table(bounds, head, rows, style = '格子 見出し淡') { if (L.length && /^\[?[^\]]*\]?\|/.test(L[L.length - 1]) && L[L.length - 1].includes('|')) L.push(''); /* 表が続くと 1 つの表に読まれるので、間に空行 */ L.push('#表 列 ' + bounds.join(',') + ' 様式 ' + style); L.push('| ' + head.map(c => '<太字>' + inl(c, true) + '</太字>').join(' | ') + ' |'); for (const r of rows) L.push('| ' + r.map(c => inl(c, true)).join(' | ') + ' |'); },
    t2(head, rows, w = 11) { h.table([0, w, 40], head, rows); },
    t3(head, rows, w1 = 10, w2 = 22) { h.table([0, w1, w2, 40], head, rows); },
    /* 囲み記事：題と本文（本文は記号の箇条書き） */
    box(title, lines) { L.push('#囲み ×' + (lines.length + 1)); L.push(leadEsc(inl(title))); for (const t of lines) L.push('[項目1]' + inl(t)); },
    note(lines) { L.push('#囲み ×' + lines.length + ' 見出しなし'); for (const t of lines) L.push('[項目1]' + inl(t)); },
    /* 原本の書き方の見本（コードの段落。字はそのまま） */
    code(lines) { for (const t of lines) L.push('[コード]' + (t ? escPlain(t) : '')); },
    toc(spec = '1-2') { L.push('[目次' + spec + ']'); },
  };
  return { h, L, missing, mentioned, heads, badRefs };
}

(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(300);
  const info = await page.evaluate(() => { localStorage.clear(); const G = FZ.app.GROUPS; const groups = {}; for (const [k, g] of Object.entries(G)) groups[k] = { title: g.title, parent: g.parent || null, items: g.items.map(i => ({ cl: i.cl, key: i.key, label: i.label, short: i.short, cmd: i.cmd, msel: i.msel })) }; return { cmds: FZ.app.cmds(), version: FZ.VERSION, groups }; });
  const cmd = new Map(); for (const c of info.cmds) if (!cmd.has(c.id)) cmd.set(c.id, c);
  const ctx = { cmd, cmds: [...cmd.values()], version: info.version, listed: new Set(), groups: info.groups };
  const dir = path.join(__dirname, 'kaisetsu'); const parts = fs.readdirSync(dir).filter(f => /^\d+.*\.js$/.test(f)).sort();
  const pass1 = makeDoc(ctx, null); for (const f of parts) require(path.join(dir, f))(pass1.h, ctx); /* 1 回目：見出しの番号を集める */
  ctx.listed = new Set();
  const { h, L, missing, mentioned, badRefs } = makeDoc(ctx, pass1.heads); for (const f of parts) require(path.join(dir, f))(h, ctx);
  if (badRefs.size) { console.error('引けない見出しの参照:', [...badRefs].join(' / ')); process.exitCode = 1; }
  if (process.env.HEADS) console.log(pass1.heads.filter(x => x.lv < 3).map(x => x.num + ' ' + x.t).join('\n'));
  const head = ['#fzk 2', '題名: 文机 取扱説明書', '用紙: A4 縦', '文字数: 40', '行数: 36', '余白: 20 20 20 20', '柱上: 文机　取扱説明書', '柱下: {page} / {pages}', '柱行: 1 1', '書体: 明朝', '明朝書体: BIZ UDMincho', 'ゴシック書体: BIZ UDGothic',
    '番号体系: 1. 1.1 1.1 1.1 （1） ① a） ⅰ）', '題: 3', '記号見出し: ■ ◆ ● ○ ▲ △ ◇ □', '箇条書き: ・ ‐ ◦ ▪ ▫ ‣ ⁃ ∙', '戻り空き: あり', '表題の後空き: あり', '表の前空き: あり', '本文位置: 見出しの頭から1字', '---'];
  const text = head.join('\n') + '\n' + L.join('\n') + '\n';
  if (missing.size) { console.error('引けないコマンド:', [...missing].join(' ')); process.exitCode = 1; }
  const out = path.resolve(__dirname, '../samples/取扱説明書.fzk'); fs.writeFileSync(out, text); fs.writeFileSync(path.resolve(__dirname, '../app/js/fz-manual.js'), '/* 生成物（tools/build-kaisetsu.js）：取扱説明書の原本。画面の「取説」が開く */\nFZ.MANUAL_FZK = ' + JSON.stringify(text) + ';\n');
  /* 確かめる：読み込み → 組版 → 読み直し */
  const r = await page.evaluate(async s => { await FZ.app.loadText(s, '取扱説明書.fzk', null); await new Promise(r => setTimeout(r, 50)); const ed = FZ.app.ed; while (!ed.layoutDone) ed.continueLayout(500); const back = FZ.serialize(ed.doc);
    const raw = ed.doc.lines.filter(l => l.attrs.raw).map(l => l.segs.map(g => g.text).join('')).slice(0, 10);
    const unk = ed.doc.lines.filter(l => l.attrs.unk && l.attrs.unk.length).map(l => l.attrs.unk.join(' ')).slice(0, 10);
    return { lines: ed.doc.lines.length, pages: ed.lay.pages ? ed.lay.pages.length : null, same: back === s, back, raw, unk }; }, text);
  if (!r.same) { fs.writeFileSync(path.join(require('os').tmpdir(), 'kaisetsu-back.fzk'), r.back); const a = text.split('\n'), b = r.back.split('\n'); let k = 0; while (k < a.length && a[k] === b[k]) k++; console.error('読み直しが違う（' + (k + 1) + ' 行目）\n  書いた: ' + a[k] + '\n  読んだ: ' + b[k]); process.exitCode = 1; }
  if (r.raw.length) console.error('指示行として読めない行:', r.raw);
  if (r.unk.length) console.error('知らない属性:', r.unk);
  const notIn = ctx.cmds.filter(c => !mentioned.has(c.id) && !ctx.listed.has(c.id)).map(c => c.id);
  if (notIn.length) console.error('どこにも載らないコマンド:', notIn.join(' '));
  if (errors.length) { console.error('画面のエラー:', errors); process.exitCode = 1; }
  console.log('取扱説明書.fzk', text.split('\n').length, '行', r.pages, '頁', '本文で触れたコマンド', mentioned.size, '/', ctx.cmds.length);
  /* はじめに.md（P19）：tools/hajime.src.md のキーの書き方をメニューの表から引いて作る */
  require('./build-prompts')(); /* 1.0.14a docs の指示文（fz-pufu.js から） */
  const hj = require('./build-hajime'); const hr = hj.write(await hj.collect(page)); if (hr.missing.length) { console.error('はじめに.md で引けないコマンド:', hr.missing.join(' ')); process.exitCode = 1; } console.log('はじめに.md', hr.text.split('\n').length, '行');
  await browser.close();
})();
