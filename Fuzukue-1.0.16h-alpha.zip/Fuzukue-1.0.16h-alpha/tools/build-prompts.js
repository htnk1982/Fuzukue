/* 文机が持つ AI への指示文を docs/ に書き出す（1.0.14a）。本体は app/js の定義（画面の「指示文を写す」と同じもの）で、ここでは使い方を前に付けるだけ。
 * 使い方：node tools/build-prompts.js（build-kaisetsu.js の最後でも走る） */
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
function build() {
  const ctx = { FZ: {} }; const g = global; const keep = g.FZ; g.FZ = ctx.FZ; try { delete require.cache[require.resolve('../app/js/fz-pufu.js')]; require('../app/js/fz-pufu.js'); } finally { ctx.FZ = g.FZ; g.FZ = keep; }
  const FZ = ctx.FZ; const out = [];
  const head = `<!-- 生成物：app/js/fz-pufu.js の FZ.PUFU_PROMPT から tools/build-prompts.js が作る。指示文を直すときは fz-pufu.js を直して作り直す -->
# 文章からプ譜を起こすプロンプト

企画書・議事録・メール・状況説明などの文章を、生成 AI にプ譜の構造へ変換させるための指示文です。

## 使い方

文机の中から使う（推奨）：

1. 挿入（F7）→ プ譜 →「下書き」で欄を開き、元の文章の種類（自動・議事録・発言録・個人の書いた文章・企画書）と本文（選んだ範囲・この節・文書全体・欄に貼る）を選んで「写す」。種類を選ぶと「元の文章の読み方」がその種類だけになる。本文と今日の日付も入る。
2. AI（ChatGPT・Copilot など）の入力欄に貼る。推論（思考）するモデルを選ぶ。逆算と言い換えの質は、思考の深さで大きく変わる。
3. 返ってきた答えを、挿入（F7）→ プ譜 →「取り込む」の欄に貼って取り込む。
   - 役の名前は外して段（深さ）になる。「取組：」は取組の印に、「成果物：」はそのまま中間目的の箱の続きに。
   - 〔推測〕の付いた行は、本文に無かったものを AI が補った所。紙面では点線の箱になる。確かめたら〔推測〕を消す。
   - 「読み取れなかったこと」と「注」は、プ譜の見出しの付箋になる。問いに答えて直す。
4. プ譜 →「点検」で、中間目的が状態で書けているか・数・担当と期日などを確かめる。

文机の外で使う：下の「ここから」〜「ここまで」を AI の入力欄に貼り、末尾の {{題}}・{{日付}}・{{本文}} を差し替える。題が空なら、AI が本文から付ける。

出力の形は、文机のプ譜の受け渡し形式です（役の名前を行の頭に付け、親子を字下げで表す）。

---ここから---

`;
  out.push({ file: path.join(root, 'docs/プロンプト_文章からプ譜を起こす.md'), text: head + FZ.PUFU_PROMPT + '\n\n---ここまで---\n' });
  /* 1.0.14d 点検と直し・次の局面（このプ譜を〈プ譜〉に入れて使う） */
  const H2 = (title, use, body, tail) => `<!-- 生成物：app/js/fz-pufu.js から tools/build-prompts.js が作る。指示文を直すときは fz-pufu.js を直して作り直す -->\n# ${title}\n\n## 使い方\n\n${use}\n\n答えは、文机の「AI から戻す」に貼ると、今のプ譜と行ごとに比べて 1 件ずつ取り込める（AI に渡した後の自分の直しは保たれる）。「直した所」「変えた所」「読み取れなかったこと」は右の欄「変換の記録」に出る。\n\n---ここから---\n\n${body}\n\n---ここまで---\n${tail || ''}`;
  out.push({ file: path.join(root, 'docs/プロンプト_プ譜を点検して直す.md'), text: H2('プ譜を点検して直すプロンプト', '文机ではプ譜の中にカーソルを置き、挿入（F7）→ プ譜 →「点検を頼む」。このプ譜を役の名前付きで入れた指示文が写される。文机の外で使うときは、下の {{プ譜}} を役の名前付きのプ譜（「- 獲得目標：…」の箇条書き）に差し替える。', FZ.PUFU_PROMPT_REVIEW()) });
  out.push({ file: path.join(root, 'docs/プロンプト_プ譜の次の局面.md'), text: H2('プ譜の次の局面を描くプロンプト', '文机ではプ譜の中にカーソルを置き、挿入（F7）→ プ譜 →「次の局面」。新しい情報（会議の記録・進捗・やってみてわかったこと）を欄に貼ると、このプ譜と一緒に指示文に入れて写す。文机の外で使うときは {{日付}}・{{プ譜}}・{{新しい情報}} を差し替える。', FZ.PUFU_PROMPT_NEXT()) });
  for (const o of out) fs.writeFileSync(o.file, o.text);
  return out.map(o => path.relative(root, o.file));
}
module.exports = build;
if (require.main === module) console.log(build().join('\n'));
