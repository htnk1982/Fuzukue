/* 読み込み用 Worker の束ね：解析に要るモジュールを 1 つの文字列にして app/js/fz-worker-src.js に書く。
 * file:// で開いたページは別ファイルの Worker を作れない（Chromium の制限）ので、文字列から Blob の Worker を作る。
 * ソースを変えたら `node tools/build-worker.js` を実行（test 一式と zip 作成の前に走らせる）。 */
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const mods = ['fz-core', 'fz-figure', 'fz-mermaid', 'fz-chart', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm'];
const body = mods.map(m => fs.readFileSync(path.join(root, 'app/js', m + '.js'), 'utf8')).join('\n');
const handler = `
self.onmessage = function (e) {
  const d = e.data || {};
  try {
    const t0 = Date.now();
    const doc = d.kind === 'md' ? FZ.fromGfm(d.text, d.format ? { ...FZ.newDoc(), format: d.format } : null, d.opts || {}) : FZ.parse(d.text);
    self.postMessage({ id: d.id, ok: true, doc, ms: Date.now() - t0 });
  } catch (err) { self.postMessage({ id: d.id, ok: false, error: String(err && err.message || err) }); }
};
`;
const src = body + '\n' + handler;
const out = '/* 生成物：tools/build-worker.js（' + mods.join(', ') + ' を束ねた読み込み用 Worker のソース） */\n(function (FZ) { FZ.WORKER_SRC = ' + JSON.stringify(src) + '; })(globalThis.FZ = globalThis.FZ || {});\n';
module.exports = { out, file: path.join(root, 'app/js/fz-worker-src.js') }; // test-lint.js が「束ねが古くないか」を比べる
if (require.main === module) { fs.writeFileSync(module.exports.file, out); console.log('fz-worker-src.js', (out.length / 1024).toFixed(0) + ' KB'); }
