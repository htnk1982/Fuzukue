#!/bin/sh
# 配布 zip を作る：sh tools/dist.sh → /home/claude/dist/Fuzukue-<版>.zip（tauri・node_modules・生成物の一部は除く）
set -e
cd "$(dirname "$0")/.."
node tools/build-worker.js >/dev/null && node tools/build-kaisetsu.js # 生成物を今のソースから作り直す（古い束ね・古い取扱説明書を配らない）
VER=$(node -e "require('./app/js/fz-core.js');console.log(globalThis.FZ.VERSION)")
OUT=/home/claude/dist/Fuzukue-$VER
rm -rf "$OUT" "$OUT.zip"; mkdir -p "$OUT"
for d in app host samples tools docs *.bat *.md; do cp -r "$d" "$OUT/"; done
rm -rf "$OUT/tools/ijiwaru/out" "$OUT/host/fuzukue.exe" 2>/dev/null || true
(cd /home/claude/dist && zip -qr "Fuzukue-$VER.zip" "Fuzukue-$VER")
ls -la "$OUT.zip"
