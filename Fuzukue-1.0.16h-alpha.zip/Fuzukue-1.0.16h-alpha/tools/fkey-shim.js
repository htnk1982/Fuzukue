/* 試験用：1.0.10u で項目の文字キー（構え）をやめたので、古い試験の「F キー → 1 文字」をコマンドの実行に読み替える。
   使い方：const shim = require('./fkey-shim'); shim(page);（page を作った直後）。F キーはそのまま押し（帯を切り替える）、
   続く 1 文字がそのグループの項目のキーなら、キーを押す代わりにその項目を実行する（プルダウンは次の値へ）。 */
module.exports = function shim(page) {
  const kb = page.keyboard, orig = kb.press.bind(kb);
  kb.press = async (key, opts) => {
    const r = await page.evaluate(k => {
      if (!window.FZ || !FZ.app || !FZ.app._menu) return 'pass';
      const M = FZ.app._menu(); const fk = M.FK.text.find(x => x[0] === k);
      if (fk) { window.__arm = M.GROUP_OF[fk[2]] || null; return 'pass'; }
      let ch = null; if (/^Key[A-Z]$/.test(k)) ch = k.slice(3); else if (/^Digit\d$/.test(k)) ch = k.slice(5); else if (k.length === 1) ch = k;
      const g = window.__arm && M.GROUPS[window.__arm];
      if (!g || ch == null) { if (k !== 'Shift' && k !== 'Control' && k !== 'Alt') window.__arm = null; return 'pass'; }
      const it = g.items.find(x => x.key && String(x.key).toLowerCase() === ch.toLowerCase());
      if (!it) { window.__arm = null; return 'pass'; }
      if (it.msel) { const S = M.MSEL[it.msel]; const o = S.opts(); const cur = String(S.val()); const i = o.findIndex(x => String(x[0]) === cur); S.set(o[(i + 1) % o.length][0]); window.__arm = null; FZ.app.drawSub(); return 'done'; }
      const el = document.querySelector('#sub .ch[data-cmd="' + it.cmd + '"]'); /* 帯の項目を押したのと同じにする（深いグループから戻るなども） */
      if (el) el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); else FZ.app.run(it.cmd);
      window.__arm = M.SUBGROUP_OF[it.cmd] || null; return 'done';
    }, key).catch(() => 'pass');
    if (r === 'pass') return orig(key, opts);
  };
  return page;
};
