/* 付録 A メニューと近道の一覧（メニューの表から作る）／付録 B 全コマンドの一覧（コマンドの表から作る） */
const FKEYS = [['F2', 'file'], ['F3', 'edit'], ['F4', 'struct'], ['F5', 'marks'], ['F6', 'line'], ['F7', 'insert'], ['F8', 'tedit'], ['F9', 'fmt'], ['F10', 'view']];
const SUB = { head: ['F6「見出し飾り」', '見出し飾り'], table: ['F8「様式」', '表の様式'] };
const MSEL = { zoom: ['倍率▾', '幅に合わせる・ページ全体・50〜200%・指定…'], depth: ['深さ▾', 'ツリーの深さ：1段・2段・3段・全段・本文・文'], figs: ['図表▾', 'ツリーの図表：図題（名前だけ）・図中身'], shape: ['形▾', 'ツリーの形：字下げ・横広げ・縦広げ'], font: ['書体▾', '本文の書体：明朝・ゴシック'], orient: ['向き▾', '用紙の向き：縦長・横長'], narrow: ['字幅▾', '長体：字の幅 100%・90%・75%・50%'] };
/* 付録 B の分け方：コマンドの「グループ」をこの順に。罫線を手で引く機能（罫線モード）はやめたので載せない */
const ORDER = ['ファイル', '編集', '構造', 'アウトライン', '文字', '配置', '見出し飾り', '挿入', '表', '表の様式', '書式', '表示', '説明', 'ツリー', '図', '網掛け（範囲）'];
const RETIRED = () => false; /* 罫線モードのコマンドは 1.0.10u で消した */
module.exports = (h, ctx) => {
  h.app('付録 A　メニューと近道の一覧');
  h.p('メニューの帯の項目と、近道のキーの一覧。どちらもいまのメニューとコマンドの表から作っている。');
  h.app2('F キーのメニュー');
  h.p('F キーを押すか F キーのボタンをクリックして帯を出し、項目をクリックする（{{§F キーとグループ}}）。▾ はプルダウン。「近道」は直接押せるキー。');
  const rowsOf = (gkey, prefix) => { const g = ctx.groups[gkey]; const rows = []; for (const it of g.items) {
      if (it.cl !== undefined) { rows.push(['**' + it.cl + '**', '', '']); continue; }
      if (it.msel) { const m = MSEL[it.msel] || [it.msel, '']; rows.push([m[0], m[1], '—']); continue; }
      if (it.segd) { rows.push(['L1・L2・L3・L全・本文・単文', 'ツリーの段数（文書全体を一度に開く・畳む）', '1〜9・0（ツリーで）']); continue; }
      const c = ctx.cmd.get(it.cmd); if (c) ctx.listed.add(c.id); const sk = c && c.keys && !/^（/.test(c.keys) ? c.keys : '—'; rows.push([it.short || it.label, c ? c.label : it.label, sk]); }
    return rows; };
  for (const [fk, gk] of FKEYS) { const g = ctx.groups[gk]; h.p('**' + fk + '　' + g.title + '**'); h.table([0, 9, 31, 40], ['名前', '働き', '近道'], rowsOf(gk, fk)); }
  for (const [gk, [pre, title]] of Object.entries(SUB)) { h.p('**' + pre + '　' + title + '**（実行するか Esc で元のグループに戻る）'); h.table([0, 9, 31, 40], ['名前', '働き', '近道'], rowsOf(gk, pre)); }
  h.app2('近道');
  h.p('直接押せるキー。紙面で効くもの（図を描いている間・網掛けの間・ツリーのキーは、それぞれ下の表）。');
  const isMode = c => ['図', 'ツリー', '罫線'].includes(c.group) || /^（/.test(c.keys || '');
  const sc = ctx.cmds.filter(c => c.keys && !isMode(c) && !RETIRED(c.id));
  h.table([0, 15, 40], ['キー', '働き'], sc.map(c => { ctx.listed.add(c.id); return [c.keys, c.label]; }));
  h.app2('ツリーのキー');
  h.table([0, 15, 40], ['キー', '働き'], [
    ['クリック・矢印・Home', '節を選ぶ（↑↓ 前後、← 親、→ 子）・いちばん上へ'],
    ['Shift+クリック・ドラッグで囲む', '足して選ぶ・囲んで選ぶ'],
    ['Enter・Shift+Enter・Tab', '弟を足す・兄を足す・子を足す'],
    ['Ctrl+Enter・ダブルクリック', '節の文字（図表の題）を直す'],
    ['Delete・Backspace', '選んだ節を消す（子と本文ごと）'],
    ['Alt+↑↓（Ctrl+↑↓）', '兄弟の中で上へ・下へ'],
    ['Alt+←→・Shift+Tab・Ctrl+→', '浅く・深く'],
    ['Space', '選んだ節を畳む・開く'],
    ['1〜8・9・0', '深さ：その段まで・全段・本文まで'],
    ['＋・−・Ctrl+0', '拡大・縮小・等倍'],
    ['Ctrl+C・Ctrl+V', '選んだ節を Markdown で写す・Markdown を子として貼る'],
    ['Ctrl+F', 'ツリーの中を探す'],
    ['Esc', '欄 → グループ → 複数の選択の順に閉じ、最後は紙面へ'],
  ]);
  for (const c of ctx.cmds.filter(c => c.group === 'ツリー')) ctx.listed.add(c.id);
  h.app2('図を描いている間のキー');
  h.p('{{§流れ図}} の「キーで描く」の表を見る。F キーの行は F1 箱・F2 文字・F3 矢印・F4 削除・F5 複製・F6 箱の設定…・F7 レーン…・F8 高さ＋・F9 高さ−・F10 ガイド・Esc 本文へ になる。');
  h.app2('網掛け（範囲）の間のキー');
  h.p('{{§網掛け（範囲）}} の表を見る。矢印で範囲、Enter で掛ける、1〜9・0・Q・W・E で文様、F5 で消す、Esc で本文へ。');

  h.app('付録 B　全コマンドの一覧');
  h.p('文机のすべてのコマンドを、グループごとに並べた。「メニュー」は F キーからの道筋、「近道」は直接押すキー。どのコマンドも {{S:palette}}（名前で探す一覧）から実行できる。');
  const groups = new Map(); for (const c of ctx.cmds) { if (RETIRED(c.id)) { ctx.listed.add(c.id); continue; } let g = c.group; if (g === '罫線') g = '網掛け（範囲）'; if (g === 'アウトライン') g = '構造'; if (!groups.has(g)) groups.set(g, []); groups.get(g).push(c); }
  const names = [...groups.keys()].sort((a, b) => (ORDER.indexOf(a) + 1 || 99) - (ORDER.indexOf(b) + 1 || 99));
  for (const g of names) { const list = groups.get(g); h.app2(g + '（' + list.length + '）');
    h.table([0, 22, 31, 40], ['働き', 'メニュー', '近道'], list.map(c => { ctx.listed.add(c.id); return [c.label, c.path || '—', (c.keys || '—').replace(/^（[^）]*）/, '')]; })); }
  h.p('（罫線を手で引く機能は 1.0.10q でやめ、コマンドも 1.0.10u で消した。表・囲み記事・区画で構造として作る。）');
};
