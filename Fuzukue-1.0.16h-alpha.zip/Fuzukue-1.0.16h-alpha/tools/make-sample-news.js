/* 新聞風の見本文書を生成（見出し飾り・表スタイルの全プリセットを 1 文書で示す） */
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-export']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; const fs = require('fs');
const md = `# 新聞の表現を文机で

見出しの重さは五段階。小さい順に「中見出し」「横倍角」「四倍角」「ベタ白抜き」「ベタ2行ぶち抜き」。F6 配置の「見出し飾り」で 1 打鍵。

地震で新幹線が全線停止

首都圏の足、終日乱れる

政府が対策本部を設置

リード（前文）は太字で 1 字下げ、折り返しも揃える。新聞では本文の前に要点をまとめる。この行がその例で、二行目以降の開始位置が同じになる。

中見出しはゴシック太字

横倍角の見出し

四倍角の見出し

ベタ白抜きの見出し

ベタ2行ぶち抜き

薄網の見出し

地紋（斜線）の見出し

地紋（点）の見出し

罫囲みの見出し

太罫下線の見出し

二重罫下線の見出し

袋文字の見出し

キーワード　階層体系

文書ごとに 8 階層の番号・記号の体系を持つ。F9 書式の「体系」で編集し、プリセットとして保存できる。

矢印（→）と❏は階層と独立の行頭記号。

## 表スタイル

| 社名 | 売上高 | 前年比 | 純利益 |
|---|---|---|---|
| 東京電機 | 12,340 | 5.2 | 830 |
| 大阪精機 | 8,120 | -3.1 | -120 |
| 合計 | 20,460 | 1.8 | 710 |

| 区分 | 2024年 | 2025年 | 増減 |
|---|---|---|---|
| 国内 | 1,200 | 1,350 | 150 |
| 海外 | 800 | 760 | -40 |
| 合計 | 2,000 | 2,110 | 110 |

| 項目 | 文机 | 従来機 |
|---|---|---|
| 起動 | 1 秒 | 数十秒 |
| 原本 | テキスト | 独自形式 |
| 価格 | 無料 | 高価 |

| 操作 | キー |
|---|---|
| 見出し飾り | F6 配置 |
| 表スタイル | F8 表 |
| 階層体系 | F9 書式 |
`;
const ed = new FZ.Editor(); ed.onChange = () => {}; ed.onCaret = () => {}; ed.setDoc(FZ.fromMarkdown(md));
const find = t => ed.doc.lines.findIndex(l => l.segs[0].text.startsWith(t));
const compact = (t1, t2) => { let a = find(t1), b = find(t2); for (let i = b - 1; i > a; i--) if (ed.doc.lines[i].segs.length === 1 && ed.doc.lines[i].segs[0].text === '') ed.removeLine(i); ed.relayout(); };
compact('地震で', '政府が'); compact('キーワード', '矢印（→）');
const head = (t, id) => { ed.setCaret({ line: find(t), seg: 0, off: 0 }); FZ.applyHeading(ed, id); };
// 千鳥：3 行選択
{ const a = find('地震で'), b = find('政府が'); ed.anchor = { line: a, seg: 0, off: 0 }; ed.caret = { line: b, seg: 0, off: 0, vcol: null, vrow: 0 }; FZ.applyHeading(ed, 'chidori'); ed.anchor = null; }
head('リード', 'lead');
for (const [t, id] of [['中見出し', 'sub'], ['横倍角', 'h'], ['四倍角', 'big'], ['ベタ白抜き', 'beta'], ['ベタ2行', 'beta2'], ['薄網', 'shade'], ['地紋（斜線）', 'hatch'], ['地紋（点）', 'dots'], ['罫囲み', 'box'], ['太罫下線', 'under'], ['二重罫下線', 'under2'], ['袋文字', 'outline']]) head(t, id);
{ const a = find('キーワード'), b = find('矢印（→）'); ed.anchor = { line: a, seg: 0, off: 0 }; ed.caret = { line: b, seg: 0, off: 0, vcol: null, vrow: 0 }; FZ.applyHeading(ed, 'article'); ed.anchor = null; }
const table = (t, id, ops = []) => { ed.setCaret({ line: find(t), seg: 0, off: 0 }); FZ.applyTable(ed, id); for (const o of ops) { ed.setCaret({ line: find(t), seg: 0, off: 0 }); FZ.applyTableOp(ed, o); } };
table('社名', 'fin', ['note']); table('区分', 'stat', ['unit']); table('項目', 'compare'); table('操作', 'news');
// 表の前に説明行
const label = (t, text) => { const i = find(t); const prev = ed.doc.lines[i - 1]; if (prev && prev.segs[0].text === '' && !prev.attrs.cells) { prev.segs[0].text = text; prev.segs[0].marks = FZ.marksFor(text, FZ.M.BOLD); } };
label('社名', '決算表（F8 表の「様式」）：黒地白抜き見出し・点線・数値右揃え・▲');
label('（単位', '統計表（F8 表の「様式」）：上下太罫・合計行の上に細罫・単位行');
label('項目', '対比表（F8 表の「様式」）：外枠太罫・表側は薄網');
label('操作', '新聞（F8 表の「様式」）：横罫だけ・白抜き見出し');
ed.doc.title = '新聞風見本'; const P = FZ.SCHEME_PRESETS[1]; ed.doc.format.scheme = P.num.slice(); ed.doc.format.titleLevels = 0; ed.doc.format.symScheme = Array(8).fill('なし'); ed.doc.format.bulletScheme = P.bullet.slice();
const text = FZ.serialize(ed.doc);
fs.writeFileSync('samples/新聞風見本.fzk', text);
fs.writeFileSync('tools/fz-samples.js', '/* 生成物：tools/make-sample-news.js */\n(function (FZ) { FZ.sampleNews = () => ' + JSON.stringify(text) + '; })(globalThis.FZ = globalThis.FZ || {});\n');
console.log(text);
