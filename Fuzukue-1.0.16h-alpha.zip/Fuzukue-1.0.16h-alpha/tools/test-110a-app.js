/* 1.0.10a（画面）：資料の新規・図表の設定・図番・画像の貼り付け・柱のクリック・網点化・コピー */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); require('./fkey-shim')(page);
  let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
  page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(500);
  await page.evaluate(() => localStorage.clear());
  // 新しい資料：F2→1→S
  await page.keyboard.press('F2'); await page.keyboard.press('n'); await page.waitForTimeout(80); await page.keyboard.press('s'); await page.waitForTimeout(150);
  let r = await page.evaluate(() => ({ kind: FZ.app.ed.doc.format.kind, st: FZ.app.ed.line().attrs.style, cols: FZ.app.ed.lay.geo.cols, body: FZ.app.ed.lay.geo.bodyCols, pos: document.getElementById('stPos').textContent }));
  if (r.kind !== 'slide' || r.st !== 'title' || r.cols !== 60 || r.body !== 36 || !r.pos.startsWith('柱')) bad('new slide', r);
  await page.keyboard.type('売上の報告'); await page.keyboard.press('ArrowDown'); await page.keyboard.type('本文です'); await page.waitForTimeout(50);
  r = await page.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs[0].text, b: FZ.app.ed.doc.lines[1].segs[0].text, y: FZ.app.ed.lay.lineMap[0].rows[0].y }));
  if (r.t !== '売上の報告' || r.b !== '本文です' || r.y >= 0) bad('type title and body', r);
  // 画像の貼り付け → 図表欄＋設定フォーム
  const png = fs.readFileSync(path.join(__dirname, 'sample-img', 'chart.png')).toString('base64');
  await page.evaluate(b64 => { const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); const dt = new DataTransfer(); dt.items.add(new File([u], 'chart.png', { type: 'image/png' })); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }, png);
  await page.waitForTimeout(300);
  r = await page.evaluate(() => ({ form: FZ.app.st.form, figs: FZ.app.ed.figList().length, img: Object.keys(FZ.app.ed.doc.images || {}), side: FZ.app.ed.lay.pages[0].side.images.length }));
  if (r.form !== 'fig' || r.figs !== 1 || r.img.length !== 1 || r.side !== 1) bad('paste image', r);
  await page.fill('#sub input[name=title]', '売上の推移'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ form: FZ.app.st.form, t: FZ.app.ed.figList()[0].fg.title, cap: FZ.app.ed.lay.pages[0].side.glyphs.map(g => g.text).join('') }));
  if (r.form || r.t !== '売上の推移' || !r.cap.includes('図 1　売上の推移')) bad('fig title', r);
  // 図番：F5→N→1
  await page.keyboard.press('End'); await page.keyboard.press('F7'); await page.keyboard.press('n'); await page.waitForTimeout(80); await page.keyboard.press('1'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ text: FZ.app.ed.lay.lineMap[1].segs[0].rows[0].glyphs.map(g => g.text).join(''), form: FZ.app.st.form }));
  if (r.text !== '本文です図 1' || r.form) bad('figref insert', r);
  // コピー：外へは「図 1」の文字
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.setCaret({ line: 1, seg: 0, off: ed.seg().text.length }, true); const dt = new DataTransfer(); document.getElementById('ta').dispatchEvent(new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true })); return dt.getData('text/plain'); });
  if (r !== '本文です図 1') bad('copy expands refs', r);
  // F6→G：図表フォーム、幅 50%
  await page.keyboard.press('End'); await page.keyboard.press('F7'); await page.keyboard.press('g'); await page.waitForTimeout(80);
  r = await page.evaluate(() => FZ.app.st.form); if (r !== 'fig') bad('F6→G opens fig form', r);
  await page.evaluate(() => { const s = document.querySelector('#sub .cyc[data-name=fsz]'); s.value = '2'; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.click('#sub button[data-act=apply]'); await page.waitForTimeout(80); /* 1.0.11e：大きさ 1/2 */
  r = await page.evaluate(() => FZ.app.ed.figList()[0].fg.div); if (r !== 2) bad('fig size 1/2', r);
  // 柱の題をクリック → 表題の行
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }));
  const box = await page.evaluate(() => { const svg = document.querySelector('svg.pg'); const rc = svg.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = rc.width / g.W; return { x: rc.left + (g.left + 2 * g.cw) * sc, y: rc.top + (g.top + 1 * g.ch) * sc }; });
  await page.mouse.click(box.x, box.y); await page.waitForTimeout(80);
  r = await page.evaluate(() => FZ.app.ed.caret.line); if (r !== 0) bad('click header title', r);
  // 図版をクリック → 図表フォーム
  const fb = await page.evaluate(() => { const im = FZ.app.ed.lay.pages[0].side.images[0]; const svg = document.querySelector('svg.pg'); const rc = svg.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = rc.width / g.W; return { x: rc.left + (g.left + (im.col + im.w / 2) * g.cw) * sc, y: rc.top + (g.top + (g.bodyTop + im.y + im.h / 2) * g.ch) * sc }; });
  await page.mouse.click(fb.x, fb.y); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.st.form); if (r !== 'fig') bad('click figure opens form', r); await page.keyboard.press('Escape');
  // 網点化：しばらくすると画像が網点の画像に替わる
  const h0 = await page.evaluate(() => document.querySelector('image.figimg') && document.querySelector('image.figimg').getAttribute('href'));
  await page.waitForTimeout(1200); await page.evaluate(() => FZ.app.flush());
  const h1 = await page.evaluate(() => document.querySelector('image.figimg') && document.querySelector('image.figimg').getAttribute('href'));
  if (!h0 || !h1 || !h1.startsWith('blob:')) bad('halftone image url', [h0, h1]);
  const px = await page.evaluate(async (u) => { const im = new Image(); im.src = u; await im.decode(); const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const x = c.getContext('2d'); x.drawImage(im, 0, 0); const d = x.getImageData(0, 0, c.width, c.height).data; let gray = 0; for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 0 && d[i] > 10 && d[i] < 245) gray++; return { w: c.width, gray }; }, h1);
  if (!(px.w > 100) || px.gray > 0) bad('halftone is binary', px);
  // 印刷：全ページを網点の画像で
  r = await page.evaluate(async () => { await FZ.app.prepareImages(); FZ.app.renderForPrint(); const hs = [...document.querySelectorAll('image.figimg')].map(i => i.getAttribute('href')); const out = { n: hs.length, blob: hs.every(h => h.startsWith('blob:')) }; FZ.app.render(); return out; });
  if (r.n !== 1 || !r.blob) bad('print uses halftone', r);
  // 書式：資料の柱フォーム
  await page.evaluate(() => FZ.app.openForm('slide')); await page.waitForTimeout(50); await page.fill('#sub input[name=secret]', '【秘】'); await page.fill('#sub input[name=bodyPct]', '50'); await page.click('#sub button[data-act=apply]'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ s: FZ.app.ed.doc.format.secret, b: FZ.app.ed.lay.geo.bodyCols, head: FZ.app.ed.lay.pages[0].head.glyphs.map(g => g.text).join('') }));
  if (r.s !== '【秘】' || r.b !== 30 || !r.head.includes('【秘】')) bad('slide form', r);
  // 作成日：今日ボタン・自動・コマンド
  await page.evaluate(() => FZ.app.openForm('slide')); await page.waitForTimeout(50); await page.fill('#sub input[name=date]', '2020年1月1日'); await page.click('#sub button[data-act=today]'); const dv = await page.$eval('#sub input[name=date]', e => e.value); await page.click('#sub button[data-act=apply]'); await page.waitForTimeout(50);
  r = await page.evaluate(() => ({ d: FZ.app.ed.doc.format.date, t: FZ.todayJa() })); if (dv !== r.t || r.d !== r.t) bad('today button', [dv, r]);
  await page.evaluate(() => FZ.app.ed.mutate('', () => { FZ.app.ed.doc.format.date = '2020年1月1日'; })); await page.evaluate(() => FZ.app.run('dateToday')); r = await page.evaluate(() => FZ.app.ed.doc.format.date === FZ.todayJa()); if (!r) bad('dateToday command');
  await page.evaluate(() => FZ.app.openForm('slide')); await page.waitForTimeout(50); await page.evaluate(() => { const s = document.querySelector('#sub .cyc[data-name=dateAuto]'); s.selectedIndex = (s.selectedIndex + 1) % s.options.length; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.click('#sub button[data-act=apply]'); await page.waitForTimeout(50);
  r = await page.evaluate(() => ({ a: FZ.app.ed.doc.format.dateAuto, s: FZ.serialize(FZ.app.ed.doc).includes('作成日: 自動') })); if (!r.a || !r.s) bad('date auto toggle', r);
  // 1 行の **太字** の貼り付け、F6→N 番号付き箇条書き
  await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.enter(); ed.setCaret({ line: 1, seg: 0, off: 0 }); });
  await page.evaluate(() => { const dt = new DataTransfer(); dt.setData('text/plain', '**国内：**主力の需要'); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }); await page.waitForTimeout(50);
  r = await page.evaluate(() => { const sg = FZ.app.ed.doc.lines[1].segs[0]; return { t: sg.text, b: sg.marks.map(m => m & 1 ? 'B' : '.').join('') }; }); if (r.t !== '国内：主力の需要' || r.b !== 'BBB.....') bad('inline ** paste', r);
  await page.keyboard.press('F4'); await page.keyboard.press('n'); await page.waitForTimeout(50); r = await page.evaluate(() => FZ.app.ed.doc.lines[1].attrs.list); if (!r || r.kind !== 'num') bad('F4→N numbered item', r);
  // 保存の形
  r = await page.evaluate(() => { const s = FZ.serialize(FZ.app.ed.doc); return { att: s.includes('#添付 画像1.png image/png'), fig: /#図版 f1 図 売上の推移 画像1\.png 1\/2/.test(s), ref: s.includes('本文です<図番 f1>') }; });
  if (!r.att || !r.fig || !r.ref) bad('serialized', r);
  // Markdown の読み込みは既定の書式（本文を見出しの文字位置に揃える・戻り空き）で組む。古い既定（版の印なし）は新しい既定に、印のある既定は従う
  r = await page.evaluate(async () => { const app = FZ.app; const out = {};
    localStorage.removeItem('fz.defaults'); await app.loadText('# 題\n\n## 原則\n\n### 市場\n\n本文の段落。\n\n## 次\n\n本文2\n', 'x.md'); const ed = app.ed; out.bf = ed.doc.format.bodyFollow; out.rg = ed.doc.format.returnGap;
    const body = ed.doc.lines.findIndex(l => l.segs[0].text === '本文の段落。'); const head = body - 1; const hm = ed.lay.lineMap[head].segs[0].rows[0].glyphs.find(g => g.marker); out.aligned = ed.doc.format.bodyFollow === 'step' && ed.lay.lineMap[body].segs[0].rows[0].glyphs[0].col === hm.col + 1 && hm.col > 0; /* 既定は見出しの頭（番号の桁）から 1 字下げ */
    localStorage.setItem('fz.defaults', JSON.stringify({ ...FZ.newDoc().format, bodyFollow: false, returnGap: false })); await app.loadText('## a\n\nb\n', 'y.md'); out.oldDefaults = ed.doc.format.bodyFollow && ed.doc.format.returnGap;
    localStorage.setItem('fz.defaults', JSON.stringify({ ...FZ.newDoc().format, bodyFollow: false, returnGap: false, _v: 2 })); await app.loadText('## a\n\nb\n', 'z.md'); out.newDefaults = !ed.doc.format.bodyFollow && !ed.doc.format.returnGap;
    localStorage.removeItem('fz.defaults'); return out; });
  if (!r.bf || !r.rg || !r.aligned || !r.oldDefaults || !r.newDefaults) bad('md import uses default format (body follows heading)', r);
  console.log('110a-app fails=' + fails, 'errors:', errors); await browser.close(); process.exit(fails ? 1 : 0);
})();
