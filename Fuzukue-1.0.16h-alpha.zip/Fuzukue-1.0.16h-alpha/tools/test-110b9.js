/* 1.0.10b.9（レッドチームの対策）：危ないリンク、圧縮つき ZIP、版面より列の多い表、外での書き換えの検出、IndexedDB の復旧、速さの退行 */
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path'); const zlib = require('zlib');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
/* 最小の ZIP 読み（中央ディレクトリ → 各項目。method 8 は inflateRaw）。CRC も確かめる */
function unzip(u8) { const b = Buffer.from(u8); let e = b.length - 22; while (e >= 0 && b.readUInt32LE(e) !== 0x06054b50) e--; if (e < 0) throw new Error('no EOCD'); const n = b.readUInt16LE(e + 10); let p = b.readUInt32LE(e + 16); const out = new Map();
  for (let k = 0; k < n; k++) { if (b.readUInt32LE(p) !== 0x02014b50) throw new Error('bad CD'); const method = b.readUInt16LE(p + 10), crc = b.readUInt32LE(p + 16), csize = b.readUInt32LE(p + 20), usize = b.readUInt32LE(p + 24), nl = b.readUInt16LE(p + 28), xl = b.readUInt16LE(p + 30), cl = b.readUInt16LE(p + 32), off = b.readUInt32LE(p + 42); const name = b.slice(p + 46, p + 46 + nl).toString('utf8'); p += 46 + nl + xl + cl;
    const lnl = b.readUInt16LE(off + 26), lxl = b.readUInt16LE(off + 28); const raw = b.slice(off + 30 + lnl + lxl, off + 30 + lnl + lxl + csize); const data = method === 8 ? zlib.inflateRawSync(raw) : method === 0 ? raw : null; if (!data) throw new Error('method ' + method);
    if (data.length !== usize) throw new Error('size ' + name); if (zlib.crc32 && (zlib.crc32(data) >>> 0) !== crc) throw new Error('crc ' + name); out.set(name, { data, method }); } return out; }
(async () => {
  // 1 危ないリンク：開かない・書き出さない
  const urls = { 'https://a.jp/x': true, 'mailto:a@b.jp': true, 'file:///C:/a.xlsx': true, 'C:\\a\\b.xlsx': true, '../a.md': true, '#s': true, 'javascript:alert(1)': false, ' JaVa\tScript:alert(1)': false, 'data:text/html,<b>': false, 'vbscript:x': false, 'blob:x': false };
  for (const [u, ok] of Object.entries(urls)) if (!!FZ.safeUrl(u) !== ok) bad('safeUrl ' + JSON.stringify(u));
  const linkDoc = FZ.parse('#fzk 2\n---\n<リンク javascript:alert(1)>危険</リンク>と<リンク https://example.com/>安全</リンク>\n');
  { const files = FZ.toDocx(linkDoc, { files: true }); const all = files.map(f => typeof f.data === 'string' ? f.data : '').join('\n'); if (/javascript:/i.test(all) || !all.includes('https://example.com/')) bad('docx drops javascript: links only'); }
  { const files = FZ.toPptx(linkDoc, { files: true }); const all = files.map(f => typeof f.data === 'string' ? f.data : '').join('\n'); if (/javascript:/i.test(all) || !all.includes('https://example.com/')) bad('pptx drops javascript: links only'); }
  // 2 圧縮つき ZIP：正しく読めて、中身が無圧縮版と同じで、ずっと小さい
  { const L = []; for (let i = 0; i < 400; i++) L.push('本文の段落。文机は文字数×行数の版面に文章を流し込む。' + i); const d = FZ.parse('#fzk 2\n---\n' + L.join('\n') + '\n');
    for (const w of ['toDocx', 'toPptx']) { const files = FZ[w](d, { files: true }); const z = await FZ.zipAsync(files); const s = FZ.zip(files); let a, b; try { a = unzip(z); b = unzip(s); } catch (e) { bad(w + ' zip unreadable', e.message); continue; }
      if (a.size !== b.size || [...a].some(([k, v]) => !b.has(k) || !v.data.equals(b.get(k).data))) bad(w + ' deflated content differs'); if (!FZ.zip.canDeflate || z.length * 3 > s.length) bad(w + ' not compressed', [z.length, s.length]); if (![...a.values()].some(v => v.method === 8)) bad(w + ' no deflated entries'); } }
  // 3 版面より列の多い Markdown の表：列は版面に収め、あふれた列は最後の列に「／」でつなぐ。読み直しても同じ
  for (const n of [41, 60, 300]) { const md = '| ' + Array.from({ length: n }, (_, i) => 'h' + i).join(' | ') + ' |\n|' + '---|'.repeat(n) + '\n| ' + Array.from({ length: n }, (_, i) => 'v' + i).join(' | ') + ' |\n';
    const d = FZ.fromGfm(md); const s1 = FZ.serialize(d), s2 = FZ.serialize(FZ.parse(s1)); const row = d.lines.find(l => l.attrs.cells && l.segs.some(s => s.text.startsWith('v'))); const last = row && row.segs[row.segs.length - 1].text;
    if (s1 !== s2 || !row || row.segs.length > d.format.cols || !last.includes('／') || !last.endsWith('v' + (n - 1)) || row.segs.some(s => /v\d+v\d+/.test(s.text))) bad('wide md table ' + n, { stable: s1 === s2, segs: row && row.segs.length, last: last && last.slice(0, 40) }); }
  // 4 速さの退行の見張り（大きめの文書で直列化・Markdown・書き出しの模型。ゆるい上限）
  { const L = []; let i = 0; while (L.length < 300 * 36) { const k = i % 40; if (k === 0) L.push('[番号1]第' + i + '章　概況'); else if (k === 6) { L.push('#表 列 0,10,22,40 様式 統計表'); L.push('| 支店 | 売上 | 備考 |'); for (let t = 0; t < 14; t++) L.push('| 支店' + t + ' | ' + (t * 137 + 100) + ' | 前年並み |'); } else L.push('本文の段落。文机は文字数×行数の版面に文章を流し込む。段落の途中に文を足せば後ろが押し下がる。' + i); i++; }
    const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 36\n---\n' + L.join('\n') + '\n'); FZ.layout(d); const T = f => { const t = Date.now(); f(); return Date.now() - t; }; FZ.serialize(d); FZ.toGfm(d);
    const t = { ser: T(() => FZ.serialize(d)), md: T(() => FZ.toGfm(d)), model: T(() => FZ.exportModel(d)) }; if (t.ser > 400 || t.md > 600 || t.model > 1500) bad('perf regression (300 pages)', t); console.log('perf 300 pages', JSON.stringify(t)); }
  // 5 画面：リンクの「開く」、外での書き換え、IndexedDB の復旧
  const browser = await chromium.launch(); const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage(); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  let r = await page.evaluate(async () => { const opened = []; window.open = (u) => { opened.push(u); return null; }; const app = FZ.app, ed = app.ed; await app.loadText('#fzk 2\n---\n<リンク javascript:alert(1)>危険</リンク>\n<リンク https://example.com/>安全</リンク>\n', 'l.fzk');
    ed.setCaret({ line: 0, seg: 0, off: 1 }); app.openForm('link'); document.querySelector('#sub button[data-act="open"]').click(); const msg1 = document.getElementById('msg') ? document.getElementById('msg').textContent : ''; app.run('escape');
    ed.setCaret({ line: 1, seg: 0, off: 1 }); app.openForm('link'); document.querySelector('#sub button[data-act="open"]').click(); return { opened, msg1 }; });
  if (r.opened.length !== 1 || r.opened[0] !== 'https://example.com/') bad('link form opens only safe urls', r); await page.keyboard.press('Escape'); await page.evaluate(() => { if (FZ.app.st.form) document.querySelector('#sub button[data-act="cancel"]') && document.querySelector('#sub button[data-act="cancel"]').click(); });
  // 外での書き換え：開いたあとに更新日時が変わっていたら、上書きの前に聞く
  r = await page.evaluate(async () => { const app = FZ.app; const writes = []; let mtime = 1000; let gone = false; let disk = '#fzk 2\n---\n本文\n'; const h = { kind: 'file', name: 'c.fzk', getFile: async () => { if (gone) throw new Error('NotFound'); return { lastModified: mtime, name: 'c.fzk', text: async () => disk }; }, createWritable: async () => ({ write: async t => { writes.push(String(t).length); disk = String(t); }, close: async () => { mtime = 2000 + writes.length; } }) }; /* 1.0.13a：外の書き換えは中身でも確かめるので、ファイルの中身も持つ */
    await app.loadText('#fzk 2\n---\n本文\n', 'c.fzk', { handle: h, name: 'c.fzk' }); await new Promise(r => setTimeout(r, 50)); const m0 = app.st.file.mtime;
    app.ed.insertText('あ'); await app.run('save'); await new Promise(r => setTimeout(r, 50)); const plain = { writes: writes.length, form: app.st.form, m: app.st.file.mtime };
    mtime = 99999; disk = '#fzk 2\n---\n外で書いた\n'; app.ed.insertText('い'); await app.run('save'); await new Promise(r => setTimeout(r, 50)); const conflict = { writes: writes.length, form: app.st.form, html: document.getElementById('sub').textContent };
    document.querySelector('#sub button[data-act="over"]').click(); await new Promise(r => setTimeout(r, 80)); const over = { writes: writes.length, form: app.st.form, dirty: app.ed.dirty };
    gone = true; app.ed.insertText('う'); await app.run('save'); await new Promise(r => setTimeout(r, 50)); const goneR = { form: app.st.form, html: document.getElementById('sub').textContent }; app.run('escape'); return { m0, plain, conflict, over, goneR }; });
  if (r.m0 !== 1000 || r.plain.writes !== 1 || r.plain.form || r.conflict.writes !== 1 || r.conflict.form !== 'conflict' || !/外で書き換え/.test(r.conflict.html) || r.over.writes !== 2 || r.over.dirty || r.goneR.form !== 'conflict' || !/見つかりません/.test(r.goneR.html)) bad('external change detection before overwrite', r);
  // IndexedDB の復旧：localStorage に入らない（上限を模す）大きな画像つきの文書 → 本文は localStorage、全文は IndexedDB → 開き直すと画像まで戻る
  const bigImg = Buffer.concat([fs.readFileSync(path.join(__dirname, 'sample-img', 'chart.png')), Buffer.alloc(240000)]).toString('base64'); // IEND のあとの詰め物は読み手が無視する（正しい PNG のまま大きくする）
  r = await page.evaluate(async (bigImg) => { const app = FZ.app; app.ed.dirty = false; localStorage.clear(); const orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (/^fz\.recover/.test(k) && String(v).length > 100000) throw new DOMException('quota', 'QuotaExceededError'); return orig.call(this, k, v); };
    await app.loadText('#fzk 2\n---\n画像の文書\n#図版 g1 図 大きな画像 big.png 50%\n===\n#添付 big.png image/png\n' + bigImg + '\n', 'big.fzk'); app.st.file = null; app.ed.insertText('追記'); await new Promise(r => setTimeout(r, 1600));
    const key = Object.keys(localStorage).find(k => /^fz\.recover\.\d/.test(k)); const mark = key ? JSON.parse(localStorage.getItem(key)) : null; const idb = key ? await FZ.RDB.get(key) : null; Storage.prototype.setItem = orig;
    return { key, full: mark && mark.full, markHasImg: !!(mark && mark.text.includes('#添付')), idbHasImg: !!(idb && idb.text.includes('#添付 big.png')), markLen: mark ? mark.text.length : 0 }; }, bigImg);
  if (r.full !== 'idb' || r.markHasImg || !r.idbHasImg || !r.markLen) bad('recovery overflows to IndexedDB', r);
  await page.evaluate(() => { FZ.app.ed.dirty = false; }); await page.reload(); await page.waitForTimeout(900);
  r = await page.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs.map(s => s.text).join(''), img: !!(FZ.app.ed.doc.images && FZ.app.ed.doc.images['big.png']), dirty: FZ.app.ed.dirty }));
  if (!r.t.includes('追記') || !r.img || !r.dirty) bad('restore body from localStorage and image from IndexedDB', r);
  // 本文すら入らないとき：印だけ localStorage、文書まるごと IndexedDB から
  r = await page.evaluate(async () => { const app = FZ.app; const orig = Storage.prototype.setItem; Storage.prototype.setItem = function (k, v) { if (/^fz\.recover/.test(k) && String(v).length > 300) throw new DOMException('quota', 'QuotaExceededError'); return orig.call(this, k, v); };
    app.ed.insertText('二度目'); await new Promise(r => setTimeout(r, 1600)); const key = Object.keys(localStorage).find(k => /^fz\.recover\.\d/.test(k)); const mark = key ? JSON.parse(localStorage.getItem(key)) : null; Storage.prototype.setItem = orig; app.ed.dirty = false; return { full: mark && mark.full, text: mark && mark.text }; });
  if (r.full !== 'idb' || r.text !== '') bad('marker-only recovery when even body overflows', r);
  await page.reload(); await page.waitForTimeout(1200);
  r = await page.evaluate(() => ({ t: FZ.app.ed.doc.lines[0].segs.map(s => s.text).join(''), img: !!(FZ.app.ed.doc.images && FZ.app.ed.doc.images['big.png']), dirty: FZ.app.ed.dirty }));
  if (!r.t.includes('二度目') || !r.img || !r.dirty) bad('full restore from IndexedDB', r);
  // 保存（または破棄）で両方とも消える
  r = await page.evaluate(async () => { const app = FZ.app; const writes = []; const h = { kind: 'file', name: 'd.fzk', getFile: async () => ({ lastModified: 5, name: 'd.fzk' }), createWritable: async () => ({ write: async t => writes.push(1), close: async () => { } }) }; app.st.file = { name: 'd.fzk', handle: h }; await app.run('save'); await new Promise(r => setTimeout(r, 100));
    const key = 'fz.recover.' + (Object.keys(localStorage).find(k => /^fz\.slot\.\d/.test(k)) || 'fz.slot.1').split('.').pop(); return { ls: localStorage.getItem(key), idb: await FZ.RDB.get(key), writes: writes.length }; });
  if (r.ls || r.idb || r.writes !== 1) bad('save clears both recovery stores', r);
  console.log(`110b9 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
