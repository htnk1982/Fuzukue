/* 1.0.10c.1：前方互換（知らない鍵・属性・飾り・指示行を持ち回る）、保存の版の履歴、文書の挿入と分割、字数、ローマ字→かな */
const { chromium } = require('playwright'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-export']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  // 1 前方互換：後の版の原本を読んで書き戻しても、知らない部分が消えない
  { const t = '#fzk 2\n新しい鍵: 値\n---\n#未知の指示 1 2\n[未知の属性 中央]本文\n[飾り:未来の飾り 番号1]見出し\n#表 列 0,10,20 様式 格子\n[未来 列揃え左右]| a | b |\n| c | d |\n';
    const s1 = FZ.serialize(FZ.parse(t)); for (const need of ['新しい鍵: 値', '#未知の指示 1 2', '未知の属性', '飾り:未来の飾り', '未来']) if (!s1.includes(need)) bad('forward compat keeps ' + need, s1);
    if (FZ.serialize(FZ.parse(s1)) !== s1) bad('forward compat stable');
    const e = new FZ.Editor(); e.onChange = () => { }; e.onCaret = () => { }; e.setDoc(FZ.parse(t)); e.setCaret({ line: 1, seg: 0, off: 2 }); e.insertText('追記'); e.splitLine(); const s2 = FZ.serialize(e.doc);
    if (!s2.includes('新しい鍵: 値') || !s2.includes('未知の属性') || !s2.includes('#未知の指示')) bad('forward compat survives editing', s2.split('---')[1]);
    const g = FZ.toGfm(FZ.parse(t)); if (/^#未知/m.test(g)) bad('unknown directive must not become a Markdown heading', g); }
  // ローマ字→かな
  { const cases = { konnnitiha: 'こんにちは', gakkou: 'がっこう', matcha: 'まっちゃ', shimbun: 'しんぶん', "kan'i": 'かんい', toukyou: 'とうきょう', fairu: 'ふぁいる', nyuuryoku: 'にゅうりょく', 'ka-do': 'かーど', 'tenki,yoi.': 'てんき、よい。', KITTE: 'きって' };
    for (const [k, v] of Object.entries(cases)) if (FZ.romajiToKana(k) !== v) bad('romaji ' + k, FZ.romajiToKana(k)); }
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(async () => { localStorage.clear(); try { indexedDB.deleteDatabase('fuzukue'); } catch { } });
  // 2 版の履歴：開いたとき・保存のたび、同じ中身は重ねない、10 版まで、外で書き換えた版も残す、選ぶとその版に戻す
  let r = await page.evaluate(async () => { const app = FZ.app; let disk = '#fzk 2\n---\n一版目\n'; let mtime = 100; const h = { kind: 'file', name: 'h.fzk', getFile: async () => ({ lastModified: mtime, name: 'h.fzk', text: async () => disk }), createWritable: async () => ({ write: async t => { disk = String(t); }, close: async () => { mtime += 10; } }) };
    const wait = ms => new Promise(r => setTimeout(r, ms)); await app.loadText(disk, 'h.fzk', { handle: h, name: 'h.fzk' }); await wait(150); const out = {}; out.open = (await FZ.histList()).map(v => v.kind);
    app.ed.setCaret({ line: 0, seg: 0, off: 3 }); app.ed.insertText('二'); await app.run('save'); await wait(150); out.save = (await FZ.histList()).map(v => v.kind);
    await app.run('save'); await wait(100); out.same = (await FZ.histList()).length;
    for (let k = 0; k < 11; k++) { app.ed.insertText('x'); await app.run('save'); await wait(60); } out.cap = (await FZ.histList()).length;
    disk = '#fzk 2\n---\n外で書いた\n'; mtime = 99999; app.ed.insertText('y'); await app.run('save'); await wait(80); document.querySelector('#sub button[data-act="over"]').click(); await wait(250); out.ext = (await FZ.histList()).slice(0, 2).map(v => v.kind);
    app.toggleSide('hist'); await wait(150); out.rows = document.querySelectorAll('#sideBody .li.hv').length; const list = await FZ.histList(); const target = list.findIndex(v => v.kind === '外で書き換えた版');
    document.querySelector(`#sideBody .li[data-hist="${target}"]`).click(); await wait(150); document.querySelector('#sideBody [data-hact="restore"]').click(); await wait(200); /* 1.0.13a：選ぶと違いを見せ、「この版を戻す」で戻す */
    out.restored = app.ed.doc.lines[0].segs.map(s => s.text).join(''); out.dirty = app.ed.dirty; out.file = app.st.file && app.st.file.name; return out; });
  if (r.open.join() !== '開いたとき' || r.save.join() !== '保存,開いたとき' || r.same !== 2 || r.cap !== 10 || r.ext[1] !== '外で書き換えた版' || r.ext[0] !== '保存' || r.rows !== 10 || r.restored !== '外で書いた' || !r.dirty || r.file !== 'h.fzk') bad('version history', r);
  // 3 文書の挿入：画像の名前・図表の ID・図番の字を付け替える。取り消しで戻る
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n前の段落。<図番 f1>を見よ。\n#図版 f1 図 元の図 a.png\n\n後の段落\n===\n#添付 a.png image/png\nAAAA\n')); app.render(); app.ed.setCaret({ line: 1, seg: 0, off: 0 });
    const ins = '#fzk 2\n---\n挿入の段落。<図番 f1>を参照。\n#図版 f1 図 挿入の図 a.png\n===\n#添付 a.png image/png\nBBBB\n'; const op = FZ.files.open; FZ.files.open = async () => ({ name: 'b.fzk', text: ins }); await app.run('insertFile'); FZ.files.open = op;
    const d = app.ed.doc; const ser = FZ.serialize(d); const n = d.lines.length; app.run('undo'); return { ser: ser.split('---')[1], n, after: app.ed.doc.lines.length, imgs: Object.keys(d.images) }; });
  if (!/挿入の段落。<図番 f1_2>を参照。/.test(r.ser) || !/#図版 f1_2 図 挿入の図 a_2\.png/.test(r.ser) || !/前の段落。<図番 f1>/.test(r.ser) || !r.imgs.includes('a_2.png') || r.after !== 3) bad('insert document remaps assets and undoes', r);
  // 文書の分割：カーソルの行から先を別名で保存し、この文書から除く。取り消しで戻る
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n一\n二\n[番号1]三\n四\n五\n')); app.render(); app.ed.setCaret({ line: 2, seg: 0, off: 0 }); let saved = null; const sa = FZ.files.saveAs; FZ.files.saveAs = async (t, nm) => { saved = { t, nm }; return { name: nm }; }; await app.run('splitDoc'); FZ.files.saveAs = sa;
    const left = app.ed.doc.lines.map(l => l.segs[0].text); app.run('undo'); return { left, back: app.ed.doc.lines.length, tail: saved && saved.t.split('---\n')[1], nm: saved && saved.nm }; });
  if (r.left.join() !== '一,二' || r.back !== 5 || r.tail !== '[番号1]三\n四\n五\n' || !/_後半\.fzk$/.test(r.nm)) bad('split document', r);
  // 4 字数：状態行に選択の字数、欄に全体・空白を除く・原稿用紙
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\nあいう　えお\n' + 'か'.repeat(45) + '\n\n')); app.render(); app.ed.setCaret({ line: 0, seg: 0, off: 0 }); app.ed.setCaret({ line: 0, seg: 0, off: 4 }, true); app.render(); const st = document.getElementById('stChars').textContent; app.run('count'); await new Promise(r => setTimeout(r, 50)); const f = document.getElementById('sub').textContent; return { st, f, info: FZ.countInfo() }; });
  if (!/^選択 3／/.test(r.st) || r.info.all !== 51 || r.info.noSp !== 50 || r.info.rows !== 5 || r.info.sheets !== 1 || !/選択 4 字/.test(r.f) || !/原稿用紙/.test(r.f)) bad('char count', r); await page.keyboard.press('Escape');
  // 5 ローマ字→かな：カーソルの前の英字、選んだ範囲、取り消し
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n今日はkonnnitiha\n')); app.render(); app.ed.setCaret({ line: 0, seg: 0, off: 13 }); app.run('romaji'); const a = app.ed.doc.lines[0].segs[0].text; app.run('undo'); const b = app.ed.doc.lines[0].segs[0].text; app.ed.setCaret({ line: 0, seg: 0, off: 3 }); app.ed.setCaret({ line: 0, seg: 0, off: 9 }, true); app.run('romaji'); return { a, b, c: app.ed.doc.lines[0].segs[0].text }; });
  if (r.a !== '今日はこんにちは' || r.b !== '今日はkonnnitiha' || r.c !== '今日はこんにtiha') bad('romaji command', r);
  // 6 取説と取扱説明書に新しい操作が載る
  r = await page.evaluate(() => { const m = FZ.guideText(); return ['版の履歴', '前の版に戻す', '文書を 2 つに分ける', '別の文書を差し込む', 'ローマ字をかなに', '字数を数える'].filter(w => !m.includes(w)); });
  if (r.length) bad('manual lists new commands', r);
  console.log(`110c1 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
