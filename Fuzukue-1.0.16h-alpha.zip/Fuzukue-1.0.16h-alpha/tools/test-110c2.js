/* 1.0.10c.2：網の文様（13 種）、字の網の文様、影文字、m×n 倍角。原本・組版・画面・印刷・Word・PowerPoint・操作 */
const { chromium } = require('playwright'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-docx', 'fz-pptx']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, M = FZ.M; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  // 1 文様の表：名前が重ならず、Word・PowerPoint の対応がある。古い名前（薄・濃・斜線・点・淡）は同じ id
  { const S = FZ.SHADES; if (S.length !== 15 || new Set(S.map(x => x.name)).size !== 15 || S.some(x => !x.word || !x.ppt)) bad('shade registry'); for (const [n, id] of [['薄', 'gray'], ['濃', 'dark'], ['斜線', 'hatch'], ['点', 'dots'], ['淡', 'light']]) if (FZ.SHADE_KEYS[n] !== id) bad('old shade name ' + n); }
  // 2 原本：範囲の網・字の網の文様・m×n・影が往復する
  const src = '#fzk 2\n---\n#網 0-10 ×2 斜め格子\n<網掛け 格子>格子の字</網掛け>と<網掛け>普通の網</網掛け>\n<倍角 3x4>大</倍角>と<影><白抜き>影</白抜き></影>\n<網掛け 濃>墨</網掛け>\n';
  const d = FZ.parse(src); const s1 = FZ.serialize(d);
  for (const need of ['#網 0-10 ×2 斜め格子', '<網掛け 格子>格子の字</網掛け>', '<網掛け>普通の網</網掛け>', '<倍角 3x4>大</倍角>', '<影>', '<網掛け 濃>墨</網掛け>']) if (!s1.includes(need)) bad('serialize keeps ' + need, s1.split('---\n')[1]);
  if (FZ.serialize(FZ.parse(s1)) !== s1) bad('shade/scale round trip stable');
  if (d.fills[0].shade !== 'check' || FZ.shadeOfMarks(d.lines[0].segs[0].marks[0]) !== 'grid' || FZ.shadeOfMarks(d.lines[0].segs[0].marks[6]) !== 'text') bad('parsed shade ids', [d.fills[0].shade]);
  // 3 組版：3x4 の字は 3 マス幅・行は 4 行分
  { const L = FZ.layout(d); const g = L.pages[0].glyphs.find(x => x.text === '大'); if (!g || g.w !== 3 || g.sx !== 3 || g.sy !== 4 || g.h !== 4) bad('m×n layout', g && [g.w, g.sx, g.sy, g.h]); const g2 = L.pages[0].glyphs.find(x => x.text === 'と' && x.line === 1); if (!g2 || g2.y !== g.y || g2.h !== 4) bad('row height follows the tallest glyph', g2 && [g2.y, g2.h]); }
  // 4 Word：文様・字の墨（白字）・影・m×n
  { const files = FZ.toDocx(d, { files: true }); const x = files.find(f => f.name === 'word/document.xml').data;
    if (!/w:val="thinDiagCross"/.test(x)) bad('docx fill pattern'); if (!/w:val="thinHorzCross"/.test(x)) bad('docx char pattern'); if (!/<w:shadow\/>/.test(x)) bad('docx shadow');
    if (!/<w:w w:val="75"\/>/.test(x)) bad('docx m×n width ratio'); if (!/w:fill="000000"\/>[\s\S]{0,40}|<w:color w:val="FFFFFF"\/>/.test(x)) bad('docx dark char shade'); }
  // 5 PowerPoint：パターン塗り・影・字の網は灰色の蛍光ペン
  { const files = FZ.toPptx(d, { files: true }); const all = files.filter(f => /slide\d+\.xml$/.test(f.name)).map(f => f.data).join('');
    if (!/prst="openDmnd"/.test(all)) bad('pptx fill pattern'); if (!/outerShdw/.test(all)) bad('pptx shadow'); if (!/<a:highlight><a:srgbClr val="D9D9D9"\/>/.test(all)) bad('pptx char shade highlight'); }
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  // 6 画面と印刷：全文様の pattern、範囲と字の網、影は 2 つの text、印刷では画像に
  let r = await page.evaluate(async (src) => { const app = FZ.app; await app.loadText(src, 's.fzk', null); app.render(); await new Promise(r => setTimeout(r, 200)); const svg = document.querySelector('svg.pg'); const pats = [...svg.querySelectorAll('pattern')].map(p => p.id).filter(id => /^s_/.test(id)); const fills = [...svg.querySelectorAll('rect')].map(e => e.getAttribute('fill') || ''); const shadowTexts = [...svg.querySelectorAll('text')].filter(t => t.textContent === '影').length;
    const pr = document.createElement('div'); const sv = new DOMParser().parseFromString(FZ.renderPage(app.ed.lay, 0, { mono: true }), 'image/svg+xml').documentElement; pr.appendChild(sv); document.body.appendChild(pr); const n = FZ.rasterizeFills(sv); const left = sv.querySelectorAll('pattern[id^="s_"]').length; pr.remove();
    return { pats: pats.length, check: fills.some(f => /s_check_/.test(f)), grid: fills.some(f => /s_grid_/.test(f)), shadowTexts, raster: n, left }; }, src);
  if (r.pats !== 15 || !r.check || !r.grid || r.shadowTexts !== 2 || r.raster < 3 || r.left) bad('screen/print rendering', r);
  // 7 操作：網掛けモードで見本の 1 文字（Q＝斜め格子）、矢印と Enter で掛ける
  r = await page.evaluate(async () => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n一行目\n二行目\n')); app.render(); app.ed.setCaret({ line: 0, seg: 0, off: 0 }); app.run('fillMode'); await new Promise(r => setTimeout(r, 30)); return { mode: app.st.mode, sw: document.querySelectorAll('#sub .ch.sw').length }; });
  if (r.mode !== 'fill' || r.sw !== 15) bad('fill mode shows swatches', r);
  await page.focus('#ta'); await page.keyboard.press('q'); await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowDown'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ shade: FZ.app.st.shade, fills: FZ.app.ed.doc.fills.map(f => f.shade), mode: document.getElementById('stMode').textContent })); if (r.shade !== 'check' || r.fills[r.fills.length - 1] !== 'check' || !/斜め格子/.test(r.mode)) bad('fill with swatch key', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(40);
  // 字の網の文様（F4→G → 0＝縦線…の順の 1 文字）、影（F4→H）、m×n（F4→K の 3×3）
  r = await page.evaluate(async () => { const app = FZ.app, ed = app.ed; ed.setDoc(FZ.parse('#fzk 2\n---\nあいうえお\n')); app.render(); ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.setCaret({ line: 0, seg: 0, off: 2 }, true); app.run('shadeType'); await new Promise(r => setTimeout(r, 30)); const btns = document.querySelectorAll('#sub button.swb').length; document.querySelector('#sub button[data-act="sh:check"]').click(); await new Promise(r => setTimeout(r, 30));
    const a = FZ.shadeOfMarks(ed.doc.lines[0].segs[0].marks[0]); ed.setCaret({ line: 0, seg: 0, off: 2 }); ed.setCaret({ line: 0, seg: 0, off: 3 }, true); app.run('shadow'); const b = !!(ed.doc.lines[0].segs[0].marks[2] & FZ.M.SHADOW);
    ed.setCaret({ line: 0, seg: 0, off: 3 }); ed.setCaret({ line: 0, seg: 0, off: 4 }, true); app.run('scale'); await new Promise(r => setTimeout(r, 30)); document.querySelector('#sub button[data-act="p:3x3"]').click(); await new Promise(r => setTimeout(r, 30)); const m3 = ed.doc.lines[0].segs[0].marks[3];
    ed.setCaret({ line: 0, seg: 0, off: 3 }); ed.setCaret({ line: 0, seg: 0, off: 4 }, true); app.run('wide'); /* 3×3 に横倍角を押すと横倍角（2×1）になる */ const m4 = ed.doc.lines[0].segs[0].marks[3]; const ser = FZ.serialize(ed.doc).split('---\n')[1]; return { btns, a, b, w3: FZ.scaleW(m3), h3: FZ.scaleH(m3), w4: FZ.scaleW(m4), h4: FZ.scaleH(m4), ser }; });
  if (r.btns !== 15 || r.a !== 'check' || !r.b || r.w3 !== 3 || r.h3 !== 3 || r.w4 !== 2 || r.h4 !== 1) bad('char shade type / shadow / scale commands', r);
  // 網を外すと文様も消える
  r = await page.evaluate(() => { const app = FZ.app, ed = app.ed; ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.setCaret({ line: 0, seg: 0, off: 2 }, true); app.run('shade'); return ed.doc.lines[0].segs[0].marks[0] & (FZ.M.SHADE | FZ.M.SHT); }); if (r) bad('toggling shade off clears its pattern', r);
  // 8 取扱説明書に載る
  r = await page.evaluate(() => { const m = FZ.guideText(); return ['網の文様', '影文字', 'm×n 倍角', '<網掛け 格子>', '<倍角 3x3>'].filter(w => !m.includes(w)); }); if (r.length) bad('manual mentions new features', r);
  console.log(`110c2 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
