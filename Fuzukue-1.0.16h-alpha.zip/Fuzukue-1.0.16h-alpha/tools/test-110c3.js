/* 1.0.10c.3：囲み記事（題あり／題なし・本文は記号の箇条書き・改行で箱が広がる・最後の空の行で外へ）、行頭の Enter、表のセルのクリック */
const { chromium } = require('playwright'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-export', 'fz-gfm']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const body = d => FZ.serialize(d).split('---\n')[1];
const mkEd = src => { const e = new FZ.Editor(); e.onChange = () => { }; e.onCaret = () => { }; e.setDoc(FZ.parse('#fzk 2\n---\n' + src)); return e; };
const vspan = (d, col) => d.rules.filter(r => r.axis === 'v' && r.col === col).map(r => r.from + '-' + r.to).join(',');
(async () => {
  // 1 改行で箱が切れない：どの行のどこで Enter を押しても、左右の縦罫は同じ範囲で上下の横罫に届く
  const SRC = '前の段落\n#囲み ×3\nメモ\n[項目1]一行目の本文\n[項目1]二行目の本文\n後の段落\n';
  for (const [line, off] of [[1, 0], [1, 1], [1, 2], [2, 0], [2, 3], [2, 6], [3, 0], [3, 3], [3, 6]]) {
    const e = mkEd(SRC); e.setCaret({ line, seg: 0, off }); e.enter(); const d = e.doc; const c = d.format.cols;
    const L = vspan(d, 0), R = vspan(d, c); const m = /^(\d+)-(\d+)$/.exec(L); const top = m && d.rules.some(r => r.axis === 'h' && r.line === +m[1]), bot = m && d.rules.some(r => r.axis === 'h' && r.line === +m[2] + 1);
    if (L !== R || !m || !top || !bot || !(line === 1 && off === 0 ? /#囲み ×3/ : /#囲み ×4/).test(body(d))) bad('box stays closed after Enter at ' + line + ':' + off, { L, R, s: body(d) });
  }
  // 題の行頭の Enter：箱ごと下がり、題は題のまま（上に空の行）
  { const e = mkEd(SRC); e.setCaret({ line: 1, seg: 0, off: 0 }); e.enter(); if (!/^前の段落\n\n#囲み ×3\nメモ\n/.test(body(e.doc)) || e.caret.line !== 2) bad('Enter at title start pushes the box down', body(e.doc)); }
  // 題の末尾の Enter：下は本文の箇条書き（次と同頁は付かない）
  { const e = mkEd(SRC); e.setCaret({ line: 1, seg: 0, off: 2 }); e.enter(); e.insertText('追加'); if (!/#囲み ×4\nメモ\n\[項目1\]追加\n/.test(body(e.doc))) bad('Enter after title makes a bullet body line', body(e.doc)); }
  // 最後の行で Enter→打つ→空の行で Enter：囲みの外へ出て、そこに書ける
  { const e = mkEd(SRC); e.setCaret({ line: 3, seg: 0, off: 6 }); e.enter(); e.insertText('三行目'); e.enter(); e.enter(); e.insertText('外の段落');
    if (body(e.doc) !== '前の段落\n#囲み ×4\nメモ\n[項目1]一行目の本文\n[項目1]二行目の本文\n[項目1]三行目\n外の段落\n後の段落\n') bad('leave the box with Enter on the empty last line', body(e.doc)); }
  // 2 題なしの囲み：原本の往復、隣り合う囲みの境の罫が重ならない
  { const t = '#fzk 2\n---\n前\n#囲み ×3\nメモ\n[項目1]一\n[項目1]二\n#囲み ×2 見出しなし\n[項目1]a\nb\n後\n'; const s1 = FZ.serialize(FZ.parse(t)); if (!s1.includes('#囲み ×2 見出しなし\n[項目1]a\nb\n後') || /#罫/.test(s1) || FZ.serialize(FZ.parse(s1)) !== s1) bad('untitled box round trip', s1); }
  // 囲み記事を作る：本文は記号の箇条書き（行頭の「・」は印に）、空の行はそのまま。題なしは全部の行が本文
  { const e = mkEd('題\n・りんご\nみかん\n\n後\n'); e.anchor = { line: 0, seg: 0, off: 0 }; e.setCaret({ line: 3, seg: 0, off: 0 }, true); FZ.applyHeading(e, 'article');
    if (body(e.doc) !== '#囲み ×4\n<太字>題</太字>\n[項目1]りんご\n[項目1]みかん\n\n後\n') bad('make titled box with bullets', body(e.doc));
    FZ.applyHeading(e, 'articleN'); if (!/^#囲み ×4 見出しなし\n題\n\[項目1\]りんご/.test(body(e.doc))) bad('toggle title off inside the box', body(e.doc));
    e.setCaret({ line: 2, seg: 0, off: 0 }); FZ.applyHeading(e, 'article'); if (!/^#囲み ×4\n<太字>題<\/太字>\n/.test(body(e.doc))) bad('toggle title on inside the box', body(e.doc)); }
  { const e = mkEd('メモ欄\n後\n'); e.anchor = { line: 0, seg: 0, off: 0 }; e.setCaret({ line: 0, seg: 0, off: 3 }, true); FZ.applyHeading(e, 'article'); e.insertText('項目A'); /* 1 行を選んで押すと、その行が題（選ばずに押すと空の枠：1.0.10s） */
    if (body(e.doc) !== '#囲み ×2\n<太字>メモ欄</太字>\n[項目1]項目A\n後\n' || e.caret.line !== 1) bad('one line becomes title with a bullet line below', body(e.doc)); }
  { const e = mkEd('メモ1\nメモ2\n後\n'); e.anchor = { line: 0, seg: 0, off: 0 }; e.setCaret({ line: 1, seg: 0, off: 0 }, true); FZ.applyHeading(e, 'articleN'); if (body(e.doc) !== '#囲み ×2 見出しなし\n[項目1]メモ1\n[項目1]メモ2\n後\n') bad('untitled box: every line is a bullet', body(e.doc)); }
  // 3 行頭の Enter：見出し・箇条書きは下の行に残る（上に空の行）
  for (const [src, want] of [['[番号1]題\n本文\n', '\n[番号1]題\n本文\n'], ['[項目1]あいう\n', '[項目1]\n[項目1]あいう\n'], ['[番号1 改頁]題\n', '\n[番号1 改頁]題\n'], ['[字下げ2]本文です\n', '\n[字下げ2]本文です\n']]) { const e = mkEd(src); e.setCaret({ line: 0, seg: 0, off: 0 }); e.enter(); if (body(e.doc) !== want || e.caret.line !== 1) bad('Enter at line start keeps the line', { src, got: body(e.doc) }); }
  // 4 画面：表のセルの空きをクリック → そのセルの字の末尾（全角空白で埋めない）。題なしの囲みは F7 の帯にある
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  await page.evaluate(() => { const app = FZ.app; app.ed.setDoc(FZ.parse('#fzk 2\n---\n前\n#表 列 0,10,20,30 様式 格子\n| 項目 | 案A | 案B |\n| 費用 | | 300 |\n| 期間 | 3か月 | |\n後\n')); app.render(); });
  const pt = (col, row) => page.evaluate(([col, row]) => { const geo = FZ.app.ed.lay.geo; const pg = document.querySelector('#pages svg'); const r = pg.getBoundingClientRect(); const s = r.width / geo.W; return { x: r.left + (geo.left + col * geo.cw) * s, y: r.top + (geo.top + (geo.bodyTop + row + 0.5) * geo.ch) * s }; }, [col, row]);
  let p = await pt(15, 2); await page.mouse.click(p.x, p.y); await page.keyboard.type('200'); p = await pt(27, 2); await page.mouse.click(p.x, p.y); const c1 = await page.evaluate(() => FZ.app.ed.caret);
  p = await pt(25, 3); await page.mouse.click(p.x, p.y); await page.keyboard.type('6か月'); await page.waitForTimeout(80);
  let r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  if (!r.includes('| 費用 | 200 | 300 |') || !r.includes('| 期間 | 3か月 | 6か月 |') || c1.seg !== 2 || c1.off !== 3 || c1.vcol != null) bad('click in a table cell lands at the cell text', { r, c1 });
  r = await page.evaluate(() => { FZ.app.run('insertGroup'); const has = !!document.querySelector('#sub .ch[data-cmd="hd:articleN"]'); FZ.app.ed.setDoc(FZ.parse('#fzk 2\n---\nメモ\n')); FZ.app.render(); FZ.app.run('hd:articleN'); return { has, s: FZ.serialize(FZ.app.ed.doc).split('---\n')[1] }; });
  if (!r.has || r.s !== 'メモ\n#囲み ×1 見出しなし\n[項目1]\n') bad('untitled box from the F7 band (nothing selected: an empty frame below)', r);
  r = await page.evaluate(() => FZ.guideText().includes('#囲み ×2 見出しなし') && FZ.guideText().includes('囲みの外へ出る')); if (!r) bad('manual shows the untitled box and how to leave it');
  console.log(`110c3 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
