/* 1.0.10d：GUI 化 — 流れ図を紙面で直接いじる（クリック・つまみ・辺の点でつなぐ・ダブルクリックで足す／文字・囲んで選ぶ・揃え・高さ・図の外で本文へ）、
 * 表の編集（行・列の挿入と削除、列の境のドラッグ、セルの範囲の網・揃え・消去・写し）、右クリックで帯がその場の操作に切り替わる */
const { chromium } = require('playwright'); const path = require('path');
for (const f of ['fz-core', 'fz-figure', 'fz-editor', 'fz-styles', 'fz-table']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ; let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const body = d => FZ.serialize(d).split('---\n')[1];
const mkEd = src => { const e = new FZ.Editor(); e.onChange = () => { }; e.onCaret = () => { }; e.setDoc(FZ.parse('#fzk 2\n---\n' + src)); return e; };
const T0 = '前\n#表 列 0,10,20,30 様式 格子\n| 項目 | 案A | 案B |\n| 費用 | 100 | 300 |\n| 期間 | 3か月 | 6か月 |\n後\n';
(async () => {
  // 1 表の操作（中身）：様式どおりの表は様式のまま、行・列を足す・消す。往復が安定
  const cases = [
    ['insertRow', true, 1, 0, '| 項目 | 案A | 案B |\n|  |  |  |\n| 費用 | 100 | 300 |'], ['insertRow', false, 1, 1, '#表 列 0,10,20,30 様式 格子\n|  |  |  |\n| 項目 |'], ['insertRow', true, 3, 0, '| 期間 | 3か月 | 6か月 |\n|  |  |  |\n後'],
    ['deleteRow', null, 2, 0, '| 項目 | 案A | 案B |\n| 期間 |'], ['insertCol', true, 2, 1, '#表 列 0,10,15,20,30 様式 格子\n| 項目 | 案A |  | 案B |'], ['insertCol', false, 2, 0, '#表 列 0,5,10,20,30 様式 格子\n|  | 項目 |'],
    ['deleteCol', null, 2, 1, '#表 列 0,20,30 様式 格子\n| 項目 | 案B |'], ['deleteCol', null, 2, 0, '#表 列 0,20,30 様式 格子\n| 案A | 案B |']];
  for (const [fn, arg, line, seg, want] of cases) { const e = mkEd(T0); e.setCaret({ line, seg, off: 0 }); FZ.tbl[fn](e, arg); const b = body(e.doc); const s1 = FZ.serialize(e.doc); if (!b.includes(want) || FZ.serialize(FZ.parse(s1)) !== s1) bad('table op ' + fn + ' ' + arg + ' @' + line + ':' + seg, b); e.undo(); if (body(e.doc) !== body(FZ.parse('#fzk 2\n---\n' + T0))) bad('table op undo ' + fn, body(e.doc)); }
  { const e = mkEd(T0); e.setCaret({ line: 2, seg: 1, off: 0 }); const I = FZ.tbl.info(e); FZ.tbl.moveBoundary(e, I, 1, 14); if (!body(e.doc).includes('#表 列 0,14,20,30 様式 格子')) bad('move boundary', body(e.doc)); const I2 = FZ.tbl.info(e); FZ.tbl.moveBoundary(e, I2, 3, 36); if (!body(e.doc).includes('#表 列 0,14,20,36 様式 格子')) bad('move right edge', body(e.doc)); }
  { const e = mkEd(T0); e.setCaret({ line: 2, seg: 0, off: 0 }); FZ.tbl.deleteTable(e); if (body(e.doc) !== '前\n\n後\n') bad('delete table', body(e.doc)); }
  { const e = mkEd(T0); const R = FZ.tbl.rectOf(e, { line: 2, col: 1 }, { line: 3, col: 2 }); if (FZ.tbl.cellsText(e, R) !== '100\t300\n3か月\t6か月') bad('cells text', FZ.tbl.cellsText(e, R)); FZ.tbl.alignCells(e, R, 'right'); FZ.tbl.clearCells(e, FZ.tbl.rectOf(e, { line: 3, col: 1 }, { line: 3, col: 1 })); const b = body(e.doc); if (!b.includes('[列揃え左右右]| 費用 | 100 | 300 |') || !b.includes('| 期間 |  | 6か月 |')) bad('cells align / clear', b); }
  // 2 画面
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const load = src => page.evaluate(src => { const app = FZ.app; if (app.st.mode !== 'text') app.run('exitMode'); app.ed.setDoc(FZ.parse(src)); app.st.zoom = 'width'; app.render(); window.scrollTo(0, 0); document.getElementById('main').scrollTop = 0; }, src);
  const pt = (col, row) => page.evaluate(([col, row]) => { const geo = FZ.app.ed.lay.geo; const pg = document.querySelector('#pages svg'); const r = pg.getBoundingClientRect(); const s = r.width / geo.W; return { x: r.left + (geo.left + col * geo.cw) * s, y: r.top + (geo.top + (geo.bodyTop + row) * geo.ch) * s }; }, [col, row]);
  const fig = () => page.evaluate(() => JSON.parse(JSON.stringify(FZ.app.ed.doc.lines.find(l => l.attrs.figure).attrs.figure)));
  const S = () => page.evaluate(() => ({ mode: FZ.app.st.mode, sel: FZ.app.st.fig ? FZ.app.st.fig.sel : null, multi: FZ.app.st.fig ? [...FZ.app.st.fig.multi] : [], arrow: FZ.app.st.fig ? FZ.app.st.fig.selArrow : null, group: FZ.app.st.group, armed: FZ.app.st.armed }));
  const FIG = '#fzk 2\n---\n前の段落\n#箱 1 0,1 8x3 細 無 受付\n#箱 2 12,1 8x3 細 無 審査\n#箱 3 24,5 8x3 細 無 承認\n#矢印 1→2 細\n[図10]\n後の段落\n';
  await load(FIG); const Y0 = 1; // 図は 2 行目から（前の段落が 0 行目）
  const fp = (x, y) => pt(x, Y0 + y);
  // クリックで選ぶ → つまみ（右下）をドラッグで大きく
  let p = await fp(4, 2.5); await page.mouse.click(p.x, p.y); let r = await S(); if (r.mode !== 'fig' || r.sel !== 1) bad('click selects a box', r);
  p = await fp(8, 4); let q = await fp(11, 6); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(40);
  let f = await fig(); if (f.boxes[0].w !== 11 || f.boxes[0].h !== 5) bad('drag the corner handle resizes', f.boxes[0]);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(30); f = await fig(); if (f.boxes[0].w !== 8 || f.boxes[0].h !== 3) bad('resize undoes in one step', f.boxes[0]);
  // 箱 2 の下の点から箱 3 へドラッグ → 矢印
  p = await fp(16, 2.5); await page.mouse.click(p.x, p.y); p = await fp(16, 4.55); q = await fp(27, 6.5); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(40);
  f = await fig(); r = await S(); if (!f.arrows.some(a => a.from === 2 && a.to === 3) || r.arrow == null) bad('drag from a port to another box connects them', { arrows: f.arrows, r });
  // 矢印をダブルクリック → その場でラベル
  const mid = await page.evaluate(() => { const F = FZ.app.ed.doc.lines[1].attrs.figure; const k = F.arrows.findIndex(a => a.from === 2 && a.to === 3); return FZ.figureArrowMid(F, k); });
  p = await fp(mid.x, mid.y); await page.mouse.dblclick(p.x, p.y); await page.waitForTimeout(40); r = await page.evaluate(() => !!document.querySelector('textarea.inl'));
  if (!r) bad('double-click an arrow opens the label editor'); else { await page.keyboard.type('はい'); await page.keyboard.press('Enter'); await page.waitForTimeout(40); f = await fig(); if (!f.arrows.some(a => a.from === 2 && a.to === 3 && a.label === 'はい')) bad('arrow label typed in place', f.arrows); }
  // 空いた所をダブルクリック → 箱を足して、その場で文字（Shift+Enter で改行）
  p = await fp(5, 8); await page.mouse.dblclick(p.x, p.y); await page.waitForTimeout(60); r = await page.evaluate(() => document.activeElement && document.activeElement.className);
  await page.keyboard.type('差し戻し'); await page.keyboard.press('Shift+Enter'); await page.keyboard.type('理由を記す'); await page.keyboard.press('Enter'); await page.waitForTimeout(40);
  f = await fig(); const nb = f.boxes.find(b => b.id === 4); if (r !== 'inl' || !nb || nb.text !== '差し戻し\n理由を記す' || nb.x !== 1 || nb.h < 3) bad('double-click empty adds a box and types in place', { r, nb });
  // 箱をダブルクリック → 文字を直す、Esc で取り消し
  p = await fp(4, 2.5); await page.mouse.dblclick(p.x, p.y); await page.waitForTimeout(40); await page.keyboard.type('XYZ'); await page.keyboard.press('Escape'); await page.waitForTimeout(40); f = await fig(); if (f.boxes[0].text !== '受付') bad('Esc cancels in-place edit', f.boxes[0]);
  // 囲むドラッグで箱 1 と 2 を選ぶ → 上を揃える（帯のタイル）→ Delete で 2 つ消す → 取り消し
  await page.evaluate(() => { const F = FZ.app.ed.doc.lines[1].attrs.figure; F.boxes[1].y = 2; FZ.app.ed.relayout(); FZ.app.render(); });
  p = await fp(-0.5, 0.3); q = await fp(21, 5.6); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(40);
  r = await S(); if (r.multi.sort().join() !== '1,2') bad('rubber band selects boxes', r);
  await page.click('#sub .ch[data-cmd="fg:al:top"]'); await page.waitForTimeout(40); f = await fig(); if (f.boxes[0].y !== 1 || f.boxes[1].y !== 1) bad('align top from the band', f.boxes.map(b => b.y));
  await page.click('#sub .ch[data-cmd="fg:k:thick"]'); await page.waitForTimeout(30); f = await fig(); if (f.boxes[0].kind !== 'thick' || f.boxes[1].kind !== 'thick') bad('line kind chip applies to all selected', f.boxes.map(b => b.kind));
  await page.click('#sub .ch[data-cmd="fg:s:deep"]'); await page.waitForTimeout(30); f = await fig(); if (f.boxes[0].shade !== 'deep') bad('shade chip', f.boxes[0]);
  await page.keyboard.press('Delete'); await page.waitForTimeout(30); f = await fig(); if (f.boxes.some(b => b.id === 1 || b.id === 2)) bad('Delete removes all selected', f.boxes.map(b => b.id));
  await page.keyboard.press('Control+z'); await page.waitForTimeout(30); f = await fig(); if (f.boxes.length !== 4) bad('undo delete', f.boxes.length);
  // Shift+クリックで足す、まとめてドラッグ
  p = await fp(4, 2.5); await page.mouse.click(p.x, p.y); q = await fp(16, 2.5); await page.keyboard.down('Shift'); await page.mouse.click(q.x, q.y); await page.keyboard.up('Shift'); r = await S(); if (r.multi.sort().join() !== '1,2') bad('Shift+click adds to selection', r);
  const f0 = await fig(); p = await fp(4, 2.5); q = await fp(6, 3.5); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(40);
  f = await fig(); if (f.boxes[0].x !== f0.boxes[0].x + 2 || f.boxes[1].x !== f0.boxes[1].x + 2 || f.boxes[0].y !== f0.boxes[0].y + 1) bad('drag moves all selected boxes', f.boxes.slice(0, 2));
  // 図の下端のつまみで高さ
  const h0 = (await fig()).h; const W2 = await page.evaluate(() => { const lm = FZ.app.ed.lay.lineMap[1]; return (lm.segs[0].rows[0].right - lm.segs[0].rows[0].left) / 2; }); p = await fp(W2, h0); q = await fp(W2, h0 + 3); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 3 }); await page.mouse.up(); await page.waitForTimeout(40);
  f = await fig(); if (f.h !== h0 + 3) bad('drag the bottom handle changes the height', [h0, f.h]);
  // 右クリック：箱を選ぶ（帯は図の帯のまま）
  p = await fp(27, 6.5); await page.mouse.click(p.x, p.y, { button: 'right' }); await page.waitForTimeout(30); r = await S(); if (r.sel !== 3 || r.mode !== 'fig' || !(await page.$('#sub .ch[data-cmd="fg:al:left"]'))) bad('right-click selects the box and the band shows figure tools', r);
  // 図の外をクリック：本文へ戻ってそこにカーソル
  const after = await page.evaluate(() => FZ.app.ed.lay.lineMap[2].rows[0].y); p = await pt(2, after + 0.5); await page.mouse.click(p.x, p.y); await page.waitForTimeout(40);
  r = await page.evaluate(() => ({ mode: FZ.app.st.mode, line: FZ.app.ed.caret.line })); if (r.mode !== 'text' || r.line !== 2) bad('clicking outside the figure returns to the text there', r);
  // 3 表：右クリックで「表の編集」の帯が構え、キーで行を足す
  await load('#fzk 2\n---\n前\n#表 列 0,10,20,30 様式 格子\n| 項目 | 案A | 案B |\n| 費用 | 100 | 300 |\n| 期間 | 3か月 | 6か月 |\n後\n');
  p = await pt(15, 2.5); await page.mouse.click(p.x, p.y, { button: 'right' }); await page.waitForTimeout(40); r = await S();
  if (r.group !== 'tedit') bad('right-click in a table shows the table band', r);
  await page.evaluate(() => { window.__arm = FZ.app.st.group; }); await page.keyboard.press('f'); await page.waitForTimeout(40); r = await page.evaluate(() => ({ s: FZ.serialize(FZ.app.ed.doc).split('---\n')[1], c: FZ.app.ed.caret }));
  if (!r.s.includes('| 費用 | 100 | 300 |\n|  |  |  |\n| 期間 |') || r.c.line !== 3) bad('band key F inserts a row below', r);
  await page.keyboard.type('合計'); await page.keyboard.press('Tab'); await page.keyboard.type('400'); await page.waitForTimeout(30);
  r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]); if (!r.includes('| 合計 | 400 |  |')) bad('type in the new row', r);
  // 列の境をドラッグ
  p = await pt(10, 1.5); r = await page.evaluate(() => getComputedStyle(document.getElementById('pages')).cursor); await page.mouse.move(p.x, p.y); await page.waitForTimeout(30); const cur = await page.evaluate(() => document.getElementById('pages').style.cursor);
  q = await pt(13.2, 1.5); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(40);
  r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]); if (cur !== 'col-resize' || !r.includes('#表 列 0,13,20,30 様式 格子')) bad('drag a column border', { cur, r: r.slice(0, 60) });
  // セルをドラッグで範囲 → 右クリック → 1（薄網）→ 範囲を Delete で消す
  p = await pt(15, 2.5); q = await pt(25, 4.5); await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(40);
  r = await page.evaluate(() => FZ.app.st.cells); if (!r || r.a.line !== 2 || r.b.line !== 4 || r.a.col !== 1 || r.b.col !== 2) bad('drag selects a cell range', r);
  p = await pt(20, 3.5); await page.mouse.click(p.x, p.y, { button: 'right' }); await page.waitForTimeout(30); await page.evaluate(() => { window.__arm = FZ.app.st.group; }); await page.keyboard.press('1'); await page.waitForTimeout(40);
  r = await page.evaluate(() => ({ fills: FZ.app.ed.doc.fills.filter(f => f.shade === 'gray' && f.from === 2 && f.to === 4).map(f => [f.col, f.cols]), cells: !!FZ.app.st.cells }));
  if (!r.fills.length || r.fills[0][0] !== 13 || r.fills[0][1] !== 17 || !r.cells) bad('band 1 shades the selected cells', r);
  r = await page.evaluate(() => { let got = ''; const dt = new DataTransfer(); const ev = new ClipboardEvent('copy', { clipboardData: dt, bubbles: true, cancelable: true }); document.getElementById('ta').dispatchEvent(ev); got = dt.getData('text/plain'); return got; });
  if (r !== '100\t300\n400\t\n3か月\t6か月') bad('Ctrl+C copies the cells as tab-separated text', r);
  await page.keyboard.press('Delete'); await page.waitForTimeout(40); r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  if (!r.includes('| 費用 |  |  |') || !r.includes('| 合計 |  |  |') || !r.includes('| 期間 |  |  |')) bad('Delete clears the selected cells', r);
  // 帯の「表の編集」は F8→U→I からも
  r = await page.evaluate(() => { FZ.app.ed.setCaret({ line: 2, seg: 1, off: 0 }); FZ.app.run('tableGroup'); return FZ.app.st.group === 'table' && FZ.app.GROUPS.table.parent === 'tedit' && !!document.querySelector('#sub .ch.back'); }); if (!r) bad('table style band goes back to the 表 band (F8)');
  // 4 取説・取扱説明書に載る
  r = await page.evaluate(() => { const m = FZ.guideText(); return ['右クリック', '列の境', 'ダブルクリック', '辺の点'].filter(w => !m.includes(w)); }); if (r.length) bad('manual mentions the GUI operations', r);
  console.log(`110d fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
