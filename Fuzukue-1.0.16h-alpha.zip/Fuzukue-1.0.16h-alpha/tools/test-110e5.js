/* 1.0.10e.6：紙面とツリーの行き来 — ツリーでも同じ F キーのメニュー、コマンドは選んだ節に効く、欄はツリーのまま、紙面だけの道具は紙面へ、図表の節（名前・表示・一括）、図表をダブルクリックで紙面のその場へ、Ctrl+Shift+O で同じ節へ戻る */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAQAAAADCAYAAAC09K7GAAAAFUlEQVR42mNgYPj/n4EBQgABMwDiABDqA/2Kv/0zAAAAAElFTkSuQmCC';
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。\n#図版 g1 図 売上の推移 a.png\n[項目1]国内\n[項目1]海外\n[番号1]目標\n#表 列 0,10,20 様式 格子\n| 項目 | 値 |\n| 売上 | 300 |\n===\n#添付 a.png image/png\n' + PNG + '\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  await page.evaluate(async src => { await FZ.app.loadText('#fzk 2\n---\n' + src, 'x.fzk', null); }, SRC); await page.waitForTimeout(150);
  const S = () => page.evaluate(() => ({ mode: FZ.app.st.mode, group: FZ.app.st.group, sel: (() => { const v = FZ.app.st.tree.view; const k = FZ.app.st.tree.sel; const n = v && v.shown.find(n => (n.fig || n.obj || 'root') === k); return n ? n.text : null; })(), names: [...document.querySelectorAll('#tree .tn')].map(g => g.textContent.replace(/表示|閉じる/g, '')) }));
  const box = text => page.evaluate(t => { const g = [...document.querySelectorAll('#tree .tn')].find(g => g.textContent.includes(t)); if (!g) return null; g.querySelector('rect').scrollIntoView({ block: 'start' }); document.getElementById('treePane').scrollTop -= 60; const r = g.querySelector('rect').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }, text);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); let r = await S();
  // 1 図表の節：名前だけ（表と図版）。本文は出さない
  if (!r.names.some(t => /^図 1　売上の推移/.test(t)) || !r.names.some(t => /^［表］/.test(t)) || r.names.some(t => /売上は伸びた/.test(t))) bad('fig and table nodes by name', r.names);
  // 2 一括で表示・閉じる
  await page.evaluate(() => FZ.app.run('tvf:open')); await page.waitForTimeout(80); r = await page.evaluate(() => ({ n: document.querySelectorAll('#tree svg.tfig').length, img: document.querySelectorAll('#tree svg.tfig image').length, btn: [...document.querySelectorAll('#tree .tshow text')].map(t => t.textContent) }));
  if (r.n !== 2 || r.img < 1 || !r.btn.every(t => t === '閉じる')) bad('show all figures', r);
  r = await page.evaluate(() => { const g = document.querySelector('#tree svg.tfig'); const b = g.getBoundingClientRect(); return { w: b.width, mainW: document.getElementById('main').clientWidth }; }); if (!(r.w > 20 && r.w < r.mainW)) bad('figure fits the width', r);
  await page.evaluate(() => FZ.app.run('tvf:close')); await page.waitForTimeout(80); r = await page.evaluate(() => document.querySelectorAll('#tree svg.tfig').length); if (r !== 0) bad('close all figures', r);
  // 3 1 つだけ表示（「表示」を押す）
  let b = await box('［表］'); { const sb = await page.evaluate(() => { const g = [...document.querySelectorAll('#tree g.tn')].find(g => g.textContent.includes('［表］')); const r = g.querySelector('.tshow').getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; }); await page.mouse.click(sb.x, sb.y); } await page.waitForTimeout(80); r = await page.evaluate(() => document.querySelectorAll('#tree svg.tfig').length); if (r !== 1) bad('show one figure', r);
  // 4 同じ F キー：F2 でファイルのグループ、Esc でツリーの帯に戻る（ツリーのまま）
  await page.keyboard.press('F2'); await page.waitForTimeout(40); r = await page.evaluate(() => ({ mode: FZ.app.st.mode, g: FZ.app.st.group, save: !!document.querySelector('#sub .ch[data-cmd="save"]'), keys: [...document.querySelectorAll('#fkeys .fk')].map(x => x.textContent).join('|') }));
  if (r.mode !== 'tree' || r.g !== 'file' || !r.save || !/ファイル/.test(r.keys) || /弟/.test(r.keys)) bad('F2 opens the file group in the tree', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(40); r = await page.evaluate(() => ({ mode: FZ.app.st.mode, g: FZ.app.st.group, band: !!document.querySelector('#sub .ch[data-cmd="tv:after"]') })); if (r.mode !== 'tree' || r.g || !r.band) bad('Esc closes the group and returns to the tree band', r);
  // 5 文字のコマンドは選んだ節の文字全体に（F4 → 太字）
  b = await box('海外'); await page.mouse.click(b.x + 30, b.y + 12); await page.keyboard.press('F5'); await page.waitForTimeout(30); await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="bold"]'); el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); }); await page.waitForTimeout(60);
  r = await page.evaluate(() => { const ln = FZ.app.ed.doc.lines.find(l => l.segs[0].text === '海外'); return { all: ln.segs[0].marks.every(m => m & FZ.M.BOLD), mode: FZ.app.st.mode }; }); if (!r.all || r.mode !== 'tree') bad('F4 bold applies to the node text', r);
  // 6 段落のコマンド（F5）：選んだ節の行の種類が変わる
  const nk = await page.evaluate(() => FZ.app.keysOf('h:num1') || FZ.app.keysOf('num1') || ''); 
  // 7 挿入（F7 → 区切り線）は選んだ節の後ろに
  await page.keyboard.press('F7'); await page.waitForTimeout(30); await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="hr"]'); el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); }); await page.waitForTimeout(60);
  r = await page.evaluate(() => { const L = FZ.app.ed.doc.lines; const i = L.findIndex(l => l.segs[0].text === '海外'); return { next: L[i + 1] && !!L[i + 1].attrs.hr, mode: FZ.app.st.mode }; }); if (!r.next || r.mode !== 'tree') bad('F7 insert goes after the selected node, staying in the tree', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(40);
  // 8 欄はツリーのまま（F9 → 体系）
  await page.keyboard.press('F9'); await page.waitForTimeout(30); await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="scheme"]'); el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); }); await page.waitForTimeout(60);
  r = await page.evaluate(() => ({ mode: FZ.app.st.mode, form: FZ.app.st.form })); if (r.mode !== 'tree' || r.form !== 'scheme') bad('forms open in the tree', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(40);
  // 9 紙面だけの道具（網掛け。1.0.10q で罫線を引く機能はやめた）は紙面へ
  await page.keyboard.press('F6'); await page.waitForTimeout(30); await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="fillMode"]'); el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); }); await page.waitForTimeout(60);
  r = await page.evaluate(() => FZ.app.st.mode); if (r !== 'fill') bad('paper-only tool goes to the paper', r); await page.keyboard.press('Escape'); await page.waitForTimeout(40);
  // 10 行って帰る：表をダブルクリック → 紙面の表の中、Ctrl+Shift+O → 表の節
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); b = await box('［表］'); await page.mouse.dblclick(b.x + 40, b.y + 40); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ mode: FZ.app.st.mode, inTable: FZ.inTable(FZ.app.ed.doc, FZ.app.ed.caret.line) })); if (r.mode !== 'text' || !r.inTable) bad('double-click a table goes to the table on the paper', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); r = await S(); if (r.mode !== 'tree' || !/^［表］/.test(r.sel || '')) bad('back to the same node', r);
  // 11 図版をダブルクリック（名前の行）→ 題を直す、中身をダブルクリック → 図表の設定（紙面）
  await page.evaluate(() => FZ.app.run('tvf:open')); await page.waitForTimeout(80); b = await box('図 1'); await page.mouse.dblclick(b.x + 40, b.y + 12); await page.waitForTimeout(60); await page.keyboard.press('Control+a'); await page.keyboard.type('売上と利益'); await page.keyboard.press('Enter'); await page.waitForTimeout(60);
  r = await page.evaluate(() => FZ.app.ed.figList()[0].fg.title); if (r !== '売上と利益') bad('double-click the name edits the figure title', r);
  b = await box('図 1'); await page.mouse.dblclick(b.x + 30, b.y + 50); await page.waitForTimeout(80); r = await page.evaluate(() => ({ mode: FZ.app.st.mode, form: FZ.app.st.form })); if (r.mode !== 'text' || r.form !== 'fig') bad('double-click the figure opens its settings on the paper', r);
  await page.keyboard.press('Escape'); await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80); r = await S(); if (!/^図 1/.test(r.sel || '')) bad('back to the figure node', r);
  // 12 図表は動かさない・消すと図版だけ
  await page.keyboard.press('Delete'); await page.waitForTimeout(60); r = await page.evaluate(() => ({ figs: FZ.app.ed.figList().length, body: FZ.serialize(FZ.app.ed.doc).includes('売上は伸びた') })); if (r.figs !== 0 || !r.body) bad('delete a figure node removes only the figure', r);
  console.log(`110e5 fails=${fails}`); for (const e of errors) console.log(' -', e);
  await browser.close(); process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
