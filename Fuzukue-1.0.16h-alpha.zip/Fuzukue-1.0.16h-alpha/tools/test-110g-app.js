/* 1.0.10g：グラフの画面操作 — Ctrl+G（見本／表から／表のすぐ下から）、帯の欄（種類はその場で、データは Ctrl+Enter）、行と列の入れ替え、図版のクリックで欄、取り消し、帯のタイル、印刷の網 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const load = async src => { await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, src); await page.waitForTimeout(150); };
  const loadMd = async md => { await page.evaluate(async s => { await FZ.app.loadText(FZ.serialize(FZ.fromGfm(s)), 'x.fzk', null); }, md); await page.waitForTimeout(150); }; /* 表は Markdown から起こす */
  const figs = () => page.evaluate(() => FZ.app.ed.figList().map(x => ({ line: x.line, id: x.fg.id, chart: x.fg.chart, title: x.fg.title })));
  /* 見本のグラフ */
  await load('[表題]報告\n本文です。\n'); await page.keyboard.press('Control+End'); await page.keyboard.press('Control+g'); await page.waitForTimeout(250);
  let F = await figs(); if (!(F.length === 1 && F[0].chart && F[0].line === 1)) bad('Ctrl+G inserts sample chart on caret line', F);
  if (!(await page.evaluate(() => FZ.app.st.form === 'chart' && !!document.querySelector('#sub .chgrid input.cg')))) bad('chart form with data grid');
  if (!(await page.evaluate(() => !!document.querySelector('.pg g.figchart g.chart')))) bad('chart drawn on page');
  await page.selectOption('#sub select[name="type"]', 'line'); await page.waitForTimeout(200); F = await figs(); if (F[0].chart.type !== 'line') bad('type select applies live', F[0].chart.type);
  await page.evaluate(() => { const a1 = document.querySelector('#sub .chgrid input.cg[data-r="0"][data-c="0"]'); const dt = new DataTransfer(); dt.setData('text/plain', '\t1月\t2月\t3月\n件数\t5\t3\t8\n目標\t4\t4\t4'); a1.focus(); a1.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); }); await page.waitForTimeout(200); /* 1.0.11e：データは表（A1 に貼ると表ごと置き換え） */
  F = await figs(); if (!(F[0].chart.cats.join() === '1月,2月,3月' && F[0].chart.series.length === 2 && F[0].chart.series[1].values.join() === '4,4,4')) bad('data via paste into A1 of the grid', F[0].chart);
  if (!(await page.evaluate(() => FZ.app.st.form === 'chart'))) bad('form stays open after data');
  await page.click('#sub button[data-act="swap"]'); await page.waitForTimeout(150); F = await figs(); if (!(F[0].chart.cats.join() === '件数,目標' && F[0].chart.series.length === 3)) bad('swap rows/cols', F[0].chart);
  await page.fill('#sub input[name="title"]', '月別件数'); await page.keyboard.press('Enter'); await page.waitForTimeout(150); F = await figs(); if (F[0].title !== '月別件数' || await page.evaluate(() => FZ.app.st.form)) bad('Enter applies title and closes', F[0].title);
  /* 図版のクリックでグラフの欄 */
  const r = await page.evaluate(() => { const el = document.querySelector('.pg g.figchart rect'); const b = el.getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top + b.height / 2 }; }); await page.mouse.click(r.x, r.y); await page.waitForTimeout(200);
  if (!(await page.evaluate(() => FZ.app.st.form === 'chart'))) bad('click on chart opens chart form');
  await page.keyboard.press('Escape'); await page.waitForTimeout(80);
  /* 取り消し */
  for (let k = 0; k < 6; k++) await page.keyboard.press('Control+z'); await page.waitForTimeout(150); F = await figs(); if (F.length) bad('undo removes chart', F.length);
  /* 表の中で Ctrl+G：表から（表はそのまま、図版は表のすぐ下の行） */
  await loadMd('前の文\n\n|  | 東 | 西 |\n| --- | --- | --- |\n| 売上 | 10 | 20 |\n| 利益 | 1 | 2 |\n\n後の文\n'); const T0 = await page.evaluate(() => { const d = FZ.app.ed.doc; let a = d.lines.findIndex((_, i) => FZ.inTable(d, i)); let b = a; while (FZ.inTable(d, b + 1)) b++; return { a, b }; }); await page.evaluate(a => { FZ.app.ed.setCaret({ line: a + 1, seg: 0, off: 0 }); }, T0.a); await page.keyboard.press('Control+g'); await page.waitForTimeout(250);
  F = await figs(); const tl = await page.evaluate(() => FZ.app.ed.doc.lines.length);
  if (!(F.length === 1 && F[0].line === T0.b + 1 && F[0].chart.cats.join() === '東,西' && F[0].chart.series.map(s => s.name).join() === '売上,利益')) bad('table -> chart below table', { F, tl, T0 });
  if (!(await page.evaluate(t => FZ.inTable(FZ.app.ed.doc, t.a) && FZ.inTable(FZ.app.ed.doc, t.b), T0))) bad('table kept');
  await page.keyboard.press('Escape');
  /* 表が最後の行：新しい行を足してそこへ。表のすぐ下の空行でも表から */
  await loadMd('| 月 | 件数 |\n| --- | --- |\n| 1月 | 3 |\n| 2月 | 5 |\n| 3月 | 4 |\n'); const nL = await page.evaluate(() => { const d = FZ.app.ed.doc; while (d.lines.length > 1 && !FZ.inTable(d, d.lines.length - 1) && !d.lines[d.lines.length - 1].segs.some(s => s.text)) d.lines.pop(); FZ.app.ed.relayout && FZ.app.ed.relayout(); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); return d.lines.length; }); await page.keyboard.press('Control+g'); await page.waitForTimeout(250);
  F = await figs(); if (!(F.length === 1 && F[0].line === nL && F[0].chart.series[0].name === '件数' && F[0].chart.cats.length === 3)) bad('table at end -> new line', { F, nL });
  await page.keyboard.press('Escape');
  await loadMd('|  | A | B |\n| --- | --- | --- |\n| x | 1 | 2 |\n\n本文\n'); const T2 = await page.evaluate(() => { const d = FZ.app.ed.doc; let b = d.lines.findIndex((_, i) => FZ.inTable(d, i)); while (FZ.inTable(d, b + 1)) b++; if (d.lines[b + 1].segs.some(s => s.text)) FZ.app.ed.insertLine(b + 1, FZ.newLine()); FZ.app.ed.setCaret({ line: b + 1, seg: 0, off: 0 }); return b; }); await page.keyboard.press('Control+g'); await page.waitForTimeout(250);
  F = await figs(); if (!(F.length === 1 && F[0].line === T2 + 1 && F[0].chart.cats.join() === 'A,B')) bad('blank line under table -> chart from table', { F, T2 }); await page.keyboard.press('Escape');
  /* 数の無い表 */
  await loadMd('| a | b |\n| --- | --- |\n| c | d |\n\n後\n'); await page.evaluate(() => { FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); }); await page.keyboard.press('Control+g'); await page.waitForTimeout(200);
  F = await figs(); if (F.length) bad('table without numbers refuses', F);
  /* 帯：挿入のタイルと 1 段 */
  await page.keyboard.press('F7'); await page.waitForTimeout(100);
  const band = await page.evaluate(() => ({ tile: !!document.querySelector('#sub .ch[data-cmd="chart"]'), h: document.querySelector('#sub').offsetHeight, rows: new Set([...document.querySelectorAll('#sub .ch')].map(e => Math.round(e.getBoundingClientRect().top))).size }));
  if (!band.tile || band.rows > 3) bad('insert band has chart tile, 3 rows at 1100px', band);
  await page.keyboard.press('Escape');
  /* 図版の設定（F7→G）もグラフならグラフの欄 */
  await load('一行目\n#グラフ g 図 円 構成\n#データ |  | A | B | C |\n#データ | x | 3 | 1 | 1 |\n'); await page.evaluate(() => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); FZ.app.run('figEdit'); }); await page.waitForTimeout(150);
  if (!(await page.evaluate(() => FZ.app.st.form === 'chart'))) bad('figEdit routes to chart form');
  await page.keyboard.press('Escape');
  /* 印刷：網の矩形は画像に（扇も切り抜いた矩形で） */
  const pr = await page.evaluate(() => { const L = FZ.app.ed.lay; const div = document.createElement('div'); div.innerHTML = FZ.renderPage(L, 0, { mono: true }); document.body.append(div); const svg = div.querySelector('svg'); const n = FZ.rasterizeFills(svg, 2); const left = svg.querySelectorAll('[fill^="url(#s_"]').length; const clipped = svg.querySelectorAll('image[clip-path]').length; div.remove(); return { n, left, clipped }; });
  if (!(pr.n >= 2 && pr.left === 0 && pr.clipped >= 2)) bad('print: pattern fills rasterized incl. clipped wedges', pr);
  /* ツリー：図表の「表示」でグラフが見える */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(200); await page.evaluate(() => FZ.app.run('tvf:open')); await page.waitForTimeout(300);
  if (!(await page.evaluate(() => !!document.querySelector('#tree g.chart')))) bad('tree shows chart when figures opened');
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(100);
  console.log('110g-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
