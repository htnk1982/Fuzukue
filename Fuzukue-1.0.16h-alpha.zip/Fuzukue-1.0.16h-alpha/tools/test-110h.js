/* 1.0.10h：メニュー再編（F4 構造・F5 文字・F6 配置、R1・R2・R4〜R6）と、構造の操作を紙面でも（G1・G4）、AI に渡す（写す）、F10 にツリーの深さ・図表・形 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。国内は横ばい。\n次の段落。\n[番号1]課題\n為替が重い。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  await page.evaluate(() => { window.__clip = null; try { Object.defineProperty(navigator, 'clipboard', { value: { writeText: t => { window.__clip = t; return Promise.resolve(); } }, configurable: true }); } catch (e) { } });
  const load = async (src = SRC) => { await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, src); await page.waitForTimeout(120); };
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const caret = (line, off) => page.evaluate(([l, o]) => FZ.app.ed.setCaret({ line: l, seg: 0, off: o }), [line, off]);
  await load();
  /* F キーの並び（構造 → 字 → 置き方 …）と既定の帯 */
  let r = await page.evaluate(() => [...document.querySelectorAll('#fkeys .fk')].map(e => e.textContent).slice(0, 10).join(','));
  if (r !== 'F1ガイド,F2ファイル,F3編集,F4構造,F5文字,F6配置,F7挿入,F8表,F9書式,F10表示') bad('F-key order (1.0.10q：F8 は表、1.0.11a：F1 ガイド)', r);
  r = await page.evaluate(() => ({ g: FZ.app.st.group, has: !!document.querySelector('#sub .ch[data-cmd="sx:out"]') })); if (!(r.g === 'struct' && r.has)) bad('default band is structure', r);
  r = await page.evaluate(() => Object.keys(FZ.app.GROUPS).includes('para')); if (r) bad('段落 group removed (R1)');
  r = await page.evaluate(() => { const g = FZ.app.GROUPS; const has = (n, c) => g[n].items.some(i => i.cmd === c); return { quoteF6: has('line', 'quote'), codeF6: has('line', 'code'), breakF4: has('line', 'pageBreak'), wideDeep: has('marks', 'wide') && !g.scale, romajiDeep: has('edit', 'romaji') && !g.fix, /* 1.0.10p：改頁は F6、倍角・救済は一段深いメニューをやめた */ decorOrder: !g.decor && g.tedit.items.some(i => i.cmd === 'tableGroup') && has('line', 'headGroup'), /* 1.0.10q：F8 は表、見出し飾りは F6 */ aiF2: has('file', 'aiCopySec') && has('file', 'aiCopyDoc'), viewTree: g.struct.items.some(i => i.segd === 'depth') && g.struct.items.some(i => i.cmd === 'tvf:toggle') && !g.struct.items.some(i => i.msel === 'shape') && !g.view.items.some(i => i.msel === 'depth') }; /* 1.0.10q：ツリーの表示は F4。1.0.11a：段のボタンと図中身、形なし */ });
  if (Object.values(r).some(v => !v)) bad('group contents (R1 R2 R4 R5, F2 AI, F10 tree)', r);
  /* G4：文を選ぶ（Ctrl+クリック）→ Alt+← で段落に */
  const rect = await page.evaluate(() => { const L = FZ.app.ed.lay; const row = L.lineMap[2].segs[0].rows[0]; const svg = document.querySelector('.pg'); const b = svg.getBoundingClientRect(); const k = b.width / L.geo.W; return { x: b.left + (L.geo.left + (row.startCol + 9) * L.geo.cw) * k, y: b.top + (L.geo.top + (L.geo.bodyTop + row.y + 0.5) * L.geo.ch) * k }; });
  await page.keyboard.down('Control'); await page.mouse.click(rect.x, rect.y); await page.keyboard.up('Control'); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const s = FZ.app.ed.sel(); return s && FZ.app.ed.doc.lines[2].segs[0].text.slice(s.a.off, s.b.off); }); if (r !== '海外が牽引した。') bad('Ctrl+click selects the sentence', r);
  await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(80); r = await body();
  if (!r.includes('売上は伸びた。\n海外が牽引した。\n国内は横ばい。')) bad('Alt+← on sentence splits paragraph', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60);
  /* 文を選んで Alt+↑：段落の中で並べ替え（選びは付いて行く） */
  await caret(2, 9); await page.evaluate(() => FZ.app.run('selSent')); await page.keyboard.press('Alt+ArrowUp'); await page.waitForTimeout(80); r = await body();
  if (!r.includes('海外が牽引した。売上は伸びた。国内は横ばい。')) bad('Alt+↑ on sentence reorders', r);
  r = await page.evaluate(() => { const s = FZ.app.ed.sel(); return s && FZ.app.ed.doc.lines[2].segs[0].text.slice(s.a.off, s.b.off); }); if (r !== '海外が牽引した。') bad('selection follows the moved sentence', r);
  await page.keyboard.press('Alt+ArrowRight'); await page.waitForTimeout(80); r = await body(); if (!/\[項目1\]海外が牽引した。/.test(r)) bad('Alt+→ on sentence makes a list item', r);
  await load();
  /* 種類（F4→3）で文を取り出す */
  await caret(2, 9); await page.evaluate(() => FZ.app.run('selSent')); await page.keyboard.press('F4'); await page.keyboard.press('3'); await page.waitForTimeout(80); r = await body();
  if (!/\[番号2\]海外が牽引した。/.test(r) || !r.includes('売上は伸びた。\n')) bad('F4→3 with sentence selected extracts it as a heading', r);
  await load();
  /* G1：段落で Alt+→ は前の段落の文に、Alt+← は見出しに */
  await caret(3, 1); await page.keyboard.press('Alt+ArrowRight'); await page.waitForTimeout(80); r = await body(); if (!r.includes('国内は横ばい。次の段落。')) bad('Alt+→ on paragraph joins previous', r);
  await page.keyboard.press('Control+z'); await caret(3, 1); await page.keyboard.press('Alt+ArrowLeft'); await page.waitForTimeout(80); r = await body(); if (!/\[番号2\]次の段落。/.test(r)) bad('Alt+← on paragraph makes a heading', r);
  await page.keyboard.press('Control+z'); await caret(4, 1); await page.keyboard.press('Alt+ArrowRight'); await page.waitForTimeout(80); r = await body(); if (!/\[番号2\]課題/.test(r)) bad('Alt+→ on heading demotes', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60);
  /* 組替（F4→L 箇条書きに）を紙面で */
  await caret(2, 0); await page.keyboard.press('F4'); await page.keyboard.press('l'); await page.waitForTimeout(80); r = await body(); if (!r.includes('[項目1]売上は伸びた。\n[項目1]海外が牽引した。\n[項目1]国内は横ばい。')) bad('regroup to list on paper', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60);
  /* まとめる：範囲で選んだ 2 行 */
  await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 2, seg: 0, off: 0 }); ed.setCaret({ line: 3, seg: 0, off: 2 }, true); }); await page.keyboard.press('F4'); await page.keyboard.press('m'); await page.waitForTimeout(80); r = await body();
  if (!r.includes('国内は横ばい。次の段落。')) bad('merge selected lines on paper', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60);
  /* 番号・記号の形（F9→N。1.0.10p で F4 から移した） */
  await caret(1, 0); await page.keyboard.press('F9'); await page.keyboard.press('n'); await page.waitForTimeout(80); r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#sub button.pal').length, t: document.querySelector('#sub .ttl').textContent }));
  if (!(r.f === 'marker' && r.n > 3 && /番号見出し1/.test(r.t))) bad('marker form for the caret heading', r);
  const tok = await page.evaluate(() => { const b = [...document.querySelectorAll('#sub button.pal')].find(x => !x.classList.contains('on')); b.click(); return b.title; }); await page.waitForTimeout(80);
  r = await page.evaluate(() => FZ.normalizeScheme(FZ.app.ed.doc.format.scheme)[0]); if (r !== tok) bad('marker changes level format', [r, tok]); await page.keyboard.press('Escape');
  /* ツリーでも F4 は同じ：選んだ節の種類 */
  await load(); await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ depth: !!document.querySelector('#sub .ch[data-cmd^="tvd:"]'), fig: !!document.querySelector('#sub .ch[data-cmd^="tvf:"]'), dir: !!document.querySelector('#tvDir') })); if (!(r.depth && r.fig && !r.dir)) bad('tree band has the depth buttons and 図中身 (1.0.11a), no shape', r);
  await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '課題'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); });
  await page.keyboard.press('F4'); await page.waitForTimeout(40); r = await page.evaluate(() => FZ.app.st.group); if (r !== 'struct') bad('F4 in tree shows structure group', r);
  await page.keyboard.press('4'); await page.waitForTimeout(80); r = await body(); if (!/\[記号1\]課題/.test(r)) bad('F4→4 in tree retypes the selected node', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(60);
  /* F10 の深さ（ツリーのまま） */
  await page.keyboard.press('F4'); await page.waitForTimeout(40); await page.evaluate(() => document.querySelector('#sub .segd .ch.mini[data-cmd="tvd:1"]').dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }))); await page.waitForTimeout(80); r = await page.evaluate(() => ({ d: FZ.app.st.tree.depth, n: document.querySelectorAll('#tree .tn').length })); if (r.d !== 1) bad('F4 depth pulldown: 1', r);
  r = await page.evaluate(() => FZ.app.st.tree.dir); if (r !== 'i') bad('the tree is indented (1.0.11a: the only shape)', r);
  /* AI に渡す：ツリーの選んだ節 */
  await page.evaluate(() => { FZ.app.run('tvd:9'); const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '概況'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); }); await page.evaluate(() => FZ.app.run('aiCopySec')); await page.waitForTimeout(80);
  r = await page.evaluate(() => window.__clip); if (!(r && /概況/.test(r) && /海外が牽引した/.test(r) && !/課題/.test(r))) bad('AI copy (tree node with children)', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(100);
  /* AI に渡す：紙面のカーソルの節／全体 */
  await caret(5, 1); await page.evaluate(() => FZ.app.run('aiCopySec')); await page.waitForTimeout(80); r = await page.evaluate(() => window.__clip); if (!(r && /課題/.test(r) && /為替/.test(r) && !/概況/.test(r))) bad('AI copy (paper section)', r);
  await page.evaluate(() => FZ.app.run('aiCopyDoc')); await page.waitForTimeout(80); r = await page.evaluate(() => window.__clip); if (!(r && /# 報告/.test(r) && /概況/.test(r) && /課題/.test(r))) bad('AI copy (whole doc)', r);
  r = await page.evaluate(() => FZ.app.st.msg); if (!/Markdown で写しました/.test(r)) bad('AI copy message', r);
  /* 右クリック：表の外は構造の帯 */
  await page.evaluate(() => { FZ.app.st.group = 'marks'; FZ.app.drawSub(); }); const pt = await page.evaluate(() => { const b = document.querySelector('.pg').getBoundingClientRect(); return { x: b.left + 120, y: b.top + 140 }; });
  await page.mouse.click(pt.x, pt.y, { button: 'right' }); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.st.group); if (r !== 'struct') bad('right click shows structure band', r);
  /* 帯は 1100px で 1 段 */
  for (const g of ['struct', 'file', 'view', 'marks', 'line', 'decor', 'fmt', 'edit']) { r = await page.evaluate(g => { FZ.app.st.group = g; FZ.app.st.armed = true; FZ.app.drawSub(); const s = document.getElementById('sub'); return { rows: new Set([...s.querySelectorAll('.ch')].map(e => Math.round(e.getBoundingClientRect().top))).size, over: s.scrollWidth > s.clientWidth }; }, g); if (r.rows > 3 || r.over) bad('band fits @1100 in 3 rows (1.0.11a): ' + g, r); }
  console.log('110h fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
