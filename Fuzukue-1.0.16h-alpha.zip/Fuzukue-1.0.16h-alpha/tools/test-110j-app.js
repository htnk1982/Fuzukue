/* 1.0.10j：画面からの書き出し — F2→5・6・7（ツリーの見た目で、ツリーの見た目で PowerPoint・Word・PDF）。紙面のままでもツリーを組んで書き出し、画面は元のまま */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const src = fs.readFileSync(path.join(__dirname, '../samples/見本.fzk'), 'utf8'); await page.evaluate(async s => { await FZ.app.loadText(s, 'x.fzk', null); }, src); await page.waitForTimeout(300);
  await page.evaluate(() => { window.__dl = []; window.showSaveFilePicker = undefined; FZ.files.download = async (data, name) => { const u = data instanceof Uint8Array ? data : data.arrayBuffer ? new Uint8Array(await data.arrayBuffer()) : new Uint8Array(data); window.__dl.push({ name, n: u.length, head: String.fromCharCode(u[0], u[1]) }); }; window.__printed = 0; window.print = () => { window.__printed++; window.__pages = document.querySelectorAll('#treePrint svg').length; window.dispatchEvent(new Event('afterprint')); }; });
  await page.keyboard.press('F2'); await page.waitForTimeout(80); let r = await page.evaluate(() => ({ g: FZ.app.st.group, tiles: [...document.querySelectorAll('#sub .ch')].map(e => e.dataset.cmd).filter(c => c !== undefined) }));
  if (!(r.g === 'file' && ['exportTreePptx', 'exportTreePdf', 'exportTreeDocx'].every(c => !r.tiles.includes(c)) && !r.tiles.includes('exportOutline'))) bad('F2 band has no separate tree exports (1.0.10u)', r);
  await page.keyboard.press('Escape'); await page.evaluate(() => FZ.app.run('exportTreePptx')); await page.waitForTimeout(800); await page.evaluate(() => FZ.app.run('exportTreeDocx')); await page.waitForTimeout(1500);
  r = await page.evaluate(() => window.__dl); if (!(r.length === 2 && r.every(x => x.head === 'PK' && x.n > 3000) && /（ツリー）\.pptx$/.test(r[0].name) && /（ツリー）\.docx$/.test(r[1].name))) bad('two files written (F2→5 and Word)', r);
  r = await page.evaluate(() => ({ view: FZ.app.st.view, mode: FZ.app.st.mode, tree: document.getElementById('tree').style.display, pages: document.getElementById('pages').style.display })); if (!(r.view === 'paper' && r.mode === 'text' && r.tree === 'none' && r.pages !== 'none')) bad('paper view unchanged after tree export', r);
  await page.evaluate(() => FZ.app.run('exportTreePdf')); await page.waitForTimeout(300); r = await page.evaluate(() => ({ p: window.__printed, n: window.__pages, left: !!document.getElementById('treePrint'), cls: document.body.classList.contains('ptree') })); if (!(r.p === 1 && r.n >= 1 && !r.left && !r.cls)) bad('tree PDF prints page SVGs and cleans up', r);
  /* ツリーを出している時は、今の深さのまま */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => FZ.app.run('tvd:1')); await page.evaluate(() => { window.__dl = []; FZ.app.run('exportTreePptx'); }); await page.waitForTimeout(800);
  r = await page.evaluate(() => ({ dl: window.__dl.length, depth: FZ.app.st.tree.depth, shown: document.querySelectorAll('#tree .tn').length, mode: FZ.app.st.mode })); if (!(r.dl === 1 && r.depth === 1 && r.shown > 2 && r.mode === 'tree')) bad('export from tree view keeps the tree', r);
  console.log('110j-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
