/* 1.0.10k：構造の道具 — 送り先を選んで移す（S3、Ctrl+M）、構造の点検（S2）、文の分け方（S7） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const LONG = 'これはとても長い文で八十字を超えるかどうかを確かめるためにわざと長く書いている文であり、読みにくさの点検に確かに引っかかるはずのものとして、ここにわざわざ置いてある文です。';
const SRC = '[表題]報告\n[番号1]概況\n売上は伸びた。海外が牽引した。\n[項目1]国内は横ばい\n[番号1]課題\n[番号3]深すぎる\n為替が重いです。対策が要る。\n[番号1]対策\n' + LONG + '\n[番号1]空の節\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400); await page.evaluate(() => localStorage.clear());
  const load = async (src = SRC) => { await page.evaluate(async s => { await FZ.app.loadText('#fzk 2\n---\n' + s, 'x.fzk', null); }, src); await page.waitForTimeout(120); };
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  await load();
  /* S2 点検 */
  await page.keyboard.press('F3'); await page.keyboard.press('k'); await page.waitForTimeout(100); let r = await page.evaluate(() => ({ f: FZ.app.st.form, info: document.querySelector('#sub .info').textContent }));
  if (!(r.f === 'scheck' && /子が 1 つ 2/.test(r.info) && /中身なし 1/.test(r.info) && /長い文 1/.test(r.info) && /文末の不統一 \d/.test(r.info) && /段・番号の飛び 1/.test(r.info))) bad('check counts', r);
  const seen = []; for (let k = 0; k < 8; k++) { await page.keyboard.press('Enter'); await page.waitForTimeout(40); seen.push(await page.evaluate(() => ({ t: document.querySelector('.ckinfo').textContent, line: FZ.app.ed.caret.line, sel: !!FZ.app.ed.sel() }))); }
  if (!seen.some(x => /長い文/.test(x.t) && x.line === 8 && x.sel)) bad('next goes to the long sentence and selects it', seen);
  if (!seen.some(x => /段・番号の飛び/.test(x.t) && x.line === 5)) bad('level jump found', seen);
  if (!seen.some(x => /文末/.test(x.t))) bad('style mix found', seen);
  await page.keyboard.press('Escape'); await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => FZ.app.run('checkStruct')); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ n: document.querySelectorAll('#tree .twarn').length, tip: (document.querySelector('#tree .twarn title') || {}).textContent })); if (!(r.n >= 4 && r.tip)) bad('warning badges on tree nodes', r);
  await page.keyboard.press('Escape'); await page.waitForTimeout(80); r = await page.evaluate(() => document.querySelectorAll('#tree .twarn').length); if (r) bad('badges cleared when closed', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(100);
  /* S3 送り先を選んで移す（紙面：Ctrl+M） */
  await load(); await page.evaluate(() => FZ.app.ed.setCaret({ line: 7, seg: 0, off: 0 })); await page.keyboard.press('Control+m'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ f: FZ.app.st.form, n: document.querySelectorAll('#sub .mv').length })); if (!(r.f === 'moveTo' && r.n === 7)) bad('Ctrl+M opens target list (root + headings)', r);
  await page.keyboard.type('概況'); await page.waitForTimeout(50); r = await page.evaluate(() => [...document.querySelectorAll('#sub .mv')].map(b => b.textContent)); if (!(r.length === 1 && /概況/.test(r[0]))) bad('filter by text', r);
  await page.keyboard.press('Enter'); await page.waitForTimeout(120); r = await body(); if (!/\[番号1\]概況\n売上は伸びた。海外が牽引した。\n\[項目1\]国内は横ばい\n\[番号2\]対策\n/.test(r)) bad('moved as last child of 概況 (level follows)', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(80);
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 7, seg: 0, off: 0 })); await page.keyboard.press('Control+m'); await page.waitForTimeout(60); await page.selectOption('#sub select[name="rel"]', 'before'); await page.focus('#sub input[name="q"]');
  await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowDown'); await page.keyboard.press('Enter'); await page.waitForTimeout(120); r = await body(); if (!/\[表題\]報告\n\[番号1\]対策\n/.test(r)) bad('arrow keys pick 概況, before', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(80);
  /* ツリーでも Ctrl+M */
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '空の節'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); });
  await page.keyboard.press('Control+m'); await page.waitForTimeout(80); await page.keyboard.type('課題'); await page.keyboard.press('Enter'); await page.waitForTimeout(120); r = await body(); if (!/\[番号1\]課題\n\[番号3\]深すぎる\n為替が重いです。対策が要る。\n\[番号3\]空の節\n/.test(r)) bad('tree Ctrl+M moves the selected node (same level as the last heading child)', r);
  r = await page.evaluate(() => FZ.app.st.mode); if (r !== 'tree') bad('stays in tree', r); await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(80);
  /* 位置の Ctrl+M は無くなった：F6→J は残る */
  r = await page.evaluate(() => FZ.app.keysOf('posRight')); if (!/F6「右へ」/.test(r) || !/Alt\+Shift\+→/.test(r) || /Ctrl\+M/.test(r)) bad('position right key', r);
  r = await page.evaluate(() => FZ.app.keysOf('moveTo')); if (!/Ctrl\+M/.test(r) || !/F4「移す」/.test(r)) bad('moveTo keys', r);
  /* S7 文の分け方 */
  await load('[表題]報告\n[番号1]概況\nＡはＢ．ＣはＤ．\n[項目1]一つ目の文。二つ目の文。\n');
  await page.evaluate(() => FZ.app.run('sentOpt')); await page.waitForTimeout(60); await page.selectOption('#sub select[name="period"]', '1'); await page.selectOption('#sub select[name="lists"]', '1'); await page.keyboard.press('Enter'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ o: FZ.tree.sentOpts, saved: localStorage.getItem('fz.sentOpts') })); if (!(r.o.period && r.o.lists && /true/.test(r.saved))) bad('sentence options saved', r);
  await page.keyboard.press('Control+Shift+O'); await page.waitForTimeout(150); await page.evaluate(() => FZ.app.run('tvd:-1')); await page.waitForTimeout(100);
  r = await page.evaluate(() => [...document.querySelectorAll('#tree .tn.sent')].map(g => g.textContent)); if (!(r.includes('ＡはＢ．') && r.includes('ＣはＤ．') && r.includes('一つ目の文。') && r.includes('二つ目の文。'))) bad('sentences split by ． and inside list items', r);
  await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.kind === 'sent' && x.text === '二つ目の文。'); FZ.app.st.tree.sel = n.key; FZ.app.render(); }); await page.keyboard.press('Alt+ArrowUp'); await page.waitForTimeout(100);
  r = await body(); if (!/\[項目1\]二つ目の文。一つ目の文。/.test(r)) bad('reorder sentences inside a list item', r);
  await page.keyboard.press('Control+Shift+O');
  console.log('110k fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
