/* 1.0.10p：画面 — メニューはすべて字付き（重要 4 字・ほか 2 字めど）で 2 段に収まる、倍角・救済・ツリー書き出しは浅く、ツリーの頁の印（P1 から）、区切り線を出さない、Shift+Enter */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 帯：字付き・幅・2 段 */
  const wide = t => [...t].reduce((w, ch) => w + (/[ -~｡-ﾟ]/.test(ch) ? 0.5 : 1), 0);
  for (const k of ['F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10']) { await page.keyboard.press(k); await page.waitForTimeout(60);
    const r = await page.evaluate(() => { const tiles = [...document.querySelectorAll('#sub .ch')]; return { labels: tiles.map(t => (t.querySelector('.lb') || {}).textContent || ''), rows: new Set(tiles.map(e => Math.round(e.getBoundingClientRect().top))).size, right: Math.max(...tiles.map(e => e.getBoundingClientRect().right)) }; });
    const empty = r.labels.filter(l => !l.trim()), long = r.labels.filter(l => wide(l) > 4);
    if (empty.length || long.length || r.rows > 3 || r.right > 1100) bad(k + ' band: every tile labelled (≤4 字), 3 rows (1.0.11a), inside the window', { empty: empty.length, long, rows: r.rows, right: r.right });
    await page.keyboard.press('Escape'); await page.waitForTimeout(30); }
  let r = await page.evaluate(() => { const has = (g, c) => FZ.app.run && document; return null; });
  await page.keyboard.press('F5'); await page.waitForTimeout(50); r = await page.evaluate(() => ['wide', 'tall', 'quad', 'scale', 'shadow'].every(c => document.querySelector(`#sub .ch[data-cmd="${c}"]`))); if (!r) bad('F5 has the 倍角 items directly'); await page.keyboard.press('Escape');
  await page.keyboard.press('F3'); await page.waitForTimeout(50); r = await page.evaluate(() => ['romaji', 'mdStars', 'jaLift', 'checkStruct'].every(c => document.querySelector(`#sub .ch[data-cmd="${c}"]`))); if (!r) bad('F3 has 救済 and 点検 directly'); await page.keyboard.press('Escape');
  await page.keyboard.press('F2'); await page.waitForTimeout(50); r = await page.evaluate(() => ['exportTreePptx', 'exportTreePdf', 'exportTreeDocx'].every(c => !document.querySelector(`#sub .ch[data-cmd="${c}"]`)) && !document.querySelector('#sub .ch[data-cmd$="Group"]')); if (!r) bad('F2 has no separate tree exports (1.0.10u：見ている姿で書き出す)'); await page.keyboard.press('Escape');
  await page.keyboard.press('F6'); await page.waitForTimeout(50); r = await page.evaluate(() => !!document.querySelector('#sub .ch[data-cmd="pageBreak"]')); if (!r) bad('改頁 is in F6 (送り)'); await page.keyboard.press('Escape');
  await page.keyboard.press('F10'); await page.waitForTimeout(50); r = await page.evaluate(() => [...document.querySelectorAll('#sub .cll')].map(e => e.textContent).join('/')); if (/ー/.test(r)) bad('vertical cluster names use a vertical long-vowel mark', r); await page.keyboard.press('Escape');
  /* Shift+Enter：段落の中の改行 */
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n[表題]報告\n[番号1]概況\n売上は伸びた。\n[区切り]\n[番号1 改頁]課題\n為替が重い。\n', 'x.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 7 }); }); await page.waitForTimeout(100);
  await page.keyboard.press('Shift+Enter'); await page.keyboard.type('海外が牽引。'); await page.waitForTimeout(80);
  r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]); if (!r.includes('売上は伸びた。\n[改行]海外が牽引。')) bad('Shift+Enter makes a line break inside the paragraph', r);
  /* ツリー：改行の行は同じ節、区切り線は出さない、頁の印は P1 から */
  await page.evaluate(() => { FZ.app.run('outlinePanel'); FZ.app.run('tvd:0'); }); await page.waitForTimeout(200);
  r = await page.evaluate(() => ({ texts: FZ.app.st.tree.view.shown.map(n => n.text), pgs: [...document.querySelectorAll('#tree .tpg text')].map(e => e.textContent), forced: document.querySelectorAll('#tree .tpg.forced').length }));
  if (!(r.texts.includes('売上は伸びた。 海外が牽引。') && !r.texts.some(t => /区切り/.test(t)))) bad('tree: one node for the paragraph, no separator node', r.texts);
  if (!(r.pgs[0] === 'P1' && r.pgs.includes('P2') && r.forced === 1)) bad('tree page marks: P1, P2 (forced break marked)', r);
  console.log('110p-app fails=' + fails, 'errors:', JSON.stringify(errors));
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
