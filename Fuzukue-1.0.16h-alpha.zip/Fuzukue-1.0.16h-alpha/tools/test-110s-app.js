/* 1.0.10s：ツリー・並べるの表示からの印刷（白紙・紙面抜け）、ツリーの段の上げ下げ（入れる兄が無いとき）、Markdown の表の左端、囲み記事は枠から、長体、ツリーの箱を接して並べる・箱の中で直す */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const pdfPages = buf => (buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); require('./fkey-shim')(page); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 印刷：紙面・ツリー・並べるのどれからでも、紙面の頁だけが刷られる */
  const src = fs.readFileSync(path.resolve(__dirname, '../samples/見本.fzk'), 'utf8');
  for (const view of ['paper', 'tree', 'split']) {
    const n = await page.evaluate(async ([s, view]) => { await FZ.app.loadText(s, '見本.fzk', null); const ed = FZ.app.ed; while (!ed.layoutDone) ed.continueLayout(500); const vs = document.getElementById('viewSel'); vs.value = view; vs.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 150));
      const g = ed.lay.geo; let st = document.getElementById('printStyle'); if (!st) { st = document.createElement('style'); st.id = 'printStyle'; document.head.append(st); } st.textContent = `@page{size:${g.W}pt ${g.H}pt;margin:0}`; FZ.app.renderForPrint(); return ed.lay.pages.length; }, [src, view]);
    const got = pdfPages(await page.pdf({ preferCSSPageSize: true, printBackground: true })); if (got !== n) bad('print from ' + view + ' view has exactly the paper pages', { n, got });
    await page.evaluate(() => { const vs = document.getElementById('viewSel'); vs.value = 'paper'; vs.dispatchEvent(new Event('change')); });
  }
  /* ツリー：入れる兄が無くても「深く」で段が深くなる（Markdown の見出し・項目） */
  const MD = '# 題\n\n## 背景\n\n本文。\n\n### 現状\n\n- 項目A\n- 項目B\n\n| 項目 | 値 |\n|---|---:|\n| 国内 | 1 |\n';
  let r = await page.evaluate(async md => { await FZ.app.loadText(md, 'x.md', null); const A = FZ.app; const ser = () => FZ.serialize(A.ed.doc).split('---\n')[1]; const tbl = ser().match(/#表 列 ([\d.,]+)/)[1];
    A.run('outlinePanel'); A.run('tvd:9'); const v = A.st.tree.view; const pick = t => { const n = A.st.tree.view.shown.find(x => x.text === t); A.st.tree.sel = n.obj; A.render(); };
    pick('背景'); A.run('tv:in'); const a1 = ser().includes('[番号2]背景'); pick('項目A'); A.run('tv:in'); const a2 = ser().includes('[項目2]項目A'); pick('項目A'); A.run('tv:out'); const a3 = ser().includes('[項目1]項目A');
    return { a1, a2, a3, tbl, para: (() => { const lm = A.ed.lay.lineMap; return 0; })() }; }, MD);
  if (!(r.a1 && r.a2 && r.a3)) bad('tree deepen works without an older sibling (level only) and back', r);
  if (!/^1(\.5)?,/.test(r.tbl) && !/^[1-4](\.5)?,/.test(r.tbl)) bad('Markdown table starts at the preceding text, not the margin', r.tbl);
  /* 囲み記事：範囲を選ばずに押すと、空の枠を作って中に書く */
  r = await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n本文の行。\n', 'b.fzk', null); FZ.app.ed.setCaret({ line: 0, seg: 0, off: 2 }); FZ.app.run('hd:article'); return FZ.app.ed.caret.line; });
  await page.keyboard.type('題の字'); r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  if (!/^本文の行。\n#囲み ×2\n<太字>題の字<\/太字>\n\[項目1\]/.test(r)) bad('box article: frame first, then type the title inside (1.0.11a: bold title, bulleted body)', r);
  /* 長体：原本の往復と字の幅 */
  r = await page.evaluate(async () => { const s = '#fzk 2\n---\n<長体 75>七割五分</長体>\n'; await FZ.app.loadText(s, 'n.fzk', null); const g = FZ.app.ed.lay.pages[0].glyphs.filter(x => x.line === 0); return { rt: FZ.serialize(FZ.app.ed.doc).endsWith('<長体 75>七割五分</長体>\n'), w: g[0] && g[0].w }; });
  if (!(r.rt && Math.abs(r.w - 0.75) < 1e-6)) bad('narrow 75%: round trip and glyph width', r);
  await page.keyboard.press('F5'); await page.waitForTimeout(60); r = await page.evaluate(() => !!document.getElementById('ms_narrow') && document.getElementById('sub').getBoundingClientRect().height < 95); if (!r) bad('F5 has the 字幅 pulldown in 3 rows');
  await page.keyboard.press('Escape');
  /* ツリー：同じ親の続く兄弟は辺で接し、枝は 1 本。箱の中でそのまま直す */
  r = await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n[表題]題\n[番号1]一\n[番号1]二\n[番号1]三\n[番号2]子\n[番号1]四\n', 't.fzk', null); FZ.app.run('outlinePanel'); FZ.app.run('tvd:9'); const v = FZ.app.st.tree.view; const P = t => v.pos.get(v.shown.find(x => x.text === t));
    const a = P('一'), b = P('二'), c = P('三'), d = P('四'), k = P('子'); return { touch12: Math.abs(b.y - (a.y + a.h)) < 0.5, touch23: Math.abs(c.y - (b.y + b.h)) < 0.5, gapChild: k.y - (c.y + c.h), gapUp: d.y - (k.y + k.h), branches: v.edges.length }; });
  if (!(r.touch12 && r.touch23 && r.gapChild === 0 && r.gapUp === 0)) bad('1.0.11b: on screen the indented tree stacks frames without gaps', r);
  await page.evaluate(() => { const v = FZ.app.st.tree.view; const n = v.shown.find(x => x.text === '二'); FZ.app.st.tree.sel = n.obj; FZ.app.render(); });
  await page.keyboard.press('Control+Enter'); await page.waitForTimeout(100);
  r = await page.evaluate(() => { const el = document.querySelector('textarea.tinl'); const v = FZ.app.st.tree.view; const p = v.pos.get(v.shown.find(x => x.text === '二')); const SC = FZ.app.st.tree.scale; return el ? { h: el.getBoundingClientRect().height, boxH: p.h * SC, w: el.getBoundingClientRect().width, boxW: p.w * SC, border: getComputedStyle(el).borderTopWidth } : null; });
  if (!(r && r.h <= r.boxH && r.w < r.boxW && r.border === '0px')) bad('tree editing happens inside the node box (no floating larger box)', r);
  console.log('110s-app fails=' + fails, 'errors:', errors); await browser.close(); process.exit(fails ? 1 : 0);
})();
