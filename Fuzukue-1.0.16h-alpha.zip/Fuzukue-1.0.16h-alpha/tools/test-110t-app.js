/* 1.0.10t：表紙の型（題・日付・作成者・目次・機密表示） */
const { chromium } = require('playwright'); const path = require('path'); const zlib = require('zlib');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const pdfPages = buf => (buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
function unzip(buf) { const out = {}; let p = 0; while (p + 30 < buf.length && buf.readUInt32LE(p) === 0x04034b50) { const m = buf.readUInt16LE(p + 8), cs = buf.readUInt32LE(p + 18), nl = buf.readUInt16LE(p + 26), xl = buf.readUInt16LE(p + 28); const name = buf.slice(p + 30, p + 30 + nl).toString(); const d = buf.slice(p + 30 + nl + xl, p + 30 + nl + xl + cs); out[name] = m === 8 ? zlib.inflateRawSync(d) : d; p += 30 + nl + xl + cs; } return out; }
const para = '二段組は資料のときだけ使える組み方で、本文を左の段から右の段へ流す。'.repeat(3);
let body = '[表題]二段組の試し\n[番号1]概況\n'; for (let k = 0; k < 30; k++) body += para + k + '\n';
body += '#表 列 0,10,20,30 様式 格子\n| 項目 | 上期 | 下期 |\n| 国内 | 1 | 2 |\n\n[表題]次の頁\n本文。\n';
const SRC = '#fzk 2\n書式: 資料\n用紙: A3 横\n文字数: 70\n行数: 30\n仕切り: 細\n段組: 2\n---\n' + body;
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 2 段組は 1.0.10u で撤去：原本の「段組: 2」は読み捨て、資料は図表欄のまま */
  r = await page.evaluate(async s => { await FZ.app.loadText(s, 'x.fzk', null); const g = FZ.app.ed.lay.geo; return { cols2: g.cols2, side: g.side, head: FZ.serialize(FZ.app.ed.doc).split('---')[0] }; }, SRC);
  if (r.cols2 || !r.side || r.head.includes('段組')) bad('段組: 2 is ignored (1.0.10u)', r);
  /* 表紙の型：題（中央・四倍角）・日付・作成者・目次の箱・右上の機密表示。原本で往復 */
  const COV = '#fzk 2\n書式: 資料\n柱の題: 頁ごと\n機密: 社外秘\n作成者: 企画部\n作成日: 2026年11月4日\n表紙: あり\n表紙の型: 目次つき\n表紙の機密: 出す\n---\n[表題]年度計画\n[表題]背景\n本文。\n[表題]方針\n本文。\n';
  await page.evaluate(async s => { await FZ.app.loadText(s, 'c.fzk', null); }, COV); await page.waitForTimeout(200);
  r = await page.evaluate(() => { const ed = FZ.app.ed, L = ed.lay, p0 = L.pages[0]; const head = FZ.serialize(ed.doc).split('---')[0]; const hs = p0.head.glyphs.map(g => g.text).join('');
    const tg = p0.glyphs.filter(g => g.line === 0); const tw = tg.reduce((t, g) => t + g.w, 0), tl = Math.min(...tg.map(g => g.col));
    return { head, hs, cover: !!p0.cover, toc: p0.head.boxes.some(b => b.coverToc), secret: p0.head.boxes.some(b => b === L.headInfo.secretBox), center: Math.abs(tl + tw / 2 - L.geo.cols / 2), big: tg.every(g => g.sx >= 2), pages: L.pages.length }; });
  if (!(r.head.includes('表紙の型: 目次つき') && r.head.includes('表紙の機密: 出す'))) bad('cover template and secret survive a save', r.head);
  if (!(r.cover && r.big && r.center < 1.01)) bad('cover title is centered and 4x', r);
  if (!(r.hs.includes('2026年11月4日') && r.hs.includes('企画部'))) bad('cover shows date and author', r.hs);
  if (!(r.toc && r.hs.includes('背景') && r.hs.includes('方針'))) bad('cover TOC box lists the page titles', r.hs);
  if (!(r.secret && r.hs.includes('社外秘'))) bad('cover shows the secret mark top right', r.hs);
  r = await page.evaluate(() => { const fs = FZ.toPptx(FZ.app.ed.doc, { files: true }); const d = fs.find(f => f.name === 'ppt/slides/slide1.xml'); return typeof d.data === 'string' ? d.data : new TextDecoder().decode(d.data); });
  if (!(r.includes('表紙の題') && r.includes('企画部') && r.includes('社外秘'))) bad('PowerPoint cover has the title box, author and secret');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110t-app OK'); process.exit(fails ? 1 : 0);
})();
