/* 1.0.10u：構え（項目の文字キー）をやめた・帯の字・近道（Alt+Shift+←→）・入口ひとつ（書き出しは見ている姿で、書式の欄に種類なし）・書式の欄の塊・ツリーの字下げは箱なし・
   並べるの範囲は左の線・ツリーの図表の切り抜き・ブラウザから刷っても全頁を描く */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const SRC = '#fzk 2\n---\n[表題]題\n[番号1]背景\n本文の文。\n#表 列 0,10,20,30 様式 格子 見出し薄\n| 項目 | 上期 | 下期 |\n| 国内 | 1 | 2 |\n\n[番号1]今後\n実施する。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 860 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText(s, 'x.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 5 }); }, SRC); await page.waitForTimeout(150); await page.focus('#ta');
  /* F キーの後に打った字は本文に入る（構えない）。帯にキーの札は出ない */
  await page.keyboard.press('F4'); await page.waitForTimeout(60); await page.keyboard.type('s'); await page.waitForTimeout(60);
  let r = await page.evaluate(() => ({ armed: FZ.app.st.armed, g: FZ.app.st.group, line: FZ.app.ed.doc.lines[2].segs[0].text, badges: [...document.querySelectorAll('#sub .ch .k')].filter(e => getComputedStyle(e).display !== 'none').length, nar: document.querySelectorAll('#sub .ch .nr').length, legend: [...document.querySelectorAll('#sub .cll')].map(e => getComputedStyle(e).writingMode + ':' + e.textContent).slice(0, 2) }));
  if (r.armed || r.g !== 'struct' || r.line !== '本文の文。s') bad('after F4 a letter types into the text', r);
  if (r.badges !== 0 || r.nar < 10) bad('band labels are condensed and show no key badges', r);
  if (!r.legend.length || !r.legend.every(t => /^horizontal-tb:/.test(t))) bad('group names are written horizontally', r.legend);
  await page.keyboard.press('Backspace');
  /* 近道：Alt+Shift+→ で位置を右へ、Alt+Shift+← で戻す */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 2, seg: 0, off: 0 }); return ed.doc.lines[2].attrs.indent | 0; });
  await page.keyboard.press('Alt+Shift+ArrowRight'); await page.waitForTimeout(60); const r1 = await page.evaluate(() => FZ.app.ed.doc.lines[2].attrs.indent | 0);
  await page.keyboard.press('Alt+Shift+ArrowLeft'); await page.waitForTimeout(60); const r2 = await page.evaluate(() => FZ.app.ed.doc.lines[2].attrs.indent | 0);
  if (!(r1 === r + 1 && r2 === r)) bad('Alt+Shift+←→ moves the position', { r, r1, r2 });
  r = await page.evaluate(() => [FZ.app.cmds().find(c => c.id === 'posRight').keys, document.querySelector('#fkeys .fk:nth-child(2)').textContent]);
  if (!/Alt\+Shift\+→/.test(r[0]) || !/ファイル/.test(r[1])) bad('posRight shortcut and full-width F2 caption', r);
  /* 入口ひとつ：F2 にツリー専用の書き出しなし、F4 にツリーのタイルなし、書式の欄に種類・資料の柱なし */
  r = await page.evaluate(() => { const A = FZ.app; A.run('fileGroup'); const f2 = ['exportTreePptx', 'exportTreeDocx', 'exportTreePdf'].filter(c => document.querySelector(`#sub .ch[data-cmd="${c}"]`)); A.run('structGroup'); const f4 = !!document.querySelector('#sub .ch[data-cmd="outlinePanel"]'); A.run('format'); const fm = { kind: !!document.querySelector('#sub select[data-name="kind"]'), slide: !!document.querySelector('#sub [data-act="slide"]'), blocks: [...document.querySelectorAll('#sub .fb .fbt')].map(e => e.textContent), miss: document.querySelectorAll('#sub .miss').length }; return { f2, f4, fm }; });
  if (r.f2.length || r.f4 || r.fm.kind || r.fm.slide) bad('one entry: no duplicate tree tiles or kind in the format form', r);
  if (r.fm.blocks.join() !== '用紙,版面,余白,組み,書体,基準の字幅,書体の組,柱') bad('format form has the 8 labelled blocks (1.0.11d: 基準の字幅・書体の組)', r.fm.blocks);
  /* 資料のまま書式を適用しても資料のまま */
  r = await page.evaluate(() => { const A = FZ.app; A.ed.mutate('', () => { A.ed.doc.format.kind = 'slide'; }); if (A.st.form !== 'format') A.run('format'); document.querySelector('#sub [data-act="apply"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); const k = A.ed.doc.format.kind; A.ed.mutate('', () => { A.ed.doc.format.kind = 'doc'; }); return k; });
  if (r !== 'slide') bad('applying the format form keeps the kind', r);
  /* 書き出しは見ている姿で：ツリーだけを見ている時の PPT はツリーの姿、紙面では紙面 */
  await page.evaluate(() => { window.__dl = []; window.showSaveFilePicker = undefined; FZ.files.download = (data, name) => { window.__dl.push(name); }; });
  await page.evaluate(() => { const vs = document.getElementById('viewSel'); vs.value = 'tree'; vs.dispatchEvent(new Event('change')); }); await page.waitForTimeout(250);
  r = await page.evaluate(() => ({ ti: !!document.querySelector('#tree svg.ti'), tf: document.querySelectorAll('#tree .tn rect.tf').length, page: document.querySelector('#tree .tpg path') && document.querySelector('#tree .tpg path').getAttribute('d') }));
  if (!r.ti || r.tf < 3) bad('indent tree has no boxes (frame only for the selected node)', r);
  await page.evaluate(() => FZ.app.run('exportPptx')); await page.waitForTimeout(1500);
  await page.evaluate(() => { const vs = document.getElementById('viewSel'); vs.value = 'paper'; vs.dispatchEvent(new Event('change')); }); await page.waitForTimeout(200);
  await page.evaluate(() => FZ.app.run('exportPptx')); await page.waitForTimeout(1500);
  r = await page.evaluate(() => window.__dl);
  if (!(r.length === 2 && /（ツリー）\.pptx$/.test(r[0]) && !/ツリー/.test(r[1]))) bad('PPT exports what is shown (tree view → tree, paper → paper)', r);
  /* 並べる：ツリーで選んだ範囲は灰色の塗りでなく左の線 */
  await page.evaluate(() => { const vs = document.getElementById('viewSel'); vs.value = 'split'; vs.dispatchEvent(new Event('change')); }); await page.waitForTimeout(200);
  await page.evaluate(() => FZ.app.run('tvf:open')); await page.waitForTimeout(100);
  r = await page.evaluate(() => { const t = document.getElementById('tree'); const g = [...t.querySelectorAll('g.tn')].find(g => g.textContent.includes('背景')); const rc = g.querySelector('rect').getBoundingClientRect(); return { x: rc.x + 20, y: rc.y + 6 }; });
  await page.mouse.click(r.x, r.y); await page.waitForTimeout(200);
  r = await page.evaluate(() => [...document.querySelectorAll('#pages .ov rect, #pages svg.ov rect')].map(e => +e.getAttribute('width')).filter(w => w > 0));
  if (r.some(w => w > 30)) bad('split view marks the range with a thin left bar, not a gray band', r.slice(0, 6));
  /* ブラウザから刷っても（doPrint を通らなくても）全頁を描く */
  r = await page.evaluate(() => { window.dispatchEvent(new Event('beforeprint')); const n = document.querySelectorAll('#pages .pgwrap svg.pg').length; window.dispatchEvent(new Event('afterprint')); return { n, pages: FZ.app.ed.lay.pages.length }; });
  if (r.n < r.pages) bad('beforeprint renders every page', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110u-app OK'); process.exit(fails ? 1 : 0);
})();
