/* 1.0.10v：工程表（ガントチャート）— 表のまま、期間のセルの字から矢羽根（五角形）・◆・基準の線。月の途中は［1/4］［1/2］［3/4］［15日］、ドラッグで 1/4 刻み、
   PowerPoint は図形、Word は網のセル、文机 Markdown は注記で往復 */
const { chromium } = require('playwright'); const path = require('path'); const zlib = require('zlib');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
function unzip(buf) { const out = {}; let p = 0; while (p + 30 < buf.length && buf.readUInt32LE(p) === 0x04034b50) { const m = buf.readUInt16LE(p + 8), cs = buf.readUInt32LE(p + 18), nl = buf.readUInt16LE(p + 26), xl = buf.readUInt16LE(p + 28); const name = buf.slice(p + 30, p + 30 + nl).toString(); const d = buf.slice(p + 30 + nl + xl, p + 30 + nl + xl + cs); out[name] = m === 8 ? zlib.inflateRawSync(d) : d; p += 30 + nl + xl + cs; } return out; }
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n[表題]工程\n\n', 'g.fzk', null); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('gantt'); }); await page.waitForTimeout(200);
  let r = await page.evaluate(() => [...document.querySelectorAll('#sub input,#sub select')].map(e => e.name || e.dataset.name));
  if (!['y0', 'm0', 'unit', 'n', 'labels', 'rows'].every(k => r.includes(k))) bad('the gantt form asks start, unit, periods, label columns and rows', r);
  await page.evaluate(() => { document.querySelector('#sub select[data-name="band"]').value = '0'; }); /* 年度の段（1.0.10z）は test-110z-app */ await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  if (!/\[工程表 工程列2\]\| \d{4}年度 \| 担当 \| 4月 \| 5月 \|/.test(r) || !r.includes('◆開始') || !/\| 計画 \| → \|/.test(r)) bad('a 12-month gantt table is inserted with an example row', r.slice(0, 400));
  /* 字を書くと矢羽根・◆、期間のセルの字は隠れる */
  await page.evaluate(() => { const ed = FZ.app.ed, L = ed.doc.lines; const i0 = L.findIndex(l => l.segs.some(s => s.text === '計画'));
    const setCell = (i, k, text) => { const c = FZ.tableCells(ed.doc, i, ed.lay.geo.bodyCols)[k]; let sg = L[i].segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6); if (!sg) { sg = FZ.newSeg(c.left, ''); L[i].segs.push(sg); L[i].segs.sort((a, b) => a.col - b.col); } sg.text = text; sg.marks = FZ.marksFor(text, 0); };
    window.__i0 = i0; ed.mutate('', () => { setCell(i0 + 1, 0, '設計'); setCell(i0 + 1, 4, '［1/2］設計'); setCell(i0 + 1, 5, '→'); setCell(i0 + 1, 6, '→［1/4］'); setCell(i0 + 1, 8, '◆［3/4］審査'); }); FZ.app.render(); });
  r = await page.evaluate(() => { const L = FZ.app.ed.lay, pg = L.pages[0], i = window.__i0 + 1; const sh = pg.shapes.filter(s => s.line === i); const cells = FZ.tableCells(FZ.app.ed.doc, i, L.geo.bodyCols); return { sh: sh.map(s => [s.kind, +(s.x0 ?? s.x).toFixed(2), s.x1 != null ? +s.x1.toFixed(2) : null, s.label]), c6: cells[4], c8: cells[6], c10: cells[8], hidden: pg.glyphs.filter(g => g.gh && g.line === i).length, svg: (document.querySelector('#pages svg.pg g.gantt') || {}).innerHTML || '' }; });
  { const b = r.sh.find(s => s[0] === 'bar'), m = r.sh.find(s => s[0] === 'ms'); const W6 = r.c6.right - r.c6.left;
    if (!b || Math.abs(b[1] - (r.c6.left + W6 / 2)) > 0.01 || Math.abs(b[2] - (r.c8.left + 0.25 * (r.c8.right - r.c8.left))) > 0.01 || b[3] !== '設計') bad('［1/2］設計 → →［1/4］ draws a bar from mid-period to a quarter', r);
    if (!m || Math.abs(m[1] - (r.c10.left + 0.75 * (r.c10.right - r.c10.left))) > 0.01 || m[3] !== '審査') bad('◆［3/4］審査 is a milestone at 3/4', r.sh);
    if (r.hidden < 8 || !/<polygon class="gbar"/.test(r.svg) || !/<polygon class="gms"/.test(r.svg)) bad('period text is hidden and shapes are drawn', { hidden: r.hidden }); }
  /* カーソルのある期間のセルは字が見える */
  r = await page.evaluate(() => { const ed = FZ.app.ed, i = window.__i0 + 1; const s = ed.doc.lines[i].segs.findIndex(x => x.text === '［1/2］設計'); ed.setCaret({ line: i, seg: s, off: 1 }); return new Promise(res => setTimeout(() => res({ rv: !!document.querySelector('#pages svg.pg g.greveal'), off: ed.caret.off }), 120)); });
  if (r.rv || r.off !== 5) bad('1.0.11a: the cell under the caret does not show ［1/2］; the caret stays after the position mark', r);
  /* ドラッグ：矢羽根の終わりを 1/4 刻みで動かす（取消 1 回で戻る） */
  const pt = await page.evaluate(() => { const L = FZ.app.ed.lay, g = L.geo, i = window.__i0; const sh = L.pages[0].shapes.find(s => s.kind === 'bar' && s.line === i); const cells = FZ.tableCells(FZ.app.ed.doc, i, g.bodyCols); const el = document.querySelectorAll('#pages .pgwrap')[0].getBoundingClientRect(); const sc = el.width / g.W; const X = c => el.left + (g.left + c * g.cw) * sc, Y = r => el.top + (g.top + (g.bodyTop + r) * g.ch) * sc; const c5 = cells[5]; return { x1: X(sh.x1 - 0.1), y: Y(sh.y + sh.h / 2), to: X(c5.left + 0.5 * (c5.right - c5.left)) }; });
  await page.mouse.move(pt.x1, pt.y); await page.mouse.down(); await page.mouse.move((pt.x1 + pt.to) / 2, pt.y, { steps: 3 }); await page.mouse.move(pt.to, pt.y, { steps: 3 }); await page.mouse.up(); await page.waitForTimeout(150);
  r = await page.evaluate(() => FZ.app.ed.doc.lines[window.__i0].segs.map(s => s.text).join('|'));
  if (!/\|計画\|→\|→\|→［1\/2］\|/.test(r)) bad('dragging the bar end snaps to 1/2 of the 4th period', r);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(80); r = await page.evaluate(() => FZ.app.ed.doc.lines[window.__i0].segs.map(s => s.text.trim()).filter(Boolean).join('|'));
  if (r !== '（例）計画|計画|→') bad('one undo restores the bar', r);
  /* 設定：基準の線（4 列目の中） */
  await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: window.__i0, seg: 0, off: 0 }); FZ.app.run('gantt'); }); await page.waitForTimeout(150);
  await page.evaluate(() => { const s = document.querySelector('#sub select[data-name="base"]'); s.value = '4'; const f = document.querySelector('#sub select[data-name="bfrac"]'); f.value = '0.5'; document.querySelector('#sub [data-act="set"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); }); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const L = FZ.app.ed.lay; const bs = L.pages[0].shapes.filter(s => s.kind === 'base'); const T = FZ.app.ed.doc.lines.find(l => l.attrs.gantt); const i = window.__i0; const c = FZ.tableCells(FZ.app.ed.doc, i, L.geo.bodyCols)[5]; return { g: T.attrs.gantt, n: bs.length, x: bs[0] && bs[0].x, want: c.left + (c.right - c.left) / 2, first: bs.filter(s => s.first).length }; });
  if (!(r.g.base === 4.5 && r.n >= 4 && Math.abs(r.x - r.want) < 0.01 && r.first === 1)) bad('the base line is at the middle of period 4 across the body rows', r);
  /* 書き出し：PowerPoint は図形、Word は網と名前、文机 Markdown で往復 */
  r = await page.evaluate(() => { const fs = FZ.toPptx(FZ.app.ed.doc, { files: true }); const s1 = fs.find(f => f.name === 'ppt/slides/slide1.xml'); const x = typeof s1.data === 'string' ? s1.data : new TextDecoder().decode(s1.data); const tbl = (x.match(/<a:tbl>[\s\S]*<\/a:tbl>/) || [''])[0];
    const dx = FZ.toDocx(FZ.app.ed.doc, { files: true }).find(f => f.name === 'word/document.xml'); const w = typeof dx.data === 'string' ? dx.data : new TextDecoder().decode(dx.data);
    const md = FZ.toGfm(FZ.app.ed.doc, { fz: true }); const back = FZ.fromGfm(md); const fzk = FZ.parse(FZ.serialize(FZ.app.ed.doc));
    return { home: (x.match(/prst="homePlate"/g) || []).length, dia: (x.match(/prst="diamond"/g) || []).length, arrowInTable: /→/.test(tbl), wArrow: />→</.test(w) || /→［/.test(w), wLabel: w.includes('設計'), wShd: (w.match(/<w:shd /g) || []).length, md: md.includes('<!-- 工程表 列2 基準4.5 -->'), mdBack: JSON.stringify((back.lines.find(l => l.attrs.gantt) || { attrs: {} }).attrs.gantt), fzk: JSON.stringify((fzk.lines.find(l => l.attrs.gantt) || { attrs: {} }).attrs.gantt) }; });
  if (!(r.home >= 2 && r.dia >= 2 && !r.arrowInTable)) bad('PowerPoint: bars are homePlate shapes, milestones are diamonds, the table cells are blank', r);
  if (!(r.wLabel && !r.wArrow && r.wShd >= 4)) bad('Word: bar cells are shaded with the name, no arrow tokens', r);
  if (!(r.md && r.mdBack === '{"labels":2,"heads":1,"base":4.5}' && r.fzk === r.mdBack)) bad('the gantt flag round-trips through 文机 Markdown and .fzk', r);
  /* ふつうの表に戻す：字が見える */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: window.__i0, seg: 0, off: 0 }); if (FZ.app.st.form !== 'gantt') FZ.app.run('gantt'); }); await page.waitForTimeout(120);
  await page.evaluate(() => document.querySelector('#sub [data-act="off"]').dispatchEvent(new MouseEvent('click', { bubbles: true }))); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ g: FZ.app.ed.doc.lines.some(l => l.attrs.gantt), sh: FZ.app.ed.lay.pages[0].shapes.length, hidden: FZ.app.ed.lay.pages[0].glyphs.filter(g => g.gh).length }));
  if (r.g || r.sh || r.hidden) bad('「ふつうの表に」 removes the gantt drawing', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110v-app OK'); process.exit(fails ? 1 : 0);
})();
