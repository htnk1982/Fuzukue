/* 1.0.10w：付箋（Word のコメントと同じ）— 選んだ字に付ける・右の余白のつまみ・行の下に開く札（組版は動かない）・本文と返信と解決・一覧・次へ・
   行を分けても付いていく・原本と文机 Markdown と Word（コメント）で往復・印刷に出ない */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const SRC = '#fzk 2\n---\n[番号1]背景\n今期の出荷は前年比で 8% 伸びた。\n国内は横ばいで、在庫の回転日数は 42 日から 47 日に悪化した。\n為替の影響を除くと、実質の伸びは 3% にとどまる。\n[番号1]課題\n欠品率は改善した。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { localStorage.setItem('fz.noteAuthor', '山田'); await FZ.app.loadText(s, 'n.fzk', null); const ed = FZ.app.ed; const t = ed.doc.lines[2].segs[0].text, k = t.indexOf('47 日'); ed.setCaret({ line: 2, seg: 0, off: k }); ed.setCaret({ line: 2, seg: 0, off: k + 4 }, true); }, SRC); await page.focus('#ta');
  const before = await page.evaluate(() => JSON.stringify(FZ.app.ed.lay.lineMap.map(m => m && m.rows.map(r => r.page + ':' + r.y).join())));
  await page.keyboard.press('Control+Alt+m'); await page.waitForTimeout(250);
  let r = await page.evaluate(() => ({ notes: FZ.app.ed.doc.notes, attrs: FZ.app.ed.doc.lines[2].attrs.notes, card: !!document.querySelector('#notesLayer .ncard'), focus: document.activeElement && document.activeElement.className, tab: !!document.querySelector('#notesLayer .ntab'), und: document.querySelectorAll('#notesLayer .nund').length, lay: JSON.stringify(FZ.app.ed.lay.lineMap.map(m => m && m.rows.map(r => r.page + ':' + r.y).join())) }));
  if (!(r.notes.length === 1 && r.notes[0].quote === '47 日' && r.notes[0].author === '山田' && r.attrs[0] === r.notes[0].id)) bad('Ctrl+Alt+M adds a note on the selected text', r.notes);
  if (!(r.card && /nbody/.test(r.focus) && r.tab && r.und >= 1)) bad('the card opens with the body focused, a tab and an underline', r);
  if (r.lay !== before) bad('the layout does not move when a note is added');
  await page.keyboard.type('根拠は？'); await page.waitForTimeout(100);
  await page.evaluate(() => { const t = document.querySelector('#notesLayer .nreply'); t.focus(); t.value = '9 月末で 46 日。'; }); await page.keyboard.press('Control+Enter'); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const n = FZ.app.ed.doc.notes[0]; return { text: n.text, reps: n.replies.map(x => x.author + ':' + x.text), card: (document.querySelector('#notesLayer .ncard') || {}).textContent || '' }; });
  if (!(r.text === '根拠は？' && r.reps[0] === '山田:9 月末で 46 日。' && r.card.includes('9 月末で 46 日。'))) bad('typing in the card and Ctrl+Enter reply', r);
  /* Esc で閉じ、その行にいる間は開かない。別の行へ行って戻ると開く */
  await page.keyboard.press('Escape'); await page.waitForTimeout(80); r = await page.evaluate(() => !!document.querySelector('#notesLayer .ncard')); if (r) bad('Esc closes the card');
  await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowUp'); await page.waitForTimeout(100); r = await page.evaluate(() => !!document.querySelector('#notesLayer .ncard')); if (!r) bad('coming back to the line opens the card again');
  /* 解決 → つまみが白抜き。一覧（未解決だけ）から消える */
  await page.evaluate(() => document.querySelector('#notesLayer [data-na="done"]').click()); await page.waitForTimeout(100);
  r = await page.evaluate(() => ({ done: FZ.app.ed.doc.notes[0].done, tab: document.querySelector('#notesLayer .ntab').className }));
  if (!(r.done && /done/.test(r.tab))) bad('resolve marks the note done', r);
  await page.evaluate(() => FZ.app.run('noteList')); await page.waitForTimeout(100);
  r = await page.evaluate(() => { const a = document.querySelectorAll('#sideBody .nli').length; document.getElementById('noteOnly').click(); return [a, document.querySelectorAll('#sideBody .nli').length]; });
  if (!(r[0] === 1 && r[1] === 0)) bad('the list shows notes and filters unresolved', r);
  await page.evaluate(() => FZ.app.run('noteList'));
  /* 2 つ目の付箋（選ばずに行へ）と次へ・前へ */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 5, seg: 0, off: 2 }); FZ.app.run('noteAdd'); }); await page.waitForTimeout(100); await page.keyboard.press('Escape');
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 })); await page.focus('#ta');
  await page.keyboard.press('Alt+PageDown'); await page.waitForTimeout(80); const l1 = await page.evaluate(() => FZ.app.ed.caret.line); await page.keyboard.press('Alt+PageDown'); await page.waitForTimeout(80); const l2 = await page.evaluate(() => FZ.app.ed.caret.line);
  if (!(l1 === 2 && l2 === 5)) bad('Alt+PageDown goes to the next note', { l1, l2 });
  /* 行を分ける：引用の字がある側に付いていく。行をつなぐ：消える行の付箋は残る行へ */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 2, seg: 0, off: 5 }); ed.enter(); const a = [ed.doc.lines[2].attrs.notes || null, ed.doc.lines[3].attrs.notes || null]; ed.undo(); ed.setCaret({ line: 3, seg: 0, off: 0 }); ed.backspace(); const b = ed.doc.lines[2].attrs.notes; ed.undo(); return { a, b }; });
  if (!(r.a[0] === null && r.a[1] && r.a[1][0] === 'n1' && r.b && r.b.includes('n1'))) bad('notes follow the quote on split and survive a join', r);
  /* 往復：原本・文机 Markdown・Word（コメント） */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const fzk = FZ.parse(FZ.serialize(ed.doc)); const md = FZ.toGfm(ed.doc, { fz: true }); const back = FZ.fromGfm(md);
    const files = FZ.toDocx(ed.doc, { files: true }); const cm = files.find(f => f.name === 'word/comments.xml'); const dx = files.find(f => f.name === 'word/document.xml'); const dt = typeof dx.data === 'string' ? dx.data : new TextDecoder().decode(dx.data); const ct = cm ? (typeof cm.data === 'string' ? cm.data : new TextDecoder().decode(cm.data)) : '';
    const w = (await FZ.fromDocx(FZ.zip(files))).doc; const sum = d => (d.notes || []).map(n => (n.done ? '済' : '未') + ':' + n.text + ':' + n.replies.length).join('|') + '@' + d.lines.filter(l => l.attrs.notes).length;
    return { fzk: sum(fzk), md: sum(back), mdHas: md.includes('<!-- 付箋 n1 -->') && md.includes('<!-- 付箋の中身'), word: sum(w), ranges: (dt.match(/<w:commentRangeStart/g) || []).length, cmts: (ct.match(/<w:comment /g) || []).length, auth: /w:author="山田"/.test(ct), orig: sum(ed.doc) }; });
  if (r.fzk !== r.orig || r.md !== r.orig || !r.mdHas) bad('notes round-trip through .fzk and 文机 Markdown', r);
  if (!(r.ranges === 2 && r.cmts === 2 && r.auth && r.word === r.orig)) bad('Word: notes become comments and come back', r);
  /* 印刷に出ない（頁の SVG に付箋の字は無い） */
  r = await page.evaluate(() => [...document.querySelectorAll('#pages svg.pg')].some(s => s.textContent.includes('根拠は？'))); if (r) bad('notes are not part of the printed page');
  /* ツリー：付箋の付いた節に印 */
  await page.evaluate(() => { const vs = document.getElementById('viewSel'); vs.value = 'tree'; vs.dispatchEvent(new Event('change')); }); await page.waitForTimeout(250);
  r = await page.evaluate(() => document.querySelectorAll('#tree .tnote').length); if (r < 1) bad('tree nodes with notes are marked', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110w-app OK'); process.exit(fails ? 1 : 0);
})();
