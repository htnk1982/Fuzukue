/* 1.0.10x：付箋の仕上げ — Word のコメントを引用の字だけに掛ける・Word のコメントの範囲の字を引用として取り込む・PowerPoint のコメント・解決した付箋をまとめて消す */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '#fzk 2\n---\n[番号1]背景\n今期の出荷は前年比で 8% 伸びた。\n[付箋:n1]国内は横ばいで、在庫の回転日数は 42 日から 47 日に悪化した。\n[付箋:n2]為替の影響を除くと、実質の伸びは 3% にとどまる。\n[番号1]課題\n欠品率は改善した。\n' +
  '#付箋 n1 山田 2026-11-05T09:35 未 「47 日」\n根拠は？\n#返信 佐藤 2026-11-05T10:00\n9 月末で 46 日。\n#付箋ここまで\n#付箋 n2 山田 2026-11-05T09:40 済\n行全体への指摘。\n#付箋ここまで\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText(s, 'n.fzk', null); }, SRC); await page.waitForTimeout(150);
  /* Word：引用のある付箋は字だけ、引用の無い付箋は段落全体 */
  let r = await page.evaluate(async () => { const files = FZ.toDocx(FZ.app.ed.doc, { files: true }); const td = f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data);
    const dx = td(files.find(f => f.name === 'word/document.xml')); const plain = x => x.replace(/<w:t[^>]*>([^<]*)<\/w:t>/g, '$1').replace(/<[^>]+>/g, '');
    const span = id => { const m = dx.match(new RegExp('<w:commentRangeStart w:id="' + id + '"/>([\\s\\S]*?)<w:commentRangeEnd w:id="' + id + '"/>')); return m ? plain(m[1]) : null; };
    const w = await FZ.fromDocx(FZ.zip(files)); const d = w.doc; window.__docx = files;
    return { s0: span(0), s1: span(1), refs: (dx.match(/<w:commentReference /g) || []).length, back: (d.notes || []).map(n => [n.quote, n.text, n.replies.length, n.done]), lines: d.lines.filter(l => l.attrs.notes).map(l => l.segs.map(s => s.text).join('')) }; });
  if (r.s0 !== '47 日') bad('Word: the comment range covers only the quoted characters', r);
  if (!(r.s1 && r.s1.startsWith('為替の影響') && r.s1.endsWith('とどまる。'))) bad('Word: a note without a quote covers the whole paragraph', r);
  if (r.refs !== 2) bad('Word: one comment reference per note', r);
  if (!(r.back.length === 2 && r.back[0][0] === '47 日' && r.back[0][1] === '根拠は？' && r.back[0][2] === 1 && r.back[1][3] === true)) bad('Word import: the comment range text becomes the quote; replies and resolved survive', r);
  if (!(r.lines.length === 2 && !r.lines.some(t => /付箋/.test(t)))) bad('Word import: notes attach to their lines without leftover markers', r);
  /* 取り込んだ付箋の下線は引用の字の位置に出る */
  r = await page.evaluate(async () => { const w = await FZ.fromDocx(FZ.zip(window.__docx)); await FZ.app.loadText(FZ.serialize(w.doc), 'w.fzk', null); await new Promise(res => setTimeout(res, 150)); return document.querySelectorAll('#notesLayer .nund').length; });
  if (r < 1) bad('imported notes underline the quoted text', r);
  await page.evaluate(async s => { await FZ.app.loadText(s, 'n.fzk', null); }, SRC); await page.waitForTimeout(100);
  /* PowerPoint：旧形式のコメント（作成者・スライドのコメント・関係・型） */
  r = await page.evaluate(() => { const files = FZ.toPptx(FZ.app.ed.doc, { files: true }); const td = f => f ? (typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data)) : ''; const get = n => td(files.find(f => f.name === n)); window.__pptx = files;
    return { au: get('ppt/commentAuthors.xml'), cm: get('ppt/comments/comment1.xml'), rel: get('ppt/slides/_rels/slide1.xml.rels'), pres: get('ppt/_rels/presentation.xml.rels'), ct: get('[Content_Types].xml') }; });
  if (!(/<p:cmAuthor id="0" name="山田"[^>]*lastIdx="2"/.test(r.au))) bad('PowerPoint: comment authors with the last index', r.au);
  if (!((r.cm.match(/<p:cm /g) || []).length === 2 && r.cm.includes('「47 日」') && r.cm.includes('→ 佐藤（2026-11-05 10:00）：9 月末で 46 日。') && r.cm.includes('［解決済み］') && /dt="2026-11-05T09:35:00.000"/.test(r.cm))) bad('PowerPoint: the slide comments carry quote, text, replies and resolved', r.cm);
  if (!(/relationships\/comments" Target="\.\.\/comments\/comment1\.xml"/.test(r.rel) && /commentAuthors/.test(r.pres) && /presentationml\.comments\+xml/.test(r.ct) && /commentAuthors\+xml/.test(r.ct))) bad('PowerPoint: relationships and content types for comments', r);
  /* 付箋の無い文書には何も足さない */
  r = await page.evaluate(() => { const d = FZ.parse('#fzk 2\n---\n本文。\n'); const fs = FZ.toPptx(d, { files: true }); return fs.some(f => /comment/i.test(f.name)); }); if (r) bad('no comment parts without notes');
  /* 解決した付箋をまとめて消す（取消で戻る） */
  await page.evaluate(() => FZ.app.run('noteList')); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const b = document.getElementById('noteClear'); if (!b) return null; b.click(); const a = { notes: FZ.app.ed.doc.notes.map(n => n.id), l3: FZ.app.ed.doc.lines[3].attrs.notes || null, list: document.querySelectorAll('#sideBody .nli').length }; FZ.app.ed.undo(); a.undo = FZ.app.ed.doc.notes.map(n => n.id); a.l3u = FZ.app.ed.doc.lines[3].attrs.notes || null; return a; });
  if (!r || r.notes.join() !== 'n1' || r.l3 !== null || r.list !== 1 || r.undo.join() !== 'n1,n2' || !(r.l3u && r.l3u[0] === 'n2')) bad('「解決済みを消す」 removes resolved notes and undo restores them', r);
  /* LibreOffice で開ける（Word・PowerPoint） */
  const dir = fs.mkdtempSync('/tmp/fz110x-'); const save = async (key, name) => { const b = await page.evaluate(k => Array.from(FZ.zip(window[k])), key); fs.writeFileSync(path.join(dir, name), Buffer.from(b)); };
  await save('__docx', 'n.docx'); await save('__pptx', 'n.pptx');
  try { require('child_process').execSync(`cd ${dir} && timeout 120 soffice --headless --convert-to pdf n.docx n.pptx >/dev/null 2>&1`); const ok = ['n.pdf'].every(f => fs.existsSync(path.join(dir, f)));
    require('child_process').execSync(`cd ${dir} && timeout 120 soffice --headless --convert-to odp n.pptx >/dev/null 2>&1 && unzip -p n.odp content.xml > c.xml`); const c = fs.readFileSync(path.join(dir, 'c.xml'), 'utf8');
    if (!ok) bad('LibreOffice converts the files'); if (!/<officeooo:annotation|<office:annotation/.test(c) || !c.includes('根拠は？')) bad('LibreOffice reads the PowerPoint comments', c.slice(0, 200)); } catch (e) { bad('LibreOffice run', e.message); }
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110x-app OK'); process.exit(fails ? 1 : 0);
})();
