/* 1.0.10y：語ごとの移動・選択・削除（Ctrl+←→・Ctrl+Shift+←→・Ctrl+Backspace／Delete） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 400) : '')); };
const SRC = '#fzk 2\n---\n在庫の回転日数は 42 日から 47 日に悪化した。\nNext quarter we ship.\n[区切り]\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText(s, 'w.fzk', null); FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); }, SRC); await page.focus('#ta');
  const off = () => page.evaluate(() => [FZ.app.ed.caret.line, FZ.app.ed.caret.off]);
  const seq = []; for (let k = 0; k < 6; k++) { await page.keyboard.press('Control+ArrowRight'); seq.push((await off())[1]); }
  const t = await page.evaluate(() => FZ.app.ed.doc.lines[0].segs[0].text); const want = [2, 3, 5, 7, t.indexOf('42'), t.indexOf('42') + 3];
  if (seq.join() !== want.join()) bad('Ctrl+→ stops at Japanese word starts (在庫／の／回転／日数／は／42／日)', { seq, want });
  /* 行末で Ctrl+→ は次の行の頭、行頭で Ctrl+← は前の行の末 */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: FZ.app.ed.doc.lines[0].segs[0].text.length })); await page.keyboard.press('Control+ArrowRight'); let r = await off();
  if (!(r[0] === 1 && r[1] === 0)) bad('Ctrl+→ at the line end goes to the next line start', r);
  await page.keyboard.press('Control+ArrowRight'); r = await off(); if (r[1] !== 5) bad('Ctrl+→ skips the space to the next English word', r);
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 })); await page.keyboard.press('Control+ArrowLeft'); r = await off();
  if (!(r[0] === 0 && r[1] === t.length)) bad('Ctrl+← at the line start goes to the previous line end', r);
  await page.keyboard.press('Control+ArrowLeft'); r = await off(); if (r[1] !== t.length - 1) bad('Ctrl+← stops before the full stop', r);
  /* Ctrl+Shift+→ で語ごとに選ぶ */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 })); await page.keyboard.press('Control+Shift+ArrowRight'); await page.keyboard.press('Control+Shift+ArrowRight');
  r = await page.evaluate(() => { const s = FZ.app.ed.sel(); return s && FZ.app.ed.doc.lines[0].segs[0].text.slice(s.a.off, s.b.off); }); if (r !== '在庫の') bad('Ctrl+Shift+→ extends the selection by words', r);
  /* Ctrl+Backspace／Ctrl+Delete（1 回の取消で戻る） */
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 5 })); await page.keyboard.press('Control+Backspace');
  r = await page.evaluate(() => [FZ.app.ed.doc.lines[0].segs[0].text.slice(0, 6), FZ.app.ed.caret.off]); if (!(r[0] === '在庫の日数は' && r[1] === 3)) bad('Ctrl+Backspace deletes back to the previous word start', r);
  await page.keyboard.press('Control+z'); await page.evaluate(() => FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 })); await page.keyboard.press('Control+Delete');
  r = await page.evaluate(() => [FZ.app.ed.doc.lines[0].segs[0].text.slice(0, 5), FZ.app.ed.doc.lines[1].segs[0].text]); if (!(r[0] === '在庫の回転' && r[1] === 'quarter we ship.')) bad('undo restores; Ctrl+Delete deletes the word and its space', r);
  /* 区切り線の行では消さない */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.attrs.hr); ed.setCaret({ line: i, seg: 0, off: 0 }); return [i, ed.doc.lines.length]; });
  await page.keyboard.press('Control+Backspace'); const r2 = await page.evaluate(i => [!!FZ.app.ed.doc.lines[i].attrs.hr, FZ.app.ed.doc.lines.length], r[0]);
  if (!(r2[0] && r2[1] === r[1])) bad('Ctrl+Backspace does nothing on a rule line', r2);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110y-app OK'); process.exit(fails ? 1 : 0);
})();
