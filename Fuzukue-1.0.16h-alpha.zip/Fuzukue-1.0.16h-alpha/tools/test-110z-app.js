/* 1.0.10z：工程表の年度の段（1 段目に年度の帯、左の列の見出しは 2 段を 1 つに）— 作る・組版（帯の中の縦罫なし・字は帯の幅）・Word と PowerPoint の結合・原本の往復・足す／外す・今日の位置 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n用紙: A4 横\n文字数: 60\n---\n[表題]工程\n\n', 'g.fzk', null); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('gantt'); }); await page.waitForTimeout(200);
  let r = await page.evaluate(() => [...document.querySelectorAll('#sub select,#sub input')].map(e => e.name || e.dataset.name)); if (!r.includes('band')) bad('the make form has 年度の段', r);
  await page.evaluate(() => { document.querySelector('#sub input[name="n"]').value = '18'; }); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const ts = d.lines.findIndex(l => l.attrs.gantt); const L = FZ.app.ed.lay, W = L.geo.bodyCols; const cells = FZ.tableCells(d, ts, W); const tx = (i, c) => (d.lines[i].segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6) || { text: '' }).text.trim();
    return { ts, g: d.lines[ts].attrs.gantt, band: cells.map(c => tx(ts, c)), per: cells.map(c => tx(ts + 1, c)), fills: d.fills.filter(f => f.from === ts + 1 && f.to === ts + 1).length }; });
  if (!(r.g.heads === 2 && r.band[0] === 'テーマ' && r.band[1] === '担当' && r.band[2] === '2026年度' && r.band[3] === '' && r.band[14] === '2027年度' && r.per[0] === '' && r.per[2] === '4月' && r.per[11] === '1月' && r.fills === 1)) bad('a gantt with a year band: band row, period row, both shaded', r);
  const ts = r.ts;
  /* 組版：帯の中の縦罫は 1 段目に無い、左の列の 2 段の間の横罫も無い、年度の字は帯の幅で 1 行・中央 */
  r = await page.evaluate(ts => { const L = FZ.app.ed.lay, d = FZ.app.ed.doc, pg = L.pages[0], W = L.geo.bodyCols; const cells = FZ.tableCells(d, ts, W); const rowTop = L.lineMap[ts].rows[0].y, rowBot = L.lineMap[ts + 1].rows[0].y;
    const inBand = c => pg.vrules.some(v => Math.abs(v.col - c) < 1e-6 && v.y1 < rowBot - 0.01 && v.y2 > rowTop + 0.01); const lr = cells[1].right;
    const hUnder = pg.hrules.filter(h => Math.abs(h.y - rowBot) < 0.01); const g = pg.glyphs.filter(x => x.line === ts && /[0-9年度]/.test(x.text));
    const sp = { l: cells[2].left, r: cells[13].right }; const gx0 = Math.min(...g.filter(x => x.col < cells[14].left).map(x => x.col)), gx1 = Math.max(...g.filter(x => x.col < cells[14].left).map(x => x.col + x.w));
    return { mid: inBand(cells[5].left), edge: inBand(cells[14].left), lab: inBand(cells[1].right), hLab: hUnder.some(h => h.from < lr - 0.01), hPer: hUnder.some(h => h.to > lr + 0.01), rows: new Set(g.map(x => x.y)).size, centre: Math.abs((gx0 + gx1) / 2 - (sp.l + sp.r) / 2) }; }, ts);
  if (r.mid || !r.edge || !r.lab) bad('band: no vertical rules inside a year, rules at the year edge and label columns', r);
  if (r.hLab || !r.hPer) bad('label headers span two rows (no rule between them); the period row keeps its rule', r);
  if (!(r.rows === 1 && r.centre < 1)) bad('the year label is one line, centred on its band', r);
  /* 書き出し：Word は gridSpan と vMerge、PowerPoint は gridSpan・hMerge と rowSpan・vMerge、見出し 2 段を繰り返す */
  r = await page.evaluate(() => { const td = f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data); const w = td(FZ.toDocx(FZ.app.ed.doc, { files: true }).find(f => f.name === 'word/document.xml')); const tbl = (w.match(/<w:tbl>[\s\S]*?<\/w:tbl>/) || [''])[0]; const trs = tbl.match(/<w:tr>[\s\S]*?<\/w:tr>/g) || [];
    const x = td(FZ.toPptx(FZ.app.ed.doc, { files: true }).find(f => f.name === 'ppt/slides/slide1.xml'));
    return { w12: (trs[0].match(/<w:gridSpan w:val="12"\/>/) || []).length, w6: /<w:gridSpan w:val="6"\/>/.test(trs[0]), vr: (trs[0].match(/<w:vMerge w:val="restart"\/>/g) || []).length, vc: (trs[1].match(/<w:vMerge\/>/g) || []).length, head: (tbl.match(/<w:tblHeader\/>/g) || []).length, tc0: (trs[0].match(/<w:tc>/g) || []).length,
      prs: (x.match(/rowSpan="2"/g) || []).length, pvm: (x.match(/vMerge="1"/g) || []).length, pgs: /gridSpan="12"/.test(x) }; });
  if (!(r.w12 === 1 && r.w6 && r.tc0 === 4 && r.vr === 2 && r.vc === 2 && r.head === 2)) bad('Word: year cells merged across, label headers merged down, two header rows repeat', r);
  if (!(r.prs === 2 && r.pvm === 2 && r.pgs)) bad('PowerPoint: year cells merged across, label headers merged down', r);
  /* 原本の往復（帯は表の字のまま） */
  r = await page.evaluate(() => { const a = FZ.serialize(FZ.app.ed.doc); const b = FZ.serialize(FZ.parse(a)); return { same: a === b, band: /\[工程表 工程列2 工程見出し2\]\| テーマ \| 担当 \| 2026年度 \|/.test(a) }; });
  if (!r.same || !r.band) bad('the band survives save and reopen', r);
  /* 今日の位置：年度の段で同じ月の 2 度目を区別（2027 年 5 月なら 2027年度の 5月） */
  r = await page.evaluate(ts => { const RD = Date; class FD extends RD { constructor(...a) { super(...(a.length ? a : [2027, 4, 20])); } } window.Date = FD; try { FZ.app.ed.setCaret({ line: ts + 3, seg: 0, off: 0 }); FZ.app.run('gantt'); const s = document.querySelector('#sub select[data-name="base"]'); s.value = 'now'; document.querySelector('#sub [data-act="set"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); return FZ.app.ed.doc.lines[ts].attrs.gantt.base; } finally { window.Date = RD; } }, ts);
  if (!(r > 14 && r < 15)) bad('today is found in the second fiscal year using the band', r);
  /* 外す → 1 段（左上に年度の範囲）、足す → 帯が戻る。どちらも取消 1 回 */
  r = await page.evaluate(ts => { const ed = FZ.app.ed, d = ed.doc; const before = FZ.serialize(d); const n0 = ed.undoStack.length; ed.setCaret({ line: ts + 3, seg: 0, off: 0 }); FZ.app.run('gantt'); const s = document.querySelector('#sub select[data-name="band"]'); s.value = '0'; document.querySelector('#sub [data-act="set"]').dispatchEvent(new MouseEvent('click', { bubbles: true }));
    const T = d.lines.findIndex(l => l.attrs.gantt); const off = { g: d.lines[T].attrs.gantt, first: d.lines[T].segs.map(x => x.text.trim()).slice(0, 4), undo: ed.undoStack.length - n0, base: d.lines[T].attrs.gantt.base };
    ed.setCaret({ line: T + 2, seg: 0, off: 0 }); FZ.app.run('gantt'); const s2 = document.querySelector('#sub select[data-name="band"]'); s2.value = '1'; document.querySelector('#sub [data-act="set"]').dispatchEvent(new MouseEvent('click', { bubbles: true }));
    const T2 = d.lines.findIndex(l => l.attrs.gantt); const cells = FZ.tableCells(d, T2, ed.lay.geo.bodyCols); const tx = c => (d.lines[T2].segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6) || { text: '' }).text.trim();
    const on = { g: d.lines[T2].attrs.gantt, band: cells.map(tx), lab2: FZ.tableCells(d, T2 + 1, ed.lay.geo.bodyCols).slice(0, 2).map(c => (d.lines[T2 + 1].segs.find(x => x.col >= c.left - 1e-6 && x.col < c.right - 1e-6) || { text: '' }).text.trim()) };
    ed.undo(); ed.undo(); return { off, on, back: FZ.serialize(d) === before }; }, ts);
  if (!(r.off.g.heads === 1 && r.off.first[0] === '2026〜2027年度' && r.off.first[1] === '担当' && r.off.first[2] === '4月' && r.off.undo === 1 && r.off.base > 14)) bad('removing the band moves labels down, keeps the base line, one undo', r.off);
  if (!(r.on.g.heads === 2 && r.on.band[0] === 'テーマ' && r.on.band[2] === '2026年度' && r.on.band[14] === '2027年度' && r.on.band[3] === '' && r.on.lab2.join() === ',')) bad('adding the band reads fiscal years from the period row', r.on);
  if (!r.back) bad('two undos restore the original table');
  /* 年度の段なしで作ると 1 段（従来どおり） */
  r = await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n\n', 'h.fzk', null); FZ.app.run('gantt'); document.querySelector('#sub select[data-name="band"]').value = '0'; FZ.app.st.form && document.querySelector('#sub [data-act="make"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); const d = FZ.app.ed.doc; const T = d.lines.find(l => l.attrs.gantt); return T && T.attrs.gantt.heads; });
  if (r !== 1) bad('without the band the gantt has one header row', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-110z-app OK'); process.exit(fails ? 1 : 0);
})();
