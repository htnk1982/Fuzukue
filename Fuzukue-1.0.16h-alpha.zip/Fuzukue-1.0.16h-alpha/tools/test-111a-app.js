/* 1.0.11a：帯 3 段・上げ／下げ・ツリーの段ボタンと図中身・形は字下げだけ・ガイドと取説（一覧はメニューから外す）・囲みの既定・グラフの枠・
   工程表（期間のセルの字を見せない・枠・つまみ・引いて作る・名前を打つ・→ のセルで切る・Backspace） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 760 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n[番号1]背景\n本文の文。\n[番号2]詳しく\n本文。\n', 'a.fzk', null); });
  /* 帯：3 段で 1 行に収まる、上げ・下げ、ツリーの段ボタン、図中身、形は無い */
  let r = await page.evaluate(() => { const A = FZ.app; A.run('structGroup'); const s = document.getElementById('sub'); const cg = s.querySelector('.cg'); const tops = new Set([...s.querySelectorAll(':scope > .cl')].map(c => Math.round(c.getBoundingClientRect().top)));
    return { rows: getComputedStyle(cg).gridTemplateRows.split(' ').length, lines: tops.size, up: s.querySelector('.ch[data-cmd="sx:out"]').textContent, down: s.querySelector('.ch[data-cmd="sx:in"]').textContent, seg: [...s.querySelectorAll('.segd .ch.mini')].map(e => e.textContent).join(','), figs: !!s.querySelector('.ch[data-cmd="tvf:toggle"]'), sel: [...s.querySelectorAll('select[data-msel]')].map(e => e.id) }; });
  if (!(r.rows === 3 && r.lines === 1)) bad('the band has 3 rows and fits on one line', r);
  if (!(r.up === '上げ' && r.down === '下げ')) bad('上げ・下げ', r);
  if (!(r.seg === 'L1,L2,L3,L全,本文,単文' && r.figs && !r.sel.length)) bad('tree depth buttons and the 図中身 toggle, no pulldowns', r);
  await page.evaluate(() => document.querySelector('#sub .segd .ch.mini[data-cmd="tvd:2"]').dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }))); await page.waitForTimeout(150);
  r = await page.evaluate(() => ({ d: FZ.app.st.tree.depth, mode: FZ.app.st.mode, on: (document.querySelector('#sub .segd .ch.mini.on') || {}).textContent }));
  if (!(r.d === 2 && r.mode === 'tree' && r.on === 'L2')) bad('pressing 2 opens the tree at depth 2', r);
  r = await page.evaluate(() => { const b = () => document.querySelector('#sub .ch[data-cmd="tvf:toggle"]'); b().dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true })); const a = [FZ.app.st.tree.showAll, b() && b().classList.contains('on')]; b().dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true })); return a.concat([FZ.app.st.tree.showAll, !!document.querySelector('#sub select[data-msel="shape"]'), FZ.app.cmds().some(c => /^tvs:/.test(c.id))]); });
  if (!(r[0] === true && r[1] && r[2] === false && !r[3] && !r[4])) bad('図中身 toggles; the tree shape is gone', r);
  await page.evaluate(() => FZ.app.run('tv:paper')); await page.waitForTimeout(80);
  /* ガイドと取説：F1 はガイド、F10 に一覧は無い、取説は取扱説明書（同梱の原本と同じ） */
  r = await page.evaluate(() => { const A = FZ.app; A.run('viewGroup'); return { f1: document.querySelector('#fkeys .fk').textContent, tiles: [...document.querySelectorAll('#sub .ch')].map(e => e.textContent), m: FZ.manualText().split('\n').slice(0, 3).join('|') }; });
  const shipped = fs.readFileSync(path.resolve(__dirname, '../samples/取扱説明書.fzk'), 'utf8'); const man = await page.evaluate(() => FZ.manualText());
  if (!(/ガイド/.test(r.f1) && r.tiles.includes('ガイド') && r.tiles.includes('取説') && !r.tiles.includes('一覧'))) bad('F1 ガイド, F10 has ガイド and 取説 but no 一覧', r);
  if (!(r.m.includes('題名: 文机 取扱説明書') && man === shipped && man.length > 50000)) bad('取説 opens the full manual (same as samples/取扱説明書.fzk)', r.m);
  if (fs.existsSync(path.resolve(__dirname, '../samples/文机 解説書.fzk'))) bad('the old 解説書 file is gone');
  /* 囲み記事（題＋箱）を空で作る：題は太字、Enter で本文の行（記号の箇条書き）へ */
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n本文。\n\n', 'k.fzk', null); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('hd:article'); }); await page.focus('#ta');
  await page.keyboard.type('ポイント'); await page.keyboard.press('Enter'); await page.keyboard.type('一つ目'); await page.keyboard.press('Enter'); await page.keyboard.type('二つ目');
  r = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  if (r !== '本文。\n#囲み ×3\n<太字>ポイント</太字>\n[項目1]一つ目\n[項目1]二つ目\n') bad('a new titled box: bold title, bulleted body', r);
  /* グラフの細い枠（画面・PowerPoint・Word のグラフ） */
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n本文。\n#グラフ g 図 棒 50% 売上\n#データ |  | A | B |\n#データ | 国内 | 1 | 2 |\n', 'c.fzk', null); }); await page.waitForTimeout(200);
  r = await page.evaluate(() => { const f = document.querySelector('#pages svg.pg g.chart rect.chframe'); const fs = FZ.toPptx(FZ.app.ed.doc, { files: true }); const ch = fs.find(x => /ppt\/charts\/chart\d+\.xml$/.test(x.name)); const t = ch ? (typeof ch.data === 'string' ? ch.data : new TextDecoder().decode(ch.data)) : '';
    return { svg: !!f, sw: f && f.getAttribute('stroke-width'), ppt: /<\/c:chart><c:spPr><a:solidFill><a:srgbClr val="FFFFFF"\/><\/a:solidFill><a:ln w="6350"><a:solidFill><a:srgbClr val="000000"\/>/.test(t) }; });
  if (!(r.svg && r.sw === '0.5' && r.ppt)) bad('charts have a thin frame on screen and in PowerPoint', r);
  /* 工程表 */
  await page.evaluate(async s => { await FZ.app.loadText(s, 'g.fzk', null); }, fs.readFileSync(path.resolve(__dirname, '../samples/工程表見本.fzk'), 'utf8')); await page.waitForTimeout(250);
  const geo = await page.evaluate(() => { const L = FZ.app.ed.lay, g = L.geo; const el = document.querySelectorAll('#pages .pgwrap')[0].getBoundingClientRect(); return { left: el.left, top: el.top, sc: el.width / g.W, gl: g.left, gt: g.top + g.bodyTop * g.ch, cw: g.cw, ch: g.ch }; });
  const X = c => geo.left + (geo.gl + c * geo.cw) * geo.sc, Y = r => geo.top + (geo.gt + r * geo.ch) * geo.sc;
  /* 期間のセルにカーソル：字（［1/2］など）は出さず、カーソルは名前の前（位置の印の後ろ）、セルの枠 */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.segs.some(s => s.text === '［1/2］基本設計')); const s = ed.doc.lines[i].segs.findIndex(x => x.text === '［1/2］基本設計'); ed.setCaret({ line: i, seg: s, off: 0 }); window.__gi = i; window.__gs = s; return new Promise(res => setTimeout(() => res({ off: ed.caret.off, rv: !!document.querySelector('#pages g.greveal'), box: [...document.querySelectorAll('#pages .ov rect')].some(e => +e.getAttribute('stroke-width') > 1.2), caret: !!document.querySelector('#pages .ov .caret, #pages .ov line.caret') }), 150)); });
  if (!(r.off === 5 && !r.rv && r.box)) bad('the caret cell shows a frame, not ［1/2］; the caret starts after the position mark', r);
  /* 名前を直す：Backspace は名前だけ。Home でも位置の印に入らない */
  await page.focus('#ta'); await page.keyboard.press('End'); await page.keyboard.press('Backspace'); await page.keyboard.press('Backspace'); await page.keyboard.type('計画'); await page.keyboard.press('Home'); await page.keyboard.press('Backspace');
  r = await page.evaluate(() => FZ.app.ed.doc.lines[window.__gi].segs[window.__gs].text); if (r !== '［1/2］基本計画') bad('typing edits only the name; Backspace at the name start keeps the position', r);
  /* つまみ：矢羽根の端に乗せると ⇔、中ほどは掴む手 */
  const bar = await page.evaluate(() => { const sh = FZ.app.ed.lay.pages[0].shapes.find(s => s.kind === 'bar' && s.label === '要件定義'); return { x0: sh.x0, x1: sh.x1, y: sh.y + sh.h / 2, line: sh.line }; });
  await page.mouse.move(X(bar.x1 - 0.1), Y(bar.y)); await page.waitForTimeout(60); const c1 = await page.evaluate(() => [document.getElementById('pages').style.cursor, FZ.app.st.ganttHover && FZ.app.st.ganttHover.which]);
  await page.mouse.move(X((bar.x0 + bar.x1) / 2), Y(bar.y)); await page.waitForTimeout(60); const c2 = await page.evaluate(() => document.getElementById('pages').style.cursor);
  if (!(c1[0] === 'ew-resize' && c1[1] === 'u1' && c2 === 'grab')) bad('hovering a bar shows the grab points', { c1, c2 });
  /* 空いた所を横に引くと新しい矢羽根、放すと始まりのセルで名前を打てる（取消 1 回で消える） */
  const row = await page.evaluate(() => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.segs[0].text.trim() === '' && FZ.inTable(ed.doc, ed.doc.lines.indexOf(l)) && ed.doc.lines.indexOf(l) > 4); const cs = FZ.tableCells(ed.doc, i, ed.lay.geo.bodyCols).slice(2); const lm = ed.lay.lineMap[i].rows[0]; return { i, y: lm.y + lm.h / 2, a: cs[2].left + 0.1, b: cs[4].left + (cs[4].right - cs[4].left) * 0.5 }; });
  await page.mouse.move(X(row.a), Y(row.y)); await page.mouse.down(); await page.mouse.move(X(row.b), Y(row.y), { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(120);
  await page.keyboard.type('新規');
  r = await page.evaluate(i => ({ t: FZ.app.ed.doc.lines[i].segs.map(s => s.text.trim()).filter(Boolean).join('|'), bar: FZ.app.ed.lay.pages[0].shapes.some(s => s.kind === 'bar' && s.line === i && s.label === '新規') }), row.i);
  if (!(r.t === '新規|→|→［1/2］' && r.bar)) bad('dragging across empty cells makes a bar; the name is typed right after', r);
  /* → のセルに名前を打つと、そこで切って新しい矢羽根 */
  r = await page.evaluate(i => { const ed = FZ.app.ed; const s = ed.doc.lines[i].segs.findIndex(x => x.text.trim() === '→'); ed.setCaret({ line: i, seg: s, off: 0 }); return s; }, row.i);
  await page.keyboard.type('次'); r = await page.evaluate(i => FZ.app.ed.doc.lines[i].segs.map(s => s.text.trim()).filter(Boolean).join('|'), row.i);
  if (r !== '新規|次|→［1/2］') bad('typing in a → cell starts a new bar there', r);
  /* 名前が空の始まりで Backspace：矢羽根の始まりごと消える */
  await page.keyboard.press('Backspace'); await page.keyboard.press('Backspace'); r = await page.evaluate(i => FZ.app.ed.doc.lines[i].segs.map(s => s.text.trim()).filter(Boolean).join('|'), row.i);
  if (r !== '新規|→［1/2］') bad('Backspace on an empty name removes the bar start', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111a-app OK'); process.exit(fails ? 1 : 0);
})();
