/* 1.0.11b：ツリーの枠（細く薄い実線・角丸なし・隙間なし・幅は中身）・単文の段落は枠の中を破線で区切る・箇条書きの 2 行目は 1 字下げ・図表は紙面で見える大きさ */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
const SRC = '#fzk 2\n---\n[表題]年度計画\n[番号1]背景\n今期の出荷は前年比で 8% 伸びた。国内は横ばいで、在庫の回転日数は 42 日から 47 日に悪化した。為替の影響を除くと、実質の伸びは 3% にとどまる。\n[項目1]国内は横ばいで推移し、主力製品の更新需要が一巡したため、来期も大きな伸びは見込めない状況が続く\n[項目1]海外はアジアが牽引\n[番号1]課題\n欠品率は改善した。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 640, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async s => { await FZ.app.loadText(s, 't.fzk', null); const vs = document.getElementById('viewSel'); vs.value = 'tree'; vs.dispatchEvent(new Event('change')); FZ.app.run('tvd:0'); }, SRC); await page.waitForTimeout(300);
  /* 枠：選んでいない節にも細い実線の枠、角丸なし、隙間なし、幅は中身（右端まで伸ばさない） */
  let r = await page.evaluate(() => { const gs = [...document.querySelectorAll('#tree svg.ti g.tn')]; const box = g => g.querySelector('rect.tf'); const of = t => gs.find(g => g.textContent.includes(t));
    const cs = e => getComputedStyle(e); const a = of('海外はアジア'), b = of('課題'), c = of('欠品率'); const ra = box(a); const st = cs(ra);
    const y = g => +box(g).getAttribute('y'), h = g => +box(g).getAttribute('height'); const items = gs.filter(g => !g.classList.contains('sent'));
    const gaps = []; for (let k = 1; k < items.length; k++) gaps.push(+(y(items[k]) - (y(items[k - 1]) + h(items[k - 1]))).toFixed(1));
    const W = +document.querySelector('#tree svg').getAttribute('viewBox').split(' ')[2];
    return { stroke: st.stroke, sw: st.strokeWidth, dash: st.strokeDasharray, rx: ra.getAttribute('rx'), gaps, wA: +ra.getAttribute('width'), wB: +box(b).getAttribute('width'), W, body: cs(box(c)).strokeDasharray }; });
  if (!(r.stroke !== 'none' && parseFloat(r.sw) < 1 && (r.dash === 'none' || !r.dash) && !r.rx && r.body === 'none')) bad('every node has a thin solid square frame', r);
  if (r.gaps.some(g => Math.abs(g) > 0.01)) bad('frames are stacked without gaps', r.gaps);
  if (!(r.wA < r.W * 0.6 && r.wB < r.W * 0.4)) bad('frames fit their text (not stretched to the right edge)', r);
  /* 箇条書きの 2 行目は記号の後ろの字に面を合わせて 1 字下げ */
  r = await page.evaluate(() => { const g = [...document.querySelectorAll('#tree svg.ti g.tn')].find(g => g.textContent.includes('国内は横ばいで推移')); const ts = [...g.querySelectorAll(':scope > text')]; return { n: ts.length, x0: +ts[0].getAttribute('x'), x1: ts[1] ? +ts[1].getAttribute('x') : null, t0: ts[0].textContent.slice(0, 2) }; });
  if (!(r.n >= 2 && r.t0 === '・国' && Math.abs(r.x1 - r.x0 - 13) < 2)) bad('a wrapped bullet hangs its 2nd line by one character', r);
  /* 単文：段落は 1 つの枠、文と文の境目は破線 */
  await page.evaluate(() => FZ.app.run('tvd:-1')); await page.waitForTimeout(200);
  r = await page.evaluate(() => { const para = [...document.querySelectorAll('#tree svg.ti g.tn.para')][0]; const seps = para ? para.querySelectorAll('path.tsep').length : 0; const sent = document.querySelector('#tree svg.ti g.tn.sent rect.tf'); return { seps, sentStroke: sent && getComputedStyle(sent).stroke, paraDash: para && getComputedStyle(para.querySelector('rect.tf')).strokeDasharray }; });
  if (!(r.seps === 2 && r.sentStroke === 'none' && r.paraDash === 'none')) bad('a paragraph of 3 sentences: one solid frame and 2 dashed separators', r);
  /* 図表：ツリーの中身は紙面で見える大きさ（ツリーを拡大しても大きくならない） */
  await page.setViewportSize({ width: 1100, height: 800 });
  await page.evaluate(async s => { const vs = document.getElementById('viewSel'); vs.value = 'paper'; vs.dispatchEvent(new Event('change')); await FZ.app.loadText(s, 'x.fzk', null); }, fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8')); await page.waitForTimeout(400);
  const paper = await page.evaluate(() => Math.round(document.querySelector('#pages svg.pg g.figimg').getBoundingClientRect().width));
  r = await page.evaluate(async () => { const vs = document.getElementById('viewSel'); vs.value = 'tree'; vs.dispatchEvent(new Event('change')); FZ.app.run('tvf:open'); await new Promise(r => setTimeout(r, 250)); const w1 = +document.querySelector('#tree svg.tfig').getAttribute('width') * FZ.app.st.tree.scale;
    FZ.app.st.tree.scale = 1.5; FZ.app.render(); await new Promise(r => setTimeout(r, 250)); const w2 = +document.querySelector('#tree svg.tfig').getAttribute('width') * FZ.app.st.tree.scale; FZ.app.st.tree.scale = 1; FZ.app.render(); return { w1: Math.round(w1), w2: Math.round(w2) }; });
  if (!(Math.abs(r.w1 - paper) <= 2 && Math.abs(r.w2 - paper) <= 2)) bad('tree figures show at their size on the paper, whatever the tree zoom', { paper, ...r });
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111b-app OK'); process.exit(fails ? 1 : 0);
})();
