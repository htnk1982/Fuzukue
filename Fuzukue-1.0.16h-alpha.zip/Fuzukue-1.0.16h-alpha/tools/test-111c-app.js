/* 1.0.11c：工程表 — 項目欄を任意の数と名前で（作る欄・設定の欄の ＋／−）・頁をまたぐと見出しの段（年度の段＋期間の段）を写す（画面・PowerPoint） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 500) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n用紙: A4 横\n文字数: 60\n行数: 20\n---\n[表題]工程\n\n', 'g.fzk', null); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('gantt'); }); await page.waitForTimeout(200);
  let r = await page.evaluate(() => { const e = document.querySelector('#sub input[name="labels"]'); return e && e.value; }); if (r !== 'テーマ・担当') bad('the make form has a free item-column field (default テーマ・担当)', r);
  await page.evaluate(() => { document.querySelector('#sub input[name="labels"]').value = 'テーマ・担当・状況'; document.querySelector('#sub input[name="rows"]').value = '30'; }); await page.keyboard.press('Enter'); await page.waitForTimeout(400);
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const ts = d.lines.findIndex(l => l.attrs.gantt); const W = FZ.app.ed.lay.geo.bodyCols; const cs = FZ.tableCells(d, ts, W); const tx = (i, c) => (d.lines[i].segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6) || { text: '' }).text.trim();
    return { ts, g: d.lines[ts].attrs.gantt, head: cs.slice(0, 4).map(c => tx(ts, c)), per: tx(ts + 1, cs[3]), right: cs[cs.length - 1].right, W, n: cs.length, bar: FZ.app.ed.lay.pages[0].shapes.some(s => s.kind === 'bar' && s.label === '計画') }; });
  if (!(r.g.labels === 3 && r.head.join() === 'テーマ,担当,状況,2026年度' && r.per === '4月' && r.n === 15 && r.right <= r.W && r.bar)) bad('three item columns: names, then the periods; bars still drawn', r);
  const ts = r.ts;
  /* 頁をまたぐ：2 頁目の頭に見出しの 2 段（年度の帯・期間）を写し、帯の中に縦罫を引かない */
  r = await page.evaluate(ts => { const L = FZ.app.ed.lay, p1 = L.pages[1]; if (!p1) return null; const rp = p1.repeats[0]; const txt = p1.glyphs.filter(g => g.rep).map(g => g.text).join(''); const cs = FZ.tableCells(FZ.app.ed.doc, ts, L.geo.bodyCols);
    const inBand = c => p1.vrules.some(v => Math.abs(v.col - c) < 1e-6 && v.y1 < rp.offs[1] - 0.01); const fills = p1.fills.filter(f => f.rep).length; return { rp, txt: txt.slice(0, 60), mid: inBand(cs[6].left), edge: inBand(cs[3].left), fills }; }, ts);
  if (!(r && r.rp.nh === 2 && /テーマ担当状況2026年度/.test(r.txt) && /4月5月/.test(r.txt) && !r.mid && r.edge && r.fills === 2)) bad('page 2 repeats both header rows (band + periods) with their shading', r);
  r = await page.evaluate(() => { const fs = FZ.toPptx(FZ.app.ed.doc, { files: true }); const s2 = fs.find(f => f.name === 'ppt/slides/slide2.xml'); const x = s2 ? (typeof s2.data === 'string' ? s2.data : new TextDecoder().decode(s2.data)) : ''; const tbl = (x.match(/<a:tbl>[\s\S]*<\/a:tbl>/) || [''])[0]; return { band: tbl.includes('2026年度'), month: tbl.includes('4月'), rowSpan: /rowSpan="2"/.test(tbl) }; });
  if (!(r.band && r.month && r.rowSpan)) bad('PowerPoint: the continuation slide repeats both header rows', r);
  /* 設定の欄：項目欄 ＋ で 4 欄（見出しは「項目」）、− で戻る。どちらも取消 1 回 */
  r = await page.evaluate(ts => { const ed = FZ.app.ed, d = ed.doc; ed.setCaret({ line: ts + 3, seg: 0, off: 0 }); FZ.app.run('gantt'); const before = FZ.serialize(d); const n0 = ed.undoStack.length;
    document.querySelector('#sub [data-act="lab+"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); const W = ed.lay.geo.bodyCols; const t = d.lines.findIndex(l => l.attrs.gantt); const cs = FZ.tableCells(d, t, W); const tx = c => (d.lines[t].segs.find(s => s.col >= c.left - 1e-6 && s.col < c.right - 1e-6) || { text: '' }).text.trim();
    const plus = { labels: d.lines[t].attrs.gantt.labels, names: cs.slice(0, 5).map(tx), undo: ed.undoStack.length - n0, n: cs.length, form: !!document.querySelector('#sub [data-act="lab-"]') };
    document.querySelector('#sub [data-act="lab-"]').dispatchEvent(new MouseEvent('click', { bubbles: true })); const minus = { labels: d.lines[t].attrs.gantt.labels, n: FZ.tableCells(d, t, W).length };
    ed.undo(); ed.undo(); return { plus, minus, back: FZ.serialize(d) === before }; }, ts);
  if (!(r.plus.labels === 4 && r.plus.names.includes('項目') && r.plus.names[4] === '2026年度' && r.plus.undo === 1 && r.plus.n === 16 && r.plus.form)) bad('＋ adds an item column (named 項目) inside the item area', r.plus);
  if (!(r.minus.labels === 3 && r.minus.n === 15 && r.back)) bad('− removes the last item column; undo restores', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111c-app OK'); process.exit(fails ? 1 : 0);
})();
