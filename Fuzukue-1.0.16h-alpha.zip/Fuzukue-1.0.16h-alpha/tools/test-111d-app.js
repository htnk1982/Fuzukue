/* 1.0.11d：基準の字幅（全角・半角を元の書体の何％で描くか、マスに収める）・書体の組（明朝・ゴシック・字幅を名前で保存） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const SRC = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n書体: ゴシック\nゴシック書体: IPAPGothic\n半角字幅: 60%\n---\nWindows Media Player とMMMwww iiii 「括弧」、句点。\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 原本：読み書き（100％ は書かない）、版面の倍率 */
  let r = await page.evaluate(s => { const d = FZ.parse(s); const t = FZ.serialize(d); const d0 = FZ.parse('#fzk 2\n全角字幅: 100%\n---\nあ\n'); return { han: d.format.hanW, zen: d.format.zenW, ser: /半角字幅: 60%/.test(t) && !/全角字幅/.test(t), g: FZ.geometry(d.format).hw, g0: FZ.geometry(d0.format).zw, ser0: /字幅/.test(FZ.serialize(d0)) }; }, SRC);
  if (!(r.han === 60 && r.zen == null && r.ser && r.g === 0.6 && r.g0 === 1 && !r.ser0)) bad('format keys 全角字幅／半角字幅 round-trip; 100% is not written', r);
  /* 画面：半角の字は 60％（はみ出す字はさらに縮める）でマスに収まり、マスの中ほど。100％ のときは従来どおり（変形なし） */
  await page.evaluate(async s => { await FZ.app.loadText(s, 'w.fzk', null); }, SRC); await page.waitForTimeout(400);
  r = await page.evaluate(() => { const L = FZ.app.ed.lay, geo = L.geo, svg = document.querySelector('#pages svg.pg'); const cw = geo.cw; const k = svg.getBoundingClientRect().width / geo.W;
    const gl = L.pages[0].glyphs.filter(g => g.line === 0 && g.text.trim()); const sr = svg.getBoundingClientRect(); const out = [];
    /* 字ごとの描いた幅：<text> の各字の位置と幅（getExtentOfChar は変形の前の座標なので、変形を掛けた外接矩形で調べる） */
    for (const t of svg.querySelectorAll('g.txt text')) { const n = t.getNumberOfChars(); const m = t.getCTM(); const sm = svg.getCTM(); for (let i = 0; i < n; i++) { const e = t.getExtentOfChar(i); const p0 = new DOMPoint(e.x, e.y).matrixTransform(m), p1 = new DOMPoint(e.x + e.width, e.y).matrixTransform(m); const inv = sm.inverse(); const a = p0.matrixTransform(inv), b = p1.matrixTransform(inv); out.push({ ch: t.textContent[i], x0: a.x, x1: b.x }); } }
    const res = []; for (const g of gl) { const o = out.find(q => q.ch === g.text && !q.used && Math.abs(q.x0 - (geo.left + g.col * cw)) < cw * g.w + 0.5); if (!o) { res.push({ ch: g.text, miss: true }); continue; } o.used = true; const c0 = geo.left + g.col * cw, c1 = c0 + g.w * cw; res.push({ ch: g.text, in: o.x0 >= c0 - 0.05 && o.x1 <= c1 + 0.05, mid: Math.abs((o.x0 + o.x1) / 2 - (c0 + c1) / 2), w: +(o.x1 - o.x0).toFixed(2), cell: +(c1 - c0).toFixed(2) }); }
    const scaled = [...svg.querySelectorAll('g.txt text[transform]')].length; return { res, scaled, cw }; });
  const half = r.res.filter(q => /[A-Za-z]/.test(q.ch)); const outside = r.res.filter(q => q.miss || !q.in);
  if (outside.length) bad('every glyph sits inside its cell', outside.slice(0, 6));
  if (!(half.length > 20 && half.every(q => q.mid < 0.15) && r.scaled > 0)) bad('half-width glyphs are scaled and centred in their half cells', { scaled: r.scaled, h: half.slice(0, 6) });
  const W = half.find(q => q.ch === 'W'), i = half.find(q => q.ch === 'i'); if (!(W && i && W.w <= W.cell + 0.05 && W.w > i.w * 1.5)) bad('a wide glyph (W) is squeezed into the cell, a narrow one (i) keeps its shape', { W, i });
  const op = r.res.find(q => q.ch === '「'), cl = r.res.find(q => q.ch === '」'), cm = r.res.find(q => q.ch === '、'); /* 全角は 100％：従来どおり（変形も寄せもなし。始め括弧も頭から） */
  if (!(op && cl && cm && op.in && cl.in && cm.in)) bad('full-width punctuation stays in its cell', { op, cl, cm });
  /* 全角も縮めると始め括弧は右、句読点・終わり括弧は左に寄る */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.mutate('', () => { ed.doc.format.zenW = 80; }); FZ.app.render(); const L = ed.lay, geo = L.geo, svg = document.querySelector('#pages svg.pg'); const gl = L.pages[0].glyphs.filter(g => g.line === 0);
    const pos = ch => { const g = gl.find(q => q.text === ch); const c0 = geo.left + g.col * geo.cw; for (const t of svg.querySelectorAll('g.txt text')) { const n = t.getNumberOfChars(); for (let k = 0; k < n; k++) { if (t.textContent[k] !== ch) continue; const e = t.getExtentOfChar(k); const m = t.getCTM(), inv = svg.getCTM().inverse(); const a = new DOMPoint(e.x, e.y).matrixTransform(m).matrixTransform(inv), b = new DOMPoint(e.x + e.width, e.y).matrixTransform(m).matrixTransform(inv); return { l: +(a.x - c0).toFixed(2), r: +(c0 + geo.cw - b.x).toFixed(2) }; } } return null; };
    return { op: pos('「'), cl: pos('」'), cm: pos('、'), ka: pos('括'), ser: /全角字幅: 80%/.test(FZ.serialize(ed.doc)) }; });
  if (!(r.ser && r.op && r.op.r < 0.2 && r.op.l > 0.5 && r.cl.l < 0.2 && r.cm.l < 0.2 && Math.abs(r.ka.l - r.ka.r) < 0.3)) bad('full-width at 80%: opening bracket right, closing/comma left, kanji centred', r);
  /* Word：字幅の比率（w:w）と字間で 1 字＝1 マス */
  r = await page.evaluate(() => { const fs = FZ.toDocx(FZ.app.ed.doc, { files: true }); const f = fs.find(x => x.name === 'word/document.xml'); const x = typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data); const runW = x.match(/<w:r><w:rPr>(?:(?!<\/w:rPr>).)*<w:w w:val="60"\/>(?:(?!<\/w:rPr>).)*<\/w:rPr><w:t xml:space="preserve">Windows Media/); const runZ = /<w:w w:val="80"\/>(?:(?!<\/w:rPr>).)*<\/w:rPr><w:t xml:space="preserve">[^<]*括弧/.test(x); return { runW: !!runW, runZ }; });
  if (!(r.runW && r.runZ)) bad('Word: half-width runs get w:w 60, full-width runs w:w 80', r);
  /* 書式の画面：基準の字幅の欄・測る・書体の組（内蔵・保存・当てる・削除） */
  r = await page.evaluate(async () => { localStorage.removeItem('fz.fontProfiles'); FZ.app.run('format'); await new Promise(r => setTimeout(r, 150)); const q = n => document.querySelector(`#sub [name="${n}"]`); const v0 = { zen: q('zenW').value, han: q('hanW').value, prof: q('fprof').value };
    document.querySelector('#sub [data-act="fit"]').click(); const fit = { zen: q('zenW').value, han: q('hanW').value };
    q('fpname').value = '社内資料'; document.querySelector('#sub [data-act="fpsave"]').click(); const saved = JSON.parse(localStorage.getItem('fz.fontProfiles') || '[]'); const selName = q('fprof').selectedOptions[0].textContent;
    const sel = q('fprof'); sel.value = '0'; sel.dispatchEvent(new Event('change')); const biz = { mi: q('fontMincho').value, go: q('fontGothic').value, zen: q('zenW').value, han: q('hanW').value };
    const k = [...sel.options].findIndex(o => o.textContent === '社内資料＊'); sel.value = String(k); sel.dispatchEvent(new Event('change')); const back = { go: q('fontGothic').value, han: q('hanW').value };
    document.querySelector('#sub [data-act="apply"]').click(); await new Promise(r => setTimeout(r, 100)); const f = FZ.app.ed.doc.format;
    FZ.app.run('format'); await new Promise(r => setTimeout(r, 150)); const sel2 = document.querySelector('#sub [name="fprof"]'); const match = sel2.selectedOptions[0].textContent; sel2.value = String(k); document.querySelector('#sub [data-act="fpdel"]').click(); const after = JSON.parse(localStorage.getItem('fz.fontProfiles') || '[]').length; document.querySelector('#sub [data-act="cancel"]').click();
    return { v0, fit, saved, selName, biz, back, f: { go: f.fontGothic, han: f.hanW, zen: f.zenW }, match, after }; });
  if (!(r.v0.zen === '80' && r.v0.han === '60')) bad('the form shows the current base widths', r.v0);
  if (!(+r.fit.han < 100 && +r.fit.han >= 30 && +r.fit.zen <= 100 && +r.fit.zen >= 90)) bad('測る: a proportional gothic gets a half-width % below 100, full-width about 100', r.fit);
  if (!(r.saved.length === 1 && r.saved[0].name === '社内資料' && r.saved[0].gothic === 'IPAPGothic' && r.saved[0].han === +r.fit.han && r.selName === '社内資料＊')) bad('a named profile saves the gothic, mincho and widths', r);
  if (!(r.biz.mi === 'BIZ UDMincho' && r.biz.go === 'BIZ UDGothic' && r.biz.zen === '100' && r.biz.han === '100')) bad('the built-in BIZ UD profile fills the fields', r.biz);
  if (!(r.back.go === 'IPAPGothic' && r.back.han === String(r.saved[0].han))) bad('choosing the saved profile fills its fonts and widths back', r.back);
  if (!(r.f.go === 'IPAPGothic' && r.f.han === r.saved[0].han && (r.f.zen == null ? 100 : r.f.zen) === r.saved[0].zen && r.match === '社内資料＊' && r.after === 0)) bad('apply sets the document fonts/widths; reopening shows the profile; delete removes it', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111d-app OK'); process.exit(fails ? 1 : 0);
})();
