/* 1.0.11e：図表の大きさ（欄の n 等分 × ％、原寸の ％、高さは比例）・並べ方・グラフのデータを Excel のような表で直す（小数・千区切り） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 600) : '')); };
const DOC = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n売上の推移\n#グラフ G1 図 棒 1/2 東日本\n#データ | | 2024 | 2025 |\n#データ | 売上 | 1234 | 2345 |\n#グラフ G2 図 棒 1/2 西日本\n#データ | | 2024 | 2025 |\n#データ | 売上 | 3456 | 4567 |\n次の段落\n#グラフ G3 図 折れ線 1/3 70% 全国\n#データ | | 2024 | 2025 |\n#データ | 売上 | 1 | 2 |\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 原本：大きさの書き方（1/2・70%・原寸50%）の読み書き。昔の 50% はそのまま（1/2 と同じ大きさ） */
  let r = await page.evaluate(src => { const d = FZ.parse(src); const figs = d.lines.flatMap(l => l.attrs.figs || []); const t = FZ.serialize(d);
    const d2 = FZ.parse('#fzk 2\n---\nあ\n#図版 F1 図 題 a.png 原寸50%\n#図版 F2 図 50%題 b.png\n#図版 F3 表 古い - 50%\n'); const f2 = d2.lines.flatMap(l => l.attrs.figs || []); const t2 = FZ.serialize(d2);
    return { g: figs.map(f => [f.id, f.div || 1, f.width, f.title]), ser: /#グラフ G1 図 棒 1\/2 東日本/.test(t) && /#グラフ G3 図 折れ線 1\/3 70% 全国/.test(t), f2: f2.map(f => [f.id, f.orig || 0, f.width, f.title, f.file]), t2: t2.split('\n').filter(l => l.startsWith('#図版')) }; }, DOC);
  if (!(JSON.stringify(r.g) === JSON.stringify([['G1', 2, 100, '東日本'], ['G2', 2, 100, '西日本'], ['G3', 3, 70, '全国']]) && r.ser)) bad('#グラフ size tokens 1/2・1/3 70% parse and serialize', r);
  if (!(r.f2[0][1] === 50 && r.f2[1][3] === '50%題' && r.f2[2][2] === 50 && r.t2[0] === '#図版 F1 図 題 a.png 原寸50%' && r.t2[2] === '#図版 F3 表 古い - 50%')) bad('#図版: 原寸50% and the old 50% read and write back', r);
  /* 組版：1/2 の 2 つは横に並んで欄いっぱい、1/3 70% は 1 つ分の 70%・中ほど。高さは縦横の比 */
  await page.evaluate(async src => { await FZ.app.loadText(src, 'f.fzk', null); }, DOC); await page.waitForTimeout(300);
  r = await page.evaluate(() => { const L = FZ.app.ed.lay, geo = L.geo; const ims = L.pages.flatMap(p => p.images); const by = id => ims.find(i => i.id === id); const a = by('G1'), b = by('G2'), c = by('G3'); const W = geo.bodyCols || geo.cols;
    const h2 = v => Math.floor(v * 2 + 1e-6) / 2; const slot3 = h2((W + 1) / 3 - 1), w3 = h2((slot3 + 1) * 0.7 - 1); return { a, b, c, W, slot3, w3, ih: Math.round(a.w * geo.cw * 0.6 / geo.ch) }; });
  if (!(r.a.y === r.b.y && r.a.w === r.b.w && r.a.col === 0 && r.b.col === r.a.w + 1 && r.a.w * 2 + 1 === r.W)) bad('two 1/2 charts sit side by side and fill the width', r);
  if (!(r.c.w === r.w3 && Math.abs(r.c.col - (r.W - r.c.w) / 2) <= 0.5 && r.a.h === r.ih)) bad('a 1/3 70% chart takes 70% of a third, centred; height follows the ratio', r);
  /* 原寸：200×100 画素の画像は 150pt 幅（96dpi）の 100％、50％ はその半分 */
  r = await page.evaluate(() => { const cv = document.createElement('canvas'); cv.width = 200; cv.height = 100; const data = cv.toDataURL('image/png').split(',')[1]; const ed = FZ.app.ed; ed.setCaret({ line: 0, seg: 0, off: 0 }); const nm = ed.addImage('image/png', data, 'p.png'); const id = ed.addFigure({ file: nm, kind: '図', title: '原寸', orig: 100 });
    const im = () => FZ.app.ed.lay.pages.flatMap(p => p.images).find(i => i.id === id); const geo = ed.lay.geo; const w1 = im().w; ed.setFig(id, { orig: 50 }); const w2 = im().w; ed.setFig(id, { orig: 0, div: 4, width: 100 }); const w3 = im().w, x = ed.figById(id).fg; ed.undo(); ed.undo(); ed.undo(); ed.undo();
    return { w1, e1: Math.round(150 / geo.cw * 2) / 2, w2, e2: Math.round(75 / geo.cw * 2) / 2, w3, e3: Math.floor(((geo.cols + 1) / 4 - 1) * 2) / 2, x: { div: x.div, orig: x.orig, width: x.width } }; });
  if (!(r.w1 === r.e1 && r.w2 === r.e2 && r.w3 === r.e3 && r.x.div === 4 && r.x.orig == null)) bad('原寸 % of an image (96dpi), and back to 1/4', r);
  /* Word：グラフの幅は 1/2 なら版面の半分（間 1 マス）。Markdown：大きさを注記で往復 */
  r = await page.evaluate(() => { const ed = FZ.app.ed, geo = ed.lay.geo; const fs = FZ.toDocx(ed.doc, { files: true }); const x = new TextDecoder().decode(fs.find(f => f.name === 'word/document.xml').data instanceof Uint8Array ? fs.find(f => f.name === 'word/document.xml').data : new TextEncoder().encode(fs.find(f => f.name === 'word/document.xml').data));
    const cx = [...x.matchAll(/<wp:extent cx="(\d+)"/g)].map(m => +m[1]); const half = Math.floor(((geo.cols + 1) / 2 - 1) * 2) / 2 * geo.cw * 12700; const md = FZ.toGfm(ed.doc, { fz: true }); const back = md ? FZ.fromGfm(md).lines.flatMap(l => l.attrs.figs || []).map(f => [f.id, f.div || 1, f.width]) : null;
    return { cx, half: Math.round(half), md: (md.match(/<!-- 図版 [^>]*-->/g) || []).slice(0, 3), back }; });
  if (!(Math.abs(r.cx[0] - r.half) < 13000 && Math.abs(r.cx[1] - r.half) < 13000)) bad('Word: a 1/2 chart is half the text width', r);
  if (!(r.md.length && r.md[0].includes('1/2') && r.back && JSON.stringify(r.back.slice(0, 3)) === JSON.stringify([['G1', 2, 100], ['G2', 2, 100], ['G3', 3, 70]]))) bad('Markdown: size tokens round-trip in the 図版 comment', r);
  /* 図表の欄：大きさ（欄の幅・1/2…・原寸）と％、決まった大きさを出す */
  r = await page.evaluate(async () => { FZ.app.st.figSel = 'G3'; FZ.app.openForm('chart'); await new Promise(r => setTimeout(r, 100)); const q = n => document.querySelector(`#sub [name="${n}"]`); const v0 = { fsz: q('fsz').value, fpc: q('fpc').value, info: document.getElementById('figSz').textContent };
    q('fsz').value = '2'; q('fsz').dispatchEvent(new Event('change')); q('fpc').value = '100'; q('fpc').dispatchEvent(new Event('input')); await new Promise(r => setTimeout(r, 600)); const fg = FZ.app.ed.figById('G3').fg; return { v0, after: { div: fg.div, width: fg.width }, info: document.getElementById('figSz').textContent }; });
  if (!(r.v0.fsz === '3' && r.v0.fpc === '70' && /マス/.test(r.v0.info) && r.after.div === 2 && r.after.width === 100 && r.info !== r.v0.info)) bad('chart form: size select and % apply at once; the info shows the cells', r);
  /* 小数・千区切り：紙面の値と Excel の書式、原本 */
  r = await page.evaluate(async () => { const q = n => document.querySelector(`#sub [name="${n}"]`); q('dec').value = '1'; q('dec').dispatchEvent(new Event('change')); q('sep').value = '0'; q('sep').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 100));
    FZ.app.st.figSel = 'G1'; FZ.app.openForm('chart'); await new Promise(r => setTimeout(r, 100)); q('dec').value = '1'; q('dec').dispatchEvent(new Event('change')); q('sep').value = '0'; q('sep').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 100));
    const c = FZ.app.ed.figById('G1').fg.chart; const svg = FZ.chartSvg(c, 0, 0, 300, 180, { fs: 10 }); const sep1 = FZ.chartSvg({ ...c, sep: true }, 0, 0, 300, 180, { fs: 10 }); const xml = FZ.chartXml(c, { latin: 'a', ea: 'a', sz: 900, ext: 'rId1' }); const ser = FZ.serialize(FZ.app.ed.doc);
    return { dec: c.dec, sep: c.sep, plain: />1234\.0</.test(svg), comma: />1,234\.0</.test(sep1), code: /formatCode="0\.0"/.test(xml), ser: /#グラフ設定 小数=1 千区切り=なし/.test(ser), back: (() => { const d = FZ.parse(ser); const f = d.lines.flatMap(l => l.attrs.figs || []).find(x => x.id === 'G1'); return [f.chart.dec, f.chart.sep]; })() }; });
  if (!(r.dec === 1 && r.sep === false && r.plain && r.comma && r.code && r.ser && r.back[0] === 1 && r.back[1] === false)) bad('decimals and thousands separator: paper labels, Excel format code, source file', r);
  /* データの表：セルで直す（離れると反映）・Enter で下へ・範囲の貼り付けで広がる・＋系列・−項目 */
  r = await page.evaluate(async () => { document.querySelector('#sub [data-act="data"]').click(); await new Promise(r => setTimeout(r, 100)); const cells = () => [...document.querySelectorAll('#sub .chgrid input.cg')]; const at = (r, c) => document.querySelector(`#sub .chgrid input.cg[data-r="${r}"][data-c="${c}"]`);
    const n0 = cells().length, focus0 = document.activeElement === at(1, 1); const e = at(1, 1); e.value = '1500'; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); const v1 = FZ.app.ed.figById('G1').fg.chart.series[0].values[0]; const stay = !!document.querySelector('#sub .chgrid') && document.body.contains(e);
    at(0, 1).focus(); at(0, 1).dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); const down = document.activeElement && document.activeElement.dataset ? [document.activeElement.dataset.r, document.activeElement.dataset.c] : null;
    const dt = new DataTransfer(); dt.setData('text/plain', '10\t20\t30\n40\t50\t60\n'); at(1, 1).focus(); at(1, 1).dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true })); const c2 = FZ.app.ed.figById('G1').fg.chart;
    const pasted = { cats: c2.cats.length, series: c2.series.length, v: c2.series.map(s => s.values), n: cells().length };
    document.querySelector('#sub [data-act="gr+"]').click(); const c3 = FZ.app.ed.figById('G1').fg.chart; const added = { series: c3.series.length, name: c3.series[c3.series.length - 1].name, focus: document.activeElement.dataset && document.activeElement.dataset.r };
    document.querySelector('#sub [data-act="gc-"]').click(); const c4 = FZ.app.ed.figById('G1').fg.chart;
    return { n0, focus0, v1, stay, down, pasted, added, cats4: c4.cats.length }; });
  if (!(r.n0 === 6 && r.focus0 && r.v1 === 1500 && r.stay)) bad('the data grid edits a cell and applies when leaving it (the grid stays)', r);
  if (!(r.down && r.down[0] === '1' && r.down[1] === '1')) bad('Enter moves to the cell below', r.down);
  if (!(r.pasted.cats === 3 && r.pasted.series === 2 && JSON.stringify(r.pasted.v) === '[[10,20,30],[40,50,60]]' && r.pasted.n === 12)) bad('pasting an Excel range fills from the cell and grows the grid', r.pasted);
  if (!(r.added.series === 3 && r.added.name === '系列3' && r.added.focus === '3' && r.cats4 === 2)) bad('＋系列 adds a row, −項目 removes the last column', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111e-app OK'); process.exit(fails ? 1 : 0);
})();
