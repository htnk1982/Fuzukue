/* 1.0.11f：新聞のグラフ — 面・棒と折れ線（2 軸）・ドーナツ・滝・段々の折れ線・左右の棒・階段・矢印、軸の省略（波線）、線の端の名前。Office へは Excel のグラフか図形の組 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
const DOC = `#fzk 2
用紙: A4 縦
文字数: 40
行数: 36
---
グラフ
#グラフ w 図 滝 1/2 増減要因
#データ | | 前期 | 数量 | 価格 | 原材料 | 今期 |
#データ | 利益 | 1200 | 180 | 90 | -240 | |
#グラフ設定 単位=億円
#グラフ c 図 棒と折れ線 1/2 売上と利益率
#データ | | 2023 | 2024 | 2025 |
#データ | 売上 | 820 | 870 | 990 |
#データ | 利益率 | 5.2 | 6.1 | 7.4 |
#グラフ設定 単位=億円|%
次
#グラフ p 図 段々の折れ線 1/2 市場
#データ | | 1月 | 2月 | 3月 | 4月 |
#データ | 株価 | 38500 | 39200 | 40100 | 42000 |
#データ | 円相場 | 148 | 150 | 151 | 145 |
#データ | 金利 | 0.72 | 0.75 | 0.89 | 1.12 |
#グラフ y 図 左右の棒 1/2 人口
#データ | | 0-19 | 20-39 | 40- |
#データ | 男性 | 1050 | 1320 | 1680 |
#データ | 女性 | 1000 | 1280 | 1650 |
`;
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1100, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 種類の名前と原本 */
  let r = await page.evaluate(src => { const names = FZ.CHART_TYPES.map(t => t[1]); const d = FZ.parse(src); const figs = d.lines.flatMap(l => l.attrs.figs || []); const t = FZ.serialize(d);
    return { names, types: figs.map(f => f.chart.type), ser: /#グラフ w 図 滝 1\/2 増減要因/.test(t) && /#グラフ p 図 段々の折れ線/.test(t), unit: figs[1].chart.unit }; }, DOC);
  if (!(['面', '棒と折れ線', 'ドーナツ', '滝', '段々の折れ線', '左右の棒', '階段', '矢印'].every(n => r.names.includes(n)) && r.types.join() === 'waterfall,combo,panels,pyramid' && r.ser && r.unit === '億円|%')) bad('new chart types parse and serialize', r);
  /* 図形：滝・棒と折れ線・段々・左右・ドーナツ・階段・矢印 */
  r = await page.evaluate(src => { const d = FZ.parse(src); const figs = d.lines.flatMap(l => l.attrs.figs || []); const sh = c => FZ.chartShapes(c, 300, 180, 10); const W = figs[0].chart, C = figs[1].chart, P = figs[2].chart, Y = figs[3].chart;
    const ws = sh(W); const bars = ws.filter(s => s.t === 'rect' && s.hit); const texts = ws.filter(s => s.t === 'text').map(s => s.text); const conn = ws.filter(s => s.t === 'line' && s.dash === '1 1').length;
    const cs = sh(C); const cb = cs.filter(s => s.t === 'rect' && s.s === 0 && s.hit), cl = cs.filter(s => s.t === 'path' && s.s === 1); const lineTop = Math.min(...cl[0].pts.map(p => p.y)), barTop = Math.min(...cb.map(b => b.y));
    const ps = sh(P); const pp = ps.filter(s => s.t === 'path' && s.pts).length, ptitles = ps.filter(s => s.t === 'text' && s.bold).map(s => s.text), pbrk = ps.filter(s => s.t === 'poly' && s.white).length;
    const ys = sh(Y); const L = ys.filter(s => s.t === 'rect' && s.s === 0), R = ys.filter(s => s.t === 'rect' && s.s === 1); const yOne = FZ.chartShapes({ ...Y, series: [Y.series[0]] }, 300, 180, 10).filter(s => s.t === 'rect' && s.hit);
    const dn = FZ.chartShapes(FZ.normalizeChart({ type: 'donut', cats: ['a', 'b'], series: [{ name: '計', values: [60, 40] }], unit: '兆円' }), 300, 180, 10); const dw = dn.filter(s => s.t === 'wedge'); const dt = dn.filter(s => s.t === 'text').map(s => s.text);
    const st = FZ.chartShapes(FZ.normalizeChart({ type: 'step', cats: ['a', 'b', 'c'], series: [{ name: '金利', values: [0.1, 0.25, 0.5] }] }), 300, 180, 10).find(s => s.t === 'path'); const nums = st.d.match(/-?[\d.]+/g).map(Number); let horiz = 0; for (let k = 2; k + 1 < nums.length; k += 2) if (Math.abs(nums[k + 1] - nums[k - 1]) < 1e-6 && nums[k] !== nums[k - 2]) horiz++;
    const ar = FZ.chartShapes(FZ.normalizeChart({ type: 'arrow', cats: ['東京', '大阪'], series: [{ name: '2024', values: [3.2, 2.8] }, { name: '2025', values: [3.9, 2.0] }] }), 300, 180, 10); const heads = ar.filter(s => s.t === 'poly' && s.fill === 'dark').length, opens = ar.filter(s => s.t === 'mark' && !s.fill).length;
    return { bars: bars.map(b => b.fill), total: texts.includes('1,230'), up: texts.includes('+180'), down: texts.includes('−240') || texts.includes('-240'), conn, lineAbove: lineTop < barTop, cb: cb.length, pp, ptitles, pbrk, L: L.length, R: R.length, lr: L.every(a => R.every(b => a.x + a.w <= b.x + 0.01)), yOne: yOne.length, ri: dw.every(w => w.ri > 0), dt, horiz, heads, opens }; }, DOC);
  if (!(r.bars.join() === 'mid,dark,dark,none,mid' && r.total && r.up && r.down && r.conn === 4)) bad('waterfall: totals (mid), up (black), down (white), computed end total, connectors', r);
  if (!(r.cb === 3 && r.lineAbove)) bad('bar + line: bars on the left axis, the line above them on the right axis', r);
  if (!(r.pp === 3 && ['株価', '円相場', '金利'].every(t => r.ptitles.includes(t)) && r.pbrk >= 1)) bad('stacked panels: one line per panel with its name, axis omission marked', r);
  if (!(r.L === 3 && r.R === 3 && r.lr && r.yOne === 3)) bad('left-right bars: first series left, second right; one series falls back to horizontal bars', r);
  if (!(r.ri && r.dt.includes('100') && r.dt.includes('兆円'))) bad('donut: ring with the total and unit in the middle', r.dt);
  if (!(r.horiz >= 2)) bad('step: the value runs flat until it changes', r.horiz);
  if (!(r.heads === 2 && r.opens === 2)) bad('arrow: open circle (before) to an arrowhead (after) for each item', r);
  /* 軸の省略：折れ線は自動で波線、棒は「省略=あり」で棒を横切る波線、「なし」で 0 から。線の端に系列名 */
  r = await page.evaluate(() => { const base = { cats: ['a', 'b', 'c'], series: [{ name: '東京', values: [1394, 1404, 1412] }, { name: '神奈川', values: [920, 923, 922] }] };
    const ln = FZ.chartShapes(FZ.normalizeChart({ ...base, type: 'line', legend: 'end' }), 300, 180, 10); const lnBrk = ln.filter(s => s.t === 'poly' && s.white).length; const axis = ln.some(s => s.t === 'line' && Math.abs(s.x1 - s.x2) < 1e-6 && s.y2 - s.y1 > 50);
    const lastX = Math.max(...ln.filter(s => s.t === 'mark').map(s => s.x)); const ends = ln.filter(s => s.t === 'text' && (s.text === '東京' || s.text === '神奈川')); const legendRects = ln.filter(s => s.leg).length;
    const bar = c => FZ.chartShapes(FZ.normalizeChart({ type: 'bar', cats: ['A', 'B'], series: [{ name: '', values: [980, 1040] }], ...c }), 300, 180, 10); const bOn = bar({ brk: true }), bOff = bar({});
    const band = bOn.find(s => s.t === 'poly' && s.white); const bars = bOn.filter(s => s.t === 'rect' && s.hit); const ser = FZ.chartLines({ id: 'x', kind: '図', title: '', width: 100, chart: FZ.normalizeChart({ type: 'bar', cats: ['A'], series: [{ name: '', values: [1] }], brk: true }) }).join('\n');
    return { lnBrk, axis, ends: ends.map(e => e.x > lastX), legendRects, band: band ? Math.max(...band.pts.map(p => p[0])) - Math.min(...band.pts.map(p => p[0])) : 0, barsW: bars.length ? Math.max(...bars.map(b => b.x + b.w)) - Math.min(...bars.map(b => b.x)) : 0, off: bOff.filter(s => s.t === 'poly').length, ser: /省略=あり/.test(ser), back: FZ.parse('#fzk 2\n---\nあ\n' + ser).lines.flatMap(l => l.attrs.figs || [])[0].chart.brk }; });
  if (!(r.lnBrk === 1 && r.axis)) bad('line chart not starting at 0 shows the axis with a break mark', r);
  if (!(r.ends.length === 2 && r.ends.every(Boolean) && r.legendRects === 0)) bad('凡例=線の端: series names at the line ends instead of a legend', r);
  if (!(r.band > r.barsW && r.off === 0 && r.ser && r.back === true)) bad('bars with 省略=あり: a white band with wavy lines across the bars; 省略 round-trips', r);
  /* Office：面・棒と折れ線・ドーナツは Excel のグラフ、滝・段々・左右は図形の組 */
  r = await page.evaluate(async src => { await FZ.app.loadText(src, 'n.fzk', null); const dec = d => typeof d === 'string' ? d : new TextDecoder().decode(d); const doc = FZ.app.ed.doc;
    const dx = FZ.toDocx(doc, { files: true }); const body = dec(dx.find(f => f.name === 'word/document.xml').data); const charts = dx.filter(f => /^word\/charts\/chart\d+\.xml$/.test(f.name)).map(f => dec(f.data));
    const px = FZ.toPptx(doc, { files: true }); const sl = px.filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f.name)).map(f => dec(f.data)).join('');
    const combo = FZ.chartXml(doc.lines.flatMap(l => l.attrs.figs || []).find(f => f.id === 'c').chart, {}); const area = FZ.chartXml(FZ.normalizeChart({ type: 'area', cats: ['a', 'b'], series: [{ name: 'x', values: [1, 2] }, { name: 'y', values: [2, 3] }] }), {}); const donut = FZ.chartXml(FZ.normalizeChart({ type: 'donut', cats: ['a', 'b'], series: [{ name: 'x', values: [1, 2] }] }), {});
    return { native: ['area', 'combo', 'donut', 'waterfall', 'panels', 'pyramid', 'step', 'arrow'].map(t => FZ.chartNative({ type: t })), wgp: (body.match(/<wpg:wgp>/g) || []).length, wordCharts: charts.length, grp: (sl.match(/<p:grpSp>/g) || []).length, txt: /<a:t>\+180<\/a:t>/.test(sl) && /<w:t xml:space="preserve">\+180<\/w:t>/.test(body),
      combo: /<c:barChart>/.test(combo) && /<c:lineChart>/.test(combo) && /<c:axPos val="r"\/>/.test(combo) && /（%）/.test(combo), area: /<c:areaChart><c:grouping val="stacked"\/>/.test(area), donut: /<c:doughnutChart>/.test(donut) && /<c:holeSize val="56"\/>/.test(donut) && !/dLblPos/.test(donut) }; }, DOC);
  if (!(r.native.join() === 'true,true,true,false,false,false,false,false')) bad('which types are Excel charts', r.native);
  if (!(r.wgp === 3 && r.wordCharts === 1 && r.grp === 3 && r.txt)) bad('Word/PowerPoint: waterfall, panels, pyramid as shape groups (with their labels), the combo as an Excel chart', r);
  if (!(r.combo && r.area && r.donut)) bad('Excel chart XML: combo with a right axis, stacked area, doughnut', r);
  /* Markdown の注記で往復（種類と設定） */
  r = await page.evaluate(() => { const c = FZ.normalizeChart({ type: 'waterfall', cats: ['a', 'b'], series: [{ name: 'x', values: [1, 2] }], tot: 'first', brk: false, dec: 1 }); const note = FZ.chartNote(c); const back = FZ.chartFromNote(note, FZ.chartToGrid(c)); return { note, back: [back.type, back.tot, back.brk, back.dec] }; });
  if (!(/グラフ：滝/.test(r.note) && r.back.join() === 'waterfall,first,false,1')) bad('Markdown note carries the type and options', r);
  /* グラフの欄：種類に新しい形、滝にすると「合計」の欄 */
  r = await page.evaluate(async () => { FZ.app.st.figSel = 'c'; FZ.app.openForm('chart'); await new Promise(r => setTimeout(r, 100)); const q = n => document.querySelector(`#sub [name="${n}"]`); const opts = [...q('type').options].map(o => o.textContent); const tot0 = !!q('tot');
    q('type').value = 'waterfall'; q('type').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 100)); const tot1 = !!q('tot'); q('tot').value = 'none'; q('tot').dispatchEvent(new Event('change')); q('brk').value = '1'; q('brk').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 100));
    const c = FZ.app.ed.figById('c').fg.chart; FZ.app.run('undo'); return { opts: opts.length, has: opts.includes('滝'), tot0, tot1, type: c.type, tot: c.tot, brk: c.brk }; });
  if (!(r.has && r.opts >= 14 && !r.tot0 && r.tot1 && r.type === 'waterfall' && r.tot === 'none' && r.brk === true)) bad('chart form: new types, 合計 appears for 滝, 軸の省略', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111f-app OK'); process.exit(fails ? 1 : 0);
})();
