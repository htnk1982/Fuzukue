/* 1.0.11g：PowerPoint（.pptx）の取り込み — スライド→資料の頁、段と列→区画、表・画像・グラフ、ノート→付箋、柱の字→書式。文机の書き出しを読み戻しても構造が戻る */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* python-pptx で作った 5 枚：表紙・箇条書きとノート・3 つの箱と矢印・グラフと字・表と画像 */
  const deck = Array.from(fs.readFileSync(path.resolve(__dirname, 'sample-pptx/test.pptx')));
  let r = await page.evaluate(async d => { const r = await FZ.fromPptx(new Uint8Array(d), { title: 'test' }); const t = r.text.split('\n'); const doc = r.doc; return { t, stats: r.stats, title: doc.title, cover: doc.format.cover, kind: doc.format.kind, images: Object.keys(doc.images), notes: (doc.notes || []).length || (FZ.serialize(doc).match(/#付箋 n1 ノート/) ? 1 : 0), lines: doc.lines.length }; }, deck);
  const T = r.t; const at = s => T.indexOf(s);
  if (!(r.stats.slides === 5 && T.filter(l => l.startsWith('[表題')).length === 5 && r.title === '2026年度 事業計画' && r.cover === true && r.kind === 'slide')) bad('slides become pages; the title slide gives the document title and a cover', r);
  if (!(at('[項目1]売上は前年比 3% 増') > 0 && at('[項目2]国内は横ばい') > at('[項目1]売上は前年比 3% 増') && at('[項目1]利益率は 6.1% に改善') > 0)) bad('body placeholder paragraphs become bullets with their levels', T.slice(0, 10));
  if (!(T.includes('[表題 付箋:n1]上期の振り返り') && r.notes)) bad('speaker notes become a note (付箋) on the slide title', T.slice(0, 6));
  const p0 = at('[番号1 区画横 区画見出し濃灰 区画矢印]現状から打ち手へ'); /* 1.0.12f 箱の塗り（白い字）→ 濃灰の見出し */ if (!(p0 > 0 && T[p0 + 1] === '[番号2]現状' && T.includes('[番号2]課題') && T.includes('[番号2]打ち手') && T.includes('受注から出荷まで平均 24 日'))) bad('three boxes side by side with arrows become panels under the bar above them', T.slice(p0 - 1, p0 + 12));
  const g = at('#グラフ g1 図 棒 60%'); /* 1.0.12f 版面の幅（余白を除く）に対する比 */ if (!(g > 0 && T[g + 1] === '#データ |  | 2023 | 2024 | 2025 |' && T[g + 2] === '#データ | 国内 | 128 | 140 | 141 |' && at('[番号1]ポイント') > 0 && at('[番号1]ポイント') < g)) bad('a chart with a text box beside it: the text, then the chart with its data', T.slice(g - 3, g + 4));
  if (!(at('#表 列 0,10.5,21.5,32 様式 格子 見出し淡') > 0 && T.includes('| 利益率 | 6.1% | 7.0% |') && r.images.length === 1 && T.some(l => /^#図版 p\d 図 画像1\.png 35%$/.test(l)))) /* 1.0.12f 字数は本文の字の大きさから（48 字） */ bad('a table and a picture', T.slice(-14));
  /* 文机の書き出し（A3 の区画の見本）を読み戻す：区画・見出し・箇条書き・グラフの題とデータ・表、柱の字は書式へ、表の上の字は捨てる、A3 の大きさ */
  r = await page.evaluate(async s => { const d = FZ.parse(s); const bytes = await FZ.zipAsync(FZ.toPptx(d, { files: true })); const r = await FZ.fromPptx(bytes, { title: 't', format: JSON.parse(JSON.stringify(FZ.app.ed.doc.format)) }); return { t: r.text.split('\n'), f: { paper: r.doc.format.paper, cols: r.doc.format.cols, secret: r.doc.format.secret, date: r.doc.format.date, author: r.doc.format.author } }; }, fs.readFileSync(path.resolve(__dirname, '../samples/A3資料見本.fzk'), 'utf8'));
  const U = r.t; const panels = U.filter(l => /^\[番号1 区画横[ \]]/.test(l));
  if (!(panels.join('|') === '[番号1 区画横 区画見出し網 区画矢印]現状から打ち手へ|[番号1 区画横 区画見出し線]効果・体制・リスク|[番号1 区画横 区画見出し網]見通しと判断いただきたいこと')) /* 1.0.12f 見出しの形とつなぎも戻る */ bad('A3 round trip: the three panel groups with their own headings (numbers stripped)', panels);
  if (!(U.includes('[番号2]現状') && U.includes('[項目1]受注から出荷まで平均 24 日（業界の上位は 10 日）') && U.some(l => /^#グラフ g\d 図 棒 .*在庫の見通し（四半期末）$/.test(l)) && U.includes('[番号1]工程') && U.some(l => l.startsWith('#表 列 0,')))) bad('A3 round trip: sections, bullets, chart title from its caption, the schedule table', U.slice(0, 20));
  if (!(!U.some(l => /^(\[番号1\])?(開始|中間審査|試行)$/.test(l)) && !U.some(l => /^(\[番号\d\])?(社外秘|SCM 推進チーム|2026年11月5日)$/.test(l)))) bad('texts over the table and the header texts stay out of the body', U.filter(l => /開始|試行|社外秘/.test(l)));
  if (!(r.f.paper === 'A3' && r.f.cols === 90 && r.f.secret === '社外秘' && /2026年11月5日/.test(r.f.date || '') && r.f.author === 'SCM 推進チーム')) bad('A3 slide size; header texts go to 機密・作成日・作成者', r.f);
  /* A4 の資料（本文欄＋図表欄）：本文は流れ、図は後に（2 つ並ぶ図は 1/2 で） */
  r = await page.evaluate(async s => { const d = FZ.parse(s); const bytes = await FZ.zipAsync(FZ.toPptx(d, { files: true })); const r = await FZ.fromPptx(bytes, { title: 't' }); return r.text.split('\n'); }, fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8'));
  if (!(r.includes('[番号1]概況') && r.includes('[番号1]構成') && r.some(l => /^#グラフ g\d 図 円 1\/2 製品別の構成比$/.test(l)) && r.some(l => /^#図版 p\d 図 展示会の様子 画像1\.jpeg 1\/2$/.test(l)))) bad('A4 slides: body text flows, side figures follow; two figures side by side get 1/2', r.slice(0, 22));
  /* 画面：ファイル（.pptx）を落とすと取り込む */
  r = await page.evaluate(async d => { const f = new File([new Uint8Array(d)], '計画.pptx'); const dt = new DataTransfer(); dt.items.add(f); document.getElementById('main').dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true })); await new Promise(r => setTimeout(r, 900)); const ed = FZ.app.ed; const fl = ed.doc.lines.find(l => l.attrs.style === 'title'); return { n: ed.doc.lines.length, kind: ed.doc.format.kind, first: fl && fl.segs.map(s => s.text).join(''), msg: document.getElementById('stMsg') ? document.getElementById('stMsg').textContent : '' }; }, deck);
  if (!(r.kind === 'slide' && r.first === '2026年度 事業計画' && r.n > 20)) bad('dropping a .pptx imports it', r);
  r = await page.evaluate(() => !!FZ.app.cmds().find(c => c.id === 'importPptx')); if (!r) bad('a command to import PowerPoint');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-111g-app OK'); process.exit(fails ? 1 : 0);
})();
