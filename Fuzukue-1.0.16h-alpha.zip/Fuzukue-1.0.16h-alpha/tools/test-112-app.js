/* 1.0.12：フレームワーク — 2 冊の型（148）を種類で選び、紙面に枠を入れ、枠の中にカーソルがある間、画面の下に枠ごとの書き方を出す */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 950 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 一覧：148 件・13 種類・出典（P 85、B 74）・使いどころと枠の説明、どれも原本として読める枠になる */
  let r = await page.evaluate(() => { const L = FZ.FW; const ids = new Set(L.map(e => e.id)); const P = L.filter(e => e.src.includes('P')).length, B = L.filter(e => e.src.includes('B')).length;
    const cats = FZ.FW_CATS.map(([k]) => L.filter(e => e.cat === k).length); const noWhen = L.filter(e => !e.when).map(e => e.id); const guided = L.reduce((t, e) => t + e.parts.filter(p => p.g).length, 0), parts = L.reduce((t, e) => t + e.parts.length, 0);
    const broken = []; for (const e of L) { const lines = FZ.fwBuild(e, { lv: 1, cols: 40, theme: '題' }); const d = FZ.parse('#fzk 2\n---\n' + lines.join('\n') + '\n'); const h = d.lines.findIndex(l => l.attrs.fw === e.id); const tbl = d.lines.some((l, i) => FZ.inTable(d, i));
      if (h !== 0 || /^(m2|sheet|ledger|grid|story)$/.test(e.form) !== tbl || !d.lines[0].segs.map(s => s.text).join('').startsWith(e.name + '：題') || (e.form === 'panels' && !d.lines[0].attrs.panels)) broken.push(e.id); }
    return { n: L.length, uniq: ids.size, P, B, cats, noWhen, ratio: guided / parts, broken }; });
  if (!(r.n === 152 && r.uniq === 152 && r.P === 85 && r.B === 74 && r.cats.length === 14 /* 1.0.13e ストーリー 4 型 */ && r.cats.every(n => n > 0) && !r.noWhen.length && r.ratio > 0.95)) bad('catalog: 148 unique frameworks from both books in 13 kinds, with usage and guidance', r);
  if (r.broken.length) bad('every framework builds a valid frame (heading with 枠:ID, table/panels as declared)', r.broken);
  /* 原本：枠:ID の往復、Enter で印が増えない */
  r = await page.evaluate(() => { const d = FZ.parse('#fzk 2\n---\n[番号1 枠:swot]SWOT分析\n本文\n'); const t = FZ.serialize(d); return { fw: d.lines[0].attrs.fw, ser: /\[番号1 枠:swot\]SWOT分析/.test(t) }; });
  if (!(r.fw === 'swot' && r.ser)) bad('枠:ID round-trips in the source', r);
  /* 選ぶ窓：探す・種類・Enter で入れる */
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n[表題]検討\n[番号1]現状の整理\n\n', 'f.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); FZ.app.run('framework'); }); await page.waitForTimeout(150);
  r = await page.evaluate(() => { const b = document.getElementById('fwpick'); return { open: !b.hidden, cats: b.querySelectorAll('.fwp-c li').length, items: b.querySelectorAll('.fwp-l li').length, focus: document.activeElement && document.activeElement.classList.contains('fwp-q') }; });
  if (!(r.open && r.cats === 15 && r.items === 152 && r.focus)) bad('the picker opens with kinds, all frameworks and the search box focused', r);
  await page.keyboard.press('ArrowRight'); await page.waitForTimeout(50); r = await page.evaluate(() => ({ cat: document.querySelector('#fwpick .fwp-c li.on').textContent, n: document.querySelectorAll('#fwpick .fwp-l li').length }));
  if (!(/問題を見つける/.test(r.cat) && r.n === 13)) bad('→ moves to the next kind', r);
  await page.keyboard.press('ArrowLeft'); await page.keyboard.type('優先'); await page.waitForTimeout(80); r = await page.evaluate(() => [...document.querySelectorAll('#fwpick .fwp-l li b')].map(b => b.textContent));
  if (!(r.includes('緊急度／重要度マトリクス') && r.length < 12)) bad('typing searches names and usages', r);
  await page.evaluate(() => { const q = document.querySelector('#fwpick .fwp-q'); q.value = 'SWOT'; q.dispatchEvent(new Event('input')); document.querySelector('#fwpick .fwp-t').value = '新商品A'; }); await page.keyboard.press('Enter'); await page.waitForTimeout(300);
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const h = d.lines.findIndex(l => l.attrs.fw); const c = FZ.app.ed.caret; return { closed: document.getElementById('fwpick').hidden, h, lv: d.lines[h].attrs.level, text: d.lines[h].segs.map(s => s.text).join(''), tbl: FZ.inTable(d, h + 1), caretIn: FZ.inTable(d, c.line), guide: document.body.classList.contains('fwg'), gname: (document.querySelector('#fwguide .fwg-h b') || {}).textContent, parts: document.querySelectorAll('#fwguide .fwg-p div').length }; });
  if (!(r.closed && r.h === 2 && r.lv === 1 && r.text === 'SWOT分析：新商品A' && r.tbl && r.caretIn)) bad('Enter inserts the SWOT frame as a child of the current section, caret in the table', r);
  if (!(r.guide && r.gname === 'SWOT分析' && r.parts === 4)) bad('the guide under the paper shows the framework and its four boxes', r);
  /* 当たり：カーソルのある枠の説明に印。弱み（W）の下の行（書く所）でも弱み */
  r = await page.evaluate(() => { const ed = FZ.app.ed, d = ed.doc; const h = d.lines.findIndex(l => l.attrs.fw); const row = h + 3; const segs = d.lines[row].segs; const k = segs.length - 1; ed.setCaret({ line: row, seg: k, off: 0 }); FZ.app.render(); const on1 = (document.querySelector('#fwguide .fwg-p div.on b') || {}).textContent;
    ed.setCaret({ line: row + 2, seg: 1, off: 0 }); FZ.app.render(); const on2 = (document.querySelector('#fwguide .fwg-p div.on b') || {}).textContent; return { on1, on2 }; });
  if (!(r.on1 === '弱み（W）' && r.on2 === '機会（O）')) bad('the guide marks the box under the caret (weakness, then opportunity)', r);
  /* 枠の外へ出ると消える。隠す × と、コマンドでまた出す */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.render(); const out = document.body.classList.contains('fwg'); const h = ed.doc.lines.findIndex(l => l.attrs.fw); ed.setCaret({ line: h, seg: 0, off: 1 }); FZ.app.render(); const back = document.body.classList.contains('fwg');
    document.querySelector('#fwguide [data-fwg="close"]').click(); const hid = document.body.classList.contains('fwg'); FZ.app.run('fwGuide'); const again = document.body.classList.contains('fwg'); return { out, back, hid, again }; });
  if (!(r.out === false && r.back && r.hid === false && r.again)) bad('the guide hides outside the frame, × hides it, the command shows it again', r);
  /* 続けて入れる：枠の中・直後なら同じ深さ。区画の最後の空の項目は区画の中に残る */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const last = () => ed.setCaret({ line: ed.doc.lines.length - 1, seg: 0, off: 0 }); last(); FZ.app.insertFw(FZ.fwById('c3')); last(); FZ.app.insertFw(FZ.fwById('pdca'));
    const d = ed.doc; const hs = d.lines.map((l, i) => [i, l.attrs.fw, l.attrs.level]).filter(x => x[1]); const c3 = hs.find(x => x[1] === 'c3')[0]; const pd = hs.find(x => x[1] === 'pdca')[0]; const lastBullet = pd - 1;
    const L = ed.lay; const g = L.pages.flatMap(p => p.glyphs).find(x => x.line === lastBullet && x.text === '・'); const pc = L.pages.flatMap(p => p.glyphs).find(x => x.line === c3 + 7); return { levels: hs.map(x => x[2]), lastIsBullet: !!d.lines[lastBullet].attrs.list, inside: g && g.col > 10, panels: d.lines[c3].attrs.panels }; });
  if (!(r.levels.join() === '1,1,1' && r.lastIsBullet && r.inside && r.panels)) bad('frames inserted one after another are siblings; the last empty bullet stays inside its panel', r);
  /* 見出しで Enter：枠の印は字の側に残り、増えない */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const h = ed.doc.lines.findIndex(l => l.attrs.fw === 'c3'); const t = ed.doc.lines[h].segs[0].text; ed.setCaret({ line: h, seg: 0, off: t.length }); ed.enter(); const n = ed.doc.lines.filter(l => l.attrs.fw === 'c3').length; ed.undo(); return n; });
  if (r !== 1) bad('Enter at the end of a frame heading does not copy 枠:ID', r);
  /* 文書の形のまま書き出せる（Word に表、Markdown に見出し） */
  r = await page.evaluate(() => { const d = FZ.app.ed.doc; const x = FZ.toDocx(d, { files: true }); const body = new TextDecoder().decode(x.find(f => f.name === 'word/document.xml').data instanceof Uint8Array ? x.find(f => f.name === 'word/document.xml').data : new TextEncoder().encode(x.find(f => f.name === 'word/document.xml').data)); const md = FZ.toGfm(d, {}); return { tbl: /<w:tbl>/.test(body) && /強み（/.test(body), md: /SWOT分析：新商品A/.test(md) && /計画（Plan）/.test(md) }; });
  if (!(r.tbl && r.md)) bad('frames export as tables and headings', r);
  r = await page.evaluate(() => !!FZ.app.cmds().find(c => c.id === 'framework' && c.path)); if (!r) bad('the command is on the insert menu');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112-app OK'); process.exit(fails ? 1 : 0);
})();
