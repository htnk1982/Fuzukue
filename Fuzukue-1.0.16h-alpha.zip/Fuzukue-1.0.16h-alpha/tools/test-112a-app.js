/* 1.0.12a：表の編集 — セルの結合・解除、列の幅をそろえる・字に合わせる（線のダブルクリックでも）、表を動かす（メニュー・つまみのドラッグ）、淡網、帯の「表の中で使う」 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
const SRC = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n表\n\n#表 列 0,10,20,30 様式 格子\n| 項目 | 2024年度 | 2025年度 |\n| 売上 | 1 | 2 |\n| 利益 | 3 | 4 |\n\n後\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const load = () => page.evaluate(async s => { await FZ.app.loadText(s, 't.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); FZ.app.render(); }, SRC);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const pt = (col, row) => page.evaluate(([col, row]) => { const geo = FZ.app.ed.lay.geo; const pg = document.querySelector('#pages svg'); const r = pg.getBoundingClientRect(); const s = r.width / geo.W; return { x: r.left + (geo.left + col * geo.cw) * s, y: r.top + (geo.top + (geo.bodyTop + row) * geo.ch) * s }; }, [col, row]);
  await load();
  /* 既定の見出しの網は淡網（新しく作る表・見出しの付いた様式） */
  let r = await page.evaluate(() => { const t = FZ.TABLES.find(x => x.id === 'grid'), c = FZ.TABLES.find(x => x.id === 'compare'); const sh = FZ.SHADES.find(s => s.id === 'light'); return { g: t.headerFill, c: c.headerFill, cs: c.sideFill, name: sh && sh.name }; });
  if (!(r.g === 'light' && r.cs === 'light' && r.name)) bad('grid and compare tables default to the light shade for headers', r);
  /* 帯：行・列は縦 1 列（3 段に収まる）、「表の中で使う」は帯の中に収まる */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); FZ.app.toggleGroup('tedit'); }); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const sub = document.getElementById('sub'); const sb = sub.getBoundingClientRect(); const n = sub.querySelector('.tnote'); const nb = n && n.getBoundingClientRect();
    const tiles = name => { const c = [...sub.querySelectorAll(':scope > .cl')].find(x => (x.querySelector('.cn') || x).textContent.replace(/<br>|\s/g, '').startsWith(name) || x.dataset.cl === name); if (!c) return null; const ys = [...c.querySelectorAll('.ch')].map(t => Math.round(t.getBoundingClientRect().left)); return new Set(ys).size; };
    return { note: !!n, inside: nb && nb.bottom <= sb.bottom + 1 && nb.top >= sb.top - 1 && nb.right <= sb.right + 1, abs: n && getComputedStyle(n).position, cmds: ['tmerge', 'tsplit', 'tcw:eq', 'tcw:fit', 'tmv:l', 'tmv:r', 'tmv:u', 'tmv:d', 'tcs:light'].filter(c => !sub.querySelector(`[data-cmd="${c}"]`)), rowsCol: tiles('行'), colsCol: tiles('列') }; });
  if (!(r.note && r.inside && r.abs === 'absolute')) bad('the "use inside a table" note sits inside the band, not below it', r);
  if (r.cmds.length) bad('the table band has merge, split, widths, move and the light shade', r.cmds);
  if (!(r.rowsCol === 1 && r.colsCol === 1)) bad('row and column insert items stack in one column', r);
  await page.evaluate(() => { FZ.app.toggleGroup('tedit'); });
  /* 結合：見出しの 2 セル → 1 セル（字はまとめる）。Word では gridSpan。解除で元の格子に */
  await page.evaluate(() => { const st = FZ.app.st, ed = FZ.app.ed; ed.setCaret({ line: 2, seg: 1, off: 0 }); st.cells = { a: { line: 2, col: 1, a: 2 }, b: { line: 2, col: 2, a: 2 } }; FZ.app.run('tmerge'); });
  let t = await body();
  if (!(/#表 列 0,10,30 様式 格子/.test(t) && /\| 2024年度 2025年度 \|/.test(t) && /#罫 縦 20 ×2/.test(t))) bad('merging two header cells joins them, keeps the grid preset', t);
  r = await page.evaluate(() => { const x = FZ.toDocx(FZ.app.ed.doc, { files: true }); const f = x.find(f => f.name === 'word/document.xml'); const s = typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data); return (s.match(/<w:gridSpan w:val="2"\/>/g) || []).length; });
  if (r !== 1) bad('the merged cell exports with gridSpan 2', r);
  r = await page.evaluate(() => { const ed = FZ.app.ed; const n = ed.undoStack.length; ed.undo(); const a = FZ.serialize(ed.doc).split('---\n')[1]; ed.redo(); return { a, n }; });
  if (!/#表 列 0,10,20,30 様式 格子\n\| 項目 \| 2024年度 \| 2025年度 \|/.test(r.a)) bad('merge is one undo step', r);
  await page.evaluate(() => { const st = FZ.app.st; st.cells = null; FZ.app.ed.setCaret({ line: 2, seg: 1, off: 0 }); FZ.app.run('tsplit'); }); t = await body();
  if (!/#表 列 0,10,20,30 様式 格子\n\| 項目 \| 2024年度 2025年度 \|  \|/.test(t)) bad('unmerge restores the cells (the text stays in the first)', t);
  /* 縦の結合：左の列の 2 行 → 横の線が消える */
  await load(); await page.evaluate(() => { const st = FZ.app.st; FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); st.cells = { a: { line: 3, col: 0, a: 2 }, b: { line: 4, col: 0, a: 2 } }; FZ.app.run('tmerge'); }); t = await body();
  if (!(/\| 売上 \| 1 \| 2 \|\n#罫 横 10-30/.test(t))) bad('merging two rows of the first column drops the rule between them there', t);
  r = await page.evaluate(() => { const dec = f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data); const x = dec(FZ.toDocx(FZ.app.ed.doc, { files: true }).find(f => f.name === 'word/document.xml')); const cell = (x.match(/<w:vMerge w:val="restart"\/>[\s\S]*?<\/w:tc>/) || [''])[0].replace(/<[^>]+>/g, '|').replace(/\|+/g, '|'); return { n: (x.match(/<w:vMerge\/>/g) || []).length, cell }; });
  if (!(r.n === 1 && r.cell === '|売上|利益|')) bad('a vertical merge exports as vMerge with both lines as paragraphs', r);
  /* 列の幅：字に合わせる（全部の列）、そろえる（全部の列） */
  const Bof = t => ((t.match(/#表 列 ([\d.,]+)/) || [])[1] || '').split(',').map(Number);
  const even = B => { const w = B.slice(1).map((x, i) => x - B[i]); return Math.max(...w) - Math.min(...w) <= 0.5 + 1e-9; };
  await load(); await page.evaluate(() => { FZ.app.st.cells = null; FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); FZ.app.run('tcw:fit'); }); t = await body();
  if (Bof(t).join() !== '0,3,8,13') bad('fit widths shrink every column to its text (+1 for the margins)', { B: Bof(t), t: t.slice(0, 120) });
  await page.evaluate(() => { FZ.app.run('tcw:eq'); }); t = await body(); r = Bof(t);
  if (!(r[0] === 0 && r[3] === 13 && even(r))) bad('equal widths split the table width evenly (half-cell steps)', r);
  /* 選んだ列だけ：等しい 2 列は変わらない。2 列を字に合わせてから全部をそろえる */
  await load(); await page.evaluate(() => { const st = FZ.app.st; FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); st.cells = { a: { line: 2, col: 0, a: 2 }, b: { line: 2, col: 1, a: 2 } }; FZ.app.run('tcw:eq'); FZ.app.st.cells = null; }); t = await body();
  if (Bof(t).join() !== '0,10,20,30') bad('equalizing two equal columns changes nothing', t);
  await page.evaluate(() => { const st = FZ.app.st; st.cells = { a: { line: 2, col: 1, a: 2 }, b: { line: 2, col: 2, a: 2 } }; FZ.app.run('tcw:fit'); st.cells = null; }); t = await body();
  if (Bof(t).join() !== '0,10,15,20') bad('fit only the selected columns', Bof(t));
  await page.evaluate(() => FZ.app.run('tcw:eq')); r = Bof(await body());
  if (!(r[3] === 20 && even(r))) bad('then equalize all columns', r);
  /* 列の線をダブルクリック：左の列を字に合わせる */
  await load(); let p = await pt(20, 2.5); await page.mouse.dblclick(p.x, p.y); await page.waitForTimeout(60); t = await body();
  if (!/#表 列 0,10,15,25/.test(t)) bad('double-clicking a column border fits the column on its left', t);
  /* 位置：右へ・左へ（半字）、下へ（上に空行）、上へ（上の空行を詰める） */
  await load(); await page.evaluate(() => { FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); for (let i = 0; i < 4; i++) FZ.app.run('tmv:r'); FZ.app.run('tmv:l'); }); t = await body();
  if (!/#表 列 1\.5,11\.5,21\.5,31\.5/.test(t)) bad('move right ×4, left ×1 → +1.5 cells', t);
  await page.evaluate(() => { FZ.app.run('tmv:d'); FZ.app.run('tmv:d'); }); t = await body();
  if (!/^表\n\n\n\n#表/.test(t)) bad('move down adds blank lines above the table', t.slice(0, 40));
  r = await page.evaluate(() => { FZ.app.run('tmv:u'); FZ.app.run('tmv:u'); FZ.app.run('tmv:u'); const t = FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; FZ.app.run('tmv:u'); return { t, msg: document.getElementById('status').textContent }; });
  if (!/^表\n#表/.test(r.t)) bad('move up removes the blank lines above, down to none', r.t.slice(0, 30));
  if (!/空行がありません/.test(r.msg)) bad('move up with no blank line above says so', r.msg);
  /* つまみのドラッグ：右へ 4 字、下へ 2 行を 1 回で（取り消しも 1 回） */
  await load(); await page.evaluate(() => { FZ.app.ed.setCaret({ line: 3, seg: 1, off: 0 }); FZ.app.render(); }); await page.waitForTimeout(40);
  p = await pt(-0.7, 2.4); await page.mouse.move(p.x, p.y); await page.waitForTimeout(30); const cur = await page.evaluate(() => document.getElementById('pages').style.cursor);
  let q = await pt(3.3, 4.4); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(60); t = await body();
  if (cur !== 'move') bad('the grip at the table\'s top-left shows the move cursor', cur);
  if (!(/^表\n\n\n\n#表 列 4,14,24,34/.test(t))) bad('dragging the grip moves the table right and down', t.slice(0, 80));
  r = await page.evaluate(() => { FZ.app.ed.undo(); return FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; });
  if (!/^表\n\n#表 列 0,10,20,30/.test(r)) bad('one undo puts the dragged table back', r.slice(0, 60));
  /* 右端を越えない */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 3, seg: 0, off: 0 }); for (let i = 0; i < 40; i++) FZ.app.run('tmv:r'); return FZ.tbl.info(ed, 3).B; });
  if (!(r[r.length - 1] === 40 && r[0] === 10)) bad('moving right stops at the edge of the text area', r);
  /* 淡網をセルに掛ける */
  await load(); await page.evaluate(() => { FZ.app.st.cells = null; FZ.app.ed.setCaret({ line: 3, seg: 1, off: 0 }); FZ.app.run('tcs:light'); }); t = await body();
  if (!/#網 .*淡/.test(t)) bad('the light shade can be put on a cell', t);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112a-app OK'); process.exit(fails ? 1 : 0);
})();
