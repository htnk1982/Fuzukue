/* 1.0.12b：フレームワークの手直し — 見本・解説を出すボタン・1 ます 1 項目・見出しは濃灰に白抜き太字・ますは「・」（セルの中の箇条書き）・版面いっぱい（資料でも図表欄まで） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const DOC = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n[表題]検討\n[番号1]現状\n\n';
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('\n---\n')[1]);
  const dec = 'const dec = f => typeof f.data === "string" ? f.data : new TextDecoder().decode(f.data);';
  /* 濃灰：白抜きの地。原本の名前・Word の灰色 */
  let r = await page.evaluate(() => { const sh = FZ.SHADE_BY.ink; return { name: sh && sh.name, ink: FZ.inkShade('ink'), dark: FZ.inkShade('dark'), gray: FZ.inkShade('gray'), key: FZ.SHADE_KEYS['濃灰'] }; });
  if (!(r.name === '濃灰' && r.ink && r.dark && !r.gray && r.key === 'ink')) bad('the ink shade (濃灰) is a white-text ground like 墨', r);
  /* 1 ます 1 項目：表の見出し・表側に「・」で並べた項目が残っていない（並び自体が一つの名前のものを除く） */
  r = await page.evaluate(() => { const ok = new Set(['販売・マーケティング', '任せる・減らす', '（高・高）', '（低・高）', '（高・低）', '（低・低）', '現実・押し出す', '原則・押し出す', '現実・合わせる', '原則・合わせる']); const out = []; for (const e of FZ.FW) { if (!/^(m2|sheet|ledger|grid)$/.test(e.form)) continue; for (const n of [...e.parts.map(p => p.n), ...(e.cols || [])]) if (/[・／]/.test(n.replace(/（[^）]*）/g, '')) && !ok.has(n)) out.push(e.id + ':' + n); }
    const il = FZ.fwById('issuelog').parts.map(p => p.n), jc = FZ.fwById('journey').cols; return { out, il, jc }; });
  if (r.out.length) bad('no table header or row label lists several items with ・', r.out);
  if (!(r.il.includes('原因') && r.il.includes('影響') && r.il.includes('担当') && r.il.includes('期限') && r.jc.length === 7)) bad('issue log and journey map split their combined columns', r);
  /* 枠を入れる：見出しの行は濃灰・太字、表側は淡網・太字、書くますは「・」、4 象限は名前の行＋行続きの「・」の行 */
  await page.evaluate(async d => { await FZ.app.loadText(d, 'f.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); FZ.app.insertFw(FZ.fwById('swot')); }, DOC);
  let t = await body();
  if (!(/#表 列 0,8,24,40 様式 格子 見出し濃灰 表側淡/.test(t) && /\| <太字>強み（S）<\/太字> \|/.test(t) && /\[行続き\]\| {2,}\| ・ \| ・ \|/.test(t))) bad('SWOT: ink header, light side, bold quadrant names, a continued row of bullets', t);
  r = await page.evaluate(() => { const ed = FZ.app.ed, c = ed.caret; const ln = ed.doc.lines[c.line]; const L = ed.lay; const g = L.pages[0].glyphs.find(x => x.text === 'プ'); const svg = document.querySelector('#pages svg').outerHTML; return { seg: ln.segs[c.seg].text, off: c.off, crow: !!ln.attrs.crow, white: /fill="#fff"[^>]*>プ|プ/.test(svg) && !!g, fill: L.pages[0].fills.some(f => f.shade === 'ink') }; });
  if (!(r.seg === '・' && r.off === 1 && r.crow && r.fill)) bad('the caret lands after the first bullet; the header is painted ink', r);
  /* 「・」のますで Enter：同じます・同じ表の行に次の「・」（上に罫なし）。印だけで Enter：印を消す。Shift+Enter：印なしの改行 */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.insertText('人材'); ed.enter(); const c = ed.caret, d = ed.doc; const ln = d.lines[c.line]; const ruled = d.rules.some(x => x.axis === 'h' && x.line === c.line && x.from < 24 && x.to > 8); const a = { line: c.line, seg: ln.segs[c.seg].text, off: c.off, crow: !!ln.attrs.crow, ruled };
    ed.enter(); const b = { seg: d.lines[ed.caret.line].segs[ed.caret.seg].text, line: ed.caret.line }; ed.insertText('技術'); ed.softBreak(); const c2 = ed.caret; return { a, b, sb: { seg: d.lines[c2.line].segs[c2.seg].text, crow: !!d.lines[c2.line].attrs.crow, line: c2.line } }; });
  if (!(r.a.seg === '・' && r.a.off === 1 && r.a.crow && !r.a.ruled)) bad('Enter in a bullet cell continues with a bullet in the same cell (no rule above)', r.a);
  if (!(r.b.seg === '' && r.b.line === r.a.line)) bad('Enter on a lone bullet clears it', r.b);
  if (!(r.sb.seg === '' && r.sb.crow && r.sb.line === r.a.line + 1)) bad('Shift+Enter in a cell breaks the line inside the cell', r.sb);
  /* 折り返しは「・」の後ろに揃う */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const d = ed.doc; const h = d.lines.findIndex(l => l.attrs.fw); const q = h + 3; const k = d.lines[q].segs.findIndex(s => s.col === 8); ed.mutate('', () => { const sg = d.lines[q].segs[k]; sg.text = '・' + 'あ'.repeat(30); sg.marks = sg.text.split('').map(() => 0); }); FZ.app.render(); const gs = ed.lay.pages[0].glyphs.filter(g => g.line === q && g.col >= 8 && g.col < 24); const ys = [...new Set(gs.map(g => g.y))].sort((a, b) => a - b); const second = gs.filter(g => g.y === ys[1]); return { rows: ys.length, col: second.length ? Math.min(...second.map(g => g.col)) : null }; });
  if (!(r.rows >= 2 && r.col === 9)) bad('a bullet cell wraps under the text, not under the bullet', r);
  /* 書き出し：Word は行続きを縦の結合（段落を足す）・ぶら下げ、見出しは灰色に白い字。Markdown は <br>、読み戻すと行続きに */
  r = await page.evaluate(new Function(dec + 'const d = FZ.app.ed.doc; const x = dec(FZ.toDocx(d, { files: true }).find(f => f.name === "word/document.xml")); const md = FZ.toGfm(d, {}); const back = FZ.fromGfm(md); const crows = back.lines.filter(l => l.attrs.crow).length; return { vm: (x.match(/<w:vMerge w:val="restart"\\/>/g) || []).length, cont: (x.match(/<w:vMerge\\/>/g) || []).length, ind: /<w:ind w:left="\\d+" w:hanging="\\d+"\\/>/.test(x), shd: /w:fill="4D4D4D"/.test(x), white: /<w:color w:val="FFFFFF"\\/>[^]*?プラス要因/.test(x), br: /人材<br>/.test(md) || /<br>/.test(md), crows };'));
  if (!(r.vm >= 3 && r.cont >= 3 && r.ind && r.shd && r.white)) bad('Word: continued rows merge into the cell above, bullets hang, the header is gray with white text', r);
  if (!(r.br && r.crows >= 2)) bad('Markdown joins continued rows with <br> and reads them back as continued rows', r);
  /* 資料（図表欄あり）：枠は版面の幅いっぱい（図表欄まで）。表は左右に動かせる */
  const head = fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8').split('\n---\n')[0];
  r = await page.evaluate(async h => { await FZ.app.loadText(h + '\n---\n[表題]検討\n\n', 's.fzk', null); const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.insertFw(FZ.fwById('swot')); const t = FZ.serialize(ed.doc).split('\n---\n')[1]; const gs = ed.lay.pages[0].glyphs.filter(x => x.text === '因' && x.line > 0); return { B: (t.match(/#表 列 ([\d.,]+)/) || [])[1], col: gs.length ? Math.max(...gs.map(x => x.col)) : null, geo: [ed.lay.geo.cols, ed.lay.geo.bodyCols] }; }, head);
  if (!(r.B === '0,10,35,60' && r.col === 40)) bad('in a slide with a figure column the frame spans the full width and its cells are laid out there', r);
  /* 区画の見出しも濃灰（原本の名前・Markdown の注記） */
  r = await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: ed.doc.lines.length - 1, seg: 0, off: 0 }); FZ.app.insertFw(FZ.fwById('c3')); const t = FZ.serialize(ed.doc); const md = FZ.toGfm(ed.doc, { fz: true }); const back = FZ.fromGfm(md); return { src: /区画見出し濃灰/.test(t), md: /<!-- 区画 \S+ 濃灰/.test(md), back: back.lines.some(l => l.attrs.panelHead === 'ink'), fill: ed.lay.pages.some(p => p.fills.some(f => f.shade === 'ink' && f.deco)) }; });
  if (!(r.src && r.md && r.back && r.fill)) bad('framework panels use ink heads that survive the source and Markdown', r);
  /* 選ぶ窓：右に、この文書の版面で組んだ枠の見本 */
  await page.evaluate(async d => { await FZ.app.loadText(d, 'f.fzk', null); FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); FZ.app.run('framework'); const q = document.querySelector('#fwpick .fwp-q'); q.value = 'SWOT'; q.dispatchEvent(new Event('input')); }, DOC); await page.waitForTimeout(100);
  r = await page.evaluate(() => { const sv = document.querySelector('#fwpick .fwp-v .pv svg'); if (!sv) return null; const vb = sv.getAttribute('viewBox').split(' ').map(Number); const ids = [...sv.querySelectorAll('[id]')].map(e => e.id); return { vb, h: sv.getBoundingClientRect().height, text: sv.textContent.includes('プラス要因'), ids: ids.every(i => /_pv$/.test(i)) }; });
  if (!(r && r.text && r.vb[3] < 300 && r.h > 60 && r.ids)) bad('the picker shows a cropped preview of the frame', r);
  await page.keyboard.press('Escape');
  /* 解説を隠しても、枠の中では「書き方を出す」が残り、押すとまた出る */
  r = await page.evaluate(() => { FZ.app.insertFw(FZ.fwById('swot')); FZ.app.render(); document.querySelector('#fwguide [data-fwg="close"]').click(); const min = document.body.classList.contains('fwgmin') && !!document.querySelector('#fwguide [data-fwg="open"]'); const full = document.body.classList.contains('fwg'); document.querySelector('#fwguide [data-fwg="open"]').click(); return { min, full, back: document.body.classList.contains('fwg'), gone: !document.body.classList.contains('fwgmin') }; });
  if (!(r.min && !r.full && r.back && r.gone)) bad('after hiding, a small show button stays while the caret is in the frame', r);
  r = await page.evaluate(() => !!FZ.app.cmds().find(c => c.id === 'fwGuide' && c.path)); if (!r) bad('the guide toggle is on the view menu');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112b-app OK'); process.exit(fails ? 1 : 0);
})();
