/* 1.0.12c：囲みの幅と位置（左右の罫をつかむ・つまみで動かす）、区画の幅の比（境をつかむ・欄で比）と全幅の区画 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
const BOX = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n前\n\n#囲み ×3\n題\n・一\n・二\n\n後\n';
const PNL = '#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n[表題]題\n[番号1 区画2]現状\n[番号2]左\n本文\n[番号2]右\n本文\n[番号2]まとめ\n本文\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const pt = (col, row) => page.evaluate(([col, row]) => { const geo = FZ.app.ed.lay.geo; const pg = document.querySelector('#pages svg'); const r = pg.getBoundingClientRect(); const s = r.width / geo.W; return { x: r.left + (geo.left + col * geo.cw) * s, y: r.top + (geo.top + (geo.bodyTop + row) * geo.ch) * s }; }, [col, row]);
  const drag = async (a, b) => { const p = await pt(...a), q = await pt(...b); await page.mouse.move(p.x, p.y); await page.waitForTimeout(20); const cur = await page.evaluate(() => document.getElementById('pages').style.cursor); await page.mouse.down(); await page.mouse.move(q.x, q.y, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(60); return cur; };
  await page.evaluate(async s => { await FZ.app.loadText(s, 'b.fzk', null); FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); FZ.app.render(); }, BOX);
  /* 右の罫をつかんで左へ：幅が縮む。原本は「位置 0-24」、字は罫の内側で折り返す */
  let cur = await drag([40, 2.5], [24, 2.5]); let t = await body();
  if (cur !== 'col-resize') bad('the box border shows the resize cursor', cur);
  if (!/#囲み ×3 位置 0-24\n/.test(t)) bad('dragging the right border narrows the box (位置 0-24)', t);
  /* 左の罫を右へ */
  await drag([0, 3.5], [6, 3.5]); t = await body();
  if (!/#囲み ×3 位置 6-24\n/.test(t)) bad('dragging the left border moves it (位置 6-24)', t);
  let r = await page.evaluate(() => { const ed = FZ.app.ed; ed.mutate('', () => { const sg = ed.doc.lines[3].segs[0]; sg.text = '一' + 'あ'.repeat(40); sg.marks = sg.text.split('').map(() => 0); }); FZ.app.render(); const gs = ed.lay.pages[0].glyphs.filter(g => g.line === 3 && !g.marker); return { min: Math.min(...gs.map(g => g.col)), max: Math.max(...gs.map(g => g.col + g.w)) }; });
  if (!(r.min >= 7 && r.max <= 24.01)) bad('text inside a positioned box stays between its borders', r);
  /* つまみ（囲みの左上の外）をドラッグ：右へ 4、下へ 1 */
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); FZ.app.render(); }); await page.waitForTimeout(40);
  cur = await drag([5.2, 2.4], [9.2, 3.4]); t = await body();
  if (cur !== 'move') bad('the box grip shows the move cursor', cur);
  if (!/^前\n\n\n#囲み ×3 位置 10-28\n/.test(t)) bad('dragging the grip moves the box right and down', t.slice(0, 60));
  r = await page.evaluate(() => { FZ.app.ed.undo(); return FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; });
  if (!/^前\n\n#囲み ×3 位置 6-24\n/.test(r)) bad('one undo puts the box back', r.slice(0, 50));
  /* F8 の位置（表・囲み）と、全幅に戻す */
  t = await page.evaluate(() => { FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); FZ.app.run('tmv:r'); FZ.app.run('tmv:r'); return FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; });
  if (!/#囲み ×3 位置 7-25\n/.test(t)) bad('the move commands work on boxes', t);
  t = await page.evaluate(() => { FZ.app.run('bx:full'); return FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; });
  if (!/#囲み ×3\n/.test(t)) bad('back to full width', t);
  /* 原本の往復と Word（左右の字下げ） */
  r = await page.evaluate(() => { const d = FZ.parse('#fzk 2\n文字数: 40\n---\n#囲み ×2 位置 4-30\n題\n本文\n'); const t = FZ.serialize(d); const x = FZ.toDocx(d, { files: true }).find(f => f.name === 'word/document.xml'); const s = typeof x.data === 'string' ? x.data : new TextDecoder().decode(x.data); return { rt: /#囲み ×2 位置 4-30/.test(t), ind: (s.match(/<w:ind w:right="(\d+)" w:left="(\d+)"/) || []).slice(1) }; });
  if (!(r.rt && r.ind.length === 2 && +r.ind[0] > 0 && +r.ind[1] > 0)) bad('positioned boxes round-trip and export with left/right indents', r);
  /* 区画：境をつかんで幅の比、欄で比、全幅の区画 */
  await page.evaluate(async s => { await FZ.app.loadText(s, 'p.fzk', null); FZ.app.ed.setCaret({ line: 3, seg: 0, off: 0 }); FZ.app.render(); }, PNL);
  r = await page.evaluate(() => { const G = FZ.app.ed.lay.panelGroups.get(1); return G && { n: G.n, e: G.edges }; });
  if (!(r && r.n === 2 && r.e.join() === '0,21,41')) bad('panel geometry is exposed (2 columns)', r);
  const y = await page.evaluate(() => { const v = FZ.app.ed.lay.pages[0].vrules.find(v => /^pnl1:0:v20/.test(v.id)); return v ? (v.y1 + v.y2) / 2 : null; });
  cur = await drag([20, y], [26, y]); t = await body();
  if (cur !== 'col-resize') bad('the gap between panels shows the resize cursor', cur);
  if (!/\[番号1 区画2 区画比26:15\]現状/.test(t)) bad('dragging the gap sets the column ratio', t.slice(0, 80));
  r = await page.evaluate(() => { const gs = FZ.app.ed.lay.pages[0].glyphs.filter(g => g.text === '右'); return gs.map(g => g.col); });
  if (!(r.length && Math.min(...r) >= 26)) bad('the right panel starts after the new boundary', r);
  r = await page.evaluate(() => { FZ.app.ed.setCaret({ line: 6, seg: 0, off: 0 }); FZ.app.run('panelWide'); const t = FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; const v = FZ.app.ed.lay.pages[0].vrules.filter(v => /^pnl1:2:v/.test(v.id)).map(v => v.col); const md = FZ.toGfm(FZ.app.ed.doc, { fz: true }); return { t, v, back: FZ.serialize(FZ.parse(t.startsWith('#fzk') ? t : '#fzk 2\n文字数: 40\n---\n' + t)).includes('区画全幅') }; });
  if (!(/\[番号2 区画全幅\]まとめ/.test(r.t) && r.v.includes(0) && r.v.includes(40) && r.back)) bad('a panel can span the full width (区画全幅)', r);
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('panels'); }); await page.waitForTimeout(80);
  t = await page.evaluate(() => { const i = document.querySelector('#sub input[name="ratio"]'); if (!i) return 'no input'; i.value = '1:1'; document.querySelector('#sub [data-act="ratio"]').click(); return FZ.serialize(FZ.app.ed.doc).split('---\n')[1]; });
  if (!/\[番号1 区画2\]現状/.test(t)) bad('the panels form sets the ratio (1:1 = equal)', t.slice(0, 60));
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112c-app OK'); process.exit(fails ? 1 : 0);
})();
