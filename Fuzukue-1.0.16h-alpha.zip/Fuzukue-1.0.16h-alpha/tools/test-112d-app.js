/* 1.0.12d：Mermaid の読み込みを図の種類ごとに組む（流れ図は層で並べる・シーケンス図・ER 図・マインドマップ・DFD）、文机の図から Mermaid へ（往復） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 700) : '')); };
const FLOW = 'flowchart TD\n  A[受付] --> B{書類はそろっている？}\n  B -->|はい| C[審査]\n  B -->|いいえ| D[差し戻し]\n  D --> A\n  C --> E([決裁])\n  C --> F[(台帳)]';
const LR = 'graph LR\n  A[企画] --> B[設計] --> C[開発]\n  A -.- N[メモ]';
const LANE = 'flowchart TD\n  subgraph 申請者\n    A[申請]\n  end\n  subgraph 窓口\n    B[受付] --> C[審査]\n  end\n  A --> B';
const SEQ = 'sequenceDiagram\n  participant U as 利用者\n  participant S as システム\n  participant D as DB\n  U->>S: 申請\n  S->>D: 照会\n  D-->>S: 結果\n  alt 不備あり\n    S-->>U: 差し戻し\n  else 不備なし\n    S->>S: 採番\n  end\n  Note over S,D: 夜間は一括';
const ER = 'erDiagram\n  顧客 ||--o{ 注文 : 行う\n  注文 ||--|{ 明細 : 含む\n  顧客 {\n    string 顧客ID PK\n  }';
const MIND = 'mindmap\n  root((新規事業))\n    市場\n      規模\n    顧客\n    体制';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1200, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const fig = src => page.evaluate(s => FZ.figureFromMermaid(s, 40), src);
  /* 流れ図：層ごとの行、分かれ道は横に並ぶ、戻りは右を回る、形（判断＝二重・端＝網・置き場＝右が開いた箱） */
  let F = await fig(FLOW); let r = { n: F.boxes.length, tag: F.tag, dir: F.dir };
  const by = t => F.boxes.find(b => b.text === t);
  if (!(r.n === 6 && r.tag === 'flow' && by('受付').y < by('書類はそろっている？').y && by('書類はそろっている？').y < by('審査').y && by('審査').y === by('差し戻し').y && by('審査').x < by('差し戻し').x)) bad('flowchart nodes go in layers (branches side by side)', F.boxes.map(b => [b.text, b.x, b.y]));
  if (!(F.arrows.find(a => a.from === by('差し戻し').id && a.to === by('受付').id).via === 'r')) bad('a back edge routes around the right', F.arrows);
  if (!(by('書類はそろっている？').kind === 'double' && by('決裁').shade && by('台帳').kind === 'store')) bad('decision, terminal and data store shapes are kept', F.boxes.map(b => [b.text, b.kind, b.shade]));
  F = await fig(LR); if (!(F.boxes[0].x < F.boxes[1].x && F.boxes[1].x < F.boxes[2].x && F.dir === 'LR' && F.arrows.find(a => a.kind === 'dotted').head === false)) bad('a short LR graph goes left to right; -.- is a dotted line without a head', [F.boxes.map(b => [b.x, b.y]), F.arrows]);
  F = await fig(LANE); if (!(F.lanes && F.lanes.dir === 'v' && F.lanes.items.map(x => x.title).join() === '申請者,窓口' && F.boxes.find(b => b.text === '申請').x < 20 && F.boxes.find(b => b.text === '審査').x >= 20 && F.boxes.find(b => b.text === '受付').y < F.boxes.find(b => b.text === '審査').y)) bad('subgraphs become lanes with layered rows', F);
  /* シーケンス図：参加者・生存線・伝達（矢じり・点線）・alt の枠と else・注 */
  F = await fig(SEQ); r = { tag: F.tag, P: F.boxes.filter(b => b.y === 0).map(b => b.text), life: F.lines.filter(l => l.role === 'life').length, msg: F.lines.filter(l => l.role === 'msg').map(l => [l.label, l.kind, l.head, l.pts.length]), sep: F.lines.filter(l => l.role === 'sep').length, frame: F.boxes.filter(b => b.kind === 'dotted').length, note: F.boxes.filter(b => b.shade && b.y > 0).map(b => b.text), texts: F.texts.map(t => t.text) };
  if (!(r.tag === 'seq' && r.P.join() === '利用者,システム,DB' && r.life === 3 && r.msg.length === 5 && r.msg[2][1] === 'dotted' && r.msg[4][3] === 4 && r.sep === 1 && r.frame === 1 && r.note[0] === '夜間は一括' && r.texts.includes('alt：不備あり') && r.texts.includes('else：不備なし'))) bad('sequence diagram: participants, lifelines, messages, alt frame, note', r);
  r = await page.evaluate(F => { const m = []; let y = -1, ok = true; for (const l of F.lines.filter(l => l.role === 'msg')) { if (l.pts[0][1] <= y) ok = false; y = l.pts[0][1]; } return ok; }, F); if (!r) bad('messages go down in order', F.lines);
  /* ER 図：実体＝箱（名前と属性）、関係＝矢じりなし、多重度は字に */
  F = await fig(ER); r = { tag: F.tag, boxes: F.boxes.map(b => b.text), arrows: F.arrows.map(a => [a.head, a.card, a.label]) };
  if (!(r.tag === 'er' && r.boxes[0] === '顧客\nstring 顧客ID PK' && r.arrows.every(a => a[0] === false) && r.arrows[0][1] === '||--o{')) bad('ER: entities with attributes, relations without heads keep their cardinality', r);
  r = await page.evaluate(F => FZ.arrowLabel(F.arrows[0]), F); if (r !== '行う（1:0..多）') bad('the relation label shows the cardinality', r);
  /* マインドマップ：中心は左（太枠・網・太字）、枝は右へ、矢じりなし */
  F = await fig(MIND); r = { tag: F.tag, root: F.boxes[0], n: F.boxes.length, heads: F.arrows.map(a => a.head) };
  if (!(r.tag === 'mind' && r.root.text === '新規事業' && r.root.bold && r.root.kind === 'thick' && r.n === 5 && F.boxes.slice(1).every(b => b.x > r.root.x) && r.heads.every(h => h === false))) bad('mindmap: root on the left, branches to the right without heads', r);
  /* 往復：Markdown へ書いて読み戻す（種類・数）、原本でも */
  r = await page.evaluate(srcs => srcs.map(s => { const F = FZ.figureFromMermaid(s, 40); const back = FZ.figureFromMermaid(FZ.figureToMermaid(F, 40).join('\n'), 40); const d = FZ.parse('#fzk 2\n---\n' + FZ.figureToLines(F).join('\n') + '\n[図' + F.h + ']\n'); const G = d.lines.find(l => l.attrs.figure).attrs.figure; return [F.tag, back && back.tag, F.boxes.length, back && back.boxes.length, F.arrows.length, back && back.arrows.length, F.lines.length, back && back.lines.length, G.tag, G.lines.length, G.texts.length === F.texts.length, JSON.stringify(G.arrows) === JSON.stringify(F.arrows)]; }), [FLOW, SEQ, ER, MIND]);
  for (const x of r) if (!(x[0] === x[1] && x[2] === x[3] && x[4] === x[5] && x[6] === x[7] && x[8] === x[0] && x[9] === x[6] && x[10] && x[11])) bad('round trip through Mermaid and the source keeps the diagram', x);
  r = await page.evaluate(s => FZ.figureToMermaid(FZ.figureFromMermaid(s, 40), 40).join('\n'), SEQ);
  if (!/participant P1 as 利用者/.test(r) || !/P3-->>P2: 結果/.test(r) || !/alt 不備あり/.test(r) || !/else 不備なし/.test(r) || !/Note over P2,P3: 夜間は一括/.test(r)) bad('sequence diagrams are written back as sequenceDiagram', r);
  r = await page.evaluate(s => FZ.figureToMermaid(FZ.figureFromMermaid(s, 40), 40).join('\n'), FLOW);
  if (!/n2\{"書類はそろっている？"\}/.test(r) || !/n6\[\("台帳"\)\]/.test(r) || !/n5\(\["決裁"\]\)/.test(r)) bad('flowchart shapes are written back', r);
  /* 文書に読み込む：Markdown の mermaid → 図、組んで描ける、Word に線と字 */
  r = await page.evaluate(async s => { const d = FZ.fromGfm('# 題\n\n```mermaid\n' + s + '\n```\n\n```mermaid\npie\n  "A" : 1\n```\n'); await FZ.app.loadText(FZ.serialize(d), 'm.fzk', null); FZ.app.render(); const ed = FZ.app.ed; const fl = ed.doc.lines.findIndex(l => l.attrs.figure); const gs = ed.lay.pages.flatMap(p => p.glyphs).filter(g => g.line === fl).map(g => g.text).join(''); const x = FZ.toDocx(ed.doc, { files: true }).find(f => f.name === 'word/document.xml'); const t = typeof x.data === 'string' ? x.data : new TextDecoder().decode(x.data); return { fig: fl >= 0, txt: /利用者/.test(gs) && /申請/.test(gs) && /alt/.test(gs), lines: (t.match(/name="線/g) || []).length, pie: ed.doc.lines.some(l => l.attrs.code) }; }, SEQ);
  if (!(r.fig && r.txt && r.lines >= 8 && r.pie)) bad('Markdown mermaid blocks load as figures (unsupported kinds stay code), render, and export lines to Word', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112d-app OK'); process.exit(fails ? 1 : 0);
})();
