/* 1.0.12d：フレームワークの解説の当たり — カーソルのあるますと、画面の下の解説の印が一致する（行と列の表・項目と記入・4 象限・台帳・区画・木、字を打った後・行続きの中も） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const r = await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n用紙: A4 縦\n文字数: 40\n行数: 36\n---\n[表題]検討\n\n', 'f.fzk', null); const ed = FZ.app.ed; const bad = [];
    const on = () => { FZ.app.render(); const ds = [...document.querySelectorAll('#fwguide .fwg-p div')]; return ds.findIndex(d => d.classList.contains('on')); };
    const ins = id => { ed.setCaret({ line: ed.doc.lines.length - 1, seg: 0, off: 0 }); FZ.app.insertFw(FZ.fwById(id)); const h = ed.doc.lines.findIndex(l => l.attrs.fw === id); return h; };
    const at = (q, k, want, why) => { ed.setCaret({ line: q, seg: k, off: 0 }); const got = on(); if (got !== want) bad.push([why, q, k, got, want]); };
    /* 行と列の表（カスタマージャーニー）：どの列でも、その行の見出しの項目。字を打っても、行続きの中でも */
    let h = ins('journey'); const J = FZ.fwById('journey'); for (let r = 0; r < J.parts.length; r++) for (const k of [0, 1, 4, 7]) at(h + 2 + r, k, r, 'journey row ' + r);
    ed.setCaret({ line: h + 3, seg: 2, off: 1 }); ed.insertText('接点ではなく行動の話'); ed.enter(); ed.insertText('二つ目'); at(ed.caret.line, ed.caret.seg, 1, 'journey: typed text and a continued line stay on the row (接点)');
    /* 項目と記入（ペルソナ）：記入のますは、その行の項目 */
    h = ins('persona'); const P = FZ.fwById('persona'); for (let r = 0; r < P.parts.length; r++) { at(h + 2 + r, 0, r, 'persona label ' + r); at(h + 2 + r, 1, r, 'persona cell ' + r); }
    /* 4 象限（SWOT）：名前の行・行続きの「・」の行、何行続けても */
    h = ins('swot'); at(h + 2, 1, 0, 'swot S name'); at(h + 3, 1, 0, 'swot S bullet'); at(h + 3, 2, 1, 'swot W bullet'); at(h + 5, 1, 2, 'swot O bullet'); at(h + 5, 2, 3, 'swot T bullet');
    ed.setCaret({ line: h + 3, seg: 2, off: 1 }); ed.insertText('機会損失が大きい'); ed.enter(); ed.enter(); ed.softBreak(); at(ed.caret.line, 2, 1, 'swot: several continued lines under W stay on W (typed 機会… does not pull to 機会)');
    /* 台帳（課題管理票）：列の見出しの項目。見出しの行でも */
    h = ins('issuelog'); const I = FZ.fwById('issuelog'); for (let c = 0; c < I.parts.length; c++) { at(h + 1, c, c, 'issuelog head ' + c); at(h + 3, c, c, 'issuelog body ' + c); }
    /* 区画（3C）：区画の中の箇条書きに、別の区画の名前に似た字を打っても、その区画 */
    h = ins('c3'); ed.setCaret({ line: h + 2, seg: 0, off: 0 }); ed.insertText('競合が少ない'); at(h + 2, 0, 0, 'c3: typed 競合… under 顧客 stays on 顧客'); at(h + 4, 0, 1, 'c3 競合'); at(h + 6, 0, 2, 'c3 自社');
    /* 木（ロジックツリー）：同じ名前（下位の要素）が並んでも、何番目の項目か */
    h = ins('logictree'); const T = FZ.fwById('logictree'); for (let r = 0; r < T.parts.length; r++) at(h + 1 + r, 0, r, 'logictree item ' + r);
    return bad; });
  if (r.length) bad('the guide marks the part under the caret', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112e-app OK'); process.exit(fails ? 1 : 0);
})();
