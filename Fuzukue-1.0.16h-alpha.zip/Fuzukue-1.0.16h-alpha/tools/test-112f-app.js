/* 1.0.12f：資料を Word に紙面のまま（PowerPoint の図形をページ基準の図形に置き直す）、PowerPoint の取り込みの再現（表紙・字の大きさ・図表欄・区画の見出しの形・つなぎ・工程表） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const A3 = fs.readFileSync(path.resolve(__dirname, '../samples/A3資料見本.fzk'), 'utf8'), A4 = fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8');
  /* Word：1 頁に 1 段落、図形はページ基準の位置。用紙は A3 横、表は字の箱の中の Word の表、グラフは Word のグラフ、頁番号は PAGE、区画のつなぎも */
  let r = await page.evaluate(async s => { await FZ.app.loadText(s, 'a3.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 300)); const d = await FZ.app.officeDoc(FZ.app.ed.doc); const fs = FZ.toDocx(d, { files: true }); const get = n => { const f = fs.find(f => f.name === n); return f ? (typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data)) : ''; }; const x = get('word/document.xml');
    const flow = FZ.toDocx(d, { files: true, flow: true }).find(f => f.name === 'word/document.xml'); const fx = typeof flow.data === 'string' ? flow.data : new TextDecoder().decode(flow.data);
    return { anchors: (x.match(/<wp:anchor /g) || []).length, page: /relativeFrom="page"/.test(x), pgSz: (x.match(/<w:pgSz w:w="(\d+)" w:h="(\d+)" w:orient="landscape"\/>/) || []).slice(1).map(Number), tblInBox: /<w:txbxContent><w:tbl>/.test(x), chart: fs.some(f => f.name === 'word/charts/chart1.xml') && /c:chart [^>]*r:id=/.test(x) && fs.some(f => /^word\/embeddings\/.*\.xlsx$/.test(f.name)), pageFld: /<w:fldSimple w:instr=" PAGE ">/.test(x), title: /受注から出荷までのリードタイムを/.test(x), link: (x.match(/区画のつなぎ/g) || []).length, ct: /word\/charts\/chart1\.xml/.test(get('[Content_Types].xml')), rels: (get('word/_rels/document.xml.rels').match(/charts\/chart1\.xml/) || []).length, flowAnchors: (fx.match(/<wp:anchor /g) || []).length, flowTbl: /<w:tbl>/.test(fx) };
  }, A3);
  if (!(r.anchors > 60 && r.page && Math.abs(r.pgSz[0] - 23811) < 30 && Math.abs(r.pgSz[1] - 16838) < 30)) bad('Word (slides): shapes anchored to the page on an A3 landscape page', r);
  if (!(r.tblInBox && r.chart && r.ct && r.rels === 1 && r.pageFld && r.title && r.link >= 2)) bad('Word (slides): tables in text boxes, an editable chart, PAGE field, title, panel arrows', r);
  if (!(r.flowAnchors < 10 && r.flowTbl)) bad('Word (flow) is still available', r);
  /* A4 の資料：2 頁、2 頁目の段落は改頁の前 */
  r = await page.evaluate(async s => { await FZ.app.loadText(s, 'a4.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 300)); const d = await FZ.app.officeDoc(FZ.app.ed.doc); const fs = FZ.toDocx(d, { files: true }); const x = fs.find(f => f.name === 'word/document.xml').data; return { breaks: (x.match(/<w:pageBreakBefore\/>/g) || []).length, pics: (x.match(/<pic:pic /g) || []).length, media: fs.filter(f => f.name.startsWith('word/media/')).length, cmd: !!FZ.app.cmds().find(c => c.id === 'exportDocxFlow') }; }, A4);
  if (!(r.breaks === 1 && r.pics === 1 && r.media === 1 && r.cmd)) bad('Word (A4 slides): one page break, the picture with its media, the flow command', r);
  /* PowerPoint の書き出しに区画のつなぎ（→） */
  r = await page.evaluate(s => { const x = FZ.toPptx(FZ.parse(s), { files: true }).find(f => f.name === 'ppt/slides/slide1.xml').data; return (x.match(/name="区画のつなぎ"/g) || []).length; }, A3);
  if (r !== 2) bad('PowerPoint export draws the arrows between panels', r);
  /* 取り込み：表紙（中ほどに大きく中央・副題も中央）、字数は本文の字の大きさから、区画の見出しは箱の塗りから（濃灰） */
  const deck = Array.from(fs.readFileSync(path.resolve(__dirname, 'sample-pptx/test.pptx')));
  r = await page.evaluate(async d => { const r = await FZ.fromPptx(new Uint8Array(d), { title: 'test' }); const t = r.text.split('\n'); return { t, cols: r.doc.format.cols, rows: r.doc.format.rows, body: r.doc.format.bodyPct }; }, deck);
  const ti = r.t.findIndex(l => l.startsWith('[表題'));
  if (!(r.t[ti] === '[表題 中央]<横倍角><縦倍角>2026年度 事業計画</縦倍角></横倍角>' && ti >= 5 && r.t.includes('[中央]経営企画部'))) bad('the title slide becomes a cover: a big centered title in the middle and the subtitle centered', r.t.slice(0, ti + 4));
  if (!(r.cols < 60 && r.cols >= 24 && r.rows > 26 && r.body === 100)) bad('the line length follows the body text size of the slides (bigger text → fewer columns)', r);
  if (!r.t.includes('[番号1 区画横 区画見出し濃灰 区画矢印]現状から打ち手へ')) bad('filled boxes with white text give dark-gray panel heads', r.t.filter(l => /区画/.test(l)));
  /* 文机の A3 の書き出しを読み戻す：区画の見出しの形（網・線・網）とつなぎ、工程表（矢羽根・◆・途中の位置） */
  r = await page.evaluate(async s => { const d = FZ.parse(s); const bytes = await FZ.zipAsync(FZ.toPptx(d, { files: true })); const r = await FZ.fromPptx(bytes, { title: 't', format: JSON.parse(JSON.stringify(d.format)) }); return { t: r.text.split('\n'), cols: r.doc.format.cols }; }, A3);
  const P = r.t.filter(l => /^\[番号1 区画/.test(l));
  if (P.join('|') !== '[番号1 区画横 区画見出し網 区画矢印]現状から打ち手へ|[番号1 区画横 区画見出し線]効果・体制・リスク|[番号1 区画横 区画見出し網]見通しと判断いただきたいこと') bad('A3 round trip: panel head styles and arrows come back', P);
  const g = r.t.findIndex(l => /^\[工程表 工程列2 工程見出し2\]/.test(l));
  if (!(g > 0 && r.t[g + 2] === '| 全体 |  | ◆開始 |  |  |  |  |  | ◆［1/4］中間審査 |  |  |  |  | ◆［3/4］完了 |' && /\| 半製品化 \| 工場 \| ［1\/2］対象品目の選定 \| → \| 仕上げ工程の改修 \| → \| → \| →［1\/2］ \|/.test(r.t[g + 3]))) bad('A3 round trip: the schedule table becomes a Gantt chart again (bars, milestones, positions)', r.t.slice(g, g + 6));
  if (r.cols !== 90) bad('A3 round trip keeps 90 columns', r.cols);
  /* 文机の A4 の資料（本文欄＋図表欄）を読み戻す：本文幅 60%、図は図表欄の幅に対して */
  r = await page.evaluate(async s => { const d = FZ.parse(s); const bytes = await FZ.zipAsync(FZ.toPptx(d, { files: true })); const r = await FZ.fromPptx(bytes, { title: 't' }); return { t: r.text.split('\n'), body: r.doc.format.bodyPct, cols: r.doc.format.cols }; }, A4);
  if (!(r.body === 60 && r.cols === 60 && r.t.some(l => /^#グラフ g\d 図 折れ線( 100%)? 売上の推移$/.test(l)))) bad('A4 round trip: a text column with a figure column (本文幅 60%), figures sized to the figure column', { body: r.body, cols: r.cols, g: r.t.filter(l => /^#(グラフ|図版)/.test(l)) });
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-112f-app OK'); process.exit(fails ? 1 : 0);
})();
