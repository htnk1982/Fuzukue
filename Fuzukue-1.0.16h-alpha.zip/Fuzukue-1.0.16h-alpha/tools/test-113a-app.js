/* 1.0.13a：保存の印と中身の一致（P01）・版の履歴の見分けと戻す前の確認（P02）・変換中のキー（P03）・差分の分類（P04）・欄の案内と仮表示（P09）・説明の整合（P19） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs'); const http = require('http');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
const ROOT = path.resolve(__dirname, '../app');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' };
const SRC = ['#fzk 2', '題名: 試し', '---', '[表題]試しの文書', '', '[番号1]はじめに', '本文の一行目。', '', '[番号1]つぎに', '二つ目の節の本文。', ''].join('\n');
(async () => {
  /* 版の履歴はブラウザのファイルの参照（OPFS）で試すので、localhost から配る（file:// では使えない） */
  const server = http.createServer((q, r) => { const u = decodeURIComponent(q.url.split('?')[0]); const f = path.join(ROOT, u === '/' ? 'index.html' : u); if (!f.startsWith(ROOT) || !fs.existsSync(f)) { r.writeHead(404); r.end(); return; } r.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(r); });
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const port = server.address().port;
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto(`http://localhost:${port}/index.html`); await page.waitForTimeout(500);
  await page.evaluate(() => { localStorage.clear();
    window.mkH = (name, text, mt) => { const h = { name, _text: text, _mt: mt || 1000, getFile: async () => ({ lastModified: h._mt, size: h._text.length, text: async () => h._text }), isSameEntry: async o => o === h }; return h; };
    window.SV = { delay: 300, active: 0, max: 0, fail: false, calls: 0 };
    FZ.files.save = async (text, ref, name) => { const S = SV; S.calls++; S.active++; S.max = Math.max(S.max, S.active); await new Promise(r => setTimeout(r, S.delay)); S.active--; if (S.fail) throw new Error('書けません'); const h = (ref && ref.handle) || mkH(name, '', 0); h._text = text; h._mt = Date.now(); return { name: h.name, handle: h }; }; });
  const open = (name = 'a.fzk') => page.evaluate(async ([s, name]) => { const h = mkH(name, s, 1000); await FZ.app.loadText(s, name, { handle: h, name }); window.H = h; FZ.app.ed.setCaret({ line: 6, seg: 0, off: 0 }); FZ.app.render(); await new Promise(r => setTimeout(r, 30)); }, [SRC, name]);

  /* P01-1：保存中に打った字は未保存のまま（印・閉じる前の確認・復旧用の退避） */
  await open();
  let r = await page.evaluate(async () => { const { ed, st } = FZ.app; ed.insertText('前'); const p = FZ.app.saveFile(false); await new Promise(r => setTimeout(r, 80)); const mid = document.getElementById('stSave').textContent; ed.insertText('後'); const ok = await p;
    const rec = JSON.parse(localStorage.getItem(FZ.app.RECOVER_KEY()) || 'null'); const ev = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(ev);
    return { ok, dirty: ed.dirty, msg: st.msg, mid, saved: H._text.includes('前') && !H._text.includes('後'), rec: !!(rec && rec.text.includes('後')), guard: ev.defaultPrevented }; });
  if (!(r.ok && r.dirty && /保存完了・その後の入力は未保存/.test(r.msg) && r.mid === '保存中…' && r.saved && r.rec && r.guard)) bad('typing during a slow save keeps the document unsaved, recovered and guarded on close', r);
  /* 同じ世代なら保存済・退避は消える */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; const ok = await FZ.app.saveFile(false); return { ok, dirty: ed.dirty, msg: st.msg, rec: localStorage.getItem(FZ.app.RECOVER_KEY()) }; });
  if (!(r.ok && !r.dirty && /保存しました/.test(r.msg) && r.rec == null)) bad('a save with no input meanwhile marks the document saved and clears the recovery', r);
  /* 閉じる前の「保存して閉じる」：保存中に打った字があれば閉じずにもう一度聞く */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; ed.insertText('閉'); let closed = false; window.fzCloseNow = () => { closed = true; }; window.fzRequestClose(); const form1 = st.form; const btn = document.querySelector('#sub button[data-act="save"]'); btn.click(); await new Promise(r => setTimeout(r, 60)); ed.insertText('滑'); await new Promise(r => setTimeout(r, 450)); const form2 = st.form; const msg = st.msg; FZ.app.st.form && document.querySelector('#sub button[data-act="cancel"]').click(); return { form1, form2, closed, dirty: ed.dirty, msg }; });
  if (!(r.form1 === 'ask' && r.form2 === 'ask' && !r.closed && r.dirty)) bad('"save and close" with input during the save asks again instead of closing', r);
  /* P01-2：保存に失敗しても復旧用の退避は残る */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; SV.fail = true; ed.insertText('失'); const ok = await FZ.app.saveFile(false); SV.fail = false; const rec = JSON.parse(localStorage.getItem(FZ.app.RECOVER_KEY()) || 'null'); return { ok, dirty: ed.dirty, msg: st.msg, rec: !!(rec && rec.text.includes('失')) }; });
  if (!(r.ok === false && r.dirty && /保存できませんでした/.test(r.msg) && /復旧用に退避しました/.test(r.msg) && r.rec)) bad('a failed save keeps the recovery data', r);
  /* P01-3：退避そのものの失敗を知らせる */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; const LS = Storage.prototype.setItem, put = FZ.RDB.put; Storage.prototype.setItem = function () { throw new Error('quota'); }; FZ.RDB.put = () => Promise.reject(new Error('quota')); ed.insertText('退'); const ok = await FZ.app.saveRecovery(); Storage.prototype.setItem = LS; FZ.RDB.put = put; const m1 = st.msg; const ok2 = await FZ.app.saveRecovery(); return { ok, ok2, m1 }; });
  if (!(r.ok === false && /復旧用の退避に失敗/.test(r.m1) && r.ok2 === true)) bad('a failed recovery save is reported (and only then)', r);
  /* P01-4：保存は一列に（手動と自動が重ならない）。保存中に文書を替えたら、新しい文書を保存済にしない */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; SV.max = 0; ed.insertText('並'); const a = FZ.app.saveFile(false), b = FZ.app.autoSave(), c = FZ.app.saveFile(false); await Promise.all([a, b, c]); return { max: SV.max, dirty: ed.dirty }; });
  if (!(r.max === 1 && !r.dirty)) bad('saves run one at a time', r);
  r = await page.evaluate(async s => { const { ed, st } = FZ.app; ed.insertText('替'); const old = st.file; const p = FZ.app.saveFile(false); await new Promise(r => setTimeout(r, 50)); await FZ.app.loadText(s.replace('試しの文書', '別の文書'), 'b.fzk', null); ed.insertText('新'); await p; return { file: st.file, dirty: ed.dirty, msg: st.msg, wrote: old.handle._text.includes('替') }; }, SRC);
  if (!(r.file === null && r.dirty && /別の文書へ替えた/.test(r.msg) && r.wrote)) bad('switching documents during a save does not mark the new document saved', r);
  /* P01-5：外での書き換え：0.5 秒後の書き換え（V5）・同じ日時で中身だけ違う・日時だけ違って中身が同じ */
  r = await page.evaluate(async () => { const f = FZ.files; const h = mkH('x.fzk', 'abc', 10000); const ref = { handle: h, name: 'x.fzk', mtime: 10000, size: 3, hash: f.hash('abc') };
    h._mt = 10500; h._text = 'abd'; const a = await f.outside(ref); h._mt = 10000; const ref2 = { ...ref }; const b = await f.outside(ref2); h._text = 'abc'; h._mt = 20000; const ref3 = { ...ref }; const c = await f.outside(ref3); h._text = 'xyz'; h._mt = 10000; const d = await f.outside({ handle: h, name: 'x', mtime: 10000 });
    return { a: a.changed, b: b.changed, c: c.changed, cm: ref3.mtime, d: d.changed }; });
  if (!(r.a === true && r.b === true && r.c === false && r.cm === 20000 && r.d === false)) bad('outside changes: a 500 ms rewrite and a same-time rewrite are found; a touch with the same content is not', r);

  /* P02：版の履歴。OPFS のファイルの参照で、別のフォルダの同じ名前のファイル・別名の写しは混ざらない */
  /* この試験の Chromium は、ファイルの参照を IndexedDB に入れると画面ごと落ちる（実際の Edge・Chrome では入る）ので、参照の表（hist:ids）だけ記憶の中に置き換える */
  await page.evaluate(() => { const R = FZ.RDB, get = R.get, put = R.put, mem = new Map(); R.get = k => k === 'hist:ids' ? Promise.resolve(mem.get(k)) : get(k); R.put = (k, v) => k === 'hist:ids' ? (mem.set(k, v), Promise.resolve()) : put(k, v); });
  r = await page.evaluate(async () => { const root = await navigator.storage.getDirectory(); const d1 = await root.getDirectoryHandle('d1', { create: true }), d2 = await root.getDirectoryHandle('d2', { create: true });
    const h1 = await d1.getFileHandle('same.fzk', { create: true }), h2 = await d2.getFileHandle('same.fzk', { create: true }), h1b = await d1.getFileHandle('same.fzk');
    const k1 = await FZ.app.histKeyOf({ handle: h1, name: h1.name }), k2 = await FZ.app.histKeyOf({ handle: h2, name: h2.name }), k1b = await FZ.app.histKeyOf({ handle: h1b, name: h1b.name });
    return { k1, k2, k1b }; });
  if (!(r.k1 && r.k2 && r.k1 !== r.k2 && r.k1 === r.k1b && /^hist:id:/.test(r.k1))) bad('history keys: same-named files in different folders differ, the same file keeps its key', r);
  r = await page.evaluate(async s => { const { ed, st } = FZ.app; const A = mkH('同名.fzk', s, 1000), B = mkH('同名.fzk', s, 1000);
    await FZ.app.loadText(s, '同名.fzk', { handle: A, name: '同名.fzk' }); ed.setCaret({ line: 6, seg: 0, off: 0 }); ed.insertText('甲'); await FZ.app.saveFile(false); await new Promise(r => setTimeout(r, 50));
    await FZ.app.loadText(s, '同名.fzk', { handle: B, name: '同名.fzk' }); ed.setCaret({ line: 6, seg: 0, off: 0 }); ed.insertText('乙'); await FZ.app.saveFile(false); await new Promise(r => setTimeout(r, 50));
    const lb = await FZ.app.histList(); const la = await FZ.app.histList({ handle: A, name: '同名.fzk' });
    return { a: la.map(v => v.kind + (v.text.includes('乙') ? '乙' : '') + (v.text.includes('甲') ? '甲' : '')), b: lb.map(v => v.kind + (v.text.includes('乙') ? '乙' : '') + (v.text.includes('甲') ? '甲' : '')) }; }, SRC);
  if (!(r.a.join() === '保存甲,開いたとき' && r.b.join() === '保存乙,開いたとき')) bad('two files with the same name keep separate histories', r);
  /* 見るだけでは変わらない。違う節を示す。「この版を戻す」で戻し、戻す前の版を履歴に残す */
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; ed.insertText('未'); const before = FZ.serialize(ed.doc); await FZ.app.histView(1); await new Promise(r => setTimeout(r, 80)); const same = FZ.serialize(ed.doc) === before; const side = document.getElementById('sideBody').innerText;
    const btn = document.querySelector('#sideBody [data-hact="restore"]'); btn.click(); await new Promise(r => setTimeout(r, 150)); const after = FZ.serialize(ed.doc); const L = await FZ.app.histList();
    return { same, side, hasBtn: !!btn, restored: !after.includes('乙') && !after.includes('未'), top: L[0].kind, keptNow: L[0].text.includes('未'), dirty: ed.dirty }; });
  if (!(r.same && /この版を戻す/.test(r.side) && /違う節/.test(r.side) && /つぎに/.test(r.side) && r.restored && r.top === '戻す前の版' && r.keptNow && r.dirty)) bad('viewing a version leaves the document as is; restoring keeps the current version first', r);
  r = await page.evaluate(async () => { await FZ.app.histView(2); await new Promise(r => setTimeout(r, 60)); const inp = document.querySelector('#sideBody [data-hname]'); inp.value = '提出前'; document.querySelector('#sideBody [data-hact="name"]').click(); await new Promise(r => setTimeout(r, 120)); const L = await FZ.app.histList(); return L.map(v => v.label || ''); });
  if (r[2] !== '提出前') bad('a version can be named', r);

  /* P03：変換中の Enter・矢印・Esc で操作を走らせない（帯の欄・コマンドの検索・フレームワークの選び場） */
  r = await page.evaluate(async () => { const { st } = FZ.app; const kd = (el, key, comp) => el.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true, isComposing: comp, keyCode: comp ? 229 : (key === 'Enter' ? 13 : 0) }));
    FZ.app.openForm('zoom'); const inp = document.querySelector('#sub input'); inp.value = '150'; kd(inp, 'Enter', true); const z1 = st.form; kd(inp, 'Escape', true); const z2 = st.form; kd(inp, 'Escape', false); const z3 = st.form;
    FZ.app.toggleSide('palette'); const pal = document.getElementById('palInput'); pal.value = '太字'; pal.dispatchEvent(new Event('input')); kd(pal, 'Enter', true); const p1 = st.side; kd(pal, 'Escape', false);
    FZ.app.openFwPick(); const fw = document.querySelector('#fwpick .fwp-q'); const n0 = FZ.app.ed.doc.lines.length; kd(fw, 'Enter', true); const f1 = !document.getElementById('fwpick').hidden && FZ.app.ed.doc.lines.length === n0; kd(fw, 'Escape', true); const f2 = !document.getElementById('fwpick').hidden; kd(fw, 'Escape', false);
    return { z1, z2, z3, p1, f1, f2, f3: document.getElementById('fwpick').hidden }; });
  if (!(r.z1 === 'zoom' && r.z2 === 'zoom' && r.z3 == null && r.p1 === 'palette' && r.f1 && r.f2)) bad('composing Enter/Esc do not act in band forms, command search and the framework picker', r);

  /* P04：リンク先だけ・強調だけの違いも出す（分類つき）。取り込むとリンク先が変わる */
  r = await page.evaluate(async () => { const { ed } = FZ.app; await FZ.app.loadText(['#fzk 2', '---', '[表題]題', '', '[番号1]節', '<リンク https://a.example/>案内</リンク>はこちら。', '大事なところ。', ''].join('\n'), 'l.fzk', null); ed.setCaret({ line: 5, seg: 0, off: 0 });
    const B = FZ.parse(FZ.serialize(ed.doc).replace('https://a.example/', 'https://b.example/')); const H = FZ.diffDocs(ed.doc, ed.doc.lines.map((_, i) => i), B);
    const C = FZ.parse(FZ.serialize(ed.doc).replace('大事な', '<太字>大事な</太字>')); const H2 = FZ.diffDocs(ed.doc, ed.doc.lines.map((_, i) => i), C);
    const md = FZ.toGfm(ed.doc).replace('https://a.example/', 'https://b.example/'); FZ.app.openForm('aiback'); document.querySelector('#sub textarea[name="md"]').value = md; document.querySelector('#sub button[data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 50));
    const info = document.querySelector('#sub .info').textContent, prev = document.querySelector('#sub .aiprev').textContent; document.querySelector('#sub button[data-act="take"]').click(); await new Promise(r => setTimeout(r, 50));
    const ln = ed.doc.lines.find(l => l.segs[0].text.startsWith('案内')); const url = ln && ln.segs[0].links && ln.segs[0].links[0].url; FZ.app.st.form && FZ.app.openForm('count');
    return { n: H.length, cats: H.map(h => h.cats.join()), n2: H2.length, cats2: H2.map(h => h.cats.join()), info, prev, url, skip: FZ.DIFF_SKIP }; });
  if (!(r.n === 1 && r.cats[0] === 'link' && r.n2 === 1 && r.cats2[0] === 'emph')) bad('link-only and emphasis-only changes are differences with their category', r);
  if (!(/リンク・参照/.test(r.info) && /b\.example/.test(r.prev) && r.url === 'https://b.example/' && /字の大きさ/.test(r.skip))) bad('the AI return shows a URL-only change and takes it', r);
  r = await page.evaluate(async () => { const A = FZ.parse(['#fzk 2', '---', '[番号1]節', '本文です。', ''].join('\n')); const B = FZ.parse(['#fzk 2', '---', '[番号2]節', '本文でした。', ''].join('\n')); return FZ.diffDocs(A, A.lines.map((_, i) => i), B).map(h => h.cats.sort().join()); });
  if (r.join('|') !== 'body,struct') bad('structure and body changes are told apart', r);
  /* Markdown の往復で強調・リンクの偽の違いが出ない（見本の文書すべて） */
  for (const f of ['見本.fzk', '資料見本.fzk', '新聞風見本.fzk']) { const t = fs.readFileSync(path.resolve(__dirname, '../samples', f), 'utf8');
    r = await page.evaluate(async ([t, f]) => { await FZ.app.loadText(t, f, null); const ed = FZ.app.ed; while (!ed.layoutDone) ed.continueLayout(500); const base = FZ.newDoc(); base.format = JSON.parse(JSON.stringify(ed.doc.format)); const anchors = ed.doc.lines.map(l => l.attrs.anchor).filter(Boolean), figs = ed.figList().map(x => x.fg.id); const B = FZ.fromGfm(FZ.toGfm(ed.doc), base, { refTargets: { anchors, figs } }); return FZ.diffDocs(ed.doc, ed.doc.lines.map((_, i) => i), B).filter(h => h.detail).length; }, [t, f]);
    if (r !== 0) bad('no false link/emphasis differences after a Markdown round trip: ' + f, r); }

  /* P09：案内は欄の動きどおり。図表の設定は仮表示（Esc で開く前に戻る）、確定は 1 回の Ctrl+Z で戻る */
  r = await page.evaluate(() => ({ fig: FZ.formGuide('fig').map(x => x.join(' ')).join('／'), chart: FZ.formGuide('chart').map(x => x.join(' ')).join('／'), fmt: FZ.formGuide('format').map(x => x.join(' ')).join('／'), find: FZ.formGuide('find').map(x => x.join(' ')).join('／') }));
  if (!(/仮表示中.*Enter 確定.*Esc 元に戻す/.test(r.fig) && /反映済み.*Esc 閉じる.*Ctrl\+Z/.test(r.chart) && /Esc 取消/.test(r.fmt) && /Esc 閉じる/.test(r.find) && !/取消/.test(r.find))) bad('form guides match what Enter and Esc do', r);
  r = await page.evaluate(async () => { const { ed, st } = FZ.app; const s = ['#fzk 2', '---', '本文の行。', '#グラフ g1 図 棒 売上', '|  | 1月 | 2月 |', '| A | 1 | 2 |', ''].join('\n'); await FZ.app.loadText(s, 'f.fzk', null); const id = ed.figList()[0].fg.id; const w0 = JSON.stringify(ed.figById(id).fg);
    const setW = v => { const el = document.querySelector('#sub [name="fsz"]'); if (el && el.tagName === 'SELECT') { el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); return true; } const b = document.querySelector(`#sub [data-cyc="fsz"]`); return !!b; };
    st.figSel = id; FZ.app.openForm('fig'); const guide = document.getElementById('stGuide').textContent; const sizes = [...document.querySelectorAll('#sub [name="fsz"] option')].map(o => o.value);
    setW(sizes[1]); setW(sizes[2]); const w1 = JSON.stringify(ed.figById(id).fg); document.querySelector('#sub').dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); const w2 = JSON.stringify(ed.figById(id).fg);
    const u0 = ed.undoStack.length; FZ.app.openForm('fig'); setW(sizes[1]); setW(sizes[2]); document.querySelector('#sub button[data-act="apply"]').click(); const w3 = JSON.stringify(ed.figById(id).fg); const u1 = ed.undoStack.length; ed.undo(); const w4 = JSON.stringify(ed.figById(id).fg);
    return { guide, sizes, changed: w1 !== w0, reverted: w2 === w0, kept: w3 !== w0, oneStep: u1 - u0, undone: w4 === w0 }; });
  if (!(/仮表示中/.test(r.guide) && r.changed && r.reverted && r.kept && r.oneStep === 1 && r.undone)) bad('figure settings: preview, Esc reverts, confirmed changes undo in one step', r);

  /* P19：はじめに.md は hajime.src.md から作ったもの（いまのメニューの表と一致）。旧い「F キー → 1 文字」が説明に残らない */
  const hj = require('./build-hajime'); const info = await hj.collect(page); const gen = hj(info);
  if (gen.missing.length) bad('はじめに.md: every command reference resolves', gen.missing);
  if (gen.text !== fs.readFileSync(hj.OUT, 'utf8')) bad('はじめに.md is up to date with the menu (run tools/build-kaisetsu.js)');
  const OLD = /F\d{1,2} ?→ ?[A-Z0-9]|F5 と 1 文字|1 打鍵/;
  for (const f of ['はじめに.md', 'app/js/fz-help.js', 'docs/文机_文書仕様_生成AI向け.md', ...fs.readdirSync(path.resolve(__dirname, 'kaisetsu')).map(x => 'tools/kaisetsu/' + x)]) { const t = fs.readFileSync(path.resolve(__dirname, '..', f), 'utf8'); const m = t.match(OLD); if (m) bad('no letter-key steps left in ' + f, m[0]); }
  /* 「最初の 5 分」の道筋は、いまの帯で押せる（F キーで帯を出し、その名前のタイルがある） */
  const five = gen.text.split('## 最初の 5 分')[1].split('\n## ')[0]; const steps = [...five.matchAll(/(F\d{1,2})「([^」]+)」/g)].map(m => [m[1], m[2]]);
  r = await page.evaluate(steps => { const M = FZ.app._menu(); const miss = []; for (const [k, name] of steps) { const fk = M.FK.text.find(x => x[0] === k); const g = fk && M.GROUP_OF[fk[2]]; const G = g && M.GROUPS[g]; const ok = G && G.items.some(it => it.msel ? (M.MSEL[it.msel].label === name.replace(/▾$/, '')) : String(it.short || it.label || '').replace(/（.*$/, '') === name); if (!ok) miss.push(k + '「' + name + '」'); } return { n: steps.length, miss }; }, steps);
  if (!(r.n >= 20 && !r.miss.length)) bad('every step in "the first 5 minutes" names a tile on the current band', r);

  await browser.close(); server.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-113a-app OK'); process.exit(fails ? 1 : 0);
})();
