/* 1.0.13b：帯をキーで操作（P06）・操作の対象を先に見せる（P07）・書き出しの目的と結果・変換の記録（P18） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
const SRC = ['#fzk 2', '題名: 試し', '---', '[表題]試しの文書', '', '[番号1]はじめに', '一つ目の本文。', '[項目1]項目あ', '[項目1]項目い', '', '[番号1]つぎに', '二つ目の本文。', '[項目1]項目う',
  '#表 列 0,10,20 様式 格子 見出し淡', '| 欄 | 値 |', '| a | 1 |', '', '[番号1 字下げ3]おわりに', '<白抜き>白い字</白抜き>と<傍点>点の字</傍点>。', '[中央]真ん中の行。', ''].join('\n');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const load = (line = 3) => page.evaluate(async ([s, line]) => { localStorage.clear(); await FZ.app.loadText(s, 't.fzk', null); FZ.app.ed.setCaret({ line, seg: 0, off: 0 }); FZ.app.render(); await new Promise(r => setTimeout(r, 30)); }, [SRC, line]);
  await load(3);
  const state = () => page.evaluate(() => ({ kb: FZ.app.st.bandKb, act: document.activeElement && (document.activeElement.dataset.cmd || document.activeElement.tagName), guide: document.getElementById('stGuide').textContent, group: FZ.app.st.group, caret: FZ.app.ed.caret.line }));

  /* P06：同じ F キーを 2 回で帯へ。1 回目は帯の切り替えだけで、続けて打った字は本文に入る */
  await page.keyboard.press('F4'); let r = await state(); if (!(r.kb !== true && /F4 もう一度/.test(r.guide) && r.act === 'TEXTAREA')) bad('one F-key press only switches the band and hints the second press', r);
  await page.keyboard.press('F4'); r = await state();
  const ring = await page.evaluate(() => { const cs = getComputedStyle(document.activeElement); return { w: cs.outlineWidth, st: cs.outlineStyle, sh: cs.boxShadow }; });
  if (!(r.kb === true && r.act && r.act !== 'TEXTAREA' && /選ぶ/.test(r.guide) || /対象/.test(r.guide))) bad('the second press puts the key mark on a band item', r);
  if (!(ring.w === '3px' && ring.st === 'solid' && /255, 255, 255/.test(ring.sh) && /0, 0, 0/.test(ring.sh))) bad('the key mark is a thick black-and-white ring', ring);
  const a0 = r.act; await page.keyboard.press('ArrowRight'); r = await state(); if (!(r.kb && r.act !== a0)) bad('→ moves to the next item', r);
  const geo = await page.evaluate(() => { const a = document.activeElement.getBoundingClientRect(); return a.top; }); await page.keyboard.press('ArrowDown'); const geo2 = await page.evaluate(() => document.activeElement.getBoundingClientRect().top);
  if (!(geo2 > geo)) bad('↓ moves to the item in the lower row', { geo, geo2 });
  await page.keyboard.press('Home'); r = await state(); if (r.act !== 'styleBody') bad('Home goes to the first item', r);
  /* Enter で実行して編集位置へ戻る（番号見出しを選んで実行） */
  await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="styleNum"]'); el.focus(); }); await page.keyboard.press('Enter'); r = await state();
  let attrs = await page.evaluate(() => FZ.app.ed.doc.lines[3].attrs.style); if (!(attrs === 'num' && r.act === 'TEXTAREA' && r.caret === 3 && !r.kb)) bad('Enter runs the item and returns to the editing position', { r, attrs });
  /* 字のキーは本文に、Ctrl+Z も効く */
  await page.keyboard.press('F4'); await page.keyboard.press('F4'); await page.keyboard.press('x'); r = await state(); let txt = await page.evaluate(() => FZ.app.ed.doc.lines[3].segs[0].text);
  if (!(r.act === 'TEXTAREA' && !r.kb && /^x/.test(txt))) bad('a character typed on the band goes into the body', { r, txt });
  await page.keyboard.press('F4'); await page.keyboard.press('F4'); await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z'); attrs = await page.evaluate(() => FZ.app.ed.doc.lines[3].attrs.style || '');
  if (attrs !== '') bad('Ctrl+Z on the band undoes in the body', attrs);
  /* Esc・変換の始まりで本文へ */
  await page.keyboard.press('F4'); await page.keyboard.press('F4'); await page.keyboard.press('Escape'); r = await state(); if (!(r.act === 'TEXTAREA' && !r.kb)) bad('Esc returns to the body', r);
  await page.keyboard.press('F4'); await page.keyboard.press('F4'); await page.evaluate(() => document.activeElement.dispatchEvent(new KeyboardEvent('keydown', { key: 'Process', keyCode: 229, isComposing: true, bubbles: true }))); r = await state(); if (!(r.act === 'TEXTAREA' && !r.kb)) bad('starting a conversion returns to the body', r);
  /* もっと深い帯（見出し飾り）へはキーのまま進む。戻るも */
  await page.keyboard.press('F6'); await page.keyboard.press('F6'); await page.evaluate(() => document.querySelector('#sub .ch[data-cmd="headGroup"]').focus()); await page.keyboard.press('Enter'); r = await state();
  if (!(r.group === 'head' && r.kb)) bad('an item that opens a deeper band keeps the key mark there', r);
  await page.keyboard.press('Escape'); await page.keyboard.press('Escape');
  /* 本文の Tab は今までどおり（帯に取られない） */
  await load(4); await page.keyboard.press('Tab'); const lv = await page.evaluate(() => FZ.app.ed.doc.lines[4].attrs.list.level); if (lv !== 1) bad('Tab in the body still indents a list item', lv);

  /* P07：帯の項目にマウスを乗せると対象を見せる（実際のコマンドと同じ範囲） */
  await load(2);
  const hover = cmd => page.evaluate(async cmd => { const el = document.querySelector(`#sub .ch[data-cmd="${cmd}"]`); if (!el) return null; el.dispatchEvent(new PointerEvent('pointerover', { bubbles: true })); await new Promise(r => requestAnimationFrame(() => setTimeout(r, 30))); return { t: FZ.app.st.tprev, guide: document.getElementById('stGuide').textContent, rects: document.querySelectorAll('.ov rect').length }; }, cmd);
  const leave = () => page.evaluate(async () => { document.getElementById('sub').dispatchEvent(new PointerEvent('pointerleave')); await new Promise(r => requestAnimationFrame(() => setTimeout(r, 30))); });
  await page.evaluate(() => FZ.app.toggleGroup('struct'));
  r = await hover('sx:down'); const sec = await page.evaluate(() => FZ.app.ed.sectionRange(2));
  if (!(r && r.t && JSON.stringify(r.t.ranges[0]) === JSON.stringify(sec) && /「はじめに」の節と配下 2 項目・段落 1/.test(r.guide))) bad('hovering "down" shows the section and what moves with it', { r, sec });
  await leave(); const r0 = await page.evaluate(() => document.querySelectorAll('.ov rect').length); r = await hover('sx:down'); if (!(r.rects > r0)) bad('the target is outlined on the paper', { r0, r: r.rects });
  /* 実行すると、動いた先の対象を見せ直す。1 回の Ctrl+Z で戻る */
  await page.evaluate(() => { const el = document.querySelector('#sub .ch[data-cmd="sx:down"]'); el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, button: 0 })); }); await page.waitForTimeout(50);
  r = await page.evaluate(() => ({ t: FZ.app.st.tprev, head: FZ.app.ed.doc.lines[FZ.app.st.tprev.ranges[0][0]].segs[0].text }));
  if (!(r.head === 'はじめに' && r.t.ranges[0][0] > 2)) bad('after running, the preview follows the moved section', r);
  await page.evaluate(() => FZ.app.ed.undo()); r = await page.evaluate(() => FZ.app.ed.doc.lines[2].segs[0].text); if (r !== 'はじめに') bad('one undo puts it back', r);
  await leave();
  /* 種類の変換：位置を決めた見出しは「個別の位置指定は保持」 */
  await load(13); await page.evaluate(() => FZ.app.toggleGroup('struct')); r = await hover('styleBody'); if (!(r && /種類を本文へ変更/.test(r.guide) && /個別の位置指定は保持/.test(r.guide))) bad('kind change preview notes the kept position', r);
  await load(3); await page.evaluate(() => { FZ.app.ed.anchor = { line: 3, seg: 0, off: 0 }; FZ.app.ed.caret = { line: 5, seg: 0, off: 0, vcol: null, vrow: 0 }; FZ.app.toggleGroup('struct'); }); r = await hover('styleNum'); if (!(r && /選んだ 3 行/.test(r.guide) && JSON.stringify(r.t.ranges) === '[[3,5]]')) bad('kind change preview uses the selected lines', r);
  /* 番号・記号の形：同じ段のもの文書全体 */
  await load(2); await page.evaluate(() => FZ.app.toggleGroup('fmt')); r = await hover('sx:mark'); if (!(r && /番号見出し1 の番号・記号/.test(r.guide) && /文書全体 3 箇所/.test(r.guide) && r.t.ranges.length === 3)) bad('number-shape preview counts the same level in the whole document', r);
  await leave();

  /* P18：書き出しは保存先を決めて書き終わってから「書き出しました」。やめた・失敗もそのとおり */
  await load(3);
  const exp = (mode, cmd) => page.evaluate(async ([mode, cmd]) => { const seen = []; const el = document.getElementById('stMsg'); const mo = new MutationObserver(() => seen.push(el.textContent)); mo.observe(el, { childList: true, characterData: true, subtree: true }); let wrote = null;
    window.showSaveFilePicker = async o => { if (mode === 'cancel') { const e = new Error('x'); e.name = 'AbortError'; throw e; } return { name: o.suggestedName, createWritable: async () => ({ write: async d => { await new Promise(r => setTimeout(r, 150)); if (mode === 'fail') throw new Error('書き込めません'); wrote = d; }, close: async () => { }, abort: async () => { } }) }; };
    const p = FZ.app.run(cmd); await new Promise(r => setTimeout(r, 60)); const mid = el.textContent; await p; await new Promise(r => setTimeout(r, 250)); mo.disconnect(); return { mid, last: el.textContent, seen, wrote: wrote ? (typeof wrote === 'string' ? wrote.length : wrote.length || wrote.byteLength) : 0, log: FZ.app.st.convLog && FZ.app.st.convLog.title }; }, [mode, cmd]);
  r = await exp('ok', 'exportPptx'); if (!(/書き出し中/.test(r.mid) && !/書き出しました/.test(r.mid) && /PowerPoint に書き出しました：試し\.pptx/.test(r.last) && r.wrote > 1000)) bad('export says done only after the write finished', r);
  if (!/近似・入らない所 \d+ 種/.test(r.last) || r.log !== 'PowerPoint（.pptx）への書き出し') bad('export reports the approximations and keeps a conversion log', r);
  r = await exp('cancel', 'exportDocx'); if (!(/書き出しをやめました/.test(r.last) && !r.seen.some(t => /書き出しました/.test(t)))) bad('a cancelled export says so (and nothing about success)', r);
  r = await exp('fail', 'exportTxt'); if (!(/書き出せませんでした：書き込めません/.test(r.last) && !r.seen.some(t => /に書き出しました/.test(t)))) bad('a failed export says so', r);
  r = await page.evaluate(async () => { window.showSaveFilePicker = undefined; let got = null; const dl = FZ.files.download; FZ.files.download = (d, n) => { got = n; }; FZ.app.run('exportMd'); await new Promise(r => setTimeout(r, 400)); FZ.files.download = dl; return { got, msg: document.getElementById('stMsg').textContent }; });
  if (!(r.got === '試し.md' && /ダウンロードに渡しました/.test(r.msg))) bad('without a save window, the export says it was handed to downloads', r);
  /* 変換の記録：行の位置つき。選ぶとその行へ */
  r = await page.evaluate(() => { const L = FZ.convAudit(FZ.app.ed.doc, 'pptx').items; const M = FZ.convAudit(FZ.app.ed.doc, 'md').items; const D = FZ.convAudit(FZ.app.ed.doc, 'docx').items; return { pptx: L.map(x => x.what + ':' + x.lines.join(',')), md: M.map(x => x.what + ':' + x.lines.join(',')), docx: D.map(x => x.what + ':' + x.lines.join(',')) }; });
  if (!(r.pptx.some(x => /^傍点は入らない:14$/.test(x)) && r.pptx.some(x => /^番号・記号は字として入る.*:2,4,5,7,9,13$/.test(x)))) bad('PowerPoint audit lists dots and burnt-in numbers with their lines', r.pptx);
  if (!(r.md.some(x => /白抜き:14$/.test(x)) && r.md.some(x => /^揃え.*:15$/.test(x)))) bad('Markdown audit is measured by reading back (outline and alignment)', r.md);
  if (!r.docx.some(x => /白抜きは Word の輪郭の字に:14$/.test(x))) bad('Word audit follows the export spec', r.docx);
  r = await page.evaluate(async () => { FZ.app.run('exportMd'); await new Promise(r => setTimeout(r, 100)); FZ.app.toggleSide('conv'); await new Promise(r => setTimeout(r, 50)); const items = document.querySelectorAll('#sideBody .li.cv'); const el = [...items].find(x => /白い字/.test(x.textContent)); if (el) el.click(); return { n: items.length, caret: FZ.app.ed.caret.line, title: document.getElementById('sideTitle').textContent }; });
  if (!(r.n > 0 && r.caret === 14 && r.title === '変換の記録')) bad('the conversion log jumps to the line', r);
  await page.evaluate(() => FZ.app.toggleSide('conv'));
  /* 目的と対象を帯で：Word（資料は紙面のまま／構成）・AI に写す範囲 */
  r = await page.evaluate(() => { FZ.app.ed.setCaret({ line: 8, seg: 0, off: 0 }); return { sec: FZ.targetOf('aiCopySec'), docx: FZ.targetOf('exportDocx').text, tiles: (FZ.app.toggleGroup('file'), [...document.querySelectorAll('#sub .ch')].map(x => x.dataset.cmd)) }; });
  if (!(/「つぎに」の節/.test(r.sec.text) && r.sec.ranges[0][0] === 7 && /Word：文書全体/.test(r.docx) && r.tiles.includes('exportDocxFlow') && r.tiles.includes('convLog'))) bad('band shows the purpose and the current target of exports', r);
  r = await page.evaluate(async () => { await navigator.clipboard.writeText('').catch(() => { }); await FZ.app.run('aiCopySec'); return { log: FZ.app.st.convLog && FZ.app.st.convLog.title }; });
  if (!/AI に写した Markdown（「つぎに」の節）/.test(r.log || '')) bad('copying for the AI keeps a Markdown conversion log of the range', r);
  /* 取り込み：PowerPoint の推定・入らない所を記録（スライドの題の行へ） */
  const deck = Array.from(fs.readFileSync(path.resolve(__dirname, 'sample-pptx/test.pptx')));
  r = await page.evaluate(async d => { const f = new File([new Uint8Array(d)], 'test.pptx'); FZ.app.ed.dirty = false; await FZ.app.importPptx(f); await new Promise(r => setTimeout(r, 200)); const C = FZ.app.st.convLog; return { title: C && C.title, items: C ? C.items.map(x => x.what + ':' + x.lines.length) : [], msg: document.getElementById('stMsg').textContent, titles: C ? C.items.flatMap(x => x.lines).every(i => FZ.app.ed.doc.lines[i].attrs.style === 'title') : false }; }, deck);
  if (!(r.title === 'PowerPoint の取り込み' && r.items.some(x => /区画は、横に並んだ図形/.test(x)) && r.titles && /推定・入らない所 \d+ 種/.test(r.msg))) bad('PowerPoint import records inferred structure by slide', r);
  /* 取り込み：Word の数式・脚注は入らないと記録（近くの字の行へ） */
  r = await page.evaluate(async () => { const d = FZ.parse(['#fzk 2', '---', '[番号1]式の節', '面積は次の式で求める。', '注のある文。', ''].join('\n')); const files = FZ.toDocx(d, { files: true }); const f = files.find(x => x.name === 'word/document.xml'); let x = typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data);
    x = x.replace(/(<w:t[^>]*>面積は次の式で求める。<\/w:t><\/w:r>)/, '$1<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"><m:r><m:t>S=ab</m:t></m:r></m:oMath>').replace(/(<w:t[^>]*>注のある文。<\/w:t><\/w:r>)/, '$1<w:r><w:footnoteReference w:id="1"/></w:r>'); f.data = x;
    const buf = await FZ.zipAsync(files); FZ.app.ed.dirty = false; await FZ.app.importDocx(new File([buf], 'w.docx')); await new Promise(r => setTimeout(r, 200)); const C = FZ.app.st.convLog; return { title: C && C.title, items: C ? C.items.map(it => it.what + ':' + it.lines.map(i => FZ.app.ed.doc.lines[i].segs.map(s => s.text).join('')).join('|')) : [] }; });
  if (!(r.title === 'Word の取り込み' && r.items.some(x => /^数式は［数式：字］として本文に.*:面積は次の式で求める。/.test(x)) && r.items.some(x => /^脚注は［注：中身］として本文に.*:注のある文。/.test(x)))) bad('Word import records equations and footnotes near their text', r);

  /* E-4：「人に渡す」の先頭は HTML と PDF（序列は変えず並びで推す）。HTML は紙面のまま（頁ごとの SVG・目次・検索用の字・印刷の用紙） */
  r = await page.evaluate(() => { FZ.app.toggleGroup('file'); const T = [...document.querySelectorAll('#sub .cl')].find(c => /人に渡す/.test(c.textContent)); return T ? [...T.querySelectorAll('.ch')].map(x => x.dataset.cmd) : []; });
  if (r.slice(0, 2).join() !== 'exportHtml,exportPdf' || !r.includes('exportDocx')) bad('HTML and PDF come first in "人に渡す"', r);
  const A3 = fs.readFileSync(path.resolve(__dirname, '../samples/資料見本.fzk'), 'utf8');
  const html = await page.evaluate(async s => { await FZ.app.loadText(s, 'h.fzk', null); window.showSaveFilePicker = undefined; let out = null; const dl = FZ.files.download; FZ.files.download = d => { out = d; }; await FZ.app.run('exportHtml'); FZ.files.download = dl; return out; }, A3);
  r = await page.evaluate(h => { const d = new DOMParser().parseFromString(h, 'text/html'); return { pages: d.querySelectorAll('section.page > svg').length, toc: [...d.querySelectorAll('nav.toc a')].map(a => a.textContent), sr: d.querySelector('.page .sr') ? d.querySelector('.page .sr').textContent : '', blob: /blob:/.test(h), page: /@page\{size:[\d.]+pt [\d.]+pt/.test(h), img: d.querySelectorAll('image').length, n: FZ.app.ed.lay.pages.length }; }, html || '');
  if (!(r.pages === r.n && r.toc.some(t => /^1\. 概況$/.test(t)) && /上期の売上高は/.test(r.sr) && !r.blob && r.page && r.img >= 1)) bad('HTML export keeps the pages as SVG with a TOC, searchable text and print size', r);
  r = await page.evaluate(async () => { let printed = 0; const p0 = window.print; window.print = () => { printed++; }; await FZ.app.run('exportPdf'); await new Promise(r => setTimeout(r, 120)); window.print = p0; return { printed, msg: document.getElementById('stMsg').textContent }; });
  if (!(r.printed === 1 && /PDF に保存/.test(r.msg))) bad('PDF goes through the print window with the hint to save as PDF', r);

  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-113b-app OK'); process.exit(fails ? 1 : 0);
})();
