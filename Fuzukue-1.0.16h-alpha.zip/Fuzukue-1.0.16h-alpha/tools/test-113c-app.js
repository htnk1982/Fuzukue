/* 1.0.13c：配置の理由（P10）・表とグラフを同じデータに（P12） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* P10：組版が採った理由（位置・太字・番号・次頁へ） */
  const fill = Array.from({ length: 30 }, (_, k) => '本文の行 ' + (k + 1) + '。');
  const SRC = ['#fzk 2', '文字数: 40', '行数: 36', '---', '[表題]理由の試し', '', '[番号1]はじめに', '本文。', '[番号2]細かい節', '[項目1]項目', '[番号1 字下げ5]固定した見出し', '[細字 番号1]細字の見出し', '[番号1]数える', '[番号1 再開]もう一度', ...fill, '[番号1]頁の終わりの見出し', '次の行。', '', '[改頁]改頁の行', ''].join('\n');
  let r = await page.evaluate(async s => { await FZ.app.loadText(s, 'w.fzk', null); const ed = FZ.app.ed; while (!ed.layoutDone) ed.continueLayout(500); const W = i => ed.lay.lineMap[i].why; const idx = t => ed.doc.lines.findIndex(l => l.segs[0].text === t);
    return { h2: W(idx('細かい節')), item: W(idx('項目')), fixed: W(idx('固定した見出し')), thin: W(idx('細字の見出し')), restart: W(idx('もう一度')), body: W(idx('本文。')), tail: W(idx('頁の終わりの見出し')), brk: W(idx('改頁の行')), title: W(idx('理由の試し')), page: ed.lay.lineMap[idx('頁の終わりの見出し')].rows[0].page }; }, SRC);
  if (!(r.h2 && /番号見出しの段 2/.test(r.h2.pos.why) && r.h2.num && r.h2.num.mark)) bad('a heading reports its position by level and its number mark', r.h2);
  if (!(r.fixed && /位置 5 を固定/.test(r.fixed.pos.why) && r.fixed.pos.own === 'indent')) bad('a fixed position is reported as this line only', r.fixed);
  if (!(r.thin && r.thin.bold && r.thin.bold.own === 'thin')) bad('thin is reported as this line only', r.thin);
  if (!(r.title && r.title.bold && /表題は太字/.test(r.title.bold.why))) bad('title bold is the layout rule', r.title);
  if (!(r.restart && r.restart.num && r.restart.num.own === 'restart')) bad('restart numbering is reported', r.restart);
  if (!(r.brk && r.brk.brk && r.brk.brk.own === 'breakBefore')) bad('page break by the line setting', r.brk);
  if (!(r.item && /箇条書きの段 1/.test(r.item.pos.why))) bad('list item position reason', r.item);
  /* 帯の欄から：この行だけ指定を外す（1 回の取消で戻る） */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const L = ed.doc.lines.findIndex(l => l.segs[0].text === '固定した見出し'); ed.setCaret({ line: L, seg: 0, off: 0 }); FZ.app.run('whyPlace'); const html = document.getElementById('sub').textContent; const btn = document.querySelector('#sub button[data-act="unIndent"]'); btn.click(); const after = ed.doc.lines[L].attrs.indent; const html2 = document.getElementById('sub').textContent; ed.undo(); const back = ed.doc.lines[L].attrs.indent; return { html, after, html2, back, guide: document.getElementById('stGuide').textContent }; });
  if (!(/行頭 6 字目：位置 5 を固定/.test(r.html) && r.after == null && /段の数だけ下げる/.test(r.html2) && r.back === 5)) bad('"this line only" removes the fixed position and the reason updates', r);
  /* 次頁へ移った理由：見出しは次の行と同じ頁（決まり）。「この行は送らない」 */
  r = await page.evaluate(() => { const ed = FZ.app.ed; FZ.app.st.form && document.querySelector('#sub button[data-act="cancel"]').click(); const g = ed.lay.geo.rows; const L = ed.doc.lines.findIndex(l => l.segs[0].text === '頁の終わりの見出し'); return { why: ed.lay.lineMap[L].why.brk, rows: g, y: ed.lay.lineMap[L].rows[0].y }; });
  if (r.why && !/次の行と同じ頁|頁の残り/.test(r.why.why)) bad('page move reason names the rule', r);
  /* 理由は印刷に出ない（印刷の頁に枠が無い） */
  r = await page.evaluate(() => { FZ.app.run('whyPlace'); FZ.app.renderForPrint(); const n = [...document.querySelectorAll('#pages .pgwrap svg')].map(s => s.querySelectorAll('.ov rect').length).reduce((a, b) => a + b, 0); document.querySelector('#sub button[data-act="cancel"]').click(); FZ.app.render(); return n; });
  if (r !== 0) bad('reason outlines are not printed', r);

  /* P12：表からグラフ → 表を直すとグラフも（1 回の取消で両方戻る） */
  const T = ['#fzk 2', '---', '売上の表。', '#表 列 0,10,20,30 様式 格子', '| 年 | 国内 | 海外 |', '| 2024 | 38 | 20 |', '| 2025 | 40 | 25 |', '', '終わり。', ''].join('\n');
  r = await page.evaluate(async s => { const { ed } = FZ.app; await FZ.app.loadText(s, 't.fzk', null); ed.setCaret({ line: 2, seg: 0, off: 0 }); FZ.app.run('chart'); const x = ed.figList()[0].fg; const tid = ed.doc.lines[1].attrs.tid; document.querySelector('#sub button[data-act="apply"]') && document.querySelector('#sub button[data-act="apply"]').click();
    return { link: x.chart.link, tid, vals: x.chart.series.map(sr => sr.name + ':' + sr.values.join(',')), linkInfo: true }; }, T);
  if (!(r.link && r.link === r.tid && r.vals.join('|') === '2024:38,20|2025:40,25')) bad('a chart made from a table is linked to it', r);
  r = await page.evaluate(() => { const { ed } = FZ.app; const L = ed.doc.lines.findIndex(l => l.segs.some(sg => sg.text === '38')); const sgi = ed.doc.lines[L].segs.findIndex(sg => sg.text === '38'); ed.setCaret({ line: L, seg: sgi, off: 0 }); ed.anchor = { line: L, seg: sgi, off: 0 }; ed.caret = { line: L, seg: sgi, off: 2, vcol: null, vrow: 0 }; ed.insertText('36');
    const v1 = ed.figList()[0].fg.chart.series[0].values.join(','); const u = ed.undoStack.length; ed.undo(); const v2 = ed.figList()[0].fg.chart.series[0].values.join(','); const cell = ed.doc.lines[L].segs[sgi].text; ed.redo(); return { v1, v2, cell }; });
  if (!(r.v1 === '36,20' && r.v2 === '38,20' && r.cell === '38')) bad('editing the table changes the chart, and one undo reverts both', r);
  /* 保存して読み直しても連動 */
  r = await page.evaluate(async () => { const { ed } = FZ.app; const s = FZ.serialize(ed.doc); await FZ.app.loadText(s, 't2.fzk', null); const L = ed.doc.lines.findIndex(l => l.segs.some(sg => sg.text === '40')); const sgi = ed.doc.lines[L].segs.findIndex(sg => sg.text === '40'); ed.anchor = { line: L, seg: sgi, off: 0 }; ed.caret = { line: L, seg: sgi, off: 2, vcol: null, vrow: 0 }; ed.insertText('41');
    return { tok: /\[表:t1\]\|/.test(s) && /連動=t1:/.test(s), v: ed.figList()[0].fg.chart.series[1].values.join(',') }; });
  if (!(r.tok && r.v === '41,25')) bad('the link survives save and reload', r);
  /* 列を足すと系列が増える。見出しの行を消しても名札は残る行へ */
  r = await page.evaluate(() => { const { ed } = FZ.app; const L = ed.doc.lines.findIndex(l => l.attrs.tid); let b = L; while (FZ.inTable(ed.doc, b + 1)) b++; ed.mutate('', () => { const nl = JSON.parse(JSON.stringify(ed.doc.lines[b])); delete nl.attrs.tid; const tx = ['2026', '45', '30']; nl.segs.forEach((sg, k) => { sg.text = tx[k] || ''; sg.marks = Array(sg.text.length).fill(0); }); ed.insertLine(b + 1, nl, true); }); const n = ed.figList()[0].fg.chart.series.length; ed.undo();
    ed.mutate('', () => ed.removeLine(L)); const tid = ed.doc.lines[L].attrs.tid; const ok = !!ed.figList()[0].fg.chart.link; ed.undo(); return { n, tid, ok }; });
  if (!(r.n === 3 && r.tid === 't1' && r.ok)) bad('adding a row adds a series; removing the first row keeps the link', r);
  /* 表を消すとグラフは値のまま、欄は「見つかりません」。連動を切る・元の表へ */
  r = await page.evaluate(() => { const { ed } = FZ.app; const v0 = ed.figList()[0].fg.chart.series[0].values.join(','); const L = ed.doc.lines.findIndex(l => l.attrs.tid); let b = L; while (FZ.inTable(ed.doc, b + 1)) b++; ed.mutate('', () => { for (let k = b; k >= L; k--) ed.removeLine(k); }); FZ.app.st.figSel = ed.figList()[0].fg.id; FZ.app.openForm('chart'); const t = document.getElementById('sub').textContent; const v1 = ed.figList()[0].fg.chart.series[0].values.join(',');
    document.querySelector('#sub button[data-act="unlink"]').click(); const link = ed.figList()[0].fg.chart.link; document.querySelector('#sub button[data-act="cancel"]').click(); ed.undo(); ed.undo(); return { v0, v1, t: /元の表が見つかりません/.test(t), link }; });
  if (!(r.v0 === r.v1 && r.t && !r.link)) bad('deleting the table keeps the chart values; unlink works', r);
  r = await page.evaluate(() => { const { ed } = FZ.app; FZ.app.st.figSel = ed.figList()[0].fg.id; FZ.app.openForm('chart'); const has = /表と連動/.test(document.getElementById('sub').textContent) && !document.querySelector('#sub button[data-act="data"]'); document.querySelector('#sub button[data-act="toTable"]').click(); return { has, caret: ed.caret.line, tid: ed.doc.lines[ed.caret.line].attrs.tid }; });
  if (!(r.has && r.tid === 't1')) bad('the chart form shows the link (no separate data) and opens the source table', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-113c-app OK'); process.exit(fails ? 1 : 0);
})();
