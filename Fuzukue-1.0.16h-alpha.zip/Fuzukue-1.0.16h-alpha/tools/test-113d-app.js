/* 1.0.13d：紙幅の使い道（P11）・版面の物差し（A-4） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  /* 目標と最小の字は原本に残る */
  let r = await page.evaluate(() => { const d = FZ.parse('#fzk 2\n文字数: 40\n行数: 30\n目標頁数: 1\n最小の字: 9\n---\n本文\n'); return { t: d.format.targetPages, m: d.format.minPt, s: /目標頁数: 1\n最小の字: 9/.test(FZ.serialize(d)) }; });
  if (!(r.t === 1 && r.m === 9 && r.s)) bad('target pages and minimum size are saved in the source', r);
  /* 2 頁にはみ出す 1 枚もの：何が紙幅を使っているか・はみ出す原因・試す案（組み直して確かめた頁数）。最小の字は破らない */
  const body = Array.from({ length: 22 }, (_, k) => '本文の段落 ' + (k + 1) + '。'.repeat(1));
  const SRC = ['#fzk 2', '用紙: A4 縦', '文字数: 40', '行数: 30', '目標頁数: 1', '最小の字: 9', '---', '[表題]一枚もの', '[番号1]現状', ...body, '#表 列 0,10,20,30,40 様式 格子', '| 工程 | 4月 | 5月 | 6月 |', '| 設計 | ○ | ○ |  |', '| 製作 |  | ○ | ○ |', '| 試験 |  |  | ○ |', '| 出荷 |  |  | ○ |', '| 保守 |  |  | ○ |', '', '[番号1]結論', '長い結論の段落です。'.repeat(18), ''].join('\n');
  r = await page.evaluate(async s => { await FZ.app.loadText(s, 'f.fzk', null); const ed = FZ.app.ed; while (!ed.layoutDone) ed.continueLayout(500); FZ.app.run('fitCheck'); await new Promise(r => setTimeout(r, 50)); const t = document.getElementById('sub').textContent; const tries = [...document.querySelectorAll('#sub button[data-act^="try"]')].map(b => b.textContent); return { pages: ed.lay.pages.length, t, tries, fs: ed.lay.geo.fs, guide: document.getElementById('stGuide').textContent }; }, SRC);
  if (!(r.pages === 2 && /1 頁はみ出し/.test(r.t) && /表「工程」が 6 行/.test(r.t) && /段落「長い結論の段落/.test(r.t))) bad('the fit form names what uses the width and the overflow', r);
  if (!(r.tries.length && r.tries.every(t => /→ 1 頁/.test(t)) && r.tries.every(t => { const m = t.match(/字 ([\d.]+) pt/); return !m || +m[1] >= 9; }))) bad('the candidates are re-laid out to 1 page and keep the minimum size', r.tries);
  /* 札：節の紙幅と頁の埋まり（印刷には出ない） */
  r = await page.evaluate(async () => { await new Promise(r => requestAnimationFrame(() => setTimeout(r, 30))); const ov = [...document.querySelectorAll('.ov text')].map(t => t.textContent); FZ.app.renderForPrint(); const pr = [...document.querySelectorAll('#pages .pgwrap svg .ov text')].length; FZ.app.render(); return { ov, pr }; });
  if (!(r.ov.some(t => /^\d+ 行・\d+%$/.test(t)) && r.ov.some(t => /^この頁 \d+%$/.test(t)) && r.pr === 0)) bad('occupancy tags are shown on screen only', r);
  /* 案を試す：1 頁になり、1 回の取消で戻る */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const b = document.querySelector('#sub button[data-act="try0"]'); const label = b.textContent; b.click(); await new Promise(r => setTimeout(r, 50)); const p1 = ed.lay.pages.length; ed.undo(); while (!ed.layoutDone) ed.continueLayout(500); const p2 = ed.lay.pages.length; return { label, p1, p2 }; });
  if (!(r.p1 === 1 && r.p2 === 2)) bad('trying a candidate fits the page and one undo reverts', r);
  /* 最小の字を大きくすると、字を小さくする案は出ない */
  r = await page.evaluate(async () => { const el = document.querySelector('#sub [name="mp"]'); el.value = '20'; el.dispatchEvent(new Event('input', { bubbles: true })); await new Promise(r => setTimeout(r, 700)); return { m: FZ.app.ed.doc.format.minPt, tries: [...document.querySelectorAll('#sub button[data-act^="try"]')].map(b => b.textContent), t: document.getElementById('sub').textContent }; });
  if (!(r.m === 20 && !r.tries.some(t => /字数を/.test(t)))) bad('the minimum size limits the candidates', r);
  await page.evaluate(() => { FZ.app.ed.undo(); document.querySelector('#sub button[data-act="cancel"]').click(); });

  /* A-4：方眼の種類（版面の枠・目盛・余白の mm）。印刷には出ない */
  r = await page.evaluate(async () => { const M = FZ.app._menu().MSEL.gridMode; M.set('frame'); await new Promise(r => setTimeout(r, 60)); const svg = document.querySelector('#pages .pgwrap svg'); const t = [...svg.querySelectorAll('.grid text')].map(x => x.textContent); M.set('off'); return t; });
  if (!(r.some(t => /^上 [\d.]+ mm$/.test(t)) && r.some(t => /40 字 × 30 行/.test(t)) && r.includes('10'))) bad('the frame grid shows margins in mm, chars × rows and rulers', r);
  /* 物差し：欄で余白を変えると仮に出し、Esc で戻る。型を選ぶ・確定は 1 回の取消 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const m0 = JSON.stringify(ed.doc.format.margins); FZ.app.run('ruler'); const grid = FZ.app.st.grid && FZ.app.st.gridMode; const el = document.querySelector('#sub [name="ml"]'); el.value = '35'; el.dispatchEvent(new Event('input', { bubbles: true })); await new Promise(r => setTimeout(r, 400)); const m1 = ed.doc.format.margins.left; const info = document.getElementById('rulerInfo').textContent;
    document.getElementById('sub').dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); const m2 = JSON.stringify(ed.doc.format.margins); const gridAfter = FZ.app.st.grid;
    FZ.app.run('ruler'); const sel = document.querySelector('#sub select[name="preset"]'); sel.value = 'kobun'; sel.dispatchEvent(new Event('change', { bubbles: true })); await new Promise(r => setTimeout(r, 50)); const f = ed.doc.format; const kob = [f.cols, f.rows, f.margins.top]; const u0 = ed.undoStack.length; document.querySelector('#sub button[data-act="ok"]').click(); ed.undo(); const back = [ed.doc.format.cols, ed.doc.format.rows];
    return { m0, grid, m1, info, m2, gridAfter, kob, back }; });
  if (!(r.grid === 'all' && r.m1 === 35 && /字 [\d.]+ pt/.test(r.info) && r.m2 === r.m0 && r.gridAfter === false)) bad('ruler previews margin changes, shows the size, Esc reverts and restores the grid', r);
  if (!(r.kob.join() === '40,30,30' && r.back.join() === '40,30')) bad('a layout preset applies and one undo reverts', r);
  /* 縁のドラッグで余白 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; FZ.app.run('ruler'); await new Promise(r => setTimeout(r, 80)); const svg = document.querySelector('#pages .pgwrap svg'); const rc = svg.getBoundingClientRect(); const g = ed.lay.geo; const sc = rc.width / g.W; const X = rc.left + g.left * sc, Y = rc.top + (g.top + (g.bodyTop + 5) * g.ch) * sc; const l0 = ed.doc.format.margins.left;
    const main = document.getElementById('main'); const pe = (t, x) => main.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: Y, bubbles: true, button: 0, pointerId: 1 })); pe('pointerdown', X); pe('pointermove', X + 20 * sc * 72 / 25.4 / 4); await new Promise(r => setTimeout(r, 80)); pe('pointerup', X); const l1 = ed.doc.format.margins.left; document.querySelector('#sub button[data-act="ok"]').click(); return { l0, l1 }; });
  if (!(r.l1 > r.l0 + 3)) bad('dragging the body edge changes the margin', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-113d-app OK'); process.exit(fails ? 1 : 0);
})();
