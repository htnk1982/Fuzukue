/* 1.0.13e：構成を試す（P13）・写した時・今・返事の三者比較（P17） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SRC = ['#fzk 2', '---', '[表題]構成の試し', '', '[番号1]背景', '背景の本文。', '[番号1]根拠', '根拠の本文。', '[番号1]結論', '結論の本文。', '[番号1]課題', '課題の本文。', '[番号1]次の一手', '次の一手の本文。', ''].join('\n');
  const heads = () => page.evaluate(() => FZ.app.ed.doc.lines.filter(l => l.attrs.style === 'num').map(l => l.segs[0].text + (l.attrs.level ? '>' + l.attrs.level : '')).join(','));
  await page.evaluate(async s => { await FZ.app.loadText(s, 'k.fzk', null); }, SRC);
  /* 試案を始めて、結論を先頭へ・根拠を背景の子に、本文を直す */
  let r = await page.evaluate(() => { const { ed } = FZ.app; FZ.app.run('trial'); const f1 = FZ.app.st.form; document.querySelector('#sub button[data-act="cancel"]').click();
    const L = t => ed.doc.lines.findIndex(l => l.segs[0].text === t); ed.moveSection(L('結論'), -1); ed.moveSection(L('結論'), -1); ed.mutate('', () => { ed.doc.lines[L('根拠')].attrs.level = 1; });
    const b = L('課題の本文。'); ed.setCaret({ line: b, seg: 0, off: 0 }); ed.insertText('直した'); return { f1, tag: document.getElementById('stFile').textContent }; });
  const trialOrder = await heads();
  if (!(r.f1 === 'trial' && /［試案］/.test(r.tag) && trialOrder === '結論,背景,根拠>1,課題,次の一手')) bad('a trial records the original and normal operations rearrange', { r, trialOrder });
  /* 元の案を見る → 試案を見る（本文の直しはどちらにも） */
  r = await page.evaluate(() => { FZ.app.run('trial'); document.querySelector('#sub button[data-act="orig"]').click(); const t = FZ.app.ed.doc.lines.map(l => l.segs[0].text).join('|'); return { t, tag: document.getElementById('stFile').textContent, info: document.getElementById('sub').textContent }; });
  let o = await heads(); if (!(o === '背景,根拠,結論,課題,次の一手' && /直した課題の本文/.test(r.t) && /［元の案］/.test(r.tag))) bad('viewing the original restores order and levels, keeping body edits', { o, r });
  await page.evaluate(() => document.querySelector('#sub button[data-act="alt"]').click()); o = await heads(); if (o !== trialOrder) bad('switching back shows the trial', o);
  /* 試案中に足した節は、直前の節の後ろに */
  await page.evaluate(() => { const { ed } = FZ.app; const L = ed.doc.lines.findIndex(l => l.segs[0].text === '背景の本文。'); ed.mutate('', () => { const n = FZ.newLine(); n.segs[0].text = '補足'; n.segs[0].marks = [0, 0]; n.attrs.style = 'num'; n.attrs.level = 0; ed.insertLine(L + 1, n); }); document.querySelector('#sub button[data-act="orig"]').click(); });
  o = await heads(); if (o !== '背景,補足,根拠,結論,課題,次の一手') bad('a section added in the trial stays after its preceding section in the original', o);
  /* 捨てる（1 回の取消で試案に）・採る */
  await page.evaluate(() => document.querySelector('#sub button[data-act="alt"]').click());
  r = await page.evaluate(() => { const { ed } = FZ.app; document.querySelector('#sub button[data-act="discard"]').click(); const a = ed.doc.lines.filter(l => l.attrs.style === 'num').map(l => l.segs[0].text).join(','); const t = FZ.app_trial(); ed.undo(); const b = ed.doc.lines.filter(l => l.attrs.style === 'num').map(l => l.segs[0].text).join(','); return { a, t, b }; });
  if (!(r.a === '背景,補足,根拠,結論,課題,次の一手' && r.t === null && r.b.startsWith('結論'))) bad('discarding goes back to the original in one undoable step', r);
  r = await page.evaluate(() => { FZ.app.run('trial'); document.querySelector('#sub button[data-act="orig"]').click(); document.querySelector('#sub button[data-act="adopt"]').click(); return { t: FZ.app_trial(), first: FZ.app.ed.doc.lines.find(l => l.attrs.style === 'num').segs[0].text }; });
  if (!(r.t === null && r.first === '結論')) bad('adopting from the original view applies the trial', r);

  /* P17：写した後で自分が「24日」を「22日」に直す。AI は旧い「24日」のまま、別の所を直して返す → 自分の直しは候補に出ない */
  const S2 = ['#fzk 2', '---', '[表題]予定', '', '[番号1]日程', '提出は24日。', '確認は25日。', '会議は26日。', ''].join('\n');
  r = await page.evaluate(async s => { const { ed } = FZ.app; navigator.clipboard.writeText = async t => { window.__md = t; }; await FZ.app.loadText(s, 'p.fzk', null); ed.setCaret({ line: 3, seg: 0, off: 0 }); await FZ.app.run('aiCopySec');
    const L = ed.doc.lines.findIndex(l => l.segs[0].text === '提出は24日。'); ed.mutate('', () => { const sg = ed.doc.lines[L].segs[0]; sg.text = '提出は22日。'; });
    const md = window.__md.replace('確認は25日。', '確認は27日。');
    FZ.app.openForm('aiback'); document.querySelector('#sub textarea[name="md"]').value = md; document.querySelector('#sub button[data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 50));
    const S = FZ.app.st.aiBack; const t = document.getElementById('sub').textContent; return { n: S.hunks.length, who: S.hunks.map(h => h.who), selfN: S.selfN, t, base: !!S.base }; }, S2);
  if (!(r.base && r.n === 1 && r.who[0] === 'ai' && r.selfN === 1 && /三者比較/.test(r.t) && /AI だけ/.test(r.t))) bad('own edits made while the AI was working are kept (three-way)', r);
  r = await page.evaluate(() => { const s = document.querySelector('#sub'); const b = document.querySelector('#sub button[data-act="take"]'); /* 1.0.15g：帯の箱は 2 段の F キーの高さまで伸びるので、中身の高さ（子の上端〜下端）で測る */ const R = [...s.querySelectorAll('button,select,input,.ch,.lbl,label')].map(e => e.getBoundingClientRect()).filter(q => q.height > 0); return { h: Math.max(...R.map(q => q.bottom)) - Math.min(...R.map(q => q.top)), bh: b ? b.getBoundingClientRect().height : 0 }; }); if (!(r.bh && r.h <= r.bh * 2 + 14)) bad('the three-way band still fits 2 rows', r);
  r = await page.evaluate(async () => { document.querySelector('#sub button[data-act="all"]').click(); await new Promise(r => setTimeout(r, 30)); const { ed } = FZ.app; return ed.doc.lines.map(l => l.segs[0].text).filter(t => /日。$/.test(t)); });
  if (r.join('|') !== '提出は22日。|確認は27日。|会議は26日。') bad('taking all AI changes keeps my 22日', r);
  /* 両方で変えた所は「両方で変更」 */
  r = await page.evaluate(async s => { const { ed } = FZ.app; if (FZ.app.st.form) document.querySelector('#sub button[data-act="cancel"]').click(); await FZ.app.loadText(s, 'q.fzk', null); navigator.clipboard.writeText = async t => { window.__md = t; }; ed.setCaret({ line: 3, seg: 0, off: 0 }); await FZ.app.run('aiCopySec'); const L = ed.doc.lines.findIndex(l => l.segs[0].text === '確認は25日。'); ed.mutate('', () => { ed.doc.lines[L].segs[0].text = '確認は28日。'; });
    FZ.app.openForm('aiback'); document.querySelector('#sub textarea[name="md"]').value = window.__md.replace('確認は25日。', '確認は29日。'); document.querySelector('#sub button[data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 50)); const S = FZ.app.st.aiBack; return { who: S.hunks.map(h => h.who), t: document.getElementById('sub').textContent }; }, S2);
  if (!(r.who.join() === 'both' && /両方で変更/.test(r.t))) bad('a line changed by both is marked "both"', r);
  /* 写した範囲以外と比べると二者比較 */
  r = await page.evaluate(async s => { const { ed } = FZ.app; FZ.app.st.form && document.querySelector('#sub button[data-act="cancel"]').click(); await FZ.app.loadText(s, 'r.fzk', null); FZ.app.st.aiScope = null; FZ.app.openForm('aiback'); document.querySelector('#sub textarea[name="md"]').value = '## 1. 日程\n\n提出は24日。\n\n確認は30日。\n\n会議は26日。\n'; document.querySelector('#sub button[data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 50)); return document.getElementById('sub').textContent; }, S2);
  if (!/二者比較/.test(r)) bad('without the copied text, it says two-way', r);
  /* ストーリー（空・雨・傘）の 4 型：見出しは淡網・中央、下に「・」の行、セルごとに空・雨・傘の書き方 */
  r = await page.evaluate(async () => { const want = { st_cause: '発生している問題|原因|解決策の提案', st_shift: '発生している現象|今後の影響|転換の提案', st_change: '変化|影響|変化適応の提案', st_chance: '現状|改善機会|実現策の提案' }; const out = {};
    for (const [id, h] of Object.entries(want)) { const e = FZ.fwById(id); const L = FZ.fwBuild(e, { cols: 60 }); out[id] = { cat: e.cat, heads: e.parts.map(p => p.n).join('|') === h, tab: L.some(l => /見出し淡/.test(l)), center: L.some(l => /^\[列揃え中中中\]\|/.test(l)), bul: L.includes('| ・ | ・ | ・ |'), guide: e.parts.map(p => p.g.slice(0, 1)).join('') }; }
    await FZ.app.loadText('#fzk 2\n---\n[表題]報告\n\n', 's.fzk', null); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.insertFw(FZ.fwById('st_chance')); await new Promise(r => setTimeout(r, 100)); const ed = FZ.app.ed; const Lb = ed.doc.lines.findIndex(l => l.segs.some(sg => sg.text === '・')); ed.setCaret({ line: Lb, seg: 2, off: 1 }); FZ.app.render(); await new Promise(r => setTimeout(r, 100));
    const on = document.querySelector('#fwguide .on, #fwguide .cur, #fwguide [aria-current]'); return { out, cats: FZ.FW_CATS.map(c => c[1]), on: on ? on.textContent : document.getElementById('fwguide') ? document.getElementById('fwguide').innerText.slice(0, 200) : '' }; });
  if (!(r.cats.includes('ストーリー（空・雨・傘）') && Object.values(r.out).every(x => x.cat === 'story' && x.heads && x.tab && x.center && x.bul && x.guide === '空雨傘'))) bad('the story kind has the four frames with the given headers', r);
  if (!/実現策の提案/.test(r.on) || !/傘/.test(r.on)) bad('the guide shows the umbrella sentence for the third cell', r.on);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : 'test-113e-app OK'); process.exit(fails ? 1 : 0);
})();
