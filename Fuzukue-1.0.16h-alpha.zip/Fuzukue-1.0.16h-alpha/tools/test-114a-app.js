/* 1.0.14a：プ譜（字下げの木を左右逆転した紙面・役・枠・資源と制約・点検・AI の答えの取り込み・指示文） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(() => { window.__clip = ''; navigator.clipboard.writeText = async t => { window.__clip = t; }; });
  const SRC = ['#fzk 2', '---', '[番号1]需給調整の進め方',
    '[番号2 プ譜]プ譜：会議の週次化',
    '[項目1]週次の数量をその場で決められる状態をつくる（2027年3月）',
    '[項目2]営業・生産・物流が同じ数字で毎週の数量を確定している',
    '[項目3 プ譜枠]需要の数字を、信じて使えるものにする',
    '[項目4]販売予測の誤差が、品目別に毎週見えている',
    '[項目5]成果物：誤差の週報',
    '[項目5]予測と実績の差を毎週集計して配る（需給T・11月）',
    '[項目6]対象品目の抽出',
    '[項目4]営業が予測を直すとき、理由を添えて出している〔推測〕',
    '[項目5]入力様式に修正理由の欄を足す（企画・11月）',
    '[項目3]数量の変更が、翌日には生産計画に届いている',
    '[項目4]変更の連絡を画面に一本化する',
    '[項目1 プ譜資源]資源と制約（廟算八要素）',
    '[項目2]ひと：需給T 3 名', '[項目2]お金：追加の予算なし', '[項目2]時間：3 月まで', '[項目2]クオリティ：', '[項目2]商流・座組：営業本部が主管', '[項目2]環境：基幹の更新', '[項目2]ライバル：原価低減 PJ', '[項目2]外敵：諦め',
    '', '次の節の本文。', ''].join('\n');
  await page.evaluate(async s => { await FZ.app.loadText(s, 'p.fzk', null); }, SRC); await page.waitForTimeout(200);
  const T = t => page.evaluate(t => FZ.app.ed.doc.lines.findIndex(l => l.segs.map(s => s.text).join('').startsWith(t)), t);

  /* 原本：印の往復 */
  let r = await page.evaluate(() => { const s = FZ.serialize(FZ.app.ed.doc); const d = FZ.parse(s); return { s: s.split('\n').filter(l => /プ譜/.test(l)), same: FZ.serialize(d) === s }; });
  if (!(r.same && r.s.some(l => /^\[番号2 プ譜\]/.test(l)) && r.s.some(l => /プ譜取組\]需要/.test(l)) && r.s.some(l => /プ譜資源\]資源と制約/.test(l)))) bad('the marks round-trip in the .fzk text', r);

  /* 木：役・枠は深さに数えない・成果物と続きは箱の続き・資源と制約は木の外 */
  r = await page.evaluate(() => { const B = FZ.pufuBlocks(FZ.app.ed.doc)[0]; const role = q => FZ.pufuRoleOf(B, B.map.get(q)); const L = FZ.app.ed.doc.lines; const at = t => L.findIndex(l => l.segs[0].text.startsWith(t));
    return { roots: B.roots.length, frames: B.frames.length, res: B.res && B.res.items.length, end: B.end, next: L[B.end] && L[B.end].segs[0].text, r: ['週次の数量', '営業・生産', '需要の数字', '販売予測', '成果物', '予測と実績', '対象品目', '数量の変更', '変更の連絡', 'ひと'].map(t => role(at(t))) }; });
  if (!(r.roots === 1 && r.frames === 1 && r.res === 8 && r.next === '' && r.r.join(',') === '獲得目標,勝利条件,取組,中間目的,成果物,施策,段取り,中間目的,施策,資源と制約')) bad('roles come from depth; frames are not counted; the output line continues the box', r);

  /* 紙面：字の頭は左で揃え、右端は深さごとに 3 字下げ。役の札・枠の太罫・背骨の矢印・〔推測〕は点線・資源は 2 列 */
  r = await page.evaluate(() => { const ed = FZ.app.ed, lay = ed.lay, L = ed.doc.lines; const at = t => L.findIndex(l => l.segs[0].text.startsWith(t)); const row = q => lay.lineMap[q].segs[0].rows[0];
    const qs = ['週次の数量', '営業・生産', '販売予測', '予測と実績', '対象品目'].map(at); const pg = lay.pages[0];
    const rt = q => pg.vrules.filter(v => v.deco && v.from === q && /:br$/.test(v.id)).map(v => v.col)[0];
    const tags = pg.glyphs.filter(g => g.pufuTag).map(g => g.text).join('');
    const arrows = pg.vrules.filter(v => v.kind === 'arrow' && v.headTop && v.deco).length;
    const thick = pg.vrules.filter(v => v.deco && v.kind === 'thick').length;
    const guess = pg.hrules.some(h => h.deco && h.kind === 'dotted' && h.line === at('営業が予測'));
    const hi = at('ひと'), mo = at('お金'); const rh = row(hi), rm = row(mo);
    const out = at('成果物'); const outTop = pg.hrules.some(h => h.deco && h.line === out && /:bt$/.test(h.id));
    return { left: qs.map(q => row(q).startCol), right: qs.map(rt), tags: tags.slice(0, 20), arrows, thick: thick > 4, guess, pair: rh.y === rm.y && rm.startCol > rh.startCol, outTop, marker: pg.glyphs.some(g => g.marker && g.line >= qs[0] && g.line <= qs[4]), pages: lay.pages.length }; });
  if (!(new Set(r.left).size === 1 && r.right.every((x, k) => k === 0 || Math.abs(r.right[k - 1] - x - 3) < 1e-6) && /^獲得目標勝利条件取組1中間目的施策段取り/.test(r.tags) && r.arrows >= 3 && r.thick && r.guess && r.pair && !r.outTop && !r.marker)) bad('the paper draws the mirrored indented tree', r);

  /* 1.0.14c 隙間（獲得目標と勝利条件・勝利条件と取組・取組と次）と、空きを通る背骨（矢じりは親の箱の下）。札の濃さ（中間目的＝薄・太字、施策＝淡、段取り＝無地） */
  r = await page.evaluate(() => { const ed = FZ.app.ed, lay = ed.lay, L = ed.doc.lines; const at = t => L.findIndex(l => l.segs[0].text.startsWith(t)); const rows = q => lay.lineMap[q].rows; const end = q => { const rs = rows(q); const r = rs[rs.length - 1]; return r.y + r.h; };
    const g = (a, b) => rows(b)[0].y - end(a); const pg = lay.pages[0]; const win = at('営業・生産'), fr = at('需要の数字'), after = at('数量の変更');
    const ext = pg.vrules.filter(v => v.deco && /:sg/.test(v.id)); const headAtGap = ext.some(v => v.kind === 'arrow' && v.headTop && Math.abs(v.y1 - end(at('週次の数量'))) < 1e-6);
    const fills = q => pg.fills.filter(f => f.deco && f.from === q && /:tf$/.test(f.id)).map(f => f.shade).join(''); const bold = q => pg.glyphs.filter(x => x.pufuTag && x.line === q).every(x => x.marks & FZ.M.BOLD);
    return { gWin: g(at('週次の数量'), win), gFr: g(win, fr), gAfter: g(at('入力様式'), after), gInner: g(fr, at('販売予測')), gMid: g(at('対象品目'), at('営業が予測')), side: pg.vrules.filter(v => v.deco && /:g[lr]/.test(v.id) && v.kind === 'thick').length, ext: ext.length, headAtGap, mid: fills(at('販売予測')), mea: fills(at('予測と実績')), det: fills(at('対象品目')), bMid: bold(at('販売予測')), bMea: bold(at('予測と実績')) }; });
  if (!(r.gWin === 1 && r.gFr === 1 && r.gAfter === 1 && r.gInner === 0 && r.gMid === 1 && r.side === 2 && r.ext >= 3 && r.headAtGap && r.mid === 'gray' && r.mea === 'light' && r.det === '' && r.bMid && !r.bMea)) bad('gaps between the goal, the win condition, each 取組 and each purpose group; the spine and the 取組 sides cross the gap; the tag tones step down', r);

  /* 印刷に出る（deco の罫・網） */
  r = await page.evaluate(() => { const svg = FZ.renderPage(FZ.app.ed.lay, 0, { print: true }); const s = typeof svg === 'string' ? svg : svg.outerHTML || ''; return { len: s.length, tag: /獲得目標/.test(s) }; }).catch(e => ({ err: String(e) }));
  if (r.err === undefined && !r.tag) bad('the tags are printed', r);

  /* 解説：役ごとの書き方。カーソルのある行の役に印 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed, L = ed.doc.lines; const at = t => L.findIndex(l => l.segs[0].text.startsWith(t)); ed.setCaret({ line: at('入力様式'), seg: 0, off: 1 }); FZ.app.render(); await new Promise(r => setTimeout(r, 120)); const g = document.getElementById('fwguide'); const on = g.querySelector('.fwg-p .on'); ed.setCaret({ line: at('成果物'), seg: 0, off: 0 }); FZ.app.render(); await new Promise(r => setTimeout(r, 120)); const on2 = g.querySelector('.fwg-p .on'); return { name: g.querySelector('.fwg-h b') && g.querySelector('.fwg-h b').textContent, on: on && on.querySelector('b').textContent, on2: on2 && on2.querySelector('b').textContent }; });
  if (!(r.name === 'プ譜' && r.on === '施策' && r.on2 === '成果物')) bad('the guide shows the writing rule of the role at the caret', r);

  /* ツリー：役の名前を印の代わりに */
  r = await page.evaluate(async () => { document.getElementById('viewSel').value = 'split'; document.getElementById('viewSel').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 300)); const t = document.getElementById('tree') ? document.getElementById('tree').textContent : document.body.textContent; document.getElementById('viewSel').value = 'paper'; document.getElementById('viewSel').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 150)); return { w: /【勝利条件】/.test(t), f: /【取組1】/.test(t) }; });
  if (!(r.w && r.f)) bad('the tree shows the role names', r);

  /* 点検：中間目的が作業・中間目的 1 つの勝利条件・担当期日・〔推測〕・空の資源 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed, L = ed.doc.lines; const at = t => L.findIndex(l => l.segs[0].text.startsWith(t)); const q = at('数量の変更'); ed.mutate('', () => { L[q].segs[0].text = '生産計画への連絡を一本化する'; L[q].segs[0].marks = FZ.marksFor(L[q].segs[0].text, 0); });
    const lint = FZ.pufuLint(ed.doc).map(x => x.level + ':' + x.msg); FZ.app.run('pufuCheck'); await new Promise(r => setTimeout(r, 120)); /* 1.0.16h プ譜の点検は診断の欄の「プ譜」に */ const info = (FZ.app.st.side === 'health' && FZ.app.st.healthOpen === 'pf_warn' && [...document.querySelectorAll('#sideBody .hsec')].some(e => e.textContent === 'プ譜')) ? '1/' : ''; const line = ed.caret.line; FZ.app.run('health'); ed.undo(); return { lint, info, line }; });
  const has = re => r.lint.some(x => re.test(x));
  if (!(has(/^warn:中間目的は状態で書く/) && has(/^info:〔推測〕/) && has(/^info:施策の担当・期日/) && has(/^info:資源と制約の「クオリティ」が空/) && !has(/^warn:中間目的が 1 つだけ/) && /1\//.test(r.info))) bad('the check finds task-like purposes, guesses, missing owner/date, empty resources', r);

  /* 枠で囲む／外す（1 回の取消） */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const at = t => ed.doc.lines.findIndex(l => l.segs[0].text.startsWith(t)); const nf = () => FZ.pufuBlocks(ed.doc)[0].frames.length;
    ed.setCaret({ line: at('数量の変更'), seg: 0, off: 0 }); FZ.app.run('pufuFrame'); await new Promise(r => setTimeout(r, 50)); const B = FZ.pufuBlocks(ed.doc)[0]; const role = FZ.pufuRoleOf(B, B.map.get(at('数量の変更'))); const a = nf(); const fl = ed.caret.line; /* 1.0.16h 取組の名前は空（薄い手引き）。囲むと字の位置は新しい取組の行 */
    const blank = !ed.doc.lines[fl].segs.map(g => g.text).join('') && !!ed.doc.lines[fl].attrs.pufuFrame; ed.setCaret({ line: fl, seg: 0, off: 0 }); FZ.app.run('pufuFrame'); await new Promise(r => setTimeout(r, 50)); const b = nf(); const role2 = FZ.pufuRoleOf(FZ.pufuBlocks(ed.doc)[0], FZ.pufuBlocks(ed.doc)[0].map.get(at('数量の変更')));
    ed.undo(); const c = nf(); ed.undo(); const d = nf(); return { a, role, b, role2, c, d, blank }; });
  if (!(r.blank && r.a === 2 && r.role === '中間目的' && r.b === 1 && r.role2 === '中間目的' && r.c === 2 && r.d === 1)) bad('wrapping a purpose in a frame keeps its role; unwrapping restores; each is one undo', r);

  /* 型を入れる・資源と制約は 1 つ */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; await FZ.app.loadText('#fzk 2\n---\n[番号1]企画\n\n', 'n.fzk', null); ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('pufuNew'); await new Promise(r => setTimeout(r, 60));
    const B = FZ.pufuBlocks(ed.doc)[0]; const n1 = ed.doc.lines.length; FZ.app.run('pufuRes'); const n2 = ed.doc.lines.length; return { ok: !!B && B.roots.length === 1 && B.frames.length === 1 && B.res && B.res.items.length === 8, caret: FZ.pufuRoleOf(B, B.map.get(ed.caret.line)), n1, n2, head: ed.doc.lines[1].attrs.style + ed.doc.lines[1].attrs.level, after: ed.doc.lines[B.end] && ed.doc.lines[B.end].segs[0].text }; });
  if (!(r.ok && r.n1 === r.n2 && r.head === 'num1' && r.after === '')) bad('the template inserts a whole プ譜 under the heading, ending with a blank line', r);

  /* 指示文を写す：本文はこの節 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; await FZ.app.loadText('#fzk 2\n---\n[番号1]基幹更新\n来年度に基幹システムを更新する。需給の業務は止めない。\n', 'q.fzk', null); ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('pufuPrompt'); await new Promise(r => setTimeout(r, 50)); document.querySelector('#sub button[data-act="go"]').click(); await new Promise(r => setTimeout(r, 80)); const c = window.__clip; return { has: /プ譜」を組み立てる編集者/.test(c) && /〈本文〉\n[\s\S]*需給の業務は止めない/.test(c), date: /〈日付〉\d{4}-\d\d-\d\d/.test(c), left: /\{\{/.test(c) }; });
  if (!(r.has && r.date && !r.left)) bad('the prompt is copied with the section as the body', r);

  /* AI の答えを取り込む：役の名前を外し、枠は印に、成果物は残す、問いと注は付箋 */
  const ANS = ['```markdown', '# プ譜：基幹更新の段取り（局面 1・2026-11-08）', '- 獲得目標：来年度の基幹更新を、需給の業務を止めずに終える', '  - 勝利条件：切り替えの週も、数量が毎週決まっている〔推測〕', '    - 枠：新しい画面で迷わず仕事ができるようにする', '      - 中間目的：全員が新しい画面で週次の作業をできている', '        - 成果物：操作の手順書', '        - 施策：試行環境で 2 回通す（需給T・1月）', '      - 中間目的：困った時に聞ける窓口が決まっている', '        - 施策：窓口を 1 つにする（IT）', '## 資源と制約', '- ひと：需給T 3 名', '- お金：記載なし', '## 読み取れなかったこと', '1. 切り替えの日程は決まっているか', '## 注', '- 手順書は成果物とした', '```'].join('\n');
  r = await page.evaluate(async md => { const ed = FZ.app.ed; await FZ.app.loadText('#fzk 2\n---\n[番号1]企画\n\n', 'i.fzk', null); ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('pufuImport'); await new Promise(r => setTimeout(r, 50)); document.querySelector('#sub textarea[name="md"]').value = md; document.querySelector('#sub button[data-act="go"]').click(); await new Promise(r => setTimeout(r, 100));
    const B = FZ.pufuBlocks(ed.doc)[0]; const L = ed.doc.lines; const role = q => FZ.pufuRoleOf(B, B.map.get(q)); const at = t => L.findIndex(l => l.segs[0].text.startsWith(t));
    return { head: L[B.head].segs[0].text, r: ['来年度', '切り替え', '新しい画面', '全員が', '成果物：操作', '試行環境', '困った時'].map(t => role(at(t))), res: B.res && B.res.items.length, notes: (ed.doc.notes || []).map(n => n.text), noteOn: (L[B.head].attrs.notes || []).length, form: FZ.app.st.form, one: (() => { ed.undo(); return FZ.pufuBlocks(ed.doc).length; })() }; }, ANS);
  if (!(r.head === 'プ譜：基幹更新の段取り（局面 1・2026-11-08）' && r.r.join(',') === '獲得目標,勝利条件,取組,中間目的,成果物,施策,中間目的' && r.res === 2 && r.noteOn === 1 && /切り替えの日程/.test(r.notes[0] || '') && /手順書は成果物/.test(r.notes[0] || '') && !r.form && r.one === 0)) bad('the AI answer is imported as a プ譜 with roles, a frame, resources and a note; one undo', r);

  /* 指示文の本体は docs の写しと同じ */
  const fs = require('fs'); const md = fs.readFileSync(path.resolve(__dirname, '../docs/プロンプト_文章からプ譜を起こす.md'), 'utf8'); r = await page.evaluate(() => FZ.PUFU_PROMPT);
  if (!md.includes(r)) bad('docs/プロンプト_文章からプ譜を起こす.md carries the same prompt (run the build)');

  /* 変換の記録：Word・PowerPoint・テキスト・Markdown にプ譜の行 */
  r = await page.evaluate(async s => { await FZ.app.loadText(s, 'p.fzk', null); const d = FZ.app.ed.doc; return ['docx', 'pptx', 'txt', 'md'].map(t => FZ.convAudit(d, t).items.some(it => /プ譜/.test(it.what) && it.lines.length > 5)); }, SRC);
  if (!r.every(Boolean)) bad('the conversion log names the プ譜 lines for Word, PowerPoint, text and Markdown', r);

  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114a-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
