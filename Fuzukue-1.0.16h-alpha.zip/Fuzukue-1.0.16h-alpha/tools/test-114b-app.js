/* 1.0.14b：プ譜を Word・PowerPoint に「見た目のまま・直せる図形」で書き出す（役の札・字の箱・枠・矢印の線のグループ） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const BODY = ['[番号1]需給調整の進め方',
    '[番号2 プ譜]プ譜：会議の週次化',
    '[項目1]週次の数量をその場で決められる状態をつくる（2027年3月）',
    '[項目2]営業・生産・物流が同じ数字で毎週の数量を確定している',
    '[項目3 プ譜枠]需要の数字を、信じて使えるものにする',
    '[項目4]販売予測の誤差が、品目別に毎週見えている',
    '[項目5]成果物：誤差の週報',
    '[項目5]予測と実績の差を毎週集計して配る（需給T・11月）',
    '[項目4]営業が予測を直すとき、理由を添えて出している〔推測〕',
    '[項目5]入力様式に修正理由の欄を足す（企画・11月）',
    '[項目3]数量の変更が、翌日には生産計画に届いている',
    '[項目4]変更の連絡を画面に一本化する（IT・1月）',
    '[項目1 プ譜資源]資源と制約（廟算八要素）',
    '[項目2]ひと：需給T 3 名', '[項目2]お金：追加の予算なし',
    '', '次の節の本文。', ''];
  const SRC = ['#fzk 2', '---', ...BODY].join('\n');
  const r = await page.evaluate(async ({ SRC, BODY }) => {
    const parse = u8 => { const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength); const files = {}; let p = 0; const td = new TextDecoder();
      while (p + 30 <= u8.length && dv.getUint32(p, true) === 0x04034b50) { const n = dv.getUint16(p + 26, true), x = dv.getUint16(p + 28, true), sz = dv.getUint32(p + 18, true); const name = td.decode(u8.subarray(p + 30, p + 30 + n)); files[name] = td.decode(u8.subarray(p + 30 + n + x, p + 30 + n + x + sz)); p += 30 + n + x + sz; } return files; };
    const wellFormed = files => Object.entries(files).filter(([n]) => /\.(xml|rels)$/.test(n)).filter(([, t]) => new DOMParser().parseFromString(t, 'application/xml').querySelector('parsererror')).map(([n]) => n);
    const count = (s, t) => s.split(t).length - 1;
    const out = {};
    const doc = FZ.parse(SRC); const lay = FZ.layout(doc); const S = FZ.pufuShapes(doc, lay);
    out.shapes = { blocks: S.length, pages: S[0].pages.length, rects: S[0].pages[0].rects.length, frames: S[0].pages[0].frames.length, lines: S[0].pages[0].lines.length, heads: S[0].pages[0].lines.filter(l => l.head).length, tags: S[0].pages[0].rects.filter(x => x.role === 'tag' && x.paras.length).map(x => x.paras[0].text).join(',') };
    /* Word（文書の流れ） */
    const dx = parse(FZ.toDocx(doc)); const D = dx['word/document.xml'];
    out.docx = { bad: wellFormed(dx), groups: count(D, '<wpg:wgp>'), named: /name="プ譜"/.test(D), inBox: count(D, 'preserve">販売予測の誤差'), boxText: /<w:txbxContent>(?:(?!<\/w:txbxContent>).)*販売予測の誤差/.test(D), out: /<w:txbxContent>(?:(?!<\/w:txbxContent>).)*成果物：誤差の週報/.test(D), arrows: count(D, '<a:tailEnd type="triangle"'), white: /<w:color w:val="FFFFFF"\/>(?:(?!<\/w:r>).)*獲得目標/.test(D), dash: count(D, 'sysDash') >= 1, head: /プ譜：会議の週次化/.test(D), after: /次の節の本文。/.test(D), fill: /<a:srgbClr val="4D4D4D"\/>/.test(D) };
    /* PowerPoint */
    const px = parse(FZ.toPptx(doc)); const P1 = px['ppt/slides/slide1.xml'];
    const grp = (P1.match(/<p:grpSp>(?:(?!<\/p:grpSp>).)*<\/p:grpSp>/) || [''])[0];
    out.pptx = { bad: wellFormed(px), groups: count(P1, 'name="プ譜"'), once: count(P1, '<a:t>販売予測の誤差'), inGroup: /販売予測の誤差/.test(grp), arrows: count(grp, '<a:tailEnd'), cxn: count(P1, '<p:cxnSp>'), cxnInGroup: count(grp, '<p:cxnSp>'), white: /<a:solidFill><a:srgbClr val="FFFFFF"\/><\/a:solidFill>(?:(?!<\/a:r>).)*<\/a:rPr><a:t>獲得目標/.test(grp), autofit: /normAutofit/.test(grp), after: /次の節の本文。/.test(P1) };
    /* 長いプ譜は頁ごとのグループ（Word は頁ごとの図、PowerPoint は各スライドに） */
    const many = ['#fzk 2', '---', '[番号1 プ譜]プ譜：長い例', '[項目1]獲得目標の例', '[項目2]勝利条件の例'];
    for (let k = 0; k < 14; k++) { many.push(`[項目3]中間目的 ${k + 1} が整っている`); many.push(`[項目4]施策 ${k + 1}-1 を行う（担当・${(k % 12) + 1}月）`); many.push(`[項目4]施策 ${k + 1}-2 を行う（担当・${(k % 12) + 1}月）`); }
    many.push('', '後ろの本文。', '');
    const d2 = FZ.parse(many.join('\n')); const lay2 = FZ.layout(d2); const S2 = FZ.pufuShapes(d2, lay2);
    const dx2 = parse(FZ.toDocx(d2))['word/document.xml']; const px2 = parse(FZ.toPptx(d2)); const slides = Object.keys(px2).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n)).map(n => px2[n]);
    out.long = { pages: lay2.pages.length, parts: S2[0].pages.length, docxGroups: count(dx2, '<wpg:wgp>'), slideGroups: slides.filter(s => /name="プ譜"/.test(s)).length, all: (() => { const t = slides.join(''); for (let k = 1; k <= 14; k++) if (!t.includes(`施策 ${k}-2 を行う`)) return k; return 0; })() };
    /* 資料（紙面のまま）の Word は PowerPoint の図形を写す */
    FZ.app.run('newSlide'); await new Promise(r => setTimeout(r, 150)); const head = FZ.serialize(FZ.app.ed.doc).split('\n---\n')[0]; const d3 = FZ.parse(head + '\n---\n' + BODY.join('\n'));
    const dx3 = parse(FZ.toDocx(d3)); const D3 = dx3['word/document.xml']; const dxf = parse(FZ.toDocx(d3, { flow: true }))['word/document.xml'];
    out.slide = { kind: d3.format.kind, bad: wellFormed(dx3), group: /<wpg:wgp>/.test(D3), text: /<w:txbxContent>(?:(?!<\/w:txbxContent>).)*販売予測の誤差/.test(D3), arrows: count(D3, 'tailEnd') >= 3, flow: count(dxf, '<wpg:wgp>') >= 1 && /<w:txbxContent>(?:(?!<\/w:txbxContent>).)*販売予測の誤差/.test(dxf) };
    /* 変換の記録：Word・PowerPoint は図形で入ると書く */
    out.log = ['docx', 'pptx'].map(t => FZ.convAudit(doc, t).items.some(it => /プ譜は図形のグループ/.test(it.what)));
    return out; }, { SRC, BODY });
  const s = r.shapes; if (!(s.blocks === 1 && s.pages === 1 && s.frames === 1 && s.heads >= 3 && /^獲得目標,勝利条件,取組1,中間目的,施策/.test(s.tags))) bad('the shapes follow the paper layout', s);
  const d = r.docx; if (!(!d.bad.length && d.groups === 1 && d.named && d.inBox === 1 && d.boxText && d.out && d.arrows >= 3 && d.white && d.dash && d.head && d.after && d.fill)) bad('Word gets one editable shape group: text boxes, white tags, dotted guess, arrows', d);
  const p = r.pptx; if (!(!p.bad.length && p.groups === 1 && p.once === 1 && p.inGroup && p.arrows >= 3 && p.cxn === p.cxnInGroup && p.white && p.autofit && p.after)) bad('PowerPoint gets one group per slide instead of fragments', p);
  const l = r.long; if (!(l.pages >= 2 && l.parts === l.pages && l.docxGroups === l.parts && l.slideGroups === l.parts && l.all === 0)) bad('a long プ譜 is split into one group per page', l);
  const sl = r.slide; if (!(sl.kind === 'slide' && !sl.bad.length && sl.group && sl.text && sl.arrows && sl.flow)) bad('the slide format Word (paper as is, and flow) carries the groups', sl);
  if (!r.log.every(Boolean)) bad('the conversion log says Word and PowerPoint get shape groups', r.log);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114b-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
