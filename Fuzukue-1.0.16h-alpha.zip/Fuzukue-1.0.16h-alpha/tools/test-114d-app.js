/* 1.0.14d：プ譜と AI の往復（役の名前付きで写す・点検と次の局面の指示文・答えを今のプ譜と三者比較で取り込む・答えの注記） */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(() => { window.__clip = ''; navigator.clipboard.writeText = async t => { window.__clip = t; }; });
  const SRC = ['#fzk 2', '---', '[番号1]需給調整の進め方', '[番号2 プ譜]プ譜：会議の週次化（局面 1）',
    '[項目1]週次の数量をその場で決められる状態をつくる', '[項目2]営業・生産・物流が同じ数字で毎週の数量を確定している',
    '[項目3 プ譜取組]需要の数字を、信じて使えるものにする', '[項目4]販売予測の誤差が、品目別に毎週見えている', '[項目5]成果物：誤差の週報', '[項目5]予測と実績の差を毎週集計して配る（需給T・11月）', '[項目6]対象品目の抽出',
    '[項目4]営業が予測を直すとき、理由を添えて出している', '集計は需給T が月曜に回す。', '[項目5]入力様式に修正理由の欄を足す（企画・11月）',
    '[項目3]数量の変更が、翌日には生産計画に届いている', '[項目4]変更の連絡を画面に一本化する（IT・1月）',
    '[項目1 プ譜資源]資源と制約（廟算八要素）', '[項目2]ひと：需給T 3 名', '[項目2]お金：追加の予算なし', '', '次の節の本文。', ''].join('\n');
  await page.evaluate(async s => { await FZ.app.loadText(s, 'p.fzk', null); }, SRC); await page.waitForTimeout(150);

  /* 役の名前付きの形：段は字下げ、取組・成果物・補足、資源と制約。読み戻すと同じ木 */
  let r = await page.evaluate(() => { const d = FZ.app.ed.doc; const B = FZ.pufuBlocks(d)[0]; const md = FZ.pufuToMd(d, B); const P = FZ.pufuFromMd(md); return { md, items: P.items.length, roles: P.items.map(x => x.role || (x.para ? '補足' : '')).join(','), lv: P.items.map(x => x.level).join(''), res: P.res.length, title: P.title }; });
  if (!(/^# プ譜：会議の週次化（局面 1）\n- 獲得目標：週次の数量/.test(r.md) && /\n    - 取組：需要の数字/.test(r.md) && /\n        - 成果物：誤差の週報/.test(r.md) && /\n        - 補足：集計は需給T が月曜に回す。/.test(r.md) && /\n          - 段取り：対象品目の抽出/.test(r.md) && /## 資源と制約\n- ひと：需給T 3 名/.test(r.md) && r.roles === '獲得目標,勝利条件,取組,中間目的,成果物,施策,段取り,中間目的,補足,施策,中間目的,施策' && r.lv === '012344534423' && r.res === 2)) bad('the role-labeled Markdown carries every role and reads back as the same tree', r);

  /* 節を写す（プ譜の見出しにカーソル）：役の名前付き。指示文：点検（このプ譜入り）・次の局面（新しい情報と日付入り） */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const head = ed.doc.lines.findIndex(l => l.attrs.pufu); ed.setCaret({ line: head, seg: 0, off: 0 }); await FZ.app.run('aiCopySec'); const sec = window.__clip; const scope = FZ.app.st.aiScope && FZ.app.st.aiScope.idx.length;
    ed.setCaret({ line: head + 3, seg: 0, off: 0 }); await FZ.app.run('pufuReview'); const rev = window.__clip;
    FZ.app.run('pufuNext'); await new Promise(r => setTimeout(r, 50)); const f = FZ.app.st.form; document.querySelector('#sub textarea[name="info"]').value = '11/8 定例：理由の欄は空欄が多い。選択式にすることに決定。'; document.querySelector('#sub button[data-act="go"]').click(); await new Promise(r => setTimeout(r, 80)); const nx = window.__clip;
    return { sec: /^# プ譜：/.test(sec) && /- 施策：/.test(sec), scope, rev: /点検して直す編集者/.test(rev) && /〈プ譜〉\n# プ譜：会議の週次化/.test(rev) && /字を一字も変えずに/.test(rev) && !/\{\{/.test(rev), f, nx: /局面を進める編集者/.test(nx) && /〈日付〉\d{4}-\d\d-\d\d/.test(nx) && /〈新しい情報〉\n11\/8 定例/.test(nx) && /〈いまのプ譜〉\n# プ譜：/.test(nx) && !/\{\{/.test(nx), form2: FZ.app.st.form }; });
  if (!(r.sec && r.scope === 16 && r.rev && r.f === 'pnext' && r.nx && !r.form2)) bad('the section copy, the review prompt and the next-phase prompt carry this プ譜', r);

  /* 戻す：答え（役の名前付き）を今のプ譜と三者比較。自分の直しは保ち、AI の直し・足しを取り込む。注記は変換の記録へ */
  r = await page.evaluate(async () => { const ed = FZ.app.ed, L = ed.doc.lines; const head = L.findIndex(l => l.attrs.pufu); ed.setCaret({ line: head, seg: 0, off: 0 }); await FZ.app.run('aiCopySec'); const md = window.__clip;
    const q = L.findIndex(l => l.segs[0].text.startsWith('変更の連絡')); ed.mutate('', () => { L[q].segs[0].text = '変更の連絡を画面に一本化する（IT・2月）'; L[q].segs[0].marks = FZ.marksFor(L[q].segs[0].text, 0); });
    let ans = md.replace('入力様式に修正理由の欄を足す（企画・11月）', '入力様式に修正理由の選択欄を足す（企画・11月）').replace('      - 施策：変更の連絡を画面に一本化する（IT・1月）', '      - 施策：変更の連絡を画面に一本化する（IT・1月）\n      - 施策：翌朝に変更の一覧を配る（需給T）〔推測〕');
    ans = '```markdown\n' + ans + '## 直した所\n- 入力様式：選択式にした\n## 読み取れなかったこと\n1. 会議の曜日は決まっているか\n```';
    FZ.app.run('aiReturn'); await new Promise(r => setTimeout(r, 50)); document.querySelector('#sub textarea[name="md"]').value = ans; document.querySelector('#sub button.pri').click(); await new Promise(r => setTimeout(r, 150));
    const S = FZ.app.st.aiBack; const out = { n: S && S.hunks.length, who: S && S.hunks.map(h => h.kind + ':' + h.who).join(','), selfN: S && S.selfN, base: !!(S && S.base), conv: (FZ.app.st.convLog && FZ.app.st.convLog.items.map(i => i.what)) || [] };
    document.querySelector('#sub [data-act="all"]').click(); await new Promise(r => setTimeout(r, 100));
    const T = ed.doc.lines.map(l => l.segs[0].text); const B = FZ.pufuBlocks(ed.doc)[0]; const role = t => FZ.pufuRoleOf(B, B.map.get(T.findIndex(x => x.startsWith(t))));
    out.after = { sel: T.some(t => t === '入力様式に修正理由の選択欄を足す（企画・11月）'), own: T.includes('変更の連絡を画面に一本化する（IT・2月）'), add: role('翌朝に変更の一覧'), frames: B.frames.length, res: B.res && B.res.items.length, note: role('集計は需給T'), next: T[B.end + 1] };
    ed.undo(); out.undo = ed.doc.lines.some(l => l.segs[0].text.startsWith('翌朝に変更の一覧')); return out; });
  if (!(r.n === 2 && r.who === 'chg:ai,add:ai' && r.selfN === 1 && r.base && r.conv.some(x => /直した・変えた所：入力様式/.test(x)) && r.conv.some(x => /問い：会議の曜日/.test(x)) && r.after.sel && r.after.own && r.after.add === '施策' && r.after.frames === 1 && r.after.res === 2 && r.after.note === '中間目的' && r.after.next === '次の節の本文。' && !r.undo)) bad('the answer is compared with this プ譜 three-way; own edits stay; AI edits and additions come in as the same kind of lines; notes go to the log', r);

  /* docs の写し */
  r = await page.evaluate(() => [FZ.PUFU_PROMPT_REVIEW(), FZ.PUFU_PROMPT_NEXT()]);
  const d1 = fs.readFileSync(path.resolve(__dirname, '../docs/プロンプト_プ譜を点検して直す.md'), 'utf8'), d2 = fs.readFileSync(path.resolve(__dirname, '../docs/プロンプト_プ譜の次の局面.md'), 'utf8');
  if (!(d1.includes(r[0]) && d2.includes(r[1]))) bad('docs carry the same review and next-phase prompts (run the build)');

  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114d-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
