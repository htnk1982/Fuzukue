/* 1.0.14e：プ譜の局面（記録・比べる）と気づき（箱の中の吹き出し） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SRC = ['#fzk 2', '---', '[番号1]需給調整の進め方', '[番号2 プ譜]プ譜：会議の週次化（局面 1）',
    '[項目1]週次の数量をその場で決められる状態をつくる', '[項目2]営業・生産・物流が同じ数字で毎週の数量を確定している',
    '[項目3]販売予測の誤差が、品目別に毎週見えている', '[項目4]予測と実績の差を毎週集計して配る（需給T・11月）', '[項目4]誤差の大きい品目を営業と見直す（各課長・12月）',
    '[項目3]数量の変更が、翌日には生産計画に届いている', '[項目4]変更の連絡を画面に一本化する（IT・1月）', '', '後ろの本文。', ''].join('\n');
  await page.evaluate(async s => { await FZ.app.loadText(s, 'p.fzk', null); }, SRC); await page.waitForTimeout(150);
  const at = t => page.evaluate(t => FZ.app.ed.doc.lines.findIndex(l => l.segs.map(s => s.text).join('').startsWith(t)), t);

  /* 局面を記録：題の「局面 1」の番号で、原本に残る（見出しに名札）。取消で消える */
  let r = await page.evaluate(() => { const ed = FZ.app.ed; const L = ed.doc.lines; const q = L.findIndex(l => l.segs[0].text.startsWith('予測と実績')); ed.setCaret({ line: q, seg: 0, off: 0 }); FZ.app.run('pufuPhaseSave'); const P = (ed.doc.pufuPhases || []).map(p => ({ key: p.key, no: p.no, md: p.md.split('\n')[0], n: p.md.split('\n').length })); const anchor = L.find(l => l.attrs.pufu).attrs.anchor; ed.undo(); const after = (ed.doc.pufuPhases || []).length; ed.redo(); return { P, anchor, after, again: (ed.doc.pufuPhases || []).length }; });
  if (!(r.P.length === 1 && r.P[0].no === 1 && r.P[0].key === r.anchor && /^# プ譜：会議の週次化（局面 1）/.test(r.P[0].md) && r.after === 0 && r.again === 1)) bad('recording a phase keeps the role-labeled snapshot under the heading anchor; undo removes it', r);

  /* 原本の往復（#局面 … #局面ここまで） */
  r = await page.evaluate(() => { const s = FZ.serialize(FZ.app.ed.doc); const d = FZ.parse(s); return { same: FZ.serialize(d) === s, n: (d.pufuPhases || []).length, head: s.split('\n').filter(l => /^#局面/.test(l)), md: d.pufuPhases && d.pufuPhases[0].md === FZ.app.ed.doc.pufuPhases[0].md }; });
  if (!(r.same && r.n === 1 && r.md && /^#局面 h\d+ 1 \d{4}-\d\d-\d\d プ譜：会議の週次化（局面 1）$/.test(r.head[0]) && r.head[1] === '#局面ここまで')) bad('phases round-trip in the .fzk text', r);

  /* 直す・足す・消す・気づき → 比べる：足した 2（施策と気づき）・直した 1・消した 1。紙面の印（画面だけ）と変換の記録 */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const L = () => ed.doc.lines; const at = t => L().findIndex(l => l.segs.map(s => s.text).join('').startsWith(t)); const set = (q, t) => ed.mutate('', () => { L()[q].segs[0].text = t; L()[q].segs[0].marks = FZ.marksFor(t, 0); });
    set(at('予測と実績'), '予測と実績の差を毎週集計して配る（需給T・11月）（済）'); ed.mutate('', () => ed.removeLine(at('誤差の大きい')));
    ed.mutate('', () => ed.insertLine(at('変更の連絡') + 1, FZ.newLine('翌朝に変更の一覧を配る（需給T）', JSON.parse(JSON.stringify(L()[at('変更の連絡')].attrs)))));
    ed.setCaret({ line: at('数量の変更'), seg: 0, off: 0 }); FZ.app.run('pufuInsight'); const ins = { line: ed.caret.line, text: L()[ed.caret.line].segs[0].text, off: ed.caret.off }; set(ed.caret.line, '気づき：前日に締めないと翌日に届かない');
    FZ.app.render(); await new Promise(r => setTimeout(r, 80));
    ed.setCaret({ line: at('予測と実績'), seg: 0, off: 0 }); FZ.app.run('pufuPhaseCmp'); await new Promise(r => setTimeout(r, 80)); const info = document.querySelector('#sub').innerText.replace(/\s+/g, ' ');
    document.querySelector('#sub button[data-act="next"]').click(); await new Promise(r => setTimeout(r, 80)); const ck = document.querySelector('#sub .ckinfo').textContent; const caret = L()[ed.caret.line].segs[0].text;
    const ovRects = document.querySelectorAll('.ov rect').length; const conv = FZ.app.st.convLog.items.map(i => i.what);
    const B = FZ.pufuBlocks(ed.doc)[0]; const insIt = [...B.map.values()].find(x => x.insight); const role = FZ.pufuRoleOf(B, insIt);
    document.querySelector('#sub button[data-act="cancel"]').click(); await new Promise(r => setTimeout(r, 50));
    return { ins, info, ck, caret, ovRects, conv, role, closed: !FZ.app.st.form && !FZ.app.st.pufuCmp }; });
  if (!(r.ins.text === '気づき：' && r.ins.off === 4 && /足した 2 直した 1 消した 1/.test(r.info) && /^直した：前は「施策：予測と実績/.test(r.ck) && /^予測と実績/.test(r.caret) && r.ovRects > 0 && r.conv.some(x => /^消した：施策：誤差の大きい/.test(x)) && r.conv.filter(x => x === '足した').length === 2 && r.role === '気づき' && r.closed)) bad('comparing with the recorded phase shows added, changed and removed lines', r);

  /* 気づきの吹き出し：点線の囲みと淡い網（印刷にも出る）。Word・PowerPoint では点線の別の箱 */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const q = ed.doc.lines.findIndex(l => l.segs[0].text.startsWith('気づき：')); const pg = ed.lay.pages[0];
    const dotted = pg.hrules.filter(h => h.deco && h.kind === 'dotted' && h.line === q).length, fill = pg.fills.some(f => f.deco && f.from === q && f.shade === 'text');
    const S = FZ.pufuShapes(ed.doc, ed.lay)[0].pages[0]; const box = S.rects.find(x => x.role === '気づき'); const owner = S.rects.find(x => x.role === '中間目的' && x.paras.some(p => /数量の変更/.test(p.text || '')));
    return { dotted, fill, box: box && box.stroke + ':' + box.fill + ':' + box.paras[0].line, q, ownerEmpty: owner && owner.paras.length === 2 && owner.paras[1].text === '' }; });
  if (!(r.dotted === 2 && r.fill && r.box === 'dotted:text:' + r.q && r.ownerEmpty)) bad('an insight is a dotted callout on paper and a separate dotted box in Office', r);

  /* 次の局面の指示文：気づきを反映するよう頼む */
  r = await page.evaluate(() => FZ.PUFU_PROMPT_NEXT()); if (!/補足：気づき：」の行は、やってみてわかったこと/.test(r)) bad('the next-phase prompt uses the insights');

  /* 下書きを AI に：元の種類（発言録）と貼った本文。読み方は発言録だけ、本文は貼ったもの */
  r = await page.evaluate(async () => { window.__clip = ''; navigator.clipboard.writeText = async t => { window.__clip = t; }; FZ.app.run('pufuPrompt'); await new Promise(r => setTimeout(r, 60)); const sel = n => document.querySelector(`#sub select[name="${n}"]`);
    sel('kind').value = 'speech'; sel('kind').dispatchEvent(new Event('change')); sel('range').value = 'paste'; sel('range').dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 60));
    const ta = document.querySelector('#sub textarea[name="text"]'); ta.value = '田中：数字が合わないので会議で決められない。\n鈴木：予測の誤差を毎週見たい。'; document.querySelector('#sub input[name="title"]').value = '週次会議'; document.querySelector('#sub button[data-act="go"]').click(); await new Promise(r => setTimeout(r, 100));
    const c = window.__clip; return { kind: /〈本文〉は発言録である/.test(c) && !/\*\*議事録\*\*/.test(c), body: /〈本文〉\n田中：数字が合わない/.test(c), title: /〈題〉週次会議/.test(c), form: FZ.app.st.form }; });
  if (!(r.kind && r.body && r.title && !r.form)) bad('the draft prompt follows the chosen source kind and the pasted text', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114e-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
