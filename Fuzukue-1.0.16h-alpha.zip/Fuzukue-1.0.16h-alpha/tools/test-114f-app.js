/* 1.0.14f：Mermaid の図を詰めて組む（箱は字の大きさ・間は 1 行）、層を飛ぶ矢印は間の箱を避けて回る、1 頁に入らない図は続きを次の頁に描く（画面・図の編集・Word・PowerPoint）、古い図を「詰めて組み直す」 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
const FLOW = ['flowchart TD', '  A[需要予測を受け取る] --> B{予測の誤差は許容内か}', '  B -->|はい| C[生産計画に反映する]', '  B -->|いいえ| D[営業と数量を見直す]', '  D --> E[修正理由を記録する]', '  E --> C',
  '  C --> F[資材の手配を確定する]', '  F --> G[物流に出荷予定を連携する]', '  G --> H{在庫は基準内か}', '  H -->|はい| I[週次会議で確定する]', '  H -->|いいえ| J[安全在庫を再計算する]', '  J --> I', '  I --> K[実績を集計して配る]', '  K --> A'].join('\n');
let BIG = 'flowchart TD\n'; for (let k = 1; k < 26; k++) BIG += `  N${k}[工程${k}：担当者が内容を確かめて次に回す] --> N${k + 1}\n`; BIG += '  N26[完了]\n';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);

  /* 詰めた組み方：1 行の字の箱は高さ 1 行、幅は字＋1 字。層の間は 1 行（字のある層は 2 行）。層を飛ぶ「はい」と戻りの矢印は、間の箱より右を回る */
  let r = await page.evaluate(s => { const F = FZ.figureFromMermaid(s, 40); const by = t => F.boxes.find(b => b.text === t); const arr = (a, b) => F.arrows.find(x => x.from === by(a).id && x.to === by(b).id);
    const yes = arr('予測の誤差は許容内か', '生産計画に反映する'), back = arr('実績を集計して配る', '需要予測を受け取る'); const right = (y0, y1) => Math.max(...F.boxes.filter(b => b.y < y1 && b.y + b.h > y0).map(b => b.x + b.w));
    return { h: F.h, hs: [...new Set(F.boxes.map(b => b.h))], wOk: F.boxes.every(b => b.w === FZ.textWidth(b.text) + 1), yes: yes.via + ':' + (yes.vp > right(by('予測の誤差は許容内か').y, by('生産計画に反映する').y + 1)), back: back.via + ':' + (back.vp > yes.vp),
      gap: by('営業と数量を見直す').y - (by('予測の誤差は許容内か').y + 1), gap2: by('修正理由を記録する').y - (by('営業と数量を見直す').y + 1) }; }, FLOW);
  if (!(r.h <= 24 && r.hs.join() === '1' && r.wOk && r.yes === 'r:true' && r.back === 'r:true' && r.gap === 2 && r.gap2 === 1)) bad('a Mermaid flowchart is laid out compactly (1-row boxes, 1-row gaps, 2 under labeled layers) and long edges detour right of the boxes in between', r);

  /* 回り道の位置は原本に残る（右回り:列） */
  r = await page.evaluate(s => { const F = FZ.figureFromMermaid(s, 40); const L = FZ.figureToLines(F); const d = FZ.parse('#fzk 2\n---\n' + L.join('\n') + '\n[図' + F.h + ']\n'); const G = d.lines.find(l => l.attrs.figure).attrs.figure; return { line: L.find(x => /右回り:/.test(x)) || '', same: JSON.stringify(G.arrows) === JSON.stringify(F.arrows) }; }, FLOW);
  if (!(/右回り:\d/.test(r.line) && r.same)) bad('the detour position round-trips through the .fzk source', r);

  /* 長い文字は行の長さをそろえて折り返す（最後の行に 1 字だけ残さない） */
  r = await page.evaluate(() => { const F = FZ.figureFromMermaid('flowchart TD\n  A[工程10：担当者が内容を確かめて次に回す] --> B[完了]', 40); const b = F.boxes[0]; return { w: b.w, h: b.h }; });
  if (!(r.h === 2 && r.w === 11)) bad('a long label wraps into balanced rows', r);

  /* 幅 3 字でも横に入らない層（子が 14）：段に分けて積み、図の幅を越えない */
  r = await page.evaluate(() => { let s = 'flowchart TD\n  R[本部]\n'; for (let k = 1; k <= 14; k++) s += `  R --> C${k}[拠点${k}]\n`; const F = FZ.figureFromMermaid(s, 40); return { right: Math.max(...F.boxes.map(b => b.x + b.w)), rows: new Set(F.boxes.filter(b => b.text !== '本部').map(b => b.y)).size }; });
  if (!(r.right <= 40 && r.rows === 2)) bad('a layer too wide for the page is stacked in two rows', r);

  /* シーケンス図：参加者の箱は 1 行、伝達はすぐ下から */
  r = await page.evaluate(() => { const F = FZ.figureFromMermaid('sequenceDiagram\n  participant U as 営業\n  participant S as 需給T\n  U->>S: 予測を出す\n  S-->>U: 受け取った', 40); return { ph: F.boxes.filter(b => b.y === 0).map(b => b.h).join(), y1: F.lines.find(l => l.role === 'msg').pts[0][1], h: F.h }; });
  if (!(r.ph === '1,1' && r.y1 === 2 && r.h <= 6)) bad('sequence diagrams start right under 1-row participant boxes', r);

  /* 1 頁に入らない図：箱をまたがない行の境で切り、続きを次の頁に描く。後ろの段落は最後の頁の続きから */
  const MD = '# 図の試験\n\n前置きの段落。\n\n```mermaid\n' + FLOW + '\n```\n\n間の段落。\n\n```mermaid\n' + BIG + '```\n\n後ろの段落。\n';
  r = await page.evaluate(async md => { const d = FZ.fromGfm(md); await FZ.app.loadText(FZ.serialize(d), 'm.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 150)); const ed = FZ.app.ed, lay = ed.lay;
    const figs = ed.doc.lines.map((l, i) => i).filter(i => ed.doc.lines[i].attrs.figure); const i = figs[1], F = ed.doc.lines[i].attrs.figure, P = lay.lineMap[i].figParts;
    const cover = P[0].f0 === 0 && P[P.length - 1].f1 === F.h && P.every((p, k) => k === 0 || p.f0 === P[k - 1].f1) && P.every((p, k) => k === 0 || p.page === P[k - 1].page + 1);
    const straddle = P.slice(1).some(p => F.boxes.some(b => b.y < p.f0 && b.y + b.h > p.f0)); const fit = P.every(p => p.y0 + (p.f1 - p.f0) <= lay.geo.rows);
    const late = F.boxes.find(b => b.text.startsWith('工程20')); const lp = P.find(p => late.y >= p.f0 && late.y < p.f1); const gl = lay.pages[lp.page].glyphs.find(g => g.line === i && g.text === '2' && g.y === lp.y0 + late.y - lp.f0);
    const after = ed.doc.lines.findIndex(l => l.segs[0].text === '後ろの段落。'); const ar = lay.lineMap[after].rows[0]; const last = P[P.length - 1];
    const heads = lay.pages[P[1].page].vrules.filter(v => v.from === i && v.kind === 'arrow').length; const top = lay.pages[P[1].page].vrules.some(v => v.from === i && v.y1 === 0);
    return { n: P.length, cover, straddle, fit, glyph: !!gl, after: ar.page === last.page && ar.y >= last.y0 + last.f1 - last.f0, heads, top, split: lay.lineMap[i].why && lay.lineMap[i].why.split, first: lay.lineMap[figs[0]].figParts.length, i }; }, MD);
  if (!(r.n >= 2 && r.cover && !r.straddle && r.fit && r.glyph && r.after && r.heads > 3 && r.top && /頁に分けて描く/.test(r.split || '') && r.first === 1)) bad('a figure taller than a page continues on the next pages, cut between boxes', r);
  const BIGI = r.i;

  /* 図を直す：続きの頁の箱をクリックで選べる。つまみと枠はその頁に */
  r = await page.evaluate(i => { FZ.app._fig.enter(i, null); const fi = FZ.app._fig.figInfo(i); const P = fi.parts; const b = fi.F.boxes.find(b => b.y >= P[1].f0 && b.y < P[1].f1 && b.text.startsWith('工程')); return { id: b.id, page: P[1].page, y: fi.Y(b.y), mapped: fi.P(b.y) === P[1].page, col: fi.left + b.x + b.w / 2 }; }, BIGI);
  await page.evaluate(q => { const w = document.querySelector(`.pgwrap[data-page="${q.page}"]`); w.scrollIntoView({ block: 'start' }); let sc = w.parentElement; while (sc && !(sc.scrollHeight > sc.clientHeight + 4 && /auto|scroll/.test(getComputedStyle(sc).overflowY))) sc = sc.parentElement; (sc || document.scrollingElement).scrollBy(0, -450); }, r); await page.waitForTimeout(150);
  const pt = await page.evaluate(q => { const el = document.querySelector(`.pgwrap[data-page="${q.page}"] svg.pg`); const rc = el.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = rc.width / g.W; return { x: rc.left + (g.left + q.col * g.cw) * sc, y: rc.top + (g.top + (g.bodyTop + q.y + 0.5) * g.ch) * sc }; }, r);
  await page.mouse.click(pt.x, pt.y); await page.waitForTimeout(80);
  const sel = await page.evaluate(() => FZ.app.st.fig && FZ.app.st.fig.sel);
  if (!(r.mapped && sel === r.id)) bad('clicking a box on a continued page selects it in figure mode', { r, sel });
  await page.evaluate(() => FZ.app._fig.exit());

  /* Word：頁ごとの図（図形のまとまりが部分の数だけ）。PowerPoint：続きは次のスライド */
  r = await page.evaluate(i => { const ed = FZ.app.ed; const x = FZ.toDocx(ed.doc, { files: true }).find(f => f.name === 'word/document.xml'); const t = typeof x.data === 'string' ? x.data : new TextDecoder().decode(x.data); const n = (t.match(/<wp:docPr id="\d+" name="図/g) || []).length; return { n, parts: ed.lay.lineMap[i].figParts.length }; }, BIGI);
  if (!(r.n === r.parts + 1)) bad('Word gets one drawing per page part (plus the first figure)', r);
  r = await page.evaluate(async i => { const ed = FZ.app.ed; const files = FZ.toPptx(ed.doc, { files: true }); const sl = files.filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f.name)).map(f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data)); return sl.map(t => (t.match(/工程\d+/g) || []).length); }, BIGI);
  if (!(r.filter(n => n > 0).length >= 2)) bad('PowerPoint puts the continued part on the next slide', r);

  /* 古い図（余白の大きい箱）を「詰めて組み直す」：高さが減り、箱と矢印は保つ。取消で戻る */
  r = await page.evaluate(async () => { const old = { h: 20, tag: 'flow', dir: 'TD', boxes: [{ id: 1, x: 10, y: 1, w: 14, h: 3, text: '受付', kind: 'thin' }, { id: 2, x: 10, y: 7, w: 14, h: 3, text: '審査', kind: 'double' }, { id: 3, x: 10, y: 13, w: 14, h: 3, text: '承認', kind: 'thin' }], arrows: [{ from: 1, to: 2 }, { from: 2, to: 3, label: 'OK' }] };
    const d = FZ.newDoc(); d.lines = [FZ.newLine('前'), FZ.newLine('', { figure: FZ.normalizeFigure(old) }), FZ.newLine('後')]; FZ.app.ed.setDoc(d); FZ.app.render(); const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 });
    FZ.app.run('fg:compact'); const F = ed.doc.lines[1].attrs.figure; const out = { h: F.h, n: F.boxes.length, a: F.arrows.length, label: F.arrows.some(a => a.label === 'OK'), kind: F.boxes.find(b => b.text === '審査').kind, hs: F.boxes.map(b => b.h).join() };
    ed.undo(); out.back = ed.doc.lines[1].attrs.figure.h; return out; });
  if (!(r.h < 10 && r.n === 3 && r.a === 2 && r.label && r.kind === 'double' && r.hs === '1,1,1' && r.back === 20)) bad('compacting an old figure keeps its boxes and arrows and can be undone', r);
  r = await page.evaluate(() => { const ed = FZ.app.ed; FZ.app._fig.enter(1, null); FZ.app.drawSub(); const on = /fg:compact/.test(document.querySelector('#sub').innerHTML); FZ.app._fig.exit(); return on; }); if (!r) bad('the compact command is on the figure band', r);

  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114f-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
