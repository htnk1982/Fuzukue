/* 1.0.14g：プ譜の列の図（横長の紙面）：右から 勝利条件・獲得目標｜中間目的｜施策（段取りは箱の中）｜資源と制約、上に列の名前の帯、矢印は親へ、取組は太罫。1 頁に収める。形を選ぶ（自動・字下げ・列）。Word・PowerPoint */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
const SRC = ['#fzk 2', '---', '[番号1]需給調整の進め方', '[番号2 プ譜]プ譜：会議の週次化（局面 1）',
  '[項目1]週次の数量をその場で決められる状態をつくる', '[項目2]営業・生産・物流が同じ数字で毎週の数量を確定している',
  '[項目3 プ譜取組]需要の数字を、信じて使えるものにする', '[項目4]販売予測の誤差が、品目別に毎週見えている', '[項目5]成果物：誤差の週報', '[項目5]予測と実績の差を毎週集計して配る（需給T・11月）', '[項目6]対象品目の抽出', '[項目6]集計の自動化〔推測〕',
  '[項目4]営業が予測を直すとき、理由を添えて出している', '集計は需給T が月曜に回す。', '[項目5]入力様式に修正理由の欄を足す（企画・11月）',
  '[項目3]数量の変更が、翌日には生産計画に届いている', '[項目4]変更の連絡を画面に一本化する（IT・1月）', '気づき：前日に締めないと翌日に届かない', '[項目4]翌朝に変更の一覧を配る（需給T）',
  '[項目1 プ譜資源]資源と制約（廟算八要素）', '[項目2]ひと：需給T 3 名', '[項目2]お金：追加の予算なし', '', '次の節の本文。', ''].join('\n');
const A3 = { paper: 'A3', widthMm: 420, heightMm: 297, landscape: true, cols: 90, rows: 44 };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1400, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const load = (src, fmt) => page.evaluate(async ([s, f]) => { const d = FZ.parse(s); if (f) Object.assign(d.format, f); await FZ.app.loadText(FZ.serialize(d), 'p.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 120)); }, [src, fmt]);

  /* A3 横：列の図。列は左から 資源｜施策｜中間目的｜勝利条件、獲得目標は勝利条件の列の下。段取りは施策の列で「・」、施策の箱の続き */
  await load(SRC, A3);
  let r = await page.evaluate(() => { const ed = FZ.app.ed, lay = ed.lay, L = ed.doc.lines; const at = t => L.findIndex(l => l.segs.map(s => s.text).join('').startsWith(t)); const pf = q => lay.pufuAt.get(q);
    const B = FZ.pufuBlocks(ed.doc)[0]; const all = [...B.map.keys()].every(q => pf(q) && pf(q).fig);
    const x = t => pf(at(t)).bx0, dy = t => pf(at(t)).fig.dy; const G = at('週次の数量'), Wn = at('営業・生産'), M1 = at('販売予測'), S1 = at('予測と実績'), D1 = at('対象品目'), D2 = at('集計の自動化'), R1 = at('ひと：');
    const cols = x('ひと：') < x('予測と実績') && x('予測と実績') < x('販売予測') && x('販売予測') < x('営業・生産') && x('営業・生産') === x('週次の数量');
    const goalBelow = dy('週次の数量') > dy('営業・生産'); const sub = pf(D1).bullet != null && pf(D1).bx0 === pf(S1).bx0 && dy('対象品目') === dy('予測と実績') + pf(S1).fig.dy * 0 + (lay.lineMap[S1].rows.reduce((t, r) => t + r.h, 0)) && !pf(D1).top && pf(D2).end;
    const first = [...B.map.keys()].sort((a, b) => a - b)[0]; const D = pf(first).fig.deco; const heads = D.heads.map(h => h.text).join(); const arrows = D.hrules.filter(h => h.kind === 'arrow').length, down = D.vrules.filter(v => v.kind === 'arrow' && v.dir === 'd').length, thick = D.hrules.filter(h => h.kind === 'thick').length;
    const top = lay.lineMap[first].rows[0].y - pf(first).fig.dy; const placed = [...B.map.keys()].every(q => lay.lineMap[q].rows[0].y === top + pf(q).fig.dy && lay.lineMap[q].rows[0].page === lay.lineMap[first].rows[0].page);
    const nx = lay.lineMap[at('次の節の本文')].rows[0]; const after = nx.y >= top + pf(first).fig.H; const pg = lay.pages[0]; const hg = ['施', '中', '勝', '獲'].every(c => pg.glyphs.some(g => g.deco && g.text === c && g.y === top || (g.deco && g.text === c))); const ink = pg.fills.filter(f => f.deco && f.shade === 'ink').length;
    const res = pf(at('資源と制約')); return { all, cols, goalBelow, sub, heads, arrows, down, thick, placed, after, hg, ink, res: res.fill + ':' + res.fig.dy, glyphBullet: pg.glyphs.some(g => g.deco && g.text === '・' && g.line === D1) }; });
  if (!(r.all && r.cols && r.goalBelow && r.sub && r.heads === '施策,中間目的,勝利条件,獲得目標' && r.arrows === 4 && r.down === 1 && r.thick === 2 && r.placed && r.after && r.hg && r.ink >= 4 && r.res === 'ink:0' && r.glyphBullet)) bad('on A3 landscape the プ譜 is drawn as the column figure', r);

  /* 打つと組み直す：施策を長くすると、その下の行が下がり、図の高さも変わる。カーソルは字の位置に */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const L = ed.doc.lines; const at = t => L.findIndex(l => l.segs.map(s => s.text).join('').startsWith(t)); const pf = q => ed.lay.pufuAt.get(q);
    const S1 = at('予測と実績'), D1 = at('対象品目'); const before = { d: pf(D1).fig.dy, H: pf(S1).fig.H }; ed.setCaret({ line: S1, seg: 0, off: L[S1].segs[0].text.length }); for (const ch of '、営業と品目ごとに見直す時間を毎週の会議の前に確保する') ed.insertText(ch); FZ.app.render(); await new Promise(r => setTimeout(r, 60));
    const after = { d: pf(D1).fig.dy, H: pf(S1).fig.H }; const xy = ed.xy(); const p = pf(S1); ed.undo(); FZ.app.render(); return { before, after, inBox: xy.col >= p.L - 1e-6 && xy.col <= p.R + 1e-6 }; });
  if (!(r.after.d > r.before.d && r.after.H >= r.before.H && r.inBox)) bad('typing into a column box re-lays the figure', r);

  /* 形を選ぶ：字下げ（列の図をやめる）・列・自動。原本の印（プ譜字下げ・プ譜列） */
  r = await page.evaluate(() => { const ed = FZ.app.ed; const L = ed.doc.lines; const head = L.findIndex(l => l.attrs.pufu); ed.setCaret({ line: head + 2, seg: 0, off: 0 }); const isCols = () => [...ed.lay.pufuAt.values()].some(p => p.fig);
    FZ.app.run('pufuFormTree'); FZ.app.render(); const t = { cols: isCols(), tok: FZ.serialize(ed.doc).includes('プ譜字下げ') }; FZ.app.run('pufuFormAuto'); FZ.app.render(); const a = isCols(); FZ.app.run('pufuFormCols'); FZ.app.render(); const c = { cols: isCols(), tok: FZ.serialize(ed.doc).includes('プ譜列'), back: FZ.parse(FZ.serialize(ed.doc)).lines[head].attrs.pufuForm };
    const M = FZ.app._menu(); const sel = M.MSEL.pufuForm && M.GROUPS.pufu.items.some(it => it.msel === 'pufuForm'); FZ.app.run('pufuFormAuto'); return { t, a, c, sel }; });
  if (!(r.t.cols === false && r.t.tok && r.a === true && r.c.cols && r.c.tok && r.c.back === 'cols' && r.sel)) bad('the form can be switched (tree / auto / columns) and is kept in the source', r);

  /* A4 縦：自動は字下げ（これまでどおり）。列を選べば列の図（40 字）。高すぎて入らなければ字下げのまま */
  await load(SRC, null);
  r = await page.evaluate(() => { const ed = FZ.app.ed; const isCols = () => [...ed.lay.pufuAt.values()].some(p => p.fig); const head = ed.doc.lines.findIndex(l => l.attrs.pufu); const a = isCols(); ed.setCaret({ line: head + 2, seg: 0, off: 0 }); FZ.app.run('pufuFormCols'); FZ.app.render(); return { a, c: isCols(), cols: ed.lay.geo.cols }; });
  if (!(r.a === false && r.c === true)) bad('A4 portrait stays indented on auto; columns can be chosen', r);
  const many = SRC.split('\n'); const k = many.findIndex(l => l.startsWith('[項目1 プ譜資源]')); const extra = []; for (let j = 0; j < 14; j++) extra.push(`[項目3]中間目的 ${j + 1} が整っている`, `[項目4]施策 ${j + 1}-1 を行う`, `[項目4]施策 ${j + 1}-2 を行う`); many.splice(k, 0, ...extra);
  await load(many.join('\n').replace('[番号2 プ譜]', '[番号2 プ譜 プ譜列]'), null);
  r = await page.evaluate(() => [...FZ.app.ed.lay.pufuAt.values()].some(p => p.fig)); if (r !== false) bad('a column figure taller than the page falls back to the indented form', r);

  /* 見出しは図と同じ頁：頁の下の方にプ譜の見出しが来たら、図ごと次の頁へ */
  const filler = []; for (let j = 0; j < 34; j++) filler.push('前の段落 ' + (j + 1) + '。');
  await load(SRC.replace('[番号1]需給調整の進め方', filler.join('\n') + '\n[番号1]需給調整の進め方'), A3);
  r = await page.evaluate(() => { const ed = FZ.app.ed, lay = ed.lay; const head = ed.doc.lines.findIndex(l => l.attrs.pufu); const B = FZ.pufuBlocks(ed.doc)[0]; return { head: lay.lineMap[head].rows[0].page, fig: lay.lineMap[B.start].rows[0].page, fits: [...B.map.keys()].every(q => lay.lineMap[q].rows.every(r => r.page === lay.lineMap[B.start].rows[0].page)) }; });
  if (!(r.head === r.fig && r.fits)) bad('the プ譜 heading stays with its column figure; the figure is not split', r);

  /* Word・PowerPoint：列の名前の帯（墨に白抜き）、段取りは「・」付きで施策の箱に、矢印 */
  await load(SRC, A3);
  r = await page.evaluate(() => { const ed = FZ.app.ed; const S = FZ.pufuShapes(ed.doc, ed.lay)[0].pages[0]; const heads = S.rects.filter(x => x.role === 'head'); const sk = S.rects.find(x => x.role === '施策' && x.paras.some(p => /予測と実績/.test(p.text || '')));
    const dx = FZ.toDocx(ed.doc, { files: true }).find(f => f.name === 'word/document.xml'); const t = typeof dx.data === 'string' ? dx.data : new TextDecoder().decode(dx.data);
    const px = FZ.toPptx(ed.doc, { files: true }).find(f => f.name === 'ppt/slides/slide1.xml'); const u = typeof px.data === 'string' ? px.data : new TextDecoder().decode(px.data);
    return { heads: heads.map(h => h.paras[0].text + ':' + h.dark).join(), paras: sk && sk.paras.map(p => p.text).join('|'), dan: S.rects.some(x => x.role === '段取り'), heads2: S.lines.filter(l => l.head).length, word: /・<\/w:t>/.test(t) || /<w:t[^>]*>・/.test(t), wordHead: /中間目的/.test(t), ppt: /施策/.test(u) && /・/.test(u) }; });
  if (!(r.heads === '施策:true,中間目的:true,勝利条件:true,獲得目標:true' && /^予測と実績.*\|・対象品目の抽出\|・集計の自動化/.test(r.paras || '') && !r.dan && r.heads2 >= 5 && r.word && r.wordHead && r.ppt)) bad('Word and PowerPoint get the column figure (header bands, sub-steps inside the measure box, arrows)', r);

  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-114g-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
