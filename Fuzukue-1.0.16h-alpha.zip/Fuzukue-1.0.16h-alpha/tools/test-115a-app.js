/* 1.0.15a：UI/UX 提案の第 1 便。三層（紙・手当て・写し）と手当ての朱、手当てを隠す、刷る（紙だけ／手当ても）、写しの見通しと項目の説明、版から節ごとに戻す、黙って消さない（Word の数式・脚注・グラフ）、CSP・読み上げ */
const { chromium } = require('playwright'); const path = require('path'); const fs = require('fs');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (/Content Security Policy/.test(m.text())) errors.push('CSP: ' + m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SRC = ['#fzk 2', '---', '[番号1]一章', '本文の一行目。', '影文字と傍点のある行。', '二行目の本文。', '[番号1]二章', '三行目の本文。', ''].join('\n');
  await page.evaluate(async s => { const d = FZ.parse(s); const L = d.lines; const q = L.findIndex(l => l.segs[0].text.startsWith('影文字')); const sg = L[q].segs[0]; for (let k = 0; k < 3; k++) sg.marks[k] = FZ.M.SHADOW; for (let k = 4; k < 6; k++) sg.marks[k] = FZ.M.DOT; await FZ.app.loadText(FZ.serialize(d), 't.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 100)); }, SRC);

  /* 手当ては朱：付箋のつまみ。手当てを隠すと紙だけ（付箋の層が消え、札も出ない） */
  let r = await page.evaluate(async () => { const ed = FZ.app.ed; ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.run('noteAdd'); await new Promise(r => setTimeout(r, 60)); const n = ed.doc.notes[ed.doc.notes.length - 1]; n.text = '確かめる'; FZ.app.render(); await new Promise(r => setTimeout(r, 60));
    const tab = document.querySelector('#notesLayer .ntab'); const bg = tab && getComputedStyle(tab).backgroundColor; FZ.app._care.toggle(false); await new Promise(r => setTimeout(r, 60)); const hid = getComputedStyle(document.querySelector('#notesLayer')).display; const cls = document.body.classList.contains('care-off');
    FZ.app._care.toggle(true); await new Promise(r => setTimeout(r, 30)); return { bg, hid, cls, back: !document.body.classList.contains('care-off'), shu: FZ.SHU }; });
  if (!(r.bg === 'rgb(210, 56, 28)' && r.hid === 'none' && r.cls && r.back && r.shu === '#d2381c')) bad('annotation marks are vermilion and can be hidden to see the paper only', r);

  /* 刷る：紙だけ（既定）は手当てを刷らない。手当ても＝付箋の番号を朱の札で余白に、中身は最後の頁 */
  r = await page.evaluate(() => { FZ.app._care.print(false); const a = { g: document.querySelectorAll('.pgwrap svg .printcare').length, list: !!document.querySelector('#printNotes') };
    FZ.app._care.print(true); const g = document.querySelector('.pgwrap svg .printcare'); const b = { g: !!g, tag: g && /fill="#d2381c"/.test(g.innerHTML) && />1<\/text>/.test(g.innerHTML), list: (document.querySelector('#printNotes') || {}).textContent || '' }; FZ.app.render(); return { a, b }; });
  if (!(r.a.g === 0 && !r.a.list && r.b.g && r.b.tag && /付箋（1 件）/.test(r.b.list) && /確かめる/.test(r.b.list))) bad('printing paper only leaves annotations out; printing with annotations adds numbered vermilion tags and a list page', r);
  r = await page.evaluate(() => { const M = FZ.app._menu(); return { sel: !!M.MSEL.printLayer, inView: M.GROUPS.view.items.some(it => it.msel === 'printLayer') && M.GROUPS.view.items.some(it => it.cmd === 'careShow') && M.GROUPS.view.items.some(it => it.cmd === 'convPreview') }; });
  if (!(r.sel && r.inView)) bad('the layer controls (annotations, print, copies preview) are on the view band', r);

  /* 写しの見通し：書き出す前に、形ごとに変わる所を位置つきで。項目の説明にも */
  r = await page.evaluate(async () => { FZ.app.run('convPreview'); await new Promise(r => setTimeout(r, 120)); const C = FZ.app.st.convLog; const side = FZ.app.st.side; const T = document.querySelector('#sideBody').innerText;
    const tip = FZ.degradeTip('shadow'), none = FZ.degradeTip('bold'); return { side, title: C.title, w: C.items.some(i => /^Word：影文字/.test(i.what)), p: C.items.some(i => /^PowerPoint：傍点は入らない/.test(i.what)), t: C.items.some(i => /^テキスト：/.test(i.what)), lines: C.items.every(i => Array.isArray(i.lines)), T: /写しの見通し/.test(T), tip, none }; });
  if (!(r.side === 'conv' && r.title === '写しの見通し（書き出す前）' && r.w && r.p && r.t && r.lines && r.T && /Word：影文字は Word の「影」に[^／]*／PowerPoint：影文字は外側の影に／Markdown：入らない/.test(r.tip) && r.none === '')) bad('the copies preview lists what changes in each format before exporting; decoration tips say it too', r);
  await page.evaluate(() => { FZ.app.run('convPreview'); });
  r = await page.evaluate(async () => { FZ.app.run('wide'); FZ.app.st.group = 'marks'; FZ.app.drawSub(); await new Promise(r => setTimeout(r, 30)); const el = document.querySelector('#sub [data-cmd="shadow"]'); return el ? el.getAttribute('title') : null; });
  if (!(r && /写し　Word：影文字/.test(r))) bad('the band item for a decoration shows how it is copied', r);

  /* 版から節ごとに戻す：古い版の違いを 1 つずつ。1 つだけ戻して、取消で元に */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; const old = FZ.serialize(ed.doc).replace('本文の一行目。', '本文の一行目（古い版）。').replace('三行目の本文。', '三行目の本文（古い版）。');
    await FZ.app._care.histPickText(old, '版 2'); await new Promise(r => setTimeout(r, 60)); const S = FZ.app.st.aiBack; const head = document.querySelector('#sub').innerText.replace(/\s+/g, ' ');
    const out = { form: FZ.app.st.form, title: S && S.title, n: S && S.hunks.length, head: /版から戻す/.test(head) && !/貼り直す/.test(head) };
    document.querySelector('#sub [data-act="take"]').click(); await new Promise(r => setTimeout(r, 60)); const T = ed.doc.lines.map(l => l.segs[0].text); out.after = [T.includes('本文の一行目（古い版）。'), T.includes('三行目の本文。')]; ed.undo(); out.undo = ed.doc.lines.some(l => l.segs[0].text === '本文の一行目。'); document.querySelector('#sub [data-act="cancel"]').click(); return out; });
  if (!(r.form === 'aiback' && r.title === '版から戻す' && r.n === 2 && r.head && r.after[0] && r.after[1] && r.undo)) bad('a history version can be restored part by part', r);

  /* 黙って消さない：Word の数式・脚注・グラフは本文に印を残す */
  r = await page.evaluate(async () => { const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"';
    const doc = `<?xml version="1.0"?><w:document ${W}><w:body><w:p><w:r><w:t>式は</w:t></w:r><m:oMath><m:r><m:t>x=1</m:t></m:r></m:oMath><w:r><w:t>である。</w:t></w:r></w:p><w:p><w:r><w:t>本文</w:t></w:r><w:r><w:footnoteReference w:id="1"/></w:r></w:p><w:p><w:r><w:drawing><wp:inline><a:graphic><a:graphicData><c:chart/></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p></w:body></w:document>`;
    const fn = `<?xml version="1.0"?><w:footnotes ${W}><w:footnote w:id="-1"><w:p><w:r><w:t>区切り</w:t></w:r></w:p></w:footnote><w:footnote w:id="1"><w:p><w:r><w:t>補足の中身</w:t></w:r></w:p></w:footnote></w:footnotes>`;
    const buf = FZ.zip([{ name: '[Content_Types].xml', data: '<?xml version="1.0"?><Types/>' }, { name: 'word/document.xml', data: doc }, { name: 'word/footnotes.xml', data: fn }]); const res = await FZ.fromDocx(buf); const t = FZ.serialize(res.doc); const conv = JSON.stringify(res.conv || res.audit || res);
    return { math: /式は［数式：x=1］である。/.test(t), note: /本文［注：補足の中身］/.test(t), chart: /［Word のグラフ（取り込めない）］/.test(t), log: /数式は［数式：字］/.test(conv) }; });
  if (!(r.math && r.note && r.chart && r.log)) bad('Word math, footnotes and charts leave a mark in the text instead of vanishing', r);

  /* CSP・読み上げ・写しの灰色の表 */
  r = await page.evaluate(() => ({ csp: (document.querySelector('meta[http-equiv="Content-Security-Policy"]') || {}).content || '', live: document.querySelector('#stMsg').getAttribute('aria-live'), gray: FZ.shadeHex('gray'), deep: FZ.shadeHex('deep'), ink: FZ.shadeHex('ink') }));
  if (!(/object-src 'none'/.test(r.csp) && /script-src 'self' file:;/.test(r.csp) && r.live === 'polite' && r.gray === 'D9D9D9' && r.deep === '8C8C8C' && r.ink === '4D4D4D')) bad('CSP, live status and the shared gray table', r);
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-115a-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
