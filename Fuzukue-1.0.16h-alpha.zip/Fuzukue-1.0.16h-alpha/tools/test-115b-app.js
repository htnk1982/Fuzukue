/* 1.0.15b：文書の健康診断（規模・構造・参照と番号・付箋・表記の決まり・構成の型）、直す（1 回の取消）・無視（文書に覚える）・自分の決まり、紙面の朱の印 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(() => { try { localStorage.removeItem('fz.proofSets'); localStorage.removeItem('fz.proofUser'); } catch { } });
  await page.reload(); await page.waitForTimeout(400);
  const SRC = ['#fzk 2', '---', '[表題]需給の報告', '[番号1 節:a1]目的', 'ＡＢＣの件で、確認する事が出来る。。', '[番号1]現状', 'サーバーとサーバーとサーバの扱いを決める。売上は12000000円。', 'これは見れる資料です。', '<図番 §zz>を見る。', '[番号1]対応策', '[項目1]案', ''].join('\n');
  /* 規則そのもの（Node でも動く） */
  let r = await page.evaluate(s => { const d = FZ.parse(s); const I = FZ.proofIssues(d, { sets: ['common', 'num', 'kobun'] }); return I.map(x => x.id + ':' + x.text + '→' + x.fix); }, SRC);
  const has = (re) => r.some(x => re.test(x));
  if (!(has(/^zenEisu:ＡＢＣ→ABC$/) && has(/^dupPunct:。。→。$/) && has(/^v_サーバー:サーバ→サーバー$/) && has(/^n_comma:12000000→12,000,000$/) && has(/^ranuki:見れる→見られる$/) && has(/^k_koto:事→こと$/) && has(/^k_dekiru:出来→でき$/))) bad('the rule sets find full-width letters, doubled punctuation, variants, digits, ra-nuki and official-style spellings', r);

  /* 欄：規模・構造・参照切れ・表記。既定は「どの文書にも」「数字」「自分の決まり」（公用文は切） */
  await page.evaluate(async s => { await FZ.app.loadText(s, 'h.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 100)); FZ.app.run('health'); await new Promise(r => setTimeout(r, 150)); }, SRC);
  r = await page.evaluate(() => { const B = document.querySelector('#sideBody'); const rows = [...B.querySelectorAll('[data-hrow]')].map(e => e.dataset.hrow); return { side: FZ.app.st.side, head: B.querySelector('.hvhead').innerText.replace(/\s+/g, ' '), rows, kobun: B.querySelector('[data-hset="kobun"]').checked, common: B.querySelector('[data-hset="common"]').checked }; });
  if (!(r.side === 'health' && /1 頁/.test(r.head) && /文 \d+（平均 \d+ 字/.test(r.head) && r.rows.includes('r_broken') && r.rows.includes('p_zenEisu') && r.rows.includes('p_v_サーバー') && r.rows.includes('s_one') && !r.rows.includes('p_k_koto') && !r.kobun && r.common)) bad('the health panel shows scale, structure, broken refs and spelling (official style off by default)', r);

  /* 行を開くと所の一覧と紙面の朱の印。所を選ぶとそこを選ぶ */
  r = await page.evaluate(async () => { document.querySelector('[data-hrow="p_zenEisu"]').click(); await new Promise(r => setTimeout(r, 120)); const it = document.querySelector('[data-hit="p_zenEisu:0"]'); it.click(); await new Promise(r => setTimeout(r, 120)); const ed = FZ.app.ed; const s = ed.sel(); const t = s ? ed.doc.lines[s.a.line].segs[0].text.slice(s.a.off, s.b.off) : ''; const hits = [...document.querySelectorAll('.ov rect')].filter(x => x.getAttribute('stroke') === '#d2381c').length; return { t, hits }; });
  if (!(r.t === 'ＡＢＣ' && r.hits >= 1)) bad('opening a row lists the places, marks them in vermilion, and choosing one selects it', r);

  /* この種類をすべて直す（1 回の Ctrl+Z）・無視（文書に覚え、原本に残る） */
  r = await page.evaluate(async () => { const ed = FZ.app.ed; document.querySelector('[data-hrow="p_v_サーバー"]').click(); await new Promise(r => setTimeout(r, 80)); document.querySelector('[data-hfixall="p_v_サーバー"]').click(); await new Promise(r => setTimeout(r, 80)); const after = ed.doc.lines.map(l => l.segs[0].text).find(t => /サーバ/.test(t)); ed.undo(); const undone = ed.doc.lines.map(l => l.segs[0].text).find(t => /サーバ/.test(t));
    FZ.app.render(); FZ.app.run('health'); FZ.app.run('health'); await new Promise(r => setTimeout(r, 80)); document.querySelector('[data-hrow="p_n_comma"]').click(); await new Promise(r => setTimeout(r, 80)); document.querySelector('[data-hign="p_n_comma:0"]').click(); await new Promise(r => setTimeout(r, 80));
    const rows = [...document.querySelectorAll('[data-hrow]')].map(e => e.dataset.hrow); const src = FZ.serialize(ed.doc); const back = FZ.parse(src).proofIgnore; return { after, undone, gone: !rows.includes('p_n_comma'), src: /#点検無視 n_comma\|12000000/.test(src), back }; });
  if (!(r.after === 'サーバーとサーバーとサーバーの扱いを決める。売上は12000000円。' && /サーバの扱い/.test(r.undone) && r.gone && r.src && r.back && r.back[0] === 'n_comma|12000000')) bad('fixing all of a kind is one undo; ignoring is remembered in the document', r);

  /* 自分の決まり・公用文の入り切り */
  r = await page.evaluate(async () => { document.querySelector('#huFrom').value = '確認する'; document.querySelector('#huTo').value = '確かめる'; document.querySelector('[data-hact="uadd"]').click(); await new Promise(r => setTimeout(r, 80)); const u = [...document.querySelectorAll('[data-hrow]')].some(e => /^p_u_確認する/.test(e.dataset.hrow));
    const k = document.querySelector('[data-hset="kobun"]'); k.click(); await new Promise(r => setTimeout(r, 80)); const kob = [...document.querySelectorAll('[data-hrow]')].some(e => e.dataset.hrow === 'p_k_dekiru'); document.querySelector('[data-hset="kobun"]').click(); return { u, kob, saved: JSON.parse(localStorage.getItem('fz.proofUser') || '[]').length }; });
  if (!(r.u && r.kob && r.saved === 1)) bad('own rules and the official-style set can be switched on', r);

  /* 構成の型：型で作った文書は、型の節が無い・書きかけを見る */
  r = await page.evaluate(async () => { const d0 = FZ.newDoc(); FZ.app.ed.setDoc(d0); FZ.app.ed.dirty = false; FZ.app.render(); FZ.app.run('skeleton'); await new Promise(r => setTimeout(r, 60)); const sel = document.querySelector('#sub select[name="where"]'); if (sel) { sel.value = 'new'; sel.dispatchEvent(new Event('change')); } document.querySelector('#sub [data-act="t0"]').click(); await new Promise(r => setTimeout(r, 150));
    const ed = FZ.app.ed; const kata = ed.doc.kata; const q = ed.doc.lines.findIndex(l => l.segs[0].text === '課題'); ed.mutate('', () => ed.removeLine(q)); FZ.app.render(); if (FZ.app.st.side !== 'health') FZ.app.run('health'); else FZ.app.run('health'), FZ.app.run('health'); await new Promise(r => setTimeout(r, 120));
    const rows = [...document.querySelectorAll('[data-hrow]')].map(e => e.dataset.hrow); return { kata, rows, src: /#型 report/.test(FZ.serialize(ed.doc)) }; });
  if (!(r.kata === 'report' && r.rows.includes('k_missing') && r.rows.includes('k_left') && r.src)) bad('a document made from a structure template is checked for its sections and leftover guides', r);

  /* 帯：編集の「整える」に診断 */
  r = await page.evaluate(() => FZ.app._menu().GROUPS.edit.items.some(it => it.cmd === 'health')); if (!r) bad('the health check is on the edit band');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-115b-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
