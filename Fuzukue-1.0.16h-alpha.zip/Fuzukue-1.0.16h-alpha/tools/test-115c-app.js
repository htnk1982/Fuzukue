/* 1.0.15c：刷りの専用の器・SVG を Word と PowerPoint に線画のまま（svgBlip）・PowerPoint の流れ図を 1 つのまとまりに・往復の自己診断・Word の図形の字の取り込み */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="100" viewBox="0 0 200 100"><rect x="10" y="10" width="180" height="80" fill="none" stroke="#000"/><text x="100" y="55" text-anchor="middle">線画</text></svg>';
  await page.evaluate(async svg => { const d = FZ.parse(['#fzk 2', '---', '[番号1]図の試験', '本文の一行目。', '#図版 g1 図 線画の図 g.svg', '後ろの本文。', ''].join('\n')); d.images = { 'g.svg': { mime: 'image/svg+xml', data: btoa(unescape(encodeURIComponent(svg))) } };
    const ln = d.lines.find(l => l.segs[0].text === '本文の一行目。'); ln.attrs.figure = undefined; await FZ.app.loadText(FZ.serialize(d), 's.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 150)); }, SVG);

  /* SVG：Word・PowerPoint に PNG と線画（svgBlip）の両方。種類の宣言も */
  let r = await page.evaluate(async () => { const od = await FZ.app.officeDoc(FZ.app.ed.doc); const dec = f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data);
    const W = FZ.toDocx(od, { files: true }); const D = dec(W.find(f => f.name === 'word/document.xml')), CT = dec(W.find(f => f.name === '[Content_Types].xml')), RL = dec(W.find(f => f.name === 'word/_rels/document.xml.rels'));
    const P = FZ.toPptx(od, { files: true }); const S = P.filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f.name)).map(dec).join(''), PCT = dec(P.find(f => f.name === '[Content_Types].xml')), PR = P.filter(f => /slides\/_rels/.test(f.name)).map(dec).join('');
    return { conv: !!od.images['g.svg'].svg, wBlip: /asvg:svgBlip[^>]*r:embed="rIdImgS1"/.test(D), wFiles: W.some(f => f.name === 'word/media/image1.svg') && W.some(f => f.name === 'word/media/image1.png'), wCT: /Extension="svg" ContentType="image\/svg\+xml"/.test(CT), wRel: /rIdImgS1[^>]*media\/image1\.svg/.test(RL),
      pBlip: /asvg:svgBlip/.test(S), pFiles: P.some(f => f.name === 'ppt/media/image1.svg'), pCT: /image\/svg\+xml/.test(PCT), pRel: /media\/image1\.svg/.test(PR) }; });
  if (!Object.values(r).every(Boolean)) bad('SVG images go to Word and PowerPoint as vectors (svgBlip) with a PNG fallback', r);

  /* PowerPoint：流れ図は 1 つのまとまり（p:grpSp「図（流れ図）」） */
  r = await page.evaluate(async () => { const d = FZ.fromGfm('# 題\n\n```mermaid\nflowchart TD\n  A[受付] --> B[審査] --> C[承認]\n```\n'); d.format.kind = 'slide'; const P = FZ.toPptx(d, { files: true }); const S = P.filter(f => /^ppt\/slides\/slide\d+\.xml$/.test(f.name)).map(f => typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data)).join('');
    const m = S.match(/<p:grpSp><p:nvGrpSpPr><p:cNvPr id="\d+" name="図（流れ図）"\/>[\s\S]*?<\/p:grpSp>/); return { group: !!m, inside: m ? /受付/.test(m[0]) && /審査/.test(m[0]) && /tailEnd/.test(m[0]) : false }; });
  if (!(r.group && r.inside)) bad('a flowchart is one group in PowerPoint', r);

  /* 刷りの専用の器：画面の頁に触らずに、器に頁を組む。刷り終われば空に */
  r = await page.evaluate(async () => { const before = document.querySelectorAll('.pgwrap').length; window.print = () => { window.__printed = { root: document.querySelectorAll('#printRoot .pgp').length, cls: document.body.classList.contains('printing'), svg: document.querySelectorAll('#printRoot .pgp > svg').length }; };
    FZ.app.run('print'); await new Promise(r => setTimeout(r, 300)); window.dispatchEvent(new Event('afterprint')); await new Promise(r => setTimeout(r, 50));
    return { p: window.__printed, after: document.querySelector('#printRoot').innerHTML.length, cls: document.body.classList.contains('printing'), pages: FZ.app.ed.lay.pages.length, wraps: document.querySelectorAll('.pgwrap').length === before }; });
  if (!(r.p && r.p.root === r.pages && r.p.svg === r.pages && r.p.cls && r.after === 0 && !r.cls && r.wraps)) bad('printing builds pages in a dedicated print root and clears it afterwards', r);

  /* 往復の自己診断：原本・Markdown・Word の結果を変換の記録の欄に */
  r = await page.evaluate(async () => { FZ.app.run('selfCheck'); for (let k = 0; k < 40 && !(FZ.app.st.convLog && FZ.app.st.convLog.target === 'self'); k++) await new Promise(r => setTimeout(r, 100)); const C = FZ.app.st.convLog; return { side: FZ.app.st.side, title: C && C.title, items: C ? C.items.map(i => i.what) : [] }; });
  if (!(r.side === 'conv' && r.title === '往復の自己診断' && r.items.some(x => /^原本（\.fzk）：書いて読み戻すと同じ/.test(x)) && r.items.some(x => /^Markdown：/.test(x)) && r.items.some(x => /^Word：/.test(x)))) bad('self check reports the .fzk, Markdown and Word round trips', r);

  /* Word の図形のまとまりの字（プ譜を Word に出して読み戻す）：本文の段落に入る */
  r = await page.evaluate(async () => { const d = FZ.parse(['#fzk 2', '---', '[番号1 プ譜]プ譜：試験', '[項目1]獲得目標の字', '[項目2]勝利条件の字', '[項目3]中間目的の字', '[項目4]施策の字', ''].join('\n')); const buf = FZ.zip(FZ.toDocx(d, { files: true, flow: true })); const R = await FZ.fromDocx(buf); const t = FZ.serialize(R.doc); return ['獲得目標の字', '勝利条件の字', '中間目的の字', '施策の字'].every(x => t.includes(x)); });
  if (!r) bad('text inside Word drawing groups comes back as paragraphs');
  await browser.close();
  console.log(fails ? 'FAIL ' + fails + '\n' + errors.join('\n') : (errors.length ? 'ERRORS\n' + errors.join('\n') : 'test-115c-app OK'));
  process.exit(fails || errors.length ? 1 : 0);
})();
