/* 1.0.15d：表の計算（合計の行・数の列を右揃え・表へ流し込む・Word の式）・検索の拡張（正規表現・一覧・すべて太字・紙面の印）・
 * 引き出し（記号・断片・文庫・物差し）・状態行の次の一手・ガイドのいまいる場所と取扱説明書の節へ */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SRC = '#fzk 2\n---\n[番号1]費用\n令和6年度と令和7年度の費用。平成30年度も。\n#表 列 0,10,20,30,40 様式 格子\n| 項目 | 予算 | 実績 | 率 |\n| 人件費 | 1,200 | △300 | 12.5% |\n| 物件費 | 3,400 | 500 | 7.5% |\n後ろの本文。\n';
  const load = src => page.evaluate(async s => { await FZ.app.loadText(s, 't.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 60)); }, src);
  const body = () => page.evaluate(() => FZ.serialize(FZ.app.ed.doc).split('---\n')[1]);
  const at = (line, seg = 0, off = 0) => page.evaluate(([l, s, o]) => { const A = FZ.app; if (A.st.mode !== 'text') A.run('tree'); A.ed.anchor = null; A.ed.caret = { line: l, seg: s, off: o, vcol: null, vrow: 0 }; A.ed.onCaret(); A.render(); }, [line, seg, off]);
  await load(SRC);

  /* 数の読み取りと書き方 */
  let r = await page.evaluate(() => { const T = FZ.tbl; return { a: T.parseNum('1,234').v, b: T.parseNum('１２３').v, c: T.parseNum('△300').v, d: T.parseNum('1,200千円').unit, e: T.parseNum('2024年'), f: T.parseNum('abc'), g: T.fmtNum(-1234.5, { dec: 1, comma: true, neg: '△', unit: '千円' }), h: T.fmtNum(4567, { full: true, comma: true }) }; });
  if (!(r.a === 1234 && r.b === 123 && r.c === -300 && r.d === '千円' && r.e === null && r.f === null && r.g === '△1,234.5千円' && r.h === '４，５６７')) bad('numbers are read with commas, full-width digits, △ and units, and written in the column style', r);

  /* 次の一手：表の中なら 様式・下に行・合計 */
  await at(4, 1); r = await page.evaluate(() => ({ ids: FZ.app._d.nextCmds(), btn: [...document.querySelectorAll('#stNext [data-next]')].map(b => b.dataset.next) }));
  if (!(r.ids.includes('tblSum') && r.btn.includes('tblSum') && r.btn.includes('tableGroup'))) bad('the next-step buttons offer the table style, a row and a sum row inside a table', r);

  /* 合計の行：足す → 数の列を足す（率の列は足さない）、様式は保つ。直すと同じ取消の単位で計算し直す。外す */
  await page.evaluate(() => document.querySelector('#stNext [data-next="tblSum"]').click());
  let b = await body(); const sumLine = b.split('\n').find(l => /合計行/.test(l)) || '';
  if (!(/\| 合計 \| 4,600 \| 200 \|  \|/.test(sumLine) && /様式 格子/.test(b))) bad('a sum row adds the number columns (not the rate column) and keeps the table style', { sumLine, b });
  r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; const n0 = ed.undoStack.length; ed.caret = { line: 3, seg: 1, off: 0, vcol: null, vrow: 0 }; ed.insertText('1'); const t = ed.doc.lines.find(l => l.attrs.sumRow).segs.map(s => s.text); ed.undo(); const u = ed.doc.lines.find(l => l.attrs.sumRow).segs.map(s => s.text); return { t, u, n: ed.undoStack.length - n0 }; });
  if (!(r.t[1] === '14,600' && r.u[1] === '4,600')) bad('editing a number recomputes the sum row in the same undo step', r);
  r = await page.evaluate(() => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.attrs.sumRow); ed.caret = { line: i, seg: 1, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); const a = FZ.app._d.hereTopic(); const nx = FZ.app._d.nextCmds(); FZ.app.run('tr:below'); return { a, nx, sumAt: ed.doc.lines.findIndex(l => l.attrs.sumRow), i }; });
  if (!(r.a[0] === '表の合計の行' && r.nx[0] === 'tblSum' && r.sumAt === r.i + 1)) bad('on the sum row the guide and next step know it, and a row "below" goes above the sum row', r);
  await page.evaluate(() => FZ.app.ed.undo());

  /* 数の列を右揃え（見出しの行は変えない）・もう一度で戻す */
  await at(3, 0); await page.evaluate(() => FZ.app.run('tblNumRight')); b = await body();
  const rows = b.split('\n').filter(l => /^\[?.*\| /.test(l));
  if (!(rows.filter(l => /列揃え左右右右/.test(l)).length === 3 && !/列揃え/.test(rows[0]))) bad('number columns are right-aligned below the header', rows);
  await page.evaluate(() => FZ.app.run('tblNumRight')); b = await body(); if (/列揃え/.test(b)) bad('pressing again returns the number columns to the left', b);

  /* 表へ貼る：カーソルのセルから流し込む。行が足りなければ合計の行の上に足す。はみ出た列は捨てる */
  await at(3, 0); r = await page.evaluate(() => { const dt = new DataTransfer(); dt.setData('text/plain', 'A\t1\t2\nB\t3\t4\nC\t5\t6\t9\tx\n'); document.getElementById('ta').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    const ed = FZ.app.ed; const t = i => ed.doc.lines[i].segs.map(s => s.text).join('|'); return { r3: t(3), r4: t(4), r5: t(5), sum: t(ed.doc.lines.findIndex(l => l.attrs.sumRow)), msg: FZ.app.st.msg }; });
  if (!(r.r3 === 'A|1|2|12.5%' && r.r4 === 'B|3|4|7.5%' && r.r5 === 'C|5|6|9' && r.sum === '合計|9|12|' && /流し込み/.test(r.msg) && /1 セル/.test(r.msg))) bad('pasting tab-separated cells inside a table fills the cells and adds rows above the sum row', r);

  /* Word：合計の行は =SUM の式（素の数の列だけ） */
  await load('#fzk 2\n---\n#表 列 0,10,20,30 様式 格子\n| 項目 | 予算 | 実績 |\n| 人件費 | 1,200 | 300 |\n| 物件費 | 3,400 | 500 |\n[合計行]| 合計 | 4,600 | 800 |\n');
  r = await page.evaluate(async () => { const od = await FZ.app.officeDoc(FZ.app.ed.doc); const W = FZ.toDocx(od, { files: true }); const f = W.find(x => x.name === 'word/document.xml'); const D = typeof f.data === 'string' ? f.data : new TextDecoder().decode(f.data); return D.match(/w:instr="[^"]*"/g) || []; });
  if (!(r.some(x => /=SUM\(B2:B3\)/.test(x)) && r.some(x => /=SUM\(C2:C3\)/.test(x)))) bad('the sum row is written to Word as =SUM fields', r);
  /* 健康診断：外で直した合計の行の食い違い */
  await load('#fzk 2\n---\n#表 列 0,10,20 様式 格子\n| 項目 | 数 |\n| あ | 1 |\n| い | 2 |\n[合計行]| 合計 | 9 |\n');
  r = await page.evaluate(() => { FZ.app.toggleSide('health'); const t = document.querySelector('#sideBody').textContent; FZ.app.toggleSide('health'); return t; });
  if (!/合計の行の食い違い/.test(r)) bad('the health check flags a sum row that does not match', r.slice(0, 200));

  /* 検索：正規表現・置換で $1・すべて太字・一覧・紙面の印 */
  await load(SRC);
  r = await page.evaluate(async () => { const A = FZ.app; A.run('replace'); await new Promise(r => setTimeout(r, 30)); const set = (n, v) => { const el = document.querySelector(`#sub [name="${n}"]`); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); };
    const re = document.querySelector('#sub select[data-name="re"]'); re.value = '1'; re.dispatchEvent(new Event('change', { bubbles: true })); set('n', '(令和|平成)(\\d+)年度'); set('r', '$1$2年度（$&）'); await new Promise(r => setTimeout(r, 30));
    const info = document.querySelector('#findInfo').textContent; document.querySelector('#sub [data-act="list"]').click(); await new Promise(r => setTimeout(r, 40));
    const list = [...document.querySelectorAll('#sideBody .li.fd')].map(x => x.textContent); A.render(); await new Promise(r => setTimeout(r, 40)); const hits = document.querySelectorAll('.ov [data-hit], .ov .hit, .ov rect').length;
    document.querySelector('#sub [data-act="next"]').click(); const sel = A.ed.sel(); const selText = sel ? A.ed.textOf(sel) : '';
    document.querySelector('#sub [data-act="all"]').click(); const after = A.ed.doc.lines[1].segs[0].text;
    set('n', '費用'); const re2 = document.querySelector('#sub select[data-name="re"]'); re2.value = '0'; re2.dispatchEvent(new Event('change', { bubbles: true })); await new Promise(r => setTimeout(r, 30));
    A._d.drawSide(); await new Promise(r => setTimeout(r, 30)); document.querySelector('#sideBody [data-fdact="bold"]').click(); const marks = A.ed.doc.lines[0].segs[0].marks.slice(0, 2).map(m => !!(m & FZ.M.BOLD));
    set('n', '(['); const err = document.querySelector('#findInfo').textContent;
    return { info, list, hits, selText, after, marks, err }; });
  if (!(r.info === '3 件' && r.list.length === 3 && /令和6年度/.test(r.list[0]) && /→「令和6年度（令和6年度）」/.test(r.list[0]))) bad('regex search counts and lists the hits with a replace preview', r);
  if (!(r.selText === '令和6年度' && r.after === '令和6年度（令和6年度）と令和7年度（令和7年度）の費用。平成30年度（平成30年度）も。')) bad('next selects the hit and replace-all uses $1 and $&', r);
  if (!(r.marks[0] && r.marks[1])) bad('bold-all bolds every hit', r);
  r = await page.evaluate(async () => { const A = FZ.app; const re = document.querySelector('#sub select[data-name="re"]'); re.value = '1'; re.dispatchEvent(new Event('change', { bubbles: true })); const el = document.querySelector('#sub [name="n"]'); el.value = '(['; el.dispatchEvent(new Event('input', { bubbles: true })); await new Promise(r => setTimeout(r, 30)); return document.querySelector('#findInfo').textContent; });
  if (!/正規表現の誤り/.test(r)) bad('a broken regex is reported in the find bar', r);
  await page.evaluate(() => { FZ.app.run('replace'); if (FZ.app.st.side) FZ.app.toggleSide(FZ.app.st.side); });

  /* 引き出し：記号（別名で探す・入れる・最近）・断片（〔〕を選ぶ・選んだ字を断片に）・文庫・物差し */
  await load(SRC); await at(1, 0, 2);
  r = await page.evaluate(async () => { const A = FZ.app; A.run('symbols'); await new Promise(r => setTimeout(r, 40)); const q = document.querySelector('#symQ'); q.value = 'こめ'; q.dispatchEvent(new Event('input')); const kome = [...document.querySelectorAll('#symList [data-sym]')].map(b => b.dataset.sym);
    q.value = 'まる1'; q.dispatchEvent(new Event('input')); const m1 = [...document.querySelectorAll('#symList [data-sym]')].map(b => b.dataset.sym);
    document.querySelector('#symList [data-sym="①"]').click(); await new Promise(r => setTimeout(r, 20)); const t = A.ed.doc.lines[1].segs[0].text; const rec = JSON.parse(localStorage.getItem('fz.symRecent') || '[]');
    return { side: A.st.side + ':' + A.st.drawerTab, kome, m1, t, rec }; });
  if (!(r.side === 'drawer:sym' && r.kome.includes('※') && r.m1.includes('①') && r.t.startsWith('令和①') && r.rec[0] === '①')) bad('the symbol drawer finds symbols by alias, inserts at the caret and remembers recent ones', r);
  r = await page.evaluate(async () => { const A = FZ.app; document.querySelector('[data-dtab="snip"]').click(); await new Promise(r => setTimeout(r, 40)); const n = document.querySelectorAll('#snipList .li.sn').length;
    A.ed.caret = { line: 5, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.anchor = null; A.ed.onCaret(); A._d.insertSnippet('標記について、下記のとおり〔通知〕します。'); const s = A.ed.sel(); const selT = s ? A.ed.textOf(s) : '';
    A.ed.anchor = { line: 1, seg: 0, off: 0 }; A.ed.caret = { line: 1, seg: 0, off: 3, vcol: null, vrow: 0 }; A.ed.onCaret(); document.querySelector('[data-dact="snipAdd"]').click(); await new Promise(r => setTimeout(r, 30)); const mine = JSON.parse(localStorage.getItem('fz.snippets') || '[]');
    return { n, selT, mine: mine[0] && mine[0].t, first: document.querySelector('#snipList .li.sn').textContent }; });
  if (!(r.n >= 15 && r.selT === '〔通知〕' && r.mine === '令和①' && /令和①/.test(r.first))) bad('snippets insert with the placeholder selected and the selection can be saved as a snippet', r);
  r = await page.evaluate(async () => { const A = FZ.app; await A._d.libTouch({ path: 'C:\\文書\\報告.fzk', name: '報告.fzk' }, '報告.fzk'); await A._d.libTouch({ path: 'C:\\文書\\計画.fzk', name: '計画.fzk' }, '計画.fzk'); await A._d.libTouch({ path: 'C:\\文書\\報告.fzk', name: '報告.fzk' }, '報告.fzk');
    const L = await A._d.libList(); document.querySelector('[data-dtab="lib"]').click(); await new Promise(r => setTimeout(r, 60)); const rows = [...document.querySelectorAll('#sideBody .li.lb')].map(x => x.textContent);
    document.querySelector('#sideBody [data-libfav="1"]').click(); await new Promise(r => setTimeout(r, 60)); const fav = [...document.querySelectorAll('#sideBody .li.lb')].map(x => x.textContent)[0];
    document.querySelector('[data-dtab="ruler"]').click(); await new Promise(r => setTimeout(r, 40)); const ruler = document.querySelector('#sideBody').textContent;
    return { names: L.map(x => x.name), rows: rows.length, fav, ruler }; });
  if (!(r.names.join() === '報告.fzk,計画.fzk' && r.rows === 2 && /★ 計画/.test(r.fav))) bad('the library lists opened/saved documents once, most recent first, favourites on top', r);
  if (!(/字数/.test(r.ruler) && /400 字詰め/.test(r.ruler) && /この節/.test(r.ruler) && /健康診断/.test(r.ruler))) bad('the ruler tab shows counts, the current section and the health summary', r.ruler.slice(0, 200));
  await page.evaluate(() => FZ.app.run('drawer'));

  /* 次の一手：見出し・選んだ字・本文 */
  r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; const go = (l, sel) => { ed.anchor = sel ? { line: l, seg: 0, off: 0 } : null; ed.caret = { line: l, seg: 0, off: sel ? 2 : 0, vcol: null, vrow: 0 }; ed.onCaret(); return A._d.nextCmds(); }; return { head: go(0), sel: go(1, true), body: go(5) }; });
  if (!(r.head.includes('aiCopySec') && r.sel[0] === 'bold' && r.body.includes('health'))) bad('the next-step buttons follow the place: heading, selection, plain text', r);

  /* ガイドのいまいる場所 → 取扱説明書のその節へ */
  await at(4, 1);
  r = await page.evaluate(async () => { const A = FZ.app; A.toggleSide('help'); await new Promise(r => setTimeout(r, 40)); const here = document.querySelector('#helpHere').textContent; const sec = document.querySelector('#helpHere [data-act="manualSec"]').dataset.sec; A.toggleSide('help');
    await A.loadText(FZ.manualText(), '取扱説明書.fzk', null); A._d.manualJump('表の計算'); await new Promise(r => setTimeout(r, 400)); const ln = A.ed.doc.lines[A.ed.caret.line]; return { here, sec, line: ln.segs.map(s => s.text).join(''), style: ln.attrs.style }; });
  if (!(/表/.test(r.here) && r.sec === '表' && r.line === '表の計算' && r.style === 'num')) bad('the guide shows where you are and jumps to that section of the manual', r);
  r = await page.evaluate(() => { const m = FZ.manualText(); const g = FZ.guideText(); return ['表の計算', '合計の行', '次の一手', '引き出し', '正規表現', '文庫'].filter(w => !m.includes(w) || (w !== '表の計算' && w !== '次の一手' && !g.includes(w))); });
  if (r.length) bad('the manual and the guide describe the new features', r);

  await browser.close();
  if (errors.length) { console.log(errors.join('\n')); }
  console.log(fails || errors.length ? `test-115d-app fails=${fails} errors=${errors.length}` : 'test-115d-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
