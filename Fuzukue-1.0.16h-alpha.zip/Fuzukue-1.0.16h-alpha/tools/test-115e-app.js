/* 1.0.15e：集中の表示・頁の地図（C-5）、原本の面（C-3）、ツリーの子孫の数と畳みの記憶（C-4）、ほかの文書と比べる（C-11）、組版の点検（B-6） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const L = ['#fzk 2', '---', '[表題]試験の文書']; for (let k = 1; k <= 5; k++) { L.push(`[番号1]第${k}の章`); for (let j = 0; j < 14; j++) L.push(`第${k}章の${j + 1}番目の段落。集中の表示と頁の地図を確かめるための文で、字を並べて行を作る。`); L.push(`[項目1]第${k}章の項目`, `[項目2]第${k}章の子の項目`); }
  const SRC = L.join('\n') + '\n';
  const load = (src, ref) => page.evaluate(async ([s, r]) => { await FZ.app.loadText(s, 't.fzk', r); FZ.app.render(); await new Promise(r => setTimeout(r, 120)); }, [src, ref || null]);
  await load(SRC);

  /* 集中の表示：節のほかを覆う。もう一度でやめる。刷りには出ない */
  let r = await page.evaluate(async () => { const A = FZ.app; A.ed.caret = { line: 20, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.run('focusMode'); A.render(); await new Promise(r => setTimeout(r, 100)); const on = document.querySelectorAll('.ov rect.dim').length;
    const pr = A.renderForPrint ? A.renderForPrint(false) : ''; A.run('focusMode'); A.render(); await new Promise(r => setTimeout(r, 100)); return { on, off: document.querySelectorAll('.ov rect.dim').length, pages: A.ed.lay.pages.length, print: /class="dim"/.test(String(pr)) }; });
  if (!(r.on >= r.pages - 1 && r.off === 0 && !r.print)) bad('focus mode covers the other sections and turns off again (not printed)', r);

  /* 頁の地図：頁の区切り・章・いま見ている所。棒を押すとその行へ */
  r = await page.evaluate(async () => { const A = FZ.app; A.render(); await new Promise(r => setTimeout(r, 100)); const pm = document.getElementById('pageMap'); const pg = pm.querySelectorAll('.pm-pg').length, h = pm.querySelectorAll('.pm-h').length, v = !!pm.querySelector('.pm-view');
    const third = pm.querySelectorAll('.pm-h')[2]; const target = +third.dataset.pml; third.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); await new Promise(r => setTimeout(r, 60));
    A.run('pageMap'); const hidden = pm.hidden; A.run('pageMap'); return { shown: !pm.hidden || !hidden, pg, h, v, pages: A.ed.lay.pages.length, caret: A.ed.caret.line, target, hidden }; });
  if (!(r.pg === r.pages - 1 && r.h === 5 && r.v && r.caret === r.target && r.hidden)) bad('the page map shows pages, chapters and the view, jumps on click and can be hidden', r);

  /* 原本の面：カーソルの節の原本。直すと紙面へ（1 回の取消）。紙面で直すと欄が追う。読めない原本は紙面を変えない */
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; ed.caret = { line: 18, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('srcPane'); await new Promise(r => setTimeout(r, 80)); const ta = document.querySelector('#srcTa');
    const first = ta.value.split('\n')[0]; const info = document.querySelector('#srcInfo').textContent; const n0 = ed.doc.lines.length, u0 = ed.undoStack.length;
    ta.focus(); ta.value = ta.value.replace('[番号1]第2の章', '[番号1]第二の章').replace('第2章の1番目の段落。集中の表示と頁の地図を確かめるための文で、字を並べて行を作る。', '第2章の1番目の段落。集中の表示と頁の地図を確かめるための文で、字を並べて行を作る。\n[項目1]原本で足した項目'); ta.dispatchEvent(new Event('input')); await new Promise(r => setTimeout(r, 1000));
    const i = ed.doc.lines.findIndex(l => l.segs[0].text === '第二の章'); const added = ed.doc.lines[i + 2]; const res = { first, info, head: i, style: ed.doc.lines[i] && ed.doc.lines[i].attrs.style, added: added && added.segs[0].text, list: !!(added && added.attrs.list), grew: ed.doc.lines.length - n0, undoN: ed.undoStack.length - u0 };
    ta.blur(); ed.undo(); res.undone = ed.doc.lines.some(l => l.segs[0].text === '第2の章') && ed.doc.lines.length === n0; A.render(); await new Promise(r => setTimeout(r, 80)); res.follow = /\[番号1\]第2の章/.test(document.querySelector('#srcTa').value);
    document.querySelector('#srcTa').blur(); A.toggleSide('src'); return res; });
  if (!(r.first === '[番号1]第2の章' && /節「第2の章」/.test(r.info) && r.style === 'num' && r.added === '原本で足した項目' && r.list && r.grew === 1 && r.undoN === 1 && r.undone && r.follow)) bad('the source pane edits the section and syncs both ways with one undo step', r);

  /* ツリー：子孫の数、消すと知らせに子孫の数、畳みと深さは保存先のある文書ごとに覚える */
  await load(SRC, { path: 'C:\\試験\\t.fzk', name: 't.fzk' });
  r = await page.evaluate(async () => { const A = FZ.app; A.ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.run('outlinePanel'); await new Promise(r => setTimeout(r, 100)); const pos = document.getElementById('stPos').textContent; const f0 = document.querySelectorAll('#tree [data-fold]').length;
    A.run('tv:fold'); await new Promise(r => setTimeout(r, 50)); A.run('outlinePanel'); await new Promise(r => setTimeout(r, 50)); const mem = JSON.parse(localStorage.getItem('fz.tmem.C:\\試験\\t.fzk') || 'null');
    return { pos, mem, f0 }; });
  const f0 = r.f0;
  if (!(/子 \d+・子孫 \d+/.test(r.pos) && r.mem && r.mem.f.length === 1 && r.mem.f[0].t === '第1の章')) bad('the tree shows descendants and remembers folds per file', r);
  await load(SRC, { path: 'C:\\試験\\t.fzk', name: 't.fzk' });
  r = await page.evaluate(async () => { const A = FZ.app; A.ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.run('outlinePanel'); await new Promise(r => setTimeout(r, 100)); const folded = document.querySelectorAll('#tree [data-fold]').length;
    A.run('tv:del'); const m = A.st.msg; A.ed.undo(); A.run('outlinePanel'); return { folded, m }; });
  if (!(r.folded === f0 + 1 && /子孫 \d+ 個も/.test(r.m))) bad('reopening the same file restores folds, and deleting reports descendants', r);

  /* ほかの文書と比べる：違いを 1 つずつ。取り込むまで今の文書は変わらない */
  await load(SRC);
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; const other = FZ.serialize(ed.doc).replace('第3章の2番目の段落。', '第3章の2番目の段落（直した）。'); const before = FZ.serialize(ed.doc);
    A.ed.caret = { line: 0, seg: 0, off: 0, vcol: null, vrow: 0 }; await A._e.compareText(other, '案.fzk'); const sub = document.getElementById('sub').textContent; const same = FZ.serialize(ed.doc) === before; const n = A.st.aiBack ? A.st.aiBack.hunks.length : -1; const m = A.st.msg;
    document.querySelector('#sub [data-act="cancel"], #sub [data-act="close"]') && document.querySelector('#sub [data-act="cancel"], #sub [data-act="close"]').click(); return { sub: sub.slice(0, 40), same, n, m }; });
  if (!(r.same && r.n === 1 && /「案\.fzk」との違い 1 か所/.test(r.m) && /文書と比べる/.test(r.sub))) bad('comparing with another document lists the differences without changing the document', r);

  /* 組版の点検：頁の下の大きな空き（理由つき）・孤立行 */
  const T = ['#fzk 2', '---', '[番号1]組版の点検']; for (let j = 0; j < 20; j++) T.push(`段落${j + 1}。` + 'あ'.repeat(30)); T.push('[分割禁止]' + 'い'.repeat(40 * 25)); for (let j = 0; j < 3; j++) T.push('う'.repeat(30));
  await load(T.join('\n') + '\n');
  r = await page.evaluate(() => { const A = FZ.app; A.toggleSide('health'); const t = document.querySelector('#sideBody').textContent; A.toggleSide('health'); return t; });
  if (!(/組版/.test(r) && /頁の下の大きな空き/.test(r))) bad('the health check reports a large gap at the bottom of a page', r.slice(0, 300));

  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['原本の面', '集中の表示と頁の地図', 'ほかの文書と比べる', '子孫'].filter(w => !m.includes(w)).concat(['集中・頁の地図', '原本の面', 'ほかの文書と比べる'].filter(w => !g.includes(w))); });
  if (r.length) bad('the manual and the guide describe the new features', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-115e-app fails=${fails} errors=${errors.length}` : 'test-115e-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
