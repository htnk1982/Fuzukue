/* 1.0.15f：道具箱（記録・使う・Alt+数字・名前で足す・設定の書き出し）、はじめの一枚 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { await FZ.app.loadText('#fzk 2\n---\n一行目の本文。\n二行目の本文。\n三行目の本文。\n', 't.fzk', null); FZ.app.render(); });

  /* 記録：コマンドと引き出しの記号を順に覚える。打った字・道具箱を開くことは覚えない */
  let r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; A.run('tools'); await new Promise(r => setTimeout(r, 60)); document.querySelector('[data-tact="recStart"]').click(); await new Promise(r => setTimeout(r, 30));
    const guide = document.getElementById('stGuide').textContent; ed.caret = { line: 0, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('alignC'); ed.insertText('字'); A._d.insertSym('※'); A.run('bold');
    A.run('tools'); A.run('tools'); await new Promise(r => setTimeout(r, 40)); const n = document.getElementById('recN') && document.getElementById('recN').textContent; document.querySelector('[data-tact="recStop"]').click(); await new Promise(r => setTimeout(r, 40));
    const T = A._f.toolsGet(); return { guide, n, steps: T[0] && T[0].steps, open: !!document.querySelector('#sideBody .tled') }; });
  if (!(/記録中/.test(r.guide) && r.n === '3' && JSON.stringify(r.steps) === JSON.stringify([{ cmd: 'alignC' }, { text: '※' }, { cmd: 'bold' }]) && r.open)) bad('recording keeps commands and drawer symbols in order, not typed text or the toolbox itself', r);

  /* 名前と Alt+数字、使う（Alt+1）。1 手ずつ取消。名前で足す */
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; const nm = document.querySelector('[data-tname="0"]'); nm.value = '中央に印'; nm.dispatchEvent(new Event('change')); const ks = document.querySelector('[data-tkey="0"]'); ks.value = '1'; ks.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 40));
    ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.anchor = null; ed.onCaret(); document.getElementById('ta').dispatchEvent(new KeyboardEvent('keydown', { key: '1', altKey: true, bubbles: true, cancelable: true })); await new Promise(r => setTimeout(r, 40));
    const ln = ed.doc.lines[1]; const res = { name: A._f.toolsGet()[0].name, key: A._f.toolsGet()[0].key, align: ln.attrs.align, text: ln.segs[0].text, m: A.st.msg };
    const q = document.querySelector('[data-tq="0"]'); if (q) { q.value = '下線'; document.querySelector('[data-tadd="0"]').click(); await new Promise(r => setTimeout(r, 30)); } res.added = A._f.toolsGet()[0].steps.slice(-1)[0];
    const exp = JSON.parse(JSON.stringify(A._f.toolsGet())); res.exp = exp.length; return res; });
  if (!(r.name === '中央に印' && r.key === '1' && r.align === 'center' && r.text.startsWith('※') && /3 \/ 3 手/.test(r.m))) bad('a tool gets a name and Alt+number and runs its steps', r);
  if (!(r.added && r.added.cmd && /under/i.test(r.added.cmd))) bad('a command can be added to a tool by its name', r);

  /* はじめの一枚：付箋 5 枚、キーは今の割り当てから */
  r = await page.evaluate(() => { const d = FZ.app._f.practiceDoc(); const n = d.notes.length; const lines = d.lines.filter(l => l.attrs.notes).length; const t = d.notes.map(x => x.text).join(' '); return { n, lines, keys: /F\d/.test(t), table: d.lines.some(l => l.attrs.cells), title: d.lines[0].attrs.style }; });
  if (!(r.n === 5 && r.lines === 5 && r.keys && r.table && r.title === 'title')) bad('the practice sheet has five step notes with the current key paths', r);

  /* 1.0.15g F キーは 2 段（上 F1〜F5・下 F6〜F10）。項目が下へ回るほど狭い窓では 1 段 */
  const fk = () => page.evaluate(() => { const ks = [...document.querySelectorAll('#fkeys .fk')].map(e => e.getBoundingClientRect()); const s = document.getElementById('sub').getBoundingClientRect(), f = document.getElementById('fkeys').getBoundingClientRect(); return { two: document.getElementById('fkeys').classList.contains('two'), row1: ks.slice(0, 5).every(k => Math.abs(k.top - ks[0].top) < 1), f6Below: ks[5].top > ks[0].bottom - 1, f6UnderF1: Math.abs(ks[5].left - ks[0].left) < 1, w: Math.round(f.width), beside: s.left >= f.right - 1 && s.top < f.bottom }; });
  await page.setViewportSize({ width: 1000, height: 800 }); await page.waitForTimeout(80); await page.evaluate(() => { FZ.app.run('tableMenu'); }); r = await fk();
  if (!(r.two && r.row1 && r.f6Below && r.f6UnderF1 && r.w < 220 && r.beside)) bad('F keys sit in two rows of five and the band fits beside them at 1000px', r);
  await page.setViewportSize({ width: 700, height: 800 }); await page.waitForTimeout(80); r = await fk();
  if (r.two) bad('on a narrow window where the band drops below anyway, the F keys go back to one row', r);
  await page.setViewportSize({ width: 1300, height: 1000 }); await page.waitForTimeout(80);
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['道具箱', 'はじめの一枚', 'Alt+1〜9'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe the toolbox and the practice sheet', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-115f-app fails=${fails} errors=${errors.length}` : 'test-115f-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
