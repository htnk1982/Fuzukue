/* 1.0.16a：下読み（機械）の規則・文書の種類・基準ファイル・健康診断の「下読み」、照合（数・否定・敬称・日付） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const load = src => page.evaluate(async s => { await FZ.app.loadText(s, 't.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 60)); }, src);
  const SRC = '#fzk 2\n---\n[表題]第3四半期の販売状況\n売上は 120 億円で、15% 増加した。\n[番号1]概要\n近年、市場環境は変化している。当社もさまざまな取り組みを行ってきた。顧客との関係構築も進めている。\n営業部門との連携を強化した。\n月次の会議を開催しました。\n上表のとおり、在庫は減った。\n必要な人員だけ配置している。\n今後、販売体制を見直す。\n2026年11月9日（火）に説明会を開く。\n渡辺部長に報告し、渡辺部長の了承を得た。渡辺さんにも共有した。\nこれは営業本部の第一部の企画課の方針である。\n';
  await load(SRC);
  const rules = kind => page.evaluate(k => FZ.reviewIssues(FZ.app.ed.doc, { kind: k }).map(x => x.rule + '@' + x.line + ':' + x.text), kind);

  /* 1. 規則：報告の文書では 13 の規則がそれぞれの所で当たる */
  let r = await rules('報告'); const want = ['cmpBase@1:増加', 'vagueRef@6:上表', 'emptyEnd@4:強化', 'activity@5:月次の会議を開催しました。', 'misread@7:必要な人員だけ', 'noDue@8:今後', 'late@3:近年、市場環境は変化している。', 'dateDow@9:2026年11月9日（火）', 'long@3:段落', 'honor@10:渡辺さん'];
  const miss = want.filter(w => !r.includes(w)); if (!r.some(x => /^ambig@11:.*営業本部の第一部の企画課の/.test(x))) miss.push('ambig@11'); if (miss.length) bad('each review rule hits its place in a report', { miss, got: r });
  /* 種類が無ければ、報告・評価向けの規則（活動・結論・期限・表）は効かない */
  r = await rules(''); if (r.some(x => /^(activity|late|noDue|tableRead)@/.test(x)) || !r.some(x => /^cmpBase@/.test(x))) bad('without a document kind only the universal rules run', r);

  /* 2. 表の読み方：数のある表の前後 2 行に読み方が無いと当たる。読み方の文があれば当たらない */
  await load('#fzk 2\n---\n[番号1]費用\n費用の内訳。\n#表 列 0,10,20 様式 格子\n| 項目 | 予算 |\n| 人件費 | 1,200 |\n| 物件費 | 3,400 |\n以上。\n');
  r = await rules('報告'); if (!r.some(x => x.startsWith('tableRead@'))) bad('a table of numbers without a reading sentence is flagged', r);
  await load('#fzk 2\n---\n[番号1]費用\n費用の内訳。\n#表 列 0,10,20 様式 格子\n| 項目 | 予算 |\n| 人件費 | 1,200 |\n| 物件費 | 3,400 |\n物件費が人件費の 2.8 倍と最も大きい。\n');
  r = await rules('報告'); if (r.some(x => x.startsWith('tableRead@'))) bad('a reading sentence after the table clears the table rule', r);

  /* 3. 会議資料：大見出しが名札。動詞か数のある見出しは当たらない */
  await load('#fzk 2\n---\n[番号1]現状と課題\n売上は前年比 5% 増。\n[番号1]在庫を 2 割減らす\n倉庫を 1 つ閉じる。\n');
  r = await rules('会議資料'); if (!(r.includes('nameHead@0:1　現状と課題') || r.some(x => /^nameHead@0:/.test(x))) || r.some(x => /^nameHead@2:/.test(x))) bad('meeting papers flag noun-only headlines but not message headlines', r);

  /* 4. 基準ファイル：頭の --- の間を読み、空語・誤読を招く語は既定に足す。一文の上限で長い文 */
  r = await page.evaluate(() => { const t = FZ.parseStd(FZ.stdTemplate()); const u = FZ.parseStd('---\n種類: 基準\n名前: 役員会\n一文の上限: 30\n箇条書き既定: いいえ\n空語: 見える化\n誤読を招く語: 一定の*を確保\n---\n## 実例\n'); const no = FZ.parseStd('# ただの文書\n本文'); const other = FZ.parseStd('---\n種類: 型\n---\n');
    const d = FZ.parse('#fzk 2\n---\n業務の見える化。\n一定の品質を確保している。\nこの文は三十字を超えるように、わざと少しだけ長めに書き足してある文である。\n'); const P = FZ.reviewIssues(d, { std: u, kind: '' }).map(x => x.rule);
    return { tname: t && t.name, tmax: t && t.maxSent, tkinds: t && t.kinds, u: u && { name: u.name, max: u.maxSent, bul: u.bullets, empty: u.empty.includes('見える化') && u.empty.includes('強化'), body: /実例/.test(u.body) }, no, other, P }; });
  if (!(r.tname && r.tmax === 60 && r.tkinds.length === 4 && r.u && r.u.name === '役員会' && r.u.max === 30 && r.u.bul === false && r.u.empty && r.u.body && r.no === null && r.other === null)) bad('a standard file is read from its front matter and adds to the defaults', r);
  if (!(r.P.includes('emptyEnd') && r.P.includes('misread') && r.P.includes('long'))) bad('the words and the sentence limit of a loaded standard take effect', r);

  /* 5. 健康診断の「下読み」：入れると欄の頭に行が出る。構造の「長い文」は下読みが受け持つ。文書の種類は原本に覚え、Ctrl+Z で戻る */
  await load(SRC);
  r = await page.evaluate(async () => { const A = FZ.app; A._g.reviewSet(false); A._g.stdSet(null); A.run('review'); await new Promise(r => setTimeout(r, 80)); const H = A._g.healthGet(); const body = document.getElementById('sideBody');
    const res = { side: A.st.side, msg: A.st.msg, secs: [...new Set(H.rows.map(x => x.sec))], rev: H.rows.filter(x => x.sec === '読み手の問い').map(x => x.key + ':' + x.n + (x.info ? 'i' : '')), sLong: H.rows.some(x => x.key === 's_long'), box: !!body.querySelector('.hrev select[data-hkind]'), cb: !!body.querySelector('[data-hrev]:checked') };
    const sel = body.querySelector('[data-hkind]'); sel.value = '報告'; sel.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 60)); const H2 = A._g.healthGet(); res.kind = A.ed.doc.kind; res.ser = /#文書の種類 報告/.test(FZ.serialize(A.ed.doc)); res.rev2 = H2.rows.filter(x => x.sec === '読み手の問い').map(x => x.key);
    const back = FZ.parse(FZ.serialize(A.ed.doc)); res.round = back.kind; A.ed.undo(); res.undone = A.ed.doc.kind || ''; return res; });
  if (!(r.side === 'health' && /読み手の問い/.test(r.msg) && r.secs[0] === '読み手の問い' && r.box && r.cb)) bad('the review command turns the review on and puts its group at the head of the health panel', r);
  if (r.sLong) bad('with the review on, long sentences are reported once (by the review)', r);
  if (r.rev.some(x => /^v_(activity|late)/.test(x)) || !['v_activity', 'v_late', 'v_noDue'].every(k => r.rev2.includes(k))) bad('choosing the kind 報告 adds the report rules', r);
  if (!(r.kind === '報告' && r.ser && r.round === '報告' && r.undone === '')) bad('the document kind is kept in the source and undone with Ctrl+Z', r);
  if (!r.rev.some(x => /^v_honor:\d+i$/.test(x)) || r.rev.some(x => /^v_cmpBase:\d+i$/.test(x))) bad('整 rows are informational, 直 rows count as things to fix', r);

  /* 6. 日付と曜日：直す（1 回の Ctrl+Z）。無視は文書に覚える */
  r = await page.evaluate(async () => { const A = FZ.app; const body = () => document.getElementById('sideBody'); A.st.healthOpen = 'v_dateDow'; A._d.drawSide(); await new Promise(r => setTimeout(r, 40)); const b = body().querySelector('[data-hfix="v_dateDow:0"]'); if (b) b.click(); await new Promise(r => setTimeout(r, 60));
    const t = A.ed.doc.lines[9].segs[0].text; A.st.healthOpen = 'v_misread'; A._d.drawSide(); await new Promise(r => setTimeout(r, 40)); const ig = body().querySelector('[data-hign="v_misread:0"]'); if (ig) ig.click(); await new Promise(r => setTimeout(r, 60));
    const H = A._g.healthGet(); return { t, ign: (A.ed.doc.proofIgnore || []).slice(), mis: H.rows.some(x => x.key === 'v_misread'), ser: /#点検無視 r_misread\|必要な人員だけ/.test(FZ.serialize(A.ed.doc)) }; });
  if (!/11月9日（月）/.test(r.t)) bad('the weekday is fixed from the health panel', r);
  if (!(r.ign.includes('r_misread|必要な人員だけ') && !r.mis && r.ser)) bad('ignoring a review hit is remembered in the document', r);

  /* 7. 照合：数・否定・敬称・日付の違い。同じなら何も出さない */
  r = await page.evaluate(() => { const a = FZ.collate('売上は 120 億円で、前年比 15% 増加した。11月9日（月）に渡辺部長が説明する。', '売上は 150 億円で、前年比 15% 増加しなかった。11月10日（火）に渡辺さんが説明する。'); const same = FZ.collate('売上は１２０億円。', '売上は 120 億円。'); const lost = FZ.collate('参加者は 30 人、欠席は 2 人。', '参加者は 30 人。');
    return { kinds: a.items.map(x => x.kind), text: a.text, same: same.n, lost: lost.text }; });
  if (!(['日付', '数', '否定', '敬称'].every(k => r.kinds.includes(k)) && /120億円→150億円/.test(r.text) && /否定が増える/.test(r.text) && /渡辺部長→渡辺さん/.test(r.text) && r.same === 0 && /数が消える 2人/.test(r.lost))) bad('collation reports numbers, negation, honorifics and dates', r);

  /* 8. 取り込む前の照合：ほかの文書と比べると、数が変わる違いに「照合」の印 */
  await load('#fzk 2\n---\n売上は 120 億円だった。\n来期も続ける。\n');
  r = await page.evaluate(async () => { const A = FZ.app; A._e.compareText('#fzk 2\n---\n売上は 150 億円だった。\n来期も続ける。\n', '別.fzk'); await new Promise(r => setTimeout(r, 80)); const b = document.querySelector('#sub .shogo'); return { form: A.st.form, badge: b && b.textContent, title: b && b.title }; });
  if (!(r.form === 'aiback' && r.badge && /数/.test(r.badge) && /120億円→150億円/.test(r.title))) bad('a number change is marked by collation before it is taken in', r);
  await page.evaluate(() => { FZ.app.run('aiReturn'); });

  /* 9. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['下読み', '照合', '基準ファイル', '文書の種類'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe the review, collation and the standard file', r);
  await page.evaluate(() => { FZ.app._g.reviewSet(false); });

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116a-app fails=${fails} errors=${errors.length}` : 'test-116a-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
