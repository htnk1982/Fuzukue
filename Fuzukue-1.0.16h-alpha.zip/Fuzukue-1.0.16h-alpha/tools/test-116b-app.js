/* 1.0.16b：AI に頼む（部品棚・種類の推し・核の第 I 部・伏せる名前・上限と削る順・欄・答えの読み取りと取り込み・議事録を新しい文書で） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('dialog', d => d.accept());
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const load = src => page.evaluate(async s => { await FZ.app.loadText(s, 't.fzk', null); FZ.app.render(); await new Promise(r => setTimeout(r, 60)); }, src);
  const SRC = '#fzk 2\n---\n[表題]第3四半期の報告\n#文書の種類 報告\n[番号1]在庫\n期末の在庫は 120 千台で、在庫が増加した。今後、生産を見直す。\n[番号1]販売\n販売は前年比 3% 増えた。\n';
  await load(SRC);
  await page.evaluate(async () => { const A = FZ.app; await A._h.shelfReset(); A._h.rqMasks([]); Object.assign(A._h.rqOpt, { type: 'review', reader: '上位者', scene: 'auto', depth: 'std', scope: 'sec', budget: 40000, namesOnly: false, draft: 'min' }); A.ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); });

  /* 1. 棚が空：内蔵の核と手順。範囲はカーソルの節、場面は本文から（在庫）、機械の下読みも入る */
  let r = await page.evaluate(async () => { const { b, sc, scene } = await FZ.app._h.rqBuildNow(); return { labels: b.items.map(x => x.label), text: b.text, what: sc.what, scene, total: b.total }; });
  if (!(r.labels[0] === '核（内蔵）' && r.labels.includes('型：下読み') && r.labels.some(l => /^基準と読み手（上位者）/.test(l)) && r.labels.some(l => /^機械の下読み/.test(l)) && r.labels.some(l => /^文書/.test(l)) && r.labels.includes('答えの形'))) bad('with an empty shelf the request has the built-in core, the task, the reader, machine findings, the document and the answer form', r.labels);
  if (!(/＝＝判定＝＝/.test(r.text) && /＝＝最小修正稿＝＝/.test(r.text) && /期末の在庫は 120 千台/.test(r.text) && !/販売は前年比/.test(r.text) && /「在庫」の節/.test(r.what) && r.scene === 'inv' && /文書の種類：報告/.test(r.text))) bad('the request carries the cursor section, the guessed scene and the document kind', { what: r.what, scene: r.scene, head: r.text.slice(0, 200) });
  const order = ['# 核', '# 頼む仕事', '# 基準と読み手', '# 文机が既に見つけた所', '# 文書', '# 答えの形'].map(h => r.text.indexOf(h)); if (order.some((x, k) => x < 0 || (k && x < order[k - 1]))) bad('the parts come in the fixed order', order);

  /* 2. 棚：種類を推し、核は第 I 部だけ、残りは知識の候補。基準・型の人名は伏せる名前の候補になり、依頼では置き換わる */
  r = await page.evaluate(async () => { const A = FZ.app; const core = '# 汎用の決まり\n## 前書き\n使い方。\n# 第I部　実行プロンプト\n## 1. 役割\n編集責任者として直す。\n# 第II部　知識\n## A4. 在庫・資産の型\n在庫は保有日数で語る。在庫の増減は起点を書く。在庫回転も。\n';
    const std = '# 審査コンパイラ\n## 必ず問われること\n- 何と比べて？ 渡辺部長はこう問う。\n## 規則 W01\n渡辺部長は結論を先に求める。渡辺信一さんの指導。\n## 実例\n渡辺部長の朱：上表参照は不可。\n';
    const r1 = await A._h.shelfAdd([{ name: '汎用資料・作文コンパイラv2.0.md', text: core }, { name: '渡辺部長向け最終審査v2.1.md', text: std }, { name: '畑中文体v1.0.md', text: '# 文体\n## 現在形\n短く書く。\n' }, { name: 'Copilot校正推敲v1.0.md', text: '# 校正の手順\n## 校正\n誤字を直す。\n' }, { name: 'SCMデータバンク.md', text: '# データバンク\n## 在庫の書き方\n在庫は在庫日数と在庫金額で。在庫の前月比。\n## 販売の書き方\n販売は受注と分ける。\n' }]);
    const sh = await A._h.shelfLoad(); const { b } = await A._h.rqBuildNow(); return { r1, kinds: sh.map(p => p.name.slice(0, 6) + ':' + p.kind), masks: A._h.rqMasks(), labels: b.items.map(x => x.label), text: b.text }; });
  const k = r.kinds.join(' '); if (!(/汎用資料・作:核/.test(k) && /渡辺部長向け:基準/.test(k) && /畑中文体v1:書き手/.test(k) && /Copilo:型/.test(k) && /SCMデータ:知識/.test(k))) bad('part kinds are guessed from the file names', r.kinds);
  if (!(/編集責任者として直す/.test(r.text) && !/使い方。/.test(r.text) && /在庫は保有日数で語る/.test(r.text) && /在庫は在庫日数と在庫金額で/.test(r.text) && !/販売は受注と分ける/.test(r.text))) bad('the core sends part I only and the rest feeds the scene knowledge', r.labels);
  if (!(r.masks.some(m => m.from === '渡辺' && m.to === '上位者' && m.person) && !/渡辺/.test(r.text) && /上位者は結論を先に求める/.test(r.text) && /上位者の指導/.test(r.text))) bad('names in the parts are masked by surname (full name, title and honorific)', { masks: r.masks, has: /渡辺/.test(r.text) });
  if (r.labels.some(l => /書き手/.test(l)) || /短く書く/.test(r.text)) bad('the writer part is left out unless the document is a mail', r.labels);

  /* 3. 上限：知識 → 書き手 → 基準の実例 の順に削り、核と文書は残す。欄に削った節が出る */
  r = await page.evaluate(async () => { const A = FZ.app; const big = '# 大きな知識\n' + Array.from({ length: 30 }, (_, i) => `## 在庫の型 ${i + 1}\n` + '在庫の話。'.repeat(160)).join('\n'); await A._h.shelfAdd([{ name: '在庫の知識バンドル.md', text: big }]); A._h.rqOpt.budget = 16000; const { b } = await A._h.rqBuildNow(); A._h.rqOpt.budget = 40000; return { total: b.total, over: b.over, items: b.items.map(x => (x.cut ? '×' : '○') + x.label) }; });
  if (!(r.total <= 16000 && !r.over && r.items.some(x => /^○知識：在庫・資産（\d+ 節・\d+ 節は削った）/.test(x)) && r.items.some(x => /^○核/.test(x)) && r.items.some(x => /^○文書/.test(x)))) bad('over the budget, knowledge is cut first and core and document stay', r);

  /* 4. 欄：開くと部品と合計。校正に変えると基準と知識が抜ける。部品の印を外すと入らない */
  r = await page.evaluate(async () => { const A = FZ.app; A.run('askAI'); await new Promise(r => setTimeout(r, 250)); const B = document.getElementById('sideBody'); const res = { side: A.st.side, title: document.getElementById('sideTitle').textContent, rows: B.querySelectorAll('.askit').length, sum: (B.querySelector('.asksum') || {}).textContent, copy: !!B.querySelector('[data-aact="copy"]'), parts: B.querySelectorAll('[data-puse]').length };
    const sel = B.querySelector('[data-ask="type"]'); sel.value = 'proof'; sel.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 250)); res.proof = [...document.querySelectorAll('#sideBody .askit .t')].map(e => e.textContent);
    const s2 = document.querySelector('#sideBody [data-ask="type"]'); s2.value = 'review'; s2.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 250));
    const cb = [...document.querySelectorAll('#sideBody [data-puse]')].find(e => /SCMデータバンク/.test(e.parentNode.textContent)); cb.checked = false; cb.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 250)); const { b } = await A._h.rqBuildNow(); res.offOut = !/在庫は在庫日数と在庫金額で/.test(b.text); return res; });
  if (!(r.side === 'request' && r.title === 'AI に頼む' && r.rows >= 6 && /合計/.test(r.sum) && r.copy && r.parts === 6)) bad('the request panel lists the parts, the total and the shelf', r);
  if (!(r.proof.some(t => /型：校正/.test(t)) && !r.proof.some(t => /基準|知識/.test(t)))) bad('a proofreading request leaves out the standard and the knowledge', r.proof);
  if (!r.offOut) bad('a part with its mark off is not sent', r);

  /* 5. 答え：区切りを読み、判定・指摘は右の欄（引用の行へ）、稿は差分で取り込む */
  r = await page.evaluate(async () => { const A = FZ.app; const ans = '前置きの挨拶です。\n＝＝判定＝＝\n判定：直してから出す\n一言：起点が無い。\n＝＝指摘＝＝\n- 重さ：直\n  引用：「在庫が増加した」\n  問題：比較起点が無い\n  突っ込み：「何と比べて？」\n  直し方：前月比を書く\n- 重さ：整\n  引用：「本文に無い引用」\n  問題：例\n＝＝最小修正稿＝＝\n## 1. 在庫\n期末の在庫は 120 千台で、前月比 8 千台増加した。今後、生産を見直す。\n＝＝要確認＝＝\n- 前月末の在庫｜比較起点｜増加の量が入る\n';
    A.run('aiReturn'); await new Promise(r => setTimeout(r, 80)); const ta = document.querySelector('#sub textarea[name="md"]'); ta.value = ans; document.querySelector('#sub [data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 200));
    const N = (A.ed.doc.notes || []).filter(n => n.author === '下読み'); const B = document.getElementById('sideBody'); return { form: A.st.form, hunks: A.st.aiBack && A.st.aiBack.hunks.length, side: A.st.side, judge: (B.querySelector('.rqj') || {}).textContent, notes: N.map(n => A.ed.doc.lines.findIndex(l => (l.attrs.notes || []).includes(n.id)) + ':' + n.text.split('\n')[0]), lost: [...B.querySelectorAll('.rql')].map(e => e.textContent) }; });
  if (!(r.form === 'aiback' && r.hunks >= 1 && r.side === 'request' && /直してから出す/.test(r.judge))) bad('a marked answer opens its draft in the diff and puts the verdict in the side panel', r);
  if (!(r.notes.length === 1 && r.notes[0] === '2:〔直〕何と比べて？' && r.lost.some(x => /本文に無い引用/.test(x)) && r.lost.some(x => /前月末の在庫/.test(x)))) bad('findings become notes on the quoted line and unknown quotes stay listed', r);
  r = await page.evaluate(async () => { const A = FZ.app; document.querySelector('#sub [data-act="take"]').click(); await new Promise(r => setTimeout(r, 120)); const t = A.ed.doc.lines.map(l => l.segs.map(s => s.text).join('')).join('\n'); A.run('aiReturn'); return { took: /前月比 8 千台増加した/.test(t), kept: /販売は前年比 3% 増えた/.test(t) }; });
  if (!(r.took && r.kept)) bad('taking the draft changes only the section that was sent', r);

  /* 6. 議事録の答えは新しい文書で開く（種類は議事録） */
  await load('#fzk 2\n---\n[表題]打合せメモ\n山田：在庫の件は来月決める。\n');
  r = await page.evaluate(async () => { const A = FZ.app; A.run('aiReturn'); await new Promise(r => setTimeout(r, 80)); const ta = document.querySelector('#sub textarea[name="md"]'); ta.value = '＝＝議事録＝＝\n# 在庫の打合せ　議事録\n## 結論\n- 在庫の扱いは来月決める\n## Todo\n- 在庫の案：山田［要確認：期限］\n＝＝要確認＝＝\n- 期限｜Todo に要る\n'; document.querySelector('#sub [data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 400));
    return { title: A.ed.doc.title, kind: A.ed.doc.kind, first: A.ed.doc.lines[0].segs[0].text, form: A.st.form, conv: A.st.convLog && A.st.convLog.items.length }; });
  if (!(r.kind === '議事録' && /議事録/.test(r.first) && !r.form && r.conv === 1)) bad('a minutes answer opens as a new document of kind 議事録', r);

  /* 7. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['AI に頼む', '部品棚', '伏せる名前'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe the request panel', r);
  await page.evaluate(async () => { await FZ.app._h.shelfReset(); FZ.app._h.rqMasks([]); });

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116b-app fails=${fails} errors=${errors.length}` : 'test-116b-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
