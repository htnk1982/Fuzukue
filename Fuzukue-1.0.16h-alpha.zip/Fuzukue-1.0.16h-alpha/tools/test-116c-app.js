/* 1.0.16c：答えの指摘を付箋に（引用の場所を寛容に探す）、判定・場所の分からない指摘・要確認・ゲートの欄、状態行の「止 N」、下読みの付箋をまとめて消す、照合の「止」 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('dialog', d => d.accept());
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { const A = FZ.app; await A.loadText('#fzk 2\n---\n[表題]第3四半期の報告\n#文書の種類 報告\n[番号1]在庫\n期末の在庫は １２０ 千台で、在庫が増加した。今後、生産を見直す。\n関係部署と連携を強化した。\n[番号1]販売\n販売は前年比 3% 増えた。\n', 't.fzk', null); A.render(); await A._h.shelfReset(); A._h.rqMasks([]); Object.assign(A._h.rqOpt, { type: 'review', scope: 'whole', draft: 'min' });
    A.ed.mutate('', () => { A.ed.doc.notes = [{ id: 'n1', author: '山田', date: '2026-11-09T10:00', done: false, quote: '', text: '人の付箋', replies: [] }]; A.ed.doc.lines[4].attrs.notes = ['n1']; }); });
  const ANS = '＝＝判定＝＝\n判定：止（このままでは出せない）\n一言：比較起点が無く、判断できない。\n＝＝指摘＝＝\n- 重さ：止\n  引用：「期末の在庫は120千台で」\n  問題：前回見通しとの差が無い\n  突っ込み：「何と比べて？」\n  直し方：前回見通し比を書く\n- 重さ：直\n  引用：「連携を強化した」\n  問題：成果が無い\n  突っ込み：「それで何が変わった？」\n- 重さ：整\n  引用：「本文のどこにも無い言い回し」\n  問題：例\n＝＝最小修正稿＝＝\n# 第3四半期の報告\n## 1. 在庫\n期末の在庫は 120 千台で、前回見通しより 8 千台多い。今後、生産を見直す。\n関係部署と連携を強化した。\n## 2. 販売\n販売は前年比 3% 増えた。\n＝＝要確認＝＝\n- 前回見通しの在庫｜比較起点｜差が書ける\n＝＝ゲート＝＝\n- G01 FAIL：比較起点が無い\n- G02 PASS：結論が先\n';

  /* 1. 指摘を付箋に：全角の数字・空白の違いがあっても引用の行に付く。引用の無い所は欄に */
  let r = await page.evaluate(async ans => { const A = FZ.app; A.run('aiReturn'); await new Promise(r => setTimeout(r, 80)); document.querySelector('#sub textarea[name="md"]').value = ans; document.querySelector('#sub [data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 300));
    const N = A.ed.doc.notes.filter(n => n.author === '下読み'); const at = id => A.ed.doc.lines.findIndex(l => (l.attrs.notes || []).includes(id)); const B = document.getElementById('sideBody');
    return { notes: N.map(n => at(n.id) + ':' + n.text.split('\n')[0] + '|' + n.quote), form: A.st.form, hunks: A.st.aiBack && A.st.aiBack.hunks.length, side: A.st.side, judge: (B.querySelector('.rqj') || {}).textContent, stop: !!B.querySelector('.rqj.stop'), lost: [...B.querySelectorAll('.rql')].map(e => e.textContent), msg: A.st.msg }; }, ANS);
  if (!(r.notes.length === 2 && r.notes[0].startsWith('2:〔止〕何と比べて？|期末の在庫は １２０ 千台で') && r.notes[1].startsWith('3:〔直〕それで何が変わった？|連携を強化した'))) bad('findings become notes by 下読み on the quoted lines, tolerant of width and spaces', r.notes);
  if (!(r.form === 'aiback' && r.hunks >= 1 && r.side === 'request' && /止/.test(r.judge) && r.stop)) bad('the verdict shows at the head of the request panel and the draft opens in the diff', r);
  if (!(r.lost.some(t => /本文のどこにも無い言い回し/.test(t)) && r.lost.some(t => /前回見通しの在庫/.test(t)) && r.lost.some(t => /G01：比較起点が無い/.test(t)) && !r.lost.some(t => /G02/.test(t)))) bad('unlocated findings, needs and failed gates are listed in the panel', r.lost);
  if (!/付箋 2 枚/.test(r.msg)) bad('the message counts the notes made', r.msg);

  /* 2. 取り込みには照合の「止」。状態行に「止 1」、押すと止の付箋へ */
  r = await page.evaluate(async () => { const A = FZ.app; const b = document.querySelector('#sub .shogo'); const badge = b && b.textContent; A.run('aiReturn'); await new Promise(r => setTimeout(r, 60)); A.ed.caret = { line: 5, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.render(); await new Promise(r => setTimeout(r, 60));
    const nx = document.querySelector('#stNext [data-next="rqStopNext"]'); const label = nx && nx.textContent; if (nx) nx.click(); await new Promise(r => setTimeout(r, 60)); return { badge, label, line: A.ed.caret.line }; });
  if (!/^止 照合：.*数/.test(r.badge || '')) bad('a number change in the draft is marked 止 by collation', r);
  if (!(r.label === '止 1' && r.line === 2)) bad('the status line offers 止 N and jumps to the stop note', r);

  /* 3. 同じ答えをもう一度貼っても付箋は増えない。下読みの付箋だけをまとめて消す（人の付箋は残る）・Ctrl+Z で戻る。原本に作成者が残る */
  r = await page.evaluate(async ans => { const A = FZ.app; A.run('aiReturn'); await new Promise(r => setTimeout(r, 60)); document.querySelector('#sub textarea[name="md"]').value = ans; document.querySelector('#sub [data-act="cmp"]').click(); await new Promise(r => setTimeout(r, 300)); A.run('aiReturn');
    const n1 = A.ed.doc.notes.filter(n => n.author === '下読み').length; const ser = /#付箋 n\d+ 下読み .* 未 「期末の在庫は １２０ 千台で」/.test(FZ.serialize(A.ed.doc)); A.run('rqNotesClear'); const after = { mine: A.ed.doc.notes.filter(n => n.author === '下読み').length, human: A.ed.doc.notes.filter(n => n.author === '山田').length, attrs: A.ed.doc.lines.filter(l => l.attrs.notes).length }; A.ed.undo(); const back = A.ed.doc.notes.filter(n => n.author === '下読み').length; return { n1, ser, after, back }; }, ANS);
  if (r.n1 !== 2) bad('pasting the same answer again does not duplicate notes', r);
  if (!r.ser) bad('review notes are kept in the source with the author 下読み', r);
  if (!(r.after.mine === 0 && r.after.human === 1 && r.after.attrs === 1 && r.back === 2)) bad('clearing removes only the review notes and is undoable', r);

  /* 4. 欄から推奨稿が無ければボタンは出ない。「最小稿と比べる」で差分を開き直す */
  r = await page.evaluate(async () => { const A = FZ.app; if (A.st.side !== 'request') A.run('askAI'); A._d.drawSide(); await new Promise(r => setTimeout(r, 250)); const B = document.getElementById('sideBody'); const rec = !!B.querySelector('[data-aact="cmpRec"]'); const b = B.querySelector('[data-aact="cmpMin"]'); if (b) b.click(); await new Promise(r => setTimeout(r, 150)); const res = { rec, min: !!b, form: A.st.form, hunks: A.st.aiBack && A.st.aiBack.hunks.length }; A.run('aiReturn'); return res; });
  if (!(r.min && !r.rec && r.form === 'aiback' && r.hunks >= 1)) bad('the panel reopens the diff with the minimal draft', r);

  /* 5. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['下読みの付箋', '止 N'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe review notes and 止 N', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116c-app fails=${fails} errors=${errors.length}` : 'test-116c-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
