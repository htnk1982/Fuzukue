/* 1.0.16d：下読みの予測の記録、本番の朱（作成者が自分・下読みでない付箋）との照らし合わせ、通算、外れた朱を基準の記録に足して次の依頼の実例に */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('dialog', d => d.accept());
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const SRC = '#fzk 2\n---\n[表題]在庫報告\n#文書の種類 報告\n[番号1]在庫\n期末の在庫は 120 千台で、在庫が増加した。\n関係部署と連携を強化した。\n今後、生産を見直す。\n';
  await page.evaluate(async src => { const A = FZ.app; localStorage.setItem('fz.noteAuthor', '畑中'); await A._h.rqLogReset(); await A._h.shelfReset(); A._h.rqMasks([]); Object.assign(A._h.rqOpt, { type: 'review', scope: 'whole', draft: 'min' }); await A.loadText(src, '在庫報告.fzk', null); A.render(); }, SRC);

  /* 1. 下読みの答えを受け取ると、予測を文書の名前で記録する */
  let r = await page.evaluate(async () => { const A = FZ.app; const P = FZ.askParse('＝＝判定＝＝\n判定：直してから出す\n＝＝指摘＝＝\n- 重さ：止\n  引用：「在庫が増加した」\n  突っ込み：「何と比べて？」\n- 重さ：直\n  引用：「連携を強化した」\n  突っ込み：「それで何が変わった？」\n'); A._h.rqTake(P); await new Promise(r => setTimeout(r, 200)); const L = await FZ.RDB.get('rq:pred'); return { n: L.length, doc: L[L.length - 1].doc, items: L[L.length - 1].items.map(x => x.ask + '|' + x.line.slice(0, 10)) }; });
  if (!(r.n === 1 && r.doc === '在庫報告' && r.items.length === 2 && /何と比べて？\|期末の在庫は/.test(r.items[0]))) bad('review predictions are recorded by document name with the quoted line', r);

  /* 2. 提出先の朱を取り込んだ文書（同じ名前の Word）：朱 3 件のうち 1 件を当てた。自分と下読みの付箋は数えない */
  r = await page.evaluate(async src => { const A = FZ.app; await A.loadText(src, '在庫報告.docx', null); A.render(); const add = (line, id, author, quote, text) => { A.ed.doc.notes = A.ed.doc.notes || []; A.ed.doc.notes.push({ id, author, date: '2026-11-10T09:00', done: false, quote, text, replies: [] }); const a = A.ed.doc.lines[line].attrs; a.notes = [...(a.notes || []), id]; };
    A.ed.mutate('', () => { add(2, 'n1', '上位者X', '在庫が増加', '何に対して増えた？前回見通し比で。'); add(3, 'n2', '上位者X', '', '「連携」では分からない。'); add(4, 'n3', '上位者X', '見直す', 'いつまでに、誰が？'); add(4, 'n4', '畑中', '', '自分のメモ'); add(2, 'n5', '下読み', '在庫が増加した', '〔止〕何と比べて？'); });
    const rec = await A._h.rqMatch(); await new Promise(r => setTimeout(r, 250)); const B = document.getElementById('sideBody'); return { rec, side: A.st.side, judge: [...B.querySelectorAll('.rqv .rqj')].map(e => e.textContent), rows: [...B.querySelectorAll('.rql')].map(e => e.textContent.slice(0, 20)), msg: A.st.msg }; }, SRC.replace('#fzk 2\n---\n', '#fzk 2\n---\n'));
  if (!(r.rec && r.rec.actual === 3 && r.rec.hit === 2 && r.rec.pred === 2 && r.rec.predHit === 2)) bad('red ink by others is matched to predictions by quote or line; own and review notes are not counted', r.rec);
  if (!(r.side === 'request' && r.judge.some(t => /当てた 2 \/ 3 件（67%）/.test(t)) && r.rows.filter(t => /^○/.test(t)).length === 2 && r.rows.some(t => /^× 上位者X：いつまでに/.test(t)))) bad('the panel shows the hit count and each red-ink item', r);

  /* 3. 照らし直しても通算は二重に数えない。外れた朱は基準の記録に足し、次の下読みの依頼に実例として入る（名前は伏せる） */
  r = await page.evaluate(async () => { const A = FZ.app; await A._h.rqMatch(); const L = await A._h.rqLog(); const B = document.getElementById('sideBody'); await new Promise(r => setTimeout(r, 200)); const stat = B.textContent;
    A._h.rqMasks([{ from: '上位者X', to: '上位者', person: false }]); await A._h.rqRecordMissed(); const sh = await A._h.shelfLoad(); const part = sh.find(p => p.name === '基準の記録.md'); const { b } = await A._h.rqBuildNow();
    return { log: L.length, stat: /これまで 1 回：本番の朱 3 件のうち当てた 2 件/.test(stat), part: part && part.kind, inReq: /いつまでに、誰が？/.test(b.text), items: b.items.map(x => x.label) }; });
  if (r.log !== 1 || !r.stat) bad('matching again replaces the last record and the totals show', r);
  if (!(r.part === '基準' && r.inReq && r.items.some(l => /基準の実例/.test(l)))) bad('missed red ink goes to the standard record and into the next request as examples', r);

  /* 4. 朱が無い文書では知らせて何もしない */
  r = await page.evaluate(async () => { const A = FZ.app; await A.loadText('#fzk 2\n---\n本文。\n', '別.fzk', null); const rec = await A._h.rqMatch(); return { rec, msg: A.st.msg }; });
  if (!(r.rec === null && /提出先の朱/.test(r.msg))) bad('without red ink the match explains what to do', r);

  /* 5. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['本番の朱', '基準の記録'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe red-ink matching', r);
  await page.evaluate(async () => { const A = FZ.app; await A._h.rqLogReset(); await A._h.shelfReset(); A._h.rqMasks([]); localStorage.removeItem('fz.noteAuthor'); });

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116d-app fails=${fails} errors=${errors.length}` : 'test-116d-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
