/* 1.0.16e：送り先（チャットに貼る／手元の AI）。手元の AI（OpenAI 互換の窓口）を page.route で模して、つなぐ・送る（流れて来る答え）・受け取り（付箋・差分）・小さく組む・失敗の知らせ */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 1000 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('dialog', d => d.accept());
  const seen = { auth: '', body: null }; let mode = 'ok';
  const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' };
  const ANS = '<think>まず数字を見る。</think>＝＝指摘＝＝\n- 重さ：整\n  引用：「在庫が増加しました」\n  問題：表記\n  直し方：「在庫が増えた」\n＝＝最小修正稿＝＝\n## 1. 在庫\n期末の在庫は 120 千台で、在庫が増えた。\n';
  await page.route('http://localhost:8888/v1/**', async route => { const req = route.request(); if (req.method() === 'OPTIONS') return route.fulfill({ status: 204, headers: cors });
    seen.auth = req.headers()['authorization'] || ''; if (mode === 'down') return route.abort('connectionrefused'); if (mode === '401') return route.fulfill({ status: 401, headers: cors, body: '{}' });
    if (req.url().endsWith('/models')) return route.fulfill({ status: 200, headers: { ...cors, 'Content-Type': 'application/json' }, body: JSON.stringify({ data: [{ id: 'gemma-test-GGUF' }, { id: 'qwen-test' }] }) });
    seen.body = JSON.parse(req.postData() || '{}'); const chunks = []; for (let k = 0; k < ANS.length; k += 7) chunks.push('data: ' + JSON.stringify({ choices: [{ delta: { content: ANS.slice(k, k + 7) } }] }) + '\n\n'); chunks.push('data: [DONE]\n\n');
    return route.fulfill({ status: 200, headers: { ...cors, 'Content-Type': 'text/event-stream' }, body: chunks.join('') }); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { const A = FZ.app; await A._h.shelfReset(); A._h.rqMasks([]); Object.assign(A._h.rqLocal, { url: 'http://localhost:8888/v1/', key: 'sk-unsloth-test', model: '', budget: 12000, models: [] }); Object.assign(A._h.rqOpt, { type: 'proof', scope: 'sec', draft: 'min' }); A._h.rqOpt.dests = { review: 'clip', proof: 'local', minutes: 'local', gist: 'local' };
    await A.loadText('#fzk 2\n---\n[表題]報告\n#文書の種類 報告\n[番号1]在庫\n期末の在庫は 120 千台で、在庫が増加しました。\n[番号1]販売\n販売は前年比 3% 増えた。\n', 't.fzk', null); A.render(); A.ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); });

  /* 1. 既定の送り先：下読みはチャット、校正は手元。欄に窓口・鍵・モデル、主ボタンは「手元の AI に頼む」 */
  let r = await page.evaluate(async () => { const A = FZ.app; A.run('askAI'); await new Promise(r => setTimeout(r, 250)); const B = document.getElementById('sideBody'); const res = { dest: B.querySelector('[data-ask="dest"]').value, url: !!B.querySelector('[data-local="url"]'), send: !!B.querySelector('[data-aact="send"]'), copyAlt: !!B.querySelector('[data-aact="copy"]') };
    const t = B.querySelector('[data-ask="type"]'); t.value = 'review'; t.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 250)); res.reviewDest = document.querySelector('#sideBody [data-ask="dest"]').value; res.reviewSend = !!document.querySelector('#sideBody [data-aact="send"]');
    const t2 = document.querySelector('#sideBody [data-ask="type"]'); t2.value = 'proof'; t2.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 250)); return res; });
  if (!(r.dest === 'local' && r.url && r.send && r.copyAlt && r.reviewDest === 'clip' && !r.reviewSend)) bad('proofreading goes to the local AI and review to the chat by default; the panel shows endpoint controls', r);

  /* 2. つなぐ：モデルの一覧を読み、最初のモデルを選ぶ。鍵を Authorization で送る */
  r = await page.evaluate(async () => { const A = FZ.app; document.querySelector('#sideBody [data-aact="connect"]').click(); await new Promise(r => setTimeout(r, 400)); return { model: A._h.rqLocal.model, opts: [...document.querySelectorAll('#sideBody [data-local="model"] option')].map(o => o.textContent), msg: A.st.msg }; });
  if (!(r.model === 'gemma-test-GGUF' && r.opts.length === 2 && /つながりました/.test(r.msg) && seen.auth === 'Bearer sk-unsloth-test')) bad('connecting reads the model list with the key', { ...r, auth: seen.auth });

  /* 3. 送る：流れて来る答えを集め、考えの跡を外して受け取る。指摘は付箋、稿は差分。依頼は小さく組む（核は内蔵） */
  r = await page.evaluate(async () => { const A = FZ.app; await A._h.shelfAdd([{ name: '汎用資料・作文コンパイラv2.0.md', text: '# 第I部　実行\n## 役割\n' + '長い核の本文。'.repeat(500) + '\n' }]); document.querySelector('#sideBody [data-aact="send"]').click(); for (let k = 0; k < 40 && (A._h.rqBusy() || !A.st.aiBack); k++) await new Promise(r => setTimeout(r, 100));
    const N = (A.ed.doc.notes || []).filter(n => n.author === '下読み'); return { form: A.st.form, hunks: A.st.aiBack && A.st.aiBack.hunks.length, notes: N.map(n => n.text.split('\n')[0]), msg: A.st.msg, last: A.st.rqLastAnswer && A.st.rqLastAnswer.slice(0, 8) }; });
  if (!(seen.body && seen.body.model === 'gemma-test-GGUF' && seen.body.stream === true && seen.body.messages[0].role === 'user')) bad('the request goes to /chat/completions with the chosen model and streaming', seen.body && { model: seen.body.model, stream: seen.body.stream });
  const prompt = seen.body ? seen.body.messages[0].content : ''; if (!(/# 頼む仕事：校正/.test(prompt) && /在庫が増加しました/.test(prompt) && /# 核：判断に耐える提出物にする決まり/.test(prompt) && !/長い核の本文/.test(prompt) && prompt.length <= 12000)) bad('the local request is compact (built-in core, within the local budget)', prompt.length);
  if (!(r.form === 'aiback' && r.hunks >= 1 && r.notes.length === 1 && /^〔整〕/.test(r.notes[0]) && /手元の AI の答え/.test(r.msg) && r.last && r.last.startsWith('＝＝指摘＝＝'))) bad('the streamed answer is received like a pasted one (notes and draft diff), without the thinking trace', r);
  await page.evaluate(() => { FZ.app.run('aiReturn'); });

  /* 4. 失敗の知らせ：鍵が違う（401）、つながらない。チャットへの写しに回せる */
  mode = '401'; r = await page.evaluate(async () => { const A = FZ.app; await A._h.rqModels(); return A.st.msg; }); if (!/鍵が違う/.test(r)) bad('a 401 says the key is wrong', r);
  mode = 'down'; r = await page.evaluate(async () => { const A = FZ.app; await A._h.rqSend(); await new Promise(r => setTimeout(r, 200)); return { msg: A.st.msg, busy: A._h.rqBusy(), copy: !!document.querySelector('#sideBody [data-aact="copy"]') }; });
  if (!(/つながらない/.test(r.msg) && /代わりに写す/.test(r.msg) && !r.busy && r.copy)) bad('an unreachable endpoint is reported with the copy fallback', r);

  /* 5. 区切りの無い答えは全体を稿として比べる */
  r = await page.evaluate(async () => { const A = FZ.app; A._h.rqReceive('## 1. 在庫\n期末の在庫は 120 千台で、前月より増えた。\n', 3); await new Promise(r => setTimeout(r, 100)); const res = { form: A.st.form, hunks: A.st.aiBack && A.st.aiBack.hunks.length, msg: A.st.msg }; A.run('aiReturn'); return res; });
  if (!(r.form === 'aiback' && r.hunks >= 1 && /区切りが無いので全体を稿として比べる/.test(r.msg))) bad('an answer without markers is compared as a whole draft', r);

  /* 5b. 文机がつなぐのは手元（localhost）だけ：外の窓口は CSP で止まる */
  r = await page.evaluate(async () => { const csp = document.querySelector('meta[http-equiv="Content-Security-Policy"]').content; let ext = 'ok'; try { await fetch('https://api.example.com/v1/models'); } catch (e) { ext = 'blocked'; } return { csp: /connect-src 'self' file: data: blob: http:\/\/localhost:\* http:\/\/127\.0\.0\.1:\*;/.test(csp) && !/connect-src[^;]*https/.test(csp), ext }; });
  if (!(r.csp && r.ext === 'blocked')) bad('only localhost endpoints are reachable; outside endpoints are blocked by the CSP', r);

  /* 6. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['手元の AI', '送り先', 'OpenAI 互換'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe the local AI', r);
  await page.evaluate(async () => { const A = FZ.app; await A._h.shelfReset(); Object.assign(A._h.rqLocal, { url: 'http://localhost:8888/v1', key: '', model: '', models: [] }); localStorage.removeItem('fz.local'); });

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116e-app fails=${fails} errors=${errors.length}` : 'test-116e-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
