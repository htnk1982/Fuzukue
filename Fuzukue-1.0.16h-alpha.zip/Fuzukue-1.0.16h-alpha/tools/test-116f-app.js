/* 1.0.16f：帯の省スペース化（F8 の短い名前・F4 の子項目を外す・ツリーの段数を小さく・表示のプルダウン）、新しい表を矢印キーでセルからセルへ */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 900 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);

  /* 1. 帯の名前と大きさ */
  let r = await page.evaluate(async () => { const A = FZ.app; await A.loadText('#fzk 2\n---\n[表題]題\n本文。\n', 't.fzk', null); A.render(); A.run('structGroup'); await new Promise(r => setTimeout(r, 80)); const sub = document.getElementById('sub');
    const f4 = { child: !!sub.querySelector('[data-cmd="childItem"]'), cll: [...sub.querySelectorAll('.cll')].map(e => e.textContent), seg: (() => { const e = sub.querySelector('.segd .ch.mini'); const cs = e && getComputedStyle(e); return cs && { fs: cs.fontSize, pl: cs.paddingLeft, h: cs.height }; })() };
    A.run('tableMenu'); await new Promise(r => setTimeout(r, 80)); const f8 = [...document.querySelectorAll('#sub .ch .lb')].map(e => e.textContent.trim()).join('|'); A.run('tableMenu');
    return { f4, f8, view: [...document.querySelectorAll('#viewSel option')].map(o => o.textContent) }; });
  if (r.f4.child || !r.f4.cll.includes('ﾂﾘｰ')) bad('F4 has no child-item tile and its tree cluster is named ﾂﾘｰ', r.f4);
  if (!(r.f4.seg && r.f4.seg.fs === '10.5px' && r.f4.seg.pl === '2px' && r.f4.seg.h === '18px')) bad('the tree depth selector is smaller (10.5px, 2px padding, 18px high)', r.f4.seg);
  if (!(/揃える/.test(r.f8) && /字合せ/.test(r.f8) && /囲全幅/.test(r.f8) && !/そろえる|字合わせ|囲み全幅/.test(r.f8))) bad('F8 uses the shorter names', r.f8);
  if (JSON.stringify(r.view) !== JSON.stringify(['紙面', 'ﾂﾘｰ', '並べ'])) bad('the view pulldown reads 紙面・ﾂﾘｰ・並べ', r.view);

  /* 2. 新しい表：→ でセルからセルへ（空のセルにも入る）、行の終わりで次の行の頭へ。← で戻る。動くだけでは原本は変わらない */
  await page.evaluate(async () => { const A = FZ.app; await A.loadText('#fzk 2\n---\n[表題]題\n本文。\n\n', 't.fzk', null); A.render(); A.ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.run('table'); await new Promise(r => setTimeout(r, 60)); document.querySelector('#sub [data-act="apply"]').click(); await new Promise(r => setTimeout(r, 100)); });
  const cur = () => page.evaluate(() => { const A = FZ.app, c = A.ed.caret, ln = A.ed.doc.lines[c.line]; const cells = FZ.cellsAt(A.ed.doc, c.line); const sg = ln.segs[c.seg]; return { line: c.line, cell: cells.findIndex(x => sg.col >= x.left - 1e-6 && sg.col < x.right - 1e-6), off: c.off, vcol: c.vcol, n: cells.length }; });
  const src0 = await page.evaluate(() => FZ.serialize(FZ.app.ed.doc));
  const path1 = []; let s = await cur(); const n = s.n; path1.push(s.line + ':' + s.cell); for (let k = 0; k < n; k++) { await page.keyboard.press('ArrowRight'); s = await cur(); path1.push(s.line + ':' + s.cell); }
  const want1 = [...Array.from({ length: n }, (_, k) => '2:' + k), '3:0']; if (JSON.stringify(path1) !== JSON.stringify(want1)) bad('→ walks the cells of a new table and wraps to the next row', { path1, want1 });
  await page.keyboard.press('ArrowLeft'); s = await cur(); if (!(s.line === 2 && s.cell === n - 1)) bad('← at the start of a row goes to the last cell of the row above', s);
  await page.keyboard.press('ArrowLeft'); s = await cur(); if (!(s.line === 2 && s.cell === n - 2)) bad('← goes back one cell', s);
  if (await page.evaluate(() => FZ.serialize(FZ.app.ed.doc)) !== src0) bad('moving the caret through empty cells does not change the source');

  /* 3. ↓↑ は同じ列のまま（空のセルにも入る）。打った字はそのセルに入る */
  await page.keyboard.press('ArrowDown'); s = await cur(); if (!(s.line === 3 && s.cell === n - 2 && s.vcol == null)) bad('↓ keeps the column and enters the empty cell below', s);
  await page.keyboard.type('右下'); r = await page.evaluate(() => { const A = FZ.app, c = A.ed.caret, ln = A.ed.doc.lines[c.line]; const cells = FZ.cellsAt(A.ed.doc, c.line); const texts = cells.map(x => ln.segs.filter(g => g.col >= x.left - 1e-6 && g.col < x.right - 1e-6).map(g => g.text).join('')); return texts; });
  if (!(r[n - 2] === '右下' && r.filter(Boolean).length === 1)) bad('typing goes into the cell the caret entered', r);
  await page.keyboard.press('ArrowUp'); s = await cur(); if (!(s.line === 2 && s.cell === n - 2)) bad('↑ keeps the column', s);

  /* 4. 表の外へ：最後のセルの終わりで → は表の次の行へ。Tab は今までどおり */
  r = await page.evaluate(async () => { const A = FZ.app; const rg = FZ.tableRange(A.ed); const last = rg[1]; const cells = FZ.cellsAt(A.ed.doc, last); A.ed.caret = { line: last, seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); for (let k = 0; k < cells.length; k++) A.ed.moveH(1, false); const out = { line: A.ed.caret.line, last, inT: FZ.inTable(A.ed.doc, A.ed.caret.line) };
    A.ed.caret = { line: rg[0], seg: 0, off: 0, vcol: null, vrow: 0 }; A.ed.onCaret(); A.ed.tab(false); const c = A.ed.caret, sg = A.ed.doc.lines[c.line].segs[c.seg]; const cs = FZ.cellsAt(A.ed.doc, c.line); out.tab = cs.findIndex(x => sg.col >= x.left - 1e-6 && sg.col < x.right - 1e-6); return out; });
  if (!(r.line === r.last + 1 && !r.inT && r.tab === 1)) bad('→ leaves the table after the last cell; Tab still moves to the next cell', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116f-app fails=${fails} errors=${errors.length}` : 'test-116f-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
