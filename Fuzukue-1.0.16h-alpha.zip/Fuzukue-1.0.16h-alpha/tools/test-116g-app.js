/* 1.0.16g：プ譜の編集（入ると帯がプ譜の帯に・状態行に役・役で足す・組み替える・消す・次の一手・ツリーの「プ譜：役」の塊） */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 950 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  await page.evaluate(async () => { const A = FZ.app, ed = A.ed; await A.loadText('#fzk 2\n---\n[表題]計画\n前書き。\n\n', 't.fzk', null); A.render(); ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('structGroup'); ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('pufuNew'); await new Promise(r => setTimeout(r, 80)); });
  const at = t => page.evaluate(t => { const A = FZ.app, ed = A.ed; const i = ed.doc.lines.findIndex(l => l.segs[0].text.startsWith(t)); ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.render(); return i; }, t);
  const outline = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => (l.attrs.list ? 'L' + l.attrs.list.level : l.attrs.style || '-') + (l.attrs.pufuFrame ? 'F' : '') + ' ' + l.segs[0].text.slice(0, 10)));
  /* 1.0.16h 手引きは字にしないので、空の項目は役で探す（k 番目） */
  const atR = (rl, k = 0) => page.evaluate(([rl, k]) => { const A = FZ.app, ed = A.ed; let n = 0, i = -1; for (let q = 0; q < ed.doc.lines.length; q++) { const pz = FZ.pufuAt(ed.doc, q); if (pz && pz.it && (pz.it.kind === 'node' || pz.it.kind === 'frame') && FZ.pufuRoleOf(pz.B, pz.it) === rl && n++ === k) { i = q; break; } } ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.render(); return i; }, [rl, k]);
  const role = t => page.evaluate(t => { const ed = FZ.app.ed; const i = ed.doc.lines.findIndex(l => l.segs[0].text.startsWith(t)); const pz = FZ.pufuAt(ed.doc, i); return pz && pz.it ? FZ.pufuRoleOf(pz.B, pz.it) : null; }, t);

  /* 1. プ譜に入ると帯がプ譜の帯に、出ると元の帯に。状態行に役 */
  await atR('中間目的'); await page.waitForTimeout(60);
  let r = await page.evaluate(() => ({ g: FZ.app.st.group, st: document.getElementById('stStyle').textContent, tiles: [...document.querySelectorAll('#sub .cll')].map(e => e.textContent) }));
  if (!(r.g === 'pufu' && r.st === 'プ譜：中間目的（取組1）' && r.tiles.includes('足す（役で）') && r.tiles.includes('組み替える'))) bad('entering a project score switches to the pufu band and shows the role', r);
  await at('前書き'); await page.waitForTimeout(60); r = await page.evaluate(() => FZ.app.st.group); if (r !== 'struct') bad('leaving the project score restores the previous band', r);
  await atR('施策'); await page.evaluate(() => FZ.app.run('marks')); await atR('獲得目標'); r = await page.evaluate(() => FZ.app.st.group); if (r !== 'marks' && r !== 'pufu') bad('a band chosen by hand inside the score is not overridden', r);

  /* 2. 役で足す：入る所は文機が決め、足した行は空（手引きは薄く出るだけ。消さずにそのまま打てる） */
  await page.evaluate(() => FZ.app.run('pufuGroup')); await atR('施策'); r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; A.run('pfAdd:act'); const ln = ed.doc.lines[ed.caret.line]; const t = ln.segs.map(g => g.text).join(''); const res = { t, sel: !!ed.sel(), msg: A.st.msg, g: A.st.group }; ed.insertText('部品を前倒しで発注する'); return res; });
  if (!(r.t === '' && !r.sel && /そのまま打つ/.test(r.msg) && r.g === 'pufu')) bad('the added item is empty (no text to erase) and the band stays', r);
  await page.evaluate(() => { const A = FZ.app, ed = A.ed; A.run('pfAdd:mid'); ed.insertText('在庫が 2 割減っている'); A.run('pfAdd:out'); ed.insertText('週次の在庫表'); A.run('pfAdd:frame'); ed.insertText('売上を守る'); A.run('pfAdd:win'); ed.insertText('利益率が 5% 上がる'); });
  r = await outline(); const want = ['L3 ', 'L4 ', 'L4 部品を前倒しで発注', 'L3 在庫が 2 割減っ', 'L4 成果物：週次の在', 'L3 ', 'L4 ', 'L2F 売上を守る', 'L3 ', 'L1 利益率が 5% 上が'];
  const k0 = r.indexOf('L3 '); if (!want.every((w, k) => w.endsWith(' ') ? r[k0 + k] === w : (r[k0 + k] || '').startsWith(w))) bad('items are added in the right place by role', r);
  if (!((await role('部品を前倒し')) === '施策' && (await role('在庫が 2 割')) === '中間目的' && (await role('成果物：週次')) === '成果物' && (await role('利益率が')) === '勝利条件')) bad('the added items get their roles', r);
  await atR('獲得目標'); r = await page.evaluate(() => { FZ.app.run('pfAdd:step'); return FZ.app.st.msg; }); if (!/施策を選んでから/.test(r)) bad('an impossible add says what to select', r);

  /* 3. 次の一手は役で（＋施策・＋成果物・＋中間目的） */
  await at('在庫が 2 割'); await page.waitForTimeout(60); r = await page.evaluate(() => [...document.querySelectorAll('#stNext button')].map(b => b.textContent)); if (JSON.stringify(r) !== JSON.stringify(['＋施策', '＋成果物', '＋中間目的'])) bad('next steps offer the roles to add', r);

  /* 4. 組み替える：下の役へ（中間目的→施策）・上の役へ、消す（子ごと・取組は外す・獲得目標は消さない）、Ctrl+Z */
  await at('在庫が 2 割'); await page.evaluate(() => FZ.app.run('pf:in')); r = await role('在庫が 2 割'); if (r !== '施策') bad('down a role turns a middle goal into a measure', r);
  await at('在庫が 2 割'); await page.evaluate(() => FZ.app.run('pf:out')); r = await role('在庫が 2 割'); if (r !== '中間目的') bad('up a role turns it back', r);
  await at('在庫が 2 割'); r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; const n0 = ed.doc.lines.length; A.run('pf:del'); const n1 = ed.doc.lines.length; const gone = !ed.doc.lines.some(l => /在庫が 2 割|成果物：週次/.test(l.segs[0].text)); ed.undo(); return { d: n0 - n1, gone, back: ed.doc.lines.length === n0 }; });
  if (!(r.d === 2 && r.gone && r.back)) bad('deleting removes the item with its children and is undoable', r);
  await at('売上を守る'); r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; A.run('pf:del'); return { frame: ed.doc.lines.some(l => /売上を守る/.test(l.segs[0].text)), mid: ed.doc.lines.filter((l, q) => { const pz = FZ.pufuAt(ed.doc, q); return l.attrs.list && l.attrs.list.level === 2 && pz && pz.it && FZ.pufuRoleOf(pz.B, pz.it) === '中間目的'; }).length }; });
  if (!(r.frame === false && r.mid === 1)) bad('deleting a frame unwraps it and keeps its middle goals', r);
  await atR('獲得目標'); r = await page.evaluate(() => { const A = FZ.app, ed = A.ed; const n0 = ed.doc.lines.length; A.run('pf:del'); return { same: ed.doc.lines.length === n0, msg: A.st.msg }; }); if (!(r.same && /獲得目標は消さない/.test(r.msg))) bad('the acquisition goal is not deleted', r);

  /* 5. AI の操作は子の帯に */
  r = await page.evaluate(async () => { const A = FZ.app; A.run('pufuAiGroup'); await new Promise(r => setTimeout(r, 40)); const c = [...document.querySelectorAll('#sub [data-cmd]')].map(e => e.dataset.cmd); A.run('pufuGroup'); return c; });
  if (!['pufuPrompt', 'pufuReview', 'pufuNext', 'pufuImport', 'aiReturn'].every(k => r.includes(k))) bad('the AI operations are in the pufu AI sub-band', r);

  /* 6. ツリー：プ譜の節を選ぶと「プ譜：役」の塊。足すとその場で字を打つ箱。浅く・深くは上の役へ・下の役へ */
  await at('利益率が'); r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; const v = document.getElementById('viewSel'); v.value = 'tree'; v.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 200));
    const sub = document.getElementById('sub'); const res = { mode: A.st.mode, cl: [...sub.querySelectorAll('.cll')].map(e => e.textContent), out: (sub.querySelector('[data-cmd="tv:out"] .lb') || {}).textContent, nx: [...document.querySelectorAll('#stNext button')].map(b => b.textContent) };
    const t = sub.querySelector('[data-cmd="pfAdd:mid"]'); t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); await new Promise(r => setTimeout(r, 200)); res.edit = !!A.st.tree.edit; const s = A.st.tree.sel; res.selText = s && s.segs && s.segs[0].text; res.role = (() => { const i = ed.doc.lines.indexOf(s); const pz = FZ.pufuAt(ed.doc, i); return pz && pz.it ? FZ.pufuRoleOf(pz.B, pz.it) : null; })(); return res; });
  if (!(r.mode === 'tree' && r.cl.includes('プ譜：勝利条件') && r.out === '上の役へ' && r.nx[0] === '＋中間目的')) bad('the tree band shows the pufu cluster, role moves and role next steps', r);
  if (!(r.edit && r.selText === '' && r.role === '中間目的')) bad('adding in the tree opens the new (empty) node for typing', r);
  await page.keyboard.press('Escape'); await page.evaluate(() => { const v = document.getElementById('viewSel'); v.value = 'paper'; v.dispatchEvent(new Event('change')); });

  /* 7. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['役で足す', '上の役へ', 'プ譜の帯'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe the new pufu editing', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116g-app fails=${fails} errors=${errors.length}` : 'test-116g-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
