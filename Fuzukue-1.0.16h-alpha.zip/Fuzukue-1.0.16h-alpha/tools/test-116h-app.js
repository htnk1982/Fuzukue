/* 1.0.16h：帯は替わらない・マウスで抜ける（閉じる ×・紙面へ）、プ譜の薄い手引き（字にしない）・古い手引きの移し替え、役の名前（表示の名前）、診断に「プ譜」と「読み手の問い」、編集の帯の「戻す」は縦 */
const { chromium } = require('playwright'); const path = require('path');
let fails = 0; const errors = []; const bad = (n, i) => { fails++; errors.push(n + (i !== undefined ? ' :: ' + JSON.stringify(i).slice(0, 900) : '')); };
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1300, height: 950 } }); page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  const fresh = () => page.evaluate(async () => { const A = FZ.app, ed = A.ed; await A.loadText('#fzk 2\n---\n[表題]計画\n前書き。\n\n', 't.fzk', null); A.render(); ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('structGroup'); ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.run('pufuNew'); await new Promise(r => setTimeout(r, 80)); });
  const atR = (rl, k = 0) => page.evaluate(([rl, k]) => { const A = FZ.app, ed = A.ed; let n = 0, i = -1; for (let q = 0; q < ed.doc.lines.length; q++) { const pz = FZ.pufuAt(ed.doc, q); if (pz && pz.it && (pz.it.kind === 'node' || pz.it.kind === 'frame') && FZ.pufuRoleOf(pz.B, pz.it) === rl && n++ === k) { i = q; break; } } ed.anchor = null; ed.caret = { line: i, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.render(); return i; }, [rl, k]);
  const down = sel => page.evaluate(async sel => { const t = document.querySelector(sel); if (!t) return false; t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); await new Promise(r => setTimeout(r, 80)); return true; }, sel);
  await fresh();

  /* 1. 帯は替わらない：プ譜の帯で 1 つ選んでも、続けて同じ帯。編集の帯（F3）でも同じ */
  await atR('中間目的'); await page.waitForTimeout(60);
  let r = { g0: await page.evaluate(() => FZ.app.st.group) }; await down('#sub [data-cmd="pfAdd:act"]'); r.g1 = await page.evaluate(() => FZ.app.st.group); await page.keyboard.type('担当を決める'); await down('#sub [data-cmd="pfAdd:out"]'); r.g2 = await page.evaluate(() => FZ.app.st.group);
  if (!(r.g0 === 'pufu' && r.g1 === 'pufu' && r.g2 === 'pufu')) bad('the pufu band stays after each item, so editing can continue', r);
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; ed.caret = { line: 1, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.render(); await new Promise(r => setTimeout(r, 40)); A.run('editGroup'); await new Promise(r => setTimeout(r, 40)); const g0 = A.st.group; const t = document.querySelector('#sub [data-cmd="selectAll"]'); t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); await new Promise(r => setTimeout(r, 60)); const res = { g0, g1: A.st.group };
    const u = document.querySelector('#sub [data-cmd="undo"]').getBoundingClientRect(), v = document.querySelector('#sub [data-cmd="redo"]').getBoundingClientRect(); res.vert = Math.abs(u.left - v.left) < 2 && v.top > u.top + 4; res.review = !!document.querySelector('#sub [data-cmd="review"]'); ed.anchor = null; return res; });
  if (!(r.g0 === 'edit' && r.g1 === 'edit')) bad('a top band (F3) stays after an item', r);
  if (!r.vert) bad('undo and redo are stacked vertically in the edit band', r);
  if (r.review) bad('the edit band no longer carries the separate review tile (it is in the health panel)', r);

  /* 2. マウスで抜ける：右の欄の「閉じる ×」、ツリーの「紙面へ」 */
  r = await page.evaluate(async () => { const A = FZ.app; A.run('health'); await new Promise(r => setTimeout(r, 80)); const open = A.st.side; const b = document.getElementById('sideClose'); const txt = b && b.textContent; if (b) b.click(); await new Promise(r => setTimeout(r, 60)); return { open, txt, after: A.st.side || '' }; });
  if (!(r.open === 'health' && /閉じる/.test(r.txt) && r.after === '')) bad('the side panel closes with its 閉じる × button', r);
  r = await page.evaluate(async () => { const A = FZ.app; const v = document.getElementById('viewSel'); v.value = 'tree'; v.dispatchEvent(new Event('change')); await new Promise(r => setTimeout(r, 200)); const m0 = A.st.mode; const t = document.querySelector('#sub [data-cmd="tv:paper"]'); const lb = t && t.textContent; if (t) t.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); await new Promise(r => setTimeout(r, 150)); return { m0, lb, m1: A.st.mode }; });
  if (!(r.m0 === 'tree' && /紙面へ/.test(r.lb || '') && r.m1 === 'text')) bad('the tree band has a 紙面へ tile that returns to the paper', r);

  /* 3. 薄い手引き：空の項目に薄く出る（原本には無い）。打ち始めると消える。印刷用の書き出しにも出ない */
  await fresh();
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; await new Promise(r => setTimeout(r, 60)); const g = [...document.querySelectorAll('#pages text.ghost')].map(e => e.textContent); const src = FZ.serialize(ed.doc); return { g, src: /与えられた使命|どうなっていたら|〜している/.test(src), op: [...document.querySelectorAll('#pages text.ghost')].every(e => /^#[9a-f][0-9a-f]{5}$/i.test(e.getAttribute('fill'))) }; });
  if (!(r.g.length >= 7 && r.g.some(t => /使命/.test(t)) && r.g.some(t => /成功/.test(t)) && !r.src && r.op)) bad('empty pufu items show faint guide text that is not in the source', r);
  const n0 = r.g.length; await atR('勝利条件'); await page.keyboard.type('利益率が上がる'); await page.waitForTimeout(80);
  r = await page.evaluate(() => ({ g: [...document.querySelectorAll('#pages text.ghost')].map(e => e.textContent), t: FZ.app.ed.doc.lines[FZ.app.ed.caret.line].segs.map(g => g.text).join('') }));
  if (!(r.t === '利益率が上がる' && r.g.length === n0 - 1 && !r.g.some(t => /成功と言えるか/.test(t)))) bad('typing into an item replaces its faint guide without erasing anything', { ...r, n0 });
  r = await page.evaluate(() => { const h = FZ.exportHtml ? FZ.exportHtml(FZ.app.ed.doc) : ''; return typeof h === 'string' ? /ghost|与えられた使命/.test(h) : false; }); if (r) bad('the faint guide is not exported', r);

  /* 4. 古い手引き（1.0.16g までの字）は開くと空になる */
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; await A.loadText('#fzk 2\n---\n[表題]計画\n[番号1 プ譜]プ譜：（題）\n[・1]（獲得目標：与えられた使命を 1 文で）\n[・2]売上を守る\n[・3 プ譜取組]（取組：まとめる目的を「〜を〜にする」で）\n[・4]（中間目的：〜している状態）\n[・5]（施策：誰が・何を・いつまでに）\n', 't.fzk', null); A.render(); await new Promise(r => setTimeout(r, 60));
    return { lines: ed.doc.lines.map(l => l.segs.map(g => g.text).join('')), blocks: FZ.pufuBlocks(ed.doc).length }; });
  if (!(r.blocks === 1 && r.lines[1] === 'プ譜：' && r.lines[2] === '' && r.lines[3] === '売上を守る' && r.lines.slice(4, 7).every(t => t === ''))) bad('legacy guide texts are emptied on load (they become faint guides)', r);

  /* 4b. 型で入れたプ譜は保存して開き直しても形が残る（1.0.14〜16g は「・N」と書いて読めなかった） */
  await fresh(); r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; const sig = d => FZ.pufuBlocks(d).map(B => [...B.map].filter(([q, it]) => it.kind === 'node' || it.kind === 'frame').map(([q, it]) => FZ.pufuRoleOf(B, it)).join(',')).join('|'); const s0 = sig(ed.doc); const src = FZ.serialize(ed.doc); await A.loadText(src, 't.fzk', null); A.render(); return { s0, s1: sig(ed.doc), dot: /^\[・\d/m.test(src) }; });
  if (!(r.s0 && r.s0 === r.s1 && !r.dot)) bad('a pufu inserted from the template survives save and reopen', r);

  /* 5. 役の名前：型を選ぶ→紙面の札・状態行が表示の名前に。原本は「プ譜名:」で覚え、構造の名前は変えない。1 回の Ctrl+Z */
  await fresh(); await atR('獲得目標'); await page.waitForTimeout(60);
  r = await page.evaluate(async () => { const A = FZ.app, ed = A.ed; const tile = !!document.querySelector('#sub [data-cmd="pufuNames"]'); A.run('pufuNames'); await new Promise(r => setTimeout(r, 60)); const form = A.st.form; const s = document.querySelector('#sub select[name="preset"]'); s.value = 'plain'; s.dispatchEvent(new Event('change')); const v = document.querySelector('#sub input[name="n_獲得目標"]').value; document.querySelector('#sub [data-act="ok"]').click(); await new Promise(r => setTimeout(r, 80));
    const B = FZ.pufuBlocks(ed.doc)[0]; const goal = B.roots[0]; const src = FZ.serialize(ed.doc); const back = FZ.pufuBlocks(FZ.parse(src))[0]; ed.caret = { line: goal, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); A.render(); await new Promise(r => setTimeout(r, 60));
    const res = { tile, form, v, ser: /プ譜名:獲得目標=目指すこと\|勝利条件=成功の基準/.test(src), back: back && back.names && back.names.獲得目標, tag: ed.lay.pufuAt.get(goal) && ed.lay.pufuAt.get(goal).tag, st: document.getElementById('stStyle').textContent, role: FZ.pufuRoleOf(B, B.map.get(goal)), lint: FZ.pufuLint(ed.doc).some(x => /目指すこと/.test(x.msg)) };
    ed.undo(); A.render(); res.undone = !ed.doc.lines[FZ.pufuBlocks(ed.doc)[0].head].attrs.pufuNames; res.tag2 = ed.lay.pufuAt.get(goal) && ed.lay.pufuAt.get(goal).tag; return res; });
  if (!(r.tile && r.form === 'pnames' && r.v === '目指すこと')) bad('the pufu band opens the role-name form and a preset fills it', r);
  if (!(r.ser && r.back === '目指すこと' && r.tag === '目指すこと' && /目指すこと/.test(r.st) && r.role === '獲得目標' && !r.lint)) bad('display names show on the paper and status line; the structure name stays', r);
  if (!(r.undone && r.tag2 === '獲得目標')) bad('changing role names is one undo', r);

  /* 6. 診断：プ譜の点検は診断の欄の「プ譜」に。下読み（機械）は「読み手の問い」 */
  r = await page.evaluate(async () => { const A = FZ.app; const tile = document.querySelector('#sub [data-cmd="pufuCheck"]'); const lb = tile && tile.textContent; A.run('pufuCheck'); await new Promise(r => setTimeout(r, 100)); const H = A._g.healthGet(); const body = document.getElementById('sideBody');
    return { lb, side: A.st.side, open: A.st.healthOpen, secs: [...new Set(H.rows.map(x => x.sec))], pf: H.rows.filter(x => x.sec === 'プ譜').map(x => x.key + ':' + x.n), lintN: FZ.pufuLint(A.ed.doc).length, rq: /読み手の問い/.test(body.textContent), msg: A.st.msg }; });
  if (!(/診断/.test(r.lb || '') && r.side === 'health' && r.secs.includes('プ譜') && r.pf.length && /^pf_/.test(r.open) && r.pf.reduce((s, x) => s + +x.split(':')[1], 0) === r.lintN)) bad('the pufu check opens the health panel at its プ譜 group', r);
  if (!r.rq) bad('the machine review is called 読み手の問い in the health panel', r);
  await page.evaluate(() => { FZ.app.run('health'); });

  /* 7. 取扱説明書とガイド */
  r = await page.evaluate(() => { const m = FZ.manualText(), g = FZ.guideText(); return ['役の名前', '薄い手引き', '読み手の問い', '閉じる ×'].filter(w => !m.includes(w) || !g.includes(w)); });
  if (r.length) bad('the manual and the guide describe role names, faint guides, 読み手の問い and the close button', r);

  await browser.close();
  if (errors.length) console.log(errors.join('\n'));
  console.log(fails || errors.length ? `test-116h-app fails=${fails} errors=${errors.length}` : 'test-116h-app OK');
  process.exit(fails || errors.some(e => /PAGEERROR/.test(e)) ? 1 : 0);
})();
