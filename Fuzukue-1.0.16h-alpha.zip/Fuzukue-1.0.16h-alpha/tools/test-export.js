/* Word / PowerPoint 書き出しの検査：生成・XML 整形式・主要部品の存在 */
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 900 }, bypassCSP: true }); /* 1.0.15a 見本の文書を差し込む試験用の script は CSP を外して */
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  await page.addScriptTag({ path: __dirname + '/fz-samples.js' });
  let fails = 0;
  const res = await page.evaluate(() => {
    const parse = (u8) => { // 最小 ZIP 読み（store のみ）
      const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength); const files = {}; let p = 0; const td = new TextDecoder();
      while (p + 30 <= u8.length && dv.getUint32(p, true) === 0x04034b50) { const n = dv.getUint16(p + 26, true), x = dv.getUint16(p + 28, true), sz = dv.getUint32(p + 18, true); const name = td.decode(u8.subarray(p + 30, p + 30 + n)); files[name] = td.decode(u8.subarray(p + 30 + n + x, p + 30 + n + x + sz)); p += 30 + n + x + sz; }
      return files;
    };
    const check = (files) => { const bad = []; for (const [n, t] of Object.entries(files)) { if (!/\.(xml|rels)$/.test(n)) continue; const d = new DOMParser().parseFromString(t, 'application/xml'); if (d.querySelector('parsererror')) bad.push(n); } return bad; };
    const out = {};
    for (const [name, text] of [['sample', FZ.sampleText()], ['news', FZ.sampleNews()]]) {
      const doc = FZ.parse(text);
      const dx = parse(FZ.toDocx(doc)), px = parse(FZ.toPptx(doc));
      out[name] = { docxBad: check(dx), pptxBad: check(px), docxParts: Object.keys(dx).length, slides: Object.keys(px).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n)).length, pages: FZ.layout(doc).pages.length,
        numbering: (dx['word/numbering.xml'].match(/<w:lvl /g) || []).length, tables: (dx['word/document.xml'].match(/<w:tbl>/g) || []).length, figures: (dx['word/document.xml'].match(/wpg:wgp/g) || []).length / 2, headings: (dx['word/document.xml'].match(/w:pStyle w:val="Heading1"/g) || []).length,
        pptTables: Object.values(px).join('').split('<a:tbl>').length - 1, pptLines: Object.values(px).join('').split('<p:cxnSp>').length - 1 };
    }
    return out;
  });
  console.log(JSON.stringify(res, null, 1));
  for (const [k, r] of Object.entries(res)) { if (r.docxBad.length || r.pptxBad.length) { fails++; console.log('FAIL xml', k, r.docxBad, r.pptxBad); } if (r.slides !== r.pages) { fails++; console.log('FAIL slide count', k); } if (r.tables < 1 || r.numbering < 9) { fails++; console.log('FAIL docx parts', k); } }
  if (res.sample.figures < 1 || res.sample.pptLines < 4) { fails++; console.log('FAIL figure export'); }
  // コマンド経由（ダウンロード）
  const dl = page.waitForEvent('download', { timeout: 5000 }).catch(() => null);
  await page.evaluate(() => { window.showSaveFilePicker = undefined; /* 1.0.13b：保存の窓の無いブラウザはダウンロードに */ FZ.app.ed.setDoc(FZ.parse(FZ.sampleText())); FZ.app.run('exportDocx'); });
  const d = await dl; if (!d) { fails++; console.log('FAIL download', d && d.suggestedFilename()); } else console.log('download', d.suggestedFilename());
  console.log(`export fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
