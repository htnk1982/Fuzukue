/* 図ブロック（フローチャート）の検査：キー操作・マウス・フォーム・往復 */
const { chromium } = require('playwright');
const out = '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 900 } }); require('./fkey-shim')(page);
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  let fails = 0; const F = () => page.evaluate(() => JSON.parse(JSON.stringify(FZ.app.ed.doc.lines.find(l => l.attrs.figure).attrs.figure)));
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); d.lines = [FZ.newLine('手順の説明'), FZ.newLine('')]; FZ.app.ed.setDoc(d); FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); FZ.app.render(); });
  // 1) F6→I で図を入れる → 図モード、箱1 が選択
  await page.keyboard.press('F7'); await page.keyboard.press('i'); await page.waitForTimeout(40);
  let mode = await page.evaluate(() => FZ.app.st.mode); if (mode !== 'fig') { fails++; console.log('FAIL enter fig mode', mode); }
  // 2) 箱1 の文字を Enter で編集（その場の入力欄）
  await page.keyboard.press('Enter'); await page.waitForTimeout(30); await page.fill('textarea.inl', '受付'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  // 3) N で箱を足し、文字を入れる（その場の入力欄が開く）
  await page.keyboard.press('n'); await page.waitForTimeout(30); await page.fill('textarea.inl', '審査する'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  await page.keyboard.press('n'); await page.waitForTimeout(30); await page.fill('textarea.inl', '承認'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  let f = await F(); console.log('boxes', f.boxes.map(b => `${b.id}:${b.text}@${b.x},${b.y}`).join(' '));
  if (f.boxes.length !== 3 || f.boxes[0].text !== '受付') { fails++; console.log('FAIL add boxes'); }
  // 4) 矢印でつなぐ：箱3 選択中 → Tab で箱1 → C → Tab → Enter（箱2 へ）
  await page.keyboard.press('1'); await page.keyboard.press('c'); await page.keyboard.press('2'); await page.waitForTimeout(30);
  await page.keyboard.press('2'); await page.keyboard.press('c'); await page.keyboard.press('Tab'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  f = await F(); console.log('arrows', JSON.stringify(f.arrows)); if (!(f.arrows.length === 2 && f.arrows[0].from === 1 && f.arrows[0].to === 2 && f.arrows[1].from === 2 && f.arrows[1].to === 3)) { fails++; console.log('FAIL connect'); }
  // 5) 矢印のラベル：選択中の矢印に Enter
  await page.keyboard.press('Enter'); await page.waitForTimeout(30); await page.fill('textarea.inl', 'OK'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  f = await F(); if (f.arrows[1].label !== 'OK') { fails++; console.log('FAIL arrow label', f.arrows[1]); }
  // 6) 箱3 を矢印キーで動かす／Shift で大きさ
  await page.keyboard.press('3'); const b3 = (await F()).boxes[2]; await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowLeft'); await page.keyboard.press('Shift+ArrowRight'); await page.waitForTimeout(30);
  f = await F(); const nb3 = f.boxes[2]; console.log('moved', JSON.stringify([b3, nb3])); if (!(nb3.y === b3.y + 2 && nb3.x === b3.x - 1 && nb3.w === b3.w + 1)) { fails++; console.log('FAIL move/resize'); }
  // 7) 線種・網・太字
  await page.keyboard.press('k'); await page.keyboard.press('s'); await page.keyboard.press('s'); await page.keyboard.press('s'); await page.keyboard.press('b'); await page.waitForTimeout(30);
  f = await F(); if (!(f.boxes[2].kind === 'thick' && f.boxes[2].shade === 'dark' && f.boxes[2].bold)) { fails++; console.log('FAIL props', f.boxes[2]); }
  // 8) レーン（縦）
  await page.keyboard.press('l'); await page.waitForTimeout(30); await page.evaluate(() => { const s = document.querySelector('#sub .cyc[data-name="dir"]'); s.selectedIndex = (s.selectedIndex + 1) % s.options.length; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.fill('#sub input[name="titles"]', '窓口｜審査部｜決裁'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  f = await F(); if (!(f.lanes && f.lanes.dir === 'v' && f.lanes.items.length === 3)) { fails++; console.log('FAIL lanes', f.lanes); }
  // 9) マウス：箱1 をドラッグで右下へ
  const geom = await page.evaluate(() => { const fi = (() => { const ln = FZ.app.ed.doc.lines.findIndex(l => l.attrs.figure); const lm = FZ.app.ed.lay.lineMap[ln]; return { Y0: lm.rows[0].y, left: lm.segs[0].rows[0].left }; })(); const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = r.width / g.W; return { fi, r: { left: r.left, top: r.top }, g: { left: g.left, top: g.top, cw: g.cw, ch: g.ch, hr: g.headerRows }, sc }; });
  const b1 = (await F()).boxes[0]; const px = (x, y) => ({ x: geom.r.left + (geom.g.left + (geom.fi.left + x) * geom.g.cw) * geom.sc, y: geom.r.top + (geom.g.top + (geom.g.hr + geom.fi.Y0 + y) * geom.g.ch) * geom.sc });
  const p0 = px(b1.x + 1, b1.y + 1), p1 = px(b1.x + 1 + 20, b1.y + 1 + 3);
  await page.mouse.move(p0.x, p0.y); await page.mouse.down(); await page.mouse.move(p0.x + 10, p0.y + 5); await page.mouse.move(p1.x, p1.y, { steps: 4 }); await page.mouse.up(); await page.waitForTimeout(50);
  f = await F(); console.log('drag', JSON.stringify([b1.x, b1.y, f.boxes[0].x, f.boxes[0].y])); if (!(f.boxes[0].x === b1.x + 20 && f.boxes[0].y === b1.y + 3)) { fails++; console.log('FAIL drag'); }
  // 10) 高さ＋、Esc で本文へ → 図の行にカーソル → Enter で再入
  await page.keyboard.press('+'); await page.keyboard.press('Escape'); await page.waitForTimeout(30);
  mode = await page.evaluate(() => [FZ.app.st.mode, !!FZ.app.ed.line().attrs.figure]); if (!(mode[0] === 'text' && mode[1])) { fails++; console.log('FAIL exit', mode); }
  await page.keyboard.type('x'); await page.keyboard.press('Enter'); await page.waitForTimeout(30);
  mode = await page.evaluate(() => [FZ.app.st.mode, FZ.app.ed.doc.lines.find(l => l.attrs.figure).segs[0].text]); if (!(mode[0] === 'fig' && mode[1] === '')) { fails++; console.log('FAIL re-enter / typing blocked', mode); }
  // 11) 削除：矢印を Tab で選んで Delete、箱を Delete
  await page.keyboard.press('Escape'); await page.keyboard.press('Enter'); // re-enter
  await page.evaluate(() => { FZ.app.st.fig.sel = null; FZ.app.st.fig.selArrow = 0; }); await page.keyboard.press('Delete'); await page.waitForTimeout(30);
  f = await F(); if (f.arrows.length !== 1) { fails++; console.log('FAIL delete arrow', f.arrows); }
  // 12) 往復
  const rt = await page.evaluate(() => { const t = FZ.serialize(FZ.app.ed.doc); const d = FZ.parse(t); return { ok: FZ.serialize(d) === t, n: (t.match(/^#箱 /gm) || []).length, l: /^#レーン 縦/m.test(t), fig: /\[図\d+\]/.test(t) }; }); console.log('roundtrip', JSON.stringify(rt)); if (!(rt.ok && rt.n === 3 && rt.l && rt.fig)) { fails++; console.log('FAIL roundtrip'); }
  await page.evaluate(() => FZ.app.flush()); await page.waitForTimeout(80);
  await page.screenshot({ path: out + 'figure.png', clip: { x: 0, y: 0, width: 1180, height: 900 } });
  // 13) Markdown 書出でも落ちない／本文側の Enter で図を割らない
  const md = await page.evaluate(() => FZ.toMarkdown(FZ.app.ed.doc)); if (typeof md !== 'string') { fails++; }
  console.log(`figure fails=${fails}`, 'errors:', errors);
  await browser.close(); process.exit(fails || errors.length ? 1 : 0);
})();
