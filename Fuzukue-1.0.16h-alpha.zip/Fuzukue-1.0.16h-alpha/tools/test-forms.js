const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 860 } }); require('./fkey-shim')(page);
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  await page.evaluate(() => { localStorage.clear(); const d = FZ.newDoc(); d.lines = ['一行目', '二行目', '三行目'].map(t => FZ.newLine(t)); FZ.app.ed.setDoc(d); FZ.app.render(); });
  let fails = 0; const L = () => page.evaluate(() => FZ.app.ed.doc.lines.map(l => l.segs.map(s => s.text).join('|')));
  // 書式フォーム：文字数を30にして Enter
  await page.keyboard.press('F9'); await page.keyboard.press('f'); await page.waitForTimeout(50); const focused = await page.evaluate(() => document.activeElement && document.activeElement.name); 
  await page.fill('#sub input[name=cols]', '30'); await page.evaluate(() => { const s = document.querySelector('#sub .cyc[data-name=landscape]'); s.selectedIndex = (s.selectedIndex + 1) % s.options.length; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.keyboard.press('Enter'); await page.waitForTimeout(50);
  const f = await page.evaluate(() => ({ cols: FZ.app.ed.doc.format.cols, w: FZ.app.ed.doc.format.widthMm, h: FZ.app.ed.doc.format.heightMm, form: FZ.app.st.form, active: document.activeElement.id }));
  if (!(f.cols === 30 && f.w === 297 && f.h === 210 && !f.form && f.active === 'ta')) { fails++; console.log('FAIL format form', f, 'focused initially', focused); }
  // 表フォーム
  await page.keyboard.press('Control+End'); await page.keyboard.press('Enter'); await page.keyboard.press('F8'); await page.keyboard.press('n'); await page.waitForTimeout(50); /* 1.0.10q：表は F8→N（罫線モードはやめた） */
  await page.fill('#sub input[name=cols]', '2'); await page.fill('#sub input[name=rows]', '2'); await page.keyboard.press('Enter'); await page.waitForTimeout(50);
  const t = await page.evaluate(() => ({ lines: FZ.app.ed.doc.lines.length, rules: FZ.app.ed.doc.rules.length, mode: FZ.app.st.mode, active: document.activeElement.id }));
  if (!(t.rules >= 6 && t.mode === 'text' && t.active === 'ta')) { fails++; console.log('FAIL table form', t); }
  await page.keyboard.type('A'); await page.keyboard.press('Tab'); await page.keyboard.type('B');
  let l = await L(); if (!l.some(x => x === 'A|B')) { fails++; console.log('FAIL table typing', l); }
  // 検索・置換フォーム
  await page.keyboard.press('Control+Home'); await page.keyboard.press('F3'); await page.keyboard.press('f'); await page.waitForTimeout(50); await page.fill('#sub input[name=n]', '行目'); await page.fill('#sub input[name=r]', 'ぎょうめ'); await page.click('#sub button[data-act=all]'); await page.waitForTimeout(50);
  l = await L(); if (l.filter(x => x.includes('ぎょうめ')).length !== 3) { fails++; console.log('FAIL replace all', l); }
  await page.keyboard.press('Escape'); await page.keyboard.type('x'); l = await L(); if (!l[0].startsWith('x')) { fails++; console.log('FAIL focus after form', l[0], await page.evaluate(() => document.activeElement.id)); }
  // 未保存確認フォーム：新規 → D で破棄
  await page.keyboard.press('F2'); await page.keyboard.press('n'); await page.waitForTimeout(50); const ask = await page.evaluate(() => FZ.app.st.form); if (ask !== 'ask') { fails++; console.log('FAIL ask form', ask); }
  await page.keyboard.press('d'); await page.waitForTimeout(50); const nd = await page.evaluate(() => FZ.app.st.form); if (nd !== 'newdoc') { fails++; console.log('FAIL newdoc form', nd); } await page.keyboard.press('1'); await page.waitForTimeout(50); l = await L(); if (!(l.length === 1 && l[0] === '')) { fails++; console.log('FAIL discard', l); }
  // 子メニュー：F6→8 中央、クリックで太字チップ
  await page.keyboard.type('中央の行'); await page.keyboard.press('F6'); await page.keyboard.press('8'); const al = await page.evaluate(() => FZ.app.ed.line().attrs.align); if (al !== 'center') { fails++; console.log('FAIL F6→8', al); }
  await page.keyboard.press('F5'); await page.waitForTimeout(30); await page.click('#sub .ch[data-cmd=bold]'); await page.keyboard.type('太'); const mk = await page.evaluate(() => FZ.app.ed.doc.lines[0].segs[0].marks.join('')); if (!mk.endsWith('1')) { fails++; console.log('FAIL quick bold click', mk); }
  // グループ開いたまま通常文字 → グループ閉じて入力される
  await page.keyboard.press('F5'); await page.keyboard.type('z'); const g = await page.evaluate(() => ({ armed: FZ.app.st.armed, t: FZ.app.ed.doc.lines[0].segs[0].text })); if (g.armed || !g.t.endsWith('z')) { fails++; console.log('FAIL group passthrough', g); }
  // 右パネル：F10 でコマンド一覧、検索して Enter
  await page.keyboard.press('Control+k'); await page.waitForTimeout(50); await page.keyboard.type('均等'); await page.keyboard.press('Enter'); await page.waitForTimeout(50); const al2 = await page.evaluate(() => ({ a: FZ.app.ed.line().attrs.align, side: FZ.app.st.side, active: document.activeElement.id })); if (!(al2.a === 'justify' && !al2.side && al2.active === 'ta')) { fails++; console.log('FAIL palette', al2); }
  console.log(`forms: fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
