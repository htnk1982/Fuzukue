/* 1.0.15c（B-14）往復の行列：見本の原本ごとに、原本（.fzk）・文机 Markdown・Word・テキストへ書いて読み戻し、変わらないこと／字が残ることを確かめる */
for (const f of ['fz-core', 'fz-figure', 'fz-mermaid', 'fz-chart', 'fz-editor', 'fz-styles', 'fz-entities', 'fz-md', 'fz-gfm', 'fz-zip', 'fz-export', 'fz-pufu', 'fz-docx', 'fz-docxin']) require('../app/js/' + f + '.js');
const FZ = globalThis.FZ, fs = require('fs'), path = require('path');
let fail = 0; const bad = (m, i) => { fail++; console.log('NG', m, i !== undefined ? JSON.stringify(i).slice(0, 500) : ''); };
const tx = l => l.segs.map(s => s.text).join('');
(async () => {
  const dir = path.join(__dirname, '../samples'); const files = fs.readdirSync(dir).filter(f => /\.fzk$/.test(f)); const rows = [];
  for (const f of files) { const text = fs.readFileSync(path.join(dir, f), 'utf8'); const d = FZ.parse(text); const row = { f, lines: d.lines.length };
    /* 原本：書いて読み戻すと同じ（2 回目からは字も同じ） */
    const s1 = FZ.serialize(d), s2 = FZ.serialize(FZ.parse(s1)); row.fzk = s1 === s2; if (!row.fzk) bad(f + ': .fzk round trip is not stable');
    /* 文机 Markdown：書いて読み戻して書くと同じ */
    try { const base = () => { const b = FZ.newDoc(); b.format = JSON.parse(JSON.stringify(d.format)); return b; }; const anchors = d.lines.map(l => l.attrs.anchor).filter(Boolean), figs = d.lines.flatMap(l => (l.attrs.figs || []).map(x => x.id));
      const md1 = FZ.toGfm(d, { fz: true }); const d2 = FZ.fromGfm(md1, base(), { refTargets: { anchors, figs } }); const md2 = FZ.toGfm(d2, { fz: true }); row.md = md1 === md2;
      if (!row.md) { const a = md1.split('\n'), b = md2.split('\n'); let k = 0; while (k < a.length && a[k] === b[k]) k++; bad(f + ': fz-Markdown round trip is not stable', [k, a[k], b[k]]); } } catch (e) { row.md = false; bad(f + ': fz-Markdown failed ' + e.message); }
    /* Word（流れの Word）：書いて読み戻すと、4 字以上の行の字の頭がどれも見つかる（図・目次の行は除く） */
    try { const buf = FZ.zip(FZ.toDocx(d, { files: true, flow: true })); const R = await FZ.fromDocx(buf); const norm = t => String(t).replace(/[\s　*_\\]/g, ''); const got = norm(R.doc.lines.map(tx).join(''));
      const miss = []; const inGantt = i => { if (!FZ.inTable(d, i)) return false; let a = i; while (a > 0 && FZ.inTable(d, a - 1)) a--; return !!d.lines[a].attrs.gantt; }; /* 工程表の期間のセルの字は矢羽根になる */
      d.lines.forEach((l, i) => { if (l.attrs.figure || l.attrs.toc || inGantt(i)) return; const t = norm(FZ.expandRefsText(d, tx(l))); if (t.length >= 4 && !got.includes(t.slice(0, 30))) miss.push(i + ':' + t.slice(0, 12)); });
      row.docx = miss.length; if (process.env.RT_SHOW) console.log(f, miss); if (miss.length > Math.max(2, d.lines.length * 0.01)) bad(f + ': Word round trip lost text', miss.slice(0, 8)); } catch (e) { row.docx = 'ERR'; bad(f + ': Word round trip failed ' + e.message); }
    /* テキスト：どの行の字も入る */
    try { const t = FZ.toPlain(d).replace(/[\s　]/g, ''); const miss = d.lines.filter(l => !l.attrs.figure && !l.attrs.toc && tx(l).trim().length >= 4 && !t.includes(FZ.expandRefsText(d, tx(l)).replace(/[\s　]/g, '').slice(0, 20))).length; row.txt = miss; if (miss) bad(f + ': text export lost lines', miss); } catch (e) { row.txt = 'ERR'; bad(f + ': text failed ' + e.message); }
    rows.push(row); }
  console.table(rows);
  console.log(fail ? 'roundtrip fails=' + fail : 'roundtrip OK');
  process.exit(fail ? 1 : 0);
})();
