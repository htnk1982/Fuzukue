/* 見出し飾り・表スタイルの検査 */
const { chromium } = require('playwright');
const out = '/tmp/claude-0/-home-claude/92a55341-730e-5359-af7b-ea1ad86ac8ec/scratchpad/fz/';
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1180, height: 1000 } }); require('./fkey-shim')(page);
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file:///home/claude/fuzukue/app/index.html'); await page.waitForTimeout(400);
  let fails = 0;
  const md = '地震で新幹線が全線停止\n\n首都圏の足、終日乱れる\n\n政府が対策本部を設置\n\n## 主な企業の決算\n\n| 社名 | 売上高 | 前年比 | 純利益 |\n|---|---|---|---|\n| 東京電機 | 12,340 | 5.2 | 830 |\n| 大阪精機 | 8,120 | -3.1 | -120 |\n| 合計 | 20,460 | 1.8 | 710 |\n';
  await page.evaluate((md) => { localStorage.clear(); const d = FZ.fromMarkdown(md); FZ.app.ed.setDoc(d); FZ.app.render(); }, md);
  // 見出し飾り：1行目にベタ白抜き
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); });
  await page.keyboard.press('F6'); await page.keyboard.press('y'); await page.waitForTimeout(30); /* 1.0.10q：見出し飾りは F6→Y */
  const grp = await page.evaluate(() => FZ.app.st.group); if (grp !== 'head') { fails++; console.log('FAIL head group', grp); }
  await page.keyboard.press('4'); await page.waitForTimeout(30);
  const f0 = await page.evaluate(() => [FZ.app.ed.doc.lines[0].attrs.deco, ...FZ.app.ed.lay.pages[0].fills.filter(f => f.from === 0 && f.deco).map(f => f.shade)]); if (!(f0[0] === 'ベタ白抜き' && f0.includes('dark'))) { fails++; console.log('FAIL beta fill (deco attr + layout fill)', f0); } // 飾りは行の属性、網は組版が引く（K-3）
  // 2〜3行目を選択して千鳥
  await page.evaluate(() => { const ed = FZ.app.ed; for (let i = ed.doc.lines.length - 1; i > 0; i--) if (i < 5 && ed.doc.lines[i].segs[0].text === '') ed.removeLine(i); ed.relayout(); ed.setCaret({ line: 1, seg: 0, off: 0 }); ed.anchor = { line: 1, seg: 0, off: 0 }; ed.caret = { line: 2, seg: 0, off: 3, vcol: null, vrow: 0 }; ed.onCaret(); });
  await page.evaluate(() => FZ.app.run('hd:chidori')); await page.waitForTimeout(30);
  const ch = await page.evaluate(() => FZ.app.ed.doc.lines.slice(1, 3).map(l => ({ ind: l.attrs.indent, wide: !!(l.segs[0].marks[0] & FZ.M.WIDE), bold: !!(l.segs[0].marks[0] & FZ.M.BOLD) }))); console.log('chidori', JSON.stringify(ch));
  if (!(ch[0].wide && ch[0].bold && ch[1].ind >= 2 && !ch[1].wide)) { fails++; console.log('FAIL chidori'); }
  // 表スタイル：決算表
  const tl = await page.evaluate(() => FZ.app.ed.doc.lines.findIndex(l => l.attrs.cells));
  await page.evaluate((tl) => { FZ.app.ed.setCaret({ line: tl + 1, seg: 1, off: 0 }); }, tl);
  await page.keyboard.press('F8'); await page.keyboard.press('u'); await page.waitForTimeout(30);
  const grp2 = await page.evaluate(() => FZ.app.st.group); if (grp2 !== 'table') { fails++; console.log('FAIL table group', grp2); }
  await page.keyboard.press('4'); await page.waitForTimeout(40);
  const tb = await page.evaluate((tl) => { const d = FZ.app.ed.doc; const rows = d.lines.filter(l => l.attrs.cells); return { v: d.rules.filter(r => r.axis === 'v').map(r => r.kind), h: d.rules.filter(r => r.axis === 'h').sort((a, b) => a.line - b.line).map(r => r.line + ':' + r.kind), fills: d.fills.filter(f => f.from === tl).map(f => f.shade), align: rows.map(l => (l.attrs.cellAlign || []).join(',')), neg: rows.map(l => l.segs.map(s => s.text).join('|')) }; }, tl); console.log('table', JSON.stringify(tb));
  if (!(tb.v.every(k => k === 'none') && tb.fills.includes('dark') && tb.align[1].includes('right') && tb.neg[2].includes('▲3.1') && tb.neg[2].includes('▲120'))) { fails++; console.log('FAIL fin table'); }
  // 単位行・注
  console.log('caret', await page.evaluate(() => JSON.stringify([FZ.app.ed.caret, FZ.tableRange(FZ.app.ed), FZ.app.st.msg])));
  await page.evaluate(() => FZ.app.run('to:note')); await page.evaluate((tl) => { FZ.app.ed.setCaret({ line: tl + 1, seg: 0, off: 0 }); }, tl); await page.evaluate(() => FZ.app.run('to:unit')); await page.waitForTimeout(30);
  const un = await page.evaluate(() => { const L = FZ.app.ed.doc.lines; const ui = L.findIndex(l => l.segs[0].text.startsWith('（単位')); const t0 = L.findIndex(l => l.attrs.cells); return { u: ui >= 0 ? L[ui].segs[0].text : '', al: ui >= 0 ? L[ui].attrs.align : null, ind: ui >= 0 ? L[ui].attrs.indent : null, n: L.find(l => l.segs[0].text.startsWith('（注）')) != null, caret: FZ.app.ed.caret.line, ui, t0 }; }); // 単位行は表の直前（見出しの直後に表があれば挿入、空行があればその行） console.log('unit/note', JSON.stringify(un));
  if (!(un.u.startsWith('（単位') && (un.al === 'right' || un.ind >= 10) && un.n && un.caret === un.ui && un.ui === un.t0 - 1)) { fails++; console.log('FAIL unit/note'); }
  // 統計表へ切替（合計行の上に細罫）
  await page.evaluate((tl) => { FZ.app.ed.setCaret({ line: tl + 2, seg: 0, off: 0 }); }, tl + 1);
  await page.evaluate(() => FZ.app.run('tb:stat')); await page.waitForTimeout(30);
  const st2 = await page.evaluate(() => { const d = FZ.app.ed.doc; return d.rules.filter(r => r.axis === 'h').sort((a, b) => a.line - b.line).map(r => r.line + ':' + r.kind); }); console.log('stat rules', st2.join(' '));
  if (st2.length !== 4) { fails++; console.log('FAIL stat rules (expect top, header, total, bottom)'); }
  // 往復
  const rt = await page.evaluate(() => { const t = FZ.serialize(FZ.app.ed.doc); const d = FZ.parse(t); return { ok: FZ.serialize(d) === t, tbl: /^#表 .*様式 (統計表|独自)/m.test(t), ca: /列揃え/.test(t) }; }); console.log('roundtrip', JSON.stringify(rt)); if (!(rt.ok && rt.tbl && rt.ca)) { fails++; console.log('FAIL roundtrip'); }
  await page.evaluate(() => { FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 }); FZ.app.flush(); }); await page.keyboard.press('Escape'); await page.waitForTimeout(80);
  await page.screenshot({ path: out + 'styles.png', clip: { x: 0, y: 0, width: 1180, height: 560 } });
  // 全プリセットを順に適用してエラーがないか
  for (const t of ['grid', 'news', 'compare', 'box', 'bare', 'fin']) { await page.evaluate((tl) => { FZ.app.ed.setCaret({ line: tl + 1, seg: 0, off: 0 }); }, tl + 1); await page.evaluate((t) => FZ.app.run('tb:' + t), t); }
  for (const h of ['sub', 'h', 'big', 'beta2', 'shade', 'hatch', 'dots', 'box', 'under', 'under2', 'outline', 'lead', 'sep', 'clear']) { await page.evaluate(() => { FZ.app.ed.setCaret({ line: 2, seg: 0, off: 0 }); }); await page.evaluate((h) => FZ.app.run('hd:' + h), h); }
  await page.evaluate(() => { const ed = FZ.app.ed; ed.setCaret({ line: 0, seg: 0, off: 0 }); ed.anchor = { line: 0, seg: 0, off: 0 }; ed.caret = { line: 2, seg: 0, off: 0, vcol: null, vrow: 0 }; ed.onCaret(); FZ.app.run('hd:article'); FZ.app.flush(); }); await page.waitForTimeout(80);
  await page.screenshot({ path: out + 'styles2.png', clip: { x: 0, y: 0, width: 1180, height: 560 } });
  console.log(`styles fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
