/* 目次の操作（画面）：F6→M で入れる、Enter で範囲、文字は入らない、Backspace で消す、上下移動でまたぐ、クリックで行に乗る */
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const browser = await chromium.launch(); const page = await browser.newPage({ viewport: { width: 1280, height: 900 } }); require('./fkey-shim')(page);
  const errors = []; page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '../app/index.html')); await page.waitForTimeout(400);
  let fails = 0; const bad = (n, i) => { fails++; console.log('FAIL', n, JSON.stringify(i)); };
  await page.evaluate(() => { localStorage.clear(); FZ.app.loadText('#fzk 2\n文字数: 40\n行数: 20\n---\n[表題]報告\n\n[番号1]背景\n本文です。\n[番号2]市場\n[記号1]現状\n[項目1]a\n[番号2]競合\n[番号1]課題\n', '試験.fzk'); });
  await page.waitForTimeout(200); await page.evaluate(() => { FZ.app.ed.setCaret({ line: 1, seg: 0, off: 0 }); });
  await page.keyboard.press('F7'); await page.keyboard.press('m'); await page.waitForTimeout(100);
  const form = await page.evaluate(() => document.getElementById('sub').textContent); if (!/目次.*数字見出し.*記号見出し/.test(form)) bad('toc form', form);
  await page.keyboard.press('Enter'); await page.waitForTimeout(150);
  const attrs = await page.evaluate(() => JSON.stringify(FZ.app.ed.doc.lines[1].attrs)); if (attrs !== '{"toc":{"num":[0,1],"sym":null}}') bad('toc inserted', attrs);
  const rows = await page.evaluate(() => FZ.app.ed.lay.lineMap[1].rows[0].h); if (rows !== 4) bad('toc rows', rows);
  const sty = await page.evaluate(() => document.getElementById('status').textContent); if (!/目次（Enter で範囲）/.test(sty)) bad('status shows toc', sty.slice(0, 100));
  await page.keyboard.type('x'); await page.waitForTimeout(50); const t = await page.evaluate(() => FZ.app.ed.doc.lines[1].segs[0].text); if (t !== '') bad('no typing on toc', t);
  await page.keyboard.press('Enter'); await page.waitForTimeout(100); const f2 = await page.evaluate(() => document.getElementById('sub').textContent); if (!/範囲を変える/.test(f2)) bad('enter opens form', f2.slice(0, 60));
  await page.evaluate(() => { const s = document.querySelector('.cyc[data-name="sym"]'); s.selectedIndex = (s.selectedIndex + 1) % s.options.length; s.dispatchEvent(new Event('change', { bubbles: true })); }); await page.keyboard.press('Enter'); await page.waitForTimeout(150);
  const a2 = await page.evaluate(() => JSON.stringify(FZ.app.ed.doc.lines[1].attrs.toc)); if (a2 !== '{"num":[0,1],"sym":[0,0]}') bad('range changed (sym 1)', a2);
  const rows2 = await page.evaluate(() => FZ.app.ed.lay.lineMap[1].rows[0].h); if (rows2 !== 5) bad('toc rows after sym', rows2);
  await page.evaluate(() => FZ.app.ed.setCaret({ line: 0, seg: 0, off: 0 })); await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowDown'); await page.waitForTimeout(50);
  const c = await page.evaluate(() => FZ.app.ed.caret.line); if (c !== 2) bad('arrow crosses toc block', c);
  // クリックで目次の行に乗る
  const pt = await page.evaluate(() => { const w = document.querySelector('.pgwrap'); const r = w.getBoundingClientRect(); const g = FZ.app.ed.lay.geo; const sc = r.width / g.W; return { x: r.left + (g.left + 3 * g.cw) * sc, y: r.top + (g.top + (g.bodyTop + 2.5) * g.ch) * sc }; });
  await page.mouse.click(pt.x, pt.y); await page.waitForTimeout(80); const c2 = await page.evaluate(() => FZ.app.ed.caret.line); if (c2 !== 1) bad('click lands on toc line', c2);
  await page.keyboard.press('Backspace'); await page.waitForTimeout(80); const a3 = await page.evaluate(() => JSON.stringify(FZ.app.ed.doc.lines[1].attrs)); if (a3 !== '{}') bad('backspace removes toc', a3);
  await page.keyboard.press('Control+z'); await page.waitForTimeout(50); const a4 = await page.evaluate(() => !!FZ.app.ed.doc.lines[1].attrs.toc); if (!a4) bad('undo restores toc');
  console.log(`toc fails=${fails}`, 'errors:', errors);
  await browser.close();
})();
